#!/bin/bash -e

: ${AAC_QUEUE_NAME:=aac}

run_celery() {
    celery -A mq_async worker \
        -n worker_aac -c 4 -Q ${AAC_QUEUE_NAME} \
        --workdir=${INSTANCE_HOME} \
        --pidfile=/var/run/celery/%n.pid \
        --time-limit=200
}

if [[ $# -eq 0 ]]; then
    run_celery
elif [[ $1 == "tests" ]]; then
    py.test ${APPDIR}/tests
else
    exec "$@"
fi
