#!/bin/sh

set -e

SL=$INSTANCE_HOME/cms/afl/settingslocal.py
cat <<EOF >> $SL;
DATABASES['default'] = {'ENGINE': 'django.db.backends.postgresql_psycopg2',
                        'NAME': '$POSTGRES_ENV_POSTGRES_USER',
                        'USER': '$POSTGRES_ENV_POSTGRES_USER',
                        'PASSWORD': '$POSTGRES_ENV_POSTGRES_PASSWORD',
                        'HOST': '$POSTGRES_PORT_5432_TCP_ADDR',
                        'PORT': $POSTGRES_PORT_5432_TCP_PORT,}
EOF

exec $@
