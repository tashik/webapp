# -*- coding: utf-8 -*-

import os

DATABASES = {
    'sync':   {'ENGINE': 'django.db.backends.sqlite3', 'NAME': 'sync.db', 'HOST': 'localhost', 'USER': '', 'PASSWORD': '', 'PORT': ''}
}

SITE_ID = 1
SITE_URL = "https://www.aeroflot.ru"
SITE_DOMAIN = "www.aeroflot.ru"

SITE_DOMAIN = "192.168.1.46:8000"

# ПОДСИСТЕМЫ
# Антифрод / Ретро ПС-1
RETRO_URL = ""
# Аэрофлот Бенефит ПС-2
BENEFIT_URL = ""
# Онлайн-табло ПС-3
ONLINE_TABLE_URL = "http://onlineboard.aeroflot.ru/"
# Деловой проездной ПС-4
BUSINESS_TRAVEL_URL = ""
# Единая система справочников (VOCABS2) ПС-5
VOCABS_URL = ""
# Единое окно ПС-6
UNIVERSAL_BOX_URL = ""
# ИКМ Skyteam ПС-7
SKYTEAM_URL = ""
# Каталог партнеров ПС-8
PARTNERS_CATALOG_URL = ""
# Консьерж сервис ПС-9
CONCIERGE_SERVICE_URL = ""
# Личный кабинет ПС-10
PERSONAL_URL = ""
# ЛК - Мои бронирования ПС-11
PERSONAL_BOOKINGS_URL = ""
# ЛК - Ретро-онлайн ПС-12
PERSONAL_RETRO_ONLINE_URL = ""
# МУС ПС-13
ICC_URL = ""
# ЛК - Статус груза ПС-14
PERSONAL_CARGO_STATUS_URL = ""
# ПМБ ПС-15
PMB_URL = ""
# Специальные предложения (Хит тарифы) ПС-16
SPECIAL_OFFERS_URL = ""
# Подсистема веб сервисов ПС-17
WEB_SERVICES_URL = SITE_URL + "/ws2/"
# Система таргетированных баннеров (СТБ) ПС-18
TARGETED_BANNERS_SYSTEM_URL = ""
# Расписание рейсов ПС-19
FLIGHT_SCHEDULE_URL = ""
# Форум ПС-20
FORUM_URL = ""

DISABLE_GEOIP = True

OFFICES_DEFAULT_SERVICE_URL = WEB_SERVICES_URL + "v.0.0.3/json/offices"

VIRTUAL_GIFT_URL = "//www.aeroflot.ru/cms/iframe_resize_helper.html"

#SECRET_KEY = open(os.environ['HOME'] + '/cms/afl/secret-key').read().strip()

DEBUG = False
TEMPLATE_DEBUG = False
MOBILE_SITE_DOMAIN = "m.aeroflot.ru"
BANNERS_SETTINGS = {
    "url": "%(protocol)s://www.aeroflot.ru/personal_banners/v2.0.0/bulk",
    #"url": "%(protocol)s://afl-test-rc.test.aeroflot.ru/personal_banners/v2.0.0/bulk",
    "enforce_https": True
}

CONN_MAX_AGE = 3600

SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
MEDIA_ROOT = '/home/prod_cms/media'
NAME_STAND = os.environ.get('HOSTNAME', 'unknown')
SHOW_INFORMATION_LABEL = False

ADMINS = [] # (('Admin', 'an@ramax.ru'),)
MANAGERS = ADMINS
SERVER_EMAIL = "prod_cms@%s" % os.environ.get('HOSTNAME', 'localhost')
EMAIL_HOST = "klaus.com.spb.ru"
EMAIL_PORT = 25
EMAIL_USE_TLS = False

SESSION_COOKIE_SECURE = True

SECRET_KEY = open('/srv/cms/cms/afl/secret-key').read().strip()
MEDIA_ROOT = '/srv/cms/media'
ERROR_LOG = '/srv/cms/log/error.log'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(levelname)s %(asctime)s %(module)s %(process)d %(thread)d %(message)s'
        },
        'simple': {
            'format': '%(levelname)s %(message)s'
        }
    },
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'null': {
            'level':'DEBUG',
            'class':'django.utils.log.NullHandler',
        },
        'mail_admins': {
            'level': 'ERROR',
            'class': 'django.utils.log.AdminEmailHandler',
            'formatter': 'verbose'
        },
        'file_error': {
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': ERROR_LOG,
            'maxBytes': 10485760,
            'backupCount': 3,
            'formatter': 'verbose'
        },
    },
    'loggers': {
       'django.request': {
            'handlers': ['mail_admins','file_error'],
            'level': 'ERROR',
            'propagate': True,
        },
        'django': {
            'handlers': ['mail_admins','file_error'],
            'propagate': True,
            'level': 'ERROR',
        }
    }
}

