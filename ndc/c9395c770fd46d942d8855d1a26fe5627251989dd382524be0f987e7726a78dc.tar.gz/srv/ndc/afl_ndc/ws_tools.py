# -*- coding: utf-8 -*-
import cherrypy
import time
import logging
import config


def reject_stale_requests():
    start_req_time = cherrypy.request.headers.get('X-Request-Start')
    if start_req_time is None:
        return

    cherrypy.response.headers['X-Request-Start'] = start_req_time  # пробрасываем в response для тестирования
    now_time = time.time()
    timeout = config.REQUEST_TIMEOUT
    try:
        if now_time - float(start_req_time) > timeout:
            raise cherrypy.HTTPError(504, 'Rejected stale request (%s + %s > %s)' % (start_req_time, timeout, now_time))
    except ValueError as e:
        logging.error('Incorrect X-Request-Start header value: "%s"', start_req_time)
