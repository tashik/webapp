# -*- coding: utf-8 -*-
import cherrypy
import sys
import cpdispatcher


class Root(object):
    u"""Корневой пустой объект."""


def main():
    if sys.platform != 'win32':
        from pidfile import PidFile
        pidfile = PidFile("ws")

    import initializer
    initializer.initialize()

    root = Root()
    app = cherrypy.Application(root, config=cpdispatcher.mount_cfg)

    from config import cpconfig
    cherrypy.config.update(cpconfig.global_cfg)
    cherrypy.config.update(cpconfig.app_cfg)
    cherrypy.tree.mount(app)

    cherrypy.request.wsgi_environ = {}
    cherrypy.engine.start()
    cherrypy.engine.block()


if __name__ == "__main__":
    main()
