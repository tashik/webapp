# -*- coding: utf-8 -*-

"""
$Id: $
"""


import random
import string

import config


def digest_auth(digest_dict, realm):
    def get_ha1(req_realm, req_username):
        if req_realm == realm:
            ha1 = digest_dict.get(req_username)
            return ha1
    private_key = ''.join(random.choice(string.letters) for n in range(40))
    return {'tools.auth_digest.on': True,
            'tools.auth_digest.realm': realm,
            'tools.auth_digest.get_ha1': get_ha1,
            'tools.auth_digest.key': private_key}


# словарь соответствия путь : файл htdigest
def auth_paths():
    d = {
        (config.VIRTUAL_BASE + '/services/status'): digest_auth(config.MONITORING_WS_DIGEST, 'aeroflot-digest'),
    }
    return d
