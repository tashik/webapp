# -*- coding: utf-8 -*-

import os
import copy
import codecs
import logging
import rfc822
import time
from logging.handlers import TimedRotatingFileHandler
from datetime import datetime

import cherrypy
from cherrypy import _cplogging, _cperror

import config


class LogFormatter(logging.Formatter):
    HEADER_FORMAT = '{} {}'

    def format(self, record):
        try:
            ip = cherrypy.request.remote.ip
        except AttributeError:
            ip = '-'
        new_record = copy.copy(record)
        v = record.msg
        if isinstance(v,unicode):
            v = v.encode("utf-8")
        new_record.msg = self.HEADER_FORMAT.format(ip, v)
        return logging.Formatter.format(self, new_record)


class ServiceFormatter(LogFormatter):
    HEADER_FORMAT = '-@{} {}'


class AppLogging(object):
    dispatcher_logger = None

    def __init__(self):
        self.dispatcher_logger = self._init_logger('dispatcher')
        self.action_logger = self._init_logger('action')
        service_formatter = ServiceFormatter('[%(asctime)s] %(message)s', datefmt='%d/%b/%Y:%H:%M:%S')
        self.service_logger = self._init_logger('service', formatter=service_formatter)
        self.sb_logger = self._init_logger('sb', formatter=service_formatter)
        self.pmb_logger = self._init_logger('pmb', formatter=service_formatter)

    def _init_simple_file_logger(self, name, propagate=config.PROPAGATE_LOG):
        logger = logging.getLogger(name)
        logger.setLevel(config.LOG_SETTINGS.get(name, config.LOG_LEVEL))
        logger.propagate = propagate

        filename = '%s/%s.log' % (config.LOGDIR, name)
        # Без ротации
        handler = logging.FileHandler(filename)
        formatter = LogFormatter(
            '[%(asctime)s] %(levelname)s in \'%(module)s\' %(message)s',
            datefmt='%d/%b/%Y:%H:%M:%S')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

    def _init_logger(self, name, backupCount=90, propagate=config.PROPAGATE_LOG,
                     handler_factory=TimedRotatingFileHandler, formatter=None):
        logger = logging.getLogger(name)
        logger.setLevel(config.LOG_SETTINGS.get(name, config.LOG_LEVEL))
        logger.propagate = propagate

        filename = '%s/%s.log' % (config.LOGDIR, name)
        # Ротация лога раз в сутки
        handler = handler_factory(filename, when='MIDNIGHT', interval=1,
                                  backupCount=backupCount)
        if formatter is None:
            formatter = LogFormatter(
                '[%(asctime)s] %(levelname)s in \'%(module)s\' %(message)s',
                datefmt='%d/%b/%Y:%H:%M:%S'
            )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        return logger

log = AppLogging()


# Специализированный и сокращенный вариант LogManager. См. cherrypy._cplogging
# Записывает в access.log время выполнения запроса.
class CustomLogManager(object):
    access_log_format = \
        '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(ty)s %(aid)s %(tid)s %(e)s'

    def __init__(self, logger_root="cherrypy"):
        self.logger_root = logger_root
        self.error_log = logging.getLogger('%s.error' % logger_root)
        self.access_log = logging.getLogger('%s.access' % logger_root)
        self.error_log.setLevel(logging.DEBUG)
        self.access_log.setLevel(logging.INFO)

    def error(self, msg='', context='', severity=logging.INFO, traceback=False):
        """Write to the error log.

        This is not just for errors! Applications may call this at any time
        to log application-specific information.
        """
        if traceback:
            msg += _cperror.format_exc()
        self.error_log.log(severity, ' '.join((self.time(), context, msg)))

    def __call__(self, *args, **kwargs):
        """Write to the error log.

        This is not just for errors! Applications may call this at any time
        to log application-specific information.
        """
        return self.error(*args, **kwargs)

    def access(self):
        """Write to the access log (in Apache/NCSA Combined Log format).

        Like Apache started doing in 2.0.46, non-printable and other special
        characters in %r (and we expand that to all parts) are escaped using
        \\xhh sequences, where hh stands for the hexadecimal representation
        of the raw byte. Exceptions from this rule are " and \\, which are
        escaped by prepending a backslash, and all whitespace characters,
        which are written in their C-style notation (\\n, \\t, etc).
        """
        request = cherrypy.request
        remote = request.remote
        response = cherrypy.response
        outheaders = response.headers
        inheaders = request.headers
        try:
            # print time.time(), cherrypy.request.start_time
            elapsed = '%.3f' % (time.time() - cherrypy.request.start_time)
        except AttributeError:
            elapsed = '-'

        action = '-'
        logger = None
        if hasattr(request, 'logger'):
            logger = getattr(request, 'logger')
        if logger:
            action = logger.kwargs.get('action', "-")

        atoms = {'h': remote.name or remote.ip,
                 'l': '-',
                 'u': getattr(request, 'login', None) or '-',
                 't': self.time(),
                 'r': request.request_line,
                 's': response.status.split(' ', 1)[0] if response.status else None,
                 'b': outheaders.get('Content-Length', '') or '-',
                 'f': inheaders.get('Referer', ''),
                 'a': inheaders.get('User-Agent', ''),
                 'e': elapsed,
                 'ty': action,
                 'tid': getattr(request, 'tracking_id', '-'),
                 'aid': getattr(request, 'agency_id', '-')
                 }
        for k, v in atoms.items():
            if isinstance(v, unicode):
                v = v.encode('utf8')
            elif not isinstance(v, str):
                v = str(v)
            # Fortunately, repr(str) escapes unprintable chars, \n, \t, etc
            # and backslash for us. All we have to do is strip the quotes.
            v = repr(v)[1:-1]
            # Escape double-quote.
            atoms[k] = v.replace('"', '\\"')

        try:
            self.access_log.log(logging.INFO, self.access_log_format % atoms)
        except:
            self(traceback=True)

    def time(self):
        """Return now() in Apache Common Log Format (no timezone)."""
        time_now = datetime.now()
        month = rfc822._monthnames[time_now.month - 1].capitalize()
        return ('[%02d/%s/%04d:%02d:%02d:%02d]' %
                (time_now.day, month, time_now.year, time_now.hour,
                 time_now.minute, time_now.second))


def initCherrypyLoggers():
    formatter = logging.Formatter(
        '[%(asctime)s] %(message)s', datefmt='%d/%b/%Y:%H:%M:%S'
    )

    root = logging.root
    root.setLevel(config.LOG_LEVEL)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)

    log = cherrypy.log = CustomLogManager()
    backupCount = getattr(log, 'rot_backupCount', 90)
    error_fname = getattr(log, 'rot_error_file', config.LOGDIR + '/error.log')
    error_handler = TimedRotatingFileHandler(
        error_fname, when='midnight', interval=1, backupCount=backupCount
    )
    error_handler.setLevel(config.LOG_LEVEL)
    error_handler.setFormatter(_cplogging.logfmt)
    log.error_log.addHandler(error_handler)

    access_fname = getattr(log, 'rot_access_file', config.LOGDIR + '/access.log')
    access_handler = TimedRotatingFileHandler(
        access_fname, when='midnight', interval=1, backupCount=backupCount
    )
    access_handler.setLevel(logging.INFO)
    access_handler.setFormatter(_cplogging.logfmt)
    log.access_log.addHandler(access_handler)
    log.access_log.propagate = False


class RequestLogger(object):
    """Log request and response of a service"""

    delimiter = '-' * 24

    def __init__(self, logger, request_log=None, response_log=None, **kwargs):
        self.logger = logger
        self.request_log = request_log or logger.debug
        self.response_log = response_log or logger.debug
        self.kwargs = kwargs
        self.kwargs['agency_id'] = getattr(cherrypy.request, 'agency_id', None)
        self.kwargs['tracking_id'] = getattr(cherrypy.request, 'tracking_id', None)

    def _get_log_text(self, prefix, *args, **kwargs):
        all_kwargs = dict(self.kwargs)
        all_kwargs.update(kwargs)
        all_kwargs_strings = tuple('# {}={};'.format(k, v) for k, v in all_kwargs.items())
        body = (prefix,) + all_kwargs_strings + (self.delimiter,) + tuple(str(arg) for arg in args)
        return '\n'.join(body)

    def log_request(self, request, method, url, *args, **kwargs):
        text = self._get_log_text('>>>>>> {} {}'.format(method, url), request, *args, **kwargs)
        self.request_log(text)

    def log_response(self, response, *args, **kwargs):
        text = self._get_log_text('<<<<<<', response, *args, **kwargs)
        self.response_log(text)


def log_to_file(body, path=None, t=None, encoding=None):
    if not config.DEBUG:
        return ''

    if path is None:
        path = config.SB_LOGDIR

    if t is None:
        t = datetime.now()

    bucket_path = os.path.join(path, t.strftime('%Y-%m-%d'), t.strftime('%H'))
    try:
        os.makedirs(bucket_path)
    except OSError:
        pass

    filename = t.strftime('%M_%S_%f.log')
    details_path = os.path.join(bucket_path, filename)

    with codecs.open(details_path, 'a', encoding=encoding) as f:
        f.write(body)

    return details_path


@cherrypy.tools.register('before_error_response', priority=0)
def log_rand_before_error():
    if hasattr(cherrypy.request, 'tracking_id'):
        cherrypy.log.error_log.error("# tracking_id={};".format(cherrypy.request.tracking_id))
    if hasattr(cherrypy.request, 'agency_id'):
        cherrypy.log.error_log.error("# agency_id={};".format(cherrypy.request.agency_id))
