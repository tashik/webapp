# -*- coding: utf-8 -*-
from collections import defaultdict

import sys
from decimal import Decimal
from itertools import chain

import re

from datetime import datetime

import config
from clients.models import (RequestSearchParams, Route, Passenger, BookParams,
                            Flight, Tariff, PriceParameters, RelatedSegments)
from clients.pmb import PMBService
from clients.sb import SBService
from mapping.enums import (NDCCabinTypes, SBCabinTypes, NDC2SBCabinTypeMap,
                           NDC2SBPassengerTypes, NDC2SBGender,
                           NDCPassengerTypes, NDC2SBDocumentTypes)
from mapping.fare_rules import FareRulesMapping
from mapping.hierarchial_xpath_to_json import HierarchicalXPathToJsonMapper
from mapping.mapping import CSVFileMappingReader, NDCAgentIdMappingReader, NDCUserAgentMappingReader
from mapping.utils import parse_sb_datetime
from services.constants import SEGMENTS_KEY_TMP
from services.response import SBFirstClassNotSupported
from services.response.airshopping import AirShoppingRS
from services.response.flightprice import FlightPriceRS
from services.response.orderview import OrderViewRS
from exc import (InvalidPriceTypeQualifierError, NDCError, FlightNotFound,
                 InvalidSegmentError, InvalidFareBasis, AlreadyTcketed, InvalidArrivalDate, InvalidTravelAgent,
                 InvalidCountryCode, InvalidFormatError, InvalidFlightNumber, InvalidInfantsCount, InvalidServiceTypeCodeError,
                 InvalidAirportCode, GenderUndefined)

from i18n import activate, _
import cherrypy
from log import log
from utils import format_pax_name


airport_code = re.compile('^[a-zA-Z]{3}$')


def afl_service_factory(full_name):
    module_name, object_name = full_name.rsplit('.', 1)
    module = sys.modules[module_name]
    klass = getattr(module, object_name)
    if not issubclass(klass, AflService):
        raise TypeError("{} is not subclass of AflService".format(full_name))
    return klass


class AflService(object):
    request_type = NotImplemented
    response_type = NotImplemented
    response_cls = NotImplemented
    external_method = NotImplemented
    request_mapping_reader = NotImplemented
    request_mapper = NotImplemented
    response_mapping_reader = None
    response_mapper_cls = None
    response_mapper = None
    should_log_response = True

    def __init__(self):
        super(AflService, self).__init__()
        self._make_request_mapper()

    def _make_request_mapper(self):
        mapper_cls = getattr(self, 'request_mapper_cls', None)
        if mapper_cls:
            self.request_mapper = mapper_cls(self.request_mapping_reader)

    def process_request(self, request):
        request_dict = self.request_mapper.map_from_ndc(request)
        intermediate_data = self.external_method(request_dict)
        response = self.response_cls(intermediate_data)
        response.container = self.response_type
        response = self.process_response(
            request_dict, intermediate_data, response)
        result = response.get_tree()
        return result

    def process_response(self, request_data, intermediate_data, response):
        return response


class AirShoppingService(AflService):
    request_type = 'AirShoppingRQ'
    response_type = 'AirShoppingRS'
    response_cls = AirShoppingRS
    request_mapping_reader = CSVFileMappingReader(config.AIR_SHOPPING_MAPPING_FILE, True)
    request_mapper_cls = HierarchicalXPathToJsonMapper
    should_log_response = False

    def external_method(self, request_dict):
        if not request_dict.get("country"):
            raise InvalidCountryCode()
        lang = request_dict['lang']
        if lang.upper() not in config.LANGUAGES and len(lang) == 2:
            request_dict['lang'] = 'en'
        search_data = self._prepare_sb_rq(request_dict)
        with SBService() as sb_client:
            sb_response = sb_client.search(search_data, combine=True)
        return search_data, sb_response

    def process_response(self, request_data, intermediate_data, response):
        ndc_rq_cabin = request_data['cabin']
        if ndc_rq_cabin == NDCCabinTypes.FIRST_CLASS:
            msg = 'Cabin code %s is not supported, replaced with %s' \
                  % (ndc_rq_cabin, NDCCabinTypes.BUSINESS)
            response.add_warning(SBFirstClassNotSupported(msg))
        return response

    def _prepare_sb_rq(self, request_data):
        activate(request_data['lang'] or config.DEFAULT_LANGUAGE_CODE)
        ndc_rq_cabin = request_data['cabin']
        if ndc_rq_cabin not in NDCCabinTypes.cabin_types:
            raise InvalidServiceTypeCodeError()
        if ndc_rq_cabin == NDCCabinTypes.FIRST_CLASS:
            sb_rq_cabin = SBCabinTypes.BUSINESS
        else:
            sb_rq_cabin = NDC2SBCabinTypeMap.map(ndc_rq_cabin)

        max_prices = self._get_max_prices(request_data)
        routes, routes_for_filter = self._get_routes(request_data)

        anon_travelers = request_data['anonym_travelers']
        recog_travelers = request_data['recognized_travelers']

        adults = self._calc_sum('adults', anon_travelers, recog_travelers)
        children = self._calc_sum('children', anon_travelers, recog_travelers)
        infants = self._calc_sum('infants', anon_travelers, recog_travelers)

        if adults < infants:
            raise InvalidInfantsCount(ndc_internal_error_text="Number of infants exceeds maximum allowed per adult passenger")

        sb_request = RequestSearchParams(
            routes,
            sb_rq_cabin,
            adults,
            award=request_data['award'],
            lang=request_data['lang'],
            country=request_data['country'],
            currency=request_data['currency'],
            children=children,
            infants=infants,
            referrer=request_data['iata_num'],
            max_results=max_prices,
            partner_name=request_data['agency_id'],
            min_price=request_data.get('min_price'),
            routes_for_filter=routes_for_filter
        )
        return sb_request

    def _calc_sum(self, attr, *dicts):
        return sum(d[attr] for d in chain(*dicts) if d[attr])

    def _get_max_prices(self, request_data):
        max_prices = request_data.get('response_results_count')
        if max_prices:
            try:
                max_results = int(max_prices)
            except ValueError as e:
                raise InvalidFormatError(
                    ndc_internal_error_text="Invalid value for NumberOfResults. Must be 1 or higher")
            if max_results < 1:
                raise InvalidFormatError(
                    ndc_internal_error_text="Invalid value for NumberOfResults. Must be 1 or higher")
        return max_prices

    def _get_routes(self, request_data):
        routes = []
        has_flight_number = []
        found_response_id = None
        for route in request_data['routes']:
            if not re.match(airport_code, route['origin']):
                raise InvalidAirportCode(ndc_internal_error_text="Invalid departure airport code: %s" % route['origin'].encode(config.ENCODING))
            if not re.match(airport_code, route['destination']):
                raise InvalidAirportCode(ndc_internal_error_text="Invalid arrival airport code: %s" % route['destination'].encode(config.ENCODING))
            marketing_airline_id = route.get('airline_id')
            marketing_airline_flight_number = route.get('flight_number')
            response_id = route.get('response_id')
            flight_found = marketing_airline_id is not None and marketing_airline_flight_number is not None
            has_flight_number.append(flight_found)
            route_item = Route(
                route['origin'],
                route['destination'],
                route['departure'].strftime('%Y-%m-%d'),
                marketing_airline_id=marketing_airline_id,
                marketing_airline_flight_number=marketing_airline_flight_number
            )
            routes.append(route_item)
            if response_id is not None:
                if found_response_id != response_id and found_response_id is not None:
                    raise InvalidFormatError()
                found_response_id = response_id
        if has_flight_number.count(has_flight_number[0]) != len(has_flight_number):
            raise InvalidFlightNumber()

        has_flights = any(has_flight_number)

        if has_flights and not found_response_id:
            raise InvalidFormatError()

        routes_from_response_id = []
        if has_flights and found_response_id:
            for r in found_response_id.split('_')[0].split('-'):
                routes_from_response_id.append(Route(
                    r.split('.')[0],
                    r.split('.')[2],
                    datetime.strptime(r.split('.')[1], '%Y%m%d').strftime('%Y-%m-%d'),
                ))

        routes_for_filter = None
        if len(routes_from_response_id) > 0:
            routes_for_filter = routes
            routes = routes_from_response_id

        return routes, routes_for_filter


class FlightPriceService(AflService):
    request_type = 'FlightPriceRQ'
    response_type = 'FlightPriceRS'
    response_cls = FlightPriceRS
    request_mapping_reader = CSVFileMappingReader(config.FLIGHT_PRICE_MAPPING_FILE, True)
    request_mapper_cls = HierarchicalXPathToJsonMapper

    def __init__(self):
        super(FlightPriceService, self).__init__()
        self._booking_class = defaultdict(list)
        self._flight_numbers = defaultdict(list)
        self._fare_group_names = defaultdict(list)
        self.link_segments = {}

    @staticmethod
    def _convert_lang(lang):
        langs = lang.split('-')
        return langs[0] if langs else lang

    def _calc_sum(self, attr, *dicts):
        return sum(d[attr] for d in chain(*dicts) if d[attr])

    def _get_data_departure(self, routes, segments, origin):
        departure = ''
        for rt in routes:
            if segments:
                if rt['segment_key'] in segments:
                    return rt['departure']
            else:
                if rt['origin'] == origin:
                    return rt['departure']
        return departure

    def _build_related_segments(self, routes, segments, origin):
        related_segments = []
        if segments:
            for route in routes:
                if not route['booking_class']:
                    raise NDCError

                if route['segment_key'] in segments:
                    related_segment = RelatedSegments(
                        airline_code=route['airline_code'],
                        booking_class=route['booking_class'],
                        flight_number=route['flight_number'],
                        departure=route['departure'].strftime('%Y-%m-%d'),
                        destination=route['destination'],
                        origin=route['origin'],
                        original_airline_code=route['airline_code'],
                        status=None,
                        inbound_connection=False,
                        fare_group_name=route['marketing_name']
                    )
                    related_segments.append(related_segment)
        return related_segments

    def _prepare_sb_search_rq(self, request_data):
        ndc_rq_cabin = request_data['cabin']
        if ndc_rq_cabin == NDCCabinTypes.FIRST_CLASS:
            sb_rq_cabin = SBCabinTypes.BUSINESS
        else:
            sb_rq_cabin = NDC2SBCabinTypeMap.map(ndc_rq_cabin)
        routes = []
        for route in request_data['destination_list']:
            if not re.match(airport_code, route['origin']):
                raise InvalidAirportCode(ndc_internal_error_text="Invalid departure airport code: %s" % route['origin'].encode(config.ENCODING))
            if not re.match(airport_code, route['destination']):
                raise InvalidAirportCode(ndc_internal_error_text="Invalid arrival airport code: %s" % route['destination'].encode(config.ENCODING))
            origin = route['origin']
            destination = route['destination']
            segments = route['segments'].split(' ')
            departure = self._get_data_departure(request_data['routes'], segments, origin)
            related_segments = self._build_related_segments(request_data['routes'], segments, origin)
            route_item = Route(
                origin,
                destination,
                departure.strftime('%Y-%m-%d'),
                related_segments=related_segments
            )
            routes.append(route_item)
        anon_travelers = request_data['anonym_travelers']
        recog_travelers = request_data['recognized_travelers']

        adults = self._calc_sum('adults', anon_travelers, recog_travelers)
        children = self._calc_sum('children', anon_travelers, recog_travelers)
        infants = self._calc_sum('infants', anon_travelers, recog_travelers)
        youth = self._calc_sum('youth', anon_travelers, recog_travelers)
        sb_request = RequestSearchParams(
            routes,
            sb_rq_cabin,
            adults,
            # award=request_data['award'],
            lang=self._convert_lang(request_data['lang']),
            country=request_data['country'],
            currency=request_data['currency'],
            children=children,
            infants=infants,
            youth=youth
        )

        return sb_request

    @staticmethod
    def _passenger_fare_bases(fares, passengers):
        result_tariff = defaultdict(list)
        passengers_ref = {passenger['travel_key']: passenger['pax_type'] for passenger in passengers}

        for fare in fares:
            pax_type = fare['pax_ref'][0]
            result_tariff[NDC2SBPassengerTypes.map(passengers_ref[pax_type])].append(fare['fare_base'])

        return [Tariff(pax_ref, fare_bases) for pax_ref, fare_bases in result_tariff.iteritems()]

    @staticmethod
    def _passenger_fare_bases_from_sb(ways, request_dict):
        flight_numbers = []
        fare_group_names = []
        booking_classes = []
        result_tariff = defaultdict(list)
        for route in request_dict['routes']:
            flight_numbers.append(route['flight_number'])
            if route.get('booking_class'):
                fare_group_names.append(route['marketing_name'].upper())
            booking_classes.append(route['booking_class'].upper())
        for way in ways:
            for way_info in way:
                all_flight_number_in_way = True
                for segment in way_info['segments']:
                    if all_flight_number_in_way:
                        all_flight_number_in_way = segment['flight_number'] in flight_numbers

                if all_flight_number_in_way:
                    for tariff in way_info['prices']:
                        for booking_class in tariff.get('booking_classes', []):
                            if fare_group_names:
                                if tariff.get('fare_group_name', '').upper() in fare_group_names:
                                    if booking_class in booking_classes:
                                        for pax_type, pax_prices in tariff['pax_prices'].iteritems():
                                            result_tariff[pax_type] += pax_prices['fare_bases']
                            else:
                                if booking_class in booking_classes:
                                    for pax_type, pax_prices in tariff['pax_prices'].iteritems():
                                        result_tariff[pax_type] += pax_prices['fare_bases']

        return [Tariff(pax_type, fare_bases) for pax_type, fare_bases in result_tariff.iteritems()]

    def _prepare_sb_price_rq(self, request_data, passenger_fare_bases):
        passenger_fare_bases = passenger_fare_bases or self._passenger_fare_bases(
            request_data['fares'], request_data['passengers'])
        anon_travelers = request_data['anonym_travelers']
        recog_travelers = request_data['recognized_travelers']
        country = request_data['country']
        lang = self._convert_lang(request_data['lang'])
        adults = self._calc_sum('adults', anon_travelers, recog_travelers)
        children = self._calc_sum('children', anon_travelers, recog_travelers)
        infants = self._calc_sum('infants', anon_travelers, recog_travelers)
        youth = self._calc_sum('youth', anon_travelers, recog_travelers)
        segments = self._get_segments(request_data['routes'])
        extra, referrer = self._get_extra_data(request_data)

        sb_request = PriceParameters(
            country=country,
            segments=segments,
            lang=lang,
            adults=adults,
            children=children,
            infants=infants,
            youth=youth,
            passenger_fare_bases=passenger_fare_bases,
            extra=extra,
            referrer=referrer
        )

        return sb_request

    def _get_segments(self, routes):
        segments = []
        for segment in routes:
            marriage_group = 'I' if segment.get('marriage_group') == "1" else ""
            segment_item = Flight(
                departure=segment['departure'].strftime('%Y-%m-%d'),
                destination=segment['destination'],
                origin=segment['origin'],
                booking_class=segment['booking_class'],
                flight_number=segment['flight_number'],
                airline_code=segment['airline_code'],
                marriage_group=marriage_group,
                brand=None
            )
            segments.append(segment_item)
        return segments

    def _get_extra_data(self, request_data):
        extra = None
        referrer = None
        disclosures_tais_dl = request_data.get('disclosures_tais_dl')
        disclosures_sigs_ssid = request_data.get('disclosures_sigs_ssid')
        if disclosures_tais_dl and disclosures_sigs_ssid and len(disclosures_sigs_ssid.strip()) > 0:
            extra = {'SIGSssid': disclosures_sigs_ssid.strip()}
            disclosures_price = request_data.get('disclosures_price')
            if disclosures_price and len(disclosures_price.strip()) > 0:
                extra['price'] = disclosures_price.strip()
            disclosures_rem5 = request_data.get('disclosures_rem5')
            if disclosures_rem5 and len(disclosures_rem5.strip()) > 0:
                extra['rem5'] = disclosures_rem5.strip()
            referrer = request_data.get('agency_id')
            if referrer:
                referrer = NDCAgentIdMappingReader(config.AGENT_ID_MAPPING_FILE).get_agent_code(referrer)
        return extra, referrer

    def _check_fare_basis_code(self, request_data):
        '''
        По тикету #125 необходимо проверить что заданы коды тарифов для каждой
        пары (тип пассажира, сегмент) в
        DataLists/FareList/FareGroup/FareBasisCode/Code

        :param request_data:
        :return:
        '''
        flight_segments = {
            (flight_segment['origin'], flight_segment['destination']): flight_segment['segment_key']
            for flight_segment in request_data['flight_segment_list']
        }
        flight_routes = []

        for flight_route in request_data['routes']:
            key_pax = flight_segments.get((flight_route['origin'], flight_route['destination']), None)
            if not key_pax:
                return False

            for passenger in request_data['passengers']:
                flight_routes.append([passenger['travel_key'], key_pax])

        for fare in request_data['fares']:
            try:
                i = flight_routes.index(fare['pax_ref'])
            except ValueError:
                return False

            flight_routes.pop(i)

        return False if flight_routes else True

    def _get_info_by_flight(self, request_data):
        for route in request_data['routes']:
            key = SEGMENTS_KEY_TMP.format(
                route['origin'],
                route['destination'],
                route['departure']
            )
            self._booking_class[key].append(route['booking_class'])
            self._flight_numbers[key].append(route['flight_number'])
            if route['marketing_name']:
                self._fare_group_names[key].append(route['marketing_name'].upper())

    @staticmethod
    def _find_price_key(value, filters, keys):
        return [key for key in keys if value in filters[key]]

    def _check_price(self, tariff, segments_keys, sb_search_rq):
        if sb_search_rq.routes[0].related_segments:
            for booking_class in tariff.get('booking_classes', []):
                if self._fare_group_names:
                    fare_group_name = tariff.get('fare_group_name', '').upper()
                    if self._find_price_key(fare_group_name, self._fare_group_names, segments_keys):
                        if self._find_price_key(booking_class, self._booking_class, segments_keys):
                            return True
                else:
                    if self._find_price_key(booking_class, self._booking_class, segments_keys):
                        return True
        else:
            return True

    def _get_segments_tariff(self, way, sb_search_rq):
        all_flight_number_in_way = True
        segments = None
        tariff = None
        for segment in way['segments']:
            key = SEGMENTS_KEY_TMP.format(
                segment['origin']['airport_code'],
                segment['destination']['airport_code'],
                parse_sb_datetime(segment['departure']).strftime('%Y-%m-%d'))
            if all_flight_number_in_way:
                all_flight_number_in_way = segment['flight_number'] in self._flight_numbers[key]

        if all_flight_number_in_way:
            segments = way['segments']
            segments_keys = [SEGMENTS_KEY_TMP.format(
                segment['origin']['airport_code'],
                segment['destination']['airport_code'],
                parse_sb_datetime(segment['departure']).strftime('%Y-%m-%d')) for segment in way['segments']]
            for price in way['prices']:
               if self._check_price(price, segments_keys, sb_search_rq):
                    tariff = price
                    break

        return segments, tariff

    def _get_way(self, sb_search_rq, sb_search_rs):
        ways = sb_search_rs['ways']
        if not ways:
            raise FlightNotFound()

        if len(ways) > 1 and len(sb_search_rq.routes) > 2:
            raise InvalidSegmentError()
        for way in ways:
            ways_cnt = 0
            for way_info in way:
                segments, tariff = self._get_segments_tariff(way_info, sb_search_rq)
                if segments and tariff:
                    ways_cnt += 1
                    yield segments, tariff
            if not ways_cnt:
                raise InvalidFareBasis()

    def _create_links_segments(self, request_dict):
        for destination in request_dict['destination_list']:
            segments_key = destination['segments'].split(' ')
            for route in request_dict['routes']:
                if route['segment_key'] in segments_key:
                    segment_key_destination = route['segment_key']
                    destination_segments = (route['origin'], route['destination'])
                    for flight_segment in request_dict['flight_segment_list']:
                        if (flight_segment['origin'], flight_segment['destination']) == destination_segments:
                            self.link_segments[segment_key_destination] = flight_segment['segment_key']

    def _generate_segments_from_sq(self, request_dict):
        response = []
        for destination in request_dict['destination_list']:
                segment_keys = destination['segments'].split(' ')

                booking_classes = []
                marketing_name = ''
                segments = []
                fare_bases = []
                for route in request_dict['routes']:
                    segment_key = route['segment_key']
                    if segment_key in segment_keys:
                        if not route.get('arrival'):
                            raise InvalidArrivalDate()

                        arrival_time = route['arrival_time'] or '00:00'
                        arrival = u'{0} {1}'.format(route['arrival'].strftime('%Y-%m-%d'), arrival_time)

                        departure_time = route['departure_time'] or '00:00'
                        departure = u'{0} {1}'.format(route['departure'].strftime('%Y-%m-%d'), departure_time)

                        segments.append({
                            'airline_code': route['airline_code'],
                            'arrival': arrival,
                            'departure': departure,
                            'flight_duration': route['flight_duration'],
                            'flight_number': route['flight_number'],
                            'marriage_group': route.get('marriage_group', 0),
                            'meal_names': [],
                            'operating_airline': route['operating_airline_code'],
                            'operating_airline_name': '',
                            'airline_name': '',
                            'operating_flight_number': route['operating_flight_number'],
                            'origin':  {'airport_code': route['origin']},
                            'destination': {'airport_code': route['destination']},
                            'airplane_code': route['aircraft_code'],
                            'airplane_name': route['aircraft_name']
                        })
                        booking_classes.append(route['booking_class'])

                        for fare in request_dict['fares']:
                            if self.link_segments.get(segment_key) in fare['pax_ref']:
                                fare_bases.append(fare['fare_base'])
                                activate(request_dict['lang'])
                                marketing_name = _("ndc.text.fares.{}.name".format(FareRulesMapping.get(None, fare['fare_base'][:3])['fare_rule_name'])).format(lang=request_dict['lang'])
                                break

                tariff = {
                    'booking_classes': booking_classes,
                    'fare_group_name': marketing_name,
                    'fare_group': None,
                    'brand': None,
                    'fare_bases': fare_bases
                }

                response.append((segments, tariff))
        return response

    def _prepare_response(self, sb_search_response, request_dict, search_data):
        response = []
        self._get_info_by_flight(request_dict)
        if not sb_search_response:
            return self._generate_segments_from_sq(request_dict)

        for segments, tariff in self._get_way(search_data, sb_search_response):
            tariff['fare_bases'] = tariff['pax_prices']['ADULT']['fare_bases']
            response.append((segments, tariff))

        return response

    def external_method(self, request_dict):
        if not request_dict.get("country"):
            raise InvalidCountryCode()
        sb_search_response = None
        search_data = None
        passenger_fare_bases = None
        self._fare_group_names = defaultdict(list)
        self._booking_class = defaultdict(list)
        self._flight_numbers = defaultdict(list)
        self._fare_group_names = defaultdict(list)
        self.link_segments = {}
        self._create_links_segments(request_dict)
        with SBService() as sb_client:
            if not (self._check_fare_basis_code(request_dict)):
                raise InvalidFareBasis()

            price_data = self._prepare_sb_price_rq(request_dict, passenger_fare_bases)
            sb_price_response = sb_client.price(price_data)
            response = self._prepare_response(sb_search_response, request_dict, search_data)
        return request_dict, response, sb_price_response

    def process_response(self, request_data, intermediate_data, response):
        ndc_rq_cabin = request_data['cabin']
        if ndc_rq_cabin not in NDCCabinTypes.cabin_types:
            raise InvalidServiceTypeCodeError()
        if ndc_rq_cabin == NDCCabinTypes.FIRST_CLASS:
            msg = 'Cabin code %s is not supported, replaced with %s' \
                  % (ndc_rq_cabin, NDCCabinTypes.BUSINESS)
            response.add_warning(SBFirstClassNotSupported(msg))
        return response


class OrderCreateService(AflService):
    request_type = 'OrderCreateRQ'
    response_type = 'OrderViewRS'
    response_cls = OrderViewRS
    request_mapping_reader = CSVFileMappingReader(config.ORDER_CREATE_MAPPING_FILE, True)
    request_mapper_cls = HierarchicalXPathToJsonMapper

    def external_method(self, request_dict):
        if not request_dict.get("country"):
            raise InvalidCountryCode()
        if request_dict['booking_ref'] is not None:
            raise AlreadyTcketed
        passenger_fare_bases = self._passenger_fare_bases(request_dict['segments'])
        segments = []
        for seg_dict in request_dict['segments'][0]['ways']:
            segments.append(self._get_flight(seg_dict))
        request_dict['lang'] = self._get_langs(request_dict['lang_info'])
        return self._book(request_dict, segments, passenger_fare_bases)

    def _book(self, request_dict, segments, passenger_fare_bases):
        with SBService() as sb_client:
            price_data = self._prepare_sb_price_rq(request_dict, segments, passenger_fare_bases)
            sb_price_response = sb_client.price(price_data)

            if self._check_price(request_dict, sb_price_response):
                remark = self._get_custom_remarks(request_dict, segments)
                book_data = self._prepare_sb_rq_book(request_dict, segments, passenger_fare_bases, remark)
                sb_book_response = sb_client.book(book_data)
                pnr_locator = sb_book_response.get('pnr_locator')
                lang = request_dict['lang'].get('Display')

                if config.USE_PMB_BOOKING_SERVICE:
                    pnr_response = self._book_with_pmb(request_dict, pnr_locator, lang)
                else:
                    pnr_key = sb_book_response.get('pnr_key')
                    pnr_response = sb_client.pnr(pnr_key=pnr_key, pnr_locator=pnr_locator, lang=lang)

                return book_data, pnr_response, sb_book_response, sb_price_response
            else:
                raise InvalidPriceTypeQualifierError

    def _book_with_pmb(self, request_dict, pnr_locator, lang):
        last_name = request_dict['passengers'][0]['last_name']
        last_name = format_pax_name(last_name)
        pnr_response = PMBService().booking_v1(pnr_locator, last_name, _preferredLanguage=lang, map_to_sb=True)

        return pnr_response

    def _prepare_sb_rq_book(self, request_data, segments, passenger_fare_bases, remark):
        phone, email = self._get_phone_email(request_data['passengers'])
        passengers = []
        for pax in request_data['passengers']:
            passengers.append(self._get_pax(pax))
        lang_dict = request_data['lang']
        email_lang = lang_dict.get('Written', lang_dict.get('Display'))

        sb_request_param = BookParams(
            email=email,
            email_lang=email_lang,
            phone=phone,
            country=request_data['country'],
            passengers=passengers,
            segments=segments,
            lang=lang_dict.get('Display'),

            currency=request_data['currency'],
            passenger_fare_bases=passenger_fare_bases,
            coupons=None,
            referrer=remark,
            points=None,
        )
        return sb_request_param

    def _get_phone_email(self, passengers):
        # TODO: ?????
        # Телефон, email берётся у первого взрослого
        phone = None
        email = None
        for pax_dict in passengers:
            if pax_dict['pax_type'] == NDCPassengerTypes.ADULT:
                contacts = pax_dict.get('contacts')
                for contact_data in contacts:
                    if phone is None:
                        phone = contact_data.get('phone')
                        if contact_data.get('country_code'):
                            phone = contact_data.get('country_code') + phone
                    email = contact_data.get('email') if email is None else email
                if phone and email:
                    return phone, email
                else:
                    phone = None
                    email = None
        return phone, email

    def _get_pax(self, pax_dict):
        sb_birth_date = pax_dict['birth_date'].strftime('%Y-%m-%d')
        if pax_dict['sex'] is None:
            raise GenderUndefined()
        sb_pax_type = NDC2SBPassengerTypes.map(pax_dict['pax_type'])
        sb_sex = NDC2SBGender.map(pax_dict['sex'])

        pax_docs = pax_dict.get('pax_doc')
        pax_doc = pax_docs[0]

        sb_doc_expiration = pax_doc['doc_expiration'].strftime('%Y-%m-%d')
        sb_doc_type = NDC2SBDocumentTypes.map(pax_doc['doc_type'])
        middle_name_suffix = pax_dict.get('middle_name_suffix')
        middle_name = '%s %s' % (pax_dict['middle_name'] or "", middle_name_suffix) if middle_name_suffix else pax_dict[
            'middle_name']
        passenger = Passenger(
            pax_type=sb_pax_type,
            first_name=pax_dict['first_name'],
            last_name=pax_dict['last_name'],
            patronymic=middle_name or "",
            birthdate=sb_birth_date,
            sex=sb_sex,
            nationality=pax_dict['nationality'],
            doc_type=sb_doc_type,
            doc_country=pax_doc['doc_country'],
            doc_expiration=sb_doc_expiration,
            doc_number=pax_doc['doc_number'],
            visa_country=pax_doc['visa_country']
        )
        return passenger

    def _get_langs(self, lang_info):
        langs = {}
        for info in lang_info:
            info_lang = info['lang']
            if info_lang.upper().strip() in [l.strip() for l in config.LANGUAGES] or info['app'] != 'Written':
                lang = info_lang
            else:
                lang = config.DEFAULT_LANGUAGE_CODE
            langs[info['app']] = lang
        return langs

    def _get_flight(self, seg_dict):
        marriage_group = 'I' if seg_dict.get('marriage_group') == "1" else ""
        flight = Flight(
            airline_code=seg_dict['airline_code'],
            flight_number=seg_dict['flight_number'],
            booking_class=seg_dict['booking_class'],
            departure=seg_dict['departure'].strftime('%Y-%m-%d'),
            destination=seg_dict['destination'],
            origin=seg_dict['origin'],
            marriage_group=marriage_group,
            brand=None
        )
        return flight

    def _passenger_fare_bases(self, segments):
        result = []
        for segment in segments:
            pax_ref = segment['pax_ref']
            pax = pax_ref.split(' ')[0]
            pax_type = pax.split('-')[1]
            fare_base = []
            fares = {f['seg_ref']: f['fare_base'] for f in segment['fares']}
            for way in segment['ways']:
                fare = fares.get(way['seg_key'])
                if fare:
                    fare_base.append(fare)
            result.append(Tariff(NDC2SBPassengerTypes.map(pax_type), fare_base))
        return result

    def _get_price_by_pax_types(self, prices):
        result = {}
        for price in prices:
            pax_ref = price['pax_ref']
            pax = pax_ref.split(' ')[0]
            pax_type = pax.split('-')[1]
            sb_pax_type = NDC2SBPassengerTypes.map(pax_type)
            result[sb_pax_type] = {'base_amount': price['base_amount'],
                                   'taxes_total': price['taxes_total']}
        return result

    def _prepare_sb_price_rq(self, request_data, segments, passenger_fare_bases):
        country = request_data['country']
        lang = request_data['lang'].get('Display')
        currency = request_data['currency']

        pax_count = {}
        for pax in request_data['passengers']:
            if pax_count.get(pax['pax_type']):
                pax_count[pax['pax_type']] += 1
            else:
                pax_count[pax['pax_type']] = 1

        adults = pax_count.get(NDCPassengerTypes.ADULT, 0)
        children = pax_count.get(NDCPassengerTypes.CHILD, 0)
        infants = pax_count.get(NDCPassengerTypes.INFANT, 0)
        youth = pax_count.get(NDCPassengerTypes.YOUTH, 0)

        sb_request = PriceParameters(
            country=country, segments=segments, lang=lang,
            currency=currency, adults=adults, children=children,
            infants=infants, youth=youth, passenger_fare_bases=passenger_fare_bases)

        return sb_request

    def _check_price(self, request_dict, sb_price_response):
        if not request_dict['simple_currency_price']:
            return False
        return Decimal(request_dict['simple_currency_price']) == Decimal(sb_price_response['total'])

    def _get_custom_remarks(self, request_data, segments):
        agent_code = NDCAgentIdMappingReader(config.AGENT_ID_MAPPING_FILE).get_agent_code(request_data['agency_id'])
        if not agent_code:
            agent_code = config.DEFAULT_AGENT_ID

        user_agent_string = cherrypy.request.headers.get('User-Agent', '')
        app_type = NDCUserAgentMappingReader(config.USER_AGENT_MAPPING_FILE).get_app_type(user_agent_string)

        fare_base = config.OTHER_FARE_BASE
        segments_count = len(segments)
        for fb in config.FARE_BASE_BOOKING_CLASSES:
            bc = config.FARE_BASE_BOOKING_CLASSES[fb]
            res = [fb for s in segments if s.booking_class in bc]
            if len(res) == segments_count:
                fare_base = fb
                break
        remark = agent_code + app_type + fare_base + config.NDC_REMARK
        return remark
