# -*- coding: utf-8 -*-

import cherrypy
import subprocess
from lxml.builder import E
import random

import config
from auth import authorize
from exc import UnsupportedFunctionError, NDCError, InvalidFormatError
from services.afl import afl_service_factory
from services.xml import XMLService
from utils.xml import parse_xml, get_tag_name, get_xml_schema, validate_xml
from utils.xml import strip_ns_prefix, NDC_ROOT_E
from log import RequestLogger, log
from mapping.mapping import NDCAgentIdMappingReader



def get_svn_revision():
    try:
        return subprocess.check_output(["svnversion", config.APPDIR])
    except:
        return '?'


class NDCService(XMLService):
    """Сервис NDC"""

    _content_type = 'application/x-iata.ndc.v1+xml'

    services = {}

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('ndc_service', '/services', controller=self, action='index', conditions={'method': ['POST']})
        dispatcher.connect('ndc_service', '/services/v{version}', controller=self, action='index',
                           conditions={'method': ['POST']})

    def __init__(self):
        super(NDCService, self).__init__()
        self.svn_version = get_svn_revision()
        for service in config.SUPPORTED_SERVICES:
            service_class = afl_service_factory(service)
            self.services[service_class.request_type] = service_class

    @property
    def response_type(self):
        return cherrypy.request.service.response_type if hasattr(cherrypy.request, 'service') else 'RESPONSE'

    @property
    def version(self):
        return getattr(cherrypy.request, 'version', config.DEFAULT_NDC_VERSION)

    @authorize
    @cherrypy.tools.gzip()
    def index(self, **params):
        cherrypy.request.tracking_id = random.random()
        body = cherrypy.request.body.read()
        xml = parse_xml(body)
        stripped_xml = strip_ns_prefix(xml)
        agency_id = stripped_xml.xpath('//Party/Sender/TravelAgencySender/AgencyID/text()')
        if agency_id:
            cherrypy.request.agency_id = NDCAgentIdMappingReader(config.AGENT_ID_MAPPING_FILE).get_agent_code(agency_id[0])
        cherrypy.request.logger = RequestLogger(log.service_logger, request_log=log.service_logger.info,
                                                response_log=log.service_logger.info, action=None, version=None)
        apic_transaction_id = cherrypy.request.headers.get('X-Global-Transaction-ID')
        try:
            xml = parse_xml(body)
            request_type = get_tag_name(xml.tag)
            cherrypy.request.logger.kwargs['action'] = request_type

            if request_type not in self.services:
                raise UnsupportedFunctionError(description=request_type)
        except NDCError:
            cherrypy.request.logger.log_request(body, cherrypy.request.method, cherrypy.url(),
                                                apic_transaction_id=apic_transaction_id)
            raise

        version = xml.get('Version')
        if version:
            if version != config.SERVICES_VERSION_NDC_VERSION.get(params.get('version', '1.0'), '16.2'):
                raise InvalidFormatError('Wrong version of services used in request')
            cherrypy.request.version = version
            cherrypy.request.logger.kwargs['version'] = xml.get('Version')

        cherrypy.request.logger.log_request(body, cherrypy.request.method, cherrypy.url(),
                                            apic_transaction_id=apic_transaction_id)
        cherrypy.request.service = self.services[request_type]()

        if config.ENABLE_XSD_VALIDATION:
            schema = get_xml_schema(request_type, self.version)
            validate_xml(schema, xml)

        cherrypy.request.request_xml_body = body
        xml_tree = cherrypy.request.service.process_request(stripped_xml)
        response = self.render(xml_tree)
        if cherrypy.request.service.should_log_response:
            cherrypy.request.logger.log_response(response, success='true')
        return response

    def renderErrors(self, errors):
        error_node = super(NDCService, self).renderErrors(errors)
        if self.response_type in config.EMPTY_DOC_IN_RESPONSE:
            doc_node = E('Document')
            response_node = NDC_ROOT_E(
                self.response_type, doc_node, error_node,
                Version=self.version, schema_name='%s.xsd' % self.response_type
            )
        else:
            response_node = NDC_ROOT_E(
                self.response_type, error_node,
                Version=self.version, schema_name='%s.xsd' % self.response_type
            )
        return response_node

    def render(self, content, **kwargs):
        cherrypy.response.headers['X_AFL_NDC_Version'] = self.svn_version
        return super(NDCService, self).render(content, **kwargs)
