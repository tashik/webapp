# coding=utf-8


from abc import ABCMeta, abstractmethod

from utils.xml import E, NDC_ROOT_E


class BaseResponse(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def get_tree(self):
        raise NotImplementedError()


class XMLResponse(BaseResponse):
    pass


class NDCResponseStatus(object):
    NOTSET = None
    PENDING = 'pending'
    SUCCESS = 'success'
    ERROR = 'error'
    WARNINGS = 'warnings'


class NDCResponse(XMLResponse):
    container = NotImplemented
    version = NotImplemented
    status = NDCResponseStatus.NOTSET

    def __init__(self):
        super(NDCResponse, self).__init__()
        self.warnings = []

    @abstractmethod
    def build_tree(self):
        raise NotImplementedError()

    def add_warning(self, ndc_warning):
        self.warnings.append(ndc_warning)

    def get_tree(self):
        payload_elems = self.build_tree()
        warn_node = self.get_warnings_node()
        if warn_node is not None:
            payload_elems = [warn_node] + payload_elems

        root = NDC_ROOT_E(
            self.container, E('Document'), E('Success'),
            *payload_elems, Version=self.version,
            schema_name='%s.xsd' % self.container
        )
        self.status = NDCResponseStatus.SUCCESS
        return root

    def get_warnings_node(self):
        warnings_node = None
        if self.warnings:
            warnings_node = E('Warnings')
            for warn in self.warnings:
                warn_node = E('Warning', warn.description, Type=warn.code)
                warnings_node.append(warn_node)

        return warnings_node
