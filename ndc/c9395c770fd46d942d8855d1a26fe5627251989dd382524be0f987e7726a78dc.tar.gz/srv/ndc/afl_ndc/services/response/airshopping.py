# coding=utf-8

from datetime import datetime
from decimal import Decimal
from itertools import izip_longest, izip

from collections import defaultdict

from exc import InvalidSegmentError
from mapping.enums import SBPassengerTypes, FareRulesMeasurements, NDCPassengerTypes
from mapping.fare_rules import FareRulesMapping
from mapping.utils import parse_sb_datetime, parse_sb_date
from mapping.utils import format_ndc_time, format_ndc_timedelta, format_ndc_date
from services.constants import CARRY_ON_ALLOWANCE_KEY_TMP, CHECKED_BAG_KEY_TMP, PRICE_CLASS_KEY_TMP, \
    FARE_GROUP_LIST_KEY_TMP, FLIGHT_SEGMENT_KEY_TMP, SERVICE_ID_TMP, SERVICE_KEY_TMP
from services.response import NDCResponse, FlightNotFound
from utils.xml import E
from i18n import _

from config import AIRSHOPPING_AIRLINE_WHITELIST, AIRSHOPPING_AIRLINE_BLACKLIST, SB_APP_URL

AIR_SHOPPING_DEEP_LINK_TEMPLATE = '%s/{country}-{lang}#/passengers?adults={adults}&children={children}&infants={infants}&segments={segments}&referrer={referrer}' % SB_APP_URL


class AirShoppingRS(NDCResponse):
    version = '16.2'

    def __init__(self, rq_data_search_rs):
        super(AirShoppingRS, self).__init__()
        self.sb_search_rq = rq_data_search_rs[0]
        self.sb_search_rs = rq_data_search_rs[1]
        self.is_interline = None
        self._offer_price_cnt = 1
        self._seg_id_cnt = 1
        self._airline_offer_cnt = 1
        self._anonymous_traveler_cnt = 1
        self._fare_groups = []
        self.carry_on_all_list = {}
        self.checked_bag_allowance_list = {}
        self.price_class_list = []
        self.fare_list = []
        self.service_list = []
        self.flight_segment_list = []
        self.price_class_list_brand = []
        self.fare_groups_keys = []
        self.fare_group_refs = []

    def build_tree(self):
        response_id = self._create_response_id()
        response_ids_node = E('ShoppingResponseID', E('ResponseID', response_id))
        nodes = self._build_nodes()
        meta = self._get_metadata()
        return [response_ids_node] + nodes + [meta]

    def _create_response_id(self):
        now = datetime.now().isoformat()
        routes_parts = []
        for route in self.sb_search_rq.routes:
            routes_parts.append(
                '{}.{}.{}'.format(route.origin, datetime.strptime(route.departure, '%Y-%m-%d').strftime('%Y%m%d'),
                                  route.destination))
        return '{}_{}'.format('-'.join(routes_parts), now)

    def _get_way_items(self):
        self.is_interline = self.sb_search_rs['interline']
        ways = self.sb_search_rs['ways']
        if ways:
            if len(ways) > 1:
                raise InvalidSegmentError()
            else:
                way_items = ways[0]
                if AIRSHOPPING_AIRLINE_WHITELIST or AIRSHOPPING_AIRLINE_BLACKLIST:
                    if AIRSHOPPING_AIRLINE_WHITELIST:
                        check_way_item = lambda way_item: \
                            way_item['segments'] \
                            and all(
                                seg['airline_code'] in AIRSHOPPING_AIRLINE_WHITELIST
                                for seg in way_item['segments'])
                    elif AIRSHOPPING_AIRLINE_BLACKLIST:
                        check_way_item = lambda way_item: \
                            not any(
                                seg['airline_code'] in AIRSHOPPING_AIRLINE_BLACKLIST
                                for seg in way_item['segments'])
                    way_items = [w for w in way_items if check_way_item(w)]
                return way_items
        else:
            return []

    def _build_nodes(self):
        way_items = self._get_way_items()
        if not way_items:
            self.add_warning(FlightNotFound('Flights not found'))
            return []

        lang = self.sb_search_rq.lang

        travelers = self._get_anon_travelers()
        traveler_nodes = [node for (key, node) in travelers.itervalues()]
        traveler_key_by_type = {pt: key for pt, (key, node) in travelers.iteritems()}

        flights = []
        segments = []
        airline_offers = []
        classes_by_brands = {}
        for way in way_items:
            segments_info = []
            way_segments = way['segments']
            for i, segment in enumerate(way_segments):
                segment_key = self._get_segment_key(segment)
                segments.append(self._build_flight_segment(segment, segment_key))
                segments_info.append((segment_key, segment['marriage_group']))
            for tariff in way['prices']:
                airline_offers.append(
                    self._build_airline_offer(tariff, traveler_key_by_type, segments_info, way_segments, lang))
                brand = tariff['brand']
                if not self.is_interline and brand not in classes_by_brands:
                    price_class = E(
                        'PriceClass',
                        E('Name', brand),
                        E('Descriptions',
                          E('Description', E('Text', _('ndc.text.airshopping.info.luggage.%(text)s') % {'text': tariff['luggage']})),
                          E('Description', E('Text', _('ndc.text.airshopping.info.exchange.%(text)s') % {'text': tariff['exchange']})),
                          E('Description', E('Text', _('ndc.text.airshopping.info.refund.%(text)s') % {'text': tariff['refund']})),
                          E('Description', E('Text', _('ndc.text.airshopping.info.miles_upgrade.%(text)s') % {'text': tariff['miles_upgrade']})),
                          ),
                        ObjectKey=brand,
                    )
                    classes_by_brands[brand] = price_class
            arrival_str = way_segments[-1]['arrival']
            arrival_offset = - way_segments[-1]['arrival_offset']
            departure_str = way_segments[0]['departure']
            departure_offset = - way_segments[0]['departure_offset']
            arrival = parse_sb_datetime(arrival_str, minutes_offset=arrival_offset)
            departure = parse_sb_datetime(departure_str, minutes_offset=departure_offset)
            route_time = format_ndc_timedelta(arrival - departure)
            segment_refs = ' '.join(seg_id for seg_id, o in segments_info)
            flights.append(
                E('Flight',
                  E('Journey', E('Time', route_time)),
                  E('SegmentReferences', segment_refs),
                  )
            )

        calendars = []
        for min_price_info in self.sb_search_rs.get('days', []):
            for date_s, min_price in sorted(min_price_info.iteritems()):
                calendar_item = E(
                    'PriceCalendar',
                    E('PriceCalendarDate', format_ndc_date(parse_sb_date(date_s))),
                    E('TotalPrice', min_price['amount'], Code=min_price['currency'])
                )
                calendars.append(calendar_item)
        offers_group_node = E(
            'OffersGroup',
            E('AirlineOffers',
              E('TotalOfferQuantity', len(airline_offers)),
              E('Owner', 'SU'),
              *(airline_offers + calendars)
              )
        )

        other_data_nodes = []
        if not self.is_interline:
            price_class_node = E(
                'PriceClassList',
                # PriceClass@ObjectKey=  ['prices'][0..N]['brand']
                *classes_by_brands.values())
            other_data_nodes.append(price_class_node)
        data_lists = [E('AnonymousTravelerList', *traveler_nodes)]
        if self.sb_search_rq.routes_for_filter:
            data_lists.extend([E('CarryOnAllowanceList', *self._build_carry_on_allowance()),
                               E('CheckedBagAllowanceList', *self._build_checked_bags()),
                               E('DisclosureList', *self._make_disclosures_list(lang)),
                               E('FareList', *self.fare_list)
                               ])

        data_lists.extend([E('FlightSegmentList', *segments), E('FlightList', *flights)])

        data_lists.extend(other_data_nodes)

        data_lists_node = E(
            'DataLists',
            *data_lists
        )

        return [offers_group_node, data_lists_node]

    def _make_disclosures_list(self, lang):
        disclosures = []
        for fare_group in set(self._fare_groups):
            descriptions = []
            fare_rule = FareRulesMapping.get(fare_group.replace('TG_', ''), None, lang=lang)
            additional_info = fare_rule.get('additional-info')
            if additional_info:
                for info in additional_info:
                    description = [E('Text', info.get('text').format(lang=lang))]
                    if info.get('link'):
                        description.append(E('Link', info.get('link').format(lang=lang)))
                    descriptions.append(E('Description', *description))
            disclosures.append(E('Disclosures', ListKey=fare_group, *descriptions))

        return disclosures

    def _build_airline_offer(self, tariff, anon_traveler_key_by_type, segments_info, segments, lang):
        segment_refs = []

        for book_class, (seg_id, marriage_gr), fare_group_name in izip_longest(
            tariff['booking_classes'],
            segments_info,
            tariff.get('fare_group_name_per_segment', ()),
            fillvalue=tariff['fare_group_name'],
        ):
            bag_detail_association = None
            if self.sb_search_rq.routes_for_filter:
                fare_base = tariff['fare_bases'][0][:3] if tariff.get('fare_bases') else None
                fare_group = tariff.get('fare_group') or None
                fare_rule = FareRulesMapping.get(fare_group, fare_base, lang=lang)
                segment_keys, service_keys, fare_bases_segments = self._generate_by_segments(segments,
                                                                                             tariff['pax_prices'][
                                                                                                 'ADULT']['fare_bases'],
                                                                                             lang)

                fare_bases_generates, checked_bag_keys, carry_on_all_keys = self._generate_by_fare_bases(
                    tariff['pax_prices']['ADULT']['fare_bases'],
                    fare_rule, anon_traveler_key_by_type, fare_bases_segments, tariff)

                checked_bag_references = E('CheckedBagReferences', ' '.join(checked_bag_keys)) if checked_bag_keys else None
                carry_on_references = E('CarryOnReferences', ' '.join(carry_on_all_keys)) if carry_on_all_keys else None
                bag_detail_association = E(
                    'BagDetailAssociation',
                    checked_bag_references,
                    carry_on_references
                )

            segment_ref = E(
                'FlightSegmentReference',
                E('ClassOfService',
                    E('Code', book_class),
                    E('MarketingName', fare_group_name),
                ),
                bag_detail_association,
                E('MarriedSegmentGroup', '1' if marriage_gr == 'I' else '0'),
                ref=seg_id
            )

            segment_refs.append(segment_ref)

        applicable_flight = E('ApplicableFlight', *segment_refs)
        priced_offer_nodes = self._make_offer_prices(
            tariff, anon_traveler_key_by_type, segments_info)
        other_associations = []
        if not self.is_interline:
            price_class_node = E(
                'PriceClass', E('PriceClassReference', tariff['brand']))
            other_associations.append(price_class_node)
        priced_offer_nodes.append(
            E('Associations', applicable_flight, *other_associations)
        )
        node = E(
            'AirlineOffer',
            E('OfferID', 'OFFER%s' % self._airline_offer_cnt, Owner='SU'),
            E('TotalPrice',
              E('SimpleCurrencyPrice', tariff['total'], Code=tariff['currency'])
              ),
            E('Disclosure', *self._make_disclosure(segments, tariff)),
            E('PricedOffer', *priced_offer_nodes)
        )
        self._airline_offer_cnt += 1
        return node

    def _make_disclosure(self, segments, tariff):
        disclosure_list = [E('Description', E('Link', self._make_offer_deep_link(segments, tariff)))]
        if self.sb_search_rq.routes_for_filter:
            self._seg_id_cnt = 1
            for segment in segments:
                seg_num = 0
                fare_group = tariff['fare_group']
                if fare_group:
                    self._add_fare_group(fare_group, disclosure_list, segment, None)
                else:
                    for fare_base in tariff['pax_prices']['ADULT']['fare_bases']:
                        fare_group = FareRulesMapping.get(None, fare_base[0:3])['fare_rule_name']
                        self._add_fare_group(fare_group, disclosure_list, segment, self._seg_id_cnt)
                    self._seg_id_cnt += 1

        return disclosure_list

    def _add_fare_group(self, fare_group_name, disclosure_list, segment, segment_num):
        fare_group_name = 'TG_' + fare_group_name
        ref = self._get_segment_key(segment, segment_num) + " " + fare_group_name
        if ref not in self.fare_group_refs:
            self._fare_groups.append(fare_group_name)
            self.fare_group_refs.append(ref)
            disclosure_list.append(E('Description', refs=ref))

    def _make_offer_deep_link(self, segments, tariff):
        adults = self.sb_search_rq.adults if self.sb_search_rq.adults else 0
        children = self.sb_search_rq.children if self.sb_search_rq.children else 0
        infants = self.sb_search_rq.infants if self.sb_search_rq.infants else 0

        country = self.sb_search_rq.country.lower()
        language = self.sb_search_rq.lang.lower()
        referrer = self.sb_search_rq.partner_name
        parts = []

        for segment, booking_class, fare_base in izip(segments, tariff['booking_classes'],
                                                      tariff['pax_prices']['ADULT']['fare_bases']):
            origin_code = segment['origin']['airport_code']
            origin_date = datetime.strptime(segment['departure'], '%Y-%m-%d %H:%M').strftime('%Y%m%d')
            destination_code = segment['destination']['airport_code']
            airline = segment['airline_code']
            flight_number = segment['flight_number']
            part = '{}{}{}.{}{}.{}.{}.{}'.format(origin_code, origin_date, destination_code, airline, flight_number,
                                                 booking_class, fare_base,
                                                 'I' if segment['marriage_group'] == 'I' else 'N')

            if segment['marriage_group'] == 'I':
                parts = parts[:-1]
                parts.append('_')

            parts.append(part)
            parts.append('-')

        if len(parts) > 1:
            parts = parts[:-1]

        return AIR_SHOPPING_DEEP_LINK_TEMPLATE.format(country=country, lang=language, adults=adults, children=children,
                                                      infants=infants, segments=''.join(parts), referrer=referrer)

    def _make_offer_prices(self, tariff, anon_traveler_key_by_type, segments_info):
        offer_prices = []
        for passenger_code, pax_price in tariff['pax_prices'].iteritems():
            taxes_total = sum(Decimal(tax['amount']) for tax in pax_price['taxes'])
            requested_date = E(
                'RequestedDate',
                E('PriceDetail',
                  E('TotalAmount',
                    E('SimpleCurrencyPrice', pax_price['total']),
                    ),
                  E('BaseAmount', pax_price['base']),
                  E('Taxes', E('Total', taxes_total, Code=pax_price['currency'])),
                  ),
                E('Associations',
                  E('AssociatedTraveler',
                    E('TravelerReferences', anon_traveler_key_by_type[passenger_code]),
                    ),
                  ),
            )
            fare_components = []
            for fare_base, (seg_id, o) in zip(pax_price['fare_bases'], segments_info):
                ref = filter(lambda x: seg_id in x and fare_base in x, self.fare_groups_keys)
                if len(ref) > 0:
                    fare_component = E(
                        'FareComponent',
                        E('SegmentReference', seg_id),
                        E('FareBasis', E('FareBasisCode', E('Code', fare_base))),
                        refs=ref[0]
                    )
                else:
                    fare_component = E(
                        'FareComponent',
                        E('SegmentReference', seg_id),
                        E('FareBasis', E('FareBasisCode', E('Code', fare_base))),
                    )
                fare_components.append(fare_component)
            offer_price = E(
                'OfferPrice',
                requested_date,
                E('FareDetail', *fare_components),
                OfferItemID=self._offer_price_cnt)
            self._offer_price_cnt += 1
            offer_prices.append(offer_price)
        return offer_prices

    def _build_flight_segment(self, segment, segment_key):
        departure_text = segment['departure']
        departure_offset = - segment['departure_offset']
        arrival_text = segment['arrival']
        arrival_offset = - segment['arrival_offset']
        departure = self._decode_airport(
            'Departure', segment['origin'], departure_text)
        arrival = self._decode_airport(
            'Arrival', segment['destination'], arrival_text)

        arrival_dt = parse_sb_datetime(arrival_text, minutes_offset=arrival_offset)
        departure_dt = parse_sb_datetime(departure_text, minutes_offset=departure_offset)

        duration_delta = format_ndc_timedelta(arrival_dt - departure_dt)

        segment_node = E(
            'FlightSegment',
            departure, arrival,
            E('MarketingCarrier',
                E('AirlineID', segment['airline_code']),
                E('Name', segment['airline_name']),
                E('FlightNumber', segment['flight_number'])),
            E('OperatingCarrier',
                E('AirlineID', segment['operating_airline']),
                E('Name', segment['operating_airline_name']),
                E('FlightNumber', segment['operating_flight_number'])),
            E('Equipment',
                E('AircraftCode', segment['airplane_code']),
                E('Name', segment['airplane_name'])),
            # TODO E('ClassOfService', ...),
            E('FlightDetail', E('FlightDuration', E('Value', duration_delta))),
            SegmentKey=segment_key)
        return segment_node

    def _get_anon_travelers(self):
        anon_travelers = {}
        if self.sb_search_rq.adults:
            anon_travelers[SBPassengerTypes.ADULT] = \
                self._make_anon_traveler('ADT', self.sb_search_rq.adults)
        if self.sb_search_rq.children:
            anon_travelers[SBPassengerTypes.CHILD] = \
                self._make_anon_traveler('CHD', self.sb_search_rq.children)
        if self.sb_search_rq.infants:
            anon_travelers[SBPassengerTypes.INFANT] = \
                self._make_anon_traveler('INF', self.sb_search_rq.infants)
        return anon_travelers

    def _make_anon_traveler(self, code, quantity):
        object_key = 'SH%s' % self._anonymous_traveler_cnt
        e = E(
            'AnonymousTraveler',
            E('PTC', code, Quantity=quantity),
            ObjectKey=object_key)
        self._anonymous_traveler_cnt += 1
        return object_key, e

    def _decode_airport(self, container, airport, dt):
        airport_code = E('AirportCode', airport['airport_code'])
        airport_name = E('AirportName', airport['airport_name'])
        dt_val = parse_sb_datetime(dt)
        d = E('Date', format_ndc_date(dt_val.date()))
        t = E('Time', format_ndc_time(dt_val.time()))
        return E(container, airport_code, d, t, airport_name)

    def _get_segment_key(self, segment, segment_num = None):
        seg_id = 'SEG_%s%s_%s' % (
            segment['origin']['airport_code'],
            segment['destination']['airport_code'],
            self._seg_id_cnt if not segment_num else segment_num)
        if segment_num is None:
            self._seg_id_cnt += 1
        return seg_id

    def _get_metadata(self):
        lang_meta = E(
            'LanguageMetadata',
            E('Application', 'Display'),
            E('Code_ISO', self.sb_search_rq.lang),
            MetadataKey='Display')
        other_metadata = E(
            'Other',
            E('OtherMetadata',
              E('LanguageMetadatas', lang_meta))
        )
        metadata = E('Metadata', other_metadata)
        return metadata

    def _build_piece_allowance(self, fare_rules_info, applicable_party, total_quantity, fare_type=None):
        if not fare_rules_info:
            return None

        bag_type = E('BagType', _('ndc.text.fares.info.bag_type.briefcase_laptop').format(
            lang=self.sb_search_rq.lang)) if fare_type else None
        lang = self.sb_search_rq.lang
        piece_dimension_allowance = E(
            'PieceDimensionAllowance',
            E('ApplicableParty', applicable_party),
            E('DimensionUOM', FareRulesMeasurements.map(fare_rules_info['height'][1]).format(lang=lang)),
            E('Dimensions', E('Category', 'Length'), E('MaxValue', str(fare_rules_info['length'][0]))),
            E('Dimensions', E('Category', 'Width'), E('MaxValue', str(fare_rules_info['width'][0]))),
            E('Dimensions', E('Category', 'Height'), E('MaxValue', str(fare_rules_info['height'][0])))
        )
        piece_measurements = E(
            'PieceMeasurements',
            E('PieceWeightAllowance',
              E('MaximumWeight',
                E('Value', str(fare_rules_info['weight'][0])),
                E('UOM', FareRulesMeasurements.map(fare_rules_info['weight'][1]).format(lang=lang)))
              ),
            piece_dimension_allowance,
            Quantity='1')

        return E('PieceAllowance',
                 E('ApplicableParty', applicable_party),
                 total_quantity, bag_type,
                 piece_measurements,
                 PieceAllowanceCombination="AND")

    def _build_allowance_description(self, applicable_party, luggage_text, luggage_descr):
        return E('AllowanceDescription',
                 E('ApplicableParty', applicable_party),
                 E('ApplicableBag', luggage_text),
                 E('Descriptions', E('Description', E('Text', luggage_descr.format(lang=self.sb_search_rq.lang)))))

    def _add_build_carry_on_allowance(self, traveler_key, fare_rule, applicable_party):
        if not fare_rule or not fare_rule['carryon'][traveler_key]:
            return None

        carry_on_allowance = {
            'carry_on': fare_rule['carryon'][traveler_key],
            'applicable_party': applicable_party,
            'type': fare_rule['carryon']['type']}
        carry_on_allowance_key = None
        for key, item in self.carry_on_all_list.iteritems():
            if item == carry_on_allowance:
                carry_on_allowance_key = key
                break
        if not carry_on_allowance_key:
            carry_on_allowance_key = CARRY_ON_ALLOWANCE_KEY_TMP.format(len(self.carry_on_all_list) + 1)
            self.carry_on_all_list[carry_on_allowance_key] = carry_on_allowance

        return carry_on_allowance_key

    def _add_build_checked_bag(self, traveler_key, fare_rule, applicable_party):
        if not fare_rule:
            return None
        checked_bag = {
            'luggage': fare_rule['luggage'][traveler_key],
            'applicable_party': applicable_party,
            'luggage_text': fare_rule['luggage_text'][traveler_key].format(lang=self.sb_search_rq.lang),
            'luggage_descr': fare_rule['luggage']['description'].format(lang=self.sb_search_rq.lang)
        }
        checked_bag_key = None
        for key, item in self.checked_bag_allowance_list.iteritems():
            if item == checked_bag:
                checked_bag_key = key
                break

        if not checked_bag_key:
            checked_bag_key = CHECKED_BAG_KEY_TMP.format(len(self.checked_bag_allowance_list) + 1)
            self.checked_bag_allowance_list[checked_bag_key] = checked_bag

        return checked_bag_key

    def _build_checked_bags(self):
        result = []
        for list_key, item in self.checked_bag_allowance_list.iteritems():
            piece_allowances = []
            allowance_descriptions = []
            luggage_text = item['luggage_text']
            applicable_party = item['applicable_party']
            luggage = item['luggage']
            luggage_descr = item['luggage_descr']

            total_quantity = E('TotalQuantity', luggage['count'])
            piece_allowances.append(self._build_piece_allowance(luggage, applicable_party, total_quantity))
            allowance_descriptions.append(
                self._build_allowance_description(applicable_party, luggage_text, luggage_descr))

            result.append(E('CheckedBagAllowance',
                            *allowance_descriptions + piece_allowances,
                            ListKey=list_key))
        return result

    def _build_carry_on_allowance(self):
        result = []
        for list_key, item in self.carry_on_all_list.iteritems():
            total_quantity = E('TotalQuantity', item['carry_on']['count'])
            result.append(
                E('CarryOnAllowance',
                  self._build_piece_allowance(item['carry_on'], item['applicable_party'], total_quantity, item['type']),
                  ListKey=list_key)
            )

        return result

    def _generate_by_fare_bases(self, fare_bases, fare_rule, traveler_key_by_type, fare_bases_segments, tariff):
        fare_bases_generates = []
        checked_bag_keys = set()
        carry_on_all_keys = set()
        for index, fare_base in enumerate(fare_bases):
            if fare_base in fare_bases_generates:
                continue
            fare_bases_generates.append(fare_base)

            if not fare_rule:
                fare_rule = FareRulesMapping.get(None, fare_base[0:3])

            self._get_prive_class(fare_rule, tariff['brand'])

            fare_group = self._build_fare_group(fare_base, fare_bases_segments[fare_base], tariff, fare_rule)
            if fare_group:
                self.fare_list.append(fare_group)

            if SBPassengerTypes.INFANT in traveler_key_by_type:
                carry_on_all_key = self._add_build_carry_on_allowance(NDCPassengerTypes.INFANT, fare_rule, traveler_key_by_type.get(SBPassengerTypes.INFANT))
                if carry_on_all_key:
                    carry_on_all_keys.add(carry_on_all_keys)
                checked_bag_keys.add(self._add_build_checked_bag(NDCPassengerTypes.INFANT, fare_rule, traveler_key_by_type.get(SBPassengerTypes.INFANT)))
                applicable_party = ' '.join(
                    [_key for _type, _key in traveler_key_by_type.iteritems() if _type != SBPassengerTypes.INFANT])
            else:
                applicable_party = 'Party'

            if fare_rule:
                checked_bag_keys.add(self._add_build_checked_bag(NDCPassengerTypes.ADULT, fare_rule, applicable_party))
                carry_on_all_keys.add(self._add_build_carry_on_allowance(NDCPassengerTypes.ADULT, fare_rule, applicable_party))

        return fare_bases_generates, checked_bag_keys, carry_on_all_keys

    def _build_fare_group(self, fare_base, segment_keys, tariff, fare_rule):
        link = fare_rule.get('fare_base_rules_url', '') if fare_rule else ''
        fare_details = self._build_fare_component(tariff, ' '.join(segment_keys), fare_rule)

        fare = E(
            'Fare',
            E('FareCode',
              E('Code', tariff['booking_classes'][0]),
              E('Link', link)),
            E('FareDetail', fare_details, E('PriceClassReference', tariff['brand']))
        )

        list_key = FARE_GROUP_LIST_KEY_TMP.format(''.join(segment_keys) + '_' + fare_base)
        if list_key not in self.fare_groups_keys:
            self.fare_groups_keys.append(list_key)
            return E(
                'FareGroup',
                fare,
                E('FareBasisCode',
                  E('Code', fare_base)),
                refs=' '.join(segment_keys),
                ListKey=list_key
            )
        else:
            return None

    def _build_fare_component(self, tariff, segment_keys, fare_rule):
        details = []
        lang = 'en'
        refund_value = fare_rule['refund_text'].format(lang=lang) if fare_rule.get('refund_text').format(
            lang=lang) else None
        if refund_value:
            details.append(self._build_detail_fare('Refund', refund_value))

        exchange_value = fare_rule['exchange_text'].format(lang=lang) if fare_rule.get('exchange_text') else None
        if exchange_value:
            details.append(self._build_detail_fare('Exchange', exchange_value))

        return E(
            'FareComponent',
            E(
                'FareRules',
                E('Penalty', E('Details', *details))
            ),
            refs=segment_keys
        )

    @staticmethod
    def _build_detail_fare(fare_type, value):
        return E(
            'Detail', E('Type', fare_type),
            E(
                'Amounts',
                E(
                    'Amount',
                    E('CurrencyAmountValue', 0),
                    E('ApplicableFeeRemarks', E('Remark', value))
                )
            )
        )

    def _generate_by_segments(self, segments, adult_fare_bases, lang='ru'):
        segment_keys = []
        service_keys = []
        self.flight_segment_list = []
        fare_bases_segments = defaultdict(list)
        for index, segment in enumerate(segments):
            segment_key = FLIGHT_SEGMENT_KEY_TMP.format(
                segment['origin']['airport_code'],
                segment['destination']['airport_code'],
                len(self.flight_segment_list) + 1
            )
            self.flight_segment_list.append(self._build_flight_segment(segment, segment_key))
            service, service_key = self._build_service(segment, segment_key)

            self.service_list.append(service)
            service_keys.append(service_key)
            segment_keys.append(segment_key)
            fare_bases_segments[adult_fare_bases[index]].append(segment_key)
        return segment_keys, service_keys, fare_bases_segments

    def _build_service(self, segment, segment_key):
        object_key = SERVICE_ID_TMP.format('MEAL', segment['flight_number'])
        service_id = E('ServiceID', object_key, Owner=segment['airline_code'])
        descr_services = []
        for meal_name in segment['meal_names']:
            descr_services.append(E('Description', E('Text', meal_name)))
        if not descr_services:
            descr_services = [E('Description')]

        service_key = SERVICE_KEY_TMP.format(len(self.service_list) + 1)
        return E('Service',
                 service_id,
                 E('Name', _('ndc.text.service.name.meal').format(lang=self.sb_search_rq.lang)),
                 E('Descriptions', *descr_services),
                 E('Associations',
                   E('Flight', E('SegmentReferences', segment_key))),
                 ObjectKey=service_key), service_key

    def _get_prive_class(self, fare_rule, brand):
        if fare_rule or brand:
            brand = brand or list(fare_rule['brands'])[0]
            if brand not in self.price_class_list_brand:
                self.price_class_list_brand.append(brand)
                self.price_class_list.append(self._build_price_class(brand, fare_rule))

    def _build_price_class(self, name, fare_rule):
        if fare_rule:
            name = name or fare_rule['brand']
            return E('PriceClass',
                     E('Name', name),
                     E('Descriptions',
                       E('Description', E('Media', E('MediaLink', fare_rule['upsale_url'])))),
                     ObjectKey=PRICE_CLASS_KEY_TMP.format(len(self.price_class_list)+1))
        else:
            return None

