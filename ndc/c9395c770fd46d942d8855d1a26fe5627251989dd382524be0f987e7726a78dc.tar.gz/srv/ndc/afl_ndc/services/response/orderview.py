# coding=utf-8
from decimal import Decimal

from mapping.enums import SB2NDCGender, NDCDocumentTypes, SB2NDCPassengerTypes
from mapping.utils import format_ndc_time
from mapping.utils import parse_sb_datetime, format_ndc_date, parse_ndc_date
from services.response import NDCResponse
from utils import format_pax_name
from utils.xml import E

import config


class OrderViewRS(NDCResponse):
    version = '16.2'
    ORDER_VIEW_LINK_TEMPLATE = "{}/info/pnr/load?pnr_locator={{}}&last_name={{}}&submit_load=true".format(config.PMB_URL)

    def __init__(self, rq_data_book_rs):
        super(OrderViewRS, self).__init__()
        self.sb_book_rq = rq_data_book_rs[0]
        self.sb_pnr_rs = rq_data_book_rs[1]
        self.sb_book_response = rq_data_book_rs[2]
        self.sb_price_rs = rq_data_book_rs[3]
        self.pax_types = {}

    def build_tree(self):
        root = E('Response', *self._build_nodes())
        return [root]

    def _build_nodes(self):
        passengers_nodes, pax_count_dict = self._get_passengers()
        passengers = E('Passengers', *passengers_nodes)

        flight_nodes = []
        order_item_id = 1
        for pax_type in pax_count_dict:
            self._build_flight_node(pax_count_dict, pax_type, order_item_id, flight_nodes)
            order_item_id += 1

        base_amount, taxes_total = self._get_price_total()
        amount_total = base_amount + taxes_total
        order_id = self.sb_pnr_rs['pnr_locator'].zfill(config.PNR_LEN_FOR_ORDER_ID)
        order_id = '%s%s%s' % (config.AIRLINE_CODE, config.ACCOUNTING_CODE, order_id)
        node_order = self._build_node_order(order_id, amount_total, taxes_total, flight_nodes)
        meta = self._get_metadata()
        data = [passengers, node_order]
        self._build_data_lists(data)
        data.append(meta)

        return data

    def _build_data_lists(self, data):
        if self.sb_pnr_rs['pnr_locator']:
            last_name = format_pax_name(self.sb_pnr_rs['passengers'][0]['last_name'])
            link = self.ORDER_VIEW_LINK_TEMPLATE.format(self.sb_pnr_rs['pnr_locator'], last_name)
            data_lists = E('DataLists', E('DisclosureList',
                                          E('Disclosures', E('Description', E('Link', link)), ListKey='PNR_DL')))
            data.append(data_lists)

    def _build_node_order(self, order_id, amount_total, taxes_total, flight_nodes):
        return E(
            'Order',
            E('OrderID', order_id, Owner=config.AIRLINE_CODE),
            E('BookingReferences', E(
                'BookingReference',
                E(
                    'Type',
                    E('Code', '703'),
                    E('Definition', 'PNR_date_{}'.format(self.sb_pnr_rs['date'])),
                ),
                E('ID', self.sb_pnr_rs['pnr_locator']),
                E('OtherID', 'Should be specified', Name='mdorder'),
            )),
            E('TotalOrderPrice', self._get_detail_price(amount_total, taxes_total)),
            E('Payments', self._get_payment(amount_total)),
            E('OrderItems', *flight_nodes),
        )

    def _build_flight_node(self, pax_count_dict, pax_type, order_item_id, flight_nodes):
        pax_ref = ''
        for num in xrange(pax_count_dict[pax_type]):
            pax_ref += ' Traveler-%s-%s' % (pax_type, num + 1)
        pax_ref = pax_ref.strip()

        flight_node = E('OrderItem',
                        E('OrderItemID', order_item_id, Owner=config.AIRLINE_CODE),
                        E('FlightItem', *self._get_segments()),
                        E('Associations',
                          E('Passengers',
                            E('PassengerReferences', pax_ref))))
        flight_nodes.append(flight_node)

    def _get_passengers(self):
        pax_nodes = []
        pax_count_dict = {}
        for pax in self.sb_pnr_rs['passengers']:

            pax_type = self._get_pax_type_from_rq(pax)
            if pax_type:
                pax_type = SB2NDCPassengerTypes.map(pax_type)
                next_num = pax_count_dict.get(pax_type)
                next_num = next_num + 1 if next_num else 1
                pax_count_dict[pax_type] = next_num

            doc_node = self._get_pax_doc(pax)
            node = E('Passenger',
                     E('PTC', pax_type, Quantity="1"),
                     E('Age',
                       E('BirthDate', parse_ndc_date(pax['birthdate']).strftime('%Y-%m-%d'))),
                     E('Name',
                       E('Surname', pax['last_name']),
                       E('Given', pax['first_name'])),
                     E('Contacts',
                       E('Contact',
                         E('EmailContact',
                           E('Address', pax['email'])))),
                     E('Gender', SB2NDCGender.map(pax['sex'])),
                     E('PassengerIDInfo', doc_node),
                     ObjectKey="Traveler-%s-%s" % (pax_type, pax_count_dict.get(pax_type)))
            pax_nodes.append(node)
        return pax_nodes, pax_count_dict

    def _get_pax_doc(self, pax):
        pax_doc = pax['document']
        doc_node = E('PassengerDocument',
                       E('Type', NDCDocumentTypes.PASSPORT),
                       E('ID', pax_doc['doc_number']),
                       E('DateOfExpiration', parse_ndc_date(pax_doc['doc_expiration']).strftime('%Y-%m-%d')),
                       E('CountryOfIssuance', pax_doc['nationality']))
        return doc_node

    def _get_segments(self):
        result = []
        for group in self.sb_pnr_rs['segment_groups']:
            for segment in group['segments']:
                destination = segment['destination']
                origin = segment['origin']
                departure_dt_val = parse_sb_datetime(segment['departure'])
                arrival_dt_val = parse_sb_datetime(segment['arrival'])

                seg_node = E('OriginDestination',
                                E('Flight',
                                    E('Departure',
                                        E('AirportCode', destination['airport_code']),
                                        E('Date', format_ndc_date(departure_dt_val.date())),
                                        E('Time', format_ndc_time(departure_dt_val.time())),
                                        E('Terminal',
                                            E('Name', destination['terminal_name']))),
                                    E('Arrival',
                                        E('AirportCode', origin['airport_code']),
                                        E('Date', format_ndc_date(arrival_dt_val.date())),
                                        E('Time', format_ndc_time(arrival_dt_val.time()))),
                                    E('MarketingCarrier',
                                        E('AirlineID', segment['airline_code']),
                                        E('FlightNumber', segment['flight_number'])),
                                    E('Equipment',
                                        E('AircraftCode', segment['airplane_code'])),
                                    E('ClassOfService',
                                        E('Code', segment['booking_class_code']))))
                result.append(seg_node)
        return result

    def _get_payment(self, amount_total):
        # TODO: убрать заглушку
        node = E('Payment',
                    E('Associations'),
                    E('Status',
                        E('StatusCode',
                            E('Code', 'FALSE'),
                            E('Link', self.sb_book_response['payment_url']))),
                        E('Amount',
                            E('SimpleCurrencyPrice', str(amount_total), Code=self._get_currency())),
                        E('Method',
                            E('PaymentCardMethod',
                                E('CardType', 'CRD'),
                                E('CardCode', 'VI'))))
        return node

    def _get_detail_price(self, amount_total, taxes_total):
        return E('DetailCurrencyPrice',
                    E('Total', str(amount_total), Code=self._get_currency()),
                    E('Taxes',
                        E('Total', str(taxes_total), Code=self._get_currency())))

    def _get_metadata(self):
        lang_meta = E(
            'LanguageMetadata',
            E('Application', 'Display'),
            E('Code_ISO', self.sb_book_rq.lang),
            MetadataKey='Display')
        other_metadata = E(
            'Other',
            E('OtherMetadata',
              E('LanguageMetadatas', lang_meta))
        )
        metadata = E('Metadata', other_metadata)
        return metadata

    def _get_pax_type_from_rq(self, pax_dict):
        # Бред! Достаём тип пассажира, сравнивая данные из запроса, так как sb его не возварщает.
        for pax in self.sb_book_rq.passengers:
            first_name = pax_dict['first_name'].split(' ')[0]
            pax_last_name = format_pax_name(pax.last_name)
            pax_first_name = format_pax_name(pax.first_name, ' ').split(' ')[0]
            if pax_first_name.upper() == first_name and pax_last_name.upper() == pax_dict['last_name'] and \
                    pax.birthdate == pax_dict['birthdate'] and pax.sex == pax_dict['sex']:
                return pax.pax_type
        return None

    def _get_currency(self):
        return self.sb_price_rs['currency']

    def _get_price_total(self):
        base_amount = 0
        taxes_total = 0
        for sb_pax_type in self.sb_price_rs['pax_prices']:
            sb_prices = self.sb_price_rs['pax_prices'][sb_pax_type]
            taxes = sb_prices['taxes']
            tt = 0
            for t in taxes:
                tt += Decimal(t['amount'])
            ba = Decimal(sb_prices['base']) * sb_prices['count']
            tt = tt * sb_prices['count']
            taxes_total += tt
            base_amount += ba
        return base_amount, taxes_total
