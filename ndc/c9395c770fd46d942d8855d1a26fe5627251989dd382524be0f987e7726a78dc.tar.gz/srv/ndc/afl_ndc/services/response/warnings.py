# coding=utf-8


class BaseNDCWarning(object):
    code = NotImplemented
    descripiton = ''

    def __init__(self, description):
        super(BaseNDCWarning, self).__init__()
        self.description = description


class SBFirstClassNotSupported(BaseNDCWarning):
    code = '101'
    description = 'First class cabin type is not supported'


class FlightNotFound(BaseNDCWarning):
    code = '102'
    description = 'Flights not found'
