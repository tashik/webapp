# coding=utf-8

from collections import defaultdict
from datetime import datetime, timedelta
from decimal import Decimal

import cherrypy

from i18n import activate, _

from mapping.enums import (SBPassengerTypes, NDCPassengerTypes,
                           FareRulesMeasurements)
from mapping.fare_rules import FareRulesMapping
from mapping.mapping import NDCAirlineIdMappingReader
from mapping.utils import (parse_sb_datetime, format_ndc_timedelta,
                           from_ndc_to_timedelta)
from services.constants import (SERVICE_ID_TMP, SERVICE_KEY_TMP,
                                PRICE_CLASS_KEY_TMP, FARE_GROUP_LIST_KEY_TMP,
                                FLIGHT_KEY_TMP, ORIGIN_DESTINATION_KEY_TMP,
                                CARRY_ON_ALLOWANCE_KEY_TMP, CHECKED_BAG_KEY_TMP,
                                FLIGHT_SEGMENT_KEY_TMP)
from services.response import NDCResponse
from services.response.airshopping import E

import config
from log import log


class FlightPriceRS(NDCResponse):
    version = '16.2'

    def __init__(self, rq_data_search_rs, ):
        super(FlightPriceRS, self).__init__()
        self.sb_search_rq = rq_data_search_rs[0]
        self.sb_search_rs = rq_data_search_rs[1]
        self.sb_price_rs = rq_data_search_rs[2]
        self.flight_segment_list = []
        self.origin_destination_list = []
        self.price_class_list = []
        self.service_list = []
        self.fare_list = []
        self.flight_list = []
        self.associations_list = []
        self.price_class_list_brand = []
        self.disclosures_list = {}
        self.disclosures = []
        self.carry_on_all_list = {}
        self.checked_bag_allowance_list = {}
        self._anonymous_traveler_cnt = 1
        self._anonymous_traveler_cnt_by_key = {}

    def _make_anon_traveler(self, code, quantity):
        object_key = 'SH%s' % self._anonymous_traveler_cnt
        e = E(
            'AnonymousTraveler',
            E('PTC', code, Quantity=quantity),
            ObjectKey=object_key)
        self._anonymous_traveler_cnt += 1
        self._anonymous_traveler_cnt_by_key[object_key] = quantity
        return object_key, e

    def _get_anon_travelers(self):
        anon_travelers = {}
        for traveler in self.sb_search_rq['anonym_travelers']:
            if traveler['adults']:
                anon_travelers[SBPassengerTypes.ADULT] = self._make_anon_traveler('ADT', traveler['adults'])
            if traveler['children']:
                anon_travelers[SBPassengerTypes.CHILD] = self._make_anon_traveler('CHD', traveler['children'])
            if traveler['infants']:
                anon_travelers[SBPassengerTypes.INFANT] = self._make_anon_traveler('INF', traveler['infants'])
        return anon_travelers

    def _build_taxes(self, taxes_total, currency, taxes, count):
        taxs = [E('Total', taxes_total, Code=currency)]
        breakdown = []
        for tax in taxes:
            breakdown.append(
                E('Tax',
                  E('Amount', Decimal(tax['amount']) * count, Code=currency),
                  E('TaxCode', tax['tax_code']),
                  E('Description', tax['tax_name'])))
        if breakdown:
            taxs.append(E('Breakdown', *breakdown))
        return E('Taxes', *taxs)

    def _build_price_detail(self, pax_price, count):
        total_amount = E('TotalAmount',
                         E('SimpleCurrencyPrice',
                           Decimal(pax_price['total']) * count,
                           Code=pax_price['currency']))
        base_amount = E('BaseAmount', Decimal(pax_price['base']) * count,
                        Code=pax_price['currency'])
        taxes_total = sum(Decimal(tax['amount']) * count for tax in pax_price['taxes'])
        taxes = self._build_taxes(taxes_total, pax_price['currency'], pax_price['taxes'], count)
        return E('PriceDetail', total_amount, base_amount, taxes)

    def _build_offer_price(self, offer_price_cnt, pax_price, passenger_code, traveler_key_by_type):
        requested_date = []
        count = 1
        if config.RETURN_PRICES_PER_TYPEGROUP:
            count = self._anonymous_traveler_cnt_by_key[traveler_key_by_type[passenger_code]]
        requested_date.append(self._build_price_detail(pax_price, count))
        requested_date.append(self._build_requested_associations(
            passenger_code, traveler_key_by_type))
        return E('OfferPrice',
                 E('RequestedDate',
                   *requested_date),
                 OfferItemID=offer_price_cnt)

    def _build_offer_prices(self, pax_prices, traveler_key_by_type):
        offer_price_cnt = 1
        offer_prices = []
        for pax_type, pax_price in pax_prices.iteritems():
            offer_prices.append(self._build_offer_price(offer_price_cnt, pax_price, pax_type, traveler_key_by_type))
            offer_price_cnt += 1
        return offer_prices

    def _build_priced_flight_offers(self, pax_prices, traveler_key_by_type):
        priced_flight_offers_cnt = 1
        offer_prices = self._build_offer_prices(pax_prices, traveler_key_by_type)
        offer_prices.append(self._build_time_limits())

        return [E('OfferID', priced_flight_offers_cnt, Owner='SU')] + offer_prices

    @staticmethod
    def _get_datetime_flight_segment(segment):
        departure_offset = -segment.get('departure_offset', 0)
        arrival_offset = -segment.get('arrival_offset', 0)
        arrival_date = datetime.strptime(segment['arrival'], '%Y-%m-%d %H:%M')
        departure_date = datetime.strptime(segment['departure'], '%Y-%m-%d %H:%M')

        if not (departure_offset or arrival_offset) and segment.get('flight_duration'):
            duration_delta = segment['flight_duration']
        else:
            departure_date_with_offset = departure_date + timedelta(minutes=departure_offset)
            arrival_date_with_offset = arrival_date + timedelta(minutes=arrival_offset)
            duration_delta = format_ndc_timedelta(arrival_date_with_offset - departure_date_with_offset)

        return duration_delta, arrival_date, departure_date

    def _build_flight_segment(self, segment, segment_key, lang):

        duration_delta, arrival_date, departure_date = self._get_datetime_flight_segment(segment)
        departure = E('Departure',
                      E('AirportCode', segment['origin']['airport_code']),
                      E('Date', departure_date.strftime('%Y-%m-%d')),
                      E('Time', departure_date.strftime('%H:%M')))

        arrival = E('Arrival',
                    E('AirportCode', segment['destination']['airport_code']),
                    E('Date', arrival_date.strftime('%Y-%m-%d')),
                    E('Time', arrival_date.strftime('%H:%M')))

        airline_code = segment['airline_code']
        marketing_carrier_airline_name = segment['airline_name']
        if marketing_carrier_airline_name is None or len(marketing_carrier_airline_name) == 0:
            marketing_carrier_airline_name = NDCAirlineIdMappingReader(config.AIRLINE_ID_MAPPING_FILE).get_airline_name(
                airline_code, lang)

        marketing_carrier = E('MarketingCarrier',
                              E('AirlineID', airline_code),
                              E('Name', marketing_carrier_airline_name),
                              E('FlightNumber', segment['flight_number']))

        operating_carrier_airline_code = segment['operating_airline']
        operating_carrier_airline_name = segment['operating_airline_name']
        if (operating_carrier_airline_name is None or len(operating_carrier_airline_name) == 0) and \
                operating_carrier_airline_code is not None and len(operating_carrier_airline_code) > 0:
            operating_carrier_airline_name = NDCAirlineIdMappingReader(config.AIRLINE_ID_MAPPING_FILE).get_airline_name(
                operating_carrier_airline_code, lang)
        operating_carrier = None
        if segment['operating_flight_number'] and operating_carrier_airline_code:
            operating_carrier = E('OperatingCarrier',
                              E('AirlineID', operating_carrier_airline_code),
                              E('Name', operating_carrier_airline_name),
                              E('FlightNumber', segment['operating_flight_number']))
        equipment = None
        if segment['airplane_code']:
            equipment = E('Equipment',
                          E('AircraftCode', segment['airplane_code']),
                          E('Name', segment.get('airplane_name')))

        flight_duration = E('FlightDetail', E('FlightDuration', E('Value', duration_delta)))

        return E('FlightSegment',
                 departure,
                 arrival,
                 marketing_carrier, operating_carrier, equipment, flight_duration,
                 SegmentKey=segment_key)

    def _build_service(self, segment, segment_key):
        object_key = SERVICE_ID_TMP.format('MEAL', segment['flight_number'])
        service_id = E('ServiceID', object_key, Owner=segment['airline_code'])
        descr_services = []
        for meal_name in segment['meal_names']:
            descr_services.append(E('Description', E('Text', meal_name)))
        if not descr_services:
            descr_services = [E('Description')]

        service_key = SERVICE_KEY_TMP.format(len(self.service_list) + 1)
        return E('Service',
                 service_id,
                 E('Name', _('ndc.text.service.name.meal').format(lang=self.sb_search_rq['lang'])),
                 E('Descriptions', *descr_services),
                 E('Associations',
                   E('Flight', E('SegmentReferences', segment_key))),
                 ObjectKey=service_key), service_key

    def _build_price_class(self, name, fare_rule):
        if fare_rule:
            name = name or fare_rule['brand']
            return E('PriceClass',
                     E('Name', name),
                     E('Descriptions',
                       E('Description', E('Media', E('MediaLink', fare_rule['upsale_url'])))),
                     ObjectKey=PRICE_CLASS_KEY_TMP.format(len(self.price_class_list)+1))
        else:
            return None

    def _build_origin_destination(self, segments, flight_references_key):
        departure_code = segments[0]['origin']['airport_code']
        arrival_code = segments[-1]['destination']['airport_code']

        return E(
            'OriginDestination',
            E('DepartureCode', departure_code),
            E('ArrivalCode', arrival_code),
            E('FlightReferences', flight_references_key),
            OriginDestinationKey="OD{0}".format(len(self.origin_destination_list) + 1))

    @staticmethod
    def _build_detail_fare(fare_type, value):
        return E(
            'Detail', E('Type', fare_type),
            E(
                'Amounts',
                E(
                    'Amount',
                    E('CurrencyAmountValue', 0),
                    E('ApplicableFeeRemarks', E('Remark', value))
                )
            )
        )

    def _build_fare_component(self, tariff, segment_keys, fare_rule):
        details = []
        lang = 'en'
        refund_value = fare_rule['refund_text'].format(lang=lang) if fare_rule.get('refund_text').format(lang=lang) else None
        if refund_value:
            details.append(self._build_detail_fare('Refund', refund_value))

        exchange_value = fare_rule['exchange_text'].format(lang=lang) if fare_rule.get('exchange_text') else None
        if exchange_value:
            details.append(self._build_detail_fare('Exchange', exchange_value))

        return E(
            'FareComponent',
            E(
                'FareRules',
                E('Penalty', E('Details', *details))
            ),
            refs=segment_keys
        )

    def _build_fare_group(self, fare_base, segment_keys, tariff, fare_rule):
        link = fare_rule.get('fare_base_rules_url', '') if fare_rule else ''
        fare_details = self._build_fare_component(tariff, ' '.join(segment_keys), fare_rule)

        fare = E(
            'Fare',
            E('FareCode',
              E('Code', tariff['booking_classes'][0]),
              E('Link', link)),
            E('FareDetail', fare_details, E('PriceClassReference', PRICE_CLASS_KEY_TMP.format(len(self.price_class_list))))
        )

        return E(
            'FareGroup',
            fare,
            E('FareBasisCode',
              E('Code', fare_base)),
            refs=' '.join(segment_keys),
            ListKey=FARE_GROUP_LIST_KEY_TMP.format(''.join(segment_keys))
        )

    @staticmethod
    def _get_duration_delta(segments):
        flight_durations = []
        for segment in segments:
            flight_duration = segment.get('flight_duration')
            if flight_duration:
                arrival_offset = -segment.get('arrival_offset', 0)
                departure_offset = -segment.get('departure_offset', 0)
                arrival = parse_sb_datetime(segment['arrival'], arrival_offset)
                departure = parse_sb_datetime(segment['departure'], departure_offset)
                flight_duration_timedelta = from_ndc_to_timedelta(flight_duration)
                flight_durations.append(arrival - departure - flight_duration_timedelta)

        departure = parse_sb_datetime(segments[0]['departure'], -segments[0].get('departure_offset', 0))
        arrival = parse_sb_datetime(segments[-1]['arrival'], -segments[-1].get('arrival_offset', 0))

        flight_duration =  arrival - departure
        for fd in flight_durations:
            flight_duration -= fd
        return format_ndc_timedelta(flight_duration)

    @staticmethod
    def _build_applicable_flight(segment_keys, tariff, carry_on_all_keys, checked_bag_keys):
        flight_segment_references = []
        for index, segment_key in enumerate(segment_keys):
            class_of_service = tariff['booking_classes'][index]
            fare_group_name = tariff['fare_group_name']
            checked_bag_references = E('CheckedBagReferences', ' '.join(checked_bag_keys)) if checked_bag_keys else None
            carry_on_references = E('CarryOnReferences', ' '.join(carry_on_all_keys)) if carry_on_all_keys else None
            bag_detail_association = E(
                'BagDetailAssociation',
                checked_bag_references,
                carry_on_references
            )

            flight_segment_reference = E(
                'FlightSegmentReference',
                E('ClassOfService',
                  E('Code', class_of_service),
                  E('MarketingName', fare_group_name)),
                bag_detail_association,
                ref=segment_key)
            flight_segment_references.append(flight_segment_reference)
        return flight_segment_references

    @staticmethod
    def _build_requested_associations(passenger_code, traveler_key_by_type):
        associated_travelers = [
            E('AssociatedTraveler',
              E('TravelerReferences',
                traveler_key_by_type[passenger_code])
              )
        ]
        return E('Associations', *associated_travelers)

    def _build_association(self, service_keys, segment_keys, tariff, carry_on_all_keys, checked_bag_keys, flight_references_key):
        flight_segment_references = self._build_applicable_flight(segment_keys, tariff, carry_on_all_keys, checked_bag_keys)
        flight_segment_references.append(E('OriginDestinationReferences', ORIGIN_DESTINATION_KEY_TMP.format(len(self.origin_destination_list))))
        flight_segment_references.append(E('FlightReferences', flight_references_key))
        return E(
            'Associations',
            E('ApplicableFlight', *flight_segment_references),
            E('PriceClass',
              E('PriceClassReference', PRICE_CLASS_KEY_TMP.format(len(self.price_class_list)))
              ),
            E('IncludedService', E('ServiceReferences', ' '.join(service_keys)))
        )

    def _build_flight(self, segments, segment_keys):
        self.flight_cnt += 1
        flight_key = FLIGHT_KEY_TMP.format(self.flight_cnt)
        duration_delta = self._get_duration_delta(segments)
        flight = E('Flight', E('Journey', E('Time', duration_delta)),
                   E('SegmentReferences', ' '.join(segment_keys)),
                   FlightKey=flight_key)
        return flight_key, flight

    def _build_piece_allowance(self, fare_rules_info, applicable_party, total_quantity, fare_type=None):
        if not fare_rules_info:
            return None

        bag_type = E('BagType', _('ndc.text.fares.info.bag_type.briefcase_laptop').format(lang=self.sb_search_rq['lang'])) if fare_type else None
        lang = self.sb_search_rq['lang']
        piece_dimension_allowance = E(
            'PieceDimensionAllowance',
            E('ApplicableParty', applicable_party),
            E('DimensionUOM', FareRulesMeasurements.map(fare_rules_info['height'][1]).format(lang=lang)),
            E('Dimensions', E('Category', 'Length'), E('MaxValue', str(fare_rules_info['length'][0]))),
            E('Dimensions', E('Category', 'Width'), E('MaxValue', str(fare_rules_info['width'][0]))),
            E('Dimensions', E('Category', 'Height'), E('MaxValue', str(fare_rules_info['height'][0])))
        )
        piece_measurements = E(
            'PieceMeasurements',
            E('PieceWeightAllowance',
              E('MaximumWeight',
                E('Value', str(fare_rules_info['weight'][0])),
                E('UOM', FareRulesMeasurements.map(fare_rules_info['weight'][1]).format(lang=lang)))
              ),
            piece_dimension_allowance,
            Quantity='1')

        return E('PieceAllowance',
                 E('ApplicableParty', applicable_party),
                 total_quantity, bag_type,
                 piece_measurements,
                 PieceAllowanceCombination="AND")

    def _build_allowance_description(self, applicable_party, luggage_text, luggage_descr):
        return E('AllowanceDescription',
                 E('ApplicableParty', applicable_party),
                 E('ApplicableBag', luggage_text),
                 E('Descriptions', E('Description', E('Text', luggage_descr.format(lang=self.sb_search_rq['lang'])))))

    def _add_build_carry_on_allowance(self, traveler_key, fare_rule, applicable_party):
        if not fare_rule['carryon'][traveler_key]:
            return None

        carry_on_allowance = {
            'carry_on': fare_rule['carryon'][traveler_key],
            'applicable_party': applicable_party,
            'type': fare_rule['carryon']['type']}
        carry_on_allowance_key = None
        for key, item in self.carry_on_all_list.iteritems():
            if item == carry_on_allowance:
                carry_on_allowance_key = key
                break
        if not carry_on_allowance_key:
            carry_on_allowance_key = CARRY_ON_ALLOWANCE_KEY_TMP.format(len(self.carry_on_all_list) + 1)
            self.carry_on_all_list[carry_on_allowance_key] = carry_on_allowance

        return carry_on_allowance_key

    def _add_build_checked_bag(self, traveler_key, fare_rule, applicable_party):
        checked_bag = {
            'luggage': fare_rule['luggage'][traveler_key],
            'applicable_party': applicable_party,
            'luggage_text': fare_rule['luggage_text'][traveler_key].format(lang=self.sb_search_rq['lang']),
            'luggage_descr': fare_rule['luggage']['description'].format(lang=self.sb_search_rq['lang'])
        }
        checked_bag_key = None
        for key, item in self.checked_bag_allowance_list.iteritems():
            if item == checked_bag:
                checked_bag_key = key
                break

        if not checked_bag_key:
            checked_bag_key = CHECKED_BAG_KEY_TMP.format(len(self.checked_bag_allowance_list) + 1)
            self.checked_bag_allowance_list[checked_bag_key] = checked_bag

        return checked_bag_key

    def _build_checked_bags(self):
        result = []
        for list_key, item in self.checked_bag_allowance_list.iteritems():
            piece_allowances = []
            allowance_descriptions = []
            luggage_text = item['luggage_text']
            applicable_party = item['applicable_party']
            luggage = item['luggage']
            luggage_descr = item['luggage_descr']

            total_quantity = E('TotalQuantity', luggage['count'])
            piece_allowances.append(self._build_piece_allowance(luggage, applicable_party, total_quantity))
            allowance_descriptions.append(self._build_allowance_description(applicable_party, luggage_text, luggage_descr))

            result.append(E('CheckedBagAllowance',
                          *allowance_descriptions + piece_allowances,
                          ListKey=list_key))
        return result

    def _build_carry_on_allowance(self):
        result = []
        for list_key, item in self.carry_on_all_list.iteritems():
            total_quantity = E('TotalQuantity', item['carry_on']['count'])
            result.append(
                E('CarryOnAllowance',
                  self._build_piece_allowance(item['carry_on'], item['applicable_party'], total_quantity, item['type']),
                  ListKey=list_key)
            )

        return result

    def _build_data_lists(self, traveler_nodes):

        return E('DataLists',
                 E('AnonymousTravelerList', *traveler_nodes),
                 E('CarryOnAllowanceList', *self._build_carry_on_allowance()),
                 E('CheckedBagAllowanceList', *self._build_checked_bags()),
                 E('DisclosureList', *self._build_disclosures_list()),
                 E('FareList', *self.fare_list),
                 E('FlightSegmentList', *self.flight_segment_list),
                 E('FlightList', *self.flight_list),
                 E('OriginDestinationList', *self.origin_destination_list),
                 E('PriceClassList', *self.price_class_list),
                 E('ServiceList', *self.service_list),
                 )

    def _build_meta_data(self):
        return E('Metadata')

    @staticmethod
    def _build_time_limits():
        return E('TimeLimits', E('OfferExpiration'))

    def _generate_by_segments(self, segments, adult_fare_bases, lang='ru'):
        segment_keys = []
        service_keys = []
        fare_bases_segments = defaultdict(list)
        for index, segment in enumerate(segments):
            segment_key = FLIGHT_SEGMENT_KEY_TMP.format(
                segment['origin']['airport_code'],
                segment['destination']['airport_code'],
                len(self.flight_segment_list)+1
            )
            self.flight_segment_list.append(self._build_flight_segment(segment, segment_key, lang))
            service, service_key = self._build_service(segment, segment_key)

            self.service_list.append(service)
            service_keys.append(service_key)
            segment_keys.append(segment_key)
            fare_bases_segments[adult_fare_bases[index]].append(segment_key)
        return segment_keys, service_keys, fare_bases_segments

    def _get_prive_class(self, fare_rule, brand):
        if fare_rule or brand:
            brand = brand or list(fare_rule['brands'])[0]
            if brand not in self.price_class_list_brand:
                self.price_class_list_brand.append(brand)
                self.price_class_list.append(self._build_price_class(brand, fare_rule))

    def _generate_by_fare_bases(self, fare_bases, fare_bases_segments, tariff, fare_rule, traveler_key_by_type):
        fare_bases_generates = []
        checked_bag_keys = set()
        carry_on_all_keys = set()
        for index, fare_base in enumerate(fare_bases):
            if fare_base in fare_bases_generates:
                continue
            fare_bases_generates.append(fare_base)
            self.fare_list.append(
                self._build_fare_group(fare_base, fare_bases_segments[fare_base], tariff, fare_rule)
            )

            if SBPassengerTypes.INFANT in traveler_key_by_type:
                carry_on_all_key = self._add_build_carry_on_allowance(NDCPassengerTypes.INFANT, fare_rule, traveler_key_by_type.get(SBPassengerTypes.INFANT))
                if carry_on_all_key:
                    carry_on_all_keys.add(carry_on_all_keys)
                checked_bag_keys.add(self._add_build_checked_bag(NDCPassengerTypes.INFANT, fare_rule, traveler_key_by_type.get(SBPassengerTypes.INFANT)))
                applicable_party = ' '.join(
                    [_key for _type, _key in traveler_key_by_type.iteritems() if _type != SBPassengerTypes.INFANT])
            else:
                applicable_party = 'Party'

            checked_bag_keys.add(self._add_build_checked_bag(NDCPassengerTypes.ADULT, fare_rule, applicable_party))
            carry_on_all_keys.add(self._add_build_carry_on_allowance(NDCPassengerTypes.ADULT, fare_rule, applicable_party))

        return fare_bases_generates, checked_bag_keys, carry_on_all_keys

    def _build_disclosures(self, segment_keys, fare_rule, lang):
        for segment_key in segment_keys:
            tg_key = "TG_" + fare_rule['fare_rule_name']
            exclusions = fare_rule.get('exclusions')
            additional_info = fare_rule.get('additional-info')
            if exclusions:
                for exclusion_ways, exclusion_info in exclusions.iteritems():
                    if segment_key.split("_")[1] in exclusion_ways:
                        tg_key += "_1"
                        additional_info = exclusion_info.get('additional-info')
            ref = segment_key + " " + tg_key
            self.disclosures.append(E('Description', refs=ref))
            if tg_key not in self.disclosures_list:
                descriptions = []
                if additional_info:
                    for info in additional_info:
                        description = {'text': info.get('text').format(lang=lang)}
                        if info.get('link'):
                            description['link'] = info.get('link').format(lang=lang)
                        descriptions.append(description)
                self.disclosures_list[tg_key] = descriptions

    def _build_disclosures_list(self):
        disclosures = []
        for tg_key, descriptions in self.disclosures_list.iteritems():
            descriptions_data = []
            for data in descriptions:
                description = [E('Text', data['text'])]
                if 'link' in data:
                    description.append(E('Link', data['link'].decode("UTF-8")))
                descriptions_data.append(E('Description', *description))
            disclosures.append(E('Disclosures', *descriptions_data, ListKey=tg_key))
        return disclosures

    def _build_nodes(self):
        lang = self.sb_search_rq['lang']
        activate(lang or config.DEFAULT_LANGUAGE_CODE)

        self.flight_cnt = 0
        priced_flight_offers = []
        anonymous_traveler_list = self._get_anon_travelers()
        traveler_nodes = [node for (key, node) in anonymous_traveler_list.itervalues()]
        traveler_key_by_type = {pt: key for pt, (key, node) in anonymous_traveler_list.iteritems()}

        for segments, tariff in self.sb_search_rs:
            pax_prices = self.sb_price_rs['pax_prices']
            fare_base = tariff['fare_bases'][0][:3] if tariff.get('fare_bases') else None
            fare_group = tariff.get('fare_group') or None
            fare_rule = FareRulesMapping.get(fare_group, fare_base, lang=lang)

            if self.flight_cnt == 0:
                priced_flight_offers = self._build_priced_flight_offers(pax_prices, traveler_key_by_type)

            segment_keys, service_keys, fare_bases_segments = self._generate_by_segments(segments, tariff['fare_bases'],
                                                                                         lang)

            self._get_prive_class(fare_rule, tariff['brand'])

            fare_bases_generates, checked_bag_keys, carry_on_all_keys = self._generate_by_fare_bases(
                tariff['fare_bases'],
                fare_bases_segments,
                tariff, fare_rule, traveler_key_by_type)

            flight_key, flight = self._build_flight(segments, segment_keys)
            self.flight_list.append(flight)

            self._build_disclosures(segment_keys, fare_rule, lang)
            self.origin_destination_list.append(self._build_origin_destination(segments, flight_key))
            self.associations_list.append(
                self._build_association(service_keys, segment_keys, tariff, carry_on_all_keys, checked_bag_keys, flight_key)
            )

        return [
            E('PricedFlightOffers', E('PricedFlightOffer', *priced_flight_offers + self.associations_list +
                                      [E('Disclosure', *self.disclosures)], ObjectKey=u'PFO1')),
            self._build_data_lists(traveler_nodes),
            self._build_meta_data()
            ]

    def build_tree(self):
        return self._build_nodes()
