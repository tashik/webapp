# -*- coding: utf-8 -*-

"""
$Id: $
"""
import threading
import time

import cherrypy
import requests

import config
from services import CPService


class ThreadStatus(object):
    start = None
    end = None
    url = None

    def last_req_time(self):
        if self.end is None:
            return 0
        return self.end - self.start

    def idle_time(self):
        if self.end is None:
            return 0
        return time.time() - self.end


# see http://tools.cherrypy.org/wiki/StatusTool
class StatusMonitor(cherrypy.Tool):
    """Register the status of each thread."""
    count = 0
    start_time = None
    sum_time = 0
    success_count = 0

    def __init__(self):
        self._point = 'on_start_resource'
        self._name = 'status'
        self._priority = 50
        self.seen_threads = {}
        StatusMonitor.start_time = time.time()

    def callable(self):
        match = cherrypy.request.dispatch.mapper.match(cherrypy.url(relative='server'))
        if match and cherrypy.url(relative='server') not in config.SKIP_STATISTICS_URLS:
            thread_id = threading._get_ident()
            ts = self.seen_threads.setdefault(thread_id, ThreadStatus())
            ts.start = cherrypy.response.time
            ts.url = cherrypy.url()
            ts.end = None
            StatusMonitor.count += 1

    def unregister(self):
        """Unregister the current thread."""
        match = cherrypy.request.dispatch.mapper.match(cherrypy.url(relative='server'))
        if match and cherrypy.url(relative='server') not in config.SKIP_STATISTICS_URLS:
            thread_id = threading._get_ident()
            if thread_id in self.seen_threads:
                self.seen_threads[thread_id].end = time.time()
                StatusMonitor.sum_time += self.seen_threads[thread_id].end - self.seen_threads[thread_id].start
                if cherrypy.response.status == '200 OK':
                    StatusMonitor.success_count += 1

    def _setup(self):
        super(StatusMonitor, self)._setup()
        cherrypy.request.hooks.attach('on_end_resource', self.unregister)


class HeartbeatService(CPService):
    """Сервис мониторинга. Проверяем, что нет явных нарушений в работе"""

    STATUS_TMPL = """
<html>
<head>
    <title>CherryPy Status</title>
</head>
<body>
<p>Current time: %(current_time)s</p>
<p>Start time: %(start_time)s</p>
<p>Uptime: %(uptime)i s</p>
<p>Requests served: %(count)i</p>
<p>Requests success: %(success_count)i</p>
<p>Requests failed: %(failed_count)i</p>
<p>Total requests processing time: %(sum_time)f</p>
<table>
<tr><th>Thread ID</th><th>Idle Time</th><th>Last Request Time</th><th>URL</th></tr>
%(threads)s
</table>
</body>
</html>
"""

    DIAG_TMPL = '<html><body>%(body)s</body></html>'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('heartbeat_svc', '/services/ping', controller=self, action='ping')
        dispatcher.connect('heartbeat_sb', '/services/ping_diag', controller=self, action='ping_diag')
        dispatcher.connect('heartbeat_status', '/services/status', controller=self, action='status')

    def ping(self):
        # TODO check server OK
        return self.render('PONG!')

    def ping_diag(self):
        start_t = time.time()
        try:
            requests.get(config.SB_MONITORING_URL)
        except Exception as err:
            cherrypy.response.status = 500
            text = "%s %s" % (err.__class__.__name__, str(err))
            status = 'FAIL'
        else:
            text = 'OK'
            status = 'SUCCESS'
        finally:
            request_time = time.time() - start_t
        message = 'SB: %s; request time %.2f<br/>\n%s' % (text, request_time, status)
        return self.DIAG_TMPL % {'body': message}

    def status(self, **params):
        if params.get('reset_counters') == '1':
            cherrypy.tools.status.seen_threads.clear()
            StatusMonitor.start_time = time.time()
            StatusMonitor.count = 0
            StatusMonitor.sum_time = 0
            return "statistics cleared"
        threadstats = [
            (thread_id, ts.idle_time(), ts.last_req_time(), ts.url)
            for thread_id, ts in cherrypy.tools.status.seen_threads.items()]
        threadstats_html = [
            '<tr><th>%s</th><td>%.4f</td><td>%.4f</td><td>%s</td></tr>' % s
            for s in threadstats
        ]
        return self.STATUS_TMPL % dict(threads='\n'.join(threadstats_html),
                                       current_time=time.ctime(),
                                       start_time=time.ctime(StatusMonitor.start_time),
                                       uptime=time.time() - StatusMonitor.start_time,
                                       count=StatusMonitor.count,
                                       sum_time=StatusMonitor.sum_time,
                                       success_count=StatusMonitor.success_count,
                                       failed_count=StatusMonitor.count - StatusMonitor.success_count)
