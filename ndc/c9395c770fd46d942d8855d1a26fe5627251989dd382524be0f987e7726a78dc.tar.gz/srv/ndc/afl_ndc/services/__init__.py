# -*- coding: utf-8 -*-

import sys
import cherrypy
import dirlog
from log import log
from exc import NDCError, InvalidXMLError


class CPService(object):
    """Сервис для использования в приложениях CherryPy"""

    _cp_config = {}
    _content_type = 'text/plain'

    def __init__(self):
        self._cp_config = dict(self._cp_config)
        self._cp_config['request.error_response'] = self._errorHandler

    def renderErrors(self, errors):
        if not hasattr(errors, '__iter__'):
            errors = [errors]
        errors = [str(e) for e in errors]
        return errors

    def _errorHandler(self):
        t, e, tb = sys.exc_info()
        errors = self.renderErrors(e)
        body = self.render(errors)
        cherrypy.response.body = body
        dirlog.log(e, tb)

        if isinstance(e, InvalidXMLError):
            cherrypy.response.status = 200
        elif isinstance(e, NDCError):
            cherrypy.response.status = 200
        else:
            cherrypy.response.status = 500

        if hasattr(cherrypy.request, 'logger'):
            cherrypy.request.logger.log_response(body, success='false; {} {}'.format(
                e.__class__.__name__, cherrypy.response.status))

    def render(self, content, **kwargs):
        cherrypy.response.headers['Content-Type'] = self._content_type
        return self._renderContent(content, **kwargs)

    def _renderContent(self, content, **kwargs):
        return content
