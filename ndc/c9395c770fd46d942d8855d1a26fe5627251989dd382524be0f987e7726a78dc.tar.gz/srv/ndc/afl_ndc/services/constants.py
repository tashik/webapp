# coding=utf-8

FLIGHT_KEY_TMP = u'FL{0}'
# SEG_<IATA_код_аэропорта_вылета><IATA_код_аэропорта_прилета>_<номер>
FLIGHT_SEGMENT_KEY_TMP = u'SEG_{0}{1}_{2}'
SEGMENTS_KEY_TMP = u'{0}_{1}_{2}'
SERVICE_ID_TMP = u'SRVC-{0}-{1}'
SERVICE_KEY_TMP = u'SV{0}'
PRICE_CLASS_KEY_TMP = u'PC{0}'
FARE_GROUP_LIST_KEY_TMP = u'FBCODE{0}'
ORIGIN_DESTINATION_KEY_TMP = u'OD{0}'
CARRY_ON_ALLOWANCE_KEY_TMP = u'CarryOn-{0}'
CHECKED_BAG_KEY_TMP = u'Baggage-{0}'
