# -*- coding: utf-8 -*-

from lxml import etree
from lxml.builder import E

from exc import NDCError
from services import CPService
import config


class XMLService(CPService):
    """Сервис, поддерживающий формат данных XML"""

    _content_type = 'text/xml'

    def renderErrors(self, errors):
        if not hasattr(errors, '__iter__'):
            errors = [errors]

        error_nodes = []
        for e in errors:
            if not isinstance(e, NDCError):
                e = NDCError(str(e))

            error_node = E('Error', Type=e.code, Code=e.code, ShortText=e.short_text[:255])
            if config.ADD_ERROR_TEXT_TO_RESPONSE and e.description and e.code != '914':
                error_node.text = e.description.decode("UTF-8")
            if config.ADD_ERROR_TEXT_TO_RESPONSE and e.ndc_internal_error_text:
                error_node.text = error_node.text if error_node.text is not None else '' + ' ' + e.ndc_internal_error_text
            error_nodes.append(error_node)

        root = E('Errors', *error_nodes)
        return root

    def _renderContent(self, content, **kwargs):
        return etree.tostring(content, encoding=config.ENCODING, pretty_print=True)
