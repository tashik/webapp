# -*- coding: utf-8 -*-
import urllib

import re
import config

PMB_NAME_SKIP_RE = re.compile('[' + re.escape(''.join(config.PMB_SKIP_SYMBOLS)) + ']')


def readable_json(text):
    return text.encode('utf-8')


def get_url(url, params):
    if params:
        return '{}?{}'.format(url, urllib.urlencode({k: v for k, v in params.items() if v is not None}))
    return url


def format_pax_name(pax_name, replace=''):
    return PMB_NAME_SKIP_RE.sub(replace, pax_name)
