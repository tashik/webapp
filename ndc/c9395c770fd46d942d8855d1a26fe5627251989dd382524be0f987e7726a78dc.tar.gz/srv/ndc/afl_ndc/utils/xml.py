# -*- coding: utf-8 -*-

import os
from decimal import Decimal

from lxml import etree
from lxml.builder import ElementMaker

import config
from exc import InvalidFormatError, InvalidXMLError
from exc import NDCSyntaxError, UnsupportedFunctionError


def parse_xml(xml_text):
    try:
        return etree.XML(xml_text)
    except etree.XMLSyntaxError as e:
        raise InvalidXMLError(str(e))


def get_tag_name(tag):
    try:
        return etree.QName(tag).localname
    except ValueError as e:
        raise NDCSyntaxError(str(e))


def get_xml_schema(file_name, version=config.DEFAULT_NDC_VERSION):
    file_path = os.path.join(config.SCHEMASDIR, version, '{}.xsd'.format(file_name))
    try:
        xsd = etree.parse(file_path)
    except IOError:
        raise UnsupportedFunctionError(file_name)
    return etree.XMLSchema(xsd)


def validate_xml(schema, xml):
    if isinstance(xml, basestring):
        xml = parse_xml(xml)
    try:
        schema.assertValid(xml)
    except (TypeError, etree.DocumentInvalid) as e:
        raise InvalidFormatError(str(e))
    return True


def strip_ns_prefix(tree):
    for element in tree.xpath('descendant-or-self::*'):
        ns = tree.nsmap.get(None)
        if ns is not None and ns in element.tag:
            element.tag = get_tag_name(element)
    return tree


class NSMAP(object):
    IATA_EDIST = 'http://www.iata.org/IATA/EDIST'
    XML_SCHEMA_INSTANCE = 'http://www.w3.org/2001/XMLSchema-instance'

    _SCHEMA_LOCATION_TMPL = 'http://www.iata.org/IATA/EDIST %s'
    _schema_loc = '{%s}schemaLocation' % XML_SCHEMA_INSTANCE


def add_text(elem, item):
    try:
        elem[-1].tail = (elem[-1].tail or "") + item
    except IndexError:
        elem.text = (elem.text or "") + item


def add_int(elem, item):
    text = str(item)
    if not elem:
        return text
    return add_text(elem, item)


def add_none(elem, item):
    text = ''
    if not elem:
        return text
    return add_text(elem, text)


def add_decimal(elem, item):
    text = str(item)
    if not elem:
        return text
    return add_text(elem, text)


E = ElementMaker(typemap={int: add_int, type(None): add_none, Decimal: add_decimal})


class NdcRootElementMaker(ElementMaker):
    def __call__(self, tag, *children, **attrib):
        schema_name = attrib.pop('schema_name', None)
        elem = super(NdcRootElementMaker, self).__call__(tag, *children, **attrib)
        if schema_name is not None:
            elem.attrib[NSMAP._schema_loc] = NSMAP._SCHEMA_LOCATION_TMPL % schema_name
        return elem


_ndc_root_nsmap = {
    None: NSMAP.IATA_EDIST,
    'xsi': NSMAP.XML_SCHEMA_INSTANCE,
}


NDC_ROOT_E = NdcRootElementMaker(namespace=NSMAP.IATA_EDIST, nsmap=_ndc_root_nsmap)
