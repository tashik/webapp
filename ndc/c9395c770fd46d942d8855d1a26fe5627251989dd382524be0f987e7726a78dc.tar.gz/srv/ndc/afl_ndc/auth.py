# -*- coding: utf-8 -*-
import cherrypy
import config
from exc import AuthorizationError


def authorize_for(obj):
    """Упрощенная авторизация для afl_ndc"""
    if config.NDC_DIGEST_ENABLED:
        ndc_digest = cherrypy.request.headers.get('Ndc-Digest')
        if (ndc_digest == config.NDC_DIGEST
            and cherrypy.request.remote.ip in config.NDC_DIGEST_IP):
            return True
        else:
            raise AuthorizationError()
    else:
        return True


def authorize(method):
    """Authorization decorator for object methods.
    
    Usage:
    
    class Foo():
    
        @authorize()
        def some_method(self, params):
            pass
    
    Authorizes method access before calling.
    """
    def decorator(self, *args, **kwargs):
        authorize_for(self)
        return method(self, *args, **kwargs)
    return decorator