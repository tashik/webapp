# coding=utf-8

import json
import cherrypy
import sys
import config

from notify.decode import (decode_country, decode_city,
                           decode_skyteam_service_classes)
from notify.vocabulary import VocabularyEvent, VocabularyFile

from log import log

OBJECT_DECODERS = {
    'Country': decode_country,
    'City': decode_city,
    'SkyTeamServiceClass': decode_skyteam_service_classes
}

LOGGER = log.action_logger


class NotifyService(object):
    _cp_config = {}
    csrf_enabled = False
    _content_type = 'application/json'

    def __init__(self):
        self._cp_config = dict(self._cp_config)
        self._cp_config['request.error_response'] = self._errorHandler

    def _connectToDispatcher(self, dispatcher):
        if config.PBUS_ENABLED:
            dispatcher.connect(
                'notify_vocabs', '/notify/%s' % config.PBUS_TOPICS['vocabs'],
                controller=self, action='index'
            )

    def _renderContent(self, content, **kwargs):
        return json.dumps(content, encoding='utf-8')

    def renderErrors(self, errors):
        if not hasattr(errors, '__iter__'):
            errors = [errors]
        errors = [isinstance(e, basestring) and unicode(str(e), 'utf-8') or
                  u'Ошибка приложения' for e in errors]

        cherrypy.response.headers['Content-Type'] = self._content_type
        cherrypy.response.status = 500

        content = json.dumps({'errors': errors}, encoding='utf-8')
        return content

    def _errorHandler(self):
        t, e, tb = sys.exc_info()
        content = self.renderErrors(e)
        cherrypy.response.status = 500
        cherrypy.response.body = content
        return content

    def render(self, content, **kwargs):
        cherrypy.response.headers['Content-Type'] = self._content_type
        return self._renderContent(content, **kwargs)

    def index(self, **params):
        body = cherrypy.request.body.read()
        msg_json = json.loads(body, encoding='utf-8')
        self.process(msg_json)
        return ''

    def process(self, msg_json):
        LOGGER.info(u'NotifyService process run')
        if isinstance(msg_json, list):
            pass
        elif isinstance(msg_json, dict) and 'event' in msg_json:
            # ответ на запрос (например, command get_all)
            msg_json = [msg_json, ]
        else:
            return

        for event in VocabularyEvent.from_json(msg_json):
            for cls_name, objects in event.decode(OBJECT_DECODERS):
                LOGGER.info(u'Loading vocabs {0}, event {1}'.format(
                    cls_name, event.type
                ))
                file_class = VocabularyFile(cls_name, objects)
                if event.type == 'replace_all':
                    # Заменяем/создаем все файлы
                    file_class.create()
                else:
                    # Открываем файл нужного словаря
                    file_class.update(event.type)
