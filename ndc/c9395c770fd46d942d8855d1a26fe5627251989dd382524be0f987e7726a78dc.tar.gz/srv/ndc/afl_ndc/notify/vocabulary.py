# coding=utf-8
import json
import os
import shutil
from lxml import etree

import config
from exc import VocabularyNotFoundError


def group_by_class(json_obs):
    r = {}
    for ob in json_obs:
        r.setdefault(ob['class'], []).append(ob)
    return r


def to_str(value):
    if isinstance(value, str):
        return value
    if isinstance(value, (int, bool, float)):
        return str(value)
    if isinstance(value, list):
        return json.dumps(value)
    return value


class VocabularyEvent(object):
    """ Событие обновления справочника
    """
    def __init__(self, event_type, event_objects):
        self.type = event_type
        self.objects = event_objects

    @classmethod
    def from_json(cls, msg_data):
        if isinstance(msg_data, list):
            events = msg_data
        elif isinstance(msg_data, dict) and 'event' in msg_data:
            # ответ на запрос (например, command get_all)
            events = [msg_data]
        else:
            # we don't understand this message
            events = []
        for event_json in events:
            yield cls(event_json['event'], event_json['objects'])

    def decode(self, decoders):
        for cls_name, json_obs in group_by_class(self.objects).items():
            decode = lambda x: x
            if decoders.get(cls_name):
                decode = decoders[cls_name]
            objects = [decode(obj) for obj in json_obs]
            yield cls_name, objects


class VocabularyFile(object):

    def __init__(self, cls_name, objects):
        self.cls_name = cls_name
        self.tmp_path = u'{0}/{1}.xml'.format(config.TMPDIR, self.cls_name)
        if not os.path.exists(config.VOCABS_CACHE_DIR):
            os.mkdir(config.VOCABS_CACHE_DIR)
        self.data_path = u'{0}/{1}.xml'.format(config.VOCABS_CACHE_DIR, self.cls_name)
        self.file = None
        self._file_exist = os.path.isfile(self.data_path)

        self.objects = objects

    def _remove_items(self, root, remove_items=None):
        remove_items = self.objects if remove_items is None else remove_items
        for remove_item in remove_items:
            item = self._find_item(root, remove_item)
            if item is not None:
                root.remove(item)

    def _update_items(self, root):
        for update_item in self.objects:
            item = self._find_item(root, update_item)
            if item is not None:
                for tag_name, value in update_item.iteritems():
                    if tag_name == 'id':
                        continue
                    item.xpath(u'{0}'.format(tag_name))[0].text = to_str(value)
            else:
                item = self._generate_item(update_item)
                root.append(item)

    def _generate_item(self, obj):
        item = etree.Element("item")
        item.append(etree.Element('from'))
        if 'id' in obj:
            item.set('id', obj['id'])
        for tag_name, value in obj.iteritems():
            if tag_name == 'id':
                continue
            tag = etree.Element(tag_name)
            tag.text = to_str(value)
            item.append(tag)

        return item

    def _generate_items(self):
        root = etree.Element("items")
        for obj in self.objects:
            item = self._generate_item(obj)
            root.append(item)
        return etree.tostring(root, pretty_print=True)

    def _create_file_class(self, data):
        with open(self.tmp_path, "w+") as f:
            f.write(data)

    @staticmethod
    def _get_all_id_items(root):
        return [item.attrib['id'] for item in root.findall('item[@id]')]

    def _find_item(self, root, object):
        item = []
        if 'id' in object:
            item = root.xpath('//item[@id="{0}"]'.format(object['id']))

        return item[0] if item else None

    def create(self):
        if not self._file_exist:
            items = self._generate_items()
            self._create_file_class(items)
        else:
            tree = etree.parse(self.data_path)
            root = tree.xpath('//items')[0]
            self._update_items(root)
            all_ids = self._get_all_id_items(root)
            vocab_ids = [item['id'] for item in self.objects]
            removed_ids = [{'id': item} for item in all_ids if item not in vocab_ids]
            if removed_ids:
                self._remove_items(root, removed_ids)
            self._create_file_class(etree.tostring(root, pretty_print=True))

        shutil.move(self.tmp_path, self.data_path)
        self._file_exist = os.path.isfile(self.data_path)

    def update(self, type_event):
        if self._file_exist:
            tree = etree.parse(self.data_path)
            root = tree.xpath('//items')[0]
            if type_event in ['change', 'add']:
                self._update_items(root)
            if type_event == 'delete':
                self._remove_items(root)
            self._create_file_class(etree.tostring(root, pretty_print=True))
            shutil.move(self.tmp_path, self.data_path)


class Vocabulary(object):

    def __init__(self, vocab_name):
        self.vocab_name = vocab_name
        self.data_path = u'{0}/{1}.xml'.format(config.VOCABS_CACHE_DIR, self.vocab_name)
        self.file = None
        self._file_exist = os.path.isfile(self.data_path)
        if not self._file_exist:
            raise VocabularyNotFoundError(u'Not found vocabulary')
        self.tree_vocab = etree.parse(self.data_path)

    @staticmethod
    def _item_to_dict(item):
        dict_item = {'id': item.attrib['id']}
        for child in item:
            if child.tag != 'from':
                dict_item[child.tag] = child.text
            else:
                for service_tag in child:
                    if len(service_tag):
                        children = {}
                        for tag in service_tag:
                            children[tag.tag] = tag.text
                        dict_item[service_tag.tag] = children
                    else:
                        dict_item[service_tag.tag] = service_tag.text

        return dict_item

    def get_vocabulary(self):
        for item in self.tree_vocab.xpath('/items/item'):
            yield self._item_to_dict(item)

    def find_item(self, value, tag=None, agent=None):
        root = self.tree_vocab.xpath('//items')[0]
        if agent:
            xpath = '//item/from/{0}[text()="{1}"] | //item/from/{0}/value[text()="{1}"]'.format(agent, value)
        else:
            if tag:
                xpath = '//item/{0}[text()="{1}"]'.format(tag, value)
            else:
                xpath = '//item[@id="{0}"]'.format(value)

        items = root.xpath(xpath)
        if items:
            item = items[0]
            if agent:
                item = items[0].getparent().getparent()
            elif tag:
                item = items[0].getparent()
            return self._item_to_dict(item)
        else:
            return None
