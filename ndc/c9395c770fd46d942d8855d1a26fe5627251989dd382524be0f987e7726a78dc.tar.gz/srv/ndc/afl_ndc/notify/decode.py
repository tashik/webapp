# coding=utf-8


def decode_country(json_ob):
    if json_ob['iso_code2']:
        return {'id': json_ob['iso_code2'], 'iso_code2': json_ob['iso_code2']}


def decode_city(json_ob):
    return {'id': str(json_ob['city_id']), 'iata': json_ob['iata']}


def decode_skyteam_service_classes(json_ob):
    return {'id': str(json_ob['skyteam_sc_id']), 'code': json_ob['code']}
