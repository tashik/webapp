# -*- coding: utf-8 -*-
import traceback
import warnings


class NDCError(Exception):
    """Базовый класс ошибки NDC"""

    # <xsd:pattern value="[0-9A-Z]{1,3}(\.[A-Z]{3}(\.X){0,1}){0,1}"/>
    code = '911'
    short_text = 'Unable to process - system error'
    description = ''
    ndc_internal_error_text = ''

    def __init__(self, description=None, code=None, short_text=None, ndc_internal_error_text=None):
        if description is not None:
            self.description = str(description)
        if code is not None and str(code):
            self.code = str(code)
        if short_text is not None and str(short_text):
            self.short_text = str(short_text)
        if ndc_internal_error_text is not None and str(ndc_internal_error_text):
            self.ndc_internal_error_text = unicode(ndc_internal_error_text)

    def __str__(self):
        string = '{} {}'.format(self.code, self.short_text)
        if self.description:
            string = '{} {}'.format(string, self.description)
        return string


class NDCSyntaxError(NDCError):
    code = '903'
    short_text = 'Unable to process - syntax error'


class FlightNotFound(NDCError):
    code = '102'
    description = 'Flights not found'


class InvalidCountryCode(NDCError):
    code = '109'
    short_text = 'Invalid Country Code'


class InvalidFlightNumber(NDCError):
    code = '114'
    short_text = 'Invalid/Missing Flight Number'


class InvalidArrivalDate(NDCError):
    code = '115'
    short_text = 'Invalid Arrival Date'


class UnsupportedFunctionError(NDCError):
    code = '915'
    short_text = 'No action - processing host cannot support function'


class InvalidFormatError(NDCError):
    code = '914'
    short_text = 'Invalid format/data - data does not match syntax rules'


class InvalidSegmentError(NDCError):
    code = '76I'
    short_text = 'Invalid segment select'


class InvalidServiceTypeCodeError(NDCError):
    code = '10'
    short_text = 'Invalid service type code'
    ndc_internal_error_text = "Invalid service type code"


class InvalidXMLError(InvalidFormatError):
    """ Не удалось построить xml DOM из текста - текст не является xml-документом"""


class InvalidPriceTypeQualifierError(NDCError):
    code = '713'
    short_text = 'Invalid Price Type Qualifier'


class InvalidFareBasis(NDCError):
    code = '715'
    short_text = 'Invalid fare basis'


class AlreadyTcketed(NDCError):
    code = '395'
    short_text = 'Already ticketed'


class InvalidTravelAgent(NDCError):
    code = '717'
    short_text = 'Missing and/or invalid travel agent and/or system identification'


class InvalidInfantsCount(NDCError):
    code = '324'
    short_text = 'Number of infants exceeds maximum allowed per adult passenger'


class InvalidAirportCode(NDCError):
    code = '4'
    short_text = 'Invalid city/airport code'


class GenderUndefined(NDCError):
    code = '474'
    short_text = 'Cannot find passenger details'
    ndc_internal_error_text = 'Cannot find passenger details'


class VocabularyNotFoundError(Exception):
    pass


class EmptyVocabularyItemError(Exception):
    pass


class NDCException(Exception):
    # сообщение об ошибке
    msg = u''

    # короткий (цифровой) код ошибки, выводится в сообщении об ошибке
    error_code = None

    def __init__(self, msg=None, *args, **kw):
        super(NDCException, self).__init__(msg, *args)
        if msg is not None:
            self.msg = msg
        elif not self.msg:
            warnings.warn(
                '%s must implement attribute `msg`' % self.__class__.__name__,
                stacklevel=2
            )

        try:
            self.error_code = kw['error_code']
        except KeyError:
            pass

        self.kw = kw

    def __unicode__(self):
        return str(self)

    def __repr__(self):
        args = list([repr(a) for a in self.args])
        try:
            args.extend(['%s=%s' % (k, repr(v)) for k, v in self.kw.items()])
        except Exception, e:
            traceback.print_exc()
            return '{INTERNAL EXCEPTION %s, see error.log}' % e.__class__.__name__

        return u'%s(%s)' % (self.__class__.__name__, u', '.join(args))

    def __call__(self):
        return str(self)

    def __str__(self):
        m = super(NDCException, self).__str__()
        if 'error_message' in self.kw:
            m = "%s: %s" % (m, self.kw['error_message'])
        return m


class AuthorizationError(Exception):
    msg = (u'Вы не имеете прав доступа, необходимых для '
           u'выполнения указанной операции')