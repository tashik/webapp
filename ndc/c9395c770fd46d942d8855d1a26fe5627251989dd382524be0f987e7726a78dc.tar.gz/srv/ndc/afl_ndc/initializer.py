# -*- coding: utf-8 -*-


import cherrypy

import config
import json

from rx.pbus.client import subscribe, post
from log import initCherrypyLoggers
from ws_tools import reject_stale_requests


def start_request_timer():
    import time
    cherrypy.request.start_time = time.time()


def init_pbus():
    subscribe(config.PBUS_TOPICS['vocabs'])
    post(
        config.PBUS_TOPICS['vocabs'],
        json.dumps({
            'command': 'get_all',
            'vocabularies': ['airlines']
        }),
        recipient=config.PBUS_VOCAB_RECIPIENTS['vocabs'],
    )


def init_cp_tools():
    from services.heartbeat import StatusMonitor
    cherrypy.tools.status = StatusMonitor()
    cherrypy.tools.request_timer = cherrypy.Tool('on_start_resource', start_request_timer, priority=0)
    cherrypy.tools.reject_stale_requests = cherrypy.Tool('on_start_resource', reject_stale_requests, priority=30)


# Инициализация --------------------------------------------------------------
def initialize():
    initCherrypyLoggers()
    init_cp_tools()
    if config.PBUS_ENABLED:
        init_pbus()
