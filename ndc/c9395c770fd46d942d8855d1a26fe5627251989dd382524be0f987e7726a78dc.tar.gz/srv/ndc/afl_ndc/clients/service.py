# -*- coding: utf-8 -*-

import json
from cookielib import DefaultCookiePolicy

from requests.auth import HTTPDigestAuth
from requests import exceptions, sessions
from clients.exc import ServiceNotFound, ServiceError

import log
from config import CONNECTION_REPEAT, CONNECTION_TIMEOUT
import cherrypy

LOGGER = log.log.dispatcher_logger


class ClientService(object):

    @property
    def names_urls(self):
        raise NotImplementedError('Implement me as well')

    @property
    def headers(self):
        raise NotImplementedError('Implement me as well')

    def _request(self, service_name=None, **kwargs):
        raise NotImplementedError('Implement me as well')

    def request_by_url(
            self, url, method='POST', json_params=None, data=None,
            params=None, auth=None, service_name=None, domain=None):
        json_params = json_params or {}
        data = data or ''

        if json_params:
            data = json.dumps(json_params)

        return self._send_request(
            method=method, url=url, data=data, params=params,
            headers=self.headers, auth=auth, service_name=service_name,
            domain=domain)

    @staticmethod
    def _debug_logger(*args, **kwargs):
        message = ' '.join(str(arg) for arg in args)
        if kwargs:
            message = '{}\n{}'.format(
                message,
                '\n'.join('{}={}'.format(key, value) for key, value in kwargs.items())
            )
        LOGGER.debug(message)

    @staticmethod
    def _info_logger(*args, **kwargs):
        message = ' '.join(str(arg) for arg in args)
        if kwargs:
            message = '{}\n{}'.format(
                message,
                '\n'.join('{}={}'.format(key, value) for key, value in kwargs.items())
            )
        LOGGER.info(message)

    def request_by_name(self, service_name, json_params=None, data=None, params=None):
        auth = None
        url, domain, auth_info = self.names_urls.get(service_name, (None, None, None))
        if auth_info is not None:
            auth_type, login, passwd = auth_info
            if auth_type == 'digest':
                auth = HTTPDigestAuth(login, passwd)
            else:
                raise ServiceNotFound('invalid auth type %r' % auth_type)
        if url:
            return self.request_by_url(
                url, service_name=service_name, json_params=json_params,
                data=data, params=params, auth=auth, domain=domain)
        else:
            self._debug_logger(
                'SBService not found', service_name, json=json_params,
                data=data, params=params, domain=domain)
            raise ServiceNotFound()

    def _send_request(self, **kwargs):
        exc = None
        for i in range(CONNECTION_REPEAT):
            try:
                cherrypy.request.attempt = i + 1
                return self._request(timeout=CONNECTION_TIMEOUT.seconds, **kwargs)
            except exceptions.RequestException as e:
                LOGGER.error(e.message)
                exc = e
                continue
        if exc is not None:
            raise ServiceError(exc.message)


class IgnoreDomainPortCookiePolicy(DefaultCookiePolicy, object):
    def set_ok_domain(self, cookie, request):
        return True

    def set_ok_port(self, cookie, request):
        return True


class HTTPService(ClientService):
    def __init__(self):
        super(HTTPService, self).__init__()
        self.session = sessions.Session()
        self.session.cookies.set_policy(IgnoreDomainPortCookiePolicy())

    def __enter__(self):
        self.session.__enter__()
        return self

    def __exit__(self, *args):
        self.session.__exit__(*args)

    def _do_request(self, **kwargs):
        if 'cookies' not in kwargs:
            kwargs['cookies'] = self.session.cookies
        domain = kwargs.pop('domain', None)
        if domain is not None:
            self.session.headers.update({'Host': domain})
        if 'X-Forwarded-For' in cherrypy.request.headers:
            self.session.headers.update({'X-Forwarded-For': ", ".join([cherrypy.request.headers['X-Forwarded-For'],
                                                                     cherrypy.server.socket_host])})

        return self.session.request(**kwargs)
