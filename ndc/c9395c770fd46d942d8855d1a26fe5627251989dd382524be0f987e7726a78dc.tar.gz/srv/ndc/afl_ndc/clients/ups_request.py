# -*- coding: utf-8 -*-

from uuid import UUID

from lxml.builder import E
from lxml import etree
from lxml.builder import ElementMaker

from clients.constants import NSMAP
import config


S = ElementMaker(namespace=NSMAP['soapenv'], nsmap=NSMAP)
X = ElementMaker(namespace=NSMAP['wsse'], nsmap=NSMAP)


class UPSWSRequest(object):
    tag = None
    namespace = None

    @property
    def tag(self):
        raise NotImplementedError('Implement tag as well')

    @property
    def namespace(self):
        raise NotImplementedError('Implement namespace as well')

    def __init__(self, username, password):
        assert isinstance(username, basestring)
        assert isinstance(password, basestring)
        self.username = username
        self.password = password

    def container(self):
        w = ElementMaker(namespace=self.namespace)
        e = getattr(w, self.tag)
        return e(*self.params())

    def token(self):
        return X.Security(X.UsernameToken(X.Username(self.username),
                                          X.Password(self.password,
                                                     Type="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordText")))

    def xml(self):
        return S.Envelope(S.Header(self.token()),
                          S.Body(self.container()))

    def __str__(self):
        return etree.tostring(self.xml(), pretty_print=True, encoding='utf-8', xml_declaration=True)


class OrderInfoRequestBase(UPSWSRequest):
    namespace = 'http://engine.paymentgate.ru/webservices/orderInfo'

    def __init__(self, lang):
        super(OrderInfoRequestBase, self).__init__(
            config.ORDWS_SOAP_USER, config.ORDWS_SOAP_PWD
        )
        assert isinstance(lang, basestring)
        self.lang = lang

    def params(self):
        return [E.language(self.lang.upper())]


class OrderInfoByIdRequest(OrderInfoRequestBase):
    tag = 'getOrderInfo'

    def __init__(self, order_id, **kwargs):
        super(OrderInfoByIdRequest, self).__init__(**kwargs)
        assert isinstance(order_id, UUID) or isinstance(order_id, basestring)
        if isinstance(order_id, UUID):
            order_id = str(order_id)
        self.id = order_id

    def params(self):
        p = super(OrderInfoByIdRequest, self).params()
        p.append(E.orderId(self.id))
        return [E.params(*p)]


class OrderInfoByPnrRequest(OrderInfoRequestBase):
    tag = 'getOrderInfoByPnr'

    def __init__(self, pnr, **kwargs):
        super(OrderInfoByPnrRequest, self).__init__(**kwargs)
        assert isinstance(pnr, basestring)
        self.pnr = pnr

    def params(self):
        p = super(OrderInfoByPnrRequest, self).params()
        p.append(E.reservationNumber(self.pnr.upper()))
        return [E.params(*p)]
