# -*- coding: utf-8 -*-

import json

import cherrypy
import sys
from requests import codes, request
from clients.exc import PMBResponseError
from clients.service import LOGGER, ClientService
from log import log_to_file, RequestLogger, log
from utils import readable_json, get_url
from config import SUB_SERVICES, SYS_NAME_PMB


class PMBService(ClientService):
    """Вызовы сервисов PMB"""

    headers = {'Content-Type': 'application/json'}
    names_urls = {service: (url, domain, auth_info) for sys, service, url, domain, auth_info in SUB_SERVICES if sys == SYS_NAME_PMB}

    def _request(self, method=None, url=None, data=None, params=None, auth=None, service_name=None, domain=None, **kwargs):
        log_url = get_url(url, params)
        tracking_id = getattr(cherrypy.request, 'tracking_id', None)

        self._debug_logger('PMBService request', method=method, url=log_url, data=data, **kwargs)
        self._info_logger('PMBService request', method=method, url=log_url, data_lenght=sys.getsizeof(data),
                          tracking_id=tracking_id)

        logger = RequestLogger(log.pmb_logger, action=service_name)
        logger.log_request(data, method, log_url)

        response = request(method, url, data=data, params=params, auth=auth, **kwargs)

        readable_response = readable_json(response.text)
        log_path = log_to_file(readable_response)
        self._debug_logger('PMBService response', response.status_code, log_path)
        self._info_logger('PMBService response', method=method, url=log_url, data_lenght=sys.getsizeof(data),
                          tracking_id=tracking_id, status_code=response.status_code)

        error_code = ''
        error_type = ''
        try:
            json_response = json.loads(response.text)
        except (TypeError, ValueError) as e:
            logger.log_response(readable_response, success='false; {} {}'.format(e.__class__.__name__, response.status_code))
        else:
            try:
                if json_response['isSuccess'] and response.status_code == codes.ok:
                    json_response['data']
                    logger.log_response(readable_response, success='true')
                    return json_response['data']
                else:
                    error_struct = json_response['errors'][0]
                    error_code = error_struct['code']
                    error_type = error_struct['comment']
            except (KeyError, AttributeError, IndexError) as e:
                LOGGER.error('PMBService invalid response format {}'.format(e))
                logger.log_response(readable_response, success='false; {} {}'.format(e.__class__.__name__, response.status_code))
            else:
                logger.log_response(readable_response, success='false; {} {}'.format(error_code, response.status_code))

        message = 'PMBService error: HTTP {} {} {}'.format(response.status_code, error_code, error_type)
        LOGGER.error(message)
        if error_code:
            LOGGER.error('PMBService unknown error code: {}'.format(error_code))

        raise PMBResponseError(message)

    def booking_v1(self, pnr, last_name, first_name=None, _preferredLanguage=None, map_to_sb=False):
        response = self.request_by_name('booking_v1', params={
            'pnr': pnr, 'last_name': last_name, 'first_name': first_name, '_preferredLanguage': _preferredLanguage,
        })
        if map_to_sb:
            return BookingPMBToSBMapper(response).process()
        return response


class BookingPMBToSBMapper(object):

    def __init__(self, response):
        self.response = response

    def process(self):
        # Новые поля
        self.response.setdefault('has_changed_segments', False)  # Нет в booking v1, есть в v2
        self.response['checkin_url'] = self._get_checkin_url()
        self.response['services'] = {}

        self._map_dict(self.response, (
            ('pnr', 'pnr_locator'),
            ('visaRequired', 'is_visa_required'),
            ('residenceRequired', 'is_residence_required'),
            ('meal', 'meals'),
        ))
        for pax in self.response['passengers']:
            self._map_dict(pax, (
                ('firstName', 'first_name'),
                ('lastName', 'last_name'),
                ('infant', 'is_infant'),
                ('loyaltyNumber', 'loyalty_number'),
                ('loyaltyLevel', 'loyalty_level'),
                ('birthDate', 'birthdate'),
                ('refNumber', 'ref_number'),
            ))
            self._map_dict(pax['document'], (
                ('expiration', 'doc_expiration'),
                ('issuedCountry', 'doc_country'),
                ('number', 'doc_number'),
            ))
            pax['pax_type'] = self._map_pax_type(pax.pop('paxType'))
            pax['escort_ref'] = ''
            pax['phone'] = ''
            pax['loyalty_name'] = ''
            pax['loyalty_level_name'] = ''
            pax['ticketing_documents'] = []

        for segment in self.response['segments']:
            self._map_dict(segment, (
                ('originalAirline', 'original_airline_code'),
                ('originalNumber', 'original_flight_number'),
                ('segmentNumber', 'segment_number'),
                ('bookingCode', 'booking_class_code'),
                ('airplaneType', 'airplane_code'),
                ('utcOffsetDeparture', 'departure_utc_offset'),
                ('utcOffsetArrival', 'arrival_utc_offset'),
                ('flightNumber', 'flight_number'),
                ('airline', 'airline_code'),
                ('statusCode', 'status_code'),
                ('flightTime', 'flight_time'),
            ))
            segment['origin'] = {
                'airport_code': segment.pop('origin'),
                'terminal_code': segment.pop('originTerminal'),
                'airport_name': '',
                'terminal_name': '',
                'country_name': '',
                'country_code': '',
                'city_name': '',
                'city_code': '',
            }
            segment['destination'] = {
                'airport_code': segment.pop('destination'),
                'terminal_code': segment.pop('destinationTerminal'),
                'airport_name': '',
                'terminal_name': '',
                'country_name': '',
                'country_code': '',
                'city_name': '',
                'city_code': '',
            }
            segment.update({
                'departure_date_name': '',
                'departure_time': '',
                'arrival_date_name': '',
                'arrival_time': '',
                'original_airline_name': '',
                'booking_class_name': '',
                'airplane_name': '',
                'airline_name': '',
                'status_name': '',
                'seat_preselect': True,
                'transfer_same_terminal': True,
                'flight_time_name': '',
                'transfer_time': '',
                'meal_codes': [],
                'meal_name': '',
            })
        self.response['segment_groups'] = [{
            'segments': self.response.pop('segments'),
            'start_weekday_name': '',
            'total_time_name': '',
        }]

        return self.response

    def _map_dict(self, dictionary, fields):
        for from_field, to_field in fields:
            dictionary[to_field] = dictionary.pop(from_field)
        return dictionary

    def _get_checkin_url(self):
        for segment in self.response['segments']:
            if segment['checkin_url']:
                return segment['checkin_url']
        return ''

    def _map_pax_type(self, pax_type):
        # FIXME: map for real
        return pax_type
