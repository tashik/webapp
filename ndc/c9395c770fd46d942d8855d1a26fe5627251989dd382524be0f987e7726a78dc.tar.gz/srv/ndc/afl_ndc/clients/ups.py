# -*- coding: utf-8 -*-

from __future__ import with_statement
import urlparse
from StringIO import StringIO

from lxml import etree
from requests import request, codes

from clients.service import ClientService, LOGGER
from clients.models import Order
from clients.ups_request import OrderInfoByIdRequest, OrderInfoByPnrRequest
from clients.ups_response import OrderInfoResponse
from clients.exc import UPSWSResponseException, OrderResponseError

from config import SUB_SERVICES, ORDWS_SOAP_BASE_URL, SYS_NAME_EPR
from exc import NDCException


class UPSService(ClientService):
    """ Соединение с системой дистрибуции купонов """
    names_urls = {service: (url, domain, auth_info) for sys, service, url, domain, auth_info in SUB_SERVICES if sys == SYS_NAME_EPR}
    headers = {}

    def __init__(self, url):
        o = urlparse.urlparse(url)
        self.url = url
        self.host = o.hostname
        self.headers = {"Host": self.host,
                        "Content-Type": 'text/xml;charset=UTF-8',
                        "User-Agent": "Aeroflot booking"}

    @staticmethod
    def _request(service_name=None, domain=None, **kwargs):
        response = request(**kwargs)
        if response.status_code == codes.ok:
            return etree.parse(StringIO(response.text))
        else:
            LOGGER.error(u'Ошибка ответа сервисов ЕПР: {0}'.format(response.text))
            raise UPSWSResponseException()

    def _get_response(self, data):
        result = self.request_by_url(ORDWS_SOAP_BASE_URL, data=str(data))
        try:
            response = OrderInfoResponse(result)
        except NDCException as e:
            self._debug_logger(self.url, xml=data)
            LOGGER.error(e.kw.get('error_message', e.msg))
            raise e

        if response.errors:
            LOGGER.error(u'Ошибка ответа сервисов ЕПР: {0}'.format(response.errors))
            raise OrderResponseError(error_message=response.errors)
        return Order.from_orderinforesponse(response)

    def get_order_info_by_id(self, order_id, lang):
        data = OrderInfoByIdRequest(order_id, lang=lang)
        return self._get_response(data)

    def get_order_info_by_pnr(self, pnr, lang):
        data = OrderInfoByPnrRequest(pnr, lang=lang)
        return self._get_response(data)
