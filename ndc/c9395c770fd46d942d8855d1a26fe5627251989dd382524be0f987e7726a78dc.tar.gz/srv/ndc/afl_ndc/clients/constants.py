# -*- coding: utf-8 -*-

WRONG_PARAM_MSG = u'Not a valid type parameter {0}, expected: {1}'


PASSENGER_TYPES = ['ADULT', 'CHILD', 'INFANT', 'INFSEAT', 'YOUTH']
DOC_TYPES = ['PASSPORT', 'OTHER']


NOT_PAID = '0'
PAID_TICKETS_ISSUED = '1'
PAID_TICKETS_NOT_ISSUED = '2'
CANCELLED = '3'
PAID_IN_EXTERNAL_SYSTEM = '4'
CANT_BE_PAID = '5'

ORDER_STATUS = {
    NOT_PAID: u'Заказ не оплачен',
    PAID_TICKETS_ISSUED: u'Заказ оплачен, билеты выпущены',
    PAID_TICKETS_NOT_ISSUED: u'Заказ оплачен, билеты не выпущены',
    CANCELLED: u'Заказ отменен',
    PAID_IN_EXTERNAL_SYSTEM: u'Заказ оплачен во внешней системе',
    CANT_BE_PAID: u'Заказ не может быть оплачен',
}

ORDER_STATES = {
    NOT_PAID: u'Не оплачен',
    PAID_TICKETS_ISSUED: u'Оплачен',
    PAID_TICKETS_NOT_ISSUED: u'Оплачен',
    CANCELLED: u'Отменен',
    PAID_IN_EXTERNAL_SYSTEM: u'Оплачен',
    CANT_BE_PAID: u'Заказ не может быть оплачен',
}


class OrderEmailType:
    PAYMENT = 1
    BOOKING = 2


NSMAP = {'soapenv': 'http://schemas.xmlsoap.org/soap/envelope/',
         'wsse': 'http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd'}
