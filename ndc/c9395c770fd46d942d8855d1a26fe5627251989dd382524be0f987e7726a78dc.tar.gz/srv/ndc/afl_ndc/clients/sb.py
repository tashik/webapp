
# -*- coding: utf-8 -*-

import bisect
import json
import heapq
import time
from copy import deepcopy

import sys

import cherrypy
from requests import codes
from decimal import Decimal

from clients.constants import WRONG_PARAM_MSG
from clients.exc import ParametersError, ServiceResponseError
from clients.models import (RequestSearchParams, RequestFareRules,
                            SegmentAdditionInfo, SegmentMiles, PriceParameters,
                            SelectedPlace, SelectedMeal, ExchangeCost,
                            ExchangeSegments, BookParams, Route)
from clients.service import HTTPService, LOGGER
from mapping.enums import SBCabinTypes
from mapping.mapping import NDCErrorMappingReader
from mapping.utils import parse_sb_datetime
from log import log_to_file, RequestLogger, log
from utils import readable_json, get_url
from config import SUB_SERVICES, SYS_NAME_SB, SB_ERRORS_MAPPING_FILE, MIN_FORWARD_TO_RETURN_TIME, SEARCH_MAX_COMBINED_PRICES
import config
from collections import defaultdict


class SBService(HTTPService):
    """Вызовы сервисов SB.
       Подробная информаци по сервисам
       https://trac.com.spb.ru/afl_sb/wiki/service_app_api
    """

    headers = {'Content-Type': 'application/json'}

    names_urls = {service: (url, domain, auth_info) for sys, service, url, domain, auth_info in SUB_SERVICES if sys == SYS_NAME_SB}

    def _request(self, method=None, url=None, data=None, params=None, auth=None, service_name=None, **kwargs):
        log_url = get_url(url, params)
        tracking_id = getattr(cherrypy.request, 'tracking_id', None)
        attempt = getattr(cherrypy.request, 'attempt', None)
        self._info_logger('SBService request', method=method, url=log_url, data_lenght=sys.getsizeof(data),
                        tracking_id=tracking_id, attempt=attempt)
        self._debug_logger('SBService request', method=method, url=log_url, data=data, **kwargs)
        logger = RequestLogger(log.sb_logger, action=service_name)
        logger.log_request(data, method, log_url)

        response = self._do_request(method=method, url=url, data=data, params=params, auth=auth, **kwargs)
        sb_session_id = self.session.cookies.get('sb_session_id')

        readable_response = readable_json(response.text)
        log_path = log_to_file(readable_response)
        self._debug_logger('SBService response', response.status_code, log_path, sb_session_id)
        self._info_logger('SBService response', method=method, url=log_url, data_lenght=sys.getsizeof(data),
                          tracking_id=tracking_id, sb_session_id=sb_session_id, status_code=response.status_code)
        error_code = ''
        error_type = ''
        try:
            json_response = json.loads(response.text)
        except (TypeError, ValueError) as e:
            logger.log_response(readable_response, success='false; {} {}'.format(e.__class__.__name__, response.status_code))
        else:
            try:
                # success в SB, isSuccess в WS2
                if (json_response.get('success') or json_response.get('isSuccess')) and response.status_code == codes.ok:
                    json_response['data']
                    logger.log_response(readable_response, success='true')
                    return json_response['data']
                else:
                    # error в SB, errors в WS2
                    error_struct = json_response.get('error') or json_response['errors'][0]
                    error_code = error_struct['code']
                    error_type = error_struct['type']
                    error_message = error_struct['message']
            except (KeyError, AttributeError, IndexError) as e:
                LOGGER.error('SBService invalid response format {}'.format(e))
                logger.log_response(readable_response, success='false; {} {}'.format(e.__class__.__name__, response.status_code))
            else:
                logger.log_response(readable_response, success='false; {} {}'.format(error_code, response.status_code))

        message = 'SBService error: HTTP {} {} {}'.format(response.status_code, error_code, error_type)
        LOGGER.error(message)
        if error_code:
            ndc_error = NDCErrorMappingReader(SB_ERRORS_MAPPING_FILE).get_exception(error_code)
            if ndc_error:
                ndc_error.description = error_message.encode('utf-8')
                raise ndc_error
            LOGGER.error('SBService unknown error code: {}'.format(error_code))

        raise ServiceResponseError(message)

    def search(self, request_search_params, combine=False):
        if not isinstance(request_search_params, RequestSearchParams):
            raise ParametersError(
                u'The format of the method parameters is not correct. '
                u'Use RequestSearchParams.'
            )
        response = self.request_by_name('search', request_search_params.to_json())
        if combine:
            max_results = request_search_params.max_results
            flights = []
            if request_search_params.routes_for_filter:
                for route in request_search_params.routes_for_filter:
                    if route.marketing_airline_flight_number:
                        flights.append((route.marketing_airline_id, unicode(route.marketing_airline_flight_number)))
            return SearchCombiner(response,
                                  max_prices=SEARCH_MAX_COMBINED_PRICES if max_results is None else int(max_results),
                                  cabin=request_search_params.cabin, min_price_enabled=request_search_params.min_price,
                                  flights=flights,
                                  ).process()
        return response

    def search_min_prices(self, request_search_params):
        if not isinstance(request_search_params, RequestSearchParams):
            raise ParametersError(u'The format of the method parameters '
                                  u'is not correct. Use RequestSearchParams.')
        return self.request_by_name(
            'search_min_prices', request_search_params.to_json()
        )

    def fare_rules(self, fare_request):
        if not isinstance(fare_request, RequestFareRules):
            raise ParametersError(u'The format of the method parameters is not'
                                  u' correct. Use RequestFareRules.')
        return self.request_by_name('fare_rules', fare_request._asdict())

    def additional_info(self, segments):
        msg = u'An array of Segment type records, the expected format: ' \
              u'[SegmentAdditionInfo(), ...]'
        if not isinstance(segments, list):
            raise ParametersError(msg)

        for s in segments:
            if not isinstance(s, SegmentAdditionInfo):
                raise ParametersError(msg)

        return self.request_by_name(
            'additional_info', {'segments': [s.to_json() for s in segments]}
        )

    def miles(self, segments):
        msg = u'An array of Segment type records, the expected format: ' \
              u'[SegmentMiles(), ...]'
        if not isinstance(segments, list):
            raise ParametersError(msg)
        for s in segments:
            if not isinstance(s, SegmentMiles):
                raise ParametersError(msg)

        return self.request_by_name(
            'miles', {'segments': [s._asdict() for s in segments]}
        )

    def check_coupons(self, coupons, lang):
        msg = u'An array of Coupons type records, the expected format: ' \
              u'["SOME_CODE", ...]'
        if not isinstance(coupons, list):
            raise ParametersError(msg)
        return self.request_by_name(
            'check_coupons', {'coupons': coupons, 'lang': lang}
        )

    def price(self, params):
        if not isinstance(params, PriceParameters):
            raise ParametersError(
                WRONG_PARAM_MSG.format('params', 'PriceParameters')
            )

        return self.request_by_name('price', params.to_json())

    def price_award(self, params):
        if not isinstance(params, PriceParameters):
            raise ParametersError(
                WRONG_PARAM_MSG.format('params', 'PriceParameters')
            )

        return self.request_by_name('price_award',  params.to_json())

    def book(self, params):
        if not isinstance(params, BookParams):
            raise ParametersError(
                WRONG_PARAM_MSG.format('params', 'BookParams')
            )
        return self.request_by_name('book', params.to_json())

    def book_award(self, params):
        if not isinstance(params, BookParams):
            raise ParametersError(
                WRONG_PARAM_MSG.format('params', 'BookParams')
            )
        return self.request_by_name('book_award', params.to_json())

    def pnr(self, pnr_locator, pnr_key, lang):
        return self.request_by_name(
            'pnr', {'pnr_locator': pnr_locator, 'pnr_key': pnr_key,
                    'lang': lang}
        )

    def pnr_search(self, pnr_locator, last_name, first_name, lang):
        return self.request_by_name(
            'pnr_search', {'pnr_locator': pnr_locator, 'last_name': last_name,
                           'first_name': first_name, 'lang': lang}
        )

    def seat_map(self, pnr_locator, pnr_key, segment_number, lang):
        return self.request_by_name(
            'seat_map', {'pnr_locator': pnr_locator, 'pnr_key': pnr_key,
                         'segment_number': segment_number, 'lang': lang})

    def choose_seat(self, pnr_locator, pnr_key, seats, lang):
        msg = WRONG_PARAM_MSG.format('seats', '[SelectedPlace(), ...]')
        if not seats or not isinstance(seats, list):
            raise ParametersError(msg)
        for seat in seats:
            if not isinstance(seat, SelectedPlace):
                raise ParametersError(msg)

        return self.request_by_name('choose_seat', {
            'pnr_locator': pnr_locator,
            'pnr_key': pnr_key,
            'seats': [s._asdict() for s in seats],
            'lang': lang
        })

    def choose_meal(self, pnr_locator, pnr_key, meals):
        msg = WRONG_PARAM_MSG.format('meals', '[SelectedMeal(), ...]')
        if not meals or not isinstance(meals, list):
            raise ParametersError(msg)
        for meal in meals:
            if not isinstance(meal, SelectedMeal):
                raise ParametersError(msg)

        return self.request_by_name('choose_meal', {
            'pnr_locator': pnr_locator,
            'pnr_key': pnr_key,
            'meals': [m._asdict() for m in meals]
        })

    def refund(self, pnr_locator, pnr_key, lang):
        return self.request_by_name(
            'refund', {'pnr_locator': pnr_locator, 'pnr_key': pnr_key,
                       'lang': lang}
        )

    def exchange_search(self, pnr_locator, pnr_key, routes, brands):
        msg = WRONG_PARAM_MSG.format('routes', '[Route(), ...]')
        if not isinstance(routes, list):
            raise ParametersError(msg)
        for r in routes:
            if not isinstance(r, Route):
                raise ParametersError(msg)
        return self.request_by_name(
            'exchange_search', {'pnr_locator': pnr_locator, 'pnr_key': pnr_key,
                                'routes': [r.to_json() for r in routes],
                                'brands': brands}
        )

    def exchange(self, pnr_locator, pnr_key, new_segments, lang,
                 cancel_segments_numbers=None, exchange_cost=None):
        msg = WRONG_PARAM_MSG.format('exchange_cost', '[ExchangeCost(), ...]')
        if not isinstance(exchange_cost, list):
            raise ParametersError(msg)
        for cost in exchange_cost:
            if not isinstance(cost, ExchangeCost):
                raise ParametersError(msg)

        msg = WRONG_PARAM_MSG.format(
            'new_segments', '[ExchangeSegments(), ...]'
        )
        if not isinstance(new_segments, list):
            raise ParametersError(msg)
        for ns in new_segments:
            if not isinstance(ns, ExchangeSegments):
                raise ParametersError(msg)

        return self.request_by_name(
            'exchange',
            {'pnr_locator': pnr_locator, 'pnr_key': pnr_key,
             'new_segments': {ns.id: ns.segment._asdict() for ns in new_segments},
             'lang': lang, 'cancel_segments_numbers': cancel_segments_numbers,
             'exchange_cost': [ex.to_json() for ex in exchange_cost]
             }
        )

    def settings(self):
        return self.request_by_name('settings')


class SearchCombiner(object):

    def __init__(self, response, max_prices=None, cabin=None, min_price_enabled=None, flights=None):
        self.response = response
        self.interlined = False
        self.max_prices = max_prices
        self.cabin = cabin
        self.min_price_enabled = min_price_enabled
        self.flights = flights

    def process(self):
        start = time.time()
        if len(self.response['ways']) == 0:
            return self.response

        if len(self.response['ways']) < 2:
            return self._build_one_way_response()

        return self._build_rt_response(start)

    def _build_rt_response(self, start):
        response = dict(self.response)
        response['days'] = []
        response['ways'] = [self.response['ways'][0]]

        if self.flights and len(self.flights) > 0:
            ways_filtered_by_flight = []
            idx = 0
            for way in self.response['ways']:
                ways_filtered_by_flight.append(self._filter_routes_by_flights(way, external_index=idx,
                                                                              check_only_index=0 if idx == 'first' else 'last'))
                idx += 1
            self.response['ways'] = ways_filtered_by_flight

        for way in self.response['ways'][1:]:
            routes = self._build_rt_routes_for_way(response, way)

            if not routes:
                response['ways'] = []
                self.interlined = self.response['interline']
                break

            routes = self._limit_routes(routes, self.flights is not None and len(self.flights) > 0)

            routes = [self._combine_routes(
                first_route,
                second_route,
                [self._combine_prices(*price) for price in prices]
            ) for first_route, second_route, prices in routes]

            if self.flights and len(self.flights) > 0:
                response['ways'] = [self._filter_routes_by_flights(routes)]
            else:
                response['ways'] = [routes]

        if self.interlined:
            response['interline'] = True

        log.dispatcher_logger.debug('Combined search response for {} s'.format(time.time() - start))
        return response

    def _build_rt_routes_for_way(self, response, way):
        routes = []
        for first_route in response['ways'][0]:
            arrival = parse_sb_datetime(first_route['segments'][-1]['arrival'])
            for second_route in way:
                departure = parse_sb_datetime(second_route['segments'][0]['departure'])
                if arrival + MIN_FORWARD_TO_RETURN_TIME > departure:
                    continue

                filtered_first_route = self._filter_routes_by_cabin([first_route])
                filtered_second_route = self._filter_routes_by_cabin([second_route])

                if len(filtered_first_route) == 0 or len(filtered_second_route) == 0:
                    continue

                first_route = filtered_first_route[0]
                second_route = filtered_second_route[0]

                prices = self._get_prices(
                    first_route['prices'],
                    second_route['prices'],
                    len(first_route['segments']),
                    len(second_route['segments']),
                )
                if prices:
                    routes.append((first_route, second_route, prices))

        return routes

    def _build_one_way_response(self):
        resp = self.response
        min_price_enabled = self.min_price_enabled == 'true' or (self.min_price_enabled is None
                                                                 and config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER)
        if min_price_enabled and (not self.flights or len(self.flights) == 0):
            self._truncate_one_way_offers_with_one_price_per_offer(resp)
        else:
            self._truncate_one_way_offers(resp)

        return resp

    def _truncate_one_way_offers(self, resp):
        routes = resp['ways'][0]
        routes = self._filter_routes_by_cabin(routes)
        routes = self._filter_routes_by_flights(routes)

        if len(routes) == 0:
            resp['ways'][0] = routes
            return

        all_prices = [Decimal(price['total']) for route in routes for price in route['prices']]

        if len(all_prices) <= self.max_prices:
            resp['ways'][0] = routes

        resp['ways'][0] = self._limit_one_way_offers(routes, all_prices)

    def _filter_routes_by_flights(self, routes, external_index=None, check_only_index=None):
        if self.flights and len(self.flights) > 0:
            routes_filtered_by_flight = []
            for route in routes:
                segments_flight_number_accepted = True
                idx = 0 if external_index is None else external_index
                for segment in route['segments']:
                    segment_airline_code = segment['airline_code']
                    segment_flight_number = segment['flight_number']
                    if (check_only_index == 'first' and idx == 0) or (check_only_index == 'last' and idx ==
                                                                      len(route['segments'])) or not check_only_index:
                        segments_flight_number_accepted = idx < len(self.flights) and segments_flight_number_accepted and (
                            segment_airline_code == self.flights[idx][0] and segment_flight_number == self.flights[idx][1])
                    if external_index is None:
                        idx += 1
                if segments_flight_number_accepted:
                    routes_filtered_by_flight.append(route)

            routes = routes_filtered_by_flight
        return routes

    def _limit_one_way_offers(self, routes, all_prices):
        limited_routes = []
        smallest = heapq.nsmallest(self.max_prices, all_prices)
        max_price = smallest[-1]
        total_max_prices = self.max_prices - bisect.bisect_left(smallest, max_price)

        n_max_prices = 0
        for route in routes:
            prices = []
            for price in route['prices']:
                total = Decimal(price['total'])
                if total < max_price:
                    prices.append(price)
                elif total == max_price and n_max_prices < total_max_prices:
                    n_max_prices += 1
                    prices.append(price)

            if prices:
                route['prices'] = prices
                limited_routes.append(route)

        return limited_routes

    def _truncate_one_way_offers_with_one_price_per_offer(self, resp):
        if len(resp['ways']) == 1:
            routes = resp['ways'][0]

            routes = self._filter_routes_by_cabin(routes)
            sorted_routes = sorted(routes, key=lambda x: Decimal(x['prices'][0]['total']))[:self.max_prices]

            for route in sorted_routes:
                route['prices'] = route['prices'][:1]

            resp['ways'][0] = sorted_routes

    def _filter_routes_by_cabin(self, routes):
        routes_by_cabin_type = defaultdict(list)
        for route in routes:
            for k in SBCabinTypes.__dict__.keys():
                if not k.startswith('__'):
                    r = deepcopy(route)
                    r['prices'] = [price for price in route['prices'] if
                                   price['class_of_service'] == getattr(SBCabinTypes, k)]
                    if len(r['prices']) > 0:
                        routes_by_cabin_type[getattr(SBCabinTypes, k)].append(r)

        if self.cabin == SBCabinTypes.ECONOM:
            if len(routes_by_cabin_type[SBCabinTypes.ECONOM]) > 0:
                return routes_by_cabin_type[SBCabinTypes.ECONOM]
            elif len(routes_by_cabin_type[SBCabinTypes.COMFORT]) > 0:
                return routes_by_cabin_type[SBCabinTypes.COMFORT]
            else:
                return routes_by_cabin_type[SBCabinTypes.BUSINESS]
        if self.cabin == SBCabinTypes.COMFORT:
            if len(routes_by_cabin_type[SBCabinTypes.COMFORT]) > 0:
                return routes_by_cabin_type[SBCabinTypes.COMFORT]
            else:
                return routes_by_cabin_type[SBCabinTypes.BUSINESS]
        if self.cabin == SBCabinTypes.BUSINESS:
            return routes_by_cabin_type[SBCabinTypes.BUSINESS]
        return []


    def _sort_prices(self, routes):
        return [(first_route, second_route, sorted(prices, key=lambda x: x[4])) for first_route, second_route, prices in routes]

    def _limit_routes(self, routes, only_sorting=False):
        if self.max_prices is None or only_sorting:
            return self._sort_prices(routes)

        only_min_price = self.min_price_enabled == 'true' or (
            self.min_price_enabled is None and config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER)

        if only_min_price and (not self.flights or len(self.flights) == 0):

            sorted_routes = sorted(routes, key=lambda x: min(x[2], key=lambda y: y[4])[4])
            limited_routes = [(first_route, second_route, sorted(prices, key=lambda x:x[4])[:1]) for first_route, second_route, prices in
                              sorted_routes[:self.max_prices]]

        else:
            all_prices = [price[4] for _, _, prices in routes for price in prices]
            if len(all_prices) <= self.max_prices:
                return self._sort_prices(routes)

            smallest = heapq.nsmallest(self.max_prices, all_prices)
            max_price = smallest[-1]
            total_max_prices = self.max_prices - bisect.bisect_left(smallest, max_price)
            limited_routes = []

            for first_route, second_route, original_prices in routes:
                prices = [price for price in original_prices if price[4] <= max_price]
                if not prices:
                    continue

                prices = sorted(prices, key=lambda x: x[4])
                if prices[-1][4] == max_price:
                    costs = [price[4] for price in prices]
                    i = bisect.bisect_left(costs, max_price)
                    n_max_prices = len(costs) - i
                    if total_max_prices >= n_max_prices:
                        total_max_prices -= n_max_prices
                    else:
                        prices = prices[:i + total_max_prices]
                        total_max_prices = 0
                        if not prices:
                            continue

                limited_routes.append((first_route, second_route, prices))

        return limited_routes

    def _combine_routes(self, first_route, second_route, prices):
        route = dict(first_route)
        route['prices'] = prices
        route['segments'] = first_route['segments'] + second_route['segments']
        return route

    def _get_prices(self, first_prices, second_prices, first_route_segments_len, second_route_segments_len):
        return [(
            first_price,
            second_price,
            first_route_segments_len,
            second_route_segments_len,
            Decimal(first_price['total']) + Decimal(second_price['total']),
        ) for first_price in first_prices for second_price in second_prices if self._prices_are_combinable(first_price, second_price)]

    def _prices_are_combinable(self, first_price, second_price):
        if second_price['brand'] not in first_price['combinable_brands'] or first_price['currency'] != second_price['currency']:
            return False

        for pax, second_cost in second_price['pax_prices'].items():
            if pax not in first_price['pax_prices']:
                return False

            if first_price['pax_prices'][pax]['currency'] != second_cost['currency']:
                return False

        return True

    def _combine_prices(self, first_price, second_price, first_route_segments_len, second_route_segments_len, *args):
        price = deepcopy(first_price)

        for pax, second_cost in second_price['pax_prices'].items():
            cost = price['pax_prices'][pax]
            cost['base'] = self._combine_numbers(cost['base'], second_cost['base'])
            cost['total'] = self._combine_numbers(cost['total'], second_cost['total'])
            cost['fare_bases'] = cost['fare_bases'] + second_cost['fare_bases']
            self._combine_taxes(cost['taxes'], second_cost['taxes'])

        price['booking_classes'] = price['booking_classes'] + second_price['booking_classes']
        price['combinable_brands'] = list(set(price['combinable_brands']) & set(second_price['combinable_brands']))
        price['fare_group_name_per_segment'] = [price['fare_group_name']] * first_route_segments_len + [second_price['fare_group_name']] * second_route_segments_len
        price['mileage'] = self._combine_numbers(price['mileage'], second_price['mileage'])
        price['base'] = self._combine_numbers(price['base'], second_price['base'])
        price['total'] = self._combine_numbers(price['total'], second_price['total'])
        price['seats'] = self._combine_seats(price['seats'], second_price['seats'])
        self._combine_taxes(price['taxes'], second_price['taxes'])

        if price['brand'] != second_price['brand']:
            self.interlined = True

        return price

    def _combine_taxes(self, first_taxes, second_taxes):
        for second_tax in second_taxes:
            for first_tax in first_taxes:
                if first_tax['tax_code'] == second_tax['tax_code']:
                    first_tax['amount'] = self._combine_numbers(first_tax['amount'], second_tax['amount'])
                    break
            else:
                first_taxes.append(second_tax)
        return first_taxes

    def _combine_numbers(self, first_number, second_number):
        return str(Decimal(first_number) + Decimal(second_number))

    def _combine_seats(self, first_seat, second_seat):
        if first_seat is None:
            return second_seat
        if second_seat is None:
            return first_seat
        return min(first_seat, second_seat)
