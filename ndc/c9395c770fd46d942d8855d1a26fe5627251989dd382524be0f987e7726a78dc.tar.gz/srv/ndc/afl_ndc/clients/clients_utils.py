# -*- coding: utf-8 -*-

from datetime import datetime
from clients.constants import WRONG_PARAM_MSG
from clients.exc import ParametersError


def _validate_date(date):
    try:
        datetime.strptime(date, '%Y-%m-%d')
    except ValueError:
        raise ParametersError(WRONG_PARAM_MSG.format(date, u'YYYY-MM-DD'))