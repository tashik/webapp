# -*- coding: utf-8 -*-
from __future__ import absolute_import
from exc import NDCException


class UPSWSException(NDCException):
    msg = u'Ошибка ЕПР'


class ParametersError(NDCException):
    pass


class ServiceError(NDCException):
    pass


class ServiceNotFound(NDCException):
    msg = 'Сервис не найден'


class ServiceResponseError(NDCException):
    msg = u'Ошибка ответа сервиса SB'


class PMBResponseError(NDCException):
    msg = u'Ошибка ответа сервиса PMB'


class UPSWSResponseException(NDCException):
    msg = u'Ошибка ответа сервисов ЕПР'


class UPSWSParseResponseException(NDCException):
    msg = u'Ошибка при разборе ответа сервисов ЕПР'


class UPSWSValueError(NDCException):
    msg = u'Ошибка системы дистрибуции купонов'


class UPSWSBadRequestException(NDCException):
    msg = u'Ошибка системы дистрибуции купонов'


class OrderNotFoundError(NDCException):
    msg = u'Заказ не найден'


class OrderResponseError(NDCException):
    msg = u'Получен ответ с ошибкой'


class UPSWSTransientConnectionException(NDCException):
    msg = u'Ошибка связи с сервисами ЕПР. Пожалуйста, повторите попытку позже.'


class UPSWSHTTPStatusException(UPSWSTransientConnectionException):
    def __init__(self, errcode, errmsg, headers, fp, **kw):
        super(UPSWSHTTPStatusException, self).__init__(**kw)
        self.errcode = errcode
        self.errmsg = errmsg
        self.headers = headers
        self.f = fp
