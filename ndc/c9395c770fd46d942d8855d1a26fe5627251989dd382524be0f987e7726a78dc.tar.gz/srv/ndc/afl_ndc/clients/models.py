# -*- coding: utf-8 -*-
from collections import namedtuple
import datetime

from clients.constants import WRONG_PARAM_MSG, PASSENGER_TYPES, DOC_TYPES, OrderEmailType, NOT_PAID, PAID_TICKETS_ISSUED, \
    PAID_TICKETS_NOT_ISSUED, ORDER_STATES, PAID_IN_EXTERNAL_SYSTEM
from clients.ups_response import OrderInfoResponse
from clients.clients_utils import _validate_date
from exc import ParametersError

RequestFareRules = namedtuple('RequestFareRules',
                              ['airline_code', 'origin', 'destination', 'departure', 'fare_code', 'lang'])

SegmentMiles = namedtuple('SegmentMiles',
                          ['airline', 'airport_from', 'airport_to', 'tier_level', 'booking_class'])

Flight = namedtuple('Flight',
                    ['airline_code', 'flight_number', 'booking_class', 'departure', 'destination', 'origin',
                     'marriage_group', 'brand'])

SelectedPlace = namedtuple('SelectedPlace', ['segment_number', 'passenger', 'seat_number'])

SelectedMeal = namedtuple('SelectedMeal', ['segment_number', 'passenger', 'meal_code'])


class SBCommonModel(object):

    @property
    def fields(self):
        raise Exception('Implemented fields!')


    def to_json(self):
        'Return a new OrderedDict which maps field names to their values'
        return {_field: getattr(self, _field) for _field in self.fields}


class RelatedSegments(SBCommonModel):

    fields = ['airline_code', 'booking_class', 'flight_number', 'departure',
              'destination', 'origin', 'original_airline_code', 'status',
              'inbound_connection', 'fare_group_name'
              ]

    def __init__(self, airline_code, booking_class, flight_number, departure,
                 destination, origin, original_airline_code, status,
                 inbound_connection, fare_group_name=None):
        self.airline_code = airline_code
        self.booking_class = booking_class
        self.flight_number = flight_number
        self.departure = departure
        self.destination = destination
        self.origin = origin
        self.original_airline_code = original_airline_code
        self.status = status
        self.inbound_connection = inbound_connection
        self.fare_group_name = fare_group_name


class Route(object):

    def __init__(self, origin, destination, departure, related_segments=None, marketing_airline_id=None,
                 marketing_airline_flight_number=None):
        self.origin = origin
        self.destination = destination
        _validate_date(departure)
        self.departure = departure
        self.related_segments = related_segments or []
        self._related_segments_validate()
        self.marketing_airline_id = marketing_airline_id
        self.marketing_airline_flight_number = marketing_airline_flight_number

    def _related_segments_validate(self):
        msg = WRONG_PARAM_MSG.format('related_segments', u'[RelatedSegments(), ...]')
        if not isinstance(self.related_segments, list):
            raise ParametersError(msg)

        for rs in self.related_segments:
            if not isinstance(rs, RelatedSegments):
                raise ParametersError(msg)

    def to_json(self):
        return {'origin': self.origin, 'destination': self.destination, 'departure': self.departure,
                'related_segments': [s.to_json() for s in self.related_segments]}


class ClientInformation(SBCommonModel):

    fields = ['ga_client_id', 'loyalty_id', 'device_token', 'device_key']

    def __init__(self, ga_client_id='', loyalty_id='', device_token='', device_key=''):
        self.ga_client_id = ga_client_id
        self.loyalty_id = loyalty_id
        self.device_token = device_token
        self.device_key = device_key


class SegmentAdditionInfo(SBCommonModel):

    fields = ['airplane', 'airline', 'airport_from', 'city_from',
              'country_from', 'airport_to', 'city_to', 'country_to']

    def __init__(self, airplane=None, airline=None, airport_from=None,
                 city_from=None, country_from=None, airport_to=None,
                 city_to=None, country_to=None):
        self.airplane = airplane	 # Строка	Тип воздушного судна	Нет
        self.airline = airline  # Строка	Авиакомпания	Нет
        self.airport_from = airport_from  # Строка	Аэропорт вылета	Нет
        self.city_from = city_from  # Строка	Город вылета	Нет
        self.country_from = country_from  # Строка	Страна вылета	Нет
        self.airport_to = airport_to  # Строка	Аэропорт прилета	Нет
        self.city_to = city_to  # Строка	Город прилета	Нет
        self.country_to = country_to  # Строка	Страна прилета	Нет


class Tariff(SBCommonModel):

    fields = ['pax_type', 'fare_bases']

    def __init__(self, pax_type, fare_bases):
        if not isinstance(fare_bases, list):
            raise ParametersError(u'An array of fare_bases type records, the expected format: ["SOME_CODE", ...]')
        self.fare_bases = fare_bases

        self.pax_type = pax_type.upper()
        if self.pax_type not in ['ADULT', 'CHILD', 'INFANT', 'YOUTH']:
            raise ParametersError(u'The class of service can be only: ADULT, CHILD, INFANT, YOUTH')


class ExchangeSegments(object):

    def __init__(self, _id, segment):
        self.id = _id
        if not isinstance(segment, RelatedSegments):
            raise ParametersError(WRONG_PARAM_MSG.format('segment', 'RelatedSegments'))
        self.segment = segment

    def to_json(self):
        return {
            'id': self.id,
            'segment': self.segment.to_json()
        }


class ExchangeCost(SBCommonModel):

    def __init__(self, currency, value=None):
        self.currency = currency
        self.value = value


class SpecialServiceAttrs(SBCommonModel):
    fields = ['ss_value', 'ss_code']

    def __init__(self, ss_code, ss_value=None):
        self.ss_value = ss_value
        self.ss_code = ss_code


class SpecialServiceParams(object):

    def __init__(self, ss_param_code, ss_param_attrs=None):
        self.ss_param_code = ss_param_code
        self.ss_param_attrs = ss_param_attrs or []
        self._validate()

    def _validate(self):
        msg = WRONG_PARAM_MSG.format('ss_param_attrs', '[SpecialServiceAttrs(), ...]')
        if not isinstance(self.ss_param_attrs, list):
            raise ParametersError(msg)
        for ssp in self.ss_param_attrs:
            if not isinstance(ssp, SpecialServiceAttrs):
                raise ParametersError(msg)

    def to_json(self):
        return {'ss_param_code': self.ss_param_code,
                'ss_param_attrs': [spa.to_json() for spa in self.ss_param_attrs]}


class SpecialService(object):
    def __init__(self, special_service_code, special_service_params=None):
        self.special_service_params = special_service_params or []
        self.special_service_code = special_service_code
        self._validate()

    def _validate(self):
        msg = WRONG_PARAM_MSG.format('special_service_params', '[SpecialServiceParams(), ...]')
        if not isinstance(self.special_service_params, list):
            raise ParametersError(msg)
        for ssp in self.special_service_params:
            if not isinstance(ssp, SpecialServiceParams):
                raise ParametersError(msg)

    def to_json(self):
        return {'special_service_code': self.special_service_code,
                'special_service_params': [ssp.to_json() for ssp in self.special_service_params]
                }


class Passenger(object):

    def __init__(self, pax_type, first_name, last_name, patronymic, birthdate,
                 sex, nationality, doc_type, doc_country, doc_expiration, doc_number, **kwargs):
        self.pax_type = pax_type.upper()
        if self.pax_type not in PASSENGER_TYPES:
            raise ParametersError(
                u'Not a valid type parameter pax_type, expected in ["ADULT", "CHILD", "INFANT", "INFSEAT", "YOUTH"]'
            )
        self.first_name = first_name
        self.patronymic = patronymic
        self.last_name = last_name
        self.birthdate = birthdate

        self.sex = sex
        self.nationality = nationality

        self.doc_type = doc_type.upper()
        self.doc_country = doc_country
        self.doc_expiration = doc_expiration
        self.doc_number = doc_number

        self.loyalty = kwargs.get('loyalty', None)
        self.loyalty_number = kwargs.get('loyalty_number', None)
        self.visa_number = kwargs.get('visa_number', None)
        self.visa_country = kwargs.get('visa_country', None)
        self.visa_issue_date = kwargs.get('visa_issue_date', None)
        self.visa_issue_place = kwargs.get('visa_issue_place', None)
        self.residence_live_country = kwargs.get('residence_live_country', None)
        self.residence_country = kwargs.get('residence_country', None)
        self.residence_state = kwargs.get('residence_state', None)
        self.residence_city = kwargs.get('residence_city', None)
        self.residence_address = kwargs.get('residence_address', None)
        self.residence_postal_code = kwargs.get('residence_postal_code', None)
        self.special_services = kwargs.get('special_services', [])

        self._validate()

    def _validate(self):
        msg = WRONG_PARAM_MSG.format('special_services', '[SpecialService(), ...]')
        if self.special_services and not isinstance(self.special_services, list):
            raise ParametersError(msg)

        for ss in self.special_services:
            if not isinstance(ss, SpecialService):
                raise ParametersError(msg)

        if self.doc_type not in DOC_TYPES:
            raise ParametersError(u'Not a valid type parameter pax_type, expected in ["PASSPORT", "OTHER"]')

        _validate_date(self.doc_expiration)
        _validate_date(self.birthdate)

    def to_json(self):
        result = {
            'pax_type': self.pax_type,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'patronymic': self.patronymic,
            'birthdate': self.birthdate,
            'sex': self.sex,
            'nationality': self.nationality,
            'doc_type': self.doc_type,
            'doc_country': self.doc_country,
            'doc_expiration': self.doc_expiration,
            'doc_number': self.doc_number,
            'loyalty': self.loyalty,
            'loyalty_number': self.loyalty_number,
            'special_services': [ss.to_json() for ss in self.special_services]
        }

        if self.visa_number:
            result['visa_number'] = self.visa_number

        if self.visa_number:
            result['visa_country'] = self.visa_country

        if self.visa_number:
            result['visa_issue_date'] = self.visa_issue_date

        if self.visa_number:
            result['visa_issue_place'] = self.visa_issue_place

        if self.residence_live_country:
            result['residence_live_country'] = self.residence_live_country

        if self.residence_country:
            result['residence_country'] = self.residence_country

        if self.residence_state:
            result['residence_state'] = self.residence_state

        if self.residence_city:
            result['residence_city'] = self.residence_city

        if self.residence_address:
            result['residence_address'] = self.residence_address

        if self.residence_postal_code:
            result['residence_postal_code'] = self.residence_postal_code

        return result


class BookParams(object):

    def __init__(self, email, email_lang, phone, country, passengers, segments, lang, **kwargs):
        self.email = email  # Адрес электронной почты получателя билетов
        self.email_lang = email_lang  # Язык получателя билетов. Список языков на данный момент полностью не определен. Перечень будет расширен
        self.phone = phone  # Телефон получателя билетов
        self.country = country  # Двух-буквенный код страны. Допустимое значение из общего справочника стран
        self.passengers = passengers  # Список пассажиров
        self.segments = segments  # Список рейсов, составляющих маршрут
        self.lang = lang  # Двухбуквенный код языка. Перечень языков на данный момент полностью не определен. Перечень будет расширен.

        self.currency = kwargs.get('currency', None)  # Код валюты в формате ISO 4217. Допустимое значение из общего справочника валют
        self.passenger_fare_bases = kwargs.get('passenger_fare_bases', [])
        self.coupons = kwargs.get('coupons', [])
        self.referrer = kwargs.get('referrer', None)
        self.custom_remarks = kwargs.get('custom_remarks', [])
        self.points = kwargs.get('points', None)
        self.extra = kwargs.get('extra', {})
        self.client = kwargs.get('client', None)

        self._validate()

    def _validate(self):
        msg = WRONG_PARAM_MSG.format('passengers', '[Passenger(), ...]')
        if not isinstance(self.passengers, list):
            raise ParametersError(msg)
        for p in self.passengers:
            if not isinstance(p, Passenger):
                raise ParametersError(msg)

        if self.client and not isinstance(self.client, ClientInformation):
            raise ParametersError(WRONG_PARAM_MSG.format('client', 'ClientInformation'))

        msg = WRONG_PARAM_MSG.format('segments', '[Flight(), ...]')
        if not isinstance(self.segments, list):
            raise ParametersError(msg)
        for s in self.segments:
            if not isinstance(s, Flight):
                raise ParametersError(msg)

        msg = WRONG_PARAM_MSG.format('passenger_fare_bases', '[Tariff(), ...]')
        if not isinstance(self.passenger_fare_bases, list):
            raise ParametersError(msg)
        for pfb in self.passenger_fare_bases:
            if not isinstance(pfb, Tariff):
                raise ParametersError(msg)

    def to_json(self):
        return {
            'email': self.email,
            'email_lang': self.email_lang,
            'phone': self.phone,
            'country': self.country,
            'passengers': [p.to_json() for p in self.passengers],
            'segments': [s._asdict() for s in self.segments],
            'lang': self.lang,
            'custom_remarks': self.custom_remarks,
            'client': self.client.to_json() if self.client else None,
            'currency': self.currency,
            'passenger_fare_bases': [pfb.to_json() for pfb in self.passenger_fare_bases],
            'coupons': self.coupons,
            'referrer': self.referrer,
            'points': self.points,
            'extra': self.extra
        }


class RequestSearchParams(object):

    def __init__(self, routes, cabin, adults, min_price, country='RU',
                 currency='RUB', lang='ru', client=None,
                 coupons=None, children=0, infants=0, youth=0,
                 referrer='', award=False, max_results=None, partner_name=None, routes_for_filter=None):
        self.routes = routes
        self.cabin = cabin
        self.country = country
        self.currency = currency
        self.lang = lang

        self.client = client
        self.coupons = coupons

        self.adults = adults
        self.children = children
        self.infants = infants
        self.youth = youth

        self.referrer = referrer
        self.award = award
        self.max_results = max_results
        self.partner_name = partner_name
        self.min_price = min_price
        self.routes_for_filter = routes_for_filter
        self._validate()

    def _validate_routes(self):
        msg = u'Routers mast be a list: [Route(), ...]'
        if not isinstance(self.routes, list):
            raise ParametersError(msg)
        for r in self.routes:
            if not isinstance(r, Route):
                raise ParametersError(msg)

    def _validate_persons(self):
        """в данных о пассажирах должен быть указан хотя бы один пассажир;
           число младенцев не может превышать число взрослых;
           пассажиры типа «Молодежь» не могут комбинироваться с другими типами пассажиров;
           поиск за мили не может содержать пассажиров типа «Молодежь» и «Младенец»;
        """
        msg_errors = []
        if self.adults + self.children + self.youth == 0:
            msg_errors.append(u'Count of passengers should be more 0.')
        if self.adults < self.infants:
            msg_errors.append(u'The Count of infants can not exceed the number of adults.')
        not_youth = self.adults + self.children + self.infants
        if bool(self.youth) == bool(not_youth):
            msg_errors.append(u'Passengers of the "Youth" type can not be combined with other types of passengers.')
        if self.award and (self.youth or self.infants):
            msg_errors.append(u'Search for miles can not contain passengers like "Youth" and "Infants".')

        if msg_errors:
            raise ParametersError('; '.join(msg_errors))

    def _validate_client(self):
        if self.client and not isinstance(self.routes, ClientInformation):
            raise ParametersError(u'Customer information should be of ClientInformation')

    def _validate(self):
        self._validate_routes()
        self._validate_persons()
        self._validate_client()
        if self.cabin not in ['econom', 'comfort', 'business']:
            raise ParametersError(u'The class of service can be only: econom, comfort, business')

    def to_json(self):
        result = {
            'routes': [r.to_json() for r in self.routes],
            'cabin': self.cabin,
            'adults': self.adults,
            'country': self.country,
            'currency': self.currency,
            'lang': self.lang,
            'coupons': self.coupons,
            'children': self.children,
            'infants': self.infants,
            'youth': self.youth,
            'referrer': self.referrer,
            'award': self.award,
            'client': self.client.to_json() if self.client else None
        }
        return result


class PriceParameters(object):

    def __init__(self, country, segments, lang, currency=None, adults=None, children=None, infants=None, youth=None,
                 passenger_fare_bases=None, client=None, coupons=None, extra=None, referrer=None):
        self.country = country
        self.segments = segments
        self.lang = lang
        self.currency = currency
        self.adults = adults or 0
        self.children = children or 0
        self.infants = infants or 0
        self.youth = youth or 0
        self.passenger_fare_bases = passenger_fare_bases
        self.client = client
        self.coupons = coupons or []
        self.extra = extra or {}
        self.referrer = referrer
        self._validate()

    def _segments_validate(self):
        msg = WRONG_PARAM_MSG.format('segments', '[Flight(), ...]')
        if not isinstance(self.segments, list):
            raise ParametersError(msg)
        for s in self.segments:
            if not isinstance(s, Flight):
                raise ParametersError(msg)

    def _passenger_fare_bases_validate(self):
        msg = WRONG_PARAM_MSG.format('passenger_fare_bases', '[Tariff(), ...]')
        if self.passenger_fare_bases:
            if not isinstance(self.passenger_fare_bases, list):
                raise ParametersError(msg)
            for fare_base in self.passenger_fare_bases:
                if not isinstance(fare_base, Tariff):
                    raise ParametersError(msg)

    def _client_validate(self):
        if self.client and not isinstance(self.client, ClientInformation):
            raise ParametersError(WRONG_PARAM_MSG.format('client', 'ClientInformation'))

    def _validate(self):
        self._segments_validate()
        self._passenger_fare_bases_validate()
        self._client_validate()

    def to_json(self):
        return {
            'country': self.country,
            'currency': self.currency,
            'adults': self.adults,
            'children': self.children,
            'infants': self.infants,
            'youth': self.youth,
            'segments': [s._asdict() for s in self.segments],
            'passenger_fare_bases': [t.to_json() for t in self.passenger_fare_bases] if self.passenger_fare_bases else None,
            'client': self.client.to_json() if self.client else None,
            'coupons': self.coupons,
            'extra': self.extra,
            'lang': self.lang,
            'referrer': self.referrer
        }


class Order(object):
    def __init__(self, order_id, pnr_locator, status, cost, currency, agent, agent_payment_code,
                 passengers, time_limit, tickets, exchange_type, additional_params):
        self.order_id = order_id
        self.pnr_locator = pnr_locator
        self.status = status
        self.cost = cost
        self.currency = currency
        self.agent = agent
        self.agent_payment_code = agent_payment_code
        self.passengers = passengers
        self.time_limit = time_limit
        self.exchange_type = exchange_type
        self.tickets = tickets
        self.additional_params = additional_params

    def get_ticket_state(self):
        return u'Выпущены' if self.status in (PAID_TICKETS_ISSUED, PAID_IN_EXTERNAL_SYSTEM) else u'Не выпущены'

    def get_action_name(self):
        if self.status != NOT_PAID:
            return

        if self.exchange_type is None:
            if self.agent:
                return u'Изменить способ оплаты'
            return u'Оплатить'

        if self.exchange_type == 'REFUND':
            return u'Завершить возврат'

        if self.exchange_type in ('EXCHANGE_COLLECT', 'EXCHANGE_REFUND', 'EXCHANGE_EVEN'):
            return u'Завершить обмен'

    def is_paid(self):
        return self.status in (PAID_TICKETS_ISSUED, PAID_TICKETS_NOT_ISSUED, PAID_IN_EXTERNAL_SYSTEM)

    def get_order_state(self):
        return ORDER_STATES.get(self.status, NOT_PAID)

    def get_message_type(self):
        if self.status == NOT_PAID:
            if self.agent is not None:
                return 'AGENT'
        elif self.status == PAID_TICKETS_ISSUED:
            if self.exchange_type in ('EXCHANGE_COLLECT', 'EXCHANGE_REFUND', 'EXCHANGE_EVEN'):
                return 'EXCHANGE'
            if self.exchange_type == 'REFUND':
                return 'REFUND'
            if self.agent is not None:
                return 'AGENT'
            return 'OK'
        elif self.status == PAID_TICKETS_NOT_ISSUED:
            return 'PAYMENT'

    def get_email_type(self):
        # явно перечисляем типы обмена
        if self.status == PAID_TICKETS_ISSUED:
            if self.exchange_type is None or self.exchange_type in ('EXCHANGE_COLLECT', 'EXCHANGE_EVEN'):
                return OrderEmailType.PAYMENT

        if self.status == NOT_PAID and (self.agent is not None or self.has_guaranteed_price()):
            return OrderEmailType.BOOKING

    def has_guaranteed_price(self):
        u"""Наличие гарантированной цены."""
        return 'garantPrice' in self.additional_params

    @classmethod
    def from_orderinforesponse(cls, r):
        assert isinstance(r, OrderInfoResponse)

        return cls(r.order_id,
                   r.pnr_locator,
                   r.status,
                   r.cost,
                   r.currency,
                   r.agent,
                   r.agent_payment_code,
                   r.passengers,
                   r.time_limit,
                   r.tickets,
                   r.exchange_type,
                   r.additional_params)
