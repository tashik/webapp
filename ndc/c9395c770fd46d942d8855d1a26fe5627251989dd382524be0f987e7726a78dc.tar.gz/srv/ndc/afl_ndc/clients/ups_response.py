# -*- coding: utf-8 -*-


from lxml import etree

from datetime import datetime, tzinfo, timedelta
from uuid import UUID

from clients.constants import (ORDER_STATUS, PAID_IN_EXTERNAL_SYSTEM,
                               CANT_BE_PAID, NSMAP)
from clients.exc import (UPSWSParseResponseException, OrderNotFoundError,
                         UPSWSException)
from i18n import _


class UPSWSResponse(object):
    success = '0'
    code_critical_errors = None
    critical_errors = None
    error_code_xpath = None

    @property
    def code_critical_errors(self):
        raise NotImplementedError('Implement code_critical_errors as well')

    @property
    def critical_errors(self):
        raise NotImplementedError('Implement critical_errors as well')

    @property
    def error_code_xpath(self):
        raise NotImplementedError('Implement error_code_xpath as well')

    def __init__(self, text):
        self._data = text
        self.errorCode = 0
        self.errors = []
        self.xml = self._parse(text)

    def _parse(self, doc):
        if isinstance(doc, basestring):
            try:
                doc = etree.XML(doc).getroottree()
            except etree.XMLSyntaxError:
                raise UPSWSParseResponseException(doc)

        elem = doc.getroot()
        body = elem.xpath("/soapenv:Envelope/soapenv:Body", namespaces=NSMAP)
        if not body:
            raise UPSWSParseResponseException(doc)
        body = body[0]

        self.errorCode = self._parse_error_code(body)
        if self.errorCode != self.success:
            self.errors = self._parse_errors(body)

        return body

    def _parse_errors(self, elem):
        return []

    def _get_error_code(self, elem):
        error_code = elem.xpath(self.error_code_xpath, namespaces=NSMAP)
        if not len(error_code):
            raise UPSWSParseResponseException('errCode not found')
        return error_code[0].text

    def _parse_error_code(self, elem):
        error_code = self._get_error_code(elem)

        if error_code == self.success:
            return error_code

        raise UPSWSException(
            error_code=error_code,
            error_message=self.critical_errors.get(error_code, None) or error_code,
            response=elem)

    def __str__(self):
        return etree.tostring(self.xml, pretty_print=True)

    def __repr__(self):
        return etree.tostring(self.xml, pretty_print=True)


class OrderInfoResponse(UPSWSResponse):
    error_code_xpath = "//return/errorCode"

    critical_errors = {
        '1': _(u'Временная ошибка. Повторите запрос позже'),
        '-1': _(u'Отсутствует обязательный параметр в запросе'),
        '-3': _(u'В системе нет заказа с таким идентификатором'),
        '-6': _(u'Внутренняя ошибка')
    }

    code_critical_errors = ['1', '-1', '-6']

    def __init__(self, text):
        self.status = None
        self.order_id = None
        self.pnr_locator = None
        self.cost = None
        self.currency = None
        self.agent = None
        self.agent_payment_code = None
        self.passengers = []
        self.time_limit = None
        self.tickets = []
        self.segments = []
        self.exchange_type = None
        self.additional_params = {}
#        self.iglobe_session_id = None
        super(OrderInfoResponse, self).__init__(text)

    def _parse_errors(self, elem):
        errors = []
        if self.errorCode != self.success:
            errors.append(self.critical_errors[self.errorCode])
        return errors

    def _parse(self, doc):
        body = super(OrderInfoResponse, self)._parse(doc)
        if self.errors:
            if self.errorCode == '-3':
                raise OrderNotFoundError()
            return body

        self._parse_basic(body)
        self._parse_itinerary(body)

        return body

    def _parse_basic(self, body):
        status = body.xpath("//return/status")
        if len(status) < 1:
            raise UPSWSParseResponseException('status not found')
        status = unicode(status[0].text)
        if status not in ORDER_STATUS:
            raise UPSWSParseResponseException('unknown order status: %s' % status)
        self.status = status

        order_id = body.xpath("//return/orderId")
        if not len(order_id):
            self.order_id = None
        else:
            order_id = unicode(order_id[0].text)
            self.order_id = UUID(order_id)

        currency = body.xpath("//return/currency")
        if len(currency) < 1:
            if status == PAID_IN_EXTERNAL_SYSTEM or status == CANT_BE_PAID:
                self.currency = None
            else:
                raise UPSWSParseResponseException('currency code not found')
        else:
            self.currency = unicode(currency[0].text)

        amount = body.xpath("//return/amount")
        if len(amount) < 1:
            amount = '0'
        else:
            amount = str(amount[0].text)

        self.cost = amount

        agent = body.xpath("//return/agent")
        if len(agent) > 0:
            agent = agent[0]
            if 'name' in agent.attrib:
                name = agent.attrib['name']
            else:
                name = agent.xpath('./name')
                if len(name) < 1:
                    raise UPSWSParseResponseException('agent name not found')
                name = name[0].text
            self.agent = unicode(name)

        a_params = body.xpath("//return/additionalParam")
        for param in a_params:
            name = param.findtext('name')
            value = param.findtext('value')

            self.additional_params.update({name: value})

            if name and value and name == 'numericPNR' and self.agent_payment_code is None:
                self.agent_payment_code = value

        time_limit = body.xpath("//return/expirationDate")
        if len(time_limit) > 0:
            time_limit = time_limit[0].text
            tz_offset = time_limit[-6:]
            try:
                self.time_limit = datetime.strptime(time_limit[:-6], '%Y-%m-%dT%H:%M:%S')
            except ValueError:
                self.time_limit = datetime.strptime(time_limit[:-6], '%Y-%m-%dT%H:%M:%S.%f')

            i = -1 if tz_offset[0] == '-' else 1
            h = i * int(tz_offset[1:3])
            m = i * int(tz_offset[4:6])

            class TZ(tzinfo):
                def utcoffset(self, dt): return timedelta(hours=h, minutes=m)

                def dst(self, date_time): return timedelta(0)

            self.time_limit = self.time_limit.replace(tzinfo=TZ())

    def _parse_itinerary(self, body):
        itinerary = body.xpath("//return/itinerary")
        itinerary = itinerary[0]
        pnr = itinerary.attrib['reservationNumber']
        self.pnr_locator = unicode(pnr)

        exchange_type = itinerary.xpath('exchangeType')
        if len(exchange_type) > 0:
            self.exchange_type = exchange_type[0].text

        for pax in itinerary.xpath('passenger'):
            if 'firstName' not in pax.attrib or 'lastName' not in pax.attrib:
                continue
            self.passengers.append((pax.attrib['firstName'], pax.attrib['lastName'], pax.attrib.get('type', 'ADT')))

        for ticket in itinerary.xpath('ticket'):
            if 'number' not in ticket.attrib:
                continue
            self.tickets.append([ticket.attrib['number']])

    def __str__(self):
        return "%s %s %s %s %s" % (self.status,
                                   self.order_id,
                                   self.pnr_locator,
                                   self.cost,
                                   self.agent,)
