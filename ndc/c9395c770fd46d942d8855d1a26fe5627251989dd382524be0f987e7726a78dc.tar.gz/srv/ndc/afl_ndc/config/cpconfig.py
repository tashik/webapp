# -*- coding: utf-8 -*-

"""CherryPy Global Configuration."""

import config

# CherryPy Global Configuration ------------------------------------------------

global_cfg = {
    'tools.decode.on': True,
    'tools.encode.on': True,
    'tools.encode.encoding': config.ENCODING,
    'tools.decode.encoding': config.ENCODING,
    'tools.status.on': True,
    'tools.request_timer.on': True,  # Фиксация длительности формирования ответа на запрос (отметки в access.log)
    'log.screen': True,  # Use 'False' for production mode
    'server.socket_port': config.SERVER_PORT,
    'server.socket_host': config.SERVER_HOST,
    'server.thread_pool': 64,  # Use >0 for production mode
    'checker.check_static_paths': False,
    'engine.autoreload.on': False,
}

global_cfg.update(config.CPCONFIG_GLOBAL)
app_cfg = config.CPCONFIG_APP
