# -*- coding: utf-8 -*-

import logging
import os
import socket
import datetime

socket.setdefaulttimeout(60)

ENCODING = 'utf-8'

DEFAULT_NDC_VERSION = '16.2'

DEBUG = True
LOG_LEVEL = logging.DEBUG
LOG_SETTINGS = {}
PROPAGATE_LOG = True  # Дублировать лог на экран/stdout
ADD_ERROR_TEXT_TO_RESPONSE = True

APPDIR = os.path.abspath(os.path.dirname(__file__) + '/..')
LOGDIR = os.path.join(APPDIR, 'log')
ERRORDIR = os.path.join(LOGDIR, 'errors')  # Путь к папке с логами ошибок
SB_LOGDIR = os.path.join(LOGDIR, 'sb_response')
SCHEMASDIR = os.path.join(APPDIR, 'data', 'schemas')
MAPPINGSDIR = os.path.join(APPDIR, 'data', 'mappings')
TMPDIR = os.path.join(APPDIR, 'tmp')
DATADIR = os.path.join(APPDIR, 'data', 'xml')
PIDDIR = os.path.join(APPDIR, 'pid')
VOCABS_CACHE_DIR = os.path.join(APPDIR, 'cache')

SERVER_HOST = '127.0.0.1'
SERVER_PORT = 6380
SERVER_NAME = 'NDC server'
VIRTUAL_BASE = '/ndc'

DEFAULT_LANGUAGE_CODE = 'en'
LANGUAGES = ['RU', 'EN', 'DE', 'ES', 'FR', 'IT', 'ZH', 'JA', 'KO']
LOCALE_DIR = os.path.join(APPDIR, 'locales')

SB_SERVICE_HOST = None
SB_SERVICE_URL = 'https://%s/sb/booking/api/app/' % SB_SERVICE_HOST
SB_SERVICE_DOMAIN = SB_SERVICE_HOST
SB_SERVICE_DIGEST_URL = 'https://%s/sb/booking/api/device/' % SB_SERVICE_HOST
SB_APP_URL = 'https://%s/sb/app' % SB_SERVICE_HOST
# Настройки системы информации о заказе
ORDWS_SOAP_BASE_URL = 'https://test.paymentgate.ru/testaeroflot/webservices/orderInfo-ws'
ORDWS_SOAP_USER = 'ramax-api'
ORDWS_SOAP_PWD = 'ramax-api'

CONNECTION_TIMEOUT = datetime.timedelta(seconds=50)
CONNECTION_REPEAT = 2

SYS_NAME_SB = 'sb'
SYS_NAME_EPR = 'epr'
SYS_NAME_PMB = 'pmb'

SUB_SERVICES = ()

# Использовать сервис ПМБ booking вместо сервиса SB pnr
USE_PMB_BOOKING_SERVICE = False

SUPPORTED_SERVICES = ['services.afl.AirShoppingService', 'services.afl.FlightPriceService', 'services.afl.OrderCreateService']
AIR_SHOPPING_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'AirShoppingRQ.csv')
ORDER_CREATE_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'OrderCreateRQ.csv')
FLIGHT_PRICE_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'FlightPriceRQ.csv')

SB_ERRORS_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'sb_errors.csv')
AGENT_ID_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'agent_id.csv')
AIRLINE_ID_MAPPING_FILE = os.path.join(VOCABS_CACHE_DIR, 'Airline.xml')
USER_AGENT_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'app_type.csv')
TARIFF_GROUPS_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'cms-tarif-groups.csv')

NDC_DIGEST_ENABLED = False
NDC_DIGEST = None
NDC_DIGEST_IP = ['127.0.0.1']

# Валидация входящего запроса сервиса по XSD схеме
ENABLE_XSD_VALIDATION = True

AIRSHOPPING_AIRLINE_WHITELIST = [
    'SU',
]

AIRSHOPPING_AIRLINE_BLACKLIST = []

# Макс. число тарифов при комбинации ответа SB search
SEARCH_MAX_COMBINED_PRICES = 100000

# Минимальное время между прямым и обратным рейсами. Значение берется из админки SB
MIN_FORWARD_TO_RETURN_TIME = datetime.timedelta(minutes=60)  # Между прилетом рейса "туда" и вылетом рейса "обратно" должно быть не менее 1-го часа


# Хэши для доступа к веб-сервисам мониторинга - история ретро, ошибки, и т.д.
# Для вычисления хэша используем команду: print hashlib.md5('LOGIN:aeroflot-digest:PASSWORD').hexdigest()
MONITORING_WS_DIGEST = {}

REQUEST_TIMEOUT = 120  # sec

CPCONFIG_GLOBAL = {}
CPCONFIG_APP = {
    'tools.reject_stale_requests.on': True,
    'tools.log_rand_before_error.on': True,
    'tools.gzip.on': True,
    'tools.gzip.mime_types': ['text/*', 'application/*'],
}

AIRLINE_CODE = 'SU'
ACCOUNTING_CODE = '555'
PNR_LEN_FOR_ORDER_ID = 8

EMPTY_DOC_IN_RESPONSE = ['OrderViewRS']

DEFAULT_APP_TYPE = 'NON'
DEFAULT_AGENT_ID = 'NN'

NDC_REMARK = 'N'

FARE_BASE_BOOKING_CLASSES = {'E': ['R', 'Y', 'B', 'M', 'U', 'K', 'H', 'L', 'Q', 'T', 'E', 'N'],
                             'C': ['W', 'S', 'A'],
                             'B': ['J', 'C', 'D', 'I', 'Z']}

OTHER_FARE_BASE = 'M'

PMB_SKIP_SYMBOLS = ["-", "'"]

PMB_URL = 'https://m.aeroflot.ru/b'
RETURN_PRICES_PER_TYPEGROUP = False

# PBUS
PBUS_ENABLED = False
PBUS_URL = 'http://127.0.0.1:8390'
PBUS_MY_NAME = 'ndc'
PBUS_PASSWORD = ''
PBUS_CALLBACK_HOST = '127.0.0.1'
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_CALLBACK_PASSWORD = ''
PBUS_TOPICS = {
    'vocabs': 'vocabs'
}
PBUS_VOCAB_RECIPIENTS = {
    'vocabs': 'vocabs'
}

SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER = False
SKIP_STATISTICS_URLS = ['/ndc/services/ping', '/ndc/services/ping_diag', '/ndc/services/status']

SERVICES_VERSION_NDC_VERSION = {
    '1.0': '16.2'
}
