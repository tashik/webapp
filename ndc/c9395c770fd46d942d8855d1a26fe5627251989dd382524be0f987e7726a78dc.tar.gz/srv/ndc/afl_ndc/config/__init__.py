# -*- coding: utf-8 -*-

import os
import imp

from defaults import *
# execfile нужен для выполнения частей конфига в общем неймспейсе
# без execfile получаются круговые записимости между конфигами
execfile(os.path.dirname(__file__) + '/local.py')

try:
    __config_test = imp.find_module('_test_config')
    execfile(__config_test[1])
except ImportError:
    pass

execfile(APPDIR + '/config/cluster.py')

# Некоторые переменные являются обязательными для переопределения.
__errors = []
for __n, __v in globals().items():
    if __v is NotImplemented:
        __errors.append(__n)

if __errors:
    raise NameError(__errors)
