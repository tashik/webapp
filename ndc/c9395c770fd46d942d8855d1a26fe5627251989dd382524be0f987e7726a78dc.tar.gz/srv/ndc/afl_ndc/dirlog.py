# -*- coding: utf-8 -*-
# Копипаст pyramid/ui/error/dirlog.py с изменениями
import logging
import os.path
import pprint
import time
import traceback
import cherrypy
import threading
from datetime import datetime
from Cookie import SimpleCookie

from exc import NDCError

import config

last_t = datetime.min
uniq = 0
write_lock = threading.Lock()


def escape_cdata(s):
    return s.replace(']]>', ']]]]><![CDATA[>')


def escape_attr(data):
    return data.replace('&', '&amp;').replace('>', '&gt;').replace('<', '&lt;').replace('"', '&quot;')


def escape_summary(s):
    return s.replace('\t', '\\t').replace('\r', '\\r').replace('\n', '\\n')


def dump_section(f, tag, text):
    print >> f, '<%s>\n<![CDATA[' % tag
    for line in escape_cdata(text).split('\n'):
        print >> f, '   ', repr(line).encode('utf-8')
    print >> f, ']]>\n</%s>\n\n' % tag


def exception_as_str(fn):
    def decorator(*args, **kw):
        try:
            return fn(*args, **kw)
        except Exception, e:
            logging.exception('Exception in %s' % fn.__name__)
            return '{%s}' % e.__class__.__name__
        except:
            logging.exception('Exception in %s' % fn.__name__)
            return '{SEE_ERROR_LOG}'
    return decorator


@exception_as_str
def get_remote_ip():
    return cherrypy.request.remote.ip


@exception_as_str
def get_path_info():
    return cherrypy.request.path_info


def format_ext_message(message):
    if not message:
        return ""
    if hasattr(message, 'msgid'):
        return unicode(message.msgid)

    return unicode(str(message).decode('UTF-8'))


def log(exc, tb, t=None):
    """ Записать исключение в лог
        Параметры:
        exc - исключение
        tb - traceback
        t - время (объект типа datetime.datetime)
    """
    ERRORDIR = getattr(config, 'ERRORDIR', None)
    if not ERRORDIR:
        return

    if t is None:
        t = datetime.now()
    exc_type_name = type(exc).__name__
    if isinstance(exc, NDCError):
        message = exc.description
    else:
        message = exc.message
    message = format_ext_message(message)
    filename = _get_filename(exc_type_name, t)
    bucket = t.strftime('%Y-%m-%d')
    bucket_path = os.path.join(config.ERRORDIR, bucket)
    _make_bucket_dir(bucket_path)
    details_path = os.path.join(bucket_path, filename)
    index_path = os.path.join(bucket_path, 'index.tsv')
    relative_path = os.path.join(bucket, filename)

    tb_s = '\n'.join(traceback.format_exception(type(exc), exc, tb))

    try:
        exc_repr = repr(exc).decode('raw_unicode_escape')
    except UnicodeDecodeError:
        exc_repr = repr(exc)

    details = [('traceback', tb_s),
               ('repr', exc_repr)]
    details += cherrypy_debug_data()

    if not message:
        message = ""

    summary = [
        ('id', filename),
        ('message', message.replace('\t', ' ')),
        ('remote_ip', get_remote_ip()),
        ('path_info', get_path_info()),
    ]

    with open(details_path, 'w+') as f:
        _write_details(f, details, relative_path, exc, message)

    with write_lock:
        with open(index_path, 'a') as f:
            _write_summary(f, summary, [])

    return relative_path


def _write_details(f, details, event_id, exc, message):
    print >> f, '<details id="%s">\n' % event_id
    print >> f, '<exception type    = "%s"' % escape_attr(type(exc).__name__)
    print >> f, '           message = "%s"' % escape_attr(message.encode('utf-8'))
    for name in dir(exc):
        if not name.startswith('_') and name not in ('args', 'msg', 'message', 'type', 'description'):
            value = getattr(exc, name)
            if value in (None, [], ()):
                continue
            if isinstance(value, str):
                value = unicode(value, errors='replace')
            elif not isinstance(value, (basestring, int, float)):
                value = repr(value).decode('raw_unicode_escape')
            else:
                value = repr(value).decode('utf-8')
            print >> f, '           %-8s= "%s"' % (name, escape_attr(unicode(value.encode('utf-8'))))
            print >> f, '/>\n'

    for name, d in details:
        if not isinstance(d, basestring):
            d = pretty_print(d).decode('raw_unicode_escape')
        dump_section(f, name.replace('.', '_'), d)

    print >> f, '</details>'


def _write_summary(f, summary, extra):
    f.seek(0, 2)
    if f.tell() == 0:  # выводим заголовок
        print >> f, '\t'.join([escape_summary(elem[0]) for elem in summary])
    extra_parts = [('', '%s=%s' % (name, value)) for name, value in extra]
    print >> f, '\t'.join([escape_summary(elem[1].encode('utf-8')) for elem in (summary + extra_parts)])


def _make_bucket_dir(path):
    if not os.path.exists(path):
        try:
            os.mkdir(path)
        except OSError:
            pass


def _get_filename(exc_type_name, t):
    global last_t, uniq
    t = t.replace(microsecond=0)
    if t > last_t:
        last_t = t
        uniq = 0
        uniq_s = ''
    else:
        uniq += 1
        uniq_s = '.%s' % uniq
    hms = t.strftime('%H%M%S')
    filename = '%s%s-%s' % (hms, uniq_s, exc_type_name)
    return filename


def cherrypy_debug_data():
    def selectAttrs(ob, *attrs):
        return dict([(a, getattr(ob, a)) for a in attrs])

    data = [
        ('request', selectAttrs(cherrypy.request, 'base', 'method', 'query_string', 'path_info', 'headers', 'params')),
        ('request.request_xml_body', getattr(cherrypy.request, 'request_xml_body', None)),
        ('request.tracking_id', getattr(cherrypy.request, 'tracking_id', None)),
        ('request.remote', selectAttrs(cherrypy.request.remote, 'ip', 'port')),
        ('response', selectAttrs(cherrypy.response, 'cookie', 'headers')),
        ('session', getattr(cherrypy, 'session', None)),
        ('build_time', time.time() - cherrypy.response.time),
    ]

    return data


def pretty_print(data, html=False):
    d = clean_val(data)
    pp = pprint.PrettyPrinter(indent=1, width=80, depth=8)
    text = pp.pformat(d)

    if html:
        text = xml_quote(text).replace('\n', '<br />\n')

    return text

LITERAL_TYPES = (int, float, basestring, bool, SimpleCookie)
CONTAINER_TYPES = (tuple, list, set)


def clean_val(v):
    if v is None:
        return v
    if isinstance(v, LITERAL_TYPES):
        return v
    if isinstance(v, CONTAINER_TYPES):
        return [clean_val(elem) for elem in v]
    if hasattr(v, 'items'):
        # print type(v)
        return clean_dict(v)
    return repr(v)


def clean_dict(data):
    d = {}
    d.update(data)
    for k, v in d.items():
        if 'passw' in str(k):
            d[k] = '**********'
        else:
            d[k] = clean_val(v)

    return d


def __dict_replace(s, d):
    """Replace substrings of a string using a dictionary."""
    for key, value in d.items():
        s = s.replace(key, value)
    return s


def xml_quote(data, entities=None):
    """Escape &, <, and > in a string of data.

    You can escape other strings of data by passing a dictionary as
    the optional entities parameter.  The keys and values must all be
    strings; each key will be replaced with its corresponding value.
    """
    if data is None:
        return None

    # must do ampersand first
    data = data.replace("&", "&amp;")
    data = data.replace(">", "&gt;")
    data = data.replace("<", "&lt;")
    data = data.replace("\"", "&quot;")
    data = data.replace("\r\n", "&#10;")
    data = data.replace("\r", "&#10;")
    data = data.replace("\n", "&#10;")
    if entities:
        data = __dict_replace(data, entities)
    return data
