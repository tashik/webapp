#!/bin/sh
python ws.py