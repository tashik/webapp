# -*- coding: utf-8 -*-
import os
import uuid
import json

def get_xml_paths(aDir):
    return (os.path.join(aDir,f) for f in os.listdir(aDir) if '.xml' in f.lower())

def main():
    xml_files = get_xml_paths(cur_dir)
    items = []
    items.append (
        {
            "id": "52b9e0f5-d6fd-d84d-ff62-551ded4aa7c6",
            "headers": "Content-Type: application/x-www-form-urlencoded\n",
            "url": "https://pay.test.aeroflot.ru/test-rc/aeropayment/api/paymentToken?pan=4111111111111111&expDate=201912&cvc=123&cardholderName=test%20testov",
            "preRequestScript": None,
            "pathVariables": {},
            "method": "POST",
            "data": [],
            "dataMode": "raw",
            "version": 2,
            "tests": "\nvar jsonData = JSON.parse(responseBody);\nvar token = jsonData.token\npostman.setGlobalVariable('token', token);\n",
            "currentHelper": "normal",
            "helperAttributes": {},
            "time": 1495214181508,
            "name": "AOC Сервис токенизации Аэрофлота (публичный TEST)",
            "description": "",
            "collectionId": "62034572-9097-d6a5-133e-a673fbc5d056",
            "responses": [],
            "isFromCollection": True,
            "collectionRequestId": "dc5863f7-ade7-3add-2bc9-9628cd8479d3",
            "rawModeData": ""
        }
    )
    for aFile in xml_files:
        try:
            f = open(aFile)
            lines = f.readlines()
            #
            item = {
            "id": str(uuid.uuid4()),
            "headers": "Content-Type: application/xml\nX-IBM-Client-Id: fd4d0e3c-dc5c-41f5-bc3e-9f5076fd4835\n",
            "url": "https://gw.aeroflot.io/ndc/sb/v1.0/ep",
            "preRequestScript": None,
            "pathVariables": {},
            "method": "POST",
            "data": [],
            "dataMode": "raw",
            "version": 2,
            "tests": None,
            "currentHelper": "normal",
            "helperAttributes": {},
            "time": 1495800283461,
            "name": os.path.basename(aFile)[:-4],
            "description": "",
            "collectionId": "62034572-9097-d6a5-133e-a673fbc5d056",
            "responses": [],
            "rawModeData": ''.join(lines)
            }
            items.append(item)
        finally:
            f.close()
    #
    result = {
        "id": "62034572-9097-d6a5-133e-a673fbc5d056",
        "name": "NDC-Ramax",
        "description": "",
        "order": [item["id"] for item in items],
        "folders": [],
        "timestamp": 1495799862030,
        "owner": "1705275",
        "public": False,
        "requests": items
    }
    with open(output_filename, "w") as fp:
        json.dump(result,fp,indent=4,sort_keys=True,ensure_ascii = False)


u"""Формирует POSTMAN коллекцию запросо по списку XML-файлов."""

if __name__ == "__main__":
    cur_dir = os.path.abspath('../soapui')
    output_filename = os.path.join(cur_dir,'NDC-Ramax.postman_collection.json')

    main()

