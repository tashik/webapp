# -*- coding: utf-8 -*-
"""CherryPy dispatcher settings and mount configuration."""


import cherrypy
import config
from access import auth_paths
from services.ndc import NDCService
from notify import NotifyService

# Конфигурация диспетчеров и параметры CherryPy --------------------------------


def _getMountConfig(main_dispatcher_factory):
    u"""Создает конфигурацию для монтирования"""

    mount_cfg = dict()

    # Для основного диспетчера -------------------------------------------------
    mount_cfg.update({
        '/': {
            'request.dispatch': main_dispatcher_factory(),
            'tools.sessions.on': False,
        }
    })

    # Для виртуального диспетчера ----------------------------------------------
    if config.VIRTUAL_BASE:
        mount_cfg.update({
            config.VIRTUAL_BASE: {
                'request.dispatch': main_dispatcher_factory(
                    prefix=config.VIRTUAL_BASE),
                'tools.proxy.on': True,
            }
        })

    return mount_cfg


def _getMainDispatcher(prefix=None):
    u"""Создает диспетчер, регистрирует маршруты и контроллеры."""
    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.mapper.prefix = prefix
    dispatcher.mapper.minimization = True
    dispatcher.mapper.explicit = False

    NotifyService()._connectToDispatcher(dispatcher)
    NDCService()._connectToDispatcher(dispatcher)

    from services.heartbeat import HeartbeatService
    HeartbeatService()._connectToDispatcher(dispatcher)

    return dispatcher


# Конфигурация диспетчеров и локальные параметры CherryPy ---------------------

mount_cfg = _getMountConfig(_getMainDispatcher)
mount_cfg.update(auth_paths())
