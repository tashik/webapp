# -*- coding: utf-8 -*-

"""
:$
"""

import config
from exc import NDCException
from fares import FARES
from .mapping import CSVFileMappingReader


class FareRules(object):
    def __init__(self, fares_by_group, urls_mapping_filename):
        super(FareRules, self).__init__()
        self.group2group_info = fares_by_group.copy()
        self.prefix2fare_info = {}
        self.urls_by_group = self.parse_urls_mapping(urls_mapping_filename)

        for group, info in self.group2group_info.iteritems():
            for rule in info['fare_bases_rules']:
                rule['_group'] = group
                for prefix in rule['fare_base_prefix']:
                    # assert prefix not in self.prefix2fare_info, \
                    #     'duplicate prefix %s' % prefix
                    self.prefix2fare_info[prefix] = rule

    def get(self, group=None, fare=None, lang=''):
        founded_rules = []
        if group is not None and fare is not None:
            group_info = self.group2group_info.get(group)
            if group_info is None:
                raise NDCException('No such fare rules for group "%s"' % group)

            for rule_info in group_info['fare_bases_rules']:
                max_len_prefix = max([len(rule) for rule in rule_info['fare_base_prefix']])
                if fare[:max_len_prefix] in rule_info['fare_base_prefix']:
                    founded_rules = [rule_info]

        elif fare is not None:
            rule_info = self.prefix2fare_info.get(fare)
            if rule_info is None:
                raise NDCException('No such fare rules for fare "%s"' % fare)
            founded_rules = [rule_info]

        elif group is not None:
            group_info = self.group2group_info.get(group)
            if group_info is None:
                raise NDCException('No such fare rules for group "%s"' % group)
            founded_rules = group_info['fare_bases_rules']

        if not founded_rules:
            return None

        founded_group = founded_rules[0]['_group']
        group_info = self.group2group_info[founded_group].copy()
        group_info.pop('fare_bases_rules')
        res = group_info
        res['fare_bases_rules'] = founded_rules

        urls_info = self.urls_by_group.get(founded_group)
        if urls_info is not None:
            res['fare_base_rules_url'] = urls_info['fare_base_rules_url'].format(lang=lang)
            res['upsale_url'] = urls_info['upsale_url'].format(lang=lang)
        res['fare_rule_name'] = founded_group

        return res

    def parse_urls_mapping(self, filename):
        urls_by_group = {}
        items = CSVFileMappingReader(filename).get_mapping()
        for item in items:
            urls_by_group[item['group']] = item
        return urls_by_group


FareRulesMapping = FareRules(FARES, config.TARIFF_GROUPS_MAPPING_FILE)
