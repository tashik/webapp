# -*- coding: utf-8 -*-

class MapperParseError(ValueError):
    """ Base CSVParseError """


class UndefinedParentError(MapperParseError):
    """ Undfined parent error"""


class UnknownTypeError(MapperParseError):
    """ UnknownTypeError """
