# -*- coding: utf-8 -*-
from datetime import datetime, timedelta
import re


def parse_sb_date(date_str):
    if not date_str:
        return None
    return datetime.strptime(date_str, '%Y-%m-%d').date()


def parse_sb_datetime(datetime_str, minutes_offset=None):
    dt = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M')
    if minutes_offset is not None:
        dt += timedelta(minutes=minutes_offset)
    return dt


def format_sb_date(date_obj):
    return date_obj.isoformat()


def parse_ndc_date(date_str):
    if not date_str:
        return None
    return datetime.strptime(date_str, '%Y-%m-%d').date()

def parse_ndc_refs(refs_str):
    if not refs_str:
        return None
    return refs_str.split(' ')

def format_ndc_date(date_obj):
    return date_obj.isoformat()


def format_ndc_time(time_obj):
    return time_obj.strftime('%H:%M')


def from_ndc_to_timedelta(ndc_timedelta):
    if not ndc_timedelta:
        return timedelta(seconds=0)

    re_ndc_timedelta = re.compile(u'P(\d+)*D?T([\d]{2})H([\d]{2})M')
    a = re.match(re_ndc_timedelta, ndc_timedelta)
    if not a:
        return timedelta(seconds=0)
    days = a.groups()[0] or 0
    hours = a.groups()[1] or 0
    minutes = a.groups()[2] or 0
    return timedelta(days=int(days), hours=int(hours), minutes=int(minutes))

def format_ndc_timedelta(timedelta_obj):
    total_seconds = timedelta_obj.total_seconds()
    total_minutes, seconds = divmod(total_seconds, 60)
    total_hours, minutes = divmod(total_minutes, 60)
    days, hours = divmod(total_hours, 24)
    days, hours, minutes = map(int, (days, hours, minutes))
    seconds = round(seconds, 6)

    bits = ['P']
    if days:
        bits.append('{}D'.format(days))

    bits.append('T')
    if days or hours:
        bits.append('{:02}H'.format(hours))
    if days or hours or minutes:
        bits.append('{:02}M'.format(minutes))
    if seconds:
        if seconds.is_integer():
            seconds = '{:02}'.format(int(seconds))
        else:
            # 9 chars long w/leading 0, 6 digits after decimal
            seconds = '%09.6f' % seconds
        seconds = seconds.rstrip('0')  # remove trailing zeros
        bits.append('{}S'.format(seconds))
    return ''.join(bits)
