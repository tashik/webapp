# -*- coding: utf-8 -*-
from exc import InvalidServiceTypeCodeError
from .constants import BaseConstantMapping, AutoReverseConstantMapping
from i18n import _

class SBPassengerTypes(object):
    ADULT = 'ADULT'
    CHILD = 'CHILD'
    INFANT = 'INFANT'
    YOUTH = 'YOUTH'

class NDCPassengerTypes(object):
    ADULT = 'ADT'
    CHILD = 'CHD'
    INFANT = 'INF'
    YOUTH = 'YOUTH' #TODO:???


class NDCDocumentTypes(object):
    PASSPORT = 'PT'
    VISA = 'VI'
    TRANSIT_VISA = 'TR'


class SBDocumentTypes(object):
    PASSPORT = 'PASSPORT'
    OTHER = 'OTHER'


class NDCGender(object):
    MALE = 'Male'
    FEMALE = 'Female'


class SBGender(object):
    MALE = 'M'
    FEMALE = 'F'


class NDCCabinTypes(object):
    FIRST_CLASS = '1'
    BUSINESS = '2'
    ECONOM = '3'
    COMFORT = '4'
    cabin_types = (FIRST_CLASS, BUSINESS, ECONOM, COMFORT)

    descriptions = {
        BUSINESS:
            'Second class, Medium class of service (Business Class Category)',
        ECONOM:
            'Third class, lowest class of service '
            '(all economy/coach class categories)',
        COMFORT: 'Economy/coach premium',
    }

    @classmethod
    def get_description(cls, cabin):
        return cls.descriptions[cabin]


class SBCabinTypes(object):
    BUSINESS = 'business'
    ECONOM = 'econom'
    COMFORT = 'comfort'


class SB2NDCCabinTypeMap(BaseConstantMapping):
    mapping = {
        SBCabinTypes.BUSINESS: NDCCabinTypes.BUSINESS,
        SBCabinTypes.ECONOM: NDCCabinTypes.ECONOM,
        SBCabinTypes.COMFORT: NDCCabinTypes.COMFORT,
    }


class NDC2SBCabinTypeMap(AutoReverseConstantMapping):
    source = SB2NDCCabinTypeMap

    @classmethod
    def map(cls, val):
        if val not in cls.reverse_mapping:
            raise InvalidServiceTypeCodeError()
        return super(NDC2SBCabinTypeMap, cls).map(val)


class NDC2SBPassengerTypes(BaseConstantMapping):
    mapping = {
        NDCPassengerTypes.ADULT: SBPassengerTypes.ADULT,
        NDCPassengerTypes.CHILD: SBPassengerTypes.CHILD,
        NDCPassengerTypes.INFANT: SBPassengerTypes.INFANT,
        NDCPassengerTypes.YOUTH: SBPassengerTypes.YOUTH,
    }

class SB2NDCPassengerTypes(AutoReverseConstantMapping):
    source = NDC2SBPassengerTypes

class NDC2SBDocumentTypes(BaseConstantMapping):
    mapping = {
        NDCDocumentTypes.PASSPORT: SBDocumentTypes.PASSPORT,
        NDCDocumentTypes.VISA: SBDocumentTypes.OTHER,
        NDCDocumentTypes.TRANSIT_VISA: SBDocumentTypes.OTHER,
    }


class SB2NDCDocumentTypes(AutoReverseConstantMapping):
    source = NDC2SBDocumentTypes


class NDC2SBGender(BaseConstantMapping):
    mapping = {
        NDCGender.MALE: SBGender.MALE,
        NDCGender.FEMALE: SBGender.FEMALE,
    }


class SB2NDCGender(AutoReverseConstantMapping):
    source = NDC2SBGender


class FareRulesMeasurements(BaseConstantMapping):
    mapping = {
        'kg': u'Kilogram',
        'cm': u'Centimeter'
    }