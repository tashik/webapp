# -*- coding: utf-8 -*-
import csv
from abc import abstractmethod, ABCMeta
import os
from lxml import etree
import ast

from exc import NDCError
from user_agents import parse as user_agent_parse
import config


class Mapper(object):
    mapping_reader = None
    __metaclass__ = ABCMeta

    def __init__(self, mapping_reader):
        self.mapping_reader = mapping_reader

    @abstractmethod
    def map_from_ndc(self, input_data):
        pass

    @abstractmethod
    def map_from_afl(self, input_data):
        pass


class MappingReader(object):
    __metaclass__ = ABCMeta

    @abstractmethod
    def get_mapping(self):
        pass


class XMLFileMappingReader(MappingReader):

    mapping_file_path = None

    def __init__(self, mapping_file_path):
        self.mapping_file_path = mapping_file_path

    def get_mapping(self):
        result = []
        tree = etree.parse(self.mapping_file_path)
        items = tree.xpath("//item")
        for item in items:
            child_item = {}
            for child in item.getchildren():
                child_item[child.tag] = child.text
            result.append(child_item)
        return result


class CSVFileMappingReader(MappingReader):

    mapping_file_path = None

    def __init__(self, mapping_file_path, check_xpath=False):
        self.mapping_file_path = mapping_file_path
        if check_xpath:
            with open(mapping_file_path) as f:
                content = f.readlines()
                content = [x.strip() for x in content]
                if len(content) < 2:
                    raise ValueError("Your csv file should contains more than 1 line")
        reader = csv.DictReader(open(mapping_file_path), delimiter=";")
        processed_rows = []
        for csv_row in reader:
            if 'parent' in csv_row:
                if csv_row['parent']:
                    alias_found = False
                    for row in processed_rows:
                        if row['alias'] == csv_row['parent']:
                            alias_found = True
                    if not alias_found:
                        raise ValueError("Parent must be exists alias, row: {}, file: {}".format(str(csv_row),
                                                                                                 mapping_file_path))
                else:
                    if not csv_row['xpath'].startswith("//"):
                        raise ValueError("Row without parent xpath should starts with //, row: {}, file: {}".format(
                            str(csv_row), mapping_file_path))
                processed_rows.append(csv_row)

    def get_mapping(self):
        return csv.DictReader(
            open(os.path.abspath(self.mapping_file_path)), delimiter=";"
        )


class NDCErrorMappingReader(CSVFileMappingReader):

    def get_exception(self, error_code):
        for error in self.get_mapping():
            if error['original_code'] == error_code:
                return NDCError(code=error['code'], short_text=error['short_text'])


class NDCAgentIdMappingReader(CSVFileMappingReader):

    def get_agent_code(self, original_name):
        for agent in self.get_mapping():
            if agent['original_name'].lower() == original_name.lower():
                return agent['code']
        return None


class NDCAirlineIdMappingReader(XMLFileMappingReader):

    def get_airline_name(self, code, lang):
        for airline in self.get_mapping():
            if airline['iata'].lower() == code.lower():
                names = {name.split(":")[0]: name.split(":")[1] for name in ast.literal_eval(airline['names'])}
                if lang == 'ru':
                    return names['ru'].decode('unicode-escape')
                else:
                    return names['en'].decode('UTF-8')
        return None


class NDCUserAgentMappingReader(CSVFileMappingReader):

    def get_app_type(self, user_agent_string):
        user_agent = user_agent_parse(user_agent_string)
        for app_type in self.get_mapping():
            property_path = app_type['property']
            current_property_value = user_agent
            for prop in property_path.split("."):
                current_property_value = getattr(current_property_value, prop)
            if str(current_property_value) == app_type['value']:
                return app_type['app_type']
        return config.DEFAULT_APP_TYPE