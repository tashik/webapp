# -*- coding: utf-8 -*-
import sys
from collections import namedtuple

from .exceptions import UndefinedParentError, UnknownTypeError
from .mapping import Mapper
from .utils import parse_ndc_date, parse_ndc_refs
from exc import InvalidFormatError


class Node(object):
    DEFAULT = ''
    STRING = 'str'
    UNICODE = 'unicode'
    INTEGER = 'int'
    DATE = 'date'
    LIST = 'list'

    typecast = {
        DEFAULT: str,
        STRING: str,
        UNICODE: unicode,
        INTEGER: int,
        DATE: parse_ndc_date,
        LIST: parse_ndc_refs
    }

    def get_typecast(self, csv_type):
        caster = self.typecast.get(csv_type)
        if caster is None:
            raise UnknownTypeError(csv_type)
        return caster

    def parse(self, xml_nodes):
        raise NotImplementedError()


_common_args = ['xpath', 'attr', 'type_']

_SimpleNode = namedtuple('_SimpleNode', _common_args)


class SimpleNode(Node, _SimpleNode):
    def parse(self, xml_node):
        values = xml_node.xpath(self.xpath)
        typecast = self.get_typecast(self.type_)
        if not values:
            return self.attr, None
        try:
            value = typecast(values[0])
        except UnicodeError:
            raise InvalidFormatError(ndc_internal_error_text='Wrong value for field %s' % self.xpath)
        return self.attr, value


_HierarchicalNode = namedtuple(
    '_HierarchicalNode', _common_args + ['name', 'children'])


class HierarchicalNode(Node, _HierarchicalNode):
    def parse(self, xml_node):  # -> (self.attr, [...])
        items = []
        for xnode in xml_node.xpath(self.xpath):
            res = {}
            for child in self.children:
                attr, value = child.parse(xnode)
                res[attr] = value
            items.append(res)
        return self.attr, items


class HierarchicalXPathToJsonMapper(Mapper):
    def map_from_afl(self, input_data):
        pass

    def map_from_ndc(self, xml_tree):  # -> {attr: value, ...}
        mapping = self.mapping_reader.get_mapping()
        roots = self._build_dependency_tree(mapping)
        result = {}
        for node in roots:
            attr, value = node.parse(xml_tree)
            result[attr] = value
        return result

    def _build_dependency_tree(self, mapping):
        roots, hierarchical_nodes, deferred_nodes = self._build_nodes(mapping)
        # resolve deferred_nodes
        for deferred_node in deferred_nodes:
            parent_node = hierarchical_nodes.get(deferred_node.parent)
            if not parent_node:
                raise UndefinedParentError(deferred_node.parent)
            parent_node.children.append(deferred_node)
        return roots

    def _build_nodes(self, mapping):
        roots = []
        hierarchical_nodes = {}
        # ноды, описание которых задано перед описанием parent
        deferred_nodes = []
        fieldnames = mapping.fieldnames
        assert isinstance(fieldnames, (list, tuple))
        Row = namedtuple('_CSVRow', fieldnames)
        for row_dict in mapping:
            row = Row(**row_dict)
            common_attrs = [row.xpath, row.attr, row.type_]
            alias = row.alias  # check .type_  == 'dicts' ?
            if alias:
                node = HierarchicalNode(*(common_attrs + [alias, []]))
                hierarchical_nodes[alias] = node
            else:
                node = SimpleNode(*common_attrs)
            parent = row.parent
            if parent:
                parent_node = hierarchical_nodes.get(parent)
                if parent_node is not None:
                    assert isinstance(parent_node, HierarchicalNode)
                    parent_node.children.append(node)
                else:
                    deferred_nodes.append(node)
            else:
                roots.append(node)

        return roots, hierarchical_nodes, deferred_nodes
