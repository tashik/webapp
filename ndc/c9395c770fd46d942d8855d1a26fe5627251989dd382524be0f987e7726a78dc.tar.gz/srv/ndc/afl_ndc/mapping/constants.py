# -*- coding: utf-8 -*-

class BaseConstantMapping(object):
    mapping = NotImplemented

    @classmethod
    def map(cls, val):
        return cls.mapping[val]


class AutoReverseConstantMappingMeta(type):
    def __init__(cls, name, bases, attrs):
        source_cls = attrs.get('source')
        if source_cls and source_cls is not NotImplemented:
            cls.reverse_mapping = {
                v: k for k, v in source_cls.mapping.iteritems()}
        type.__init__(cls, name, bases, attrs)


class AutoReverseConstantMapping(BaseConstantMapping):
    __metaclass__ = AutoReverseConstantMappingMeta

    source = NotImplemented  # type: BaseConstantMapping

    @classmethod
    def map(cls, val):
        return cls.reverse_mapping[val]
