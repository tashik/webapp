# -*- coding: utf-8 -*-

import unittest

import mock
import testoob
from clients.models import RequestSearchParams

from services.response.airshopping import AirShoppingRS
from urlparse import urlparse

_sb_rs_test_data = {
    'interline': True,
    'ways': [
        [
            {
                '__id': 'way1',
                "segments": [
                    {"airline_code": "white1"},
                    {"airline_code": "black1"},
                    {"airline_code": "white2"},
                    {"airline_code": "code4"},
                ],
            },
            {
                '__id': 'way2',
                "segments": [
                    {"airline_code": "white1"},
                    {"airline_code": "white2"},
                    {"airline_code": "white1"},
                ],
            },
            {
                '__id': 'way3',
                "segments": [
                    {"airline_code": "black1"},
                    {"airline_code": "black1"},
                    {"airline_code": "black2"},
                ],
            },
        ]
    ]
}


class TestAirShoppingRS(unittest.TestCase):
    def setUp(self):
        super(TestAirShoppingRS, self).setUp()
        self.response = AirShoppingRS((None, _sb_rs_test_data))

    @mock.patch('services.response.airshopping.AIRSHOPPING_AIRLINE_WHITELIST', ['white1', 'white2'])
    @mock.patch('services.response.airshopping.AIRSHOPPING_AIRLINE_BLACKLIST', [])
    def test_get_way_items_white_list(self):
        way_items = self.response._get_way_items()
        self.assertEqual(len(way_items), 1)
        self.assertEqual(way_items[0]['__id'], 'way2')

    @mock.patch('services.response.airshopping.AIRSHOPPING_AIRLINE_WHITELIST', [])
    @mock.patch('services.response.airshopping.AIRSHOPPING_AIRLINE_BLACKLIST', ['black1', 'black2'])
    def test_get_way_items_black_list(self):
        way_items = self.response._get_way_items()
        self.assertEqual(len(way_items), 1)
        self.assertEqual(way_items[0]['__id'], 'way2')

    def test_build_deeplink_for_one_segment(self):
        rq_data_search_rs = [
            RequestSearchParams(
                [], 'econom', 2,
                min_price='false',
                children=2,
                infants=0,
                country='US',
                lang='EN',
                partner_name='SKYSCANNER'
            ), {}
        ]

        segments = [{
            'origin': {
                'airport_code': 'LED',
            },
            'departure': '2017-10-10 22:44',
            'destination': {
                'airport_code': 'VKO',
            },
            'airline_code': 'SU',
            'flight_number': '1241',
            'marriage_group': '',
        }]

        tariff = {
            'booking_classes': ['econom'],
            'pax_prices': {
                'ADULT': {
                    'fare_bases': 'NVOR'
                }
            }
        }

        response = AirShoppingRS(rq_data_search_rs)
        result = urlparse(response._make_offer_deep_link(segments, tariff))
        self.assertEqual(result.path + "#" + result.fragment,
                         '/sb/app/us-en#/passengers?adults=2&children=2&infants=0&segments=LED20171010VKO.SU1241.econom.N.N&referrer=SKYSCANNER')

    def test_build_deeplink_without_interline(self):
        rq_data_search_rs = [
            RequestSearchParams(
                [], 'econom', 2,
                min_price='false',
                children=1,
                infants=1,
                country='US',
                lang='EN',
                partner_name='SKYSCANNER'
            ), {}
        ]

        segments = [{
            'origin': {
                'airport_code': 'LED',
            },
            'departure': '2017-10-10 22:44',
            'destination': {
                'airport_code': 'VKO',
            },
            'airline_code': 'SU',
            'flight_number': '1241',
            'marriage_group': '',
        },
            {
                'origin': {
                    'airport_code': 'SVO',
                },
                'departure': '2017-11-11 10:22',
                'destination': {
                    'airport_code': 'LED',
                },
                'airline_code': 'SU',
                'flight_number': '1243',
                'marriage_group': '',
            }
        ]

        tariff = {
            'booking_classes': ['B', 'N'],
            'pax_prices': {
                'ADULT': {
                    'fare_bases': ['BFO', 'NFOR']
                }
            }
        }

        response = AirShoppingRS(rq_data_search_rs)
        result = urlparse(response._make_offer_deep_link(segments, tariff))
        self.assertEqual(result.path + "#" + result.fragment,
                         '/sb/app/us-en#/passengers?adults=2&children=1&infants=1&segments=LED20171010VKO.SU1241.B.BFO.N-SVO20171111LED.SU1243.N.NFOR.N&referrer=SKYSCANNER')

    def test_build_deeplink_with_interline(self):
        rq_data_search_rs = [
            RequestSearchParams(
                [], 'econom', 2,
                min_price='false',
                children=1,
                infants=1,
                country='US',
                lang='EN',
                partner_name='SKYSCANNER'
            ), {}
        ]

        segments = [{
            'origin': {
                'airport_code': 'LED',
            },
            'departure': '2017-10-10 22:44',
            'destination': {
                'airport_code': 'VKO',
            },
            'airline_code': 'SU',
            'flight_number': '1241',
            'marriage_group': '',
        },
            {
                'origin': {
                    'airport_code': 'SVO',
                },
                'departure': '2017-11-11 10:22',
                'destination': {
                    'airport_code': 'LED',
                },
                'airline_code': 'SU',
                'flight_number': '1243',
                'marriage_group': 'I',
            },
            {
                'origin': {
                    'airport_code': 'LED',
                },
                'departure': '2017-11-12 01:23',
                'destination': {
                    'airport_code': 'VVO',
                },
                'airline_code': 'SU',
                'flight_number': '1255',
                'marriage_group': '',
            }
        ]

        tariff = {
            'booking_classes': ['B', 'N', 'N'],
            'pax_prices': {
                'ADULT': {
                    'fare_bases': ['BFO', 'NFOR', 'NVOR']
                }
            }
        }

        response = AirShoppingRS(rq_data_search_rs)
        result = urlparse(response._make_offer_deep_link(segments, tariff))
        self.assertEqual(result.path + "#" + result.fragment,
                         '/sb/app/us-en#/passengers?adults=2&children=1&infants=1&segments=LED20171010VKO.SU1241.B.BFO.N_SVO20171111LED.SU1243.N.NFOR.I-LED20171112VVO.SU1255.N.NVOR.N&referrer=SKYSCANNER')


if __name__ == '__main__':
    testoob.main()
