# -*- coding: utf-8 -*-


_ = lambda s: s


FARES = {
    'econom-budget': {
        'classes': {'E', 'N', 'Q', 'T'},
        'brands': {'ES'},
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['QVU', 'QVO', 'TVU', 'TVO', 'EVU', 'EVO', 'NVU', 'NVO'],
                'miles_percent_text': _(u'75 %'),
                'exchange_text': _(u'с доплатой'),
                'refund_text': _(u'запрещен'),
                'luggage_text': _(u'1 место'),
                'miles_upgrade_text': _(u'недоступен'),
                'choose_seat_text': _(u'недоступен'),
                '_weight': 120
            },
        ],
        'combinations': {'ES'}
    },
    'LE-HE-KE-UE-ME': {
        'classes': {'H', 'K', 'L', 'M', 'U'},
        'brands': {'LE', 'HE', 'KE', 'UE', 'ME'},
        'fare_bases_rules': [
            {
                'fare_base_prefix': {'H', 'K', 'L', 'U'},
                'miles_percent_text': _(u'150 %'),
                'exchange_text': _(u'с доплатой'),
                'refund_text': _(u'с доплатой'),
                'luggage_text': _(u'1 место'),
                'miles_upgrade_text': _(u'доступен'),
                'choose_seat_text': _(u'бесплатно'),
                '_weight': 251
            },
            {
                'fare_base_prefix': {'M'},
                'miles_percent_text': _(u'150 %'),
                'exchange_text': _(u'бесплатно'),
                'refund_text': _(u'с доплатой'),
                'luggage_text': _(u'1 место'),
                'miles_upgrade_text': _(u'доступен'),
                'choose_seat_text': _(u'бесплатно'),
                '_weight': 252
            },
        ],
        'combinations': {'NE', 'EE'}
    },
}
