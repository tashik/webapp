# -*- coding: utf-8 -*-
from collections import OrderedDict
import unittest
import testoob
from clients.models import (Route, RelatedSegments, Tariff, ExchangeSegments,
                            SpecialServiceParams, SpecialService,
                            SpecialServiceAttrs, Passenger, BookParams,
                            Flight, RequestSearchParams)
from clients.exc import ParametersError


class TestModels(unittest.TestCase):

    def test_route(self):
        route = Route('MOW', 'LED', '2017-04-20')
        self.assertEqual(route.origin, 'MOW')
        self.assertEqual(route.destination, 'LED')
        self.assertEqual(route.departure, '2017-04-20')

    def test_route_json(self):
        route = Route('MOW', 'LED', '2017-04-20')
        self.assertEqual(route.to_json(), {
            'departure': '2017-04-20', 'destination': 'LED', 'origin': 'MOW',
            'related_segments': []
        })

        segments = [
            RelatedSegments(**{
                'airline_code': 'SU', 'booking_class': 'Y',
                'flight_number': '1718', 'departure': '2016-11-19T18:00:00',
                'destination': 'SVO', 'origin': 'NOZ',
                'original_airline_code': 'SU', 'status': 'HK',
                'inbound_connection': False}),
            RelatedSegments(**{
                'airline_code': 'SU', 'booking_class': 'Y',
                'flight_number': '22', 'departure': '2016-11-19T21:30:00',
                'destination': 'LED', 'origin': 'SVO',
                'original_airline_code': 'SU', 'status': 'HK',
                'inbound_connection': True})
        ]

        route = Route('MOW', 'LED', '2017-04-20', segments)
        self.assertEqual(route.to_json(), {
            'origin': 'MOW', 'destination': 'LED', 'departure': '2017-04-20',
            'related_segments': [
                {'origin': 'NOZ', 'status': 'HK',
                 'original_airline_code': 'SU',
                 'inbound_connection': False, 'fare_group_name': None,
                 'destination': 'SVO', 'departure': '2016-11-19T18:00:00',
                 'booking_class': 'Y', 'flight_number': '1718',
                 'airline_code': 'SU'},
                {'origin': 'SVO', 'status': 'HK',
                 'original_airline_code': 'SU', 'inbound_connection': True,
                 'fare_group_name': None, 'destination': 'LED',
                 'departure': '2016-11-19T21:30:00', 'booking_class': 'Y',
                 'flight_number': '22', 'airline_code': 'SU'
                 }
            ]
        })

    def test_route_validate(self):
        with self.assertRaises(ParametersError):
            Route('MOW', 'LED', '2017')

        with self.assertRaises(ParametersError):
            Route('MOW', 'LED', '2017-04-20', 'related_segments')

        with self.assertRaises(ParametersError):
            Route('MOW', 'LED', '2017-04-20', ['related_segments'])

    def test_tariff(self):
        tariff = Tariff('ADULT', ['AAAA'])
        self.assertEqual(tariff.fare_bases, ['AAAA'])

    def test_tariff_validate(self):
        with self.assertRaises(ParametersError):
            Tariff('ADULT', 'AAAA')

        with self.assertRaises(ParametersError):
            Tariff('ADU', ['AAAA'])

    def test_exchange_segments(self):
        es = ExchangeSegments(
            '1',
            RelatedSegments(**{
                'airline_code': 'SU', 'booking_class': 'Y',
                'flight_number': '22', 'departure': '2016-11-19T21:30:00',
                'destination': 'LED', 'origin': 'SVO',
                'original_airline_code': 'SU', 'status': 'HK',
                'inbound_connection': True})
        )
        self.assertEqual(es.id, '1')
        self.assertEqual(
            es.segment.to_json(),
            OrderedDict(
                [('airline_code', 'SU'), ('booking_class', 'Y'),
                 ('flight_number', '22'), ('departure', '2016-11-19T21:30:00'),
                 ('destination', 'LED'), ('origin', 'SVO'),
                 ('original_airline_code', 'SU'), ('status', 'HK'),
                 ('inbound_connection', True), ('fare_group_name', None)]
            )
        )

    def test_exchange_segments_validate(self):
        with self.assertRaises(ParametersError):
            ExchangeSegments('1', ['aaaa'])

    def test_special_service_params(self):
        ssp = SpecialServiceParams('AAA', [])
        self.assertEqual(
            ssp.to_json(),
            {'ss_param_code': 'AAA', 'ss_param_attrs': []}
        )

        ssp = SpecialServiceParams('AAA', [SpecialServiceAttrs('CODE', 'VAL')])
        self.assertEqual(
            ssp.to_json(),
            {'ss_param_attrs': [{'ss_code': 'CODE', 'ss_value': 'VAL'}],
             'ss_param_code': 'AAA'}
        )

    def test_special_service_params_validate(self):
        with self.assertRaises(ParametersError):
            SpecialServiceParams('AAA', 'SpecialServiceAttrs')

        with self.assertRaises(ParametersError):
            SpecialServiceParams('AAA', ['SpecialServiceAttrs'])

    def test_special_service(self):
        ss = SpecialService('IATA', [])
        self.assertEqual(
            ss.to_json(),
            {'special_service_code': 'IATA', 'special_service_params': []}
        )

        ss = SpecialService('IATA', [SpecialServiceParams('AAA', [])])
        self.assertEqual(
            ss.to_json(),
            {'special_service_code': 'IATA',
             'special_service_params': [
                 {'ss_param_code': 'AAA', 'ss_param_attrs': []}
             ]}
        )

        ss = SpecialService(
            'IATA',
            [SpecialServiceParams('AAA', [SpecialServiceAttrs('CODE', 'VAL')])]
        )
        self.assertEqual(
            ss.to_json(),
            {'special_service_code': 'IATA',
             'special_service_params': [
                 {'ss_param_code': 'AAA', 'ss_param_attrs': [
                     {'ss_value': 'VAL', 'ss_code': 'CODE'}
                 ]}
             ]})

    def test_special_service_validate(self):
        with self.assertRaises(ParametersError):
            SpecialService('IATA', ['asdasd'])

        with self.assertRaises(ParametersError):
            SpecialService('IATA', 'asdasd')

    def test_passenger(self):
        passenger = Passenger(
            pax_type='ADULT', first_name='PaxFirstName',
            patronymic='PaxPatronymic', last_name='PasLastName',
            birthdate='1977-05-23', sex='M', nationality='RU',
            doc_type='PASSPORT', doc_country='RU', doc_expiration='2023-06-12',
            doc_number='2222111111', special_services=[]
        )
        self.assertEqual(passenger.to_json(), {
            'last_name': 'PasLastName', 'doc_number': '2222111111',
            'loyalty': None, 'sex': 'M', 'pax_type': 'ADULT',
            'patronymic': 'PaxPatronymic', 'nationality': 'RU',
            'doc_expiration': '2023-06-12', 'doc_type': 'PASSPORT',
            'first_name': 'PaxFirstName', 'loyalty_number': None,
            'birthdate': '1977-05-23', 'doc_country': 'RU',
            'special_services': []
        })

    def test_passenger_validate(self):
        pass_attr = {'pax_type': 'ADULT', 'first_name': 'PaxFirstName',
                     'patronymic': 'PaxPatronymic', 'last_name': 'PasLastName',
                     'birthdate': 'asdasdasd', 'sex': 'M', 'nationality': 'RU',
                     'doc_type': 'PASSPORT', 'doc_country': 'RU',
                     'doc_expiration': '2023-06-12',
                     'doc_number': '2222111111', 'special_services': []}

        with self.assertRaises(ParametersError):
            Passenger(**pass_attr)

        pass_attr['birthdate'] = '1977-05-23'
        pass_attr['doc_expiration'] = 'asdasdasd'

        with self.assertRaises(ParametersError):
            Passenger(**pass_attr)

        pass_attr['birthdate'] = '1977-05-23'
        pass_attr['doc_expiration'] = '2023-06-12'
        pass_attr['special_services'] = 'asdasdasd'

        with self.assertRaises(ParametersError):
            Passenger(**pass_attr)

        pass_attr['special_services'] = ['asdasdasd']

        with self.assertRaises(ParametersError):
            Passenger(**pass_attr)

    def test_book_params(self):
        passengers = [
            Passenger(**{
                'pax_type': 'ADULT', 'first_name': 'PaxFirstName',
                'patronymic': 'PaxPatronymic', 'last_name': 'PasLastName',
                'birthdate': '1977-05-23', 'sex': 'M', 'nationality': 'RU',
                'doc_type': 'PASSPORT', 'doc_country': 'RU',
                'doc_expiration': '2023-06-12', 'doc_number': '2222111111',
                'special_services': []})
        ]

        book = BookParams(**{
            'email': 'TEST@TEST.COM', 'email_lang': 'RU', 'phone': '9991111',
            'passengers': passengers,
            'passenger_fare_bases': [
                Tariff(**{'pax_type': 'ADULT', 'fare_bases': ['QI']})
            ],
            'segments': [
                Flight(**{'airline_code': 'SU', 'booking_class': 'H',
                          'brand': 'PC', 'departure': '2017-04-06',
                          'destination': 'JFK', 'origin': 'SVO',
                          'marriage_group': 'I', 'flight_number': 100})
            ],
            'custom_remarks': ['CUSTOM REMARK 1', 'CUSTOM REMARK 2'],
            'lang': 'ru', 'country': 'RU'
        })

        self.assertEqual(book.to_json(), {
            'custom_remarks': ['CUSTOM REMARK 1', 'CUSTOM REMARK 2'],
            'extra': {}, 'phone': '9991111', 'coupons': [],
            'points': None, 'lang': 'ru',
            'passengers': [{
                'last_name': 'PasLastName', 'doc_number': '2222111111',
                'loyalty': None, 'sex': 'M', 'pax_type': 'ADULT',
                'patronymic': 'PaxPatronymic', 'nationality': 'RU',
                'doc_expiration': '2023-06-12', 'doc_type': 'PASSPORT',
                'first_name': 'PaxFirstName', 'loyalty_number': None,
                'birthdate': '1977-05-23', 'doc_country': 'RU',
                'special_services': []
            }],
            'currency': None, 'country': 'RU',
            'segments': [
                OrderedDict([('airline_code', 'SU'), ('flight_number', 100),
                             ('booking_class', 'H'),
                             ('departure', '2017-04-06'),
                             ('destination', 'JFK'), ('origin', 'SVO'),
                             ('marriage_group', 'I'), ('brand', 'PC')])
            ],
            'email_lang': 'RU',
            'passenger_fare_bases': [
                {'fare_bases': ['QI'], 'pax_type': 'ADULT'}
            ],
            'client': None, 'referrer': None, 'email': 'TEST@TEST.COM'})

    def test_book_params_validate(self):

        passengers = [
            Passenger(**{
                'pax_type': 'ADULT', 'first_name': 'PaxFirstName',
                'patronymic': 'PaxPatronymic', 'last_name': 'PasLastName',
                'birthdate': '1977-05-23', 'sex': 'M', 'nationality': 'RU',
                'doc_type': 'PASSPORT', 'doc_country': 'RU',
                'doc_expiration': '2023-06-12', 'doc_number': '2222111111',
                'special_services': []})
        ]

        book_params = {
            'email': 'TEST@TEST.COM', 'email_lang': 'RU', 'phone': '9991111',
            'passengers': passengers,
            'passenger_fare_bases': [
                Tariff(**{'pax_type': 'ADULT', 'fare_bases': ['QI']})
            ],
            'segments': [
                Flight(**{'airline_code': 'SU', 'booking_class': 'H',
                          'brand': 'PC', 'departure': '2017-04-06',
                          'destination': 'JFK', 'origin': 'SVO',
                          'marriage_group': 'I', 'flight_number': 100})
            ],
            'custom_remarks': ['CUSTOM REMARK 1', 'CUSTOM REMARK 2'],
            'lang': 'ru', 'country': 'RU'}

        with self.assertRaises(ParametersError):
            book_params['passengers'] = 'passengers'
            BookParams(**book_params)

        with self.assertRaises(ParametersError):
            book_params['passengers'] = ['passengers']
            BookParams(**book_params)

        with self.assertRaises(ParametersError):
            book_params['passengers'] = [passengers]
            book_params['client'] = ['passengers']
            BookParams(**book_params)

        with self.assertRaises(ParametersError):
            book_params['client'] = 'passengers'
            BookParams(**book_params)

        book_params['client'] = []

        with self.assertRaises(ParametersError):
            book_params['segments'] = 'segments'
            BookParams(**book_params)

        with self.assertRaises(ParametersError):
            book_params['segments'] = ['segments']
            BookParams(**book_params)

        book_params['segments'] = []

        with self.assertRaises(ParametersError):
            book_params['passenger_fare_bases'] = 'passenger_fare_bases'
            BookParams(**book_params)

        with self.assertRaises(ParametersError):
            book_params['passenger_fare_bases'] = ['passenger_fare_bases']
            BookParams(**book_params)

    def test_request_search_params(self):
        rsp = RequestSearchParams(
            routes=[Route("MOW", "LED", "2017-04-20")],
            cabin='econom',
            min_price='false',
            adults=1,
        )

        self.assertEqual(
            rsp.to_json(),
            {'adults': 1, 'award': False, 'currency': 'RUB', 'infants': 0,
             'children': 0, 'coupons': None, 'lang': 'ru', 'referrer': '',
             'youth': 0, 'client': None, 'country': 'RU',
             'routes': [
                 {'origin': 'MOW', 'destination': 'LED',
                  'departure': '2017-04-20', 'related_segments': []}
             ],
             'cabin': 'econom'}
        )

    def test_request_search_params_validate(self):
        rsp_param = {
            'routes': 'routes',
            'cabin': 'econom',
            'adults': 1,
            'min_price': 'false'
        }
        routes = [Route("MOW", "LED", "2017-04-20")]

        with self.assertRaises(ParametersError):
            RequestSearchParams(**rsp_param)

        rsp_param['routes'] = routes
        with self.assertRaises(ParametersError):
            rsp_param['adults'] = 0
            RequestSearchParams(**rsp_param)

        rsp_param['adults'] = 1
        with self.assertRaises(ParametersError):
            rsp_param['infants'] = 3
            RequestSearchParams(**rsp_param)

        rsp_param['adults'] = 1
        rsp_param['infants'] = 1
        with self.assertRaises(ParametersError):
            rsp_param['youth'] = 1
            RequestSearchParams(**rsp_param)

        rsp_param['adults'] = 0
        rsp_param['infants'] = 0
        rsp_param['youth'] = 1
        with self.assertRaises(ParametersError):
            rsp_param['award'] = 1
            RequestSearchParams(**rsp_param)

        rsp_param['award'] = 0
        with self.assertRaises(ParametersError):
            rsp_param['cabin'] = 'cabin'
            RequestSearchParams(**rsp_param)

        rsp_param['cabin'] = None
        with self.assertRaises(ParametersError):
            rsp_param['client'] = 'client'
            RequestSearchParams(**rsp_param)

    def test_price_parameters(self):
        pass

if __name__ == '__main__':
    testoob.main()
