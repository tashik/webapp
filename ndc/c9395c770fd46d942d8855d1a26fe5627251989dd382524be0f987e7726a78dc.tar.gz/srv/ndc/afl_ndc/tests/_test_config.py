# -*- coding: utf-8 -*-
import os.path

LOGDIR = os.path.join(APPDIR, 'tests', 'log')
TMPDIR = os.path.join(APPDIR, 'tests', 'tmp')
DATADIR = os.path.join(APPDIR, 'tests', 'data', 'xml')
MAPPINGSDIR = os.path.join(APPDIR, 'tests', 'data')
CACHEDIR = os.path.join(APPDIR, 'tests', 'cache')
TARIFF_GROUPS_MAPPING_FILE = os.path.join(APPDIR, 'tests', 'data', 'cms-tarif-groups.csv')
AIR_SHOPPING_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'AirShoppingRQ.csv')
ORDER_CREATE_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'OrderCreateRQ.csv')
FLIGHT_PRICE_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'FlightPriceRQ.csv')

SB_ERRORS_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'sb_errors.csv')
AGENT_ID_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'agent_id.csv')
AIRLINE_ID_MAPPING_FILE = os.path.join(CACHEDIR, 'Airline.xml')
USER_AGENT_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'app_type.csv')
TARIFF_GROUPS_MAPPING_FILE = os.path.join(MAPPINGSDIR, 'cms-tarif-groups.csv')

SB_SERVICE_HOST = 'afl-dev.test.aeroflot.ru'

NDC_DIGEST_ENABLED = False
ENABLE_XSD_VALIDATION = True

USE_PMB_BOOKING_SERVICE = True