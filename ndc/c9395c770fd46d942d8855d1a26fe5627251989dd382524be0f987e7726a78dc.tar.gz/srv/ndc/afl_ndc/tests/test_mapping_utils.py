# -*- coding: utf-8 -*-
from datetime import timedelta
import os
import unittest
import testoob
from mapping.utils import from_ndc_to_timedelta


class TestMappingUtils(unittest.TestCase):

    def test_from_ndc_to_timedelta(self):
        ndc_format_timedelta = 'P14DT17H20M'
        timedelta_obj = from_ndc_to_timedelta(ndc_format_timedelta)
        self.assertEqual(timedelta_obj, timedelta(days=14, hours=17, minutes=20))

        ndc_format_timedelta = 'PT01H15M'
        timedelta_obj = from_ndc_to_timedelta(ndc_format_timedelta)
        self.assertEqual(timedelta_obj, timedelta(hours=1, minutes=15))

        ndc_format_timedelta = 'PT'
        timedelta_obj = from_ndc_to_timedelta(ndc_format_timedelta)
        self.assertEqual(timedelta_obj, timedelta(seconds=0))

        ndc_format_timedelta = None
        timedelta_obj = from_ndc_to_timedelta(ndc_format_timedelta)
        self.assertEqual(timedelta_obj, timedelta(seconds=0))

if __name__ == '__main__':
    testoob.main()
