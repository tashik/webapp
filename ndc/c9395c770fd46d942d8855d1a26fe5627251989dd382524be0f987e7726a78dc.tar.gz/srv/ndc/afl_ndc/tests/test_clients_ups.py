# -*- coding: utf-8 -*-

import unittest

import testoob
import requests
from mock import patch

from clients.ups import UPSService

from clients.exc import UPSWSResponseException
from config import ORDWS_SOAP_BASE_URL


class TestUPSService(unittest.TestCase):
    def setUp(self):
        super(TestUPSService, self).setUp()
        self.service = UPSService(ORDWS_SOAP_BASE_URL)

    @patch('clients.ups.LOGGER')
    @patch('clients.ups.request')
    def test_logger(self, mock_request, mock_logging):
        r = requests.Response()
        mock_request.return_value = r
        with self.assertRaises(UPSWSResponseException):
            self.service.get_order_info_by_id('asd', 'RU')
        self.assertTrue(mock_logging.error.called)

    def test_all_wrappers_exists(self):
        for name in self.service.names_urls:
            self.assertTrue(name in dir(self.service))

    def test_check_params(self):
        with self.assertRaises(AssertionError):
            self.service.get_order_info_by_id(1, 'RU')


if __name__ == '__main__':
    testoob.main()
