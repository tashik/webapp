# -*- coding: utf-8 -*-

import unittest

import testoob
import os

from fare_rules_data import FARES
from mapping.fare_rules import FareRules


_ = lambda s: s


class TestFareRules(unittest.TestCase):
    def setUp(self):
        super(TestFareRules, self).setUp()
        self.mapping = FareRules(
            FARES,
            os.path.join(os.path.dirname(os.path.realpath(__file__)), 'data/cms-tarif-groups.csv'))

    def test_get_by_group(self):
        group_info = self.mapping.get(group='LE-HE-KE-UE-ME', lang='en')
        self._check_group_info(group_info, 'en')

        rules = group_info['fare_bases_rules']
        self.assertEqual(2, len(rules))

        rule0, rule1 = rules[0], rules[1]
        self._check_rule0(rule0)
        self._check_rule1(rule1)

    def test_get_by_fare(self):
        group_info = self.mapping.get(fare='K', lang='de')
        self._check_group_info(group_info, 'de')

        rules = group_info['fare_bases_rules']
        self.assertEqual(1, len(rules))

        rule0 = rules[0]
        self._check_rule0(rule0)

    def test_get_by_group_and_fare(self):
        group_info = self.mapping.get(group='LE-HE-KE-UE-ME', fare='K', lang='de')
        self._check_group_info(group_info, 'de')

        rules = group_info['fare_bases_rules']
        self.assertEqual(1, len(rules))

        rule0 = rules[0]
        self._check_rule0(rule0)

    def _check_group_info(self, group_info, lang):
        self.assertEqual(group_info['fare_base_rules_url'], '/media/%s/url41.png' % lang)
        self.assertEqual(group_info['upsale_url'], '/media/%s/url42.png' % lang)
        self.assertEqual(group_info['classes'], {'H', 'K', 'L', 'M', 'U'})
        self.assertEqual(group_info['brands'], {'LE', 'HE', 'KE', 'UE', 'ME'})

    def _check_rule0(self, rule):
        self.assertEqual(
            rule,
            {
                '_group': 'LE-HE-KE-UE-ME',
                'fare_base_prefix': {'H', 'K', 'L', 'U'},
                'miles_percent_text': u'150 %',
                'exchange_text': _(u'с доплатой'),
                'refund_text': _(u'с доплатой'),
                'luggage_text': _(u'1 место'),
                'miles_upgrade_text': _(u'доступен'),
                'choose_seat_text': _(u'бесплатно'),
                '_weight': 251
            })

    def _check_rule1(self, rule):
        self.assertEqual(
            rule,
            {
                '_group': 'LE-HE-KE-UE-ME',
                'fare_base_prefix': {'M'},
                'miles_percent_text': _(u'150 %'),
                'exchange_text': _(u'бесплатно'),
                'refund_text': _(u'с доплатой'),
                'luggage_text': _(u'1 место'),
                'miles_upgrade_text': _(u'доступен'),
                'choose_seat_text': _(u'бесплатно'),
                '_weight': 252
            })





if __name__ == '__main__':
    testoob.main()
