# -*- coding: utf-8 -*-
import json

import unittest
import datetime
from uuid import UUID
import requests

import testoob
from mock import patch, PropertyMock

from clients.models import (Route, PriceParameters, Flight, BookParams,
                            Passenger, RelatedSegments, ExchangeSegments,
                            ExchangeCost, Tariff, RequestSearchParams,
                            RequestFareRules, SegmentAdditionInfo,
                            SegmentMiles, Order)
from clients.service import ClientService
from clients.sb import SBService
from clients.ups import UPSService
from clients.exc import ServiceError, ServiceResponseError
import config


class TestService(unittest.TestCase):
    def setUp(self):
        super(TestService, self).setUp()
        self.service = ClientService()

        p = PropertyMock(return_value={})

        def _request(cls_self, **kwargs):
            response = requests.request(**kwargs)
            if response.status_code == requests.codes.ok:
                return json.loads(response.text)['data']
            else:
                raise ServiceResponseError()

        type(self.service)._request = _request

        type(self.service).names_urls = p
        type(self.service).headers = p

        self.request_params = {
            'url': '',
            'headers': {'Content-Type': 'application/json'},
            'json': {},
            'method': 'POST',
            'timeout': 5
        }

    @patch('clients.service.LOGGER')
    def test_request(self, mock_logging):
        params = self.request_params
        params['url'] = 'https://google.com'

        with self.assertRaises(ServiceResponseError):
            self.service._request(**params)

    @patch('clients.service.LOGGER')
    def test_send_request(self, mock_logging):
        params = self.request_params

        del params['timeout']

        params['url'] = 'https://some_url.ru'
        with self.assertRaises(ServiceError):
            self.service._send_request(**params)

        params = self.request_params
        params['url'] = 'https://google.com'
        with self.assertRaises(ServiceResponseError):
            self.service._send_request(**params)
        self.assertTrue(mock_logging.error.called)

    @patch('clients.service.LOGGER')
    def test_request_by_url(self, mock_logging):
        with self.assertRaises(ServiceError):
            self.service.request_by_url('https://some_url.ru')

        with self.assertRaises(ServiceResponseError):
            self.service.request_by_url('https://google.com')
        self.assertTrue(mock_logging.error.called)

        search_params = {
            "routes": [
                {
                    "origin": "MOW",
                    "destination": "LED",
                    "departure": "2016-12-31"
                }
            ],
            "cabin": "econom",
            "country": "RU",
            "currency": "RUB",
            "adults": 1,
            "lang": "ru"
        }

        with self.assertRaises(ServiceResponseError):
            self.service.request_by_url(
                config.SB_SERVICE_URL + 'search/v1', json_params=search_params
            )
        self.assertTrue(mock_logging.error.called)


class TestSBService(unittest.TestCase):
    def setUp(self):
        super(TestSBService, self).setUp()
        self.service = SBService()
        self.some_date = (datetime.datetime.today() + datetime.timedelta(days=12)).strftime('%Y-%m-%d')

    def test_search(self):
        result = self.service.search(
            RequestSearchParams(
                routes=[Route("MOW", "LED", self.some_date)],
                cabin='econom',
                adults=1)
        )
        self.assertEqual(result.keys(), ['ways', 'interline', 'days'])
        self.assertIsInstance(result['interline'], bool)
        self.assertIsInstance(result['ways'], list)
        self.assertIsInstance(result['days'], list)

    def test_search_min_prices(self):
        result = self.service.search_min_prices(
            RequestSearchParams(
                routes=[Route("MOW", "LED", self.some_date)],
                cabin='econom',
                adults=1)
        )
        self.assertEqual(result.keys(), ['interline', 'days'])
        self.assertIsInstance(result['interline'], bool)
        self.assertIsInstance(result['days'], list)

    def test_fare_rules(self):
        # TODO: тест с корректным fare_code
        with self.assertRaises(ServiceResponseError):
            self.service.fare_rules(
                RequestFareRules(
                    airline_code="SU",
                    origin="MOW",
                    destination="LED",
                    departure=self.some_date,
                    fare_code="BOWRF",
                    lang="ru")
            )

    def test_additional_info(self):
        result = self.service.additional_info([
            SegmentAdditionInfo(airport_from="ZRH", airport_to="LED", airline="SU"),
            SegmentAdditionInfo(airport_from="TLL", airport_to="LED", airline="OV")
        ])
        self.assertIsInstance(result, list)

    def test_miles(self):
        result = self.service.miles([SegmentMiles(
            airline="SU",
            airport_from="LED",
            airport_to="SVO",
            tier_level="gold",
            booking_class="D",
        )])
        self.assertEqual(result.keys(), ['segments', 'total'])

    def test_check_coupons(self):
        result = self.service.check_coupons(["DUC1UZI", "FREFUZ6"], 'ru')
        self.assertEqual(result.keys(), ['coupons'])

    def test_price(self):
        # TODO: тест с корректным тарифом

        with self.assertRaises(ServiceResponseError):
            self.service.price(PriceParameters(**{
                "country": "RU",
                "currency": "RUB",
                "adults": 1,
                "passenger_fare_bases": [Tariff("ADULT", ["BNRT"])],
                "segments": [
                    Flight(**{
                        "airline_code": "SU",
                        "booking_class": "H",
                        "brand": "PC",
                        "departure": self.some_date,
                        "destination": "JFK",
                        "origin": "SVO",
                        "marriage_group": "I",
                        "flight_number": 100
                    })
                ],
                "lang": "ru",
            }))

    def test_price_award(self):
        pass

    def test_book(self):
        # TODO: тест с корректным тарифом
        passengers = [Passenger(**{
            "pax_type": "ADULT",
            "first_name": "PaxFirstName",
            "patronymic": "PaxPatronymic",
            "last_name": "PasLastName",
            "birthdate": "1977-05-23",
            "sex": "M",
            "nationality": "RU",
            "doc_type": "PASSPORT",
            "doc_country": "RU",
            "doc_expiration": "2023-06-12",
            "doc_number": "2222111111",
            "special_services": []
        })]
        with self.assertRaises(ServiceResponseError):
            self.service.book(BookParams(**{
                "email": "TEST@TEST.COM",
                "email_lang": "RU",
                "phone": "9991111",
                "passengers": passengers,
                "passenger_fare_bases": [Tariff("ADULT", ["BNRT"])],
                "segments": [Flight(**{
                    "airline_code": "SU",
                    "booking_class": "H",
                    "brand": "PC",
                    "departure": self.some_date,
                    "destination": "JFK",
                    "origin": "SVO",
                    "marriage_group": "I",
                    "flight_number": 100
                })],
                "custom_remarks": ["CUSTOM REMARK 1", "CUSTOM REMARK 2"],
                "lang": "ru",
                "country": "RU"
            }))

    def test_pnr(self):
        pass

    def test_pnr_search(self):
        pass

    def test_seat_map(self):
        pass

    def test_choose_seat(self):
        pass

    def test_choose_meal(self):
        pass

    def test_refund(self):
        pass

    def test_exchange_search(self):
        with self.assertRaises(ServiceResponseError):
            self.service.exchange_search(**{
                "pnr_locator": "DUCUZI",
                "pnr_key": "c493dccaf7b7214402a68fd35f1263a1",
                "routes": [
                    Route(**{"departure": "2016-11-17", "destination": "NOZ",
                             "origin": "LED"}),
                    Route(**{"departure": "2016-11-19", "destination": "LED",
                             "origin": "NOZ",
                             "related_segments": [
                                 RelatedSegments(**{
                                     "airline_code": "SU",
                                     "booking_class": "Y",
                                     "flight_number": "1718",
                                     "departure": "2016-11-19T18:00:00",
                                     "destination": "SVO",
                                     "origin": "NOZ",
                                     "original_airline_code": "SU",
                                     "status": "HK",
                                     "inbound_connection": False
                                 }),
                                 RelatedSegments(**{
                                     "airline_code": "SU",
                                     "booking_class": "Y",
                                     "flight_number": "22",
                                     "departure": "2016-11-19T21:30:00",
                                     "destination": "LED",
                                     "origin": "SVO",
                                     "original_airline_code": "SU",
                                     "status": "HK",
                                     "inbound_connection": True
                                 })
                             ]})
                ],
                "brands": ["RE", "BE", "VE"]
            })

    def test_exchange(self):
        with self.assertRaises(ServiceResponseError):
            self.service.exchange(**{
                "pnr_locator": "DUCUZI",
                "pnr_key": "c493dccaf7b7214402a68fd35f1263a1",
                "cancel_segments_numbers": [1, 2],
                "new_segments": [
                    ExchangeSegments("1", RelatedSegments(**{
                        "airline_code": "SU",
                        "flight_number": "11",
                        "booking_class": "E",
                        "departure": "2016-11-17T10:30:00",
                        "destination": "SVO",
                        "origin": "LED",
                        "inbound_connection": False,
                        "original_airline_code": None,
                        "status": None
                    })),
                    ExchangeSegments("2", RelatedSegments(**{
                        "airline_code": "SU",
                        "flight_number": "1458",
                        "booking_class": "E",
                        "departure": "2016-11-17T22:30:00",
                        "destination": "NOZ",
                        "origin": "SVO",
                        "inbound_connection": False,
                        "original_airline_code": None,
                        "status": None
                    }))],
                "exchange_cost": [ExchangeCost("RUB", 2500)],
                "lang": "ru"
            })


class TestUPSService(unittest.TestCase):
    def setUp(self):
        super(TestUPSService, self).setUp()
        self.service = UPSService(config.ORDWS_SOAP_BASE_URL)

    def test_get_order_info_by_id(self):
        result = self.service.get_order_info_by_id(
            u'70d9ca58-d4c1-4228-a618-a89e86f3d297', u'RU'
        )
        self.assertIsInstance(result, Order)
        self.assertEqual(result.cost, u'4350.00')
        self.assertEqual(result.currency, u'RUB')
        self.assertEqual(result.order_id,
                         UUID('70d9ca58-d4c1-4228-a618-a89e86f3d297'))
        self.assertEqual(result.pnr_locator, u'KIHOJE')

    def test_get_order_info_by_pnr(self):
        result = self.service.get_order_info_by_pnr(u'KIHOJE', 'EN')
        self.assertIsInstance(result, Order)
        self.assertEqual(result.cost, u'4350.00')
        self.assertEqual(result.currency, u'RUB')
        self.assertEqual(result.order_id,
                         UUID('70d9ca58-d4c1-4228-a618-a89e86f3d297'))
        self.assertEqual(result.pnr_locator, u'KIHOJE')

if __name__ == "__main__":
    testoob.main()
