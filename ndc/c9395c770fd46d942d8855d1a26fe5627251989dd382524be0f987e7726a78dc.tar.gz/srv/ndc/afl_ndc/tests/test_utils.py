# -*- coding: utf-8 -*-
import os
import unittest

import re
import testoob
from lxml import etree
from mock import patch

from utils.xml import parse_xml, get_tag_name, get_xml_schema, validate_xml
from utils import format_pax_name
from exc import NDCSyntaxError, UnsupportedFunctionError, InvalidFormatError, InvalidXMLError
import config


class TestUtils(unittest.TestCase):

    def test_parse_xml(self):
        with self.assertRaises(InvalidXMLError):
            parse_xml('<abc>text</def>')
        xml = parse_xml('<abc>text</abc>')
        self.assertIsInstance(xml, etree._Element)

    def test_get_tag_name(self):
        with self.assertRaises(NDCSyntaxError):
            get_tag_name('123abc')
        self.assertEqual(get_tag_name('abc'), 'abc')

    def test_get_schema(self):
        schema = get_xml_schema('FlightPriceRQ')
        self.assertIsInstance(schema, etree.XMLSchema)
        with self.assertRaises(UnsupportedFunctionError):
            get_xml_schema('invalid_file_name')

    def test_validate_xml(self):
        schema = get_xml_schema('FlightPriceRQ')
        with open(os.path.join(config.APPDIR, 'tests', 'data', 'FlightPriceRQ.xml')) as f:
            xml = f.read()
        with self.assertRaises(InvalidFormatError) as e:
            validate_xml(schema, xml)

        schema = get_xml_schema('OrderCreateRQ')
        with open(os.path.join(config.APPDIR, 'tests', 'data', 'OrderCreateRQ.xml')) as f:
            xml = f.read()
        self.assertTrue(validate_xml(schema, xml))
        xml = etree.XML(xml)
        self.assertTrue(validate_xml(schema, xml))

    @patch('utils.PMB_NAME_SKIP_RE', re.compile('[' + re.escape(''.join(['a', 'b', 'c', "'", '-'])) + ']'))
    def test_format_pax_name(self):
        assert format_pax_name("Ivan-boris'chris") == 'Ivnorishris'

if __name__ == '__main__':
    testoob.main()
