# -*- coding: utf-8 -*-

import unittest
import json

from mock import patch, PropertyMock

import requests
import testoob
from requests import Session

from clients.exc import ServiceNotFound, ServiceError
from clients.exc import ServiceResponseError
from clients.service import ClientService, HTTPService
import cherrypy
import config


class TestService(unittest.TestCase):
    def setUp(self):
        super(TestService, self).setUp()
        self.service = ClientService()
        p = PropertyMock(return_value={})

        def _request(cls_self, service_name=None, domain=None, **kwargs):
            response = requests.request(**kwargs)
            if response.status_code == requests.codes.ok:
                return json.loads(response.text)['data']
            else:
                raise ServiceResponseError()

        type(self.service)._request = _request

        type(self.service).names_urls = p
        type(self.service).headers = p

        self.request_params = {
            'url': '',
            'headers': {'Content-Type': 'application/json'},
            'json': {},
            'method': 'POST',
            'timeout': 5
        }

    @patch('clients.service.LOGGER')
    def test_send_request(self, mock_logging):
        params = self.request_params

        del params['timeout']

        params['url'] = 'https://some_url.ru'
        with self.assertRaises(ServiceError):
            self.service._send_request(**params)

    @patch('clients.service.LOGGER')
    def test_request_by_name(self, mock_logging):
        with self.assertRaises(ServiceNotFound):
            self.service.request_by_name('test')

    @patch('clients.service.LOGGER')
    def test_request_by_url(self, mock_logging):
        with self.assertRaises(ServiceError):
            self.service.request_by_url('https://some_url.ru')

    def test_request_by_url_service_error(self):
        with self.assertRaises(ServiceResponseError):
            # FIXME: actually calls SB
            self.service.request_by_url(config.SB_SERVICE_URL + 'search/v1')


class TestHttpService(unittest.TestCase):
    def setUp(self):
        super(TestHttpService, self).setUp()
        self.service = HTTPService()
        p = PropertyMock(return_value={})

        def _request(cls_self, service_name=None, domain=None, **kwargs):
            self.service._do_request(**kwargs)

        type(self.service)._request = _request

        type(self.service).names_urls = p
        type(self.service).headers = p

        self.request_params = {
            'url': '',
            'headers': {'Content-Type': 'application/json'},
            'json': {},
            'method': 'POST',
            'timeout': 5
        }

    def test_should_add_x_forwarder_for(self):
        params = self.request_params
        params['headers']['x-forwarded-for'] = "test-x-forwarded"
        self.service.names_urls['search'] = ('https://afl-test.test.aeroflot.ru/sb/booking/api/app/book/v1', None, None)
        cherrypy.request.headers['X-Forwarded-For'] = "test_x_forwarded_for"

        with patch.object(Session, 'request'):
            self.service.request_by_name('search')
            assert self.service.session.headers['X-Forwarded-For'] == 'test_x_forwarded_for, 127.0.0.1'


if __name__ == '__main__':
    testoob.main()
