# -*- coding: utf-8 -*-
import unittest
import testoob
from exc import NDCError
from mapping.mapping import NDCErrorMappingReader
import config


class TestNDCErrorMappingReader(unittest.TestCase):

    def test_get_exception(self):
        r = NDCErrorMappingReader(config.SB_ERRORS_MAPPING_FILE)
        self.assertIsNone(r.get_exception(None))
        self.assertIsNone(r.get_exception('invalid'))
        e = r.get_exception('1001000217')
        self.assertIsInstance(e, NDCError)
        self.assertEqual(e.code, '911')
        self.assertEqual(e.short_text, 'Unable to process - system error')


if __name__ == '__main__':
    testoob.main()
