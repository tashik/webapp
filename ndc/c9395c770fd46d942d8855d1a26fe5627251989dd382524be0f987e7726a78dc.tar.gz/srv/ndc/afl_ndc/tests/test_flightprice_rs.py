# -*- coding: utf-8 -*-
import copy
import datetime
import unittest

import testoob

from services.response.flightprice import FlightPriceRS

_sb_rs_test_data = [
    {'lang': 'ru', 'passengers': [{'pax_count': '1', 'travel_key': 'SH1', 'pax_type': 'ADT'}],
     'disclosures_sigs_ssid': None, 'disclosures_tais_dl': None, 'country': 'IT', 'disclosures_price': None,
     'agency_id': 'SS', 'currency': 'EUR',
     'destination_list': [{'origin': 'SVO', 'segments': 'SEG_SVOLED_1', 'destination': 'LED'}],
     'anonym_travelers': [{'infants': 2, 'youth': 3, 'children': 4, 'adults': 1}], 'disclosures_rem5': None,
     'routes': [{'arrival': datetime.date(2017, 10, 27), 'origin': 'SVO', 'aircraft_code': '320',
                 'marketing_name': u'\u042d\u043a\u043e\u043d\u043e\u043c \u0411\u044e\u0434\u0436\u0435\u0442',
                 'aircraft_name': 'Airbus A320', 'arrival_time': '01:55', 'operating_airline_code': 'SU',
                 'operating_flight_number': '0046', 'destination': 'LED', 'departure': datetime.date(2017, 10, 27),
                 'segment_key': 'SEG_SVOLED_1', 'booking_class': 'N', 'flight_number': '0046', 'marriage_group': '0',
                 'airline_code': 'SU', 'flight_duration': 'PT01H15M', 'departure_time': '00:40'}],
     'recognized_travelers': [], 'fares': [{'fare_base': 'NVOR', 'pax_ref': ['SH1', 'FL_SVOLED_1']}],
     'flight_segment_list': [
         {'segment_key': 'FL_SVOLED_1', 'origin': 'SVO', 'destination': 'LED', 'flight_number': '0046',
          'airline_id': 'SU'}], 'cabin': '3'}
    ,
    # sb_search_rs

    [([{'arrival': u'2017-10-27 01:55', 'operating_flight_number': '0046', 'airplane_name': 'Airbus A320',
        'operating_airline_name': '', 'meal_names': [], 'marriage_group': '0', 'flight_duration': 'PT01H15M',
        'airplane_code': '320', 'origin': {'airport_code': 'SVO'}, 'destination': {'airport_code': 'LED'},
        'airline_name': '', 'departure': u'2017-10-27 00:40', 'flight_number': '0046', 'airline_code': 'SU',
        'operating_airline': 'SU'}], {'fare_bases': ['NVOR'], 'fare_group': None, 'brand': None,
                                      'fare_group_name': u'\u042d\u043a\u043e\u043d\u043e\u043c \u0411\u044e\u0434\u0436\u0435\u0442',
                                      'booking_classes': ['N']})]
    ,
    # sb_price_rs

    {u'pax_prices': {
        u'ADULT': {u'count': 1, u'passenger_type_name': u'\u0412\u0437\u0440\u043e\u0441\u043b\u044b\u0439',
                   u'taxes': [{u'tax_code': u'YQF', u'amount': u'21.46',
                               u'tax_name': u'\u0422\u043e\u043f\u043b\u0438\u0432\u043d\u044b\u0439 \u0441\u0431\u043e\u0440'},
                              {u'tax_code': u'RI3', u'amount': u'1.91', u'tax_name': u'RI3'},
                              {u'tax_code': u'RI4', u'amount': u'1.38', u'tax_name': u'RI4'}],
                   u'currency_name': u'\u0415\u0432\u0440\u043e (EUR)', u'currency': u'EUR', u'base': u'22',
                   u'total': u'46.75'}}, u'mileage': u'0',
        u'taxes': [{u'tax_code': u'RI4', u'amount': u'1.38', u'tax_name': u'RI4'},
                   {u'tax_code': u'YQF', u'amount': u'21.46',
                    u'tax_name': u'\u0422\u043e\u043f\u043b\u0438\u0432\u043d\u044b\u0439 \u0441\u0431\u043e\u0440'},
                   {u'tax_code': u'RI3', u'amount': u'1.91', u'tax_name': u'RI3'}],
        u'currency_name': u'\u0415\u0432\u0440\u043e (EUR)', u'currency': u'EUR', u'base': u'22',
        u'total': u'46.75'}

]


class TestFlightPriceRS(unittest.TestCase):
    def setUp(self):
        super(TestFlightPriceRS, self).setUp()

    def test_get_anon_travelers(self):
        response = FlightPriceRS(_sb_rs_test_data)
        anon_travelers = response._get_anon_travelers()
        assert anon_travelers["ADULT"][0] == "SH1"
        assert anon_travelers["ADULT"][1].find('PTC').attrib['Quantity'] == '1'
        assert anon_travelers["CHILD"][0] == "SH2"
        assert anon_travelers["CHILD"][1].find('PTC').attrib['Quantity'] == '4'
        assert anon_travelers["INFANT"][0] == "SH3"
        assert anon_travelers["INFANT"][1].find('PTC').attrib['Quantity'] == '2'

    def test_build_flight_segment_with_operating_carrier(self):
        response = FlightPriceRS(_sb_rs_test_data)
        tree = response.build_tree()
        assert tree[1].xpath("//OperatingCarrier/Name")[0].text == u'Аэрофлот'

    def test_build_flight_segment_without_operating_carrier(self):
        data = copy.deepcopy(_sb_rs_test_data)
        data[1][0][0][0]['operating_airline'] = ''
        data[1][0][0][0]['operating_airline_code'] = ''
        data[1][0][0][0]['operating_airline_name'] = ''
        response = FlightPriceRS(data)
        tree = response.build_tree()
        assert len(tree[1].xpath("//OperatingCarrier")) == 0


if __name__ == '__main__':
    testoob.main()
