# -*- coding: utf-8 -*-
import os
import mock
import unittest
import testoob
import cherrypy
from StringIO import StringIO
from lxml import etree
from lxml.builder import E
from services.ndc import NDCService
from exc import UnsupportedFunctionError, InvalidFormatError, InvalidXMLError
import config

NS = {
    'soap': 'http://schemas.xmlsoap.org/soap/envelope/',
    'edist': 'http://www.iata.org/IATA/EDIST',
}


class TestNDCService(unittest.TestCase):

    @mock.patch('services.ndc.config.SUPPORTED_SERVICES', ['services.afl.OrderCreateService'])
    @mock.patch('services.afl.OrderCreateService.process_request')
    def test_index(self, process_request):
        process_request.return_value = E('OrderViewRS')
        self.service = NDCService()
        cherrypy.request.body = StringIO('')
        with self.assertRaises(InvalidXMLError):
            self.service.index()

        cherrypy.request.body = StringIO('<123></123>')
        with self.assertRaises(InvalidXMLError):
            self.service.index()

        cherrypy.request.body = StringIO('<SomeOtherRQ></SomeOtherRQ>')
        with self.assertRaises(UnsupportedFunctionError):
            self.service.index()

        cherrypy.request.body = StringIO('<OrderCreateRQ></OrderCreateRQ>')
        with self.assertRaises(InvalidFormatError):
            self.service.index()

        self.service._errorHandler()
        xml = etree.XML(cherrypy.response.body[0])
        self.assertEqual(xml.xpath('/edist:OrderViewRS/@Version', namespaces=NS)[0], config.DEFAULT_NDC_VERSION)
        error = xml.xpath('/edist:OrderViewRS/edist:Errors/edist:Error', namespaces=NS)[0]
        self.assertEqual(error.get('Type'), '914')
        self.assertEqual(error.get('Code'), '914')
        self.assertEqual(error.get('ShortText'), 'Invalid format/data - data does not match syntax rules')

        with open(os.path.join(config.APPDIR, 'tests', 'data', 'OrderCreateRQ.xml')) as f:
            request = f.read()
        cherrypy.request.body = StringIO(request.replace('Version="16.2"', 'Version="1.1.5"'))
        with self.assertRaises(UnsupportedFunctionError), mock.patch('config.SERVICES_VERSION_NDC_VERSION',
                                                                     {'1.0': '1.1.5'}):
            self.service.index()
        cherrypy.request.body = StringIO(request.replace('Version="1.1.5"', 'Version="16.2"'))
        response = self.service.index()
        xml = etree.XML(response)
        self.assertTrue(xml.xpath('/OrderViewRS', namespaces=NS))

if __name__ == '__main__':
    testoob.main()
