# -*- coding: utf-8 -*-

import os
import json
import mock
import unittest
from copy import deepcopy
from datetime import timedelta
from decimal import Decimal

import testoob
import requests
from mapping.enums import SBCabinTypes
from mock import patch

from exc import NDCError
from clients.sb import SBService, SearchCombiner
from clients.models import RequestSearchParams, ExchangeCost
from clients.exc import ParametersError, ServiceResponseError
import config


def route(prices):
    return {}, {}, prices


def price(i, x):
    return {}, {}, i, i, Decimal(x)


class TestSBService(unittest.TestCase):
    def setUp(self):
        super(TestSBService, self).setUp()
        self.service = SBService()

    @patch('clients.sb.SBService._do_request')
    @patch('clients.sb.LOGGER')
    @patch('clients.sb.SBService._debug_logger')
    def test_request(self, _debug_logger, LOGGER, request):
        r = requests.Response()
        r.status_code = 500
        r._content = ''
        request.return_value = r
        with self.assertRaises(ServiceResponseError):
            self.service.search(RequestSearchParams(routes=[], cabin='econom', adults=1, min_price='false'))
        self.assertEqual(_debug_logger.call_count, 2)
        LOGGER.error.assert_called_with('SBService error: HTTP 500  ')

        r.status_code = 200
        r._content = '{"data": "some data","error":null,"success":true}'
        request.return_value = r
        response = self.service.search(RequestSearchParams(routes=[], cabin='econom', adults=1, min_price='false'))
        self.assertEqual(response, 'some data')
        self.assertEqual(_debug_logger.call_count, 4)

        r._content = '{"data":null,"error":{"code": "2009009999","message": "Some error","type": "SomeException"},"success":false}'
        request.return_value = r
        with self.assertRaises(ServiceResponseError):
            self.service.search(RequestSearchParams(routes=[], cabin='econom', adults=1, min_price='false'))
        self.assertEqual(_debug_logger.call_count, 6)
        LOGGER.error.assert_called_with('SBService unknown error code: 2009009999')

        r.status_code = 500
        r._content = '{"data":null,"errors":[{"code": "2004000022","message": "Some error","type": "LangIsNotSpecifiedValidateException"}],"isSuccess":false}'
        request.return_value = r
        with self.assertRaises(NDCError) as ndc_error:
            self.service.search(RequestSearchParams(routes=[], cabin='econom', adults=1, min_price='false'))
        assert ndc_error.exception.description == "Some error"
        self.assertEqual(_debug_logger.call_count, 8)
        LOGGER.error.assert_called_with('SBService error: HTTP 500 2004000022 LangIsNotSpecifiedValidateException')

        r.status_code = 500
        r._content = '{"data":null,"errors":[{"code": "2004000022","message": "Какая-то ошибка","type": "LangIsNotSpecifiedValidateException"}],"isSuccess":false}'
        request.return_value = r
        with self.assertRaises(NDCError) as ndc_error:
            self.service.search(RequestSearchParams(routes=[], cabin='econom', adults=1, min_price='false'))
        assert ndc_error.exception.description == "Какая-то ошибка"

    def test_all_wrappers_exists(self):
        for name in self.service.names_urls:
            self.assertTrue(name in dir(self.service))

    def test_check_params(self):
        with self.assertRaises(ParametersError):
            self.service.search([])

        with self.assertRaises(ParametersError):
            self.service.search_min_prices([])

        with self.assertRaises(ParametersError):
            self.service.fare_rules([])

        with self.assertRaises(ParametersError):
            self.service.additional_info('some')
        with self.assertRaises(ParametersError):
            self.service.additional_info([1, 2])

        with self.assertRaises(ParametersError):
            self.service.miles('some')
        with self.assertRaises(ParametersError):
            self.service.miles([1, 2])

        with self.assertRaises(ParametersError):
            self.service.check_coupons('some', 'ru')

        with self.assertRaises(ParametersError):
            self.service.price([])

        with self.assertRaises(ParametersError):
            self.service.price_award([])

        with self.assertRaises(ParametersError):
            self.service.book([])

        with self.assertRaises(ParametersError):
            self.service.book_award([])

        with self.assertRaises(ParametersError):
            self.service.choose_seat(None, None, [], 'ru')
        with self.assertRaises(ParametersError):
            self.service.choose_seat(None, None, ['a', 'b'], 'ru')

        with self.assertRaises(ParametersError):
            self.service.choose_meal(None, None, 'some')
        with self.assertRaises(ParametersError):
            self.service.choose_meal(None, None, ['a', 'b'])

        with self.assertRaises(ParametersError):
            self.service.exchange_search(None, None, 'some', None)
        with self.assertRaises(ParametersError):
            self.service.exchange_search(None, None, ['a', 'b'], None)

        with self.assertRaises(ParametersError):
            self.service.exchange(None, None, None, 'ru', exchange_cost='some')
        with self.assertRaises(ParametersError):
            self.service.exchange(None, None, None, 'ru', exchange_cost=['a', 'b'])
        with self.assertRaises(ParametersError):
            self.service.exchange(None, None, None, 'ru', exchange_cost=[ExchangeCost('RUB'), ])
        with self.assertRaises(ParametersError):
            self.service.exchange(None, None, ['a', 'b'], 'ru', exchange_cost=[ExchangeCost('RUB'), ])


class TestSearchCombiner(unittest.TestCase):

    def setUp(self):
        with open(os.path.join(config.APPDIR, 'tests', 'data', 'search_response.json')) as f:
            response = f.read()
        self.c = SearchCombiner(json.loads(response), 100000)
        self.first_route = self.c.response['ways'][0][0]
        self.second_route = self.c.response['ways'][1][0]
        self.first_price = self.first_route['prices'][0]
        self.second_price = self.second_route['prices'][0]

    @mock.patch('clients.sb.MIN_FORWARD_TO_RETURN_TIME', timedelta(minutes=60))
    def test_process(self):
        self.c.cabin = SBCabinTypes.ECONOM
        response = self.c.process()
        self.assertEqual(response['ways'][0][0]['segments'], [self.c.response['ways'][0][0]['segments'][0], self.c.response['ways'][1][0]['segments'][0]])
        del response['ways'][0][0]['segments']

        self.assertDictEqual(response, {u'ways': [[{u'prices': [{
            u'base': u'50185',
            u'booking_classes': [u'E', u'I'],
            u'brand': u'EC',
            u'choose_seat': u'бесплатно',
            u'class_of_service': u'econom',
            u'class_of_service_name': u'Эконом',
            u'combinable_brands': [u'CC', u'EC', u'BC'],
            u'currency': u'RUB',
            u'currency_name': u'Рубль (RUB)',
            u'exchange': u'с доплатой',
            u'fare_group': u'econom-optimum',
            u'fare_group_name': u'Эконом Оптимум',
            u'fare_group_name_per_segment': [u'Эконом Оптимум', u'Бизнес Оптимум'],
            u'hit': False,
            u'luggage': u'1 место',
            u'mileage': u'579',
            u'miles_percent': u'100 %',
            u'miles_upgrade': u'недоступен',
            u'pax_prices': {
                u'ADULT': {
                    u'base': u'28675',
                    u'count': 1,
                    u'currency': u'RUB',
                    u'currency_name': u'Рубль (RUB)',
                    u'fare_bases': [u'ECLR', u'ICLR'],
                    u'passenger_type_name': u'Взрослый',
                    u'taxes': [{u'tax_code': u'YQF', u'amount': u'4500', u'tax_name': u'Топливный сбор'}],
                    u'total': u'33175',
                },
                u'CHILD': {
                    u'base': u'21508',
                    u'count': 1,
                    u'currency': u'RUB',
                    u'currency_name': u'Рубль (RUB)',
                    u'fare_bases': [u'ECLR/CH25', u'ICLR/CH25'],
                    u'passenger_type_name': u'Ребёнок',
                    u'taxes': [{u'tax_code': u'YQF', u'amount': u'4500', u'tax_name': u'Топливный сбор'}],
                    u'total': u'26010',
                },
                u'INFANT': {
                    u'base': u'0',
                    u'count': 1,
                    u'currency': u'RUB',
                    u'currency_name': u'Рубль (RUB)',
                    u'fare_bases': [u'ECLR/IN00', u'ICLR/IN00'],
                    u'passenger_type_name': u'Младенец без места',
                    u'taxes': [],
                    u'total': u'0',
                },
            },
            u'refund': u'с доплатой',
            u'seats': 4,
            u'taxes': [{u'tax_code': u'TOTALTAX', u'amount': u'9000', u'tax_name': u'TOTALTAX'}],
            u'total': u'59185',
        }], u'route_time_name': u'1 ч. 25 мин.'}]], u'interline': True, u'days': []})
        self.assertTrue(self.c.interlined)

    @mock.patch('clients.sb.MIN_FORWARD_TO_RETURN_TIME', timedelta(minutes=60))
    def test_process_several_routes(self):
        self.c.cabin = SBCabinTypes.ECONOM
        self.c.response['ways'][1].append(self.c.response['ways'][1][0])
        self.assertEqual(len(self.c.process()['ways'][0]), 2)

    @mock.patch('clients.sb.MIN_FORWARD_TO_RETURN_TIME', timedelta(minutes=60))
    @mock.patch('config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER', False)
    def test_process_several_prices(self):
        self.c.cabin = SBCabinTypes.ECONOM
        self.c.response['ways'][1][0]['prices'].append(self.c.response['ways'][1][0]['prices'][0])
        self.assertEqual(len(self.c.process()['ways'][0][0]['prices']), 2)

    @mock.patch('clients.sb.MIN_FORWARD_TO_RETURN_TIME', timedelta(minutes=60))
    def test_process_several_prices_limit(self):
        self.c.max_prices = 1
        self.c.cabin = SBCabinTypes.ECONOM
        new_price = deepcopy(self.c.response['ways'][1][0]['prices'][0])
        new_price['total'] = '100'
        self.c.response['ways'][1][0]['prices'].insert(0, new_price)
        response = self.c.process()
        self.assertEqual(len(response['ways'][0][0]['prices']), 1)
        self.assertEqual(response['ways'][0][0]['prices'][0]['total'], '6035')

    @mock.patch('clients.sb.MIN_FORWARD_TO_RETURN_TIME', timedelta(minutes=60))
    def test_process_departure(self):
        self.c.response['ways'][1][0]['segments'][0]['departure'] = u'2017-04-09 03:04'
        self.assertEqual(self.c.process(), {u'ways': [], u'interline': False, u'days': []})

    def test_process_no_way(self):
        del self.c.response['ways'][1]
        response = self.c.process()
        self.assertEqual(response, self.c.response)

        del self.c.response['ways'][0]
        response = self.c.process()
        self.assertEqual(response, self.c.response)

    @mock.patch('config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER', False)
    def test_limit_routes(self):

        self.c.max_prices = 3
        routes = [
            route([price(1, 400), price(2, 200)]),
            route([price(3, 300), price(4, 100)]),
            route([price(5, 200), price(6, 200)]),
            route([price(7, 200), price(8, 200)]),
        ]
        self.assertEqual(self.c._limit_routes(routes), [route([price(2, 200)]), route([price(4, 100)]), route([price(5, 200)])])

        self.assertEqual(self.c._sort_prices(routes), [
            route([price(2, 200), price(1, 400)]),
            route([price(4, 100), price(3, 300)]),
            route([price(5, 200), price(6, 200)]),
            route([price(7, 200), price(8, 200)]),
        ])

    @mock.patch('config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER', True)
    def test_limit_routes_one_price_per_offer(self):

        self.c.max_prices = 3
        routes = [
            route([price(1, 400), price(2, 200)]),
            route([price(3, 300), price(4, 100)]),
            route([price(5, 200), price(6, 200)]),
            route([price(7, 200), price(8, 200)]),
        ]
        self.assertEqual(self.c._limit_routes(routes), [route([price(4, 100)]), route([price(2, 200)]),
                                                        route([price(5, 200)])])

    @mock.patch('config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER', True)
    def test_one_way_with_one_price_per_offer_without_cabin_type_filtering(self):
        self.c.max_prices = 3
        self.c.cabin = SBCabinTypes.ECONOM
        self.c.response = {
            'ways': [
                [{'prices': [{'total': Decimal(1000), 'class_of_service': 'econom'},
                             {'total': Decimal(1050), 'class_of_service': 'econom'},
                             {'total': Decimal(1100), 'class_of_service': 'econom'}]},
                 {'prices': [{'total': Decimal(900), 'class_of_service': 'econom'},
                             {'total': Decimal(1200), 'class_of_service': 'econom'},
                             {'total': Decimal(1300), 'class_of_service': 'econom'}]},
                 {'prices': [{'total': Decimal(100), 'class_of_service': 'econom'},
                             {'total': Decimal(200), 'class_of_service': 'econom'},
                             {'total': Decimal(3000), 'class_of_service': 'econom'}]},
                 {'prices': [{'total': Decimal(800), 'class_of_service': 'econom'},
                             {'total': Decimal(950), 'class_of_service': 'econom'},
                             {'total': Decimal(1000), 'class_of_service': 'econom'}]}]
            ]
        }
        self.assertEqual(self.c._build_one_way_response(), {'ways': [[
            {'prices': [{'total': Decimal(100), 'class_of_service': 'econom'}]},
            {'prices': [{'total': Decimal(800), 'class_of_service': 'econom'}]},
            {'prices': [{'total': Decimal(900), 'class_of_service': 'econom'}]},
        ]]})

    @mock.patch('config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER', True)
    def test_one_way_with_one_price_per_offer_with_cabin_type_filtering(self):
        self.c.max_prices = 3
        self.c.cabin = SBCabinTypes.BUSINESS
        self.c.response = {
            'ways': [
                [{'prices': [{'total': Decimal(1000), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1050), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1100), 'class_of_service': SBCabinTypes.BUSINESS}]},
                 {'prices': [{'total': Decimal(900), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1200), 'class_of_service': SBCabinTypes.BUSINESS},
                             {'total': Decimal(1300), 'class_of_service': SBCabinTypes.BUSINESS}]},
                 {'prices': [{'total': Decimal(100), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(200), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(3000), 'class_of_service': SBCabinTypes.BUSINESS}]},
                 {'prices': [{'total': Decimal(800), 'class_of_service': SBCabinTypes.BUSINESS},
                             {'total': Decimal(950), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1000), 'class_of_service': SBCabinTypes.BUSINESS}]}]
            ]
        }
        self.assertEquals(self.c._build_one_way_response(), {'ways': [[
            {'prices': [{'total': Decimal(800), 'class_of_service': SBCabinTypes.BUSINESS}]},
            {'prices': [{'total': Decimal(1100), 'class_of_service': SBCabinTypes.BUSINESS}]},
            {'prices': [{'total': Decimal(1200), 'class_of_service': SBCabinTypes.BUSINESS}]},
        ]]})

    @mock.patch('config.SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER', False)
    def test_one_way_without_one_price_per_offer(self):
        self.c.max_prices = 3
        self.c.cabin = SBCabinTypes.ECONOM

        self.c.response = {
            'ways': [
                [{'prices': [{'total': Decimal(1000), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1050), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1100), 'class_of_service': SBCabinTypes.ECONOM}]},
                 {'prices': [{'total': Decimal(900), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1200), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1300), 'class_of_service': SBCabinTypes.ECONOM}]},
                 {'prices': [{'total': Decimal(100), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(200), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(3000), 'class_of_service': SBCabinTypes.ECONOM}]},
                 {'prices': [{'total': Decimal(800), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(950), 'class_of_service': SBCabinTypes.ECONOM},
                             {'total': Decimal(1000), 'class_of_service': SBCabinTypes.ECONOM}]}]
            ]
        }
        self.assertEquals(self.c._build_one_way_response(), {'ways': [[
            {'prices': [{'total': Decimal(100), 'class_of_service': SBCabinTypes.ECONOM},
                        {'total': Decimal(200), 'class_of_service': SBCabinTypes.ECONOM}]},
            {'prices': [{'total': Decimal(800), 'class_of_service': SBCabinTypes.ECONOM}]},
        ]]})

    def test_combine_routes(self):
        self.first_route['segments'] = [1, 2]
        self.second_route['segments'] = [3, 4]
        self.assertEqual(self.c._combine_routes(self.first_route, self.second_route, [5, 6]), {
            'segments': [1, 2, 3, 4],
            'prices': [5, 6],
            'route_time_name': u'1 ч. 25 мин.',
        })

    def test_get_prices(self):
        prices = self.c._get_prices(self.first_route['prices'], self.second_route['prices'], 1, 2)
        self.assertEqual(prices, [(self.first_price, self.second_price, 1, 2, Decimal(59185))])

        with mock.patch('clients.sb.SearchCombiner._prices_are_combinable', return_value=False):
            self.assertEqual(self.c._get_prices(self.first_route['prices'], self.second_route['prices'], 1, 2), [])

    def test_combine_prices_interlined(self):
        self.first_price['brand'] = self.second_price['brand']
        self.c._combine_prices(self.first_price, self.second_price, len(self.first_route['segments']), len(self.second_route['segments']))
        self.assertFalse(self.c.interlined)

    def test_prices_are_combinable_brands(self):
        self.first_price['combinable_brands'] = []
        self.assertFalse(self.c._prices_are_combinable(self.first_price, self.second_price))

        self.first_price['combinable_brands'] = ['BC', 'EC']
        self.second_price['combinable_brands'] = ['BC', 'CC']
        self.assertTrue(self.c._prices_are_combinable(self.first_price, self.second_price))
        price = self.c._combine_prices(self.first_price, self.second_price, len(self.first_route['segments']), len(self.second_route['segments']))
        self.assertEqual(price['combinable_brands'], ['BC'])

    def test_prices_are_combinable_currency(self):
        self.first_price['currency'] = 'USD'
        self.assertFalse(self.c._prices_are_combinable(self.first_price, self.second_price))

    def test_prices_are_combinable_brand(self):
        self.second_price['brand'] = 'XX'
        self.assertFalse(self.c._prices_are_combinable(self.first_price, self.second_price))

    def test_prices_are_combinable_cost_currency(self):
        self.first_price['pax_prices']['ADULT']['currency'] = 'USD'
        self.assertFalse(self.c._prices_are_combinable(self.first_price, self.second_price))

    def test_prices_are_combinable_pax_prices(self):
        del self.first_price['pax_prices']['ADULT']
        self.assertFalse(self.c._prices_are_combinable(self.first_price, self.second_price))

    def test_combine_taxes(self):
        taxes = self.c._combine_taxes([], self.second_price['pax_prices']['CHILD']['taxes'])
        self.assertEqual(taxes, [{u'tax_code': u'YQF', u'amount': u'3000', u'tax_name': u'Топливный сбор'}])

    def test_combine_numbers(self):
        self.assertEqual(self.c._combine_numbers('0.00', '0.00'), '0.00')
        self.assertEqual(self.c._combine_numbers('0', '0'), '0')
        self.assertEqual(self.c._combine_numbers('123', '456'), '579')
        self.assertEqual(self.c._combine_numbers('779.00', '757.00'), '1536.00')

    def test_combine_seats(self):
        self.assertEqual(self.c._combine_seats(0, 2), 0)
        self.assertEqual(self.c._combine_seats(1, 2), 1)
        self.assertEqual(self.c._combine_seats(4, 0), 0)
        self.assertEqual(self.c._combine_seats(4, 3), 3)
        self.assertEqual(self.c._combine_seats(4, None), 4)
        self.assertEqual(self.c._combine_seats(None, 5), 5)

if __name__ == '__main__':
    testoob.main()
