import unittest

import datetime
from mock import MagicMock, patch

import config
from clients.pmb import PMBService
from clients.sb import SBService
from exc import InvalidFareBasis
from mapping.enums import NDCCabinTypes
from services.afl import AirShoppingService, OrderCreateService, FlightPriceService


class TestAirShoppingService(unittest.TestCase):

    def test_process_request(self):
        service = AirShoppingService()

        mock_mapper_from_ndc = MagicMock(return_value=[4, 5, 6])
        mock_mapper = MagicMock()
        mock_mapper.map_from_ndc = mock_mapper_from_ndc
        mock_external_method = MagicMock(return_value=[1, 2, 3])

        mock_cls = MagicMock()
        mock_cls.container = MagicMock()
        mock_response_cls = MagicMock(return_value=mock_cls)
        mock_response_type = MagicMock()
        mock_process_response = MagicMock()

        service.request_mapper = mock_mapper
        service.external_method = mock_external_method
        service.response_cls = mock_response_cls
        service.response_type = mock_response_type
        service.process_response = mock_process_response

        service.process_request("test")

        mock_mapper_from_ndc.assert_called_once_with("test")
        mock_external_method.assert_called_once_with([4, 5, 6])
        mock_response_cls.assert_called_once_with([1, 2, 3])
        mock_process_response.assert_called_once_with([4, 5, 6], [1, 2, 3], mock_cls)

    def test_external_method(self):
        service = AirShoppingService()
        service._prepare_sb_rq = MagicMock(return_value=[7, 8])
        with patch.object(SBService, "search", return_value=[4, 5, 6]):
            search_data, sb_response = service.external_method({'country': 'ru', 'a': 1, 'b': 2, 'lang': 'bn'})
            assert search_data == [7, 8]
            assert sb_response == [4, 5, 6]

    def test_process_response(self):
        service = AirShoppingService()
        response = MagicMock()
        service.process_response({'cabin': NDCCabinTypes.FIRST_CLASS}, [], response)
        assert response.add_warning.called

    def test_prepare_sb_rq(self):
        service = AirShoppingService()
        request_data = {
            'lang' : 'bg',
            'cabin': NDCCabinTypes.FIRST_CLASS,
            'routes': [
                {
                    'origin': 'SVO',
                    'destination': 'LED',
                    'departure': datetime.date(2017, 11, 11)
                 },
                {
                    'origin': 'IKT',
                    'destination': 'SVO',
                    'departure': datetime.date(2017, 11, 12)
                },
            ],
            'anonym_travelers': [{
                'adults': 1,
                'children': 2,
                'infants': 0
            }],
            'recognized_travelers': [{
                'adults': 3,
                'children': 5,
                'infants': 2
            }],
            'award': None,
            'country': 'PO',
            'currency': 'EUR',
            'iata_num': 123,
            'agency_id': 'Skyscanner'
        }
        result = service._prepare_sb_rq(request_data)
        assert result.adults == 4
        assert result.award is None
        assert result.cabin == 'business'
        assert result.country == 'PO'
        assert result.currency == 'EUR'
        assert result.infants == 2
        assert result.lang == 'bg'
        assert result.referrer == 123
        assert result.routes[0].departure == '2017-11-11'
        assert result.routes[0].destination == 'LED'
        assert result.routes[0].origin == 'SVO'
        assert result.routes[1].departure == '2017-11-12'
        assert result.routes[1].destination == 'SVO'
        assert result.routes[1].origin == 'IKT'


class TestFlightPriceService(unittest.TestCase):
    request_data = {
        'lang': 'bg',
        'cabin': NDCCabinTypes.FIRST_CLASS,
        'routes': [
            {
                'origin': 'SVO',
                'destination': 'LED',
                'segment_key': 'SEG1',
                'departure': datetime.date(2017, 11, 11),
                'arrival': datetime.date(2017, 11, 11),
                'departure_time': '12:45',
                'arrival_time': '13:45',
                'booking_class': 'business',
                'airline_code': 'SU',
                'flight_number': 'SU1234',
                'marketing_name': 'AAAAA',
                'flight_duration': 'PT01H15M',
                'aircraft_code': 319,
                'aircraft_name': 'Airobus 319',
                'operating_airline_code': 'SU',
                'operating_flight_number': '1234',
            },
            {
                'origin': 'IKT',
                'destination': 'DME',
                'segment_key': 'SEG2',
                'booking_class': 'business',
                'departure': datetime.date(2017, 11, 12),
                'arrival': datetime.date(2017, 11, 12),
                'arrival_time': '03:45',
                'departure_time': '02:45',
                'airline_code': 'SU',
                'flight_number': 'SU5668',
                'marketing_name': 'BBBBB',
                'flight_duration': 'PT05H15M',
                'aircraft_code': 319,
                'aircraft_name': 'Airobus 319',
                'operating_airline_code': 'SU',
                'operating_flight_number': '3456',
            },
        ],
        'destination_list': [
            {
                'origin': 'SVO',
                'destination': 'LED',
                'segments': 'SEG1 SEG2',
                'departure': datetime.date(2017, 11, 11),
                'arrival': datetime.date(2017, 11, 11)
            },
            {
                'origin': 'IKT',
                'destination': 'SVO',
                'segments': 'SEG1 SEG2',
                'arrival': datetime.date(2017, 11, 11),
                'departure': datetime.date(2017, 11, 12)
            },
        ],
        'flight_segment_list': [
            {
                'origin': 'SVO',
                'destination': 'LED',
                'segment_key': 'SEG1',
                'airline_code': 'SU',
                'flight_number': 'SU1234',
            },
            {
                'origin': 'IKT',
                'destination': 'SVO',
                'segment_key': 'SEG2',
                'airline_id': 'SU',
                'flight_number': 'SU5668'
            },
        ],
        'anonym_travelers': [{
            'adults': 1,
            'children': 2,
            'infants': 0,
            'youth': 0
        }],
        'recognized_travelers': [{
            'adults': 3,
            'children': 5,
            'infants': 2,
            'youth': 0
        }],
        'award': None,
        'country': 'PO',
        'currency': 'EUR',
        'iata_num': 123,
        'passengers': [{
            'travel_key': 'TRK1',
            'pax_type': 'ADT',
            'contacts': [{
                'phone': '+79112223311',
                'email': 'test@example.com'
            }],
            'birth_date': datetime.date(1987, 10, 10),
            'sex': 'Male',
            'pax_doc': [{
                'doc_expiration': datetime.date(2020, 5, 5),
                'doc_type': 'PT',
                'doc_country': 'RU',
                'doc_number': '111232323121',
                'visa_country': 'NL'
            }],
            'middle_name_suffix': 'mr',
            'middle_name': 'Ivanovovich',
            'first_name': 'Ivan',
            'last_name': 'Ivanov',
            'nationality': 'Russian'
        }],
        'fares': [
            {
                'seg_ref': 'REF01',
                'fare_base': 'YVO',
                'pax_ref': ['TRK1', 'SEG1']
            },
            {
                'seg_ref': 'REF02',
                'fare_base': 'QVU',
                'pax_ref': ['TRK1', 'SEG2']
            }
        ],

    }

    def should_raise_invalid_fare_basis(self):
        service = FlightPriceService()
        with patch.object(SBService, "search", return_value=None):
            with patch.object(SBService, "price", return_value={'result_type': "price"}):
                with self.assertRaises(InvalidFareBasis):
                    service.external_method(self.request_data)

    def test_external_method(self):
        service = FlightPriceService()

        request_data = self.request_data.copy()
        request_data['routes'][1]['destination'] = 'SVO'

        with patch.object(SBService, "search", return_value=None):
            with patch.object(SBService, "price", return_value={'result_type': "price"}):
                request_dict, response, sb_price_response = service.external_method(request_data)
                segment = response[0][0][0]
                self.assertEqual(segment['airline_code'], u'SU')
                self.assertEqual(segment['airplane_code'], 319)
                self.assertEqual(segment['departure'], '2017-11-11 12:45')
                self.assertEqual(segment['flight_duration'], 'PT01H15M')

                self.assertEqual(response[0][1]['booking_classes'], ['business', 'business'])
                self.assertEqual(response[0][1]['fare_group_name'], u'Economy Saver')

                self.assertEqual(sb_price_response['result_type'], 'price')


class TestOrderCreateService(unittest.TestCase):
    request = {
        'segments': [{
            'pax_ref': 'AA-ADT RR',
            'fares': [
                {
                    'seg_ref': 'REF01',
                    'fare_base': 1000
                }
            ],
            'ways': [{
                'seg_key': 'REF01',
                'origin': 'IKT',
                'destination': 'SVO',
                'segment_key': 'SEG2',
                'booking_class': 'business',
                'departure': datetime.date(2017, 11, 12),
                'airline_code': 'SU',
                'flight_number': 'SU5668',
                'marketing_name': 'BBBBB'
            }]

        }],
        'lang_info': [{
            'app': 'site',
            'lang': 'ko'
        }],
        'country': 'ko',
        'currency': 'EUR',
        'passengers': [{
            'pax_type': 'ADT',
            'contacts': [{
                'phone': '+79112223311',
                'email': 'test@example.com'
            }],
            'birth_date': datetime.date(1987, 10, 10),
            'sex': 'Male',
            'pax_doc': [{
                'doc_expiration': datetime.date(2020, 5, 5),
                'doc_type': 'PT',
                'doc_country': 'RU',
                'doc_number': '111232323121',
                'visa_country': 'NL'
            }],
            'middle_name_suffix': 'mr',
            'middle_name': 'Ivanovovich',
            'first_name': 'Ivan',
            'last_name': 'Ivanov',
            'nationality': 'Russian',
        }],
        'agency_id': 'SS',
        'booking_ref': None,
        'prices': [
            {'pax_ref': "AAA-ADT BBB", 'base_amount': 100, 'taxes_total': 150}
        ],
        'simple_currency_price': 250
    }

    def test_external_method(self):
        service = OrderCreateService()

        price_return = {'pax_prices': {'ADULT': {'taxes': [{'amount': 100}], 'base': 50}}, 'total': 250}
        with patch.object(SBService, "price", return_value=price_return):
            with patch.object(SBService, "book", return_value={
                'pnr_locator': 'AAABBB'
            }):
                with patch.object(PMBService, "booking_v1", return_value=[4, 5, 6]):
                    result = service.external_method(self.request)
                    assert result[2]['pnr_locator'] == 'AAABBB'
                    assert result[0].country == 'ko'
                    assert result[0].currency == 'EUR'
                    assert result[0].email == 'test@example.com'
                    assert result[0].phone == '+79112223311'
                    assert result[0].referrer == 'NNNONMN'
                    assert result[0].passengers[0].patronymic == 'Ivanovovich mr'
                    assert len(result[0].segments) == 1
                    assert len(result[0].passengers) == 1

    def test_external_method_without_middle_name(self):
        service = OrderCreateService()
        request = self.request.copy()
        request['passengers'][0]['middle_name'] = ''
        request['passengers'][0]['middle_name_suffix'] = ''
        price_return = {'pax_prices': {'ADULT': {'taxes': [{'amount': 100}], 'base': 50}}, 'total': 250}

        with patch.object(SBService, "price", return_value=price_return):
            with patch.object(SBService, "book", return_value={
                'pnr_locator': 'AAABBB'
            }):
                with patch.object(PMBService, "booking_v1", return_value=[4, 5, 6]):
                    result = service.external_method(request)
                    assert result[0].passengers[0].patronymic == ''

    def test_get_langs_acceptable_written(self):
        service = OrderCreateService()
        lang_data = [{'app': 'test', 'lang': 'unknown'}, {'app': 'Written', 'lang': 'unknown'}]
        langs = service._get_langs(lang_data)
        assert langs['Written'] == config.DEFAULT_LANGUAGE_CODE
        assert langs['test'] == 'unknown'

    def test_get_langs_unacceptable_written(self):
        service = OrderCreateService()
        lang_data = [{'app': 'test', 'lang': 'unknown'}, {'app': 'Written', 'lang': 'ru'}]
        langs = service._get_langs(lang_data)
        assert langs['Written'] == 'ru'
        assert langs['test'] == 'unknown'

    @patch('config.LANGUAGES', ['EN ', '  RU   '])
    def test_get_langs_space_in_config_langs_list(self):
        service = OrderCreateService()
        lang_data = [{'app': 'test', 'lang': 'unknown'}, {'app': 'Written', 'lang': 'ru'}]
        langs = service._get_langs(lang_data)
        assert langs['Written'] == 'ru'
        assert langs['test'] == 'unknown'
