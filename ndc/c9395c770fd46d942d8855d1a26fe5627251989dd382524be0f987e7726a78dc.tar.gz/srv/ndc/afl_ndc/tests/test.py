# -*- coding: utf-8 -*-

"""Test Runner.
"""
import testoob
import unittest
import os
import config


PATTERN = 'test_*.py'


def filter_empty_test_suites(test_suites):

    def filter_empty_test_suites_rec(test_suites, filtered_test_suite):
        for test_suite in test_suites:
            if isinstance(test_suite, unittest.TestCase):
                filtered_test_suite.append(test_suite)
            else:
                filter_empty_test_suites_rec(test_suite, filtered_test_suite)
        return filtered_test_suite
    return unittest.TestSuite(filter_empty_test_suites_rec(test_suites, []))


if __name__ == '__main__':
    u""" Смотри python test.py -h опции запуска """
    test_loader = unittest.TestLoader()
    current_dir = os.path.dirname(__file__)
    suite = test_loader.discover(current_dir, pattern=PATTERN)
    testoob.main(filter_empty_test_suites(suite))
