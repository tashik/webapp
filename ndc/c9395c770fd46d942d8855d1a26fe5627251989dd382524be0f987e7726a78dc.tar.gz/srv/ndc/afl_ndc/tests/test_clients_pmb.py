# -*- coding: utf-8 -*-

import os
import json
import unittest

import testoob
import requests
from mock import patch

from clients.pmb import PMBService, BookingPMBToSBMapper
from clients.exc import PMBResponseError
import config


class TestPMBService(unittest.TestCase):
    def setUp(self):
        super(TestPMBService, self).setUp()
        self.service = PMBService()

    @patch('clients.pmb.BookingPMBToSBMapper')
    @patch('clients.pmb.request')
    @patch('clients.pmb.LOGGER')
    @patch('clients.pmb.PMBService._debug_logger')
    def test_request(self, _debug_logger, LOGGER, request, mapper):
        r = requests.Response()
        r.status_code = 500
        r._content = ''
        request.return_value = r
        with self.assertRaises(PMBResponseError):
            self.service.booking_v1('XXXXXX', 'LAST')
        self.assertEqual(_debug_logger.call_count, 2)
        LOGGER.error.assert_called_with('PMBService error: HTTP 500  ')

        r.status_code = 200
        r._content = '{"data": "some data","errors":[],"isSuccess":true}'
        request.return_value = r
        response = self.service.booking_v1('XXXXXX', 'LAST')
        self.assertEqual(response, 'some data')
        self.assertEqual(_debug_logger.call_count, 4)

        self.service.booking_v1('XXXXXX', 'LAST', map_to_sb=True)
        self.assertEqual(_debug_logger.call_count, 6)
        self.assertEqual(mapper.call_count, 1)

        r._content = '{"data":null,"errors":[{"code": "2009009999","comment": "Some error","type": "SomeException"}],"isSuccess":false}'
        request.return_value = r
        with self.assertRaises(PMBResponseError):
            self.service.booking_v1('XXXXXX', 'LAST')
        self.assertEqual(_debug_logger.call_count, 8)
        LOGGER.error.assert_called_with('PMBService unknown error code: 2009009999')


class TestBookingPMBToSBMapper(unittest.TestCase):

    def setUp(self):
        with open(os.path.join(config.APPDIR, 'tests', 'data', 'pmb_booking_response.json')) as f:
            response = f.read()
        self.m = BookingPMBToSBMapper(json.loads(response))

    def test_process(self):
        response = self.m.process()
        self.assertDictEqual(response, {
            'tickets': [],
            'passengers': [{
                'last_name': 'IVANOV',
                'escort_ref': '',
                'loyalty_level_name': '',
                'loyalty_number': '',
                'ref_number': '01.01',
                'loyalty_level': '',
                'loyalty': '',
                'birthdate': '1991-02-19',
                'sex': 'M',
                'phone': '',
                'is_infant': False,
                'loyalty_name': '',
                'pax_type': 'ADT',
                'first_name': 'FEDOR NIKOLAEVICH',
                'ticketing_documents': [],
                'document': {
                    'doc_expiration': '2025-01-01',
                    'doc_number': '123123123',
                    'doc_country': 'RU',
                    'documentType': 'P',
                    'nationality': 'RU'
                },
                'email': 'VILNUS.JON@YANDEX.RU'
            }],
            'has_changed_segments': False,
            'pnr_key': '05974e869f2f510e3b00573779daecdd',
            'pnr_locator': 'OFECNE',
            'segment_groups': [{'start_weekday_name': '', 'total_time_name': '', 'segments': [{
                'origin': {
                    'terminal_code': 'D',
                    'city_name': '',
                    'country_code': '',
                    'country_name': '',
                    'airport_code': 'SVO',
                    'airport_name': '',
                    'city_code': '',
                    'terminal_name': ''
                },
                'meal_codes': [],
                'checkin_url': '',
                'status_code': 'HK',
                'airplane_name': '',
                'flight_time': 75,
                'original_airline_code': '',
                'transfer_time': '',
                'destination': {
                    'terminal_code': '1',
                    'city_name': '',
                    'country_code': '',
                    'country_name': '',
                    'airport_code': 'LED',
                    'airport_name': '',
                    'city_code': '',
                    'terminal_name': ''
                },
                'flight_time_name': '',
                'paxCount': 1,
                'flight_number': '46',
                'meal_name': '',
                'arrival': '2017-08-01 01:55',
                'booking_class_name': '',
                'booking_class_code': 'B',
                'departure_date_name': '',
                'arrival_time': '',
                'segment_number': 1,
                'airline_name': '',
                'airplane_code': '320',
                'airline_code': 'SU',
                'departure_time': '',
                'seat_preselect': True,
                'departure_utc_offset': 180,
                'arrival_date_name': '',
                'status_name': '',
                'original_flight_number': '',
                'departure': '2017-08-01 00:40',
                'transfer_same_terminal': True,
                'arrival_utc_offset': 180,
                'original_airline_name': '',
                'checkin_message': ''
            }]}],
            'checkin_url': '',
            'passbook_url': 'http://127.0.0.1:6981/b/info/booking/OFECNE/05974e869f2f510e3b00573779daecdd/passbook',
            'is_visa_required': False,
            'services': {},
            'seats': [],
            'date': '2017-05-07',
            'is_residence_required': False,
            'meals': [],
            'is_block_charter': False
        })

    def test_map_dict(self):
        self.assertEqual(self.m._map_dict({'a': 1, 'b': 2}, (('a', 'c'),)), {'c': 1, 'b': 2})

    def test_process_several_prices(self):
        self.m.response['segments'][0]['checkin_url'] = 'CHECKIN_URL'
        self.assertEqual(self.m._get_checkin_url(), 'CHECKIN_URL')

if __name__ == '__main__':
    testoob.main()
