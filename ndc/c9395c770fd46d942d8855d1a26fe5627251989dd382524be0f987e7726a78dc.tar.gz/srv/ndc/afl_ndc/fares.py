# -*- coding: utf-8 -*-


from i18n import _


LUGGAGE_DESCRIPTION = _('ndc.text.fares.info.checked_bag')

CARRY_ON_BAG_TYPE = _('ndc.text.fares.info.bag_type.briefcase_laptop')


class BusinessLuggageInfo(object):
    adt_chd_carry_on = {
        'count': 1,
        'weight': (15., 'kg'),
        'length': (55., 'cm'),
        'width': (40., 'cm'),
        'height': (20., 'cm'),
    }

    adt_chd_luggage = {
        'count': 2,
        'weight': (32., 'kg'),
        'length': (70., 'cm'),
        'width': (60., 'cm'),
        'height': (28., 'cm'),
    }

    infants_luggage = {
        'count': 1,
        'weight': (10., 'kg'),
        'length': (55., 'cm'),
        'width': (40., 'cm'),
        'height': (20., 'cm'),
    }

    CARRY_ON = {
        'type': CARRY_ON_BAG_TYPE,
        'ADT': adt_chd_carry_on,
        'CHD': adt_chd_carry_on,
        'INF': {},
    }

    LUGGAGE = {
        'description': LUGGAGE_DESCRIPTION,
        'ADT': adt_chd_luggage,
        'CHD': adt_chd_luggage,
        'INF': infants_luggage,
    }


class ComfortLuggageInfo(object):
    adt_chd_luggage = BusinessLuggageInfo.adt_chd_luggage.copy()
    adt_chd_luggage['weight'] = (23., 'kg')  # 2 места не более 23 кг каждое

    adt_chd_carry_on = {
        'count': 1,
        'weight': (10., 'kg'),
        'length': (55., 'cm'),
        'width': (40., 'cm'),
        'height': (20., 'cm'),
    }

    LUGGAGE = {
        'description': LUGGAGE_DESCRIPTION,
        'ADT': adt_chd_luggage,
        'CHD': adt_chd_luggage,
        'INF': BusinessLuggageInfo.infants_luggage,
    }

    CARRY_ON = {
        'type': CARRY_ON_BAG_TYPE,
        'ADT': adt_chd_carry_on,
        'CHD': adt_chd_carry_on,
        'INF': {},
    }


class EconomLuggageInfo(object):
    adt_chd_luggage_other = {  # 1 место не более 23 кг
        'count': 1,
        'weight': (23., 'kg'),
        'length': (70., 'cm'),
        'width': (60., 'cm'),
        'height': (28., 'cm'),
    }

    LUGGAGE_PREMIUM = {
        'description': LUGGAGE_DESCRIPTION,
        'ADT': {
            'count': 2,
            'weight': (23., 'kg'),
            'length': (70., 'cm'),
            'width': (60., 'cm'),
            'height': (28., 'cm'),
        },
        'CHD': {
            'count': 2,
            'weight': (23., 'kg'),
            'length': (70., 'cm'),
            'width': (60., 'cm'),
            'height': (28., 'cm'),
        },
        'INF': BusinessLuggageInfo.infants_luggage,
    }

    LUGGAGE_OTHER = {
        'description': LUGGAGE_DESCRIPTION,
        'ADT': adt_chd_luggage_other,
        'CHD': adt_chd_luggage_other,
        'INF': BusinessLuggageInfo.infants_luggage,
    }

    CARRY_ON = ComfortLuggageInfo.CARRY_ON


FARES = {
    # 'econom': {
    #     'cabin': 'Y',
    #     'travel_cabin': 'Y',
    # 'groups': {
    'econom-promo': {
        'classes': {'R'},
        'brands': {'EP'},
        'is_hit': True,
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['RSX', 'RSO'],
                '_weight': 110
            },
        ],
        'combinations': {'EP'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "", "text": _("ndc.text.fares.info.econom-promo.line1")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-promo.line2")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-promo.line3")},
            {"link": "", "text": _("ndc.text.fares.info.econom-promo.line4")},
            {"link": "", "text": _("ndc.text.fares.info.econom-promo.line5")}
        ],
        'exclusions': {
            ("SVOKZN", "VKOKZN", "KZNSVO", "KZNVKO", "SVOROV", "VKOROV", "ROVSVO", "ROVVKO", "KHVUUS",
             "UUSKHV")
            : {
                'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.econom-promo-exclude.line1")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-promo-exclude.line2")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-promo-exclude.line3")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-promo-exclude.line4")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-promo-exclude.line5")}
                ],
            }
        },
    },
    'econom-budget': {
        'classes': {'E', 'N', 'Q', 'T'},
        'brands': {'ES', 'ER'},

        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['QVU', 'QVO', 'TVU', 'TVO', 'EVU', 'EVO', 'NVU', 'NVO'],
                'miles_percent_text': _(u'75 %'),
                '_weight': 120
            },
            {
                'fare_base_prefix': ['YVU', 'YVO', 'BVU', 'BVO', 'MVU', 'MVO', 'UVU', 'UVO', 'KVU', 'KVO', 'HVU', 'HVO', 'LVU', 'LVO'],
                'miles_percent_text': _(u'125 %'),
                '_weight': 130
            },
        ],
        'combinations': {'ES', 'ER'},

        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
        'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.econom-budget.line1")},
                    {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-budget.line2")},
                    {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-budget.line3")},
                    {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-budget.line4")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-budget.line5")}
                ],
        'exclusions': {
            ("SVOKZN", "VKOKZN", "KZNSVO", "KZNVKO", "SVOROV", "VKOROV", "ROVSVO", "ROVVKO", "KHVUUS",
             "UUSKHV")
            : {
                'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.econom-budget-exclude.line1")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-budget-exclude.line2")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-budget-exclude.line3")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-budget-exclude.line4")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-budget-exclude.line5")}
                ],
            },
        }
    },
    'econom-optimum': {
        'classes': {'H', 'K', 'L', 'M', 'U'},
        'brands': {'EC'},
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'с доплатой'),
                'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['MFX', 'MFL', 'UFX', 'UFL', 'KFX', 'KFL', 'LFX', 'LFL', 'HFX', 'HFL', 'QCL', 'QCO',
                                     'TCL', 'TCO', 'ECL', 'ECO', 'NCL', 'NCO', ],
                'miles_percent_text': _(u'100 %'),
                '_weight': 140
            },
            {
                'fare_base_prefix': ['YCL', 'YCO', 'BCL', 'BCO', 'MCL', 'MCO', 'UCL', 'UCO', 'KCL', 'KCO', 'HCL', 'HCO', 'LCL', 'LCO'],
                'miles_percent_text': _(u'150 %'),
                '_weight': 150
            },
        ],
        'combinations': {'EC', 'CC', 'BC'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "", "text": _("ndc.text.fares.info.econom-optimum.line1")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-optimum.line2")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-optimum.line3")},
            {"link": "", "text": _("ndc.text.fares.info.econom-optimum.line4")},
            {"link": "", "text": _("ndc.text.fares.info.econom-optimum.line5")}
        ],
        'exclusions': {
            ("SVOKZN", "VKOKZN", "KZNSVO", "KZNVKO", "SVOROV", "VKOROV", "ROVSVO", "ROVVKO", "KHVUUS",
             "UUSKHV")
            : {
                'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.econom-optimum-exclude.line1")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-optimum-exclude.line2")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-optimum-exclude.line3")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-optimum-exclude.line4")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-optimum-exclude.line5")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-optimum-exclude.line6")}
                ],
            },
        }
    },
    'econom-status': {
        'classes': {'B', 'Y'},
        'brands': {'EF', 'EL'},
        'exchange_text': _(u'бесплатно'),
        'refund_text': _(u'бесплатно'),
        'luggage_text': {
            'ADT': _(u'2 место'),
            'CHD': _(u'2 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'доступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['QFM', 'QFO', 'TFM', 'TFO', 'EFM', 'EFO', 'NFM', 'NFO'],
                'miles_percent_text': _(u'150 %'),
                '_weight': 160
            },
            {
                'fare_base_prefix': ['YFM', 'YFO', 'BFM', 'BFO', 'MFM', 'MFO', 'UFM', 'UFO', 'KFM', 'KFO', 'HFM', 'HFO', 'LFM', 'LFO'],
                'miles_percent_text': _(u'200 %'),
                '_weight': 170
            },
        ],
        'combinations': {'EF', 'CF', 'BF', 'EL', 'CL', 'BL'},
        'luggage': EconomLuggageInfo.LUGGAGE_PREMIUM,
        'carryon': EconomLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "", "text": _("ndc.text.fares.info.econom-status.line1")},
            {"link": "", "text": _("ndc.text.fares.info.econom-status.line2")},
            {"link": "", "text": _("ndc.text.fares.info.econom-status.line3")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-status.line4")},
            {"link": "", "text": _("ndc.text.fares.info.econom-status.line5")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.econom-status.line6")},
            {"link": "", "text": _("ndc.text.fares.info.econom-status.line7")}
        ],
        'exclusions': {
            ("SVOKZN", "VKOKZN", "KZNSVO", "KZNVKO", "SVOROV", "VKOROV", "ROVSVO", "ROVVKO", "KHVUUS",
             "UUSKHV")
            : {
                'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.econom-status-exclude.line1")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-status-exclude.line2")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-status-exclude.line3")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-status-exclude.line4")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-status-exclude.line5")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-status-exclude.line6")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.econom-status-exclude.line7")}
                ],
            },
        }
    },
    'econom-flat': {
        'classes': {'B', 'T'},
        'brands': {'BU', 'FT'},
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'с доплатой'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['TFX', 'NFX'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 180
            },
            {
                'fare_base_prefix': ['BPX'],
                'miles_percent_text': _(u'25 %'),
                '_weight': 190
            },
        ],
        'combinations': {'BU', 'FT'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
        'exclusions': {
            ("SVOSIP", "SIPSVO", "SVOKGD", "KGDSVO", "SVOVVO", "VVOSVO", "SVOKHV", "KHVSVO", "SVOUUS", "UUSSVO",
             "SVOPKC", "PKCSVO", "SVOGDX", "GDXSVO")
            : {
                'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.econom-flat-exclude.line1")},
                    {"link": "http://www.aeroflot.ru/{lang}/sabre/manual_tariffs/new_rules",
                     "text": _("ndc.text.fares.info.econom-flat-exclude.line2")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-flat-exclude.line3")},
                    {"link": "", "text": _("ndc.text.fares.info.econom-flat-exclude.line4")},
                ],
            },
        }
    },

    'econom-award': {
        'classes': {'X'},
        'brands': {'AE', 'FE'},
        'is_award': True,
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['X'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 210
            },
        ],
        'combinations': {'AE', 'FE'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
    },
    'econom-lightaward': {
        'classes': {'X'},
        'brands': {'SE', 'GE'},
        'is_award': True,
        'is_hit': True,
        'skip_search_by_class': True,
        'exchange_text': _(u'запрещен'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['X'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 210
            },
        ],
        'combinations': {'SE', 'GE'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
    },
    'RE': {
        'classes': {'R'},
        'brands': {'RE'},
        'is_hit': True,
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['R'],
                'miles_percent_text': _(u'25 %'),
                '_weight': 115
            }
        ],
        'combinations': {'RE'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON
    },
    'NE-EE-TE-QE': {
        'classes': {'E', 'N', 'Q', 'T'},
        'brands': {'NE', 'EE', 'TE', 'QE'},
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'недоступен'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': {'E', 'N', 'Q', 'T'},
                'miles_percent_text': _(u'75 %'),
                '_weight': 250
            },
        ],
        'combinations': {'NE', 'EE', 'TE', 'QE', 'LE', 'HE', 'KE', 'UE', 'ME', 'BE', 'YE', 'ZB', 'IB', 'DB', 'CB', 'JB', 'ZE', 'IE', 'DE', 'CE', 'JE'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
    },
    'LE-HE-KE-UE-ME': {
        'classes': {'H', 'K', 'L', 'M', 'U'},
        'brands': {'LE', 'HE', 'KE', 'UE', 'ME'},
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'с доплатой'),
        'luggage_text': {
            'ADT': _(u'1 место'),
            'CHD': _(u'1 место'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'доступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': {'H', 'K', 'L', 'U'},
                'miles_percent_text': _(u'150 %'),
                '_weight': 251
            },
            {
                'fare_base_prefix': {'M'},
                'miles_percent_text': _(u'150 %'),
                '_weight': 252
            },
        ],
        'combinations': {'NE', 'EE', 'TE', 'QE', 'LE', 'HE', 'KE', 'UE', 'ME', 'BE', 'YE', 'ZB', 'IB', 'DB', 'CB', 'JB', 'ZE', 'IE', 'DE', 'CE', 'JE'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
    },
    'BE-YE': {
        'classes': {'B', 'Y'},
        'brands': {'BE', 'YE'},
        'exchange_text': _(u'бесплатно'),
        'refund_text': _(u'с доплатой'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'доступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': {'B'},
                'miles_percent_text': _(u'200 %'),
                '_weight': 253
            },
            {
                'fare_base_prefix': {'Y'},
                'miles_percent_text': _(u'200 %'),
                '_weight': 253
            },
        ],
        'combinations': {'NE', 'EE', 'TE', 'QE', 'LE', 'HE', 'KE', 'UE', 'ME', 'BE', 'YE', 'ZB', 'IB', 'DB', 'CB', 'JB', 'ZE', 'IE', 'DE', 'CE', 'JE'},
        'luggage': EconomLuggageInfo.LUGGAGE_OTHER,
        'carryon': EconomLuggageInfo.CARRY_ON,
    },
    # },
    # },
    # 'comfort': {
    #     'cabin': 'S',
    #     'travel_cabin': 'W',
    #     'groups': {
    'comfort-optimum': {
        'classes': {'A', 'S'},
        'brands': {'CC'},
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'с доплатой'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['WCL', 'WCO', 'SCL', 'SCO', 'ACL', 'ACO'],
                'miles_percent_text': _(u'150 %'),
                '_weight': 310
            },
        ],
        'combinations': {'CC', 'EC', 'BC'},
        'luggage': ComfortLuggageInfo.LUGGAGE,
        'carryon': ComfortLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "", "text": _("ndc.text.fares.info.comfort-optimum.line1")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-optimum.line2")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.comfort-optimum.line3")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-optimum.line4")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-optimum.line5")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-optimum.line6")},
        ],
    },
    'comfort-premium': {
        'classes': {'W'},
        'brands': {'CF', 'CL'},
        'exchange_text': _(u'бесплатно'),
        'refund_text': _(u'бесплатно'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'доступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['WFM', 'WFO', 'SFM', 'SFO', 'AFM', 'AFO'],
                'miles_percent_text': _(u'200 %'),
                '_weight': 320
            },
        ],
        'combinations': {'EF', 'CF', 'BF', 'EL', 'CL', 'BL'},
        'luggage': ComfortLuggageInfo.LUGGAGE,
        'carryon': ComfortLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line1")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line2")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line3")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line4")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line5")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.comfort-premium.line6")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line7")},
            {"link": "", "text": _("ndc.text.fares.info.comfort-premium.line8")},
        ],
    },
    'comfort-award': {
        'classes': {'F'},
        'brands': {'AC', 'FC'},
        'is_award': True,
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['F'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 420
            },
        ],
        'combinations': {'AC', 'FC'},
        'luggage': ComfortLuggageInfo.LUGGAGE,
        'carryon': ComfortLuggageInfo.CARRY_ON,
    },
    'comfort-lightaward': {
        'classes': {'F'},
        'brands': {'SC', 'GC'},
        'is_award': True,
        'is_hit': True,
        'skip_search_by_class': True,
        'exchange_text': _(u'запрещен'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['F'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 410
            },
        ],
        'combinations': {'SC', 'GC'},
        'luggage': ComfortLuggageInfo.LUGGAGE,
        'carryon': ComfortLuggageInfo.CARRY_ON,
    },
    # },
    # },
    # 'business': {
    #     'cabin': 'C',
    #     'travel_cabin': 'J',
    #     'groups': {
    'business-optimum': {
        'classes': {'I', 'Z'},
        'brands': {'BC'},
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'с доплатой'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['ICL', 'ICO', 'ZCL', 'ZCO'],
                'miles_percent_text': _(u'150 %'),
                '_weight': 510
            },
            {
                'fare_base_prefix': ['JCL', 'JCO', 'CCL', 'CCO', 'DCL', 'DCO'],
                'miles_percent_text': _(u'200 %'),
                '_weight': 520
            },
        ],
        'combinations': {'EC', 'CC', 'BC'},
        'luggage': BusinessLuggageInfo.LUGGAGE,
        'carryon': BusinessLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.business-optimum.line1")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line2")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.business-optimum.line3")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line4")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line5")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line6")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line7")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line8")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line9")},
            {"link": "", "text": _("ndc.text.fares.info.business-optimum.line10")}
        ],
        'exclusions': {
            ("SVOKZN", "VKOKZN", "KZNSVO", "KZNVKO", "SVOROV", "VKOROV", "ROVSVO", "ROVVKO", "KHVUUS",
             "UUSKHV")
            : {
                'additional-info': [
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line1")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line2")},
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.business-optimum-exclude.line3")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line4")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line5")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line6")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line7")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line8")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line9")},
                    {"link": "", "text": _("ndc.text.fares.info.business-optimum-exclude.line10")}
                ],
            },
        }
    },
    'business-status': {
        'classes': {'C', 'D', 'J'},
        'brands': {'BF', 'BL'},
        'exchange_text': _(u'бесплатно'),
        'refund_text': _(u'бесплатно'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['IFM', 'IFO', 'ZFM', 'ZFO'],
                'miles_percent_text': _(u'200 %'),
                '_weight': 530
            },
            {
                'fare_base_prefix': ['JFM', 'JFO', 'CFM', 'CFO', 'DFM', 'DFO'],
                'miles_percent_text': _(u'250 %'),
                '_weight': 540
            },
        ],
        'combinations': {'EF', 'CF', 'BF', 'EL', 'CL', 'BL'},
        'luggage': BusinessLuggageInfo.LUGGAGE,
        'carryon': BusinessLuggageInfo.CARRY_ON,
        'additional-info': [
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.business-status.line1")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line2")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line3")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line4")},
            {"link": "https://www.aeroflot.ru/{lang}/information/purchase/rate/fare_rules", "text": _("ndc.text.fares.info.business-status.line5")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line6")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line7")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line8")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line9")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line10")},
            {"link": "", "text": _("ndc.text.fares.info.business-status.line11")}
        ],
        'exclusions': {
            ("SVOKZN", "VKOKZN", "KZNSVO", "KZNVKO", "SVOROV", "VKOROV", "ROVSVO", "ROVVKO", "KHVUUS",
             "UUSKHV")
            : {
                'additional-info': [
                    {"link": "http://www.aeroflot.ru/{lang}/important_information/new_kzn_rov_hbr_uus_rules", "text": _("ndc.text.fares.info.business-status-exclude.line1")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line2")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line3")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line4")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line5")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line6")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line8")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line9")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line10")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line11")},
                    {"link": "", "text": _("ndc.text.fares.info.business-status-exclude.line12")}
                ],
            },
        }
    },
    'business-award': {
        'classes': {'O'},
        'brands': {'AB', 'FB'},
        'is_award': True,
        'exchange_text': _(u'с доплатой'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['O'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 620
            },
        ],
        'combinations': {'AB', 'FB'},
        'luggage': BusinessLuggageInfo.LUGGAGE,
        'carryon': BusinessLuggageInfo.CARRY_ON,
    },
    'business-lightaward': {
        'classes': {'O'},
        'brands': {'GB'},
        'is_award': True,
        'is_hit': True,
        'skip_search_by_class': True,
        'exchange_text': _(u'запрещен'),
        'refund_text': _(u'запрещен'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': ['O'],
                'miles_percent_text': _(u'0 %'),
                '_weight': 610
            },
        ],
        'combinations': {'SB', 'GB'},
        'luggage': BusinessLuggageInfo.LUGGAGE,
        'carryon': BusinessLuggageInfo.CARRY_ON,
    },

    'IB-ZB': {
        'classes': {'I', 'Z'},
        'brands': {'IB', 'ZB', 'IE', 'ZE'},
        'exchange_text': _(u'бесплатно'),
        'refund_text': _(u'бесплатно'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': {'I', 'Z'},
                'miles_percent_text': _(u'150 %'),
                '_weight': 700
            },
        ],
        'combinations': {'NE', 'EE', 'TE', 'QE', 'LE', 'HE', 'KE', 'UE', 'ME', 'BE', 'YE', 'ZB', 'IB', 'DB', 'CB', 'JB', 'ZE', 'IE', 'DE', 'CE', 'JE'},
        'luggage': BusinessLuggageInfo.LUGGAGE,
        'carryon': BusinessLuggageInfo.CARRY_ON,
    },
    'CB-DB-JB': {
        'classes': {'C', 'D', 'J'},
        'brands': {'CB', 'DB', 'JB', 'CE', 'DE', 'JE'},
        'exchange_text': _(u'бесплатно'),
        'refund_text': _(u'бесплатно'),
        'luggage_text': {
            'ADT': _(u'2 места'),
            'CHD': _(u'2 места'),
            'INF': _(u'1 место'),
        },
        'miles_upgrade_text': _(u'недоступен'),
        'choose_seat_text': _(u'бесплатно'),
        'fare_bases_rules': [
            {
                'fare_base_prefix': {'C', 'D', 'J'},
                'miles_percent_text': _(u'250 %'),
                '_weight': 701
            },
        ],
        'combinations': {'NE', 'EE', 'TE', 'QE', 'LE', 'HE', 'KE', 'UE', 'ME', 'BE', 'YE', 'ZB', 'IB', 'DB', 'CB', 'JB', 'ZE', 'IE', 'DE', 'CE', 'JE'},
        'luggage': BusinessLuggageInfo.LUGGAGE,
        'carryon': BusinessLuggageInfo.CARRY_ON,
    },
    # },
    # },
}
