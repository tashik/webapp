#!/usr/bin/env bash

pybabel extract --no-wrap --sort-output --no-location -F scripts/babel-extract.cfg -k L_ -k _l -o locales/messages.pot .
