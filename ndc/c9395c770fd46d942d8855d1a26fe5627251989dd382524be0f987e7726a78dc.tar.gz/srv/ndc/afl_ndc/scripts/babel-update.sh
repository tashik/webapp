#!/usr/bin/env bash

# --------------------------- FUNCTIONS -------------------------------------
update(){
    pybabel update -D $1 -i ${LOCALES_DIR}/messages.pot -d locales -o ${LOCALES_DIR}/$1.po -l en -N --previous
}

# --------------------------- DEFAULTS -------------------------------------
LOCALES_DIR=locales


# --------------------------- void main(void) -------------------------------------

update ru
update en
update de
update es
update fr
update it
update ja
update ko
update zh

echo Complete!
