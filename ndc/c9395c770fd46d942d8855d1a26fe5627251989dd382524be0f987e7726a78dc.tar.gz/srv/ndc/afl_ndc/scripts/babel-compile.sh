#!/usr/bin/env bash

# --------------------------- FUNCTIONS -------------------------------------
remove_poedit(){
    echo rm -f ${LOCALES_DIR}/*.poedit.po
    rm -f ${LOCALES_DIR}/*.poedit.po
}

compile_po(){
    echo compiling $1 ...
    cp ${LOCALES_DIR}/$1.po ${LOCALES_DIR}/$1.poedit.po
    msgcat --no-wrap ${LOCALES_DIR}/$1.poedit.po -o ${LOCALES_DIR}/$1.po
    pybabel compile -i ${LOCALES_DIR}/$1.po -o ${LOCALES_DIR}/$1/LC_MESSAGES/messages.mo
}

# --------------------------- DEFAULTS -------------------------------------
LOCALES_DIR=locales


# --------------------------- void main(void) -------------------------------------
remove_poedit

compile_po ru
compile_po en
compile_po de
compile_po es
compile_po fr
compile_po it
compile_po ja
compile_po ko
compile_po zh

remove_poedit

echo.
echo Complete!
