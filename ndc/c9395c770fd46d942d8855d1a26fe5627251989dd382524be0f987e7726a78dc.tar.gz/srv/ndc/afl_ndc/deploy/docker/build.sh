#!/bin/bash
set -eu
###############################################################################
. ./build-config.sh

echo "[..] APP_REPO = $APP_REPO"
echo "[..] APP_REV  = $APP_REV"
echo "[..] Building image $FULL_NAME"

###############################################################################
mkdir -p checkout
svn_checkout "$APP_REPO" checkout/afl_ndc "$APP_REV"

tar c --exclude .svn Dockerfile checkout files | \
    docker build -t $FULL_NAME -t ndc:$DOCKER_TAG -t ndc --force-rm \
        --label afl_ndc_repo=$(get_repo_url checkout/afl_ndc) \
        --label afl_ndc_rev=$(svnversion checkout/afl_ndc) \
        -



