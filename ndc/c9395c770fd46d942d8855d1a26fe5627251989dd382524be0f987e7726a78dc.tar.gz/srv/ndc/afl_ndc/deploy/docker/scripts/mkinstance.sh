#!/bin/bash
set -eu
###############################################################################
# !!! Слешом директории не закрывать
WORKDIR=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)
CONFIG_REPO="https://svn.com.spb.ru/afl_ndc/site-config"
APP_UID=2007
APP_NAME="ndc"
APP_USER="docker_ndc"
APP_HOME=$(cd "${WORKDIR}/.." && pwd)
APP_CONF="$APP_HOME/site-config"
INSTANCE_NUMBER=${1:-}
CLUSTER=${2:-}

###############################################################################
echo "[..] APP_NAME=${APP_NAME}"
echo "[..] APP_USER=${APP_USER}"
echo "[..] APP_HOME=${APP_HOME}"
echo "[..] APP_CONF=${APP_CONF}"


cd "${APP_HOME}" || exit 1


mkdir -p  "${APP_HOME}/cache"
chmod 750 "${APP_HOME}"


### DOCKER
which docker >/dev/null || { echo "[EE] Docker not installed"; exit 1; }


### INSTANCE_UID
DOCKREMAP_UID=`cat /etc/subuid | grep dockremap | cut -d':' -f2`
if [ -z "$DOCKREMAP_UID" ] || ! echo "$DOCKREMAP_UID" | grep -iqE "^[0-9]+$"; then
  echo "[EE] Incorrect DOCKREMAP_UID"
  exit 1
fi
INSTANCE_UID=$(( $DOCKREMAP_UID + ${APP_UID} ))
echo "[..] INSTANCE_UID=$INSTANCE_UID"


### INSTANCE_GID
DOCKREMAP_GID=`cat /etc/subgid | grep dockremap | cut -d':' -f2`
if [ -z "$DOCKREMAP_GID" ] || ! echo "$DOCKREMAP_GID" | grep -iqE "^[0-9]+$"; then
  echo "[EE] Incorrect DOCKREMAP_GID"
  exit 1
fi
INSTANCE_GID=$(( $DOCKREMAP_GID + ${APP_UID} ))
echo "[..] INSTANCE_GID=$INSTANCE_GID"

chown $INSTANCE_UID:$INSTANCE_GID "$APP_HOME"
chown $INSTANCE_UID:$INSTANCE_GID "$APP_HOME/cache"

if ! grep -q "^${APP_USER}:" /etc/passwd; then
    groupadd -g $INSTANCE_GID "${APP_USER}"
    useradd "${APP_USER}" -M --uid $INSTANCE_UID --gid $INSTANCE_GID -d "${APP_HOME}" -s /bin/bash
    echo "[OK] APP USER created '${APP_USER}'"
else
    echo "[WW] APP USER already exist '${APP_USER}'"
fi

echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"

### SVN
SVN_ADDITIONAL=
: ${svn_username:=}
: ${svn_password:=}
if [[ -n "${svn_username}" && -n "${svn_password}" ]]; then
    SVN_ADDITIONAL="--username="${svn_username}" --password="${svn_password}" --trust-server-cert --non-interactive"
fi
if [ -d "${APP_CONF}" ]; then
    svn sw "$CONFIG_REPO" "$APP_CONF" ${SVN_ADDITIONAL}
else
    svn co "$CONFIG_REPO" "$APP_CONF" ${SVN_ADDITIONAL}
fi


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"

### CLUSTER
CLUSTER_INF_FILE="${APP_HOME}/.cluster"
if [ -f "${CLUSTER_INF_FILE}" ]; then
    # auto detect
    CLUSTER=$(head -n1 "${CLUSTER_INF_FILE}")
    echo "[..] AUTODETECT CLUSTER=${CLUSTER}"
else
    if [ -z "${CLUSTER}" ]; then
        # set manually
        cd "${APP_CONF}"
        find ./ -maxdepth 1 -type d -not -name '\.*' -printf "%f\n" | sort
        read -p "Enter cluster name:" CLUSTER
    fi
    # argument set
    echo "[..] CLUSTER=${CLUSTER}"
fi

CLUSTER_DIR="${APP_CONF}/${CLUSTER}"
cd "${CLUSTER_DIR}"

CLUSTER_PASSWD_FILE="${CLUSTER_DIR}/passwd.py"
if [ ! -f "${CLUSTER_PASSWD_FILE}" ]; then
    cp "${APP_CONF}/passwd.py.example" "${CLUSTER_PASSWD_FILE}"
else
    echo "[WW] Already exist '${CLUSTER_PASSWD_FILE}'"
fi
chmod 600 "${CLUSTER_PASSWD_FILE}"
chown $INSTANCE_UID:$INSTANCE_GID "${CLUSTER_PASSWD_FILE}"


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"

### INSTANCE
if [ -z "$INSTANCE_NUMBER" ]; then
    cd "${APP_HOME}"
    find ./ -maxdepth 1 -type d -name 'i[0-9]+' -printf "%f\n" | sort
    read -p "Enter INSTANCE_NUMBER:" INSTANCE_NUMBER
fi
echo "[..] INSTANCE_NUMBER=$INSTANCE_NUMBER"
if ! echo "${INSTANCE_NUMBER}" | grep -iqE "^[0-9]+$"; then
    echo "[EE] Incorrect INSTANCE_NUMBER"
    exit 1
fi

INSTANCE_HOME="$APP_HOME/i${INSTANCE_NUMBER}"
echo "[..] INSTANCE_HOME=$INSTANCE_HOME"

if [ -d "$INSTANCE_HOME" ]; then
    echo "[WW] Already exist '${INSTANCE_HOME}'"
fi

mkdir -p "${INSTANCE_HOME}/log"
chown -R $INSTANCE_UID:$INSTANCE_GID "${INSTANCE_HOME}"


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"

### INIT.D
INITD_SRC="${WORKDIR}/${CLUSTER}/initd.sh"
INITD_TRG="/etc/init.d/${CLUSTER}_${APP_NAME}_${INSTANCE_NUMBER}"
if [ ! -f "${INITD_SRC}" ]; then
    echo "[EE] INIT.D src not found '$INITD_SRC'"
    exit 1
elif [ ! -e "${INITD_TRG}" ]; then
    cp "${INITD_SRC}" "${INITD_TRG}"
    echo "[OK] INIT.D created '${INITD_TRG}'"
else
    echo "[WW] INIT.D already exist '${INITD_TRG}'"
fi

### CLUSTER
if [ ! -f "${CLUSTER_INF_FILE}" ]; then
    # save cluster info in end
    echo "${CLUSTER}" > "${CLUSTER_INF_FILE}"
    echo "[OK] CLUSTER INFO SAVED '$CLUSTER_INF_FILE'"
fi


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"

### DOCKER IMAGE
DOCKER_IMAGE=`grep "DOCKER_IMAGE=" "${INITD_SRC}" | head -n1 | cut -d'=' -f2 | tr -d "\"" | tr -d "'" | tr -d " "`
if [ -z "${DOCKER_IMAGE}" ]; then
    echo "[EE] Not found DOCKER_IMAGE in INIT.D script '$INITD_SRC'"
    exit 1
fi
echo "[..] Update DOCKER_IMAGE=$DOCKER_IMAGE"

set +e
docker login  "$DOCKER_IMAGE"
docker pull   "$DOCKER_IMAGE"
docker logout "$DOCKER_IMAGE"
set -e


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"

### Done
echo "[OK] Done!"
