#!/bin/bash
### BEGIN INIT INFO
# Provides:       AFL_NDC
# Required-Start: docker
# Required-Stop:  docker
# Default-Start:  2 3 4 5
# Default-Stop:   0 1 6
# Description:    Docker container AFL_NDC
### END INIT INFO

### Устанавливаемые переменные
DOCKER_IMAGE="registry.com.spb.ru/ndc:test"
APP_NAME="ndc"
APP_HOME="/srv/prod_${APP_NAME}"
CLUSTER_PORT=6379 # !!! Определяется для каждого CLUSTER'a т.к. может быть занят на других площадках
PBUS_HOST="afl-test32"
WAIT_STOPPING=60 # in sec
#
### Рассчитываемые переменные
DOCKER_HOST=`/sbin/ifconfig | grep docker0 -A1 | grep -oE "1.2\S+"`
if [ -z $DOCKER_HOST ]; then
    echo "[EE] Incorrect DOCKER HOST"
    exit 1
fi
CLUSTER=$(basename "$0" | grep -oE "^[0-9a-zA-Z]+")
INSTANCE_NUMBER=$(basename "$0" | grep -oE "_[0-9]+$" | tr -d '_')
if [[ -z $CLUSTER || -z $INSTANCE_NUMBER ]]; then
    echo "[EE] You need call executable script in format: <CLUSTER>_<APP_NAME>_<INSTANCE_NUMBER>"
    exit 1
fi
INSTANCE_PORT=$(( $CLUSTER_PORT + $INSTANCE_NUMBER ))
INSTANCE_NAME="${CLUSTER}_${APP_NAME}${INSTANCE_NUMBER}"
INSTANCE_HOME="${APP_HOME}/${APP_NAME}${INSTANCE_NUMBER}"
# Привязка к ядру ЦП
INSTANCE_CPUS='' # default: ''
_TMP=`grep -E "^$INSTANCE_NAME=([0-9][0-9,-]*)$" /etc/docker/cpuset 2>/dev/null | head -n1 | awk -F'=' '{print $2}'`
if [ ! -z $_TMP ]; then
    INSTANCE_CPUS="--cpuset-cpus=${_TMP}"
fi

export RETVAL=0


start() {
    echo "[..] Starting: $INSTANCE_NAME --port=$INSTANCE_PORT $INSTANCE_CPUS ($DOCKER_IMAGE)"
    status
    rc=$?
    local start_time=$(date +"%Y-%m-%dT%H:%M:%S.%N")

    if [ $rc -eq 0 ]; then
        echo "[OK] $INSTANCE_NAME already started"
        return 0
    elif [ $rc -eq 1 ]; then
        docker run --rm -d --name $INSTANCE_NAME \
            --ulimit nofile=65536:65536 $INSTANCE_CPUS \
            -p $INSTANCE_PORT:6380 \
            -v "$INSTANCE_HOME/log":"/srv/ndc/log" \
            -v "$APP_HOME/deployment-config":"/cluster-config" \
            -e INSTANCE_NUMBER=$INSTANCE_NUMBER \
            -e INSTANCE_PORT=$INSTANCE_PORT \
            --add-host dockerhost:$DOCKER_HOST \
            $DOCKER_IMAGE >/dev/null
        RETVAL=$?
    else
        docker start $INSTANCE_NAME >/dev/null
        RETVAL=$?
    fi
    if [ $RETVAL -eq 0 ] && spinner 6 && status; then
        echo "[OK] $INSTANCE_NAME started"
        return $RETVAL
    else
        echo "[EE] $INSTANCE_NAME not started"
        docker logs --since=$start_time $INSTANCE_NAME
        RETVAL=1
        return $RETVAL
    fi
}


stop() {
    echo "[..] Stopping: $INSTANCE_NAME"
    docker exec -i $INSTANCE_NAME /bin/sh -c 'pkill -INT -F "$APPDIR/pid/ws.pid"' &
    cnt=0
    while [ $cnt -lt $WAIT_STOPPING ]; do
        if ! status; then
            echo "[OK] $INSTANCE_NAME stopped"
            return 0
        fi
        sleep 1
        cnt=$(( $cnt + 1 ))
        spinner
    done
    echo "[WW] $INSTANCE_NAME not stopped"
    RETVAL=1
    return $RETVAL
}


reload() {
    echo "[..] Reloading: $INSTANCE_NAME"
    #
    if [ -z "$1" ] || ! echo "$1" | grep -iqE "^[0-9]+$" || [ "$1" -eq $INSTANCE_NUMBER ]; then
        echo "[EE] Incorrect INSTANCE NUMBER"

        RETVAL=1
        return $RETVAL
    fi
    RESERVE_PORT=$(( $CLUSTER_PORT + $1 ))
    if ! nc -w5 127.0.0.1 $RESERVE_PORT </dev/null ; then
        echo "[EE] Failed access RESERVE PORT=$RESERVE_PORT"
        RETVAL=1
        return $RETVAL
    fi
    #
    if ! iptables-save | grep -q "REDIRECT --to-ports $RESERVE_PORT"; then
        set -e
        iptables -t nat -I PREROUTING '!' -s $PBUS_HOST -p tcp --dport $INSTANCE_PORT -j REDIRECT --to-ports $RESERVE_PORT
        set +e
        echo "[OK] IPTABLES set REDIRECT $INSTANCE_PORT->$RESERVE_PORT"
    fi
    #
    if status; then
        echo "[..] Waiting for completion requests (60 sec) ..."
        spinner 60
        stop || { RETVAL=1; return $RETVAL; }
        sleep 1
    fi
    start || { RETVAL=1; return $RETVAL; }
    while ! nc -w5 -v 127.0.0.1 $INSTANCE_PORT </dev/null ; do sleep 2 ; done
    sleep 1
    if iptables-save | grep -q "REDIRECT --to-ports $RESERVE_PORT"; then
        set -e
        iptables -t nat -D PREROUTING '!' -s $PBUS_HOST -p tcp --dport $INSTANCE_PORT -j REDIRECT --to-ports $RESERVE_PORT
        set +e
        echo "[OK] IPTABLES remove REDIRECT $INSTANCE_PORT->$RESERVE_PORT"
    fi
    echo "[OK] $INSTANCE_NAME reloaded"
}


kill() {
    echo "[..] Killing: $INSTANCE_NAME"
    docker kill "$INSTANCE_NAME"
    RETVAL=$?
    return $RETVAL
}


status() {
    rd=`docker ps -a -f name="^/$INSTANCE_NAME\$"`
    if echo "$rd" | grep -q "Up "; then
        # running
        return 0
    elif echo "$rd" | grep -q "$INSTANCE_NAME"; then
        # other
        return 2
    else
        # does not exist
        return 1
    fi
}


entry() {
    docker exec -i -t "$INSTANCE_NAME" /bin/bash
}


info() {
    if status; then
        echo "[II] $INSTANCE_NAME started ($DOCKER_IMAGE)"
    else
        echo "[II] $INSTANCE_NAME stopped ($DOCKER_IMAGE)"
    fi
    status
    rc=$?
    if [[ $rc -eq 1 ]]; then
         # Информация из образа
        _TMP=$DOCKER_IMAGE
    else
         # Информация из контейнера
        _TMP=$INSTANCE_NAME
    fi
    for X in $(docker inspect --format '{{ .Config.Labels }}' $_TMP); do
        echo ${X} | sed -e 's/\(map\[\|\]\)//g' | sort
    done
}


_SPINNER_CHR='/-\/'
_SPINNER_POS=0
spinner() {
    _SPINER_CNT=0
    _SPINER_MAX=${1:-1}
    while true; do
        _SPINNER_POS=$(( ($_SPINNER_POS + 1) %4 ))
        echo -ne "${_SPINNER_CHR:$_SPINNER_POS:1}" "\r"
        _SPINER_CNT=$(( $_SPINER_CNT + 1 ))
        [ $_SPINER_CNT -lt $_SPINER_MAX ] || break
        sleep 1
    done
    return 0
}


case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    restart)
        stop && { sleep 1;  start; }
        ;;
    reload|graceful)
        reload "$2"
        ;;
    kill)
        kill
        ;;
    status)
        status && exit 0 || exit $?
        ;;
    entry)
        entry
        ;;
    info)
        info
        ;;
    *)
        echo "Usage: ${0##*/} {start|stop|restart|(reload|graceful)|kill|status|entry|info}"
        RETVAL=1
esac

exit $RETVAL
