#!/bin/bash
set -eu
###############################################################################
. ./build-config.sh

echo "[..] NDCLIB_REPO          = $NDCLIB_REPO"
echo "[..] NDCLIB_REV           = $NDCLIB_REV"
echo "[..] NDCLIB_UBUNTU14_REPO = $NDCLIB_UBUNTU14_REPO"
echo "[..] NDCLIB_UBUNTU14_REV  = $NDCLIB_UBUNTU14_REV"
#echo "[..] NDCLIB_SRC_REPO      = $NDCLIB_SRC_REPO"
#echo "[..] NDCLIB_SRC_REV       = $NDCLIB_SRC_REV"

###############################################################################

cd ndc-libs
mkdir -p checkout
cd checkout

svn_checkout "$NDCLIB_REPO" afl_ndc-lib "$NDCLIB_REV"
svn_checkout "$NDCLIB_UBUNTU14_REPO" afl_ndc-lib-ubuntu14  "$NDCLIB_UBUNTU14_REV"

cd ..

tar c --exclude .svn Dockerfile checkout pydistutils.cfg | \
    docker build -t ndc-libs --force-rm \
                 --label afl_ndc_lib_rev=$(svnversion checkout/afl_ndc-lib) \
                 --label afl_ndc_lib_ubuntu14_rev=$(svnversion checkout/afl_ndc-lib-ubuntu14) \
                 -







