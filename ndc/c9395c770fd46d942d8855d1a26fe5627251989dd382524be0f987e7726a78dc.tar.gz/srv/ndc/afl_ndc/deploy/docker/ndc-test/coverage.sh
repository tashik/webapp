#!/bin/sh

cd $INSTANCE_HOME
python-coverage run /usr/bin/py.test --junitxml afl_ndc/log/test-report.xml afl_ndc
python-coverage xml --include="afl_ndc/*" --omit="afl_ndc/tests/*"  -i -o afl_ndc/log/coverage-report.xml
