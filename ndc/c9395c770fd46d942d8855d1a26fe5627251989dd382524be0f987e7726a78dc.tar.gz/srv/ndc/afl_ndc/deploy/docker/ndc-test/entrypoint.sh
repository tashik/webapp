#!/bin/bash -exu

mkdir -p /srv/ndc/log/{errors}
chown -R ndc /srv/ndc/log

if [[ -z "$@" ]]; then
    # default action
    exec su-exec ndc python -u /usr/bin/py.test $APPDIR
else
    # cutsom cmd (example: /bin/bash)
    exec su-exec ndc $@
fi
