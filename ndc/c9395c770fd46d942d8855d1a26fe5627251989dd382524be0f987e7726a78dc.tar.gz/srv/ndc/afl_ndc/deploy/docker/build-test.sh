#!/bin/bash
. ./build-config.sh

docker build -t registry.com.spb.ru/ndc-test:$DOCKER_TAG -t ndc-test ndc-test
