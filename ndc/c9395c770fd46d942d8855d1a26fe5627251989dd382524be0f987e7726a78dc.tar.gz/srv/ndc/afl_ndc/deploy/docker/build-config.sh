get_latest_revision() {
    [ -n "$1" ] || return 1
    local REPO="$1"
    svn info "$REPO" | grep 'Last Changed Rev:' | sed -e 's/^.*: //'
}

get_repo_url() {
    [ -n "$1" ] || return 1
    local DIR="$1"
    svn info "$DIR" | grep "^URL:" | awk '{print $2}'
}


# Переменные ниже можно переопределять своими значениями из окружения
# (пример: APP_REPO=https://svn.com.spb.ru/afl_ndc/trunk ./build.sh)

: ${APP_REPO:="https://svn.com.spb.ru/afl_ndc/trunk"}
: ${APP_REV:=$(get_latest_revision $APP_REPO)}
: ${DOCKER_TAG:=latest}

: ${NDCLIB_REPO:="https://svn.com.spb.ru/afl_ndc/lib"}
: ${NDCLIB_REV:=$(get_latest_revision "$NDCLIB_REPO")}
: ${NDCLIB_UBUNTU14_REPO:="https://svn.com.spb.ru/afl_ndc/lib-ubuntu14"}
: ${NDCLIB_UBUNTU14_REV:=$(get_latest_revision "$NDCLIB_UBUNTU14_REPO")}
#: ${NDCLIB_SRC_REPO:="https://svn.com.spb.ru/afl_ndc/lib-src"}
#: ${NDCLIB_SRC_REV:=$(get_latest_revision "$NDCLIB_SRC_REPO")}

# При разработке отключаем svn revert для сохранения локальных изменений
: ${NO_REVERT_ON_BUILD:=}
: ${APT_PROXY_URL:="http://afl-site2.com.spb.ru:3142"}
: ${REGISTRY:="registry.com.spb.ru"}

SHORT_NAME=ndc
FULL_NAME="$REGISTRY/$SHORT_NAME:$DOCKER_TAG"

svn_checkout() {
    [[ -n "$1" && -n "$2" && -n "$3" ]] || return 1
    local REPO="$1"
    local DIR="$2"
    local REV="$3"
    if [ -e "$DIR" ]; then
        svn sw "$REPO" "$DIR" -r"$REV"
        if [ -z $NO_REVERT_ON_BUILD ]; then
            svn revert -R "$DIR"
        fi
    else
        svn co "$REPO" "$DIR" "-r$REV"
    fi
}
