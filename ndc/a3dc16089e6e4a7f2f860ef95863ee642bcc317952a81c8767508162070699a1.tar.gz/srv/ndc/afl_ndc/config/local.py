# -*- coding: utf-8 -*-

DEBUG = True

SERVER_HOST = '127.0.0.1'  # Set real application server host
SERVER_PORT = 6380  # Set real application server port
SERVER_NAME = 'NDC server'

SB_SERVICE_HOST = 'afl-dev.test.aeroflot.ru'
SB_SERVICE_URL = 'https://%s/sb/booking/api/app/' % SB_SERVICE_HOST
SB_SERVICE_DOMAIN = None   # в случае если SB_SERVICE_HOST это ip-адрес
SB_SERVICE_DIGEST_URL = 'https://%s/sb/booking/api/device/' % SB_SERVICE_HOST
SB_APP_URL = 'https://%s/sb/app' % SB_SERVICE_HOST
SB_SERVICE_DIGEST_LOGIN = '############'
SB_SERVICE_DIGEST_PASSWORD = '############'
SB_MONITORING_URL = 'https://%s/sb/booking/api/app/settings' % SB_SERVICE_HOST  # URL для проверки работы SB

PMB_SERVICE_HOST = 'afl-dev.test.aeroflot.ru'
PMB_SERVICE_URL = 'https://{}/b/services/'.format(PMB_SERVICE_HOST)

# Настройки системы информации о заказе
ORDWS_SOAP_BASE_URL = 'https://test.paymentgate.ru/testaeroflot/webservices/orderInfo-ws'
ORDWS_SOAP_USER = 'ramax-api'
ORDWS_SOAP_PWD = 'ramax-api'

SUB_SERVICES = (
    # Поиск рейсов
    (SYS_NAME_SB, 'search', SB_SERVICE_DIGEST_URL + 'search/v1', SB_SERVICE_DOMAIN, ('digest', SB_SERVICE_DIGEST_LOGIN, SB_SERVICE_DIGEST_PASSWORD)),
    (SYS_NAME_SB, 'search_min_prices', SB_SERVICE_URL + 'search_min_prices/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'fare_rules', SB_SERVICE_URL + 'fare_rules/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'additional_info', 'https://www.aeroflot.ru/ws2/v.0.0.1/json/additional_info', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'miles', 'https://www.aeroflot.ru/partners/ws/v.0.0.2/json/miles', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'check_coupons', SB_SERVICE_URL + 'check_coupons/v1', SB_SERVICE_DOMAIN, None),
    # Бронирование билетов
    (SYS_NAME_SB, 'price', SB_SERVICE_DIGEST_URL + 'price/v1', SB_SERVICE_DOMAIN, ('digest', SB_SERVICE_DIGEST_LOGIN, SB_SERVICE_DIGEST_PASSWORD)),
    (SYS_NAME_SB, 'price_award', SB_SERVICE_URL + 'price_award/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'book', SB_SERVICE_URL + 'book/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'book_award', SB_SERVICE_URL + 'book_award/v1', SB_SERVICE_DOMAIN, None),
    # Управление бронированием
    (SYS_NAME_SB, 'pnr', SB_SERVICE_URL + 'pnr/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'pnr_search', SB_SERVICE_URL + 'pnr_search/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'seat_map', SB_SERVICE_URL + 'seat_map/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'choose_seat', SB_SERVICE_URL + 'choose_seat/v1', SB_SERVICE_DOMAIN, None),
    # (SYS_NAME_SB, 'meal', 'http://www.aeroflot.ru/ws2/v.0.0.1/meal', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'choose_meal', SB_SERVICE_URL + 'choose_meal/v1', SB_SERVICE_DOMAIN, None),
    # Обмен/возврат
    (SYS_NAME_SB, 'refund', SB_SERVICE_URL + 'refund/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'exchange_search', SB_SERVICE_URL + 'exchange_search/v1', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_SB, 'exchange', SB_SERVICE_URL + 'exchange/v1', SB_SERVICE_DOMAIN, None),

    (SYS_NAME_SB, 'settings', SB_SERVICE_URL + 'settings', SB_SERVICE_DOMAIN, None),
    (SYS_NAME_PMB, 'booking_v1', PMB_SERVICE_URL + 'v.1.0.0/booking', None, None),
)

# Использовать сервис ПМБ booking вместо сервиса SB pnr
USE_PMB_BOOKING_SERVICE = False

PROPAGATE_LOG = True  # Дублировать лог на экран/stdout
LOG_SETTINGS = {
    'dispatcher': logging.ERROR,
    'service': logging.INFO,
    'sb': logging.INFO,
    'pmb': logging.INFO,
}

SUPPORTED_SERVICES = ['services.afl.AirShoppingService', 'services.afl.FlightPriceService', 'services.afl.OrderCreateService']

# Валидация входящего запроса сервиса по XSD схеме
ENABLE_XSD_VALIDATION = True

# Минимальное время между прямым и обратным рейсами. Значение берется из админки SB
MIN_FORWARD_TO_RETURN_TIME = datetime.timedelta(minutes=60)  # Между прилетом рейса "туда" и вылетом рейса "обратно" должно быть не менее 1-го часа

# Макс. число тарифов при комбинации ответа SB search
SEARCH_MAX_COMBINED_PRICES = 100000

# Хэши для доступа к веб-сервисам мониторинга - история ретро, ошибки, и т.д.
# Для вычисления хэша используем команду: print hashlib.md5('LOGIN:aeroflot-digest:PASSWORD').hexdigest()
MONITORING_WS_DIGEST = {
    'mon-ws-client': '####',
}

SEARCH_COMBINER_ONLY_ONE_PRICE_FOR_OFFER = False
