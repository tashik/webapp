#!/bin/bash

if [[ -z "$@" ]]; then
    # default action
    mkdir -p "$INSTANCE_HOME/log/errors"
    python -u ws.py
else
    # cutsom cmd (example: /bin/bash)
    exec $@
fi

