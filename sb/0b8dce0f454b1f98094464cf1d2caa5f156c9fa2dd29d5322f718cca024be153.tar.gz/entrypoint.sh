#!/bin/bash -eu

if [[ -z "$@" ]]; then
    # default action
    mkdir -p "$INSTANCE_HOME/log/errors"
    mkdir -p "$INSTANCE_HOME/log/ga/archive"
    exec python -u ws.py
else
    # cutsom cmd (example: /bin/bash)
    exec $@
fi
