# -*- coding: utf-8 -*-

""" Сюда идут настройки, общие для кластера (за исключением паролей и секретных ключей).
    Настройки, вычисляемые по номеру инстанса, тоже живут здесь.
"""

import os
import sys
import datetime
import socket

INSTANCE_ID = '.dev'

USE_DB_CONNECTION = True #INSTANCE_NUMBER == 1

# Настройка cpconfig ----------------------------------------------------------
CPCONFIG = {
    'server.thread_pool': 8,        # Число создаваемых тредов для обработки запросов
    'engine.autoreload.on': True,   # Автоматически перезагружать приложение при изменении *py файлов
    'tools.sessions.timeout': 2*60, # Срок жизни сессии (в минутах)
    'tools.trusted_proxy.on': False,
    'tools.sessions.servers': ['memcached'],
    'engine.signal_handler.on': True,
}

# Настройки веб-сервера и сервера приложений ----------------------------------
SERVER_PORT = 7180  # Номер порта для прослушивания запросов
SERVER_HOST = '0.0.0.0'  # IP-адрес интерфейса для прослушивания запросов
SESSION_COOKIE_PREFIX = 'sb{}-'.format(INSTANCE_ID)
SYSTEM_INSTANCE_ID = 'SB{}'.format(INSTANCE_ID)

FALLBACK_LANGUAGES = ['en', 'ru']

NOTIFY_VOCABS_CACHE_DIR = APPDIR + '/log'
NOTIFY_SETTINGS_CACHE_DIR = APPDIR + '/log'
LOG_LEVEL = logging.DEBUG # Бирин

# Список IP-адресов прокси-серверов, запросы от которых считаются доверительными
PROXY_IP = ['127.0.0.1']


# Google Analytics ------------------------------------------------------------
GOOGLE_TAG_MANAGER_IDS = ('GTM-5ZKPBX', 'GTM-W89V4K')  # Идентификатор клиента для Google Tag Manager
GOOGLE_ANALYTICS_IDS   = ('UA-75201616-1', 'UA-25816578-3')
ENABLE_GOOGLE_TOOLS = True

# Настройки БД ----------------------------------------------------------------
POSTGRES_DSN = ''   # адрес БД берем из переменных окружения PGHOST, PGUSER, PGDATABASE

# Настройки взаимодействия с почтовыми сервисами ------------------------------
SMTP_SERVER = 'klaus.com.spb.ru' # Имя или IP-адрес smtp-сервера
SMTP_FROM = 'sb{}@aeroflot.test'.format(INSTANCE_ID) # !!!
SYSTEM_USER_EMAIL_ADDRESS = SMTP_FROM  # Email отправителя всех писем
# ADMIN_EMAIL = ['kmakarov@com.spb.ru', 'mikhail.birin@ramax.ru', ]  # Список email получателей писем с логами ошибок


# Настройки взаимодействия с сервисами SSO и ЛК и ПКЛ -------------------------
SSO_CLIENT_NAME = 'sb.dev'
SSO_SERVER_URL = 'http://aflcab-sso:7480'  # Внутренний адрес сервера SSO для сервиса валидации !!!


# Настройки взаимодействия с сервисом попутчиков ------------------------------
FELLOW_TRAVELERS_SSO_CLIENT_NAME = SSO_CLIENT_NAME  # Имя приложения при обращении к сервису попутчиков
FELLOW_TRAVELERS_SSO_SERVER_URL = SSO_SERVER_URL  # Внутренний адрес сервера SSO для сервиса попутчиков
FELLOW_TRAVELERS_SERVICE_URL = '{}/personal/ws/v.0.0.1/json/all_fellow_travelers/{}/all'.format(FELLOW_TRAVELERS_SSO_SERVER_URL, FELLOW_TRAVELERS_SSO_CLIENT_NAME)
# Адрес сервиса доступного питания
AVAILABLE_MEAL_WS_URL = 'http://ws:6580/ws2/v.0.0.1/meal'


# Настройки взаимодействия с сервисами ПКЛ ------------------------------------
SSO_CLIENT_NAME_PKL = 'sb@{}'.format(INSTANCE_ID)
SSO_SERVER_PKL = 'http://pkl-sso:3481' # Внутренний адрес сервера SSO ПКЛ для сервиса валидации

PKL_SESSION_COOKIE_NAME = 'cl_sso_session_id'  # Имя куки с номером сессии в SSO ПКЛ


# Настройки взаимодействия с сервисом PBUS ------------------------------------
PBUS_URL = 'http://pbus:8390' # !!! Адрес сервера PBUS
PBUS_CALLBACK_HOST = '127.0.0.1'  # Имя или IP-адрес сервера приложения для callback-запросов от PBUS
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_MY_NAME = 'sb@{}'.format(INSTANCE_ID)
PBUS_PASSWORD = Secret('123')
PBUS_VOCABS_NAME = 'vocabs'  # Имя сервиса справочников, к которому будем обращаться через PBUS
PBUS_VOCABS_TOPIC = 'vocabs' # Имя топика в PBUS
PBUS_ENABLE_SETTINGS = True  # Флаг включения механизма обмена настройками между экземплярами приложения


# Настройки взаимодействия с сервисами Sabre ----------------------------------
#SWS_SOAP_BASE_URL <- *_passwd.py
SWS_SESSIONS_LIMIT = 50  # Максимальное число сессий при работе с сервисом Sabre WS
SESSION_CONVERSATION_ID_PREFIX = 'DEV-SB{}'.format(INSTANCE_ID)


# Настройки взаимодействия с платежными сервисами ЕПР -------------------------
# PAYMENT_URL -- адрес сервиса ЕПР для продукта
# PAYMENT_PRODUCT -- идентификатор продукта для ЕПР
# PAYMENT_SECRET -- пароль для продукта в ЕПР
#PAYMENT_ACCOUNT <- *_passwd.py

PAYMENT_ACCOUNT = {
    # Для API js-приложения
    'APP': {
        'PAYMENT_URL': 'https://pay.test.aeroflot.ru/test-rc/aeropayment/epr/startmobilepayment.do',
        'PAYMENT_PRODUCT': 'SBWEB',
        'PAYMENT_SECRET': Secret('########'),
    },
    # Для API корпоративного js-приложения
    'CORP': {
        'PAYMENT_URL': 'https://pay.test.aeroflot.ru/test-rc/aeropayment/epr/startpayment.do',
        'PAYMENT_PRODUCT': 'SBCORP',
        'PAYMENT_SECRET': Secret('########'),
    },
    # Для API мобильных приложений
    'DEVICE': {
        'PAYMENT_URL': 'https://pay.test.aeroflot.ru/test-rc/aeropayment/epr/startmobilepayment.do',
        'PAYMENT_PRODUCT': 'SBAPP',
        'PAYMENT_SECRET': Secret('########'),
    },
    # Для API приложений компаний-партнеров
    'PARTNER': {
        'PAYMENT_URL': 'https://pay.test.aeroflot.ru/test-rc/aeropayment/epr/startpayment.do',
        'PAYMENT_PRODUCT': 'SBPARTNER',
        'PAYMENT_SECRET': Secret('########'),
    },
    # Для продажи услуг после онлайн-регистрации (upsale)
    'ESS.CHECKIN': {
        'PAYMENT_URL': 'https://pay.test.aeroflot.ru/test-rc/aeropayment/epr/startpayment.do',
        'PAYMENT_PRODUCT': 'CHECKIN',
        'PAYMENT_SECRET': Secret('########'),
    },
}

# Настройки взаимодействия с системой СИЗ -------------------------------------
ORDWS_SOAP_BASE_URL = 'https://pay.test.aeroflot.ru/test-rc/aeropayment/webservices/orderInfo-ws'
ORDWS_SOAP_USER = 'ramax-api'
ORDWS_SOAP_PWD = Secret('########')

# Настройки взаимодействия с системой СДК -------------------------------------
#CPNWS_SOAP_BASE_URL <- *_passwd.py
COUPON_EXPIRATION_WARN_DAYS = 3 # Кол-во дней до истечения срока действия купона, при котором отображается предупреждение


# Настройки механизмов безопасности и прав доступа ----------------------------
MONITORING_ACCESS_IP = ['127.0.0.1']
MONITORING_WS_DIGEST = {
    # Структура словаря:
    # '<user_name>': '<hash>'
}

# Настройки инструментов защиты от ботов --------------------------------------
MAPP_V1_WS_DIGEST_FILE = "{}/config/mapp_v1_digest.pw".format(APPDIR)  # Имя файла хешей для аутентификации мобильных приложений
NDC_DIGEST_AUTH_FILE = '{}/config/ndc_digest.pw'.format(APPDIR)  # Имя файла хешей для аутентификации приложения NDC

ENABLE_AUTH_CLIENT_BY_TOKEN = True

# Путь к исполняемому файлу wkhtmltopdf (библиотека для генерации pdf из html)
WKHTMLTOPDF_PATH = './wkhtmltopdf/linux/wkhtmltopdf-amd64'

# Настройки взаимодействия с метапоисковыми системами -------------------------
# Имя csv-лога, отправляемого на FTP в метапоисковые системы
BOOKING_CSV_LOG_NAME = 'BookingLog{}'.format(INSTANCE_ID)

# принудительно откусывать лог через обозначенный интервал, не дожидаясь следующего события
# (которое может наступить очень нескоро)
FORCED_BOOKING_CSV_LOG_ROTATION = False

# периодичность пробуждения монитора для проверки необходимости принудительной ротации BookingLog.csv
BOOKING_CSV_LOG_MONITOR_INTERVAL = 60 * 2  # seconds

# Настройки взаимодействия с сервисами WS -------------------------------------

AES_DATA_TRANSFER_KEY = Secret('x' * 32)
AES_BYTEARRAY = Secret('x' * 32)
AES_PNR_KEY = Secret('xxxxxxxxxxxxxxxx')

MEMBER_BOOKINGS_SERVICE_URL = 'http://sso/personal/services/member_bookings/test_sb'


# Адреса, на которые дублировать отправку писем об оплате
PAYMENT_EMAIL_BCC_RECIPIENTS = []

# Ссылка на информацию в ESS
ESS_INFO_URL = 'https://ess.test.aeroflot.ru/?PNR={pnr_locator}&Sign={sign}&Language={lang}'
ESS_SERVICE_URL = 'https://ess.test.aeroflot.ru/?PNR={pnr_locator}&Sign={sign}&Language={lang}&Goto={goto}'
ESS_INFO_URL_SECRET = Secret('########')
ESS_INFO_URL_CHECKIN_SECRET = Secret('########')

# Ссылка на сервис создания заказа ESS
ESS_CREATE_ORDER_URL = 'https://ws.ess.test.aeroflot.ru/rest/order/create/byobject'

# Ссылка на сервис получения заказа ESS
ESS_GET_ORDER_URL = 'https://ws.ess.test.aeroflot.ru/rest/order/get'

# Ссылка на сервис финализации (подтверждения) заказа ESS
ESS_FINALIZE_ORDER_URL = 'https://ws.ess.test.aeroflot.ru/rest/order/finalize'

# Ссылка на сервис получения предложений Аэроэкспресса для заказа ESS
ESS_AEROEXPRESS_OPTIONS_URL = 'https://ws.ess.test.aeroflot.ru/rest/aeroexpress/options/byavia'

# Ссылка на сервис добавления предложений Аэроэкспресса в заказ ESS
ESS_AEROEXPRESS_ADD_OPTIONS_URL = 'https://ws.ess.test.aeroflot.ru/rest/aeroexpress/add/byavia'

# Ссылка на сервис получения услуг Аэроэкспресса в заказе ESS
ESS_AEROEXPRESS_GET_SERVICES_URL = 'https://ws.ess.test.aeroflot.ru/rest/aeroexpress/get/byavia'

# Ссылка на сервис удаления услуг Аэроэкспресса в заказе ESS
ESS_AEROEXPRESS_REMOVE_SERVICES_URL = 'https://ws.ess.test.aeroflot.ru/rest/aeroexpress/remove/byavia'

# сервис резервирования сертификатов (ваучеров) для повышения класса обслуживания на сегментах
UPGRADE_CERTIFICATES_RESERVE_SERVICE_URL = '{}/personal/ws/v.0.0.1/json/vouchers/reserve'.format(SSO_SERVER_URL)

# Ссылка на сервис расчёта количества миль для повышения класса обслуживания
UPGRADE_CALCULATE_MILES_SERVICE_URL = '{}/personal/ws/v.0.0.1/json/miles_to_upgrade_class/get'.format(SSO_SERVER_URL)

# Включить группу сервисов "повышение уровня обслуживания за сертификаты"
UPCL4CRT_ENABLED = True

ESS_UPSALE_OFFERS_SERVICE_URL = 'https://ws.ess.test.aeroflot.ru/rest/offer/create/minPrice'

# Ссылка на сервис регистрации заказа в ЕПР
UPS_CREATE_ORDER_URL = 'https://gw.aeroflot.io/api/sb/pay/v2.2/registerOrder'

# Ссылка на сервис выполнения обработки заказа без проведения платежа
UPS_PROCESS_NON_PAID_URL = 'https://gw.aeroflot.io/api/sb/pay/v2.2/processNonPaid'

# Ссылка на сервис запроса состояния заказа
UPS_PAYMENT_RESULT_URL = 'https://gw.aeroflot.io/api/sb/pay/v2.2/getPaymentResult'

UPS_CLIENT_ID = '######'
