# -*- coding: utf-8 -*-

"""Aeroflot B2B Application registrations and initialization.

$Id: initializer.py 20690 2016-09-07 12:20:05Z oeremeeva $
"""


import cherrypy
import os
import time

from pyramid.app import initializer as _initializer
from pyramid.registry.interfaces import IRegisterable, IRegisterableVocabulary
from pyramid.vocabulary import getV
from pyramid.registry import registerFromModule
from pyramid.ui.auto import adapters
from pyramid import ormlite
from pyramid import model
from pyramid.vocabulary import mvcc

from zope.i18n import ITranslationDomain
from zope.i18n.gettextmessagecatalog import GettextMessageCatalog
from zope.i18n.translationdomain import TranslationDomain
from zope.component import provideUtility, queryUtility

import config
from log import init_cherrypy_loggers
from ws_tools import set_current_lang_locale

import transaction

import models.award
import models.geo
import models.partner
import models.air
import models.route
import models.bonus
import models.special_offer
from django.utils.translation import activate
from i18n import get_current_lang

from services.heartbeat import StatusMonitor
from ui.csrf import check_submit
import rx.i18n.translation
from zope import component
from zope.component import provideUtility, queryUtility
from zope.i18n.gettextmessagecatalog import GettextMessageCatalog
from zope.i18n.interfaces import ITranslationDomain
from zope.i18n.translationdomain import TranslationDomain
from rx.pbus.client import subscribe, post
from zope.component import provideAdapter
from services.base.xml_base import ICommonXMLService, XMLServiceErrorReporter
from services.base.json_base import ICommonJSONService, JSONServiceErrorReporter


def setup_module_vocabularies(module):
    """ Регистрируем вокабы и загружаем в них данные, если требуется """
    for elem in module.__dict__.values():
        if IRegisterableVocabulary.providedBy(elem):
            elem.register()
            if hasattr(elem, 'preload'):
                getV(elem.regName).preload()
        elif IRegisterable.providedBy(elem):
            elem.register()

def init_common_templates_i18n():
    u"""Регистрация каталогов в домене приложения (переводы общих шаблонов)"""

    domain = config.APP_I18N_DOMAIN
    localedir = os.path.normpath('%s/templates/common/locales' % config.APPDIR)
    translation_domain = queryUtility(ITranslationDomain, domain) or TranslationDomain(domain)
    exist_locale_dir = filter(lambda x: os.path.isdir(os.path.join(localedir, x)), os.listdir(localedir))

    # Подключаем все доступные языки
    for lang in exist_locale_dir:
        filename = os.path.join(localedir, lang, 'LC_MESSAGES', '%s.mo' % domain)
        if os.path.isfile(filename):
            catalog = GettextMessageCatalog(lang, domain, filename)
            translation_domain.addCatalog(catalog)
    provideUtility(translation_domain, name=domain)

def init_vocabularies():
    u"""Регистрирует словари и адаптеры моделей"""

    transaction.begin()

    # пирамидовские вокабы

    registerFromModule(adapters)

    registerFromModule(ormlite)

    registerFromModule(model)

    # наши вокабы

    mvcc.register()


    setup_module_vocabularies(models.award)


    setup_module_vocabularies(models.geo)


    setup_module_vocabularies(models.partner)


    setup_module_vocabularies(models.air)


    setup_module_vocabularies(models.route)


    setup_module_vocabularies(models.bonus)

    setup_module_vocabularies(models.special_offer)

    transaction.commit()


def init_django_i18n():

    def activate_lang():
        activate(get_current_lang())

    cherrypy.tools.activate_django_translation = cherrypy.Tool(
        'on_start_resource', activate_lang, priority=60
    )  # после tools.session (50)


def init_django():
    # Configure Django settings once, and only once.
    from django.conf import settings
    if not settings.configured:
        settings.configure()
#        settings.DATE_FORMAT = config.WEB_DATE_FORMAT
        init_django_i18n()


def trusted_proxy(base=None, local='X-Forwarded-Host', remote='X-Forwarded-For',
                  scheme='X-Forwarded-Proto'):
    if cherrypy.request.remote.ip not in config.PROXY_IP:
        cherrypy.log('Remote address (%s) is not in config.PROXY_IP' % cherrypy.request.remote.ip)
        raise cherrypy.HTTPError(403, 'Remote address is not in PROXY_IP')

    # Удаляем из X-Forwarded-For IP-адреса, входящие в PROXY_IP
    xff = cherrypy.request.headers.get(remote)
    if xff and remote == 'X-Forwarded-For':
        xff_parts = [ip for ip in xff.split(',') if ip.strip() not in config.PROXY_IP]
        cherrypy.request.headers[remote] = ','.join(xff_parts)

    return cherrypy.lib.cptools.proxy(base=base, local=local, remote=remote, scheme=scheme)


def start_request_timer():

    cherrypy.request.start_time = time.time()


def init_cherrypy_tools():
    # pyramid tools
    _initializer.initCPPageTransactionWrapper()
    _initializer.initCPSavedSessionHandler()
    _initializer.initCPNoCacheHandler()

    # aflcab tools
    cherrypy.tools.set_current_lang_locale = cherrypy.Tool('on_start_resource', set_current_lang_locale, priority=30)
    cherrypy.tools.request_timer = cherrypy.Tool('on_start_resource', start_request_timer, priority=0)


    cherrypy.tools.status = StatusMonitor()


    cherrypy.tools.csrf_submit_reject = cherrypy.Tool('before_request_body', check_submit, priority=90)

def init_pbus():

    subscribe(config.PBUS_TOPICS['vocabs'])

    post(config.PBUS_TOPICS['vocabs'], '{"command": "get_all", "vocabularies": ["airlines", "countries", "cities", "airports", "pairs", "partner_categories", "partners", "partner_offices", "partner_award_conditions", "tier_levels", "tier_level_factors", "skyteam_service_classes", "service_classes_limits", "airline_service_classes", "tariff_groups", "airline_tariff_groups", "booking_classes", "redemption_zones", "bonus_routes", "awards", "wrong_routes", "special_offers"]}',
         recipient=config.PBUS_VOCAB_RECIPIENTS['vocabs'])


def init_error_reporting():

    # обертка под ошибки XML сервисов

    provideAdapter(XMLServiceErrorReporter, [ICommonXMLService,])

    # обертка под ошибки JSON сервисов

    provideAdapter(JSONServiceErrorReporter, [ICommonJSONService, ])


def init_proxy_tool():
    cherrypy.tools.trusted_proxy = cherrypy.Tool('before_request_body', trusted_proxy, priority=30)


# Инициализация ----------------------------------------------------------------

def initialize():
    init_cherrypy_loggers()

    _initializer.initMimetypesExtensions()

    _initializer.initDBConnection()
    _initializer.initCache()

    init_vocabularies()

    _initializer.initI18NSupport()

    rx.i18n.translation.init_i18n()

    init_common_templates_i18n()
    # В конце делаем пред-загрузку всех persistent-словарей, т.к. их
    # необходимо загружать ДО старта cherrypy-сервера, пока приложение
    # работает в единственном треде.
    ###_initializer.preloadVocabularies()

    init_cherrypy_tools()
    init_error_reporting()

    init_django()
    init_pbus()

    init_proxy_tool()
