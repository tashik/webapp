# -*- coding: utf-8 -*-

import cherrypy
from mako.lookup import TemplateLookup
from pyramid.ui.utils import resolveRoute

import config
from i18n import _, get_current_lang, get_available_languages, get_current_localization

tplLookup = TemplateLookup(directories=config.TEMPLATEDIR, input_encoding='utf-8')
__ = unicode


def renderTemplate(tpl_file_name, **kw):
    B = resolveRoute('root')
    if B == '/':
        B = ''
    tpl = tplLookup.get_template(tpl_file_name)

    x_params = dict(B=B, LK=config.LK_URL,
                    R=resolveRoute,
                    config=config,
                    current_lang=get_current_lang(),
                    current_locale=get_current_localization(),
                    known_languages=get_available_languages(),
                    url=cherrypy.url(),
                    COMMON_STATIC_URL=config.COMMON_STATIC_URL,
                    SITE_HOST=config.SITE_HOST,
                    GA_ACCOUNT=config.GA_ACCOUNT,
                    GOOGLE_TAG_MANAGER_ID=config.GOOGLE_TAG_MANAGER_ID)
    x_params.update(kw)

    return tpl.render(_=_, __=__, **x_params)
