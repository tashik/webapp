# -*- coding: utf-8 -*-

"""
$Id: airlines.py 21554 2016-11-18 09:03:41Z oeremeeva $
"""
import cherrypy
import json
from i18n import _, get_current_lang
import config

from pyramid.vocabulary import getV, getVI
import ui.common
from ui.template import renderTemplate

from rx.i18n.translation import self_translated
from logic.skyteam import (airline_to_dict, flight_code, get_miles_table,
                           search_skyteam_airlines, extend_miles_table,
                           get_miles_table_with_tariff_code, get_fake_miles_table,
                           extend_miles_table_with_tariff_code)
from pyramid.ui.utils import resolveRoute


class AirlinesPage(ui.common.AppPage):
    page_title = _(u'Партнёры программы')
    sectionTitle = _(u'Авиакомпании')
    active_menu_item = 'afl_bonus'
    template_page = '/airlines.html'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('airlines', '/airlines', controller=self, action='index')

    def _afl_at_begin(self, airlines):
        su = self._get_su(airlines)
        if su is not None:
            airlines.remove(su)
            airlines.insert(0, su)
        return airlines

    def _get_su(self, airlines):
        for airline in airlines:
            if airline.iata == config.AFL_AIRLINE_IATA:
                return airline
        return None

    def _sorted_airlines(self, airlines):
        return sorted(airlines, key=lambda x: (x.weight, x.sort_title))

    def index(self, **params):

        content = renderTemplate(
            self.template_page,
            skyteam_airlines=self._afl_at_begin(
                self._sorted_airlines(search_skyteam_airlines())
            ),
            banner_url=json.dumps(config.BANNERS_AJAX_URL),
            banner_params=json.dumps({
                "lang": get_current_lang(),
                "positions": [21, 22, 23]}),
            user_info=json.dumps({
                "loyalty_id": "1111111", "tier_level": "BASIC" }))

        return self.render(content, show_breadcrumbs=True,
                           active_menu_subitem='partners')


class AirlinePage(ui.common.AppPage):
    u"""Страница авиакомпании."""
    sectionTitle = _(u'Партнёры')
    active_menu_item = 'afl_bonus'
    template_page = '/airline.html'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('airline', '/airlines/:id', controller=self, action='index',
                           requirements={'id': '\d+'})

    def index(self, id, **params):
        ml_to_self_translated = lambda val, lang: unicode(self_translated(**dict([s.split(':', 1) for s in val if s])))
        airlines = getV('airlines')
        try:
            self.ob = airlines[id]
        except KeyError:
            raise cherrypy.HTTPError(404)

        parent_airline = None if self.ob.parent_airline_id is None \
            else airlines[self.ob.parent_airline_id]

        is_afl_child = parent_airline and parent_airline.iata == config.AFL_AIRLINE_IATA

        # Если компания не входит в SkyTeam, не Аэрофлот и не дочерняя, возвращаем 404
        if not (self.ob.iata == config.AFL_AIRLINE_IATA or is_afl_child
                or self.ob.alliance == 'SkyTeam'):
            raise cherrypy.HTTPError(404)

        self.page_title = self.ob.title
        tier_level_dict = getV('tier_levels')

        current_lang = get_current_lang()
        airline_dict = airline_to_dict(self.ob, ml_fnc=ml_to_self_translated,
                                       fields=['names', 'iata', 'airline_id', 'url'],
                                       fieldmap={'airline_id': 'id', 'names': 'title'}, lang=current_lang)
        airline_dict.update({
            'image': unicode(self.ob.default_logo_url),
            'description': unicode(self.ob.description),
            'full_url': unicode(self.ob.url_local),
            'ikm_code': config.AFL_AIRLINE_IATA if is_afl_child else self.ob.iata})

        tab_info_airline = parent_airline or self.ob
        mile_earning_comments = {
            'miles_earn_description': ml_to_self_translated(self.ob.miles_earn_description, lang=current_lang),
            'miles_earn_comment': ml_to_self_translated(tab_info_airline.miles_earn_comment, lang=current_lang),
            'miles_limitation_verbose': unicode(tab_info_airline.miles_limitation_verbose),
            'miles_minimum': tab_info_airline.miles_minimum}

        sc_fnc= lambda ob, lang: ml_to_self_translated(ob.names, lang)

        miles_table = get_miles_table_with_tariff_code(tab_info_airline, sc_fnc=sc_fnc,
                                      lang=current_lang)
        is_new_miles_table = 1
        if miles_table:
            booking_class_comments = extend_miles_table_with_tariff_code(miles_table,
                                            ml_fnc=ml_to_self_translated,
                                            lang=current_lang)
        else:
            is_new_miles_table = 0
            miles_table = get_miles_table(tab_info_airline, sc_fnc=sc_fnc,
                                      lang=current_lang)
            booking_class_comments = extend_miles_table(miles_table,
                                                        ml_fnc=ml_to_self_translated,
                                                        lang=current_lang)
        old_miles_table = get_fake_miles_table(lang=current_lang, airline=self.ob.iata)
        flight_code_fmt = _(u'оператор рейса %s') if self.ob.iata == config.AFL_AIRLINE_IATA else  _(u'код рейсов %s')

        render_params = {
            'airline': json.dumps(airline_dict),

            'children': json.dumps([
                {'id': ch.id, 'flight_code': flight_code_fmt % flight_code(ch),
                 'title': unicode(ch.title), 'weight': ch.weight,
                 'link': resolveRoute('airline', id=ch.id) if self.ob.iata == config.AFL_AIRLINE_IATA else None}
                for ch in self.ob.children]),

            'parent':  json.dumps(
                {'id': parent_airline.id, 'flight_code': _(u'код рейсов %s') % parent_airline.iata,
                 'title': unicode(parent_airline.title),
                 'link': resolveRoute('airline', id=parent_airline.id)
                 if parent_airline.iata == config.AFL_AIRLINE_IATA else None}
                if parent_airline is not None else None),

            'afl_iata': json.dumps(config.AFL_AIRLINE_IATA),

            'mile_earning_comments': json.dumps(mile_earning_comments),

            'miles_table': json.dumps(miles_table),
            'old_miles_table': json.dumps(old_miles_table),
            'is_new_miles_table': is_new_miles_table,
            'is_old_miles_table': len(old_miles_table) > 0,
            'booking_class_comments': json.dumps(booking_class_comments),

            'elite_coefficients': json.dumps(
                sorted([(tlf.tier_level, tlf.factor)
                        for tlf in getVI('tier_level_factors_by_airline_idx')(context=tab_info_airline)],
                       key=lambda tlf: tier_level_dict[tlf[0]].ordering, reverse=True)),

            'banner_url': json.dumps(config.BANNERS_AJAX_URL),

            'banner_params': json.dumps({"lang": get_current_lang(), "positions": [21, 22, 23]}),

            'user_info': json.dumps({"loyalty_id": "1111111", "tier_level": "BASIC"}),

            'earn_calc_main_url': config.URL_EARN_CALC_MAIN,
            'url_to_new_fares': config.URL_TO_NEW_FARES['en'] if current_lang not in ('ru', 'en') else config.URL_TO_NEW_FARES[current_lang],
            'earn_calc_url':
                config.URL_EARN_CALC +
                ("?airline={0}".format(self.ob.iata
                                       if parent_airline is None or parent_airline.iata != config.AFL_AIRLINE_IATA
                                       else config.AFL_AIRLINE_IATA)) +
                "&lang={0}".format(get_current_lang()),
            'spend_calc_url':
                config.URL_SPEND_CALC.format(get_current_lang())
        }

        content = renderTemplate(
            self.template_page,
            **render_params)

        self.backUrl = resolveRoute('airlines')

        return self.render(content, active_menu_subitem='partners')
