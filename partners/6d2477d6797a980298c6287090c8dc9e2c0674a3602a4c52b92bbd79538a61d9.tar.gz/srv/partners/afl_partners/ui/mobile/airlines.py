# -*- coding: utf-8 -*-

"""
$Id: mobile/partners.py 3758 2014-03-05 22:46:24Z anovgorodov $
"""

import ui.common
from i18n import _
from ui.airlines import AirlinesPage as _AirlinesPage, AirlinePage as _AirlinePage
from pyramid.ui.utils import resolveRoute



class AirlinesPage(ui.mobile.common.AppPage, _AirlinesPage):
    sectionTitle = _(u'Бонус')
    title = _(u'Авиакомпании')
    page_title = None
    active_menu_item = 'afl_bonus'
    template_page = '/mobile/airlines.html'
    backUrl = resolveRoute('partners')


class AirlinePage(ui.mobile.common.AppPage, _AirlinePage):
    sectionTitle = _(u'Бонус')
    title = _(u'Партнёры')
    page_title = None
    active_menu_item = 'afl_bonus'
    template_page = '/mobile/airline.html'

