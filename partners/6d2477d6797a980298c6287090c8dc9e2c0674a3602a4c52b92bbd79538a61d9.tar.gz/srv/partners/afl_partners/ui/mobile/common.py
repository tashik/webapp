# -*- coding: utf-8 -*-

"""
$Id: common.py 5698 2014-08-11 16:00:19Z tmoskov $
"""


from ui.common import AppPage as _AppPage
from i18n import _
import config

class AppPage(_AppPage):
    """ Веб-страница """

    _menus = 'main_menu'
    _template = '/common/mobile/page.html'
    _authObject = 'general'
    active_menu_item = None
    is_mobile_page = True

    def render(self, content, page_title=None, section_title=None,
               show_breadcrumbs=True, show_as_menu=False,
               back_url=None, **params):

        if page_title is None: page_title = getattr(self, 'title', '')
        if section_title is None: section_title = getattr(self, 'sectionTitle', '')
        if back_url is None: back_url = getattr(self, 'backUrl', '')

        x_params = {
            'show_as_menu': show_as_menu,
            'back_url' : back_url,
            'root_url' : config.MOBILE_SERVER_ROOT_URL,
            'page_title': page_title,
            'section_title': section_title
        }

        x_params.update(params)
        return super(AppPage, self).render(content, **x_params)

