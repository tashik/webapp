# -*- coding: utf-8 -*-

"""
$Id: root.py 3758 2014-03-05 22:46:24Z anovgorodov $
"""

import urllib
import cherrypy
from pyramid.app.page import Page
import config
import ui.common
from auth import authorize
import log
from ui.mobile.common import AppPage
LOG = log.log.action_logger.info


class LoginPage(Page):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('login', '/login', controller=self, action='login')
        dispatcher.connect('logout', '/logout', controller=self, action='logout', mode='full')

    def login(self, return_url=config.EXT_SERVER_URL+config.PDA_BASE):
        url = "%s?return_url=%s" % (config.SSO_LOGIN_URL, urllib.quote(return_url))
        self.redirect(url)

    def logout(self, mode, return_url=config.EXT_SERVER_URL+config.PDA_BASE):
        from pyramid.auth.authentication import revokeAuthentication
        revokeAuthentication()
        url = "%s?return_url=%s" % (config.SSO_LOGOUT_URL, return_url)
        self.redirect(url)


class RootPage(AppPage):
    sectionTitle = config.SYSTEM_NAME
    _template = '/common/mobile/page.html'
    is_mobile_page = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('root', '/', controller=self, action='index')

    @authorize
    def index(self, **params):
        print "mobile root page"
        LOG('some text')
        return self.render('')

