# -*- coding: utf-8 -*-

"""
$Id: mobile/partners.py 3758 2014-03-05 22:46:24Z anovgorodov $
"""

import cherrypy
import json

import ui.common
from i18n import _
from ui.partners import (SearchFormPage as _SearchFormPage,
                         SearchResultPage as _SearchResultPage,
                         SearchOfficesResultPage as _SearchOfficesResultPage,
                         PartnerPage as _PartnerPage,
                         TransVocabs, city_iata2id, get_priority)

from pyramid.vocabulary import getV
from pyramid.ui.utils import resolveRoute

from ui.template import renderTemplate
from logic.partners import (countries_available, cities_available)
import config
from i18n import get_current_lang


class SearchFormPage(ui.mobile.common.AppPage, _SearchFormPage):
    sectionTitle = _(u'Бонус')
    title = _(u'Поиск партнёров')
    active_menu_item = 'afl_bonus'
    template_page = '/mobile/partners.html'

    def index(self, **params):
        self.backUrl = config.URL_BACK_MOBILE_CMS_BONUS
        if get_current_lang() in config.URL_POSTFIX_BACK_MOBILE_LANGS:
            self.backUrl = self.backUrl + config.URL_POSTFIX_BACK_MOBILE_LANGS[get_current_lang()]
        else:
            self.backUrl = self.backUrl + config.URL_POSTFIX_BACK_MOBILE_LANGS['int']
        return super(SearchFormPage, self).index(**params)


class SearchResultPage(ui.mobile.common.AppPage, _SearchResultPage):
    paginator_step = config.PARTNERS_MOBILE_PAGINATOR_STEP


class SearchOfficesResultPage(ui.mobile.common.AppPage, _SearchOfficesResultPage):
    paginator_step = config.PARTNERS_MOBILE_OFFICE_CONTACTS_PAGINATOR_STEP


class PartnerPage(ui.mobile.common.AppPage, _PartnerPage):
    sectionTitle = _(u'Бонус')
    title = _(u'Партнёры')
    template_page = '/mobile/partner.html'

    def _check_earn_menu(self, ob, **params):
        conditions = ob.get_award_conditions()
        return True if len(unicode(ob.mile_earn_comment)) > 0 or len(conditions) > 0 else False

    def _get_earn_params(self, ob, **params):
        conditions = ob.get_award_conditions()
        conditions = sorted(conditions, key=lambda x: x.weight)

        def f(val):
            if int(val) == val:
                return int(val)
            return val

        return {'conditions': [dict(description=unicode(c.description), miles=f(c.miles))
                               for c in conditions if c.is_earning],
                'comment': ob.mile_earn_comment}

    def _check_spend_menu(self, ob, **params):
        return True if len(unicode(ob.mile_spend_comment)) > 0 else False

    def _get_spend_params(self, ob, **params):
        return {'comment': ob.mile_spend_comment}

    def _get_so_params(self, ob, **params):
        spec_offs = ob.get_special_offers(get_current_lang())
        max_spec_off_len = 70
        return {'comment': ob.special_offers_comment,
                'spec_offs': [dict(
                    name=unicode(s.name.strip()[:max_spec_off_len]
                                 + ('...' if len(s.name.strip()) > max_spec_off_len else '')),
                    url=unicode(s.url.strip()
                                if s.url.strip().startswith('http://') or s.url.strip().startswith('https://')
                                else config.URL_SP_OFFERS_MS_PREFIX + (s.url.strip()
                                                                 if s.url.strip().startswith('/')
                                                                 else '/' + s.url.strip())))
                              for s in spec_offs]}

    def _get_contacs_params(self, ob, **params):
        countries = [{'code': c.country, 'name': unicode(c.title)}
                        for c in countries_available(partners=[ob.id])]
        countries_json = json.dumps(countries)
        cities = [{'id': c.id, 'name': unicode(c.title), 'country_code': c.country_code}
                     for c in cities_available(partners=[ob.id])]
        cities_json = json.dumps(cities)
        contact_types_json = json.dumps(TransVocabs.get_partner_office_contact_types().items())

        default_city = params.get('city', '')
        default_country = params.get('country', '')

        return {'countries': countries_json,
                'cities': cities_json,
                'contact_types': contact_types_json,
                'default_country': default_country,
                'default_city': default_city}

    def index(self, id, **params):
        try:
            ob = getV('partners')[id]
        except KeyError:
            raise cherrypy.HTTPError(404)

        if not ob.published:
            raise cherrypy.HTTPError(404)

        partner = {
            'title': unicode(ob.title),
            'image': unicode(ob.default_logo_url),
            'description': unicode(ob.description),
            'url': unicode(ob.url_local),
            'id': id,
        }

        country = params.get('country', '')
        city = params.get('city', '')
        searchType = params.get('searchType', '')
        name = params.get('name', '')
        categories = params.get('categories[]', '')

        input_params = {
            'country': country,
            'city': city,
            'searchType': searchType,
            'name': name,
            'categories': categories
        }

        render_params = {}
        render_params.update(partner=partner)
        render_params.update(input_params)
        template_page = self.template_page

        if country == '':
            input_params.pop('country')
        if city == '':
            input_params.pop('city')
        if searchType == '':
            input_params.pop('searchType')
        if name == '':
            input_params.pop('name')
        if categories == '':
            input_params.pop('categories')
        target_params = "&".join([key + '=' + input_params[key] for key in input_params])
        back_to_partner = resolveRoute('partner', id=id) + \
                          "?" + target_params
        back_to_partners = resolveRoute('partners') + \
                           "#!" + target_params

        actions = {
            'earn': {
                'func': self._get_earn_params,
                'template': '/mobile/partner_earn.html',
                'backUrl': back_to_partner
            },
            'spend': {
                'func': self._get_spend_params,
                'template': '/mobile/partner_spend.html',
                'backUrl': back_to_partner
            },
            'special': {
                'func': self._get_so_params,
                'template': '/mobile/partner_spec_off.html',
                'backUrl': back_to_partner
            },
            'contacts':  {
                'func': self._get_contacs_params,
                'template': '/mobile/partner_contacts.html',
                'backUrl': back_to_partner
            },
        }

        back_url = resolveRoute('partners', country=country, city=city)

        action = params.get('action', None)
        if action is not None and action in actions.keys():
            render_params.update(actions[action]['func'](ob, **params))
            template_page = actions[action].get('template', template_page)
            back_url = actions[action]['backUrl']

        partner_menu = [
            ('earn', dict(descr=_(u'Набрать мили'))),
            ('spend', dict(descr=_(u'Потратить мили'))),
            ('special', dict(descr=_(u'Специальные предложения'))),
            ('contacts', dict(descr=_(u'Контакты')))
        ]

        if len(ob.get_special_offers(get_current_lang())) == 0:
            partner_menu.pop(2)
        if not self._check_spend_menu(ob, **params):
            partner_menu.pop(1)
        if not self._check_earn_menu(ob, **params):
            partner_menu.pop(0)
        render_params.update(dict(menu=partner_menu, action=action))

        common_menu = [
            ('self_url', dict(descr=_(u'Перейти на сайт партнёра'), url=partner['url'], target="_blank", rel="nofollow")),
            ('partner', dict(descr=_(u'Профиль партнера'), url=back_to_partner)),
            ('partners', dict(descr=_(u'Каталог партнеров'), url=back_to_partners))
        ]
        if action is None or action == '':
            common_menu.pop(1)
        render_params.update(dict(common_menu=common_menu))

        render_params.update(dict(country_priority=get_priority(config.COUNTRY_PRIORITY),
                                  city_priority=get_priority(config.CITY_PRIORITY, mapper=city_iata2id)))

        self.backUrl = back_url

        content = renderTemplate(template_page, **render_params)

        return self.render(content)
