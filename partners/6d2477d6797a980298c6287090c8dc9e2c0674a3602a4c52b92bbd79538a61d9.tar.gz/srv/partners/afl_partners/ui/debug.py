# -*- coding: utf-8 -*-
"""
$Id: debug.py 7024 2014-10-07 14:47:48Z ogambaryan $
"""

import cherrypy
from pyramid.app.page import Page
from pyramid.exc import PyramidException
import config


TEST_AJAX_COOKIE = '_test_ajax_error'

class TestAjaxError(PyramidException):
    msg = u'Test AJAX Error'

def simulate_ajax_error(func):
    def raise_if_testing(*args, **kw):
        if cherrypy.request.cookie.get(TEST_AJAX_COOKIE):
            raise TestAjaxError()
        return func(*args, **kw)
    return raise_if_testing

class SetDebugPage(Page):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('set_debug', 'set_debug/{state}', controller=self, action='set_debug')
        dispatcher.connect('set_ajax_errors', 'set_ajax_errors/{state}', controller=self, action='set_ajax_errors')

    def set_debug(self, state='on'):
        assert state in ('on', 'off')
        cherrypy.response.cookie[config.DEBUG_COOKIE] = \
            state == 'on' and '1' or '0'
        cherrypy.response.cookie[config.DEBUG_COOKIE]['path'] = '/'
        if config.COOKIE_DOMAIN:
            cherrypy.response.cookie[config.DEBUG_COOKIE]['domain'] = config.COOKIE_DOMAIN
        cherrypy.response.cookie[config.DEBUG_COOKIE]['max-age'] = \
            3600 * 24 * 365
        cherrypy.response.cookie[config.DEBUG_COOKIE]['version'] = 1
        return "<html><body>debug mode is <b>%s</b></body></html>" % state

    def set_ajax_errors(self, state='on'):
        assert state in ('on', 'off')
        cherrypy.response.cookie[TEST_AJAX_COOKIE] = '1'
        cookie = cherrypy.response.cookie[TEST_AJAX_COOKIE]
        if config.COOKIE_DOMAIN:
            cookie['domain'] = config.COOKIE_DOMAIN
        cookie['path'] = '/'
        cookie['version'] = 1
        if state != 'on':
            cookie['expires'] = 0
        return "<html><body>AJAX errors are <b>%s</b></body></html>" % state
