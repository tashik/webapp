# -*- coding: utf-8 -*-

"""
$Id: root.py 3758 2014-03-05 22:46:24Z anovgorodov $
"""

import cherrypy
import json

from pyramid.vocabulary import getV
from pyramid.ui.utils import resolveRoute

import config
import ui.common
from i18n import _, get_current_lang
from ui.debug import simulate_ajax_error
from ui.template import renderTemplate

from logic.geo import load_city, load_country, load_city_by_iata
from logic.partners import (countries_available, cities_available,
                            categories_available, search_partners,
                            search_offices)
from models.partner import (AC_EARN, AC_SPEND, AC_ALL, CT_PHONE, CT_FAX,
                            CT_EMAIL, OT_MAIN, OT_OTHER)


def city_iata2id(iata):
    ob = load_city_by_iata(iata)
    if ob is not None:
        return ob.city_id


def get_priority(flat_list, mapper=None):
    p = {}
    for idx, c in enumerate(flat_list):
        if mapper is not None:
            c = mapper(c)
        if c:
            p[c] = idx + 1
    return p


class TransVocabs(object):
    @staticmethod
    def get_search_type_choices():
        return (
            (AC_ALL, _(u'Набрать или потратить мили')),
            (AC_SPEND, _(u'Потратить мили')),
            (AC_EARN, _(u'Набрать мили')),
        )

    @staticmethod
    def get_search_type_choices_mobile():
        return (
            (AC_EARN, _(u'Набрать')),
            (AC_SPEND, _(u'Потратить')),
            (AC_ALL, _(u'Все')),
        )

    @staticmethod
    def get_partner_office_contact_types():
        return {
            CT_PHONE: _(u'Телефон'),
            CT_FAX: _(u'Факс'),
            CT_EMAIL: _(u'Email')
        }

    @staticmethod
    def get_partner_office_types():
        return {
            OT_MAIN: _(u'Головной офис'),
            OT_OTHER: _(u'Филиал')
        }


class SearchFormPage(ui.common.AppPage):
    sectionTitle = _(u'Поиск партнёров')
    #sectionTitle = _(u'Партнёры')
    active_menu_item = 'afl_bonus'
    template_page = '/partners.html'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('partners', '/partners', controller=self, action='index')

    def index(self, **params):
        search_type_choices = TransVocabs.get_search_type_choices() \
                              if not self.is_mobile_page else \
                              TransVocabs.get_search_type_choices_mobile()
        render_params = {
            'country_priority': get_priority(config.COUNTRY_PRIORITY),
            'city_priority': get_priority(config.CITY_PRIORITY, mapper=city_iata2id),
            'countries': [{'code': c.country, 'name': unicode(c.title)}
                                for c in countries_available()],
            'cities': [{'id': c.id, 'name': unicode(c.title), 'country_code': c.country_code}
                       for c in cities_available()],
            'categories': [{'id': c.id, 'name': unicode(c.title)}
                           for c in categories_available()] if categories_available else [],
            'search_types': [(k, unicode(v)) for k, v in search_type_choices],
            'banner_url': (config.BANNERS_AJAX_URL if not self.is_mobile_page else config.URL_BANK_BANNER_MOBILE),
            'banner_params': {"lang": get_current_lang(), "positions": [24, 25, 26]},
            'user_info': {"loyalty_id": "1111111", "tier_level": "BASIC"}
        }

        content = renderTemplate(self.template_page, **{key: json.dumps(value) for key, value in render_params.items()})

        return self.render(content)


class SearchResultPage(ui.common.AppPage):
    _loginUrl = None  # из обработчика AJAX нельзя делать редирект

    paginator_step = config.PARTNERS_PAGINATOR_STEP

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('ajax_search', 'ajax/search', controller=self, action='index')

    @simulate_ajax_error
    def index(self, **params):
        # ui.csrf.check_ajax()
        res = {}
        try:
            res = self._index(**params)
        except:
            cherrypy.response.status = 503
            raise

        if isinstance(res, unicode):
            res = res.encode('utf-8')

        cherrypy.response.headers['Content-Type'] = 'application/json; charset=UTF-8'

        return res

    def _index(self, **params):
        success = True
        errors = []

        try:
            page = int(params.get('page', 0))
        except ValueError:
            page = 0

        partners = search_partners(country=params.get('country'),
                                   city=params.get('city'),
                                   categories=params.get('categories[]'),
                                   q=params.get('name'),
                                   search_type=params.get('searchType'))

        partners = sorted(partners, key=lambda x: (x.weight, unicode(x.title)))

        total = len(partners)
        start = page * self.paginator_step

        items = []
        for ob in partners[start:start + self.paginator_step]:
            items.append({
                'id': ob.id,
                'name': unicode(ob.title),
                'link': unicode(ob.url_local),
                'image': unicode(ob.default_logo_url),
                'short_descr': unicode(ob.short_description),
                'description': unicode(ob.description.strip()),
                'url': resolveRoute('partner', id=ob.id),
                'mile_action': ('earn' if ob.mile_action == AC_EARN else 'spend' if ob.mile_action == AC_SPEND else 'all'),
                'weight': ob.weight,
                'is_new': ob.is_new
            })

        result = json.dumps({
            'success': success,
            'data': {
                'items': items,
                'paginator': {
                    'total': total,
                    'page': page,
                    'step': self.paginator_step,
                    'amount': len(items)
                }
            },
            'errors': errors,
        })

        return result


class SearchOfficesResultPage(ui.common.AppPage):
    _loginUrl = None  # из обработчика AJAX нельзя делать редирект

    paginator_step = config.PARTNERS_OFFICE_CONTACTS_PAGINATOR_STEP

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('ajax_offices', 'ajax/offices', controller=self, action='index')

    @simulate_ajax_error
    def index(self, **params):
        # ui.csrf.check_ajax()
        res = {}
        try:
            res = self.partner_offices(**params)
        except:
            cherrypy.response.status = 503
            raise

        if isinstance(res, unicode):
            res = res.encode('utf-8')

        cherrypy.response.headers['Content-Type'] = 'application/json; charset=UTF-8'

        return res

    def partner_offices(self, **params):
        success = True
        errors = []

        try:
            page = int(params.get('page', 0))
        except ValueError:
            page = 0

        partner_id = params.get('id', None)

        try:
            ob = getV('partners')[partner_id]
        except KeyError:
            raise

        if not ob.published:
            raise

        offices = search_offices(partner=ob,
                                 country=params.get('country'),
                                 city=params.get('city'))

        items = []
        total = len(offices)
        start = page * self.paginator_step

        for ob in offices[start:start + self.paginator_step]:
            contacts = []
            for c in ob.contacts:
                contacts.append({
                    'contact_type': c.contact_type,
                    'contact_type_name': unicode(TransVocabs.get_partner_office_contact_types()[c.contact_type]),
                    'contact': unicode(c.contact),
                    'main_contact': c.main_contact
                })
            contacts = sorted(contacts, key=lambda x: x['main_contact'])

            city = load_city(ob.city) or ''
            country = ''
            if city:
                country = load_country(city.country_code) or ''
                if country:
                    country = country.title
                city = city.title

            items.append({
                'id': ob.partner_office_id,
                'country': unicode(country),
                'city': unicode(city),
                'lat': ob.lat,
                'lon': ob.lon,
                'comments': unicode(ob.office_comments),
                'address': unicode(ob.office_address),
                'worktime': unicode(ob.office_worktime),
                'office_type': ob.office_type,
                'office_type_name': unicode(TransVocabs.get_partner_office_types()[ob.office_type]),
                'contacts': contacts,
            })

        items = sorted(items, key=lambda x: (x['office_type'], x['address']))

        result = json.dumps({
            'success': success,
            'data': {
                'items': items,
                'paginator': {
                    'total': total,
                    'page': page,
                    'step': self.paginator_step,
                }
            },
            'errors': errors,
        })

        return result


class PartnerPage(ui.common.AppPage):
    sectionTitle = _(u'Партнёры')
    active_menu_item = 'afl_bonus'
    template_page = '/partner.html'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('partner', '/partners/:id', controller=self, action='index',
                           requirements={'id': '[0-9]+'})

    def index(self, id, **params):
        try:
            ob = getV('partners')[id]
        except KeyError:
            raise cherrypy.HTTPError(404)

        if not ob.published:
            raise cherrypy.HTTPError(404)

        country_priority = get_priority(config.COUNTRY_PRIORITY)
        city_priority = get_priority(config.CITY_PRIORITY, mapper=city_iata2id)
        search_type_choices = TransVocabs.get_search_type_choices() \
                              if not self.is_mobile_page else \
                              TransVocabs.get_search_type_choices_mobile()
        contact_type_choices = TransVocabs.get_partner_office_contact_types().items()

        countries = json.dumps([{'code': c.country, 'name': unicode(c.title)}
                                for c in countries_available()])
        cities = json.dumps([{'id': c.id, 'name': unicode(c.title), 'country_code': c.country_code}
                             for c in cities_available()])
        categories = json.dumps([{'id': c.id, 'name': unicode(c.title)}
                                 for c in categories_available()] if categories_available else [])
        search_types = json.dumps([(k, unicode(v)) for k, v in search_type_choices])
        contact_types = json.dumps([(k, unicode(v)) for k, v in contact_type_choices])

        contacts_countries = json.dumps([{'code': c.country, 'name': unicode(c.title)}
                                         for c in countries_available(partners=[ob.id])])
        contacts_cities = json.dumps([{'id': c.id, 'name': unicode(c.title), 'country_code': c.country_code}
                                      for c in cities_available(partners=[ob.id])])

        partner = json.dumps({
            'title': unicode(ob.title),
            'logo': unicode(ob.default_logo_url),
            'image': ob.image,
            'description': unicode(ob.description),
            'url': unicode(ob.url_local),
            'mile_action': ob.mile_action,
            'mile_earn_comment': unicode(ob.mile_earn_comment),
            'mile_spend_comment': unicode(ob.mile_spend_comment),
            'special_offers_comment': unicode(ob.special_offers_comment),
            'id': id,
        })

        conditions = ob.get_award_conditions()
        conditions = sorted(conditions, key=lambda x: x.weight)
        lang = get_current_lang()

        earn_conditions = json.dumps([{'description': unicode(c.description),
                                       'miles': c.miles}
                                       for c in sorted(conditions, key=lambda x: x.weight) if c.is_earning])
        spend_conditions = json.dumps([{'description': unicode(c.description),
                                        'miles': c.miles}
                                       for c in conditions if c.is_spending])

        # Спецпредложения
        special_offers = json.dumps([{'name': unicode(o.name),
                                      'description': unicode(o.description.strip()),
                                      'url': unicode(o.url),
                                      'image': o.image}
                                     for o in ob.get_special_offers(lang)])

        banner_params = {key: json.dumps(value) for key, value in {
            'banner_url': (config.BANNERS_AJAX_URL if not self.is_mobile_page else config.URL_BANK_BANNER_MOBILE),
            'banner_params': {"lang": lang, "positions": [24, 25, 26]},
            'user_info': {"loyalty_id": "1111111", "tier_level": "BASIC"}
            }.items()}

        content = renderTemplate(self.template_page, countries=countries,
                                 country_priority=country_priority,
                                 city_priority=city_priority,
                                 cities=cities, categories=categories,
                                 search_types=search_types,
                                 contact_types=contact_types,
                                 contacts_countries=contacts_countries,
                                 contacts_cities=contacts_cities,
                                 partner=partner,
                                 earn_conditions=earn_conditions,
                                 spend_conditions=spend_conditions,
                                 default_country=params.get('country', ''),
                                 default_city=params.get('city', ''),
                                 special_offers=special_offers, **banner_params)

        return self.render(content, active_menu_subitem='partners')
