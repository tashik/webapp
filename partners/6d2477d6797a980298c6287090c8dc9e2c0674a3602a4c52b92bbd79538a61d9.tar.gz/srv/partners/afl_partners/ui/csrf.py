# -*- coding: utf-8 -*-

"""
$Id: csrf.py 3840 2014-03-13 14:49:05Z kmakarov $
"""

import sys
import cherrypy
from urlparse import urlparse
from pyramid.ui.error import dirlog
import config

REFERER_PREFIX = urlparse(config.EXT_SERVER_URL)[1].split(':')[0]


class CSRFRejected(cherrypy.HTTPError):
    def __init__(self, status=403, message='Forbidden'):
        super(CSRFRejected, self).__init__(status, message)


def reject():
    try:
        raise CSRFRejected()
    except CSRFRejected:
        exc_type, exc, tb = sys.exc_info()
        dirlog.log(exc, tb)
        raise exc_type, exc, tb


def check_referer():
    referer = cherrypy.request.headers.get('referer', '')
    if not referer.startswith(REFERER_PREFIX):
        reject()


# see http://stackoverflow.com/questions/3315914/is-this-sufficient-to-protect-against-a-csrf-for-an-ajax-driven-application?rq=1
def check_ajax():
    origin = cherrypy.request.headers.get('origin', None)
    if origin is not None:
        url = urlparse(origin)
        if url.scheme:
            # Chrome возвращает origin со схемой
            origin_host = url.netloc
        else:
            origin_host = origin
        if not origin_host == REFERER_PREFIX:
            reject()
    else:
        x_requested_with = cherrypy.request.headers.get('x-requested-with', '')
        if x_requested_with.lower() != 'xmlhttprequest':
            reject()


def check_submit(name_prefix='submit'):
    for k in cherrypy.request.params.keys():
        if k.startswith(name_prefix):
            check_referer()
            break
