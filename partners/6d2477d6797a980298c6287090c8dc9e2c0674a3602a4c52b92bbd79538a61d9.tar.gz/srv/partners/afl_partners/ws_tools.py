#!/usr/bin/env python
# -*- coding: utf-8 -*-

import cherrypy
import time
from cherrypy.lib import cptools

from i18n import _get_lang, _get_localization
import config


class Dotdict(dict):
    def __getattr__(self, attr):
        return self.get(attr, None)

def trusted_proxy(base=None, local='X-Forwarded-Host', remote='X-Forwarded-For',
                  scheme='X-Forwarded-Proto'):
    remote_ip = cherrypy.request.remote.ip
    if remote_ip not in config.PROXY_IP:
        cherrypy.log('Remote address (%s) is not in config.PROXY_IP' % remote_ip)
        raise cherrypy.HTTPError(403, 'Remote address is not in PROXY_IP')

    # Удаляем из X-Forwarded-For IP-адреса, входящие в PROXY_IP
    xff = cherrypy.request.headers.get(remote)
    if xff and remote == 'X-Forwarded-For':
        xff_parts = [ip for ip in xff.split(',') if ip.strip() not in config.PROXY_IP]
        cherrypy.request.headers[remote] = ','.join(xff_parts)

    return cptools.proxy(base=base, local=local, remote=remote, scheme=scheme)


# у пользователя на компьютере может быть установлено неправильное время
def clear_sess_cookie_expiry():
    cookie = cherrypy.response.cookie
    name = cherrypy.config.get('tools.sessions.name', 'session_id')
    if name in cookie:
        del cookie[name]['expires']
        # cookie[name]['HttpOnly'] = 1


def start_request_timer():
    cherrypy.request.start_time = time.time()


def set_current_lang_locale():
    cherrypy.request.current_lang = _get_lang()
    cherrypy.request.current_locale = _get_localization()


def set_endpoint():
    view = cherrypy.request.dispatch.mapper.match(cherrypy.request.path_info)
    if not view:
        raise cherrypy.HTTPError(404)
    controller = cherrypy.request.dispatch.controllers.get(view['controller'])
    endpoint_name = '%s.%s' % (controller.__class__.__name__, view['action'])
    cherrypy.request.endpoint = Dotdict(name=endpoint_name,
                                        route=view['controller'],
                                        controller=controller)


def is_xhr():
    # Определяем, что это AJAX-запрос
    environ = cherrypy.request.wsgi_environ
    cherrypy.request.is_xhr = environ.get('HTTP_X_REQUESTED_WITH', '').lower() == 'xmlhttprequest'
