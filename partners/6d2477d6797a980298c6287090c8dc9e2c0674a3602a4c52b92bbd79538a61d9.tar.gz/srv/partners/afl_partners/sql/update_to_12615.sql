insert into _schema_revisions (revision) values (12615);

ALTER TABLE tariff_groups ADD COLUMN weight integer not null default 0;

