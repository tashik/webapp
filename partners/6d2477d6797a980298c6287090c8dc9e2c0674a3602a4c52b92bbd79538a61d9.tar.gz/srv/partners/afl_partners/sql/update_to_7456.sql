begin;
insert into _schema_revisions (revision) values (7456);

-- Тарифные группы
create table tariff_groups (
  id integer not null primary key,
  service_class integer not null references skyteam_service_classes deferrable,
  tariff_group varchar(50) UNIQUE not null
);

-- Тарифные группы для авиакомпании
create table airline_tariff_groups(
  id integer not null primary key,
  tariff_group integer references tariff_groups(id) deferrable,
  service_class integer references airline_service_classes(airline_sc_id) deferrable,
  charge_coef integer not null,
  weight integer not null
);

-- Классы бронирования
CREATE TABLE booking_classes(
  id                integer not null primary key,
  bc_code           varchar(50) unique not null,
  miles_are_charged boolean not null,
  commentary        text,
  al_tariff_group   integer references airline_tariff_groups
                    deferrable
);

commit;
