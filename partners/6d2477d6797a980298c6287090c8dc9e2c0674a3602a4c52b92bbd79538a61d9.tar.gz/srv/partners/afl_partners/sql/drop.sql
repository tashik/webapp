-- $Id: drop.sql 8194 2014-11-21 21:02:27Z ogambaryan $

drop table _schema_revisions;
drop sequence global_seq;

drop table special_offers;
drop table partner_award_conditions;
drop table partner_office_contacts;
drop table partner_offices;
drop table partners;
drop table partner_categories;
drop table wrong_routes;
drop table booking_classes;
drop table pairs;
drop table awards;
drop table bonus_routes;
drop table tier_level_factors;
drop table tier_levels;
drop table airline_tariff_groups;
drop table tariff_groups;
drop table service_classes_limits;
drop table airline_service_classes;
drop table skyteam_service_classes;
drop table airports;
drop table redemption_zones;
drop table cities;
drop table countries;
drop table airlines;

