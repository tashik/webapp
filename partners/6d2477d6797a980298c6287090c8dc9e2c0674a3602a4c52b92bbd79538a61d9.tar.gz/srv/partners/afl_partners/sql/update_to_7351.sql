begin;
insert into _schema_revisions (revision) values (7351);

-- Добавляем колонки в таблицу cities
alter table cities add column tz varchar(32) not null;
alter table cities add column iata varchar(3);
alter table cities add column lat decimal(7,4);
alter table cities add column lon decimal(7,4);

-- Добавляем redemption_zone в таблицу airports
alter table airports add column redemption_zone varchar (2);

commit;
