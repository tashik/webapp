BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (9514);

-- Удаление колонки "Город базирования", добавление колонки "Аэропорт базирования" в модель "Авиакомпания".
ALTER TABLE airlines DROP COLUMN city_id;
ALTER TABLE airlines ADD COLUMN airport_id INTEGER;

COMMIT;
