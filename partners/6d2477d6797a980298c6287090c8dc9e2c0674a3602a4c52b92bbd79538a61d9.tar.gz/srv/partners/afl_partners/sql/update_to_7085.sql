insert into _schema_revisions (revision) values (7085);

-- авиакомпании
create table airlines (
  airline_id integer not null primary key,
  iata varchar(3) unique,
  icao varchar(3) unique,
  callsign varchar(64),
  country char(2) references countries(country) deferrable,
  names varchar(4096) not null,
  alliance varchar(16),
  parent_airline_id integer,
  logo_url varchar(256),
  url varchar(256),
  weight integer not null
);
