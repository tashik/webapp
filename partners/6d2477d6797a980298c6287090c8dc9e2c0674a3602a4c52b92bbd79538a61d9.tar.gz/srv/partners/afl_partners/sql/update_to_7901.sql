begin;
insert into _schema_revisions (revision) values (7901);

-- Спецпредложения
create table special_offers
(
  offer_id integer not null primary key,
  partner_id integer not null,
  names character varying(4096) not null,
  begin_date timestamp with time zone,
  end_date timestamp with time zone,
  status character varying(1) not null,
  offer_description text not null,
  offer_url character varying(4096) not null,
  ui_languages character varying(4096)
);
commit;