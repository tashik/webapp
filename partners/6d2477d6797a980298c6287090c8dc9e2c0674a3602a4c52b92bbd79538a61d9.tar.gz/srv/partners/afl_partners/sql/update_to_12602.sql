begin;

insert into _schema_revisions (revision) values (12602);

alter table partners alter column partner_description type text;
alter table partner_offices alter column worktime type text;
alter table partner_award_conditions alter column award_condition_description type text;

commit;