BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (8226);

-- Добавление колоноки "Примечания для набора миль"
ALTER TABLE partners ADD COLUMN spec_offer_comm text not null default '';

COMMIT;
