insert into _schema_revisions (revision) values (7365);
-- Статус учатника
create table tier_levels(
  tier_level varchar(16) not null primary key,  -- код статуса участника
  names varchar (4096) not null,                -- наименование статуса участника
  miles_factor decimal(3,2) not null,           -- коэффициент для начисления миль
  ordering integer not null                     -- вес записи
);