begin;
insert into _schema_revisions (revision) values (7470);

drop table booking_classes;
drop table airline_tariff_groups;
drop table tariff_groups;
drop table service_classes_limits;
drop table airline_service_classes;
drop table skyteam_service_classes;

-- Классы обслуживания SkyTeam
create table skyteam_service_classes (
  skyteam_sc_id int not null primary key,
  code varchar(4096) not null,
  names varchar(4096) not null
);

-- Классы обслуживания авиакомпаний
create table airline_service_classes (
  airline_sc_id int not null primary key,
  airline_id integer not null,
  skyteam_sc_id integer not null
);

-- Ограничения для классов обслуживания
create table service_classes_limits (
    service_classes_limit_id int not null primary key,
    airline_sc_id integer not null,
    pair_id integer not null
);

-- Тарифные группы
create table tariff_groups (
  tariff_group_id integer not null primary key,
  skyteam_sc_id integer not null,
  code varchar(50) unique not null
);

-- Тарифные группы для авиакомпании
create table airline_tariff_groups (
  airline_tariff_group_id integer not null primary key,
  tariff_group_id integer not null,
  airline_sc_id integer not null,
  charge_coef integer not null,
  weight integer not null
);

-- Классы бронирования
create table booking_classes (
  booking_class_id integer not null primary key,
  code varchar(50) unique not null,
  miles_are_charged boolean not null,
  text_comment text,
  airline_tariff_group_id integer not null
);

commit;
