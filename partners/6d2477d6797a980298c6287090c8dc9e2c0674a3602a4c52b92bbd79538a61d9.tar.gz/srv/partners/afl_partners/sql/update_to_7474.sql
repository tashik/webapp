begin;
insert into _schema_revisions (revision) values (7474);

alter table tariff_groups add names varchar (4096);
update tariff_groups set names = '';
alter table tariff_groups alter column names set not null;

commit;
