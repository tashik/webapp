begin;

insert into _schema_revisions (revision) values(7821);

-- Добавление колонки "перевозчик" в таблицу "премиальные зоны".
alter table redemption_zones add column carrier varchar(1);
update redemption_zones set carrier='A' where carrier IS NULL;
alter table redemption_zones alter column carrier set not null;

commit;
