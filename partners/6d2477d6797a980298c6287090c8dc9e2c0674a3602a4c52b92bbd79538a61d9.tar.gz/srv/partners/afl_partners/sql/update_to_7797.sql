begin;
insert into _schema_revisions (revision) values (7797);

alter table partners add column mile_get_comm text not null default '';
alter table partners add column mile_waste_comm text not null default '';
alter table partners add column short_descr text not null default '';

alter table partners alter column partner_categories set DEFAULT ''::character varying;
commit;
