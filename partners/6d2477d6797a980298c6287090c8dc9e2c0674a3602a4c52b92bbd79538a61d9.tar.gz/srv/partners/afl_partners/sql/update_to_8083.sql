begin;
insert into _schema_revisions (revision) values (8083);

alter table airlines drop column logo_url;
commit;
