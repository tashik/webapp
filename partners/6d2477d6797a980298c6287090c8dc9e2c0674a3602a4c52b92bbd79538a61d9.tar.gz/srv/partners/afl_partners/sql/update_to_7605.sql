begin;
insert into _schema_revisions (revision) values (7605);

ALTER TABLE skyteam_service_classes ADD COLUMN weight integer NOT NULL DEFAULT 0;

commit;
