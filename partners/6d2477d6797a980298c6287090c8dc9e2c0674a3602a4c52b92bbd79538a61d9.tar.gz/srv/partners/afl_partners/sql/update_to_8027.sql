begin;
insert into _schema_revisions (revision) values (8027);

alter table partner_award_conditions add column miles float not null default 0.0;
commit;
