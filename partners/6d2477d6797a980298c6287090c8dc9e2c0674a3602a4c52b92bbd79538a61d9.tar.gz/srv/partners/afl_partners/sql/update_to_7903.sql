begin;
insert into _schema_revisions (revision) values (7903);

-- Удаляем колонку carrier из таблицы redemption_zones
alter table redemption_zones drop column carrier;

commit;
