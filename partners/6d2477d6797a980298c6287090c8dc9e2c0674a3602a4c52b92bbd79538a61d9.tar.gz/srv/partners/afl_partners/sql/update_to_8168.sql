BEGIN;

-- Добаление колонок описания и комментариев по набору миль.
ALTER TABLE airlines ADD COLUMN miles_earn_description TEXT NOT NULL DEFAULT '';
ALTER TABLE airlines ADD COLUMN miles_earn_comment TEXT NOT NULL DEFAULT '';

COMMIT;
