begin;
insert into _schema_revisions (revision) values (7623);

-- Премиальные зоны
create table redemption_zones (
  redemption_zone varchar(2) not null primary key,  -- код премиальной зоны
  names varchar(4096) not null                      -- наименование премиальной зоны
);

-- Премиальные маршруты
create table bonus_routes (
  bonus_route_id integer not null primary key,
  code varchar(9) not null,
  zone_from varchar(2) not null,
  zone_via varchar(2),
  zone_to varchar(2) not null,
  carrier varchar(1) not null
);

-- Премии
create table awards (
  award_id integer not null primary key,
  award_type varchar(2) not null,
  airline_service_class_id_1 integer not null,
  airline_service_class_id_2 integer,
  award_value integer not null,
  bonus_route_id integer not null
);

-- Запрещённые маршруты
create table wrong_routes (
  wrong_route_id integer not null primary key,
  city_from_id integer not null,                -- город вылета
  city_via_id integer not null,                 -- город пересадки
  city_to_id integer not null                   -- город прилёта
);

commit;
