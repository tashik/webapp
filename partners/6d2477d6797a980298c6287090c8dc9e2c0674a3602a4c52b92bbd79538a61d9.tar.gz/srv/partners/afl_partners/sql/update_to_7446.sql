begin;
insert into _schema_revisions (revision) values (7446);

-- Классы обслуживания SkyTeam
create table skyteam_service_classes(
  skyteam_sc_id int not null primary key,
  code varchar(4096) not null,
  names varchar(4096) not null
);

-- Классы обслуживания авиакомпаний
create table airline_service_classes(
  airline_sc_id int not null primary key,
  airline_id int not null,
  skyteam_sc_id int not null
);

-- Ограничения для классов обслуживания
CREATE TABLE service_classes_limits(
    service_classes_limit_id int not null primary key,
    airline_sc_id integer not null,
    pair_id integer not null
);

commit;
