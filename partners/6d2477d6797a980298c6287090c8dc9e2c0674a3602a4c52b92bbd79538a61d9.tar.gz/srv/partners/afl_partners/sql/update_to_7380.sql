insert into _schema_revisions (revision) values (7380);
-- Статус учатника
drop table tier_levels;
create table tier_levels(
  tier_level varchar(16) not null  primary key, -- код статуса участника
  names varchar (4096) not null,                -- наименование статуса участника
  ordering integer not null,                    -- вес записи
  miles integer,                                -- Мили, количество миль для достижения уровня
  segments integer                              -- Сегменты, количество перелетов, которое необходимо совершить для достижения урованя
);
