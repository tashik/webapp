BEGIN;
INSERT INTO _schema_revisions (revision) values (7207);

ALTER TABLE partners DROP COLUMN logo_url;

COMMIT;
