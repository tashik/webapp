-- $Id: create.sql 25100 2017-06-09 13:37:46Z achunaev $

create sequence global_seq;

create table _schema_revisions (
  revision integer not null primary key,
  applied timestamp not null default NOW()
);

-- Страна
create table countries (
  country char(2) not null primary key,  -- двухзначный код страны
  iso_code3 varchar(3),                  -- см. http:--en.wikipedia.org/wiki/ISO_3166-1_alpha-3
  names varchar(4096) not null           -- наименование страны
);

-- Город
create table cities (
  city_id integer not null primary key, -- первичный ключ
  country char(2) not null,             -- iso_code2 данные страны
  tz varchar(32) not null,              -- часовой пояс
  iata varchar(3),                      -- код по IATA
  lat decimal(7,4),                     -- широта
  lon decimal(7,4),                     -- долгота
  names varchar(4096) not null          -- наименование города
);

-- Аэропорты
create table airports (
  airport_id integer not null primary key,  -- первичный ключ
  city_id integer not null,                 -- город, где расположен аэропорт
  iata varchar(3) unique,                   -- iata код аэропорта
  icao varchar(4) unique,                   -- icao код аэропорта
  names varchar(4096) not null,             -- наименование аэропорта
  afl_redemption_zone varchar (2),          -- премиальная зона Аэрофлота
  skyteam_redemption_zone varchar (2),      -- премиальная зона SkyTeam
  lat decimal(7,4),                         -- широта
  lon decimal(7,4),                         -- долгота
  has_uc_award boolean not null default false -- доступна премия за повышение класса обслуживания при регистрации
);

-- Пары
create table pairs (
  pair_id integer not null primary key, -- первичный ключ
  airport_from_id integer not null,     -- аэропорт вылета
  airport_to_id integer not null,       -- аэропорт прилета
  airline_id integer not null,          -- авиакомпания
  miles integer,                        -- расстояние
  no_spending boolean                   -- не предоставлять трату миль
);

-- Авиакомпании
create table airlines (
  airline_id integer not null primary key,
  iata varchar(3) unique,
  icao varchar(3) unique,
  callsign varchar(64),
  country char(2),
  airport_id integer,
  names varchar(4096) not null,
  alliance varchar(16),
  parent_airline_id integer,
  url varchar(1024),
  weight integer not null,
  miles_minimum float not null default 0.0,
  miles_limitation varchar(1) not null default 'N',
  miles_earn_description text not null default '',
  miles_earn_comment text not null default ''
);

-- Классы обслуживания SkyTeam
create table skyteam_service_classes (
  skyteam_sc_id int not null primary key,
  code varchar(4096) not null,
  names varchar(4096) not null,
  weight integer not null
);

-- Классы обслуживания авиакомпаний
create table airline_service_classes (
  airline_sc_id int not null primary key,
  airline_id integer not null,
  skyteam_sc_id integer not null
);

-- Ограничения для классов обслуживания
create table service_classes_limits (
  service_classes_limit_id int not null primary key,
  airline_sc_id integer not null,
  pair_id integer not null
);

-- Тарифные группы
create table tariff_groups (
  tariff_group_id integer not null primary key,
  skyteam_sc_id integer not null,
  code varchar(50) unique not null,
  names varchar(4096) not null,
  weight integer not null default 0
);

-- Тарифные группы для авиакомпании
create table airline_tariff_groups (
  airline_tariff_group_id integer not null primary key,
  tariff_group_id integer not null,
  airline_sc_id integer not null,
  charge_coef integer not null,
  weight integer not null,
  fare_code character varying(50)
);

-- Классы бронирования
create table booking_classes (
  booking_class_id integer not null primary key,
  code varchar(50) not null,
  miles_are_charged boolean not null,
  text_comment text,
  airline_tariff_group_id integer not null,
  unique(code, airline_tariff_group_id)
);

-- Статусы участника
create table tier_levels (
  tier_level varchar(16) not null primary key,  -- код статуса участника
  names varchar (4096) not null,                -- наименование статуса участника
  ordering integer not null,                    -- вес записи
  miles integer,                                -- Мили, количество миль для достижения уровня
  segments integer                              -- Сегменты, количество перелетов, которое необходимо совершить для достижения урованя
);

-- Коэффициенты статуса участника
create table tier_level_factors (
  tier_level_factor_id int not null primary key,
  airline_id int not null,
  tier_level varchar(16) not null,
  factor decimal(7,4) not null
);

-- Премиальные зоны
create table redemption_zones (
  redemption_zone varchar(2) not null primary key,  -- код премиальной зоны
  names varchar(4096) not null                      -- наименование премиальной зоны
);

-- Премиальные маршруты
create table bonus_routes (
  bonus_route_id integer not null primary key,
  code varchar(9) not null,
  zone_from varchar(2) not null,
  zone_via varchar(2),
  zone_to varchar(2) not null,
  carrier varchar(1) not null
);

-- Премии
create table awards (
  award_id integer not null primary key,
  award_type varchar(2) not null,
  skyteam_service_class_id_1 integer not null,
  skyteam_service_class_id_2 integer,
  award_value integer not null,
  bonus_route_id integer not null
);

-- Запрещённые маршруты
create table wrong_routes (
  wrong_route_id integer not null primary key,
  city_from_id integer not null,                -- город вылета
  city_via_id integer not null,                 -- город пересадки
  city_to_id integer not null                   -- город прилёта
);

-- Категории партнёров-неавиакомпаний
create table partner_categories (
  partner_category_id integer not null primary key,
  status varchar(1) not null,
  names varchar(4096) not null
);

-- Партнёры-неавиакомпании
create table partners (
  partner_id integer not null primary key,
  names varchar(4096) not null,
  partner_description text not null,
  url varchar(1024),
  partner_categories varchar (4096),
  status varchar (1),
  mile_action varchar (1),
  mile_get_comm text not null default '',
  mile_waste_comm text not null default '',
  short_descr text not null default '',
  spec_offer_comm text not null default '',
  weight integer not null,
  new_until date
);

-- Филиалы  партнёров-неавиакомпаний
create table partner_offices (
  partner_office_id integer not null primary key,
  partner_id  integer,
  city_id integer,
  lat decimal(7,4),
  lon decimal(7,4),
  comments text,
  address text,
  worktime text,
  office_type varchar(1)
);

-- Контакты филиалов партнёров-неавиакомпаний
create table partner_office_contacts (
  partner_office_contact_id integer not null primary key,
  partner_office_id integer,
  contact_type varchar(1) not null,
  contact varchar(4096) not null,
  main_contact boolean default false
);

-- Условия набора и траты миль для партнёров-неавиакомпаний
create table partner_award_conditions (
  partner_award_condition_id integer not null primary key,
  partner_id  integer not null,
  award_condition_type varchar(1) not null,
  award_condition_description text not null,
  weight integer not null,
  status varchar(1) not null,
  miles float not null default 0.0
);


-- Спецпредложения
create table special_offers
(
  offer_id integer not null primary key,
  partner_id integer not null,
  names character varying(4096) not null,
  begin_date timestamp with time zone,
  end_date timestamp with time zone,
  status character varying(1) not null,
  offer_description text not null,
  offer_url character varying(4096) not null,
  ui_languages character varying(4096)
);

