BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (10967);

ALTER TABLE awards ADD COLUMN skyteam_service_class_id_1 INTEGER;
ALTER TABLE awards ADD COLUMN skyteam_service_class_id_2 INTEGER;

UPDATE awards SET skyteam_service_class_id_1=ascl.skyteam_sc_id FROM airline_service_classes ascl WHERE awards.airline_service_class_id_1=ascl.airline_sc_id;
UPDATE awards SET skyteam_service_class_id_2=ascl.skyteam_sc_id FROM airline_service_classes ascl WHERE awards.airline_service_class_id_2=ascl.airline_sc_id AND awards.airline_service_class_id_2 IS NOT NULL;

ALTER TABLE awards ALTER COLUMN skyteam_service_class_id_1 SET NOT NULL;
ALTER TABLE awards DROP COLUMN airline_service_class_id_1;
ALTER TABLE awards DROP COLUMN airline_service_class_id_2;

COMMIT;
