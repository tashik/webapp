BEGIN;

INSERT INTO _schema_revisions (revision) values (9434);

ALTER TABLE airlines ADD COLUMN city_id INTEGER;
COMMIT;
