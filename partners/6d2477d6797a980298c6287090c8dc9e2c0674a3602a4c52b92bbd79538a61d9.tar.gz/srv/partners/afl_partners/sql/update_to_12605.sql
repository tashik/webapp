BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (12605);

ALTER TABLE airline_tariff_groups ADD COLUMN fare_code character varying(50);

END;