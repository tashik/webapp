begin;

insert into _schema_revisions (revision) values (12600);

alter table partner_offices alter column address type text;
alter table partner_offices alter column comments type text;


commit;