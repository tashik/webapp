begin;
insert into _schema_revisions (revision) values (7310);

-- Пары
create table pairs (
  pair_id integer not null primary key, -- первичный ключ
  airport_from_id integer not null,     -- аэропорт вылета
  airport_to_id integer not null,       -- аэропорт прилета
  airline_id integer not null,          -- авиакомпания
  miles integer                         -- расстояние
);

commit;