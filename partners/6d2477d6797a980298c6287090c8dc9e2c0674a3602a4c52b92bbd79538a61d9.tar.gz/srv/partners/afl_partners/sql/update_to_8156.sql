BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (8156);
ALTER TABLE booking_classes DROP CONSTRAINT booking_classes_code_key;
ALTER TABLE booking_classes ADD UNIQUE(code, airline_tariff_group_id);

COMMIT;
