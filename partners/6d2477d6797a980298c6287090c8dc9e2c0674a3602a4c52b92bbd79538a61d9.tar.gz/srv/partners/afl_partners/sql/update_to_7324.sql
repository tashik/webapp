begin;
insert into _schema_revisions (revision) values (7324);

-- Убираем FK constraint с колонки airlines.country
alter table airlines drop constraint airlines_country_fkey;
alter table airlines alter COLUMN country type char(2);

commit;
