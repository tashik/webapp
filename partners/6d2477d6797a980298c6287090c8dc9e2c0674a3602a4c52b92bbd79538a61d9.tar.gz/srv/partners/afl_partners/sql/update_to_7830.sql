begin;

insert into _schema_revisions (revision) values(7830);

-- Разбиение колонки "код зоны" на две: для Аэрофлота и для SkyTeam.
alter table airports rename column redemption_zone to afl_redemption_zone;
alter table airports add column skyteam_redemption_zone varchar(2);

commit;
