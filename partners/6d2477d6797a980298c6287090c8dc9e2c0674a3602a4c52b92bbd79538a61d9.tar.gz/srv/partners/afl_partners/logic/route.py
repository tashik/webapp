# -*- coding: utf-8 -*-

from itertools import product, izip, tee

from pyramid.vocabulary import getV

from logic.geo import get_airports_by_iata, get_airport_city
from models.route import Pair


TYPE_EARN = 'earn'
TYPE_SPEND = 'spend'


def available_pairs(airline_id=None, search_type=None):
    u"""Пары, доступные для авиакомпании и типа поиска."""

    def f(pair):
        result = []
        if airline_id is not None:
            result.append(int(pair.airline_id) == airline_id)
        if search_type is not None:
            if search_type == TYPE_EARN:
                result.append(True)
            elif search_type == TYPE_SPEND:
                result.append(not pair.no_spending)
        return all(result)

    return list(set([(p.airport_from_id, p.airport_to_id) for p in getV('pairs') if f(p)]))


def available_airports(airline_id):
    u"""Аэропорты, в которые летает авиакомпания."""

    return list(set(sum(available_pairs(airline_id=airline_id), ())))


def all_available_pairs():
    u"""Все доступные пары."""

    return list(set([(p.airport_from_id, p.airport_to_id) for p in getV('pairs')]))


def all_available_airports():
    u"""Все аэропорты, в которые осуществляют полёты авиакомпании."""

    airports = set([])
    for ap1, ap2 in all_available_pairs():
      airports.add(ap1)
      airports.add(ap2)
    return list(airports)


def airports_by_iata(iata, available=None):
    u"""Получение списка аэропортов по IATA коду (города или аэропорта)."""

    airports = set([ob.airport_id for ob in get_airports_by_iata(iata)])

    if available is not None:
        airports &= set(available)

    return airports


def is_pair_international(pair):
    u"""Проверка является ли перелёт международным или нет."""

    assert isinstance(pair, Pair)
    c1 = get_airport_city(pair.airport_from_id)
    c2 = get_airport_city(pair.airport_to_id)
    if c1 and c2:
        return c1.country_code != c2.country_code
    return False


def available_routes(*args, **kwargs):
    u"""Генератор всех возможных маршрутов.

    Arguments:
    sets of locations

    Keyword arguments:
    airline_id -- ограничение по авиакомпании
    """

    airline_id = kwargs.get('airline_id')
    s = map(lambda x: x or [None], args)
    for r in product(*s):
        if airline_id is None:
            yield r
        else:
            pairs = [Pair.search(*s, **{'airline_id': airline_id}) for s in route_to_segments(*r)]
            if pairs and all(pairs):
                yield r


def pairwise(iterable):
    "s -> (s0,s1), (s1,s2), (s2, s3), ..."
    a, b = tee(iterable)
    next(b, None)
    return izip(a, b)


def route_to_segments(*args):
    u"""Генератор возможных сегментов для маршрута."""

    iterable = [a for a in args if a is not None]
    for s in pairwise(iterable):
        yield s


class RouteSolver(object):
    def __init__(self, routes):
        self.routes = routes

        self._map = {}
        for p1, p2 in self.routes:
            self._map.setdefault(p1, set([])).add(p2)
            self._map.setdefault(p2, set([])).add(p1)

    def get_full_routes(self):
        u"""Все возможные маршруты (прямые, с одной пересадкой)."""

        result = set([])

        for p1, p2 in self.routes:
            result.add((p1, p2, None))
            result.add((p2, p1, None))

            locations1 = self._get_nearest_locations(p1, exclude=p2)
            for l1 in locations1:
                result.add((l1, p1, p2))

            locations2 = self._get_nearest_locations(p2, exclude=p1)
            for l2 in locations2:
                result.add((l2, p2, p1))

        return result

    def get_locations(self):
        u"""Список возможных точек отправления."""

        return set(self._map.keys())

    def get_to_locations(self, p_from):
        u"""Список возможных точек прибытия."""

        locations = self._get_nearest_locations(p_from)

        _locations = locations.copy()
        for p in locations:
            ps = self._get_nearest_locations(p, exclude=p_from)
            _locations |= ps

        return _locations

    def get_to_locations2(self, p_from):
        u"""Расширенный список возможных точек прибытия."""

        locations = self._get_nearest_locations(p_from)

        _locations = locations.copy()
        direct_locations = locations.copy()
        via_loactions = set([])
        for p in locations:
            ps = self._get_nearest_locations(p, exclude=p_from)
            _locations |= ps
            via_loactions |= ps

        return (_locations, direct_locations, via_loactions)

    def get_via_locations(self, p_from, p_to):
        u"""Список возможных точек пересадок."""

        locations1 = self._get_nearest_locations(p_from)
        locations2 = self._get_nearest_locations(p_to)

        return locations1 & locations2

    def check_direct_flight(self, p_from, p_to):
        u"""Проверка возможности прямого перелёта между точками."""

        return (p_from, p_to) in self.routes or (p_to, p_from) in self.routes

    def _get_nearest_locations(self, p, exclude=None):
        result = self._map[p].copy()

        if exclude is not None:
            try:
                result.remove(exclude)
            except KeyError:
                pass

        return result
