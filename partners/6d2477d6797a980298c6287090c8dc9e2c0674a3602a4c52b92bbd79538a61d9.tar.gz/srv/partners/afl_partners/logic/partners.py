# -*- coding: utf-8 -*-

from pyramid.vocabulary import getV

from i18n import get_current_lang


def cities_available(partners=None, country=None):
    u"""Список городов, в котором есть партнёры
        partnes = список id партнёров
        country = двухзначный код страны
    """
    cities = getV('cities')
    partners_vocab = getV('partners')
    if partners is not None:
        partners = [partners_vocab[id] for id in partners]
    else:
        partners = partners_vocab
    city_ids = []
    for partner in partners:
        if partner.published:
            offices = partner.get_offices()
            for office in offices:
                city_ids.append(office.city)
    city_ids = set(city_ids)

    if country is None:
        data = [cities[cities_id] for cities_id in city_ids]
    else:
        data = [cities[cities_id] for cities_id in city_ids if cities[cities_id].country_code == country]
    return data


def countries_available(partners=None):
    u"""Список стран, в которых есть филиалы партнёров
        partnes = список id партнёров
    """
    cities = getV('cities')
    countiries = getV('countries')
    partners_vocab = getV('partners')
    if partners is not None:
        partners = [partners_vocab[id] for id in partners]
    else:
        partners = partners_vocab
    countiry_ids = []
    for partner in partners:
        if partner.published:
            offices = partner.get_offices()
            for office in offices:
                city_id = office.city
                countiry_ids.append(cities[city_id].country_code)
    countiry_ids = set(countiry_ids)
    data = [countiries[country_id] for country_id in countiry_ids]
    return data


def categories_available():
    u"""Список категорий, в которых есть партнёры"""

    partners = getV('partners')
    categories = getV('partner_categories')
    available_categories = []
    for partner in partners:
        if partner.published:
            available_categories.extend(filter(bool, partner.partner_categories))
    available_categories = set(available_categories)
    data = [categories[category_id] for category_id in available_categories]
    return data


def search_partners(country=None, city=None, categories=None, q=None,
                    search_type=None, language=None):
    u"""Поиск партнёров по параметрам"""

    language = language or get_current_lang()

    result = []

    for ob in getV('partners'):
        if not ob.published:
            continue
        if city and not ob.check_city(city):
            continue
        if country and not ob.check_country(country):
            continue
        if categories and not ob.check_categories(categories):
            continue
        if q and not ob.check_name(q, language):
            continue
        if search_type and not ob.check_mile_action(search_type):
            continue

        result.append(ob)

    return result


def search_offices(partner, country=None, city=None):
    u"""Поиск офисов партнёров по параметрам"""

    result = []

    for ob in partner.get_offices():
        if city and not ob.check_city(city):
            continue
        if country and not ob.check_country(country):
            continue

        result.append(ob)

    return result

