# -*- coding: utf-8 -*-


from pyramid.vocabulary import getV, getVI

import log


LOG = log.log.notification_logger.info


def load_airport(airport_id):
    try:
        return getV('airports')[airport_id]
    except LookupError:
        if airport_id is not None:
            LOG('Missing data for Airport with id=%s' % airport_id)


def load_city(city_id):
    try:
        return getV('cities')[city_id]
    except LookupError:
        if city_id is not None:
            LOG('Missing data for City with id=%s' % city_id)


def load_country(country_code):
    try:
        return getV('countries')[country_code]
    except LookupError:
        if country_code is not None:
            LOG('Missing data for Country with code=%s' % country_code)


def load_airport_by_iata(iata):
    c_idx = getVI('airports_by_iata_idx')
    try:
        return c_idx(context=iata)[0]
    except IndexError:
        pass


def load_city_by_iata(iata):
    c_idx = getVI('cities_by_iata_idx')
    try:
        return c_idx(context=iata)[0]
    except IndexError:
        pass


def iata_valid(iata):
    a_idx = getVI('airports_by_iata_idx')
    c_idx = getVI('cities_by_iata_idx')
    return len(a_idx(context=iata)) or len(c_idx(context=iata))


def get_airports_by_iata(iata):
    # аэропорт имеет приоритет, так как возможна ситуация, когда код города
    # совпадает с одним из кодов аэропортов
    airport = load_airport_by_iata(iata)
    if airport is not None:
        return [airport]
    else:
        city = load_city_by_iata(iata)
        if city is not None:
            return getVI('airports_by_city_idx')(context=city)

    return []


def get_airport_city(airport_id):
    ob = load_airport(airport_id)
    if ob is not None:
        return load_city(ob.city_id)

