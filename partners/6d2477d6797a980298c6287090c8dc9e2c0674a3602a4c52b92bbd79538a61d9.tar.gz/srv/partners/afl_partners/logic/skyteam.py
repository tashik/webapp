# -*- coding: utf-8 -*-
import json
from operator import itemgetter
from pyramid.vocabulary import getV, getVI

from i18n import get_current_lang

from rx.i18n.translation import SelfTranslationDomain

import log
import models.air
import models.award
import models.bonus
import models.route
from logic.route import is_pair_international
from models.interfaces import IAirline
from models.ml import MLNames
import config
from zope.schema import getFieldsInOrder
from zope.schema.interfaces import ITokenizedTerm

LOG = log.log.notification_logger.info


flight_code_mapping = {'A5': 'AF',     # HOP! -- дочерняя Air France
                       'XM': 'AZ',     # AlItalia Express
                       'AP': 'AZ',     # AirOne
                       'PW': 'KQ',     # Precision Air -- дочерняя Kenya Airways
                       'WA': 'KL'}     # KLM Cityhopper -- дочерняя KLM


def load_airline(airline_id):
    try:
        return getV('airlines')[airline_id]
    except LookupError:
        if airline_id is not None:
            LOG('Missing data for Airline with id=%s' % airline_id)


def load_airline_by_iata(iata):
    c_idx = getVI('airlines_by_iata_idx')
    try:
        return c_idx(context=iata)[0]
    except IndexError:
        pass


def flight_code(airline):
    u"""Для некоторых дочерних АК код рейса берётся из родительской."""

    if airline.parent_airline_id is not None:
        parent = getV('airlines')[airline.parent_airline_id]
        if parent.iata and flight_code_mapping.get(airline.iata) == parent.iata:
            return parent.iata

    return airline.iata


def available_tier_levels(airline):
    u"""Список всех возможных кодов статусов участников для авиакомпании."""

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    return set([ob.tier_level for ob in getVI('tier_level_factors_by_airline_idx')(context=airline)])


def resolve_tier_level_factor(tier_level, airline):
    u"""Коэффициент статуса участника по названию статуса и авиакомпании."""

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    obs = [ob for ob in getVI('tier_level_factors_by_airline_idx')(context=airline) if ob.tier_level == tier_level]
    try:
        return obs[0]
    except IndexError:
        pass
    return None


def available_tariff_groups(airline):
    u"""Список всех возможных кодов тарифных групп для авиакомпании."""

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    ids = set([])
    for sc in getVI('airline_service_classes_by_airline_idx')(context=airline):
        ids |= set([ob.tariff_group_id for ob in
                    getVI('airline_tariff_groups_by_airline_service_class_idx')(context=sc)])

    result = []
    v = getV('tariff_groups')
    for tg_id in ids:
        try:
            result.append(v[tg_id].code)
        except LookupError:
            pass

    return result


def available_airline_tariff_groups(airline):
    u"""Список всех возможных кодов тарифных групп для авиакомпании."""

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    result = []
    for sc in getVI('airline_service_classes_by_airline_idx')(context=airline):
        for ob in getVI('airline_tariff_groups_by_airline_service_class_idx')(context=sc):
            if ob.fareCode:
                result.append(ob.fareCode)

    return result


def available_booking_classes(airline):
    u"""Список ID всех классов бронирования для авиакомпании."""

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    bcl_idx = getVI('booking_classes_by_airline_tariff_group_idx')
    atg_idx = getVI('airline_tariff_groups_by_airline_service_class_idx')

    ids = set([])
    for sc in getVI('airline_service_classes_by_airline_idx')(context=airline):
        for atg in atg_idx(context=sc):
            ids |= set([bcl.booking_class_id for bcl in bcl_idx(context=atg)])
    return ids


def tariff_groups_by_booking_class(airline, booking_class_code):
    u"""Возвращает коды тарифных групп по коду класса бронирования и авиакомпании."""
    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    bcl_idx = getVI('booking_classes_by_airline_tariff_group_idx')
    atg_idx = getVI('airline_tariff_groups_by_airline_service_class_idx')
    tg_vocab = getV('tariff_groups')

    airline_tariff_groups = []
    for sc in getVI('airline_service_classes_by_airline_idx')(context=airline):
        airline_tariff_groups += [atg for atg in atg_idx(context=sc) if booking_class_code in [bcl.code for bcl in bcl_idx(context=atg)]]

    result = [tg_vocab[atg.tariff_group_id].code for atg in sorted(airline_tariff_groups, key=lambda atg: atg.charge_coef)]
    return result


def airline_to_dict(airline, ml_fnc, fields=None, exclude=None, fieldmap=None,
                    fieldfmt=None, lang=None):
    u"""
        Словарь атрибутов авиакомпании на основе полей IAirline.

        @param airline              Airline record
        @param ml_fnc(value, lang)  Функция для преобразования полей типа MLNames
        @param fields               Какие поля обрабатывать (если None, то все)
        @param exclude              Какие поля пропустить (имеет смысл, если fields=None)
        @param fieldmap             Под какими ключами записать (dict {fieldname: key})
        @param fieldfmt             Formatters (dict {fieldname: func})
        @param lang                 Язык (второй аргумент для ml_fnc)
    """
    if fieldmap is None:
        fieldmap = {'airline_id': 'id'}

    fieldfmt = fieldfmt or {}

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    result = {}
    for fieldname, field in getFieldsInOrder(IAirline):
        if fields and fieldname not in fields:
            continue

        if exclude and fieldname in exclude:
            continue

        val = getattr(airline, fieldname)

        try:
            fmt = fieldfmt[fieldname]
            val = fmt(val)
        except KeyError:
           pass

        try:
            key = fieldmap[fieldname]
        except KeyError:
            key = fieldname

        if isinstance(field, MLNames):
            val = ml_fnc(val, lang)

        result[key] = val

    return result


def get_fake_miles_table(lang=None, airline=None):
    u"""Данные для таблицы набора миль в формате:

        [(skyteam_service_class, [([booking_class.code], charge_coef)])]
    """

    result = []
    lang = lang if lang else 'ru'
    try:
        with open('{0}/json/{1}.json'.format(config.STATICDIR, airline)) as data_file:
            service_data = json.load(data_file)
            for sscl_data in service_data:
                result.append((sscl_data[0].get(lang, 'en'), [(sscl[0], sscl[1]) for sscl in sscl_data[1]]))
    except IOError:
        pass
    return result

def get_miles_table_with_tariff_code(airline, sc_fnc, lang=None):
    u"""Данные для таблицы набора миль в формате с двойным названием тарифа:

        [(skyteam_service_class, [(tariff_groups, [([booking_class.code], charge_coef)])])]
    """

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    result = []
    skyteam_sc_vocab = getV('skyteam_service_classes') # Классы обслуживания SkyTeam
    atg_idx = getVI('airline_tariff_groups_by_airline_service_class_idx') # Тарифные группы для авиакомпаний
    bcl_idx = getVI('booking_classes_by_airline_tariff_group_idx') # Классы бронирования
    tg_vocab = getV('tariff_groups') # Тарифные группы

     # Сортируем классы бронирования по алфавиту, а тарифные группы АК -- по коэффициенту.
    for ascl in getVI('airline_service_classes_by_airline_idx')(context=airline): # Классы обслуживания авиакомпаний
        skyteam_sc = skyteam_sc_vocab.get(ascl.skyteam_sc_id)
        if not skyteam_sc: continue
        skyteam_sc_name = sc_fnc(skyteam_sc, lang)

        airline_tariff_groups = atg_idx(context=ascl)
        atg_result = {}
        for atg in airline_tariff_groups:
            tariff_group = tg_vocab.get(atg.tariff_group_id)
            if not tariff_group: continue
            if bcl_idx(context=atg) and atg.fareCode:
                bcl_result = sorted(
                    [{'id': bcl.booking_class_id, 'code': u'{0}{1}'.format(bcl.code, atg.fareCode)}
                     for bcl in bcl_idx(context=atg) if bcl.miles_are_charged], key=itemgetter('code'))
                if bcl_result:
                    atg_result.setdefault((sc_fnc(tariff_group, lang), tariff_group.weight), []).append((bcl_result, atg.charge_coef, -atg.weight))

        if atg_result:
            atg_result = sorted(atg_result.iteritems(), key=lambda x: int(x[0][1]), reverse=True)
            atg_result = [(key[0], [(item[0], item[1]) for item in sorted(items, key=itemgetter(2))]) for key, items in atg_result]
            result.append((skyteam_sc_name, atg_result, -skyteam_sc.weight))
    return map(itemgetter(0, 1),  sorted(result, key=itemgetter(2)))


def get_miles_table(airline, sc_fnc, lang=None):
    u"""Данные для таблицы набора миль в формате:

        [(skyteam_service_class, [([booking_class.code], charge_coef)])]
    """

    if not IAirline.providedBy(airline):
        airline = load_airline(airline)

    result = []
    skyteam_sc_vocab = getV('skyteam_service_classes')
    atg_idx = getVI('airline_tariff_groups_by_airline_service_class_idx')
    bcl_idx = getVI('booking_classes_by_airline_tariff_group_idx')

    for ascl in getVI('airline_service_classes_by_airline_idx')(context=airline):

        airline_tariff_groups = atg_idx(context=ascl)

        # Сортируем классы бронирования по алфавиту, а тарифные группы АК -- по коэффициенту.

        booking_classes = map(itemgetter(0, 1), sorted(
            [(sorted([{'id': bcl.booking_class_id, 'code': bcl.code}
                       for bcl in bcl_idx(context=atg) if bcl.miles_are_charged], key=itemgetter('code')),
              atg.charge_coef, -atg.charge_coef)
             for atg in airline_tariff_groups if bcl_idx(context=atg) and not atg.fareCode],
            key=itemgetter(2)))
        if booking_classes:
            skyteam_sc = skyteam_sc_vocab[ascl.skyteam_sc_id]
            result.append((sc_fnc(skyteam_sc, lang), booking_classes,
                           -skyteam_sc.weight))

    return map(itemgetter(0, 1),  sorted(result, key=itemgetter(2)))


def extend_miles_table_with_tariff_code(miles_table, ml_fnc, lang=None):
    u"""Расширение данных для таблицы набора миль информацией о комментариях к классам бронирования"""

    booking_class_dict = getV('booking_classes')
    booking_class_comments = []
    booking_class_notes = {}
    next_note = 1
    for skyteam_sc, airline_tariff in miles_table:
        for tariff_groups_name, airline_tariff_groups in airline_tariff:
            for booking_classes, charge_coefficient in airline_tariff_groups:
                for booking_class in booking_classes:
                    if booking_class['id'] in booking_class_notes:
                        booking_class['note'] = booking_class_notes[booking_class['id']]
                    else:
                        bc = booking_class_dict[booking_class['id']]
                        comment = bc.text_comment
                        comment = ml_fnc(comment, lang)

                        not_empty = comment
                        if isinstance(comment, dict):
                            not_empty = any(comment.values())

                        if not_empty:
                            booking_class_notes[booking_class['id']] = next_note
                            booking_class_comments.append((next_note, comment))
                            booking_class['note'] = next_note
                            next_note += 1

    return booking_class_comments

def extend_miles_table(miles_table, ml_fnc, lang=None):
    u"""Расширение данных для таблицы набора миль информацией о комментариях к классам бронирования"""

    booking_class_dict = getV('booking_classes')
    booking_class_comments = []
    booking_class_notes = {}
    next_note = 1
    for skyteam_sc, airline_tariff_groups in miles_table:
        for booking_classes, charge_coefficient in airline_tariff_groups:
            for booking_class in booking_classes:
                if booking_class['id'] in booking_class_notes:
                    booking_class['note'] = booking_class_notes[booking_class['id']]
                else:
                    bc = booking_class_dict[booking_class['id']]
                    comment = bc.text_comment
                    comment = ml_fnc(comment, lang)

                    not_empty = comment
                    if isinstance(comment, dict):
                        not_empty = any(comment.values())

                    if not_empty:
                        booking_class_notes[booking_class['id']] = next_note
                        booking_class_comments.append((next_note, comment))
                        booking_class['note'] = next_note
                        next_note += 1

    return booking_class_comments


def search_afl_airlines(q=None, language=None):
    u"""Поиск авиакомпаний, входящих в AFL, по названию."""

    language = language or get_current_lang()

    result = []
    afl = load_airline_by_iata(config.AFL_AIRLINE_IATA)
    afl_token = int(ITokenizedTerm(afl).token)
    result.append(afl)

    for ob in getV('airlines'):
        if ob.parent_airline_id != afl_token:
            continue
        if q and not ob.check_name(q, language):
            continue
        ob.localized_logo_url = SelfTranslationDomain().translate(ob.logo_urls, target_language=language)
        result.append(ob)
    return result


def search_skyteam_airlines(q=None, language=None, full=False):
    u"""Поиск авиакомпаний, входящих в SkyTeam, по названию.
        full=True -- включать дочерние авиакомпании.
    """

    language = language or get_current_lang()

    result = []
    for ob in getV('airlines'):
        if ob.alliance != 'SkyTeam':
            # Авиакомпании не из SkyTeam пропускаем
            continue
        if not full and ob.parent_airline_id is not None:
            # Дочерние авиакомпании пропускаем
            continue
        if q and not ob.check_name(q, language):
            continue
        ob.localized_logo_url = SelfTranslationDomain().translate(ob.logo_urls, target_language=language)
        result.append(ob)
    return result


class MilesCalculatorResult(object):
    def __init__(self, distance, charged_miles, qualifying_miles, bonus_miles,
                 distance_miles):
        self.distance = distance
        self.charged_miles = charged_miles
        self.qualifying_miles = qualifying_miles
        self.bonus_miles = bonus_miles
        self.distance_miles = distance_miles

    def attrs(self):
        attrs = []

        attrs.append(('distance', '%d' % self.distance))  # расстояние
        attrs.append(('chargedMiles', '%d' % self.charged_miles))  # общее кол-во начисленных миль
        attrs.append(('qualifyingMiles', '%d' % self.qualifying_miles))  # квалификационные мили в зависимости от тарифа
        attrs.append(('bonusMiles', '%d' % self.bonus_miles))  # бонусные мили в зависимости от уровня участника
        attrs.append(('promoMiles', '%d' % self.distance_miles))  # бонусные мили в зависимости от направления

        return attrs


class MilesCalculator(object):
    miles_minimum = 0

    def __init__(self, a1_id, a2_id, tier_level_factor, airline_tariff_group):
        assert isinstance(tier_level_factor, models.bonus.TierLevelFactor)
        assert isinstance(airline_tariff_group, models.bonus.AirlineTariffGroup)
        assert tier_level_factor.airline_id == airline_tariff_group.airline_sc.airline_id

        self.a1_id = a1_id
        self.a2_id = a2_id
        self.tier_level_factor = tier_level_factor
        self.airline_tariff_group = airline_tariff_group
        self.airline_id = tier_level_factor.airline_id

    def calculate(self):
        distance = 0
        result = 0
        tariff_bonus_miles = 0
        status_bonus_miles = 0
        distance_miles = 0

        pair = models.route.Pair.search(self.a1_id, self.a2_id, self.airline_id)
        if pair is not None:
            miles_limitation = models.air.MILES_NO_LIMIT
            miles_minimum = self.miles_minimum

            airline = load_airline(self.airline_id)
            if airline is not None:
                miles_limitation = airline.miles_limitation
                miles_minimum = airline.miles_minimum

            if miles_limitation == models.air.MILES_NO_LIMIT:
                miles_minimum = 0
            elif miles_limitation == models.air.MILES_INTERNATIONAL_FLIGHTS_LIMIT:
                if not is_pair_international(pair):
                    miles_minimum = 0

            distance = pair.miles

            if distance < miles_minimum:
                distance = miles_minimum

            tariff_bonus_miles = distance * self.airline_tariff_group.charge_coef / 100.0
            if tariff_bonus_miles < miles_minimum:
                tariff_bonus_miles = miles_minimum

            tariff_bonus_miles = round(tariff_bonus_miles)

            if self.airline_tariff_group.charge_coef < 100:
                status_bonus_miles = tariff_bonus_miles * self.tier_level_factor.factor / 100.0
            else:
                status_bonus_miles = distance * self.tier_level_factor.factor / 100.0

            status_bonus_miles = round(status_bonus_miles)

            result = tariff_bonus_miles + status_bonus_miles

        return MilesCalculatorResult(distance, result, tariff_bonus_miles,
                                     status_bonus_miles, distance_miles)


class AwardsCalculatorResult(object):
    def __init__(self, a1, a3, a2=None, name=None, data=None):
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.name = name or ''
        self.data = data or []

    def attrs(self):
        attrs = []

        attrs.append(('from', self.a1.iata))
        if self.a2 is not None:
            attrs.append(('via', self.a2.iata))
        attrs.append(('to', self.a3.iata))

        attrs.append(('name', self.name))

        for name, value in self.data:
            attrs.append((name, '%d' % value))

        return attrs


class AwardsCalculator(object):
    def __init__(self, a1, a2, a3, airline=None):
        assert isinstance(a1, models.geo.Airport)
        assert isinstance(a3, models.geo.Airport)
        if a2 is not None:
            assert isinstance(a2, models.geo.Airport)
        if airline is not None:
            assert isinstance(airline, models.air.Airline)

        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.airline = airline
        self.carrier = airline.carrier if airline is not None \
                                       else models.award.CARRIER_SKYTEAM

        self.allowed_pairs = self.get_allowed_pairs_by_skyteam_service_class()

    def get_allowed_pairs_by_skyteam_service_class(self):
        result = {}
        if self.airline is not None:
            pairs_vocab = getV('pairs')
            for airline_sc in getVI('airline_service_classes_by_airline_idx')(context=self.airline):
                result.setdefault(airline_sc.skyteam_sc_id, set([]))
                for limit in getVI('service_classes_limits_by_airline_service_class_idx')(context=airline_sc):
                    try:
                        pair = pairs_vocab[limit.pair_id]
                    except LookupError:
                        pass
                    else:
                        result[airline_sc.skyteam_sc_id].add((pair.airport_from_id,
                                                              pair.airport_to_id))
                        result[airline_sc.skyteam_sc_id].add((pair.airport_to_id,
                                                              pair.airport_from_id))
        return result

    def is_service_class_allowed(self, segment, service_class_id):
        pairs = self.allowed_pairs.get(service_class_id, [])
        if not len(pairs) or segment in pairs:
            return True
        return False

    def check_award_service_class(self, award, a1, a2, a3):
        if a2 is None:
            segments = [(a1.airport_id, a3.airport_id),]
        else:
            segments = [(a1.airport_id, a2.airport_id),
                        (a2.airport_id, a3.airport_id),]

        allowed = []
        for segment in segments:
            allowed.append(self.is_service_class_allowed(segment, award.skyteam_service_class_id_1) \
                           and self.is_service_class_allowed(segment, award.skyteam_service_class_id_2))

        return any(allowed)  # хотя бы один сегмент выполняется с классом обсл-я

    def check_award_upgrade_checkin(self, award, a1, a2, a3):
        if award.award_type != models.award.AWARD_TYPE_UPGRADE_CHECKIN_OW:
            return True

        # 1) пункт вылета (не прилета) - аэропорт, у которого отмечен флаг
        # "Доступна премия за повышение класса обслуживания на стойке регистрации"
        # 2) отсутствуют стыковки
        if a2 is None and a1.has_upgrade_on_checkin_award:
            return True
        return False

    def get_awards(self, a1, a2, a3, check_award_service_class=None,
                   check_award_upgrade_checkin=None):
        z1 = a1.redemption_zone_by_carrier(self.carrier)
        z3 = a3.redemption_zone_by_carrier(self.carrier)
        z2 = None
        if a2 is not None:
            z2 = a2.redemption_zone_by_carrier(self.carrier)

        bonus_route = models.award.BonusRoute.search(z1, z2, z3, self.carrier)

        data = []
        for award in sorted(getVI('awards_by_bonus_route_idx')(context=bonus_route),
                            key=lambda ob: ob.award_value):
            #14796
            check_award_service_class = check_award_service_class or self.check_award_service_class

            #14794
            check_award_upgrade_checkin = check_award_upgrade_checkin or self.check_award_upgrade_checkin

            if check_award_service_class(award, a1, a2, a3) \
                and check_award_upgrade_checkin(award, a1, a2, a3):
                data.append((award.title, award.award_value))

        try:
            bonus_route_code = bonus_route.code
        except AttributeError:
            bonus_route_code = None

        return {'name': bonus_route_code, 'data': data}

    def calculate(self):
        result = []
        if self.a2 is not None:
            wrong_route = None
            if self.carrier == models.award.CARRIER_AFL:
                wrong_route = models.award.WrongRoute.search(self.a1.city_id, self.a2.city_id, self.a3.city_id)

            if wrong_route is not None:
                # Расчёт двумя сегментами
                result.append(AwardsCalculatorResult(self.a1, self.a2,
                    **self.get_awards(self.a1, None, self.a2)))
                result.append(AwardsCalculatorResult(self.a2, self.a3,
                    **self.get_awards(self.a2, None, self.a3)))
            else:
                result.append(AwardsCalculatorResult(self.a1, self.a3,
                    a2=self.a2, **self.get_awards(self.a1, self.a2, self.a3)))
        else:
            result.append(AwardsCalculatorResult(self.a1, self.a3,
                **self.get_awards(self.a1, None, self.a3)))

        return result
