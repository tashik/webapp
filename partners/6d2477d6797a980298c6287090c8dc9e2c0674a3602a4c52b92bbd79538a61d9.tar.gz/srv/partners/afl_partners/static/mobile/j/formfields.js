function initOverLabels () {
  if (typeof(customs) != 'undefined') { return;}
  if (!document.getElementById) return;      

  var labels, id, field;

  // устанавливаем обработчики onfocus и onblur
  // чтобы скрывать и отображать метки
  // с именем класса 'overlabel'
  labels = document.getElementsByTagName('label');
  for (var i = 0; i < labels.length; i++) {
      labels[i].onclick = function () { return; }; //for Safari

      id = labels[i].htmlFor || labels[i].getAttribute('for');
      if (!id || !(field = document.getElementById(id))) {
          continue;
      } 
      
      if (field.tagName == 'SELECT') {
          if (field.options[0].text == '') {
              if (typeof _ !== 'undefined') {  // проверяем наличие функции для перевода вида _('ключ_перевода')
                  field.options[0].text = _('text.choose');
              } else {
                  field.options[0].text = document.getElementById("logo_en") ? "Select..." : "Выбрать...";
              }
          }
          continue;
      }
      if (field.type == 'checkbox') continue;
      if (field.type == 'radio'){
          field.addEventListener('change',
              function () {
                  if (this.checked){
                      ls = this.parentNode.parentNode.getElementsByTagName('label');
                      for (var i = 0; i < ls.length; i++) {
                          id = ls[i].htmlFor || ls[i].getAttribute('for');
                          if (!id || !document.getElementById(id)) continue;
                          ls[i].className = id == this.id ? 'checked': '';
                      }
                  }
              },
	      false
          );
          continue;
      }

      // скрываем метку если поле
      // имеет значение по умолчанию
      //labels[i].style.display = (field.value !== '') ? 'none' : 'inline-block';

      // устанавливаем обработчики
      // скрывающие и отображающие метки
      field.addEventListener('focus',
          function () { 
              label = this.parentNode.getElementsByTagName('label')[0];
              //if (label) label.style.display = 'none';
          },
	  false
      );

      field.addEventListener('blur',
          function () { 
              label = this.parentNode.getElementsByTagName('label')[0];
              //if (label) label.style.display = (this.value !== '') ? 'none' : 'inline-block';
          },
	  false
      );
  }
};

function initLinks(){
    var links = document.getElementsByTagName('a');
    for (var i = 0; i < links.length; i++) {
        var link = links[i];
        if (link.href == document.referrer && link.className == "back"){
            link.onclick = function(e) { history.back(); return false;};
        }
    }
}

if(window.addEventListener){
    window.addEventListener("load",function() {
        setTimeout(initOverLabels, 0);
        setTimeout(initLinks, 0);
    }, false);
} else {
    window.attachEvent("onload",function() {
        setTimeout(initOverLabels, 0);
        setTimeout(initLinks, 0);
    });

}