function set_class_name(obj, class_name){
    obj.className = class_name;
}
function set_class_name_by_id(id_name, class_name){
    var o = document.getElementById(id_name);
    if (typeof(o) == 'undefined') return;
    set_class_name(o, class_name)
}

function set_obj_full(obj){
    obj.height = document.height;
    if (document.body.className.indexOf("for-edit") == -1){
        document.body.className += " for-edit";
        setTimeout(function(){ window.scrollTo(0, 1); }, 0);
    }
}

function set_obj_full_by_id(id_name){
    var o = document.getElementById(id_name);
    if (typeof(o) == 'undefined') return;
    set_obj_full(o);
}

function clear_obj_full(){
    document.body.className = document.body.className.split(" for-edit").join(" ");
    var o = document.getElementById("id_error");
    if (o && typeof(o) != 'undefined') o.style.display = "none";
    o = document.getElementById("id_form_error");
    if (o && typeof(o) != 'undefined') o.style.display = "none";
    
}
