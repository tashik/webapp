var today = new Date();
var enddate = new Date();
enddate.setDate(330);
var dfrom = new Date();
var dto = new Date();

var multi_dates = [new Date(), new Date(), new Date(), new Date(), new Date(), new Date()];

var months = {'ru':['Января','Февраля','Марта','Апреля','Мая','Июня','Июля','Августа','Сентября','Октября','Ноября','Декабря'],
		      'en':['January','February','March','April','May','June','July','August','September','October','November','December'],
              'it':['Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio', 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre'],
              'es':['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
              'fr':['Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'],
              'de':['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'],
              'ja':['1 月', '2 月', '3 月', '4 月', '5 月', '6 月', '7 月', '8 月', '9 月', '10 月', '11 月', '12 月'],
              'ko':['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'],
              'zh':['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月']};


function getMonthDays(d){
	var _d = new Date(d.getFullYear(), d.getMonth() + 1, 0);
	return _d.getDate();
}

function dateFromStr(str){
    var n = new Date(today.getFullYear(), 1*str.substr(2, 2) - 1, 1*str.substr(0, 2));
    var _n = new Date(today.getFullYear() + 1, 1*str.substr(2, 2) - 1, 1*str.substr(0, 2));
    if (n < today)
    	if (_n > enddate) n = new Date(today);
    	else n = new Date(_n);
    
    return n;
}
    

function _(str){
    return str;
}

function init_mcal(){
    init_dates();
    var dep = document.getElementById('id_dep');
    if (typeof(dep) == 'undefined') return;
    var cbk = document.getElementById('id_cbk');
    if (typeof(cbk) == 'undefined') return;
    dep.className = "hidden";
    cbk.className = "hidden";
	updateDate();    
}

function init_multi_mcal(){
    init_multi_dates();
    for (var i=0; i < 6; i++){
        var d = document.getElementById('id_multi_dep_' + i);
        if (typeof(d) != 'undefined'){
            d.className = "hidden";
        }
        d = document.getElementById('id_multi_route_' + i);
        if (typeof(d) != 'undefined' && d.value == ''){
            document.getElementById('did_dates_' + i).style.display = "none";
        }
    }
	updateMultiDates();
}


function init_dates() {
    var d = document.getElementById('id_departure');
    if (typeof(d) == 'undefined') return;
    var c = document.getElementById('id_comeback');
    if (typeof(c) == 'undefined') return;
    if (typeof(mcalMinDate) == 'undefined')
        mcalMinDate = today;

    setFromDate(dateFromStr(d.value));
    setToDate(dateFromStr(c.value));
}

function init_multi_dates() {
    var last_date = new Date();
    for (var i=0; i < 6; i++){
        var d = document.getElementById('id_multi_departure_' + i);
        if (typeof(d) != 'undefined'){
            if (d.value != '')
                multi_dates[i] = dateFromStr(d.value);
            else
                multi_dates[i].setDate(new Date(last_date).getDate() + 2);
            last_date = multi_dates[i];
        }
    }
}



function fmt_date_number(i){ var r = "" + i; if (r.length < 2) r = "0" + r; return r; }
function formatDate(dt) {
    var d = dt.getDate();
    var m = dt.getMonth();
    var y = dt.getFullYear();
    return d + ' ' + months[typeof(language) != 'undefined' ? language : 'en'][m] + ' ' + y;
}




function updateDate(){
    var d = document.getElementById('id_departure');
    if (typeof(d) == 'undefined') return;
    var c = document.getElementById('id_comeback');
    if (typeof(c) == 'undefined') return;
    var dfd = document.getElementById('id_dfd');
    if (typeof(dfd) == 'undefined') return;
    var dfm = document.getElementById('id_dfm');
    if (typeof(dfm) == 'undefined') return;
    var dtd = document.getElementById('id_dtd');
    if (typeof(dtd) == 'undefined') return;
    var dtm = document.getElementById('id_dtm');
    if (typeof(dtm) == 'undefined') return;

    d.value = fmt_date_number(dfrom.getDate()) + fmt_date_number(dfrom.getMonth() + 1);
    c.value = fmt_date_number(dto.getDate()) + fmt_date_number(dto.getMonth() + 1);
    
    dfd.innerHTML = dfrom.getDate();
    dfm.innerHTML = months[typeof(language) != 'undefined' ? language : 'en'][dfrom.getMonth()]; // lang
    dtd.innerHTML = dto.getDate();
    dtm.innerHTML = months[typeof(language) != 'undefined' ? language : 'en'][dto.getMonth()]; // lang
    
    updateCal('id_mctf', dfrom);
    updateCal('id_mctt', dto);
    
}

function updateMultiDate(index){
    var d = document.getElementById('id_multi_departure_' + index);
    if (typeof(d) == 'undefined') return;
    var dfd = document.getElementById('id_multi_' + index + '_dfd');
    if (typeof(dfd) == 'undefined') return;
    var dfm = document.getElementById('id_multi_' + index + '_dfm');
    if (typeof(dfm) == 'undefined') return;

    dt = multi_dates[index];
    d.value = fmt_date_number(dt.getDate()) + fmt_date_number(dt.getMonth() + 1);

    dfd.innerHTML = dt.getDate();
    dfm.innerHTML = months[typeof(language) != 'undefined' ? language : 'en'][dt.getMonth()]; // lang
    updateCal('id_multi_' + index + '_mctf', dt);
}


function updateMultiDates(){
    for (var i=0; i < 6; i++){
        updateMultiDate(i);
    }
}

function cfm(index, day) {
	var d  = new Date(multi_dates[index]);
	d.setDate(day);
	setMultiDate(d, index);
	updateMultiDate(index);
}


function cf(day){
	var d  = new Date(dfrom);
	d.setDate(day);
	setFromDate(d);
	updateDate();
}

function ct(day){
	var d  = new Date(dto);
	d.setDate(day);
	setToDate(d);
	updateDate();
}

function doneCal(){
	set_class_name_by_id('did_mc', 'mc');
	clear_obj_full();	
}

function doneMultiCal(index){
	set_class_name_by_id('did_mc_' + index, 'mc');
	clear_obj_full();
}


function updateCal(cal_id, d)
{
	var mct = document.getElementById(cal_id);
	if (typeof(mct) == 'undefined') return;
	var st = new Date(d);
	st.setDate(1);
	mct.children[0].className = "s" + (st.getDay());
	var days = getMonthDays(d);
	
	var flag_today = d.getMonth() == today.getMonth();
	var flag_enddate = d.getMonth() == enddate.getMonth();
	
	for (var i=1; i < mct.children.length;i++){
		var val = parseInt(mct.childNodes[i].innerHTML);
		mct.childNodes[i].className = ((flag_today && val < mcalMinDate.getDate())||(flag_enddate && val > enddate.getDate())) ? "disabled" : "";
		if (val == d.getDate()) mct.childNodes[i].className = "selected";
		if (val > days) mct.childNodes[i].className = "hidden";
	}
}

function setFromDate(d){
    if (d < mcalMinDate) d = new Date(mcalMinDate);
    if (d > enddate) d = new Date(enddate);
    dfrom = new Date(d);
    if (dfrom > dto) dto = new Date(dfrom);
}
function setToDate(d){
    if (d < mcalMinDate) d = new Date(mcalMinDate);
    if (d > enddate) d = new Date(enddate);
    dto = new Date(d);
    if (dto < dfrom) dfrom = new Date(dto);
}

function setMultiDate(d, index){
    if (d < mcalMinDate) d = new Date(mcalMinDate);
    if (d > enddate) d = new Date(enddate);
    multi_dates[index] = new Date(d);

    for (var i = index + 1; i < 6; i++){
        if (multi_dates[i] < multi_dates[i-1]){
            multi_dates[i] = new Date(multi_dates[i-1]);
        }
    }
    for (var i = index - 1; i >= 0; i--){
        if (multi_dates[i] > multi_dates[i+1]){
            multi_dates[i] = new Date(multi_dates[i+1]);
        }
    }
    updateMultiDates(index);
    //if (dto < dfrom) dfrom = new Date(dto);
}


function shiftMonth(d, shift){
    if (d == 'from'){
    	var _df = new Date(dfrom);
    	_df.setMonth(_df.getMonth() + shift);
    	setFromDate(_df)
    }else{
    	var _dt = new Date(dto);
    	_dt.setMonth(_dt.getMonth() + shift);
    	setToDate(_dt)
    }
    updateDate();
}
function shiftDay(d, shift){
    if (d == 'from'){
    	var _df = new Date(dfrom);
    	_df.setDate(_df.getDate() + shift);
    	setFromDate(_df)
    }else{
    	var _dt = new Date(dto);
    	_dt.setDate(_dt.getDate() + shift);
    	setToDate(_dt)
    }
    updateDate();
}

function shiftMultiMonth(shift, index){
    var _df = new Date(multi_dates[index]);
    _df.setMonth(_df.getMonth() + shift);
    setMultiDate(_df, index)
}

function shiftMultiDay(shift, index){
    var _df = new Date(multi_dates[index]);
    _df.setDate(_df.getDate() + shift);
    setMultiDate(_df, index)
}

