$(function() {
    function show_full_info(elem, is_interline) {
            var info_div = $(elem).parent().children('div.itinerary-full-info');

        if (info_div) {
            info_div.clone().appendTo('#div_itinerary_info_content');
            $('#div_itinerary_info_content div.itinerary-full-info').show();

            hide_itineraries_content();

            var title = $('#div_itinerary_info_content_title').text();
            var original_title = change_content_title(title);

            change_back_buttons_action(function() {
                clear_full_info();
                show_itineraries_content();
                change_content_title(original_title);
            });
        }
    }

    function clear_full_info() {
        $('#div_itinerary_info_content').empty();
    }

    function show_itineraries_content() {
        $('#div_search_result_content').show();
    }

    function hide_itineraries_content() {
        $('#div_search_result_content').hide();
    }

    function change_back_buttons_action(action) {
        var top_button = $('#back_top_url');
        var bottom_button = $('#back_bottom_url');
        var base_back_url = top_button.attr('href');

        top_button.attr('href', '#');
        top_button.click(function(e) {
            e.preventDefault();
            action();
            top_button.attr('href', base_back_url);
            top_button.unbind('click');
            bottom_button.attr('href', base_back_url);
            bottom_button.unbind('click');
        });

        bottom_button.attr('href', '#');
        bottom_button.click(function(e) {
            e.preventDefault();
            action();
            top_button.attr('href', base_back_url);
            top_button.unbind('click');
            bottom_button.attr('href', base_back_url);
            bottom_button.unbind('click');
        });
    }

    function change_content_title(title) {
        var original_title = $('div.title > b').text();
        $('div.title > b').text(title);
        return original_title;
    }

    $('div.segments > div.segment > a.fi').click(function() {
        show_full_info(this);
    });

    $('div.segments > div.transfer-itinerary > div.segment-part > a.fi:first').click(function() {
        show_full_info(this);
    });
});