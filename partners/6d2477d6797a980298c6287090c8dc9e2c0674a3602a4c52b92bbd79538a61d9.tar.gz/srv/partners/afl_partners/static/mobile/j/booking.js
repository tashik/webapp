var customs = true;
var max_pax_count = 6;

function checkEnter(e) {
     e = e || event;
     return (e.keyCode || e.which || e.charCode || 0) !== 13;
}

function inc_value(name, step) {
    if (typeof(step) == 'undefined') step = 1;
    var o = document.getElementById(name);
    if (typeof(o) == 'undefined') return;
    var v = parseInt(o.value);
    if (isNaN(v)) v = 0;
    v += step;
    if (v > 6) v = 6;
    if (v < 0) v = 0;
    o.value = v;
    change_passengers(o.name);
}

function change_passengers(name){
    var adults = document.getElementById('id_adults');
    var children = document.getElementById('id_children');
    var infants_noplace = document.getElementById('id_infants_noplace');
    var youth = document.getElementById('id_youth');
    if (typeof(adults) == 'undefined' ||
        typeof(children) == 'undefined' ||
        typeof(infants_noplace) == 'undefined' ||
        typeof(youth) == 'undefined') return;
    
    var ads = parseInt(adults.value);
    var inf = parseInt(infants_noplace.value);
    var pls = ads + parseInt(children.value) + inf;

    switch(name){
        case 'adults': {
            youth.value = 0;
            if (ads == 0 || ads < 0) adults.value = 1; 
            if (pls > max_pax_count) adults.value = ads - 1;
            break;
        }
        case 'children': {
            if (pls > max_pax_count) children.value = parseInt(children.value) - 1;
            if (parseInt(adults.value) == 0 ) {
                adults.value = 1;
            }
            youth.value = 0;
            break;
        }
        case 'infants_noplace': {
            if (pls + (inf === ads + 1 ? 1 : 0) > max_pax_count) {
                infants_noplace.value = parseInt(infants_noplace.value) - 1;
            }
            if (parseInt(adults.value) == 0 ) {
                adults.value = 1;
            }
            youth.value = 0;
            break;
        }
        case 'youth': {
            if (parseInt(youth.value) == 0 && parseInt(adults.value) == 0 ) {
                adults.value = 1;
            }
            if (parseInt(youth.value) > 0){
                adults.value = 0;
                children.value = 0;
                infants_noplace.value = 0;
            }
            break;
        }
    }
    
    inf = parseInt(infants_noplace.value);
    if (parseInt(adults.value) < inf) {
        adults.value = inf;
    }

    pls = parseInt(adults.value) + parseInt(children.value);
    var cls_name = '';
    for(i=1; i <= pls; i++){
        cls_name += ' cp_num_' + i;
    }
    var coupons_div = document.getElementById('did_cp');
    if (typeof(coupons_div) != 'undefined' && coupons_div ){

        if (parseInt(youth.value) > 0) {
            coupons_div.style.display = 'none';
        }
        else {
            coupons_div.style.display = 'block';
        }

        var container = coupons_div.getElementsByTagName('FIELDSET')[0];
        container.className = cls_name;
        
        var inputs = container.getElementsByTagName('INPUT');
        var has_cp = false;
        for (var i = 0; i < inputs.length; i++) {
            var val = inputs[i].value;
            if (val != null && val !== '' && val != 'undefined') {
                has_cp = true;
            }
        }

        if (has_cp) {
            coupons_div.className = 'cp';
        } else {
            coupons_div.className = 'cp new';
        }
    }
    
    document.getElementById('did_adults').className = 'pr' + (parseInt(adults.value) == 0 ? ' hide' : '');
    document.getElementById('did_children').className = 'pr' + (parseInt(children.value) == 0 ? ' hide' : '');
    document.getElementById('did_infants_noplace').className = 'pr' + (parseInt(infants_noplace.value) == 0 ? ' hide' : '');
    document.getElementById('did_youth').className = 'pr' + (parseInt(youth.value) == 0 ? ' hide' : '');
}


function change_coupons(){
    var coupons_div = document.getElementById('did_cp');
    if (typeof(coupons_div) != 'undefined' && coupons_div ){
        var inputs = coupons_div.getElementsByTagName('INPUT');
        var empty = true;
        for (var i = 0; i < inputs.length; i++){
            if (inputs[i].value != '' && inputs[i].style.display != 'none'){
                empty = false;
                break;
            }
        }
        coupons_div.className = 'cp' + (empty ? ' new': '');
    }
}


function set_checked(id_name){
    var o = document.getElementById(id_name);
    if (typeof(o) == 'undefined') return;
    o.checked = 'checked';
}


function change_trip_type(one){
    var o = document.getElementById('did_dates');
    if (typeof(o) == 'undefined') return;    
    o.className = one ? 'dates one' : 'dates';
}


function rotate_route(name){
    var input = document.getElementById('id_' + name);
    if (typeof(input) == 'undefined') return;    
    var text = document.getElementById('id_text_' + name);
    if (typeof(input) == 'undefined') return;
    input.value = input.value.slice(3) + input.value.slice(0,3);
    
    var sep = ' → ';
    var cities = text.innerHTML.split(sep);
    cities.reverse();
    text.innerHTML = cities.join(sep);
}
