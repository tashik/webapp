var SearchFilter = function(listId, inputId, clearId) {
    this.listId = listId;
    this.inputId = inputId;
    this.clearId = clearId;
    
    this._t = null;
    this._timeout = 300;
    this._minLength = 2;
    
    this._match = function(str, html) {
        var text = html.replace(/(<([^>]+)>)/ig, '');
        return text.search(str) == -1 ? false : true;
    };
    
    this._filter = function() {
        var _this = this;
        
        var txt = this.inputEl.value.toLowerCase();
        for (var i = 0; i < this.listEl.children.length; i++) {
            var ch = this.listEl.children[i];
            if (txt.length < this._minLength || txt.length > this._minLength - 1 && this._match(txt, ch.innerHTML.toLowerCase())) {
                ch.style.display = 'block';
            } else {
                ch.style.display = 'none';
            }
        }
        
        this._t = setTimeout(function() {
            _this._filter();
        }, this._timeout);
    };
    
    this._clear = function() {
        this.inputEl.value = '';
        for (var i = 0; i < this.listEl.children.length; i++) {
            var ch = this.listEl.children[i];
            ch.style.display = 'block';                
        }
    };
    
    this.startup = function() {
        this.listEl = document.getElementById(this.listId);
        this.inputEl = document.getElementById(this.inputId);
        this.clearEl = document.getElementById(this.clearId);
        
        var onfocus = function() {
            var _this = this;
            return function() {
                _this._t = setTimeout(function() {
                    _this._filter();
                }, _this._timeout);
            }
        }.call(this);
        this.inputEl.onfocus = onfocus;
        
        var onblur = function() {
            var _this = this;
            return function() {
                clearTimeout(_this._t);
            }
        }.call(this);
        this.inputEl.onblur = onblur;
        
        if (this.clearEl) {
            var onclick = function() {
                var _this = this;
                return function() {
                    _this._clear();
                    clearTimeout(_this._t);
                }
            }.call(this);
            this.clearEl.onclick = onclick;
        }
    };
};