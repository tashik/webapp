'use strict';

function add_or_replace_query_param(url, name, new_value) {
    var params_sep_index = url.indexOf('?');
    var url_without_params = url.substring(0, params_sep_index);
    var query_params_string = url.substring(params_sep_index + 1);
    var queries = query_params_string.split('&');
    var query_params = {};

    for (var i = 0; i < queries.length; i++) {
        var sep_index = queries[i].indexOf('=');
        var key = queries[i].substring(0, sep_index);
        var value = queries[i].substring(sep_index + 1);
        query_params[key] = value;
    }
    if (new_value === null) {
        delete query_params[name];
    }
    else {
        query_params[name] = new_value;
    }
    return url_without_params + '?' + $.param(query_params);
};


var ItinerariesPageState = {
    ITINERARIES_LIST: 0,
    ITINERARY_INFO: 1,
}


var ItinerariesPage = function () {
    this.state = ItinerariesPageState.ITINERARIES_LIST;

    this.container = $('#div_itinerary_pages');
    this.itinerary_info_container = $('#div_itinerary_info_page');

    this.pages_elements = this.container.children();
    this.current_page = parseInt(this.container.attr('class').split('_')[1], 10);
    this.pages_count = this.pages_elements.length;

    this.fare_buttons = this.container.find('div.tariffs a[data-fare]');
    this.back_buttons = [$('#back_button_top'), $('#back_button_bottom')];
    this.original_back_url = this.back_buttons[0].attr('href');

    this.selected_itineraries_form = $('#form_itineraries_submit');
    this.selected_itineraries_div = $('#div_selected_itineraries');
    this.wait_message = $('#div_wait_message');

    var data = $('#div_page_data');
    this.is_interline = data.data('is_interline');
    this.unavailable_price = data.data('unavailable_price');
    this.fare_combinations = data.data('fare_combinations');
    this.default_fare_combination = data.data('default_fare_combination');
    this.not_combinable_msg = data.data('not_combinable_msg');
};

ItinerariesPage.prototype.init = function() {
    var page = this;
    this.fare_buttons.click(function(e) {
        page.select_itinerary($(this));
    });

    if (this.is_interline) {
        $('div.segments > div.segment > div.segment-part > a.fi').click(function() {
            var itin_id = $(this).parent().parent().data('itinerary_id');
            var info_div = $('#div_itinerary_info_' + itin_id);
            page.show_full_info(info_div);
        });
    }
    else {
        $('div.segments > div.segment > a.fi').click(function() {
            var itin_id = $(this).parent().data('itinerary_id');
            var info_div = $('#div_itinerary_info_' + itin_id);
            page.show_full_info(info_div);
        });
    }

    this.selected_itineraries_div.find('div a[data-fare]').click(function(e) {
        var target = $(this);
        target.siblings().removeClass('active');
        target.addClass('active');

        var select_data = target.data('itin_select_info');
        var selected_fare = target.data('fare');
        page.replace_search_urls(page.current_page, select_data);
        page.update_fare_combinations(page.current_page, selected_fare);
    });

    this.itinerary_info_container.find('div.itinerary-info a[data-fare]').click(function() {
        var button = $(this);
        var fare = button.data('fare');
        var itin_id = button.closest('div.itinerary-info').data('itinerary_id');
        var segment = page.container.find('div.segment[data-itinerary_id="' + itin_id + '"]');
        var fare_button = segment.find('div.tariffs a[data-fare="' + fare + '"]');
        page.hide_full_info();
        page.select_itinerary($(fare_button));
    });

    if (this.selected_itineraries_div) {
        var selected_fare = this.selected_itineraries_div.find('div a.active').data('fare');
        page.update_fare_combinations(page.current_page, selected_fare);
    }

    this.replace_back_url();
}

ItinerariesPage.prototype.show_full_info = function(info_div) {
    this.state = ItinerariesPageState.ITINERARY_INFO;
    this.container.hide();
    this.selected_itineraries_div.hide();
    info_div.addClass('displayed');
    this.replace_back_url();
};

ItinerariesPage.prototype.hide_full_info = function() {
    this.state = ItinerariesPageState.ITINERARIES_LIST;
    this.itinerary_info_container.children().removeClass('displayed');
    this.container.show();
    this.selected_itineraries_div.show();
    this.replace_back_url();
};

ItinerariesPage.prototype.is_last_page = function() {
    return this.current_page === this.pages_count - 1;
};

ItinerariesPage.prototype.is_fares_combinable = function(first_fare, second_fare) {
    if (first_fare in this.fare_combinations) {
        if (second_fare in this.fare_combinations[first_fare]) {
            return this.fare_combinations[first_fare][second_fare];
        }
    }

    if (second_fare in this.fare_combinations) {
        if (first_fare in this.fare_combinations[second_fare]) {
            return this.fare_combinations[second_fare][first_fare];
        }
    }

    return this.default_fare_combination;
};

ItinerariesPage.prototype.update_fare_combinations = function(page_index, selected_fare) {
    var next_page_fares = $(this.pages_elements[page_index]).find('div.tariffs a[data-fare]');

    var page = this;
    $.each(next_page_fares, function(i, el) {
        var fare_button = $(el);
        var fare = fare_button.data('fare');
        var is_combinable = page.is_fares_combinable(fare, selected_fare);

        if (!is_combinable) {
            fare_button.addClass('not-combinable');
            fare_button.unbind('click');
            fare_button.click(function(e) {
                alert(page.not_combinable_msg);
            });
        }
        else {
            fare_button.removeClass('not-combinable');
            fare_button.unbind('click');
            fare_button.click(function(e) {
                page.select_itinerary($(this));
            });
        }
    });
};

ItinerariesPage.prototype.select_itinerary = function(button) {
    var selected_fare = button.data('fare');
    var max_time = button.parent().parent().data('max_time_before_arrival');
    this.add_selection(button);

    if (this.is_last_page()) {
        this.submit_form();
    }

    else {
        var select_data = button.data('itin_select_info');
        this.replace_search_urls(this.current_page + 1, select_data);
        this.update_fare_combinations(this.current_page + 1, selected_fare);
        this.update_filter_fares_by_time(this.current_page + 1, max_time);
        this.show_next_page();
    }
};

ItinerariesPage.prototype.deselect_itinerary = function() {
    this.remove_selection();
    this.show_prev_page();
};

ItinerariesPage.prototype.add_selection = function(button) {
    var page = this;
    var booking_class = button.data('booking_class');
    button.addClass('active');
    var itin_copy = button.parent().parent().parent().clone(true);
    button.removeClass('active');

    var div_booking_class = $('<div>', {'class': booking_class}).append(itin_copy);
    this.selected_itineraries_div.append(div_booking_class);
    var fare_buttons = div_booking_class.find('div.segment div.tariffs a[data-fare]');

    fare_buttons.unbind('click');

    fare_buttons.click(function(e) {
        var target = $(this);
        target.siblings().removeClass('active');
        target.addClass('active');

        var select_data = target.data('itin_select_info');
        var selected_fare = target.data('fare');
        page.replace_search_urls(page.current_page, select_data);
        page.update_fare_combinations(page.current_page, selected_fare);
    });
};

ItinerariesPage.prototype.remove_selection = function() {
    this.selected_itineraries_div.children().last().remove();
};

ItinerariesPage.prototype.show_next_page = function() {
    this.current_page += 1;
    this.replace_back_url();
    this.container.attr('class', 'itinerary-page_' + this.current_page);
};

ItinerariesPage.prototype.show_prev_page = function() {
    this.current_page -= 1;
    this.replace_back_url();
    this.container.attr('class', 'itinerary-page_' + this.current_page);
};

ItinerariesPage.prototype.update_filter_fares_by_time = function(page_index, max_time) {
    var next_page_itineraries = $(this.pages_elements[page_index]).find('div.segments > div.segment');
    $.each(next_page_itineraries, function(i, el) {
        var segment = $(el);
        var dt = segment.data('time_until_departure');

        if (dt < max_time) {
            segment.addClass('hidden');
        }
        else {
            segment.removeClass('hidden');
        }
    });

};

ItinerariesPage.prototype.replace_back_url = function() {
    var page = this;

    if (this.state === ItinerariesPageState.ITINERARY_INFO) {
        $.each(this.back_buttons, function(i, el) {
            el.attr('href', '#');
            el.unbind('click');
            el.click(function(e) {
                e.preventDefault();
                page.hide_full_info();
            });
        });
    }

    else if (this.current_page === 0) {
        $.each(this.back_buttons, function(i, el) {
            el.unbind('click');
            el.attr('href', page.original_back_url);
        });
    }

    else {
        $.each(this.back_buttons, function(i, el) {
            el.attr('href', '#');
            el.unbind('click');
            el.click(function(e) {
                e.preventDefault();
                page.deselect_itinerary();
            });
        });
    }
};

ItinerariesPage.prototype.replace_search_urls = function(page_index, value) {
    var prev_search_button = $(this.pages_elements[page_index]).children('.daysline').children('.button.first').children('a');
    if (prev_search_button.children('.price').text() !== this.unavailable_price) {
        var prev_search_url = prev_search_button.attr('href');
        prev_search_button.attr('href', add_or_replace_query_param(prev_search_url, 'prev_itineraries', value));

    }

    var next_search_button = $(this.pages_elements[page_index]).children('.daysline').children('.button.last').children('a');
    if (next_search_button.children('.price').text() !== this.unavailable_price) {
        var next_search_url = next_search_button.attr('href');
        next_search_button.attr('href', add_or_replace_query_param(next_search_url, 'prev_itineraries', value));
    }
};

ItinerariesPage.prototype.get_itinerary_data_from_selection = function() {
    var itins = this.selected_itineraries_div.children();
    var itin_data = [];

    if (this.is_interline) {
        itins = itins.children().children('.segment-part');
        for (var i = 0; i < itins.length; i++ ) {
            var data = $(itins[i]).data('itin_info');
            var full_data = $(itins[i]).data('itin_full_info');
            itin_data.push({'data': data, 'full_data': full_data});
        }
    }

    else {
        for (var i = 0; i < itins.length; i++ ) {
            var data_item = $(itins[i]);
            var data = data_item.find('a.active').data('itin_info');
            var full_data = data_item.children('.segment').data('itin_full_info');
            itin_data.push({'data': data, 'full_data': full_data});
        }

    }
    return itin_data;
};

ItinerariesPage.prototype.submit_form = function() {
    this.container.hide();
    this.selected_itineraries_div.hide();
    this.itinerary_info_container.hide();
    this.wait_message.show();

    var selected_itineraries_data = this.get_itinerary_data_from_selection();
    for (var i = 0; i < selected_itineraries_data.length; i++ ) {
        $('<input>', {type: 'text', val: selected_itineraries_data[i]['data'], name: 'itin_' + i}).appendTo(this.selected_itineraries_form);
        $('<input>', {type: 'text', val: selected_itineraries_data[i]['full_data'], name: 'aitin_' + i}).appendTo(this.selected_itineraries_form);
    }

    this.selected_itineraries_form.submit();
};


$(document).ready(function() {
    var itin_page = new ItinerariesPage();
    itin_page.init();
});