(function($){
    var _;
    var translations = {
		'ru': {
            'Add': 'Добавить',
            'The type of passenger "Youth" cannot be combined with other types of passengers.': 'Тип пассажира "Молодежь" не комбинируется с другими типами пассажиров.',
            'Invalid number of adults.': 'Недопустимое число взрослых пассажиров.',
            'Maximum of 6 passengers allowed.': 'Максимально допустимое количество пассажиров: 6.'
        }
    }
    
    var methods = {
        init: function(options) {
            var settings = $.extend({                
                boxClass: 'passangers',
                language: 'ru'
            }, options);
            
            _ = function(str) {
                if (translations[settings.language] != undefined && translations[settings.language][str] != undefined) {
                    return translations[settings.language][str];
                }
                return str;
            }
            
            return $('.' + settings.boxClass, this).each(function(i) {                
                var $this = $(this),
                    data = $this.data('passangerWidget'),
                    dialog = $('<div class="dialog" style="display:none;"></div>');
                
                if (!data) {
                    var selects = [];
                    var buttons = [];
                    var container = $('<div class="passanger-widget"><span>' + _('Add') + ':</span></div>');
                    $('>div', $this).each(function(i, el) {
                        var link = $('<span class="button"><a href="#">' + $('>label', $(el)).html() + '</a></span>');
                        link.bind('click', function(e) {
                            var data = $this.data('passangerWidget');
                            $('>select', $(el)).val(1);
                            $(el).show();                            
                            data.dialog.hide();
                            
                            $this.passangerWidget('updateState', e);
                            
                            return false;
                        });
                        
                        link.data('passangerWidget', {
                            id: $('>select', $(el)).attr('id')
                        });
                        
                        container.append(link);
                        
                        $('>select', $(el)).bind('change', function(e) {
                            var data = $this.data('passangerWidget');
                            
                            if (!$(this).val()) {
                                $(el).hide();                                
                            }
                            
                            $this.passangerWidget('updateState', null);                           
                        });
                        if (!$('>select', $(el)).val()) {
                            $(el).hide();
                        }
                        
                        selects[selects.length] = $('>select', $(el));
                        buttons[buttons.length] = link;
                    });
                    dialog.append(container);
                    $('body').prepend(dialog);
                    
                    var btn = $('<span class="button add"><a class="orange" href="#">+</a></span>');                    
                    btn.bind('click', function(e) {
                        var data = $this.data('passangerWidget');
                        $this.passangerWidget('dialogPosition', true);
                        
                        $(data.selects).each(function(i, select) {
                            if ($(select).val()) {
                                data.buttons[i].hide();
                            } else {
                                data.buttons[i].show();
                            }
                        });
                        
                        data.dialog.show();
                        
                        return false;
                    });
                    $this.after(btn);
                    
                    $(this).data('passangerWidget', {
                        dialog: dialog,
                        selects: selects,
                        buttons: buttons
                    });
                    
                    $this.passangerWidget('updateState', null);
                    
                    $('#id_currency_1').bind('click', function(e) {
                        btn.show();
                    });
                    
                    $('#id_currency_2').bind('click', function(e) {
                        btn.show();
                    });
                    
                    $('#id_currency_3').bind('click', function(e) {
                        btn.show();
                    });                    
                    
                    $('#id_currency_4').bind('click', function(e) {
                        btn.hide();
                        
                        $('#id_adults').parent().show();
                        
                        $(selects).filter(function(i) {
                            return $(this).attr('id') != 'id_adults';                            
                        }).each(function(i, el) {                        
                            $(el).parent().hide();
                            if ($('option', $(el)).eq(0).val()) {
                                $(el).prepend($('<option value="">0</option>'));
                            }
                            $(el).val('');
                        });
                        
                        $this.passangerWidget('updateState', null);                        
                    });
                    
                    $(window).bind('resize.passangerWidget', function() { $this.passangerWidget('dialogPosition', false); });
                    $(window).bind('scroll.passangerWidget', function() { $this.passangerWidget('dialogPosition', false); });
                }                
            });            
        },
        
        dialogPosition: function(forceCalculation) {
            var $this = $(this),
                data = $this.data('passangerWidget');
            
            if (data) {
                if (data.dialog.is(':visible') || forceCalculation) {
                    var scrollTop = $(window).scrollTop();
                    
                    var viewportHeight = $(window).height();
                    var dialogHeight = $(data.dialog).height();
                    if (viewportHeight > dialogHeight) {
                        $(data.dialog).css({'top': (viewportHeight - dialogHeight) / 2 + scrollTop + 'px'});
                    } else {
                        $(data.dialog).css({'top': scrollTop + 'px'});
                    }
                    
                    var viewportWidth = $('body').width();
                    var dialogWidth = $(data.dialog).width();
                    if (viewportWidth > dialogWidth) {
                        $(data.dialog).css({'left': (viewportWidth - dialogWidth) / 2 + 'px'});
                    } else {
                        $(data.dialog).css({'width': viewportWidth + 'px'});
                    }
                }
            }
        },
        
        updateState: function(e) {
            var $this = $(this),
                data = $this.data('passangerWidget');
            
            if (data) {
                $this.passangerWidget('checkPassangers');
                
                var visibleSelects = $(data.selects).filter(function(i) {
                    return $(this).parent().is(':visible');
                });
                
                if ($('#id_youth').val() && visibleSelects.length > 1) {
                    $(data.selects).filter(function(i) {
                        if (e && $(e.target).parent().data('passangerWidget').id == 'id_youth') {
                            return $(this).val() && $(this).attr('id') != 'id_youth';
                        } else {
                            return $(this).val() && $(this).attr('id') == 'id_youth';
                        }
                    }).each(function(i, el) {                        
                        $(el).parent().hide();
                        
                        if ($('option', $(el)).eq(0).val()) {
                            $(el).prepend($('<option value="">0</option>'));
                        }
                        
                        $(el).val('');
                    });
                }
                
                var visibleSelects = $(data.selects).filter(function(i) {
                    return $(this).parent().is(':visible');
                });
                
                if (visibleSelects.length <= 1) {
                    visibleSelects.each(function(i, el) {
                        if (!$('option', $(el)).eq(0).val()) {
                            $('option', visibleSelects[0]).eq(0).remove();
                        }
                    });                    
                } else {
                    visibleSelects.each(function(i, el) {
                        if ($('option', $(el)).eq(0).val()) {
                            $(el).prepend($('<option value="">0</option>'));
                        }
                    });
                }                
            }
        },
        
        checkPassangers: function() {
            var $this = $(this),
                data = $this.data('passangerWidget');
            
            if (data) {
                var adt = parseInt($('#id_adults').val() ? $('#id_adults').val() : 0);
                var chd = parseInt($('#id_children').val() ? $('#id_children').val() : 0);
                var ifs = parseInt($('#id_infants_place').val() ? $('#id_infants_place').val() : 0);
                var inf = parseInt($('#id_infants_noplace').val() ? $('#id_infants_noplace').val() : 0);
                var yth = parseInt($('#id_youth').val() ? $('#id_youth').val() : 0);
                
                var totalPax = adt + chd + ifs + yth;
                
                if (yth > 0 && (yth != totalPax || inf > 0)) {
                    window.setTimeout(function() {alert(_('The type of passenger "Youth" cannot be combined with other types of passengers.'))}, 0.5);
                    return;
                }
                
                if (!yth) {
                    if (!adt) {
                        window.setTimeout(function() {alert(_('Invalid number of adults.'))}, 0.5);
                        return;
                    }
                    if (adt + chd + ifs + inf > 6) {
                        window.setTimeout(function() {alert(_('Maximum of 6 passengers allowed.'))}, 0.5);
                        return;
                    }
                    if (adt < inf + ifs) {
                        window.setTimeout(function() {alert(_('Invalid number of adults.'))}, 0.5);
                        return;
                    }
                }
            }
        }
    }
        
    $.fn.passangerWidget = function(method) {        
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method ' + method + ' does not exist on jQuery.passangerWidget');
        }
    }
})(jQuery);

jQuery(document).ready(function($) {
    $('body').passangerWidget({
        'language': language != undefined ? language : 'ru'
    });    
});