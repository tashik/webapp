/**
 * Created by soms on 02.12.14.
 */
"use strict";

function set_checked(id_name){
    var o = document.getElementById(id_name);
    if (typeof(o) == 'undefined') return;
    o.checked = "checked";
}

/* Adaptive Image */
function AdaptiveImage(el, options) {
    this.$el = $(el);

    this.options = {
        src_attr: 'data-src',
        padding: 10,
        centerH: false,
        centerW: false,
        force_image_reload: true,
        show_on_error: false,
        onLoad: function() {}
    };

    for (var pr in options) {
        this.options[pr] = options[pr];
    }

    var unique_tag = "?" + (this.options.force_image_reload? new Date().getTime() : "");
    var _this = this;
    var process = function() {
        _this.$el.get(0).onload = function() {
            var $image = $(this);
            var iW = $image.width();
            var iH = $image.height();

            var $parent = $image.parent();
            var oW = $parent.width() - _this.options.padding * 2;
            var oH = $parent.height() - _this.options.padding * 2;

            var w = iW;
            var h = iH;

            if (iH > oH && iH * oW > iW * oH) { // Height ratio > width ratio > 1
                h = oH;
                w = Math.round(iW * h / iH);
            } else if (iW > oW) {
                w = oW;
                h = Math.round(iH * w / iW);
            }

            var marginTop = 0;
            var marginLeft = 0;
            if (_this.options.centerH) {
                marginLeft = Math.round(($parent.width() - w) / 2);
            }
            if (_this.options.centerV) {
                marginTop = Math.round(($parent.height() - h) / 2);
            }

            $image.css({
                visibility: 'visible',
                width: w,
                height: h,
                marginTop: marginTop,
                marginLeft: marginLeft
            });
        }
        _this.$el.css('visibility', 'hidden');
        _this.$el.attr('src', _this.$el.attr(_this.options.src_attr) + unique_tag);

        _this.options.onLoad();
    };

    var preloadedImage = new Image();
    preloadedImage.onload = function() {
        process();
    };
    if (this.options.show_on_error) {
        preloadedImage.onerror = function() {
            _this.$el.attr('src', '');
            _this.$el.css('visibility', 'visible');
            if (_this.options.padding) {
                _this.$el.css({
                    position: "relative",
                    left: _this.options.padding,
                    top: _this.options.padding
                });
            }
        };
    };
    preloadedImage.src = this.$el.attr(this.options.src_attr) + unique_tag;

    return this;
}


function isBorderRadiusSupport(testEl) {
    var res = false;

    $.each(['borderRadius','BorderRadius','MozBorderRadius','WebkitBorderRadius','OBorderRadius','KhtmlBorderRadius'], function() {
        if(testEl.style[this] !== undefined)
            res = true;
    });
    return res;
}

function niceBlueTable(el) {
    el.find('thead>tr').children().last().addClass('right-top-corner');

    var $leftBottomCorner = null;
    var rowSpan = 0;

    el.find('tbody>tr').each(function(i, el) {
        var $firstCell = $(el).children().first()

        if (rowSpan == 0) {
            var newRowspan = parseInt($firstCell.attr("rowspan"));

            if (newRowspan > 0) {
                rowSpan = newRowspan - 1;
            }

            $firstCell.addClass('first-cell');
            $leftBottomCorner = $firstCell;
        } else {
            rowSpan--;
        }
    });

    var browserSuffix = '';

    if (!isBorderRadiusSupport(el.children('thead').get(0))) {
        browserSuffix = '-ie8';
    }

    var lastRowCells = el.find('tbody>tr').last().children().last().addClass('right-bottom-corner' + browserSuffix);
    if ($leftBottomCorner) {
        $leftBottomCorner.addClass('left-bottom-corner' + browserSuffix);
    }

    el.addClass('ppTable');
}

function setupBackButton(button, cb) {
    button.click(function() {
        if (document.referrer == "") {
            var href = button.data('href');
            if (typeof(cb) == 'function') {
                href = cb(href);
            }
            window.location.href = href;
        } else {
            window.history.back();
        }
    });
}

function setupLinkButton(button, cb) {
    button.click(function() {
        var href = button.data('href');
        if (typeof(cb) == 'function') {
            href = cb(href);
        }
        window.location.href = href;
    });
}

function updateAdaptiveWidgets($widgets, minInputWidth) {
    var inline = true;
    var data = [];
    $widgets.each(function() {
        var $c = $(this);
        var $label = $('label', $c);
        var w = $label.outerWidth();
        var $input = $('input:nth-child(1), select:nth-child(1)', $c);
        data.push({
            label: $label,
            input: $input,
            w: w
        });
        if ($c.outerWidth() - w < minInputWidth) {
            inline = false;
        }
    });

    $(data).each(function(i, ob) {
        if (inline) {
            ob.label.parent().css('width', ob.w);
            ob.input.parent().css('margin-left', ob.w);
        } else {
            ob.label.parent().css('width', 'auto');
            ob.input.parent().css('margin-left', 0);
        }
    });
}

/* Paginator */
function Paginator(options) {
    this.options = {
        page: 0,
        step: 20,
        total: 0,
        prevText: '&larr; Prev',
        nextText: 'Next &rarr;',
        showNextPrev: true,
        pagesStr: 'Pages: ',
        showPages: false,
        longDescr: '',
        showDescr: false
    };

    for (var pr in options) {
        this.options[pr] = options[pr];
    }

    this.pageCount = Math.ceil(this.options.total / this.options.step);

    this.prev = this.options.page - 1;
    if (this.prev < 0) {
        this.prev = 0;
    }

    this.next = this.options.page + 1;
    if (this.next > this.pageCount - 1) {
        this.next = this.pageCount - 1;
    }

    return this;
}

Paginator.prototype.isEnabled = function() {
    return this.enabled = this.pageCount > 1;
};

Paginator.prototype.getHTML = function(maxPageCount) {
    if (!this.options.total || this.pageCount < 2) return;

    var html = '';

    if( this.options.showPages )
        html += '<h4>' + this.options.pagesStr + '</h4>';

    html += '<ul class="paginator b-pagination b-pagination_list ">';

    if( this.options.showNextPrev )
        if (this.options.page) {
            html += '<li class="b-pagination__item -type_prev"><a href="#" title="" class="b-pagination__link" data-page="' + this.prev + '">' + this.options.prevText + '</a></li>';
        } else {
            html += '<li class="b-pagination__item b-pagination__item_inActive"><span class="inactive">' + this.options.prevText + '</span></li>';
        }
    var pageCount = maxPageCount ? maxPageCount < this.pageCount ?  maxPageCount : this.pageCount : this.pageCount;
    var center_page = this.options.page - (maxPageCount / 2 >>0)
    if (center_page < 0) center_page=0;
    if (center_page + pageCount > this.pageCount) center_page=this.pageCount - pageCount;
    for (var i = center_page; i < center_page + pageCount; i++) {
        if (i == this.options.page) {
            html += '<li class="b-pagination__item"><span class="it">' + (i + 1) + '</span></li>';
        } else {
            html += '<li class="b-pagination__item"><a href="#" class="b-pagination__link" title="" data-page="' + i + '">' + (i + 1) + '</a></li>';
        }
    }

    if( this.options.showNextPrev )
        if (this.options.page < this.pageCount - 1) {
            html += '<li class="b-pagination__item -type_next"><a href="#" title="" data-page="' + this.next + '">' + this.options.nextText + '</a></li>';
        } else {
            html += '<li class="b-pagination__item -type_next"><span class="inactive">' + this.options.nextText + '</span></li>';
        }

    html += '</ul>';

    if( this.options.showDescr ) {
        var longDescr = this.options.longDescr.replace("{{amount}}", this.options.amount);
        longDescr = longDescr.replace("{{total}}", this.options.total);
        html += '<h4 class="descr">' + longDescr + '</h4>';
    }

    html += '<div style="clear: both;"></div>';

    return html;
};




/* Logger */
var Logger = (function() {
    var module = {};

    var settings = {
        debug: 1
    };

    module.init = function(_settings) {
        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }
    };

    module.log = function() {
        if (settings.debug) {
            try {
                console.log.apply(console, arguments);
            } catch(e) {}
        }
    };

    return module;
}());





/* Translator */
var Translator = (function() {
    var module = {};
    var messages = {};

    module.init = function(_messages) {
        for (var pr in _messages) {
            messages[pr] = _messages[pr];
        }
    };

    module.translate = function(msg, params) {
        if (messages[msg]) {
            msg = messages[msg];
        }

        if (!params) params = {};
        for (var pr in params) {
            msg = msg.replace(pr, params[pr]);
        }

        return msg;
    };

    return module;
}());





/* common helpers functions */
function showLoader($container) {
    var $overlay = $('<div class="pp_overlay"><span></span></div>').prependTo($container);
    $overlay.css({
        width: $container.outerWidth(true),
        height: $container.outerHeight(true)
    });

    $('span', $overlay).css('top', ($overlay.height() - $('span', $overlay).height()) / 2);

    $overlay.show();
    setTimeout(function() {
        $overlay.addClass('overlay');
    }, 0);
}

function hideLoader($container) {
    var $overlay = $('.pp_overlay', $container);
    $overlay.css({
        width: $container.outerWidth(true),
        height: $container.outerHeight(true)
    });

    setTimeout(function(){
        $overlay.removeClass('overlay');
    }, 0);

    setTimeout(function(){
        $overlay.remove();
    }, 500);
}

function showErrors(errors) {

}

function clearErrors($container) {

}

function parseURLParams() {
    var params = {};

    var hash = window.location.hash;
    if (hash.substr(0, 2) == '#!') {
        var pairs = hash.substr(2).split('&');
        for (var i = 0; i < pairs.length; i++) {
            var kv = pairs[i].split('=');
            if (typeof(kv[1]) != 'undefined') {
                params[kv[0]] = decodeURIComponent(kv[1]);
            }
        }
    }
    return params;
}

function buildHashString(params) {
    var pairs = [];
    for (var key in params) {
        pairs.push(key + '=' + params[key]);
    }

    return pairs.join('&');
}

function prepareHashParams(params) {
    var result = {};
    for (var key in params) {
        var v = params[key];
        if ($.isArray(v)) {
            v = v.join(',');
        }
        if (v) result[key] = v;
    }
    return result;
}

function scrollToBlock($el) {
    $('body, html').animate({scrollTop: $el.offset().top}, 100);
}
