/* PartnersForm */
var PartnersForm = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        debug: 1,
        defaultCountry: '',
        countryOrdering: {},
        cityOrdering: {},
        emptyOptionTitle: '---',
        searchURL: '',
        emptyImage: 'empty.gif',
        paginatorOnTop: true,
        trimLength: 60,
        bannerParams: {},
        bannerUrl: {},
        bannerSrcTpl: '',
        resultContainerHint: ''
    };

    var vocabs = {
        countries: [],
        cities: [],
        categories: [],
        searchTypes: []
    };

    var ui = {
        formContainer: '#ppFormContainer',
        nameInput: '#ppName',
        countrySelect: '#ppCountry',
        citySelect: '#ppCity',
        categorySelect: '#ppCategory',
        searchTypes: '#ppSearchTypes',
        submitBtn: '#ppSubmit',
        resetBtn: '#ppReset',
        resultHeader: '#ppResultHeader',
        resultContainer: '#ppResultContainer',
        bankBannerImg: '#ppBankBannerImg',
        bankBannerUrl: '#ppBankBannerUrl'
    };

    var userInitSearch = false;

    var log = Logger.log;
    var t = Translator.translate;

    function countryOptions() {
        var options = [];

        for (var i = 0; i < vocabs.countries.length; i++) {
            var opt = vocabs.countries[i];
            options.push([opt.code, opt.name]);
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.countryOrdering[a1[0]]) {
                a = Array(settings.countryOrdering[a1[0]]).join(' ');
            }
            if (settings.countryOrdering[b1[0]]) {
                b = Array(settings.countryOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function cityOptions(countryCode) {
        var options = [];

        for (var i = 0; i < vocabs.cities.length; i++) {
            var opt = vocabs.cities[i];
            if (opt.country_code == countryCode) {
                options.push([opt.id, opt.name]);
            }
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.cityOrdering[a1[0]]) {
                a = Array(settings.cityOrdering[a1[0]]).join(' ');
            }
            if (settings.cityOrdering[b1[0]]) {
                b = Array(settings.cityOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function categoryOptions() {
        var options = [];

        for (var i = 0; i < vocabs.categories.length; i++) {
            var opt = vocabs.categories[i];
            options.push([opt.id, opt.name]);
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function searchTypeOptions() {
        return vocabs.searchTypes;
    }

    function buildTextInput($el, initialVal) {
        if (initialVal) {
            $el.val(initialVal);
        }

        $el.css('background-color', '#f0f0f0');

        $el.focus(function() {
            $(this).parent().addClass('active');
        });

        $el.blur(function() {
            $(this).parent().removeClass('active');
        });
    }

    function buildSelect($el, data, allowEmpty, emptyTitle, defaultVal, initialVal) {
        log('build select', $el.attr('id'));

        $('option', $el).remove();

        if (allowEmpty) {
            if (!emptyTitle) emptyTitle = settings.emptyOptionTitle;
            $el.append($('<option value="">' + emptyTitle + '</option>'));
        }

        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<option value="' + opt[0] + '">' + opt[1] + '</option>'));
        }

        if (initialVal) {
            $el.val(initialVal);
        } else if (defaultVal) {
            $el.val(defaultVal);
        }
    }

    function buildCheckboxes($el, data, defaultVal, initialVal) {
        log('build checkboxes', $el.attr('id'), initialVal);

        $('label', $el).remove();

        var prefix = $el.attr('id');
        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            var cur_id = prefix + opt[0];
            var $label = $(''
                + '<label for="' + cur_id + '" class="s' + (i+1) +'" >'
                + '<input id="' + cur_id + '" '
                    + 'type="radio" '
                    + 'name="searchtype" '
                    + 'value="' + opt[0] + '" '
                    + 'style="display:none" '
                    + ' />'
                + opt[1] + '</label>'
            ).click(function() {
                var cl = $(this).attr('class');
                var cid = $(this).attr('for');
                //var id = $(this).child('input').attr('id');
                set_class_name_by_id(prefix, 'triggers trigger_3 ' + cl);
                set_checked(cid);
            });
            var $span = $(
                '<span class="button '
                    + (i == 0 ? 'first ' : '')
                    + (i == data.length - 1? 'last ' : '')
                    + 's' + (i+1) + '">'
                    + '</span>'
            ).append($label);
            $el.append($span);
        }

        if (initialVal) {
            $('input[value=' + initialVal + ']', $el).parent('label').click();
        } else if (defaultVal) {
            $('input[value=' + defaultVal + ']', $el).parent('label').click();
        } else {
            $('input', $el).last().parent('label').click();
        }
    }

    function buildPaginator(data) {
        data['prevText'] = t('PAGINATOR_PREV_TEXT');
        data['nextText'] = t('PAGINATOR_NEXT_TEXT');
        data['longDescr'] = t('PAGINATOR_SHOW_HTML');
        data['showDescr'] = true;
        data['showPages'] = false;
        data['pagesStr'] = t('PAGINATOR_PAGES');

        var paginator = new Paginator(data);
        if (paginator.isEnabled()) {
            return '<div class="pager">' + paginator.getHTML() + '</div>';
        }
        return '';
    }

    function checkForm() {
        var errors = [];

        return errors;
    }

    function buildResult(data) {
        var html = '';
        for (var i = 0; i < data.length; i++) {
            var qs = {
                country: ui.countrySelect.val(),
                city: ui.citySelect.val(),
                searchType: ui.searchTypes.find(':checked').val(),
                name: ui.nameInput.val(),
                categories: [ui.categorySelect.val()]
            };

            var img = data[i].image;
            if (!img) img = settings.emptyImage;

            var ma_imgsrc = 'earn-spend.png',
                img_class = 'earn-spend';
            if (data[i].mile_action == 'earn') {
                ma_imgsrc = 'earn.png';
                img_class = 'earn';
            }
            else if (data[i].mile_action == 'spend') {
                ma_imgsrc = 'spend.png';
                img_class = 'spend';
            }

            html +=
                '<div class="p">' +
                    '<a href="' + data[i].url + '?' + $.param(qs) + '">' +
                        (data[i].is_new? '<div class="mark-new"></div>' : '') +
                        '<div class="ma_img ' + img_class + '"></div>' +
                        '<div class="pi"><img src="' + img + '" alt="' + data[i].name + '" /></div>' +
                        '<div class="pd"><p>' +
                        (data[i].short_descr.length < settings.trimLength ?
                            data[i].short_descr :
                            data[i].short_descr.substr(0, settings.trimLength) + '...') +
                        '</p></div>' +
                    '</a>' +
                '</div>';
        }

        return html;
    }

    function loadPartners(params) {
        window.location.hash = '!' + buildHashString(prepareHashParams(params));

        $.ajax({
            url: settings.searchURL,
            cache: true,
            dataType: 'json',
            type: 'GET',
            data: params,
            beforeSend: function(xhr) {
                showLoader(ui.resultContainer);
            },
            success: function(data) {
                ui.resultContainer.empty();

                var html = '';
                if (data.success) {
                    if (data.data.items && data.data.items.length) {
                        html = '';
                        var paginator_data = data.data.paginator;
                        paginator_data['showNextPrev'] = settings.paginatorOnTop;
                        if( settings.paginatorOnTop )
                            html += buildPaginator(paginator_data);
                        html += buildResult(data.data.items);
                        if( !settings.paginatorOnTop )
                            html += buildPaginator(paginator_data);
                    } else {
                        html = '<p class="info">' + t('NO_ITEMS_FOUND') + '</p>';
                    }
                } else {
                    html = '<p class="error">' + data.errors.join('<br />') + '</p>';
                }

//                ui.resultContainer.append($('<div class="bi">' + html + '</div>'));
                ui.resultContainer.append($(html));

                $('.paginator a', ui.resultContainer).each(function(i, el) {
                    $(el).click(function(e) {
                        e.preventDefault();

                        var page = parseInt($(el).attr('data-page'), 10);
                        var _params = $.extend({}, params);
                        if (page) {
                            _params['page'] = page;
                        } else {
                            delete _params['page'];
                        }

                        loadPartners(_params);

                        scrollToBlock(ui.resultHeader.prev());
                    });
                });
            },
            complete: function() {
                hideLoader(ui.resultContainer);
                if (userInitSearch) {
                    ui.resultHeader.show();
                }
                ui.resultContainer.show();
            },
            error: function() {
                ui.resultContainer.empty();
                ui.resultContainer.append($('<div class="bi">' + t('DATA_LOAD_ERROR') + '</div>'));
            }
        });
    }

    function initBanners() {
        log('init banner');
        var lang = (settings.bannerParams.lang == 'ru' ? settings.bannerParams.lang : 'int');
        ui.bankBannerImg.attr('src', settings.bannerSrcTpl.replace("{0}", lang)).load(function() {
            $(this).show();
        });
        ui.bankBannerUrl.attr('href', settings.bannerUrl[lang]);
    }

    function init() {
        log('init');

        var initialParams = parseURLParams();

        initBanners();

        buildTextInput(ui.nameInput, initialParams['name']);

        buildSelect(ui.countrySelect, countryOptions(), settings.defaultCountry == '',
                    t('SELECT_COUNTRY'), settings.defaultCountry, initialParams['country']);

        ui.countrySelect.bind('change', function(evt) {
            var $target = $(evt.target);

            log('evt change', $target.attr('id'));

            if (!$target.val()) {
                buildSelect(ui.citySelect, [], true, t('SELECT_CITY'), '', '');
                ui.citySelect.prop('disabled', true).trigger('chosen:updated');
            } else {
                buildSelect(ui.citySelect, cityOptions($target.val()), true,
                            t('SELECT_CITY'), '', initialParams['city']);
                ui.citySelect.prop('disabled', false).trigger('chosen:updated');
            };
//            buildSelect(ui.citySelect, cityOptions($target.val()), true,
//                        t('SELECT_CITY'), '', initialParams['city']);

            delete initialParams['city'];
        });
        ui.countrySelect.trigger('change');

        buildSelect(ui.categorySelect, categoryOptions(), true,
                         t('ALL_CATEGORIES'), '',
                         initialParams['categories']);

        buildCheckboxes(ui.searchTypes, searchTypeOptions(), '', initialParams['searchType']);

        if (!settings.resultContainerHint) {
            settings.resultContainerHint = ui.resultContainer.html();
        }

        ui.submitBtn.bind('click', function(evt, customEvent) {
            var $target = $(evt.target);

            log('evt click', $target.attr('id'));

            var errors = checkForm();
            clearErrors(ui.formContainer)
            if (errors.length) {
                showErrors(errors);
                return;
            }

            if (!customEvent) {
                userInitSearch = true;
            }

            loadPartners({
                name: ui.nameInput.val(),
                country: ui.countrySelect.val(),
                city: ui.citySelect.val(),
                categories: [ui.categorySelect.val()],
                searchType: ui.searchTypes.find(':checked').val()
            });
        });

        ui.nameInput.keypress(function(evt) {
            if (evt.which == 13) {
                ui.submitBtn.click();
                return false;       // End processing, do not submit form.
            }
        });

        ui.resetBtn.bind('click', function(evt) {
            ui.countrySelect.val('').trigger("chosen:updated").trigger("change");
            ui.categorySelect.val('').trigger("chosen:updated").trigger("change");
            ui.searchTypes.find('input[value=A]').trigger('click');
            ui.nameInput.val('');
            //ui.resultContainer.html(settings.resultContainerHint);
            window.location.hash = '';
            ui.submitBtn.trigger('click', true);
        });

        ui.submitBtn.trigger('click', true);
    }

    module.init = function(_settings, _translations, _vocabs) {
        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    };

    return module;
}(jQuery, Logger, Translator));


/* PartnerPage */
var PartnerPage = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        debug: 1,
        defaultCountry: '',
        defaultCity: '',
        countryOrdering: {},
        cityOrdering: {},
        emptyOptionTitle: '---',
        emptyImage: 'empty.gif',
        partner_id: '',
        searchURL: '',
        contactTypes: {PHONE: 'P', FAX: 'F', EMAIL: 'E'},
        officeTypes: {MAIN: 'M', OTHER: 'O'},
        hideContactsSearchBlock: false
    };

    var vocabs = {
        countries: [],
        cities: [],
        contactTypes: []
    };

    var ui = {
        countrySelect: '#ppCountry',
        citySelect: '#ppCity',
        formContainer: '#ppContactsForm',
        resultHeader: '#ppResultHeader',
        resultContainer: '#ppResultContainer',
        submitBtn: '#ppSubmit',
        tabContacts: '#ppTabsContacts'
    };

    var userInitSearch = false;

    var log = Logger.log;
    var t = Translator.translate;

    function countryOptions() {
        var options = [];

        for (var i = 0; i < vocabs.countries.length; i++) {
            var opt = vocabs.countries[i];
            options.push([opt.code, opt.name]);
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.countryOrdering[a1[0]]) {
                a = Array(settings.countryOrdering[a1[0]]).join(' ');
            }
            if (settings.countryOrdering[b1[0]]) {
                b = Array(settings.countryOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function cityOptions(countryCode) {
        var options = [];

        for (var i = 0; i < vocabs.cities.length; i++) {
            var opt = vocabs.cities[i];
            if (opt.country_code == countryCode) {
                options.push([opt.id, opt.name]);
            }
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.cityOrdering[a1[0]]) {
                a = Array(settings.cityOrdering[a1[0]]).join(' ');
            }
            if (settings.cityOrdering[b1[0]]) {
                b = Array(settings.cityOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function buildSelect($el, data, allowEmpty, emptyTitle, defaultVal, initialVal) {
        log('build select', $el.attr('id'));


        $('option', $el).remove();

        if (allowEmpty) {
            if (!emptyTitle) emptyTitle = settings.emptyOptionTitle;
            $el.append($('<option value="">' + emptyTitle + '</option>'));
        }

        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<option value="' + opt[0] + '">' + opt[1] + '</option>'));
        }

        if (initialVal) {
            $el.val(initialVal);
        } else if (defaultVal) {
            $el.val(defaultVal);
        }

        $el.trigger('chosen:updated');
    }


    function buildPaginator(data) {
        data['prevText'] = t('PAGINATOR_PREV_TEXT');
        data['nextText'] = t('PAGINATOR_NEXT_TEXT');
        data['showNextPrev'] = false;

        var paginator = new Paginator(data);
        if (paginator.isEnabled()) {
            return '<div class="pager">' + paginator.getHTML() + '</div>';
        }
        return '';
    }

    function getGroupedContacts(data) {
        data.sort(function(a, b) {
            return b.main_contact;
        });

        var grouped = {};
        for (var i = 0; i < data.length; i++) {
            if (!grouped[data[i].contact_type]) {
                grouped[data[i].contact_type] = [];
            }
            grouped[data[i].contact_type].push(data[i]);
        }

        var map = {};
        for (var i = 0; i < vocabs.contactTypes.length; i++) {
            map[vocabs.contactTypes[i][0]] = vocabs.contactTypes[i][1];
        }

        var result = [];
        var types = [settings.contactTypes.PHONE, settings.contactTypes.FAX, settings.contactTypes.EMAIL];
        var classes = {};
        classes[settings.contactTypes.PHONE] = 's_phone';
        classes[settings.contactTypes.FAX] = 's_fax';
        classes[settings.contactTypes.EMAIL] = 's_mail';
        for (var i = 0; i < types.length; i++) {
            if (grouped[types[i]]) {
                result.push({
                    cls: classes[types[i]],
                    name: map[types[i]],
                    items: grouped[types[i]]
                });
            }
        }

        return result;
    }

    function buildResult(data) {
        data.sort(function(a, b) {
            var co1 = a.country.toLowerCase();
            var co2 = b.country.toLowerCase();
            if (co1 != co2) { // by country
                if (co1 < co2) return -1;
                if (co1 > co2) return 1;
                return 0;
            }

            var ct1 = a.city.toLowerCase();
            var ct2 = b.city.toLowerCase();
            if (ct1 != ct2) { // by city
                if (ct1 < ct2) return -1;
                if (ct1 > ct2) return 1;
                return 0;
            }

            var ot1 = a.office_type;
            var ot2 = b.office_type;
            if (ot1 != ot2) { // by office type
                if (ot1 == settings.officeTypes.MAIN) return -1;
                if (ot2 == settings.officeTypes.MAIN) return 1;
                return 0;
            }

            var ad1 = a.address.toLowerCase();
            var ad2 = b.address.toLowerCase();
            if (ad1 < ad2) return -1;
            if (ad1 > ad2) return 1;
            return 0;
        });

        var html = '';
        for (var i = 0; i < data.length; i++) {
            var mapF = function(elem) {
                if (elem.main_contact) {
                    elem.contact = '<b>' + elem.contact + '</b>';
                }
                return elem.contact;
            };

            var groupedContacts = getGroupedContacts(data[i].contacts);
            var contacts = [];
            for (var k = 0; k < groupedContacts.length; k++) {
                contacts.push('<p class="' + groupedContacts[k].cls + '">' + $.map(groupedContacts[k].items, mapF).join(', ') + '</p>');
            }

            html +=
                '<div style="padding-top:5px">' +
                    '<h4>' + data[i].comments + '</h4>' +
                    '<p>' + data[i].address + '</p>' +
                    (contacts.length > 0 ? contacts.join('') : '') +
                    //(data[i].worktime ? '<p class="s_clock">' + data[i].worktime + '</p>' : '') +
                '</div>';
        }

        return html;
    }

    function checkForm() {
        var errors = [];

        return errors;
    }

    function loadOffices(params) {

        $.ajax({
            url: settings.searchURL,
            cache: true,
            dataType: 'json',
            type: 'GET',
            data: params,
            beforeSend: function(xhr) {
                showLoader(ui.resultContainer);
            },
            success: function(data) {
                ui.resultContainer.empty();

                var html = '';
                if (data.success) {
                    if (data.data.items && data.data.items.length) {
                        html = buildPaginator(data.data.paginator);
                        html += '<fieldset class="info">' + buildResult(data.data.items) + '</fieldset>';
                    } else {
                        html = '<p class="info">' + t('NO_ITEMS_FOUND') + '</p>';
                    }
                } else {
                    html = '<p class="error">' + data.errors.join('<br />') + '</p>';
                }

                ui.resultContainer.append($(html));

                $('.paginator a', ui.resultContainer).each(function(i, el) {
                    $(el).click(function(e) {
                        e.preventDefault();

                        var page = parseInt($(el).attr('data-page'), 10);
                        var _params = $.extend({}, params);
                        if (page) {
                            _params['page'] = page;
                        } else {
                            delete _params['page'];
                        }

                        loadOffices(_params);

                        scrollToBlock(ui.resultHeader.prev());
                    });
                });
            },
            complete: function() {
                hideLoader(ui.resultContainer);
                if (userInitSearch) {
                    ui.resultHeader.show();
                }
                ui.resultContainer.show();

                userInitSearch = true;
            },
            error: function() {
                ui.resultContainer.empty();
                ui.resultContainer.append($('<p class="error">' + t('DATA_LOAD_ERROR') + '</p>'));
            }
        });
    }


    function init() {
        log('init');

        var initialParams = parseURLParams();

        buildSelect(ui.countrySelect, countryOptions(), true, t('SELECT_COUNTRY'),
                    settings.defaultCountry, '');

        ui.countrySelect.bind('change', function(evt) {
            var $target = $(evt.target);

            log('evt change', $target.attr('id'));

            if (!$target.val()) {
                buildSelect(ui.citySelect, [], true, t('SELECT_CITY'), '', '');
                ui.citySelect.prop('disabled', true).trigger('chosen:updated');
            } else {
                buildSelect(ui.citySelect, cityOptions($target.val()), true,
                            t('SELECT_CITY'), settings.defaultCity, initialParams['city']);
                ui.citySelect.prop('disabled', false).trigger('chosen:updated');
            };
//            buildSelect(ui.citySelect, cityOptions($target.val()), true,
//                        t('SELECT_CITY'), settings.defaultCity, '');
        });
        ui.countrySelect.trigger('change');

        var params = $.extend({
            id: settings.partner_id,
            country: ui.countrySelect.val(),
            city: ui.citySelect.val(),
            reqType: 'offices'
        }, initialParams);

        if (settings.hideContactsSearchBlock) {
            ui.tabContacts.children().not(ui.resultContainer).hide();
            loadOffices(params);
        } else {
            ui.submitBtn.bind('click', function (evt, customEvent, initialParams) {
                var $target = $(evt.target);

                log('evt click', $target.attr('id'));

                if (typeof(initialParams) == 'undefined') initialParams = {};

                var errors = checkForm();
                clearErrors(ui.formContainer);
                if (errors.length) {
                    showErrors(errors);
                    return;
                }

                if (!customEvent) {
                    userInitSearch = true;
                }

                loadOffices(params);
            });
        }

        if (!$.isEmptyObject(initialParams) || settings.defaultCountry != '' || settings.defaultCity != '') {
            ui.submitBtn.trigger('click', true, initialParams);
        }

        ui.tabContacts.show();
    }

    module.init = function(_settings, _translations, _vocabs) {
        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    };

    return module;
}(jQuery, Logger, Translator));



/* Airline Page */
var AirlinePage = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        debug: 1,
        airline: {},
        parent: {},
        children: [],
        emptyImage: 'empty.gif',
        milesTable: [],
        oldMilesTable: [],
        isNewMiliesTable: false,
        bookingClassComments: [],
        eliteCoefficients: [],
        mileEarningComments: [],
        afl_iata: ''
    };

    var ui = {
        contentBlock: '.content',

        imageContainer: '#apImage',
        airlineTitle: '#ppName',
        descriptionContainer: '#apAirlineDescription',
        descriptionTitle: '#apDescriptionTitle',
        relatives: '#apRelatives',
        awardsCalculatorButton: '#apAwardsCalculatorButton',
        earnTab: '#apTabsEarn',
        airlineSite: '#apAirlineSite',
        milesTitle: '#apMilesTitle',
        milesEarnDescription: '#apMilesEarnDescription',
        milesComment: '#apMilesComment',
        milesLimitation: '#apMilesLimitation',
        milesTable: '#apMilesTable',
        milesTableOld: '#apMilesTableOld',
        eliteCoefficients: '#apEliteCoefficients',
        bookingClassesWithoutBonus: '#apBookingClassesWithoutBonus',
        bookingClassesWithoutBonusOld: '#apBookingClassesWithoutBonusOld',
        bookingClassComments: '#apBookingClassComments',
        backButton: '#apBackButton',
        earnCalcLink: '#apEarnCalcLink',
        spendCalcLink: '#apSpendCalcLink'
    };

    var log = Logger.log;
    var t = Translator.translate;

    var links = {};

    function buildInfo(ob) {
        log('build info');

        if (!ob) return;

        var img = ob.image;
        if (!img) img = settings.emptyImage;

        ui.imageContainer.children('img').each(function(i) {
            $(this).attr({"src": settings.emptyImage, "data-src": img, "alt": ob.title});
            var image = new AdaptiveImage($(this), {padding: 0});
        });

        //ui.airlineTitle.html(settings.airline.title);

        if (ob.url.length > 0)
            ui.airlineSite.html('<a target="_blank" href="' + ob.full_url +'" rel="nofollow">' + ob.url + '</a>');

        if (settings.airline.iata == settings.afl_iata)
            ui.spendCalcLink.show();
        else
            ui.spendCalcLink.remove();
    }

    function _airline2div(airline, show_link) {
        if (!show_link)
            return '<div><label>' + airline.title + ' (' + airline.flight_code + ')</label></div>';
        return '<li><a href="' + airline.link + '" '
            + 'title="' + airline.title + '">' + airline.title + ' (' + airline.flight_code + ')</a></li>'
    }

    function buildRelatives(par, children, show_links) {
        log('parent and children info');

        var html = '';
        if (par !== null) {
            html = '<div class="list-header">' + t('PARENT_AIRLINE') + ':</div>';
            html += (show_links ? '<ul class="table">' : '<fieldset class="v">')
                + _airline2div(par, show_links)
                + (show_links ? '</ul>' : '</fieldset>');
        }

        if (children.length > 0) {
            html += '<div class="list-header">' + t('CHILDREN_AIRLINES') + ':</div>';
            html += (show_links ? '<ul class="table">' : '<fieldset class="v">');
            children.forEach(function(item, i, arr) {
                html += _airline2div(item, show_links);
            });
            html += (show_links ? '</ul>' : '</fieldset>');
        }

        ui.relatives.html(html);
    }

    function buildMileEarningComments(mileEarningComments) {
        ui.milesTitle.html('<p>' + t('MILES_DEPEND') + '</p>');
        if (mileEarningComments.miles_earn_description.length > 0)
            ui.milesEarnDescription.html('<p>' + mileEarningComments.miles_earn_description + '</p>');
        ui.milesComment.html('<p>' + t('MILES_ARE_QUALIFYING') + '</p>');
        if (mileEarningComments.miles_limitation_verbose.length > 0)
            ui.milesLimitation.html('<p>' + mileEarningComments.miles_limitation_verbose.replace(/#/g, mileEarningComments.miles_minimum) + '</p>');
        if (mileEarningComments.miles_earn_comment.length > 0)
            ui.bookingClassesWithoutBonus.html('<p>' + mileEarningComments.miles_earn_comment + '</p>');
    }

    function buildMilesTable(milesTable, idMilesTable) {
        log('miles table');

        var html = '';

        milesTable.forEach(function(cl, i, arr) {
            var clname = cl[0];
            var booking_classes = cl[1];

            if (booking_classes.length > 0) {
                html += '<h4>' + clname + '</h4>'
                    + '<fieldset class="v">';
            }

            var bcl_html = '';

            booking_classes.forEach(function(bcl, j, arr) {
                var booking_class_list = [];
                bcl[0].forEach(function(bcl, k, arr) {
                    var bcl_str = '<em>' + bcl.code.toString() + '</em>';

                    if (bcl.note) {
                        bcl_str += '<sup>' + bcl.note + '</sup>';
                    }
                    booking_class_list.push(bcl_str);
                });

                bcl_html += '<div><label>' + booking_class_list.join(', ') + '<b class="ordinal">' + bcl[1] + '%</b></label></div>';
            });
            if (booking_classes.length > 0)
                html += bcl_html + '</fieldset>';
        });
        idMilesTable.html(html);
    }

    function buildMilesTableNew(milesTable) {
        log('miles table new');

        var html = '';

        milesTable.forEach(function(cl, i, arr) {
            var clname = cl[0];
            var tariffs = cl[1];

            var tf_html = '<table class="miles_table_new"><tr>';
            tariffs.forEach(function(tf, j, arr) {
                var bcl_html = '<td>'+tf[0]+'</td>';
                tf[1].forEach(function(bcl, k, arr){
                    if (k > 0) {
                        bcl_html += '</tr><tr><td></td>';
                    }
                    var booking_class_list = [];
                    bcl[0].forEach(function(bcl, k, arr) {
                        var bcl_str = bcl.code.toString();

                        if (bcl.note) {
                            bcl_str += '<sup>' + bcl.note + '</sup>';
                        }
                        booking_class_list.push(bcl_str);
                    });
                    bcl_html += '<td>' + booking_class_list.join(', ') + '</td><td class="bcl_miles">' + bcl[1] + '%</td>';
                });
                tf_html += bcl_html  + '</tr>';
            });

            if (tariffs.length > 0)
                html += '<h4>' + clname + '</h4>'
                    + '<fieldset class="v">' + tf_html + '</table></fieldset>';
        });
        ui.milesTable.html(html);
        ui.bookingClassesWithoutBonusOld.html('<p>' + settings.bookingClassesWithoutBonusOld + '</p>');
    }

    function buildBookingClassComments(bookingClassComments) {
        log('booking class comments');
        var html = '';

        bookingClassComments.forEach(function(item, i, arr) {
            html += '<p><sup>' + item[0] + '</sup>' + item[1] + '</p>';
        });

        ui.bookingClassComments.html(html);
    }

    function buildEliteCoefficients(eliteCoefficients) {
        var list_html = '';

        var levels = {platinum: t('TO_PLATINUM_PARTICIPANTS'),
                      gold: t('TO_GOLD_PARTICIPANTS'),
                      silver: t('TO_SILVER_PARTICIPANTS')}

        log('elite coefficients');
        if (eliteCoefficients.length == 0)
            return;

        var html = '<p>' + t('ADDITIONAL_ELITE_MILES') + ':</p>';

        eliteCoefficients.forEach(function(record, i, arr) {
            var coefficient = record[1];

            if (coefficient > 0) {
                var title = levels[record[0]];
                list_html += '<p>+' + coefficient + '% ' + t('FROM_DISTANCE') + '&nbsp;&ndash;&nbsp;' + title + '</p>';
            }
        });

        html += list_html;

        html += '<p>' + t('ELITE_MILES_AINT_QUALIFYING') + '</p>';
        ui.eliteCoefficients.html(html);
    }

    function init() {
        log('init');

        var initialParams = parseURLParams();

        buildInfo(settings.airline);
        buildRelatives(settings.parent, settings.children,
                settings.airline.iata == settings.afl_iata || (settings.parent != null && settings.parent.flight_code == settings.afl_iata));

        if (settings.isNewMiliesTable) {
            buildMilesTableNew(settings.milesTable);
            buildMilesTable(settings.milesTableOld, ui.milesTableOld);
            $('.toggle_apMilesTable').click(function(evt){
                if ($(this).hasClass('withoutArrow')) {
                    $(this).parent().toggle();
                    $(this).parent().parent().find('.toggle_apMilesTable').toggleClass('opened');
                } else {
                    $(this).parent().find('.toggleBlock').toggle();
                    $(this).toggleClass('opened');
                }
            });
        } else {
            buildMilesTable(settings.milesTable, ui.milesTable);
            if (settings.milesTableOld.length > 0) {
                buildMilesTable(settings.milesTableOld, ui.milesTableOld);
                $('.toggle_apMilesTable').click(function(evt){
                    if ($(this).hasClass('withoutArrow')) {
                        $(this).parent().toggle();
                        $(this).parent().parent().find('.toggle_apMilesTable').toggleClass('opened');
                    } else {
                        $(this).parent().find('.toggleBlock').toggle();
                        $(this).toggleClass('opened');
                    }
                });
            }
        }
        buildBookingClassComments(settings.bookingClassComments);
        buildEliteCoefficients(settings.eliteCoefficients);
        buildMileEarningComments(settings.mileEarningComments);
        setupLinkButton(ui.awardsCalculatorButton);
    }

    module.init = function(_settings, _translations, _vocabs) {

        if (typeof Array.prototype.forEach != 'function') {
            Array.prototype.forEach = function(callback){
                for (var i = 0; i < this.length; i++){
                    callback.apply(this, [this[i], i, this]);
                }
            };
        }

        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    }

    return module;
}(jQuery, Logger, Translator));
