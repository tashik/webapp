"use strict";

/* Bind ENTER {13} on Select search type */

function setKeyBindSearchType(selectElem) {
  var $mySelect = selectElem;
  var $chInput = $mySelect.next(this).find('.chosen-search input');

  function setActiveDescendant(container) {
    var text_predefined = $mySelect.next(container).find('.chosen-single > span').text();
    $mySelect.attr('title', text_predefined);
  }

  function handlerKeyDownEmulate(event) {
    if (event.keyCode === 13 && !$(this).hasClass('chosen-with-drop')) {
      var triggerChosen,
        evt = jQuery.Event("keyup");
      evt.which = evt.keyCode = 40;
      startForceTrigger();
    }
    function startForceTrigger() {
      clearTimeout(triggerChosen);
      $chInput.blur();
      triggerChosen = setTimeout(function () {
        $mySelect.chosen({});
        $mySelect.trigger('chosen:open');
      }, 250);
    }
  }

  setActiveDescendant('.chosen-container');
  $(".chosen-container").unbind('keydown.force').bind('keydown.force', function (e) {
    handlerKeyDownEmulate.call(this, e);
  });

  function setAriaActiveDescendant (search_field) {
    var first_elem = $('.chosen-results').children().eq(0),
      first_elem_id = first_elem.id || search_field.attr('aria-owns') + '-0';
    search_field.attr('aria-activedescendant', first_elem_id)
  }
}

function updateAdaptiveWidgets($widgets, minInputWidth) {
    var inline = true;
    var data = [];
    $widgets.each(function() {
        var $c = $(this);
        var $label = $('label', $c);
        var w = $label.text() ? $label.outerWidth() : 0;
        var $input = $('input:nth-child(1), select:nth-child(1)', $c).first();
        data.push({
            label: $label,
            input: $input,
            w: w
        });
        if ($c.outerWidth() - w < minInputWidth) {
            inline = false;
        }
    });

    $(data).each(function(i, ob) {
        if (inline) {
            ob.label.parent().css('width', ob.w);
            ob.input.parent().css('margin-left', ob.w);
        } else {
            ob.label.parent().css('width', 'auto');
            ob.input.parent().css('margin-left', 0);
        }
    });
}

/* Banners block */
function loadBanners($container, banner_url, banner_params, user_info) {
    if (typeof(banner_url) == "string" && !!banner_url) {
        $.ajax({
            type: "POST",
            url: banner_url,
            data: {
                data: JSON.stringify(banner_params),
                user_info: JSON.stringify(user_info)
            },
            dataType: "json",
            success: function(data, testStatus) {
                var html = '';
                for (var key in data.banners) {
                    html += data.banners[key];
                }
                $container.html(html);
            }
        });
    };
}

/* PartnersForm */
var PartnersForm = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        debug: 1,
        defaultCountry: '',
        countryOrdering: {},
        cityOrdering: {},
        emptyOptionTitle: '---',
        searchURL: '',
        emptyImage: 'empty.gif',
        paginatorOnTop: false,
        oldCategorySelector: true,
        useAjax: true,
        minInputWidth: 150,
        maxPageCount: 6,
        mileActionIcons: { earn: 'earn', spend: 'spend', 'all': 'earn-spend'},
        resultContainerHint: ''
    };

    var vocabs = {
        countries: [],
        cities: [],
        categories: [],
        searchTypes: []
    };

    var ui = {
        rightBlock: '.block-right',
        formContainer: '#ppFormContainer',
        searchFormContainer: '#ppSearchFormContainer',
        stWidgets: '#ppSearchFormContainer .stwidget:visible',
        nameInput: '#ppName',
        countrySelect: '#ppCountry',
        citySelect: '#ppCity',
        categorySelect: '#ppCategory',
        //searchTypes: '#ppSearchTypes',
        searchType: '#ppSearchType',
        submitBtn: '#ppSubmit',
        resetBtn: '#ppReset',
        resultHeader: '#ppResultHeader',
        resultContainer: '#ppResultContainer'
    };

    var userInitSearch = false;

    var log = Logger.log;
    var t = Translator.translate;

    function countryOptions() {
        var options = [];

        for (var i = 0; i < vocabs.countries.length; i++) {
            var opt = vocabs.countries[i];
            options.push([opt.code, opt.name]);
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.countryOrdering[a1[0]]) {
                a = Array(settings.countryOrdering[a1[0]]).join(' ');
            }
            if (settings.countryOrdering[b1[0]]) {
                b = Array(settings.countryOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function cityOptions(countryCode) {
        var options = [];

        for (var i = 0; i < vocabs.cities.length; i++) {
            var opt = vocabs.cities[i];
            if (opt.country_code == countryCode) {
                options.push([opt.id, opt.name]);
            }
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.cityOrdering[a1[0]]) {
                a = Array(settings.cityOrdering[a1[0]]).join(' ');
            }
            if (settings.cityOrdering[b1[0]]) {
                b = Array(settings.cityOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function categoryOptions() {
        var options = [];

        for (var i = 0; i < vocabs.categories.length; i++) {
            var opt = vocabs.categories[i];
            options.push([opt.id, opt.name]);
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function searchTypeOptions() {
        return vocabs.searchTypes;
    }

    function updateLayout() {
        log('update layout');

        updateAdaptiveWidgets(ui.stWidgets, settings.minInputWidth);
        setKeyBindSearchType(ui.searchType);
    }

    function buildTextInput($el, initialVal) {
        if (initialVal) {
            $el.val(initialVal);
        }

        $el.wrap('<div class="inputContainer"></div>');

        $el.focus(function() {
            $(this).parent().addClass('active');
        });

        $el.blur(function() {
            $(this).parent().removeClass('active');
        });
    }

    function buildSelect($el, data, allowEmpty, emptyTitle, defaultVal, initialVal) {
        log('build select', $el.attr('id'));

        $el.chosen({
            width: '100%',
            disable_search: data.length < 20,
            inherit_select_classes: true,
            search_contains: true,
            no_results_text: t('SELECT_NO_RESULTS')
        });

        $('option', $el).remove();

        if (allowEmpty) {
            if (!emptyTitle) emptyTitle = settings.emptyOptionTitle;
            $el.append($('<option value="">' + emptyTitle + '</option>'));
        }

        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<option value="' + opt[0] + '">' + opt[1] + '</option>'));
        }

        if (initialVal) {
            $el.val(initialVal);
        } else if (defaultVal) {
            $el.val(defaultVal);
        }

        $el.trigger('chosen:updated');
    }

    function buildNewMultiSelect($el, data, defaultVal, initialVal, placeholder) {
        log('build new multiselect', $el.attr('id'));

        ui.categorySelect.width(0);
        $el.multiselect({
            minWidth: 200,
            selectedText: function(numChecked, numTotal, checkedItems) {
                if (numChecked === 0) {
                    return placeholder;
                } else if (numChecked === 1) {
                    return checkedItems[0].getAttribute('data-title');
                } else {
                    return checkedItems[0].getAttribute('data-title') + ' ' + t('AND_MORE') + ' ' + (numChecked - 1);
                }
            },
            checkAllText: t('CHECK_ALL'),
            uncheckAllText: t('UNCHECK_ALL'),
            noneSelectedText: placeholder
        });

        $('option', $el).remove();

        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<option value="' + opt[0] + '">' + opt[1] + '</option>'));
        }
        if (initialVal) {
            $el.val(initialVal.split(','));
        } else if (defaultVal) {
            $el.val(defaultVal);
        }
        $el.multiselect('refresh');

        // Prevent container collapse.
        //ui.categorySelect.parent().parent().css(
        //    {'min-width': ui.categorySelect.next().outerWidth() + 'px'}
        //);
    }

    function buildMultiSelect($el, data, defaultVal, initialVal, placeholder) {
        log('build multiselect', $el.attr('id'));

        $el.chosen({
            width: '100%',
            placeholder_text_multiple: placeholder,
            inherit_select_classes: true,
            search_contains: true,
            no_results_text: t('MULTISELECT_NO_RESULTS')
        });

        $('option', $el).remove();

        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<option value="' + opt[0] + '">' + opt[1] + '</option>'));
        }

        if (initialVal) {
             $el.val(initialVal.split(','));
        } else if (defaultVal) {
            $el.val(defaultVal);
        }

        $el.trigger('chosen:updated');
    }

    function buildCheckboxes($el, data, defaultVal, initialVal) {
        log('build checkboxes', $el.attr('id'), initialVal);

        $('label', $el).remove();

        var prefix = $el.attr('id');
        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<label for="' + prefix + opt[0] + '"><input id="' + prefix + opt[0] + '" type="radio" name="searchtype" value="' + opt[0] + '" />' + opt[1] + '</label>'));
        }

        if (initialVal) {
            $('input[value=' + initialVal + ']', $el).prop('checked', 'checked');
        } else if (defaultVal) {
            $('input[value=' + defaultVal + ']', $el).prop('checked', 'checked');
        } else {
            $('input', $el).first().prop('checked', 'checked');
        }
    }

    function buildPaginator(data, maxPageCount) {
        data['prevText'] = t('PAGINATOR_PREV_TEXT');
        data['nextText'] = t('PAGINATOR_NEXT_TEXT');
        data['paginatorTitle'] = t('PAGINATOR_TITLE');

        var paginator = new Paginator(data);
        if (paginator.isEnabled()) {
            var title = data['paginatorTitle']? '<span class="title">' + data['paginatorTitle'] + '</span>': '';
            var html = '<div class="pager">' + title + paginator.getHTML(maxPageCount) + '</div>';
            return html
        }
        return '';
    }

    function checkForm() {
        var errors = [];

        return errors;
    }

    function getFormData() {
        return {
            name: ui.nameInput.val(),
            country: ui.countrySelect.val(),
            city: ui.citySelect.val(),
            categories: ui.categorySelect.val(),
            //searchType: ui.searchTypes.find(':checked').val()
            searchType: ui.searchType.val()
        };
    }

    function buildResult(data) {
        var hashStr = '!' + buildHashString(prepareHashParams(getFormData()));

        var html = '';
        for (var i = 0; i < data.length; i++) {
            var qs = {
                country: ui.countrySelect.val(),
                city: ui.citySelect.val()
            };

            var img = data[i].image;
            if (!img) img = settings.emptyImage;
            var miles_action_icon = settings.mileActionIcons[data[i].mile_action]

            var alt = data[i].name;
            if (alt.length > 25) {
                alt = alt.substr(0, 25) + '...';
            }

            html +=
                '<li class="partner-search-item list-partners__item">' +
                    (data[i].is_new? '<div class="mark-new"></div>' : "") +
                    '<a aria-label="' + data[i].name + '" href="' + data[i].url + '?' + $.param(qs) + '#' + hashStr + '" class="list-partners__link" >' +
                        '<div class="img-container list-partners__container">' +
                            '<img class="ai logo list-partners__logo" data-src="' + img + '" src="' + settings.emptyImage + '"  alt="' + alt + '" />' +
                        '</div>' +
                        '<div class="info list-partners__inf">' + data[i].short_descr.substr(0,70) + '</div>' +
                        '<div class="list-partners__icon list-partners__icon_type-action action_icon '+ miles_action_icon +'"></div>' +
                    '</a>' +
                '</li>';
        }
        return html;
    }

    function loadPartners(params) {
        var hashStr = '!' + buildHashString(prepareHashParams(params));

        if (settings.useAjax) {
            window.location.hash = hashStr;

            $.ajax({
                url: settings.searchURL,
                cache: true,
                dataType: 'json',
                type: 'GET',
                data: params,
                beforeSend: function(xhr) {
                    showLoader(ui.resultContainer);
                },
                success: function(data) {
                    ui.resultContainer.empty();

                    var html = '';
                    if (data.success) {
                        if (data.data.items && data.data.items.length) {
                            html = '';
                            var paginator_data = data.data.paginator;
                            paginator_data['showNextPrev'] = true;
                            if( settings.paginatorOnTop ) {
                              ui.resultContainer.prepend(buildPaginator(paginator_data, settings.maxPageCount));
                            }
                            html += buildResult(data.data.items);
                            if(data.data.paginator.total > data.data.paginator.step ) {
                                var shown = '<span>' + data.data.items.length + '</span>';
                                var paginator_info = t('PAGINATOR_INFO')
                                    .replace('{0}', shown)
                                    .replace('{1}', data.data.paginator.total);
                               ui.resultContainer.append('<span class="paginator-info paginator-info_partners">' + paginator_info + '</span>');
                            }
                            if( !settings.paginatorOnTop ) {
                              ui.resultContainer.append(buildPaginator(paginator_data, settings.maxPageCount));
                            }
                        } else {
                            html = '<p>' + t('NO_ITEMS_FOUND') + '</p>';
                        }
                    } else {
                        html = '<p>' + data.errors.join('<br />') + '</p>';
                    }

                    ui.resultContainer.prepend($('<ul class="bi clearfix list-partners list-partners_col-3">' + html + '</ul>'));

                    $('.ai', ui.resultContainer).each(function() {
                        var image = new AdaptiveImage(this, {centerH: true, centerV: true, padding: 10, show_on_error: true});
                    });

                    $('.paginator a', ui.resultContainer).each(function(i, el) {
                        $(el).click(function(e) {
                            e.preventDefault();

                            var page = parseInt($(el).attr('data-page'), 10);
                            var _params = $.extend({}, params);
                            if (page) {
                                _params['page'] = page;
                            } else {
                                delete _params['page'];
                            }

                            loadPartners(_params);

                            scrollToBlock($('body'));
                        });
                    });
                },
                complete: function() {
                    hideLoader(ui.resultContainer);
                    if (userInitSearch) {
                        ui.resultHeader.show();
                    }
                    ui.resultContainer.show();
                },
                error: function() {
                    ui.resultContainer.empty();
                    ui.resultContainer.append($('<div class="bi">' + t('DATA_LOAD_ERROR') + '</div>'));
                }
            });
        } else {
            window.location = settings.searchURL + '#' + hashStr;
        }
    }

    function init() {
        log('init');

        var initialParams = parseURLParams();

        buildTextInput(ui.nameInput, initialParams['name']);

        buildSelect(ui.countrySelect, countryOptions(), settings.defaultCountry == '',
                    t('SELECT_COUNTRY'), settings.defaultCountry, initialParams['country']);
        ui.countrySelect.bind('change', function(evt) {
            var $target = $(evt.target);

            log('evt change', $target.attr('id'));

            if (!$target.val()) {
                buildSelect(ui.citySelect, [], true, t('SELECT_CITY'), '', '');
                ui.citySelect.prop('disabled', true).trigger('chosen:updated');
            } else {
                buildSelect(ui.citySelect, cityOptions($target.val()), true,
                            t('SELECT_CITY'), '', initialParams['city']);
                ui.citySelect.prop('disabled', false).trigger('chosen:updated');
            }

            delete initialParams['city'];
        });
        ui.countrySelect.trigger('change');

        if (settings.oldCategorySelector) {
            buildMultiSelect(ui.categorySelect, categoryOptions(), ['all'],
                    initialParams['categories'], t('ALL_CATEGORIES'));
        }
        else {
            buildNewMultiSelect(ui.categorySelect, categoryOptions(), ['all'],
                    initialParams['categories'], t('ALL_CATEGORIES'));
        }

        //buildCheckboxes(ui.searchTypes, searchTypeOptions(), '', initialParams['searchType']);
        buildSelect(ui.searchType, searchTypeOptions(), false,
                    t('SELECT_SEARCH_TYPE'), '', initialParams['searchType']);

        if (!settings.resultContainerHint) {
            settings.resultContainerHint = ui.resultContainer.html();
        }


        ui.submitBtn.bind('click', function(evt, customEvent) {
            var $target = $(evt.target);

            log('evt click', $target.attr('id'));

            var errors = checkForm();
            clearErrors(ui.formContainer)
            if (errors.length) {
                showErrors(errors);
                return;
            }

            if (!customEvent) {
                userInitSearch = true;
            }

            loadPartners(getFormData());
        });

        ui.nameInput.keypress(function(evt) {
            if (evt.which == 13) {
                ui.submitBtn.click();
            }
        });

        ui.resetBtn.bind('click', function(evt) {
            ui.countrySelect.val('').trigger("chosen:updated").trigger("change");
            ui.categorySelect.find('option:selected').removeAttr('selected');
            ui.categorySelect.multiselect('refresh');
            ui.searchType.val('A').trigger("chosen:updated");
            ui.nameInput.val('');
            ui.resultContainer.html(settings.resultContainerHint);
            window.location.hash = '';
            ui.submitBtn.trigger('click', true);
        });

        updateLayout();
        $(window).resize(updateLayout);

        ui.searchFormContainer.css('visibility', 'visible');
        ui.searchFormContainer.parents('fieldset').removeClass('no-style');

        if (settings.useAjax) {
            ui.submitBtn.trigger('click', true);
        }

        loadBanners(ui.rightBlock, settings.bannerUrl, settings.bannerParams, settings.userInfo);
    }

    module.init = function(_settings, _translations, _vocabs) {
        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    };

    return module;
}(jQuery, Logger, Translator));


/* PartnerPage */
var PartnerPage = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        debug: 1,
        defaultCountry: '',
        defaultCity: '',
        countryOrdering: {},
        cityOrdering: {},
        emptyOptionTitle: '---',
        emptyImage: 'empty.gif',
        partner: {},
        earnConditions: [],
        spendConditions: [],
        miles_table: [],
        booking_class_comments: [],
        elit_coefficients: {},
        searchURL: '',
        mileActions: {ALL: 'A', EARN: 'E', SPEND: 'S'},
        contactTypes: {PHONE: 'P', FAX: 'F', EMAIL: 'E'},
        officeTypes: {MAIN: 'M', OTHER: 'O'},
        minInputWidth: 150,
        maxDescriptionLength: 300,
        hideContactsSearchBlock: false
    };

    var vocabs = {
        countries: [],
        cities: [],
        contactTypes: []
    };

    var ui = {
        contentBlock: '.content',
        tabs: '#ppTabs',
        infoContainerLeft: '#ppInfoContainer .column-left',
        infoContainerRight: '#ppInfoContainer .column-right',
        imageContainer: '#ppImage',
        logoContainer: '#ppLogo',
        descriptionContainer: '#ppDescription',
        tabsContainer: '#ppTabsContainer',
        tabsTitle: '#ppTabsTitle',
        earnTab: '#ppTabsEarn',
        spendTab: '#ppTabsSpend',
        specialOffersTab: '#ppTabsSpecialOffers',
        contactsTab: '#ppTabsContacts',
        stWidgets: '#ppContactsForm .stwidget',
        countrySelect: '#ppContactsCountry',
        citySelect: '#ppContactsCity',
        formContainer: '#ppContactsForm',
        resultHeader: '#ppResultHeader',
        resultContainer: '#ppResultContainer',
        submitBtn: '#ppContactsSubmit',
        backButton: '#ppBackButton'
    };

    var userInitSearch = false;

    var log = Logger.log;
    var t = Translator.translate;

    function initTabs() {
        var tabAllowed = $.inArray(settings.partner.mile_action,
                                   [settings.mileActions.EARN, settings.mileActions.ALL]) > -1
            && (settings.partner.mile_earn_comment.length > 0 || settings.earnConditions.length > 0);
        buildConditions(ui.earnTab, tabAllowed);
        if (tabAllowed) {
            var $table = ui.earnTab.children('table').first();
            buildEarnTable($table, settings.earnConditions);
            if (settings.partner['mile_earn_comment']) {
                ui.earnTab.children('.earn-tab-comment').first().html(
                        '<p>' + settings.partner['mile_earn_comment'] + '</p>');
            }
        }

        var tabAllowed = $.inArray(settings.partner.mile_action,
                                   [settings.mileActions.SPEND, settings.mileActions.ALL]) > -1
            && (settings.partner.mile_spend_comment.length > 0);
        buildConditions(ui.spendTab, tabAllowed);
        if (tabAllowed) {
            if (settings.partner['mile_spend_comment']) {
                ui.spendTab.children('.spend-tab-comment').first().html(
                        '<p>' + settings.partner['mile_spend_comment'] + '</p>');
            }
        }

        var tabAllowed = (settings.specialOffers.length > 0);
        buildConditions(ui.specialOffersTab, tabAllowed);
        if (tabAllowed) {
            ui.specialOffersTab.children(".specialoffers-tab-title").first().html(
                            '<p>' + settings.partner['special_offers_comment'] + '</p>');

            var html_special_offers = '';

            settings.specialOffers.forEach(function(offer, i, arr) {
                var url = offer.url.trim();

                if (!url.startsWith("http://") && !url.startsWith("https://")) {
                    if (!url.startsWith("/")) url = "/" + url;
                    url = "http://www.aeroflot.ru" + url;
                }
                var desc = offer.description;

                if (desc.length > settings.maxDescriptionLength) {
                    desc = desc.substr(0, settings.maxDescriptionLength) + '&#8230;';
                }
                html_special_offers += '<div>' +
                    '<div class="column-left"><div class="special-offer-tab-image">' +
                        '<img src="' + settings.emptyImage + '" data-src="' + offer.image + '"/></div></div>' +
                    '<div class="column-right"><a href="' + url + '">' + offer.name + '</a>' +
                    '<p>' + desc + '</p></div>' +
                '</div>';
            });
            ui.specialOffersTab.children(".specialoffers-tab-list").first().html(html_special_offers);
        }

        ui.tabs.tabs({
            activate: function(evt, ob) {
                if (ob.newPanel.attr('id') == ui.specialOffersTab.attr('id') && !ob.newPanel.attr('data-tab-loaded')) {
                    ob.newPanel.attr('data-tab-loaded', 1);
                    ob.newPanel.find('.special-offer-tab-image>img').each(function(i, el) {
                        var image = new AdaptiveImage(el, {centerH: true, centerV: true, padding: 0});
                    });
                }

                if (ob.newPanel.attr('id') == ui.contactsTab.attr('id') && !ob.newPanel.attr('data-tab-loaded')) {
                    ob.newPanel.attr('data-tab-loaded', 1);
                    search();
                }
                updateLayout();
            }
        });
        ui.tabsTitle.html(settings.partner.title);

        if (settings.hideContactsSearchBlock) {
            ui.formContainer.addClass('hidden');
        }
    }

    function buildEarnTable(el, earnConditions) {
        var html_head = '';
        var html_body = '';
        if (earnConditions.length > 0) {
            html_head = '<tr><th>' + t('SERVICE_OF_THE_PARTNER') + '</th>' +
                        '<th class="right-top-corner">' + t('MILES') + '</th></tr>';
        };
        el.children("thead").html(html_head);

        earnConditions.forEach(function(c, i, arr) {
            html_body += '<tr><td>' + c.description + '</td><td class="bold-column">' + c.miles + '</td></tr>';
        });
        el.children("tbody").html(html_body);
        niceBlueTable(el);
    }

    function countryOptions() {
        var options = [];

        for (var i = 0; i < vocabs.countries.length; i++) {
            var opt = vocabs.countries[i];
            options.push([opt.code, opt.name]);
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.countryOrdering[a1[0]]) {
                a = Array(settings.countryOrdering[a1[0]]).join(' ');
            }
            if (settings.countryOrdering[b1[0]]) {
                b = Array(settings.countryOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function cityOptions(countryCode) {
        var options = [];

        for (var i = 0; i < vocabs.cities.length; i++) {
            var opt = vocabs.cities[i];
            if (opt.country_code == countryCode) {
                options.push([opt.id, opt.name]);
            }
        }

        options = options.sort(function(a1, b1) {
            var a = ('' + a1[1]).toLowerCase();
            var b = ('' + b1[1]).toLowerCase();
            if (settings.cityOrdering[a1[0]]) {
                a = Array(settings.cityOrdering[a1[0]]).join(' ');
            }
            if (settings.cityOrdering[b1[0]]) {
                b = Array(settings.cityOrdering[b1[0]]).join(' ');
            }
            if (a > b) return 1;
            if (a < b) return -1;
            return 0;
        });

        return options;
    }

    function updateLayout() {
        log('update layout');

        updateAdaptiveWidgets(ui.stWidgets, settings.minInputWidth);
    }

    function buildSelect($el, data, allowEmpty, emptyTitle, defaultVal, initialVal) {
        log('build select', $el.attr('id'));

        $el.chosen({
            width: '100%',
            disable_search: data.length < 20,
            inherit_select_classes: true,
            search_contains: true,
            no_results_text: t('SELECT_NO_RESULTS')
        });
        $('option', $el).remove();

        if (allowEmpty) {
            if (!emptyTitle) emptyTitle = settings.emptyOptionTitle;
            $el.append($('<option value="">' + emptyTitle + '</option>'));
        }

        for (var i = 0; i < data.length; i++) {
            var opt = data[i];
            $el.append($('<option value="' + opt[0] + '">' + opt[1] + '</option>'));
        }

        if (initialVal) {
            $el.val(initialVal);
        } else if (defaultVal) {
            $el.val(defaultVal);
        }

        $el.trigger('chosen:updated');
    }

    function buildInfo(ob) {
        log('build info');

        if (!ob) return;

        var img = ob.image;
        if (!img) img = settings.emptyImage;

        ui.imageContainer.children('img').each(function(i) {
            $(this).attr({"src": settings.emptyImage, "data-src": img, "alt": ob.title});
            var image = new AdaptiveImage($(this), {
                centerH: true,
                centerV: true,
                padding: 0,
                onLoad: function() {
                    ui.infoContainerLeft.addClass('float');
                    ui.infoContainerRight.addClass('float');
                }
            });
        });

        var logo = ob.logo;
        if (!logo) logo = settings.emptyImage;

        ui.logoContainer.children('img').each(function(i) {
            $(this).attr({"src": settings.emptyImage, "data-src": logo, "alt": ob.title});
            var image = new AdaptiveImage($(this), {centerH: false, centerV: true, padding: 0});
        });

        var description_html = '<div>' + ob.description + '</div>';

        if (ob.url.length > 0) {
            ui.logoContainer.wrap('<a target="_blank" aria-label="'+  ob.title +'" href="' + ob.url + '"></a>');
            description_html += '<p class="pl"><a target="_blank" rel="nofollow" href="' + ob.url + '">' + t('GO_TO_PARTNER_SITE') + '</a></p>';
        }

        ui.descriptionContainer.html(description_html);
    }

    function buildConditions($tab, tabAllowed) {
        log('build conditions', $tab.attr('id'), tabAllowed);

        if (tabAllowed) {
            $tab.show();
            $('a[href="#' + $tab.attr('id') + '"]', ui.tabs).parent().show();
        } else {
            $tab.remove();
            $('a[href="#' + $tab.attr('id') + '"]', ui.tabs).parent().remove();
        }
    }

    function buildPaginator(data) {
        data['prevText'] = t('PAGINATOR_PREV_TEXT');
        data['nextText'] = t('PAGINATOR_NEXT_TEXT');

        var paginator = new Paginator(data);
        if (paginator.isEnabled()) {
            return '<div class="pager l-pagination">' + paginator.getHTML() + '</div>';
        }
        return '';
    }

    function getGroupedContacts(data) {
        data.sort(function(a, b) {
            return b.main_contact;
        });

        var grouped = {};
        for (var i = 0; i < data.length; i++) {
            if (!grouped[data[i].contact_type]) {
                grouped[data[i].contact_type] = [];
            }
            grouped[data[i].contact_type].push(data[i]);
        }

        var map = {};
        for (var i = 0; i < vocabs.contactTypes.length; i++) {
            map[vocabs.contactTypes[i][0]] = vocabs.contactTypes[i][1];
        }

        var result = [];
        var types = [settings.contactTypes.PHONE, settings.contactTypes.FAX, settings.contactTypes.EMAIL];
        var classes = {};
        classes[settings.contactTypes.PHONE] = 's_phone';
        classes[settings.contactTypes.FAX] = 's_fax';
        classes[settings.contactTypes.EMAIL] = 's_mail';
        for (var i = 0; i < types.length; i++) {
            if (grouped[types[i]]) {
                result.push({
                    cls: classes[types[i]],
                    name: map[types[i]],
                    items: grouped[types[i]]
                });
            }
        }

        return result;
    }

    function buildResult(data) {
        var mapF = function(elem) {
            if (elem.contact_type == settings.contactTypes.EMAIL) {
                elem.contact = '<a href="mailto:' + elem.contact + '">' + elem.contact + '</a>';
            }
            if (elem.main_contact) {
                elem.contact = '<b>' + elem.contact + '</b>';
            }
            return '<span>' + elem.contact + '</span>';
        };

        data.sort(function(a, b) {
            var co1 = a.country.toLowerCase();
            var co2 = b.country.toLowerCase();
            if (co1 != co2) { // by country
                if (co1 < co2) return -1;
                if (co1 > co2) return 1;
                return 0;
            }

            var ct1 = a.city.toLowerCase();
            var ct2 = b.city.toLowerCase();
            if (ct1 != ct2) { // by city
                if (ct1 < ct2) return -1;
                if (ct1 > ct2) return 1;
                return 0;
            }

            var ot1 = a.office_type;
            var ot2 = b.office_type;
            if (ot1 != ot2) { // by office type
                if (ot1 == settings.officeTypes.MAIN) return -1;
                if (ot2 == settings.officeTypes.MAIN) return 1;
                return 0;
            }

            var ad1 = a.address.toLowerCase();
            var ad2 = b.address.toLowerCase();
            if (ad1 < ad2) return -1;
            if (ad1 > ad2) return 1;
            return 0;
        });

        var html = '';
        for (var i = 0; i < data.length; i++) {
            var groupedContacts = getGroupedContacts(data[i].contacts);
            var contacts = [];
            for (var k = 0; k < groupedContacts.length; k++) {
                contacts.push('<li>' + groupedContacts[k].name + ': ' + $.map(groupedContacts[k].items, mapF).join(', ') + '</li>');
            }
            html +=
                '<div class="pc">' +
                    '<h3>' + data[i].comments + '</h3>' +
                    '<p>' + data[i].address + '</p>' +
                    (contacts.length > 0 ? '<ul>' + contacts.join('') + '</ul>' : '') +
                    (data[i].worktime ? '<p>' + data[i].worktime + '</p>' : '') +
                '</div>';
        }

        return html;
    }

    function checkForm() {
        var errors = [];

        return errors;
    }

    function loadOffices(params) {
        if (params === undefined) {
            params = {
                id: settings.partner.id,
                country: ui.countrySelect.val(),
                city: ui.citySelect.val()
            }
        }

        $.ajax({
            url: settings.searchURL,
            cache: true,
            dataType: 'json',
            type: 'GET',
            data: params,
            beforeSend: function(xhr) {
                showLoader(ui.resultContainer);
            },
            success: function(data) {
                ui.resultContainer.empty();

                var html = '';
                if (data.success) {
                    if (data.data.items && data.data.items.length) {
                        html = buildPaginator(data.data.paginator);
                        html += buildResult(data.data.items);
                    } else {
                        html = '<p>' + t('NO_ITEMS_FOUND') + '</p>';
                    }
                } else {
                    html = '<p>' + data.errors.join('<br />') + '</p>';
                }

                if (userInitSearch) {
                    ui.resultHeader.show();
                }

                ui.resultContainer.append($('<div class="bi">' + html + '</div>'));

                $('.paginator a', ui.resultContainer).each(function(i, el) {
                    $(el).click(function(e) {
                        e.preventDefault();

                        var page = parseInt($(el).attr('data-page'), 10);
                        var _params = $.extend({}, params);
                        if (page) {
                            _params['page'] = page;
                        } else {
                            delete _params['page'];
                        }

                        loadOffices(_params);

                        scrollToBlock(ui.resultHeader.next());
                    });
                });
            },
            complete: function() {
                hideLoader(ui.resultContainer);
            },
            error: function() {
                ui.resultContainer.empty();
                ui.resultContainer.append($('<div class="bi">' + t('DATA_LOAD_ERROR') + '</div>'));
            }
        });
    }

    function search() {
        settings.hideContactsSearchBlock
            ? loadOffices()
            : ui.submitBtn.trigger('click', true);
    }

    function init() {
        log('init');

        var initialParams = parseURLParams();

        buildInfo(settings.partner);

        setupBackButton(ui.backButton, function(href) {
            return href + '#!' + buildHashString(prepareHashParams(initialParams));
        });

        initTabs();

        buildSelect(ui.countrySelect, countryOptions(), true, t('SELECT_COUNTRY'),
                    settings.defaultCountry, '');

        ui.countrySelect.bind('change', function(evt) {
            var $target = $(evt.target);

            log('evt change', $target.attr('id'));

            if (!$target.val()) {
                buildSelect(ui.citySelect, [], true, t('SELECT_CITY'), '', '');
                ui.citySelect.prop('disabled', true).trigger('chosen:updated');
            } else {
                buildSelect(ui.citySelect, cityOptions($target.val()), true,
                            t('SELECT_CITY'), '', initialParams['city']);
                ui.citySelect.prop('disabled', false).trigger('chosen:updated');
            };
        });
        ui.countrySelect.trigger('change');

        if (!settings.hideContactsSearchBlock) {
            ui.submitBtn.bind('click', function (evt, customEvent) {
                var $target = $(evt.target);

                log('evt click', $target.attr('id'));

                var errors = checkForm();
                clearErrors(ui.formContainer)
                if (errors.length) {
                    showErrors(errors);
                    return;
                }

                if (!customEvent) {
                    userInitSearch = true;
                }

                loadOffices();
            });
        }

        updateLayout();
        $(window).resize(updateLayout);
    }

    module.init = function(_settings, _translations, _vocabs) {
        if (typeof Array.prototype.forEach != 'function') {
            Array.prototype.forEach = function(callback){
                for (var i = 0; i < this.length; i++){
                    callback.apply(this, [this[i], i, this]);
                }
            };
        };

        if(typeof(String.prototype.trim) === "undefined") {
            String.prototype.trim = function() {
                return String(this).replace(/^\s+|\s+$/g, '');
            };
        }

        if (typeof String.prototype.startsWith != 'function') {
            String.prototype.startsWith = function (str) {
                return this.slice(0, str.length) == str;
            };
        }

        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    };

    return module;
}(jQuery, Logger, Translator));


/* Airline List */
var AirlineList = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        bannerURL: '',
        bannerParams: {},
        userInfo: {},
        debug: 1
    };

    var vocabs = {};

    var ui = {
        adaptiveImages: '.airlineContainer .ai',
        rightBlock: '.block-right'
    };

    var log = Logger.log;
    var t = Translator.translate;

    function initAdaptiveImages() {
        $(ui.adaptiveImages).each(function() {
            var alt = $(this).attr('alt');
            if (alt.length > 30) {
                alt = alt.substr(0, 30) + '...';
                $(this).attr({"alt": alt});
            }

            var image = new AdaptiveImage(this, {centerH: true, centerV: true, show_on_error: true});
        });
    }

    function init() {
        log('init');

        initAdaptiveImages();

        loadBanners(ui.rightBlock, settings.bannerUrl, settings.bannerParams, settings.userInfo);
    }

    module.init = function(_settings, _translations, _vocabs) {
        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    };

    return module;
}(jQuery, Logger, Translator));


/* Airline Page */
var AirlinePage = (function($, Logger, Translator) {
    var module = {};

    var settings = {
        debug: 1,
        airline: {},
        parent: {},
        children: [],
        emptyImage: 'empty.gif',
        milesTable: [],
        oldMilesTable: [],
        isNewMiliesTable: false,
        bookingClassComments: [],
        eliteCoefficients: []
    };

    var ui = {
        rightBlock: '.block-right',
        contentBlock: '.content',

        // Reuse Partner style
        tabsContainer: '#ppTabsContainer',
        tabsTitle: '#ppTabsTitle',
        tabs: '#ppTabs',

        imageContainer: '#apImage',
        descriptionContainer: '#apAirlineDescription',
        descriptionTitle: '#apDescriptionTitle',
        relatives: '#apRelatives',
        awardsCalculatorButton: '#apAwardsCalculatorButton',
        earnTab: '#apTabsEarn',
        airlineSite: '#apAirlineSite',
        milesTitle: '#apMilesTitle',
        milesEarnDescription: '#apMilesEarnDescription',
        milesComment: '#apMilesComment',
        milesLimitation: '#apMilesLimitation',
        milesTable: '#apMilesTable',
        milesTableOld: '#apMilesTableOld',
        eliteCoefficients: '#apEliteCoefficients',
        bookingClassesWithoutBonus: '#apBookingClassesWithoutBonus',
        bookingClassesWithoutBonusOld: '#apBookingClassesWithoutBonusOld',
        bookingClassComments: '#apBookingClassComments',
        backButton: '#apBackButton'
    };

    var log = Logger.log;
    var t = Translator.translate;

    function initTabs(ob) {
        ui.tabs.tabs();
        if (ob.url.length > 0) {
            ui.airlineSite.html('<a target="_blank" href="' + ob.full_url +'"  rel="nofollow">' + ob.url + '</a>');
        }
        ui.tabsTitle.html(settings.airline.title);
    }

    function buildInfo(ob) {
        log('build info');

        if (!ob) return;

        var img = ob.image;
        if (!img) img = settings.emptyImage;

        ui.imageContainer.children('img').each(function(i) {
            $(this).attr({"src": settings.emptyImage, "data-src": img, "alt": ob.title});
            var image = new AdaptiveImage($(this), {centerH: true, centerV: true});
        });

        ui.descriptionTitle.html(t('AIRLINE_INFORMATION'));
    }

    function _airline2li(airline) {
        var title = airline.title;
        if (airline.link) {
            title = '<a href="' + airline.link + '">' + title + '</a>';
        }
        return '<li>' + title + ' (' + airline.flight_code + ')</li>';
    }

    function buildRelatives(par, children) {
        log('parent and children info');

        var html = '';
        if (par !== null) {
            html = '<div class="list-header">' + t('PARENT_AIRLINE') + ':</div>';
            html += '<ul>' + _airline2li(par) + '</ul>';
        }

        if (children.length > 0) {
            html += '<div class="list-header">' + t('CHILDREN_AIRLINES') + ':</div>';
            html += '<ul>';
            children.forEach(function(item, i, arr) {
                html += _airline2li(item);
            });
            html += '</ul>';
        }

        ui.relatives.html(html);
    }

    function buildMileEarningComments(mileEarningComments) {
        ui.milesTitle.html('<p>' + t('MILES_DEPEND') + '</p>');
        ui.milesEarnDescription.html('<p>' + mileEarningComments.miles_earn_description + '</p>');
        ui.milesComment.html('<p>' + t('MILES_ARE_QUALIFYING') + '</p>');
        ui.milesLimitation.html('<p>' + mileEarningComments.miles_limitation_verbose.replace(/#/g, mileEarningComments.miles_minimum) + '</p>');
        ui.bookingClassesWithoutBonus.html('<p>' + mileEarningComments.miles_earn_comment + '</p>');
    }

    function buildMilesTableWithTariffCode(milesTable) {
        log('new miles table');
        var html_head = '';
        var html_body = '';
        var cl_html = '';
        if (milesTable.length > 0) {
            var help_link = '<a href="#" class="icon-button i-question unselect" role="button" unselectable="on" id="pass_rules" data-content="'+t('INFO_BOOKING_CLASS')+'" data-title=""></a>'
            html_head = '<tr><th></th><th>' + t('PREFIX_CODE_TARIFF') + '&nbsp' + help_link + '</th><th>' + t('TOTAL_MILES_IN') + '&nbsp;%</th></tr>';
        }
        milesTable.forEach(function(cl, i, arr) {
            cl_html += '<tr class="no-border sub_title"><td colspan="3">'+cl[0]+'</td></tr>';
            var tf_html = '';
            cl[1].forEach(function(tf, i, arr) {
                var bcl_html = '';
                if (tf_html) {
                    tf_html += '</tr><tr class="no-border">';
                }
                var clname = tf[0];
                var link_to_fare = '<a href="' + settings.url_to_new_fares + '" target="_blank">' + clname + '</a>';
                var booking_class_list = [];
                tf[1].forEach(function(bcl, j, arr) {
                    if (bcl_html) {
                        bcl_html += '</tr><tr class="no-border">';
                    }
                    var booking_class_list = [];
                    bcl[0].forEach(function(bcl, k, arr) {
                        var bcl_str = bcl.code.toString();

                        if (bcl.note) {
                            bcl_str += '<sup>' + bcl.note + '</sup>';
                        }
                        booking_class_list.push(bcl_str);
                    });

                    bcl_html += '<td>' + (j === 0 ? link_to_fare : '') + '</td>' +
                        '<td>' + booking_class_list.join(", ") + '</td>' +
                        '<td class="bold-column">' + bcl[1] + '%</td>';
                });

                tf_html += '<tr>' + bcl_html + '</tr>';
            });
            cl_html += '<tr>' + tf_html + '</tr>';
        });
        html_body += cl_html;
        ui.milesTable.children('thead').html(html_head);
        ui.milesTable.children('tbody').html(html_body);
        niceBlueTable(ui.milesTable);
        ui.milesTable.addClass('airlineTable fixedWidthTable');
        ui.bookingClassesWithoutBonusOld.html('<p>' + settings.bookingClassesWithoutBonusOld + '</p>');
    }

    function buildMilesTable(milesTable, idMilesTable) {
        log('miles table');

        var html_head = '';
        var html_body = '';

        if (milesTable.length > 0) {
            html_head = '<tr><th>' + t('SERVICE_CLASS') + '</th><th>' + t('BOOKING_CLASS')
                    + '</th><th>' + t('TOTAL_MILES_IN') + ' %</th></tr>';
        }

        milesTable.forEach(function(cl, i, arr) {
            var clname = cl[0];
            var booking_classes = cl[1];

            var bcl_html = '';

            booking_classes.forEach(function(bcl, j, arr) {
                if (bcl_html) {
                    bcl_html += '</tr><tr class="no-border">';
                }
                var booking_class_list = [];
                bcl[0].forEach(function(bcl, k, arr) {
                    var bcl_str = bcl.code.toString();

                    if (bcl.note) {
                        bcl_str += '<sup>' + bcl.note + '</sup>';
                    }
                    booking_class_list.push(bcl_str);
                });

                bcl_html += '<td>' + (j === 0 ? clname : '') + '</td>' +
                    '<td>' + booking_class_list.join(", ") + '</td>' +
                    '<td class="bold-column">' + bcl[1] + '%</td>';
            });

            html_body += '<tr>' + bcl_html + '</tr>';
        });

        idMilesTable.children('thead').html(html_head);
        idMilesTable.children('tbody').html(html_body);
        niceBlueTable(idMilesTable);
        idMilesTable.addClass('airlineTable fixedWidthTable');
    }

    function buildBookingClassComments(bookingClassComments) {
        var html = '';

        bookingClassComments.forEach(function(item, i, arr) {
            html += '<li><sup>' + item[0] + '</sup></span>' + item[1] + '</li>';
        });

        ui.bookingClassComments.html('<ul>' + html + '</ul>');
    }

    function buildEliteCoefficients(eliteCoefficients) {
        var list_html = '';

        var levels = {platinum: t('TO_PLATINUM_PARTICIPANTS'),
                      gold: t('TO_GOLD_PARTICIPANTS'),
                      silver: t('TO_SILVER_PARTICIPANTS')}

        log('elite coefficients');
        if (eliteCoefficients.length == 0)
            return;

        var html = '<p>' + t('ADDITIONAL_ELITE_MILES') + ':</p>';

        eliteCoefficients.forEach(function(record, i, arr) {
            var coefficient = record[1];

            if (coefficient > 0) {
                var title = levels[record[0]];
                list_html += '<li>+' + coefficient + '% ' + t('FROM_DISTANCE') + '&nbsp;&ndash;&nbsp;' + title + '</li>';
            }
        });

        html += '<ul>' + list_html + '</ul>';

        html += '<p>' + t('ELITE_MILES_AINT_QUALIFYING') + '</p>';
        ui.eliteCoefficients.html(html);
    }

    function adjustInfoBlockHeights($b1, $b2) {
        var h1 = $b1.height();
        var h2 = $b2.height();

        var diff = h1 - h2;
        if (diff < 0) diff = 0;
        ui.descriptionContainer.css('padding-top', diff)
    }

    function updateLayout() {
        log('update layout');

        adjustInfoBlockHeights(ui.imageContainer, ui.descriptionContainer);
    }

    function initCalculatorButton($btn, airline) {
        var link_components = $btn.attr("data-href").split("?", 2);
        var link_params = link_components.pop();

        if (link_params) {
            link_params += "&";
        }
        link_params += "airline=" + airline.ikm_code;
        link_components.push(link_params);
        $btn.attr("data-href", link_components.join("?"));
        setupLinkButton(ui.awardsCalculatorButton);
    }
    function init() {
        log('init');

        var initialParams = parseURLParams();

        buildInfo(settings.airline);
        buildRelatives(settings.parent, settings.children);
        if (settings.isNewMiliesTable) {
            buildMilesTableWithTariffCode(settings.milesTable);
            $('[data-content]').popover({trigger: 'hover, focus'});
            buildMilesTable(settings.milesTableOld, ui.milesTableOld);
        } else {
            buildMilesTable(settings.milesTable, ui.milesTable);
            if (settings.milesTableOld.length > 0) {
                buildMilesTable(settings.milesTableOld, ui.milesTableOld);
            }
        }

        buildBookingClassComments(settings.bookingClassComments);
        buildEliteCoefficients(settings.eliteCoefficients);
        buildMileEarningComments(settings.mileEarningComments);
        initCalculatorButton(ui.awardsCalculatorButton, settings.airline);
        //ui.awardsCalculatorButton.remove();
        setupBackButton(ui.backButton);

        initTabs(settings.airline);
        loadBanners(ui.rightBlock, settings.bannerUrl, settings.bannerParams, settings.userInfo);

        updateLayout();
        $(window).resize(updateLayout);
        $('.toggle_apMilesTable').click(function(evt){
            $(this).parent().find('.toggleBlock').toggle();
        });
    };

    module.init = function(_settings, _translations, _vocabs) {

        if (typeof Array.prototype.forEach != 'function') {
            Array.prototype.forEach = function(callback){
                for (var i = 0; i < this.length; i++){
                    callback.apply(this, [this[i], i, this]);
                }
            };
        };

        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _vocabs) {
            vocabs[pr] = _vocabs[pr];
        }

        for (var pr in ui) {
            ui[pr] = $(ui[pr]);
        }

        Logger.init(settings);
        Translator.init(_translations);

        init();
    };

    return module;
}(jQuery, Logger, Translator));
