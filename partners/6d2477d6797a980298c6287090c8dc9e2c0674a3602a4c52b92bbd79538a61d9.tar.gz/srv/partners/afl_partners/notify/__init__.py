# -*- coding: UTF-8 -*-

import cherrypy
import json
import logging
import transaction

from zope.schema.interfaces import ITokenizedTerm

from pyramid.ui.page import CPJSONService
from pyramid.ormlite.dbop import selectFrom
from pyramid.vocabulary import getV, getVI

import rx.pbus.vocabulary

import config
import decode
from models.base import WSVocabularyBase


OBJECT_DECODERS = {
    'Airline': decode.decode_airline,
    'Country': decode.decode_country,
    'City': decode.decode_city,
    'Airport': decode.decode_airport,
    'Pair': decode.decode_pair,
    'PartnerCategory': decode.decode_partner_category,
    'Partner': decode.decode_partner,
    'PartnerOffice': decode.decode_partner_office,
    'PartnerOfficeContact': decode.decode_partner_office_contact,
    'PartnerAwardCondition': decode.decode_partner_award_condition,
    'ServiceClassesLimit': decode.decode_service_classes_limit,
    'SkyTeamServiceClass': decode.decode_skyteam_service_class,
    'AirlineServiceClass': decode.decode_airline_service_class,
    'TierLevel': decode.decode_tier_level,
    'TierLevelFactor': decode.decode_tier_level_factor,
    'TariffGroup': decode.decode_tariff_group,
    'AirlineTariffGroup': decode.decode_airline_tariff_group,
    'BookingClass': decode.decode_booking_class,
    'RedemptionZone': decode.decode_redemption_zone,
    'BonusRoute': decode.decode_bonus_route,
    'Award': decode.decode_award,
    'WrongRoute': decode.decode_wrong_route,
    'SpecialOffer': decode.decode_special_offer,
}

CONTAINERS = {
    'Airline': ('airlines', 'airlines'),
    'Country': ('countries', 'countries'),
    'City': ('cities', 'cities'),
    'Airport': ('airports', 'airports'),
    'Pair': ('pairs', 'pairs'),
    'PartnerCategory': ('partner_categories', 'partner_categories'),
    'Partner': ('partners', 'partners'),
    'PartnerOffice': ('partner_offices', 'partner_offices'),
    'PartnerOfficeContact': ('partner_office_contacts', 'partner_office_contacts'),
    'PartnerAwardCondition': ('partner_award_conditions', 'partner_award_conditions'),
    'ServiceClassesLimit': ('service_classes_limits', 'service_classes_limits'),
    'SkyTeamServiceClass': ('skyteam_service_classes', 'skyteam_service_classes'),
    'AirlineServiceClass': ('airline_service_classes', 'airline_service_classes'),
    'TierLevel': ('tier_levels', 'tier_levels'),
    'TierLevelFactor': ('tier_level_factors', 'tier_level_factors'),
    'TariffGroup': ('tariff_groups', 'tariff_groups'),
    'AirlineTariffGroup': ('airline_tariff_groups', 'airline_tariff_groups'),
    'BookingClass': ('booking_classes', 'booking_classes'),
    'RedemptionZone': ('redemption_zones', 'redemption_zones'),
    'BonusRoute': ('bonus_routes', 'bonus_routes'),
    'Award': ('awards', 'awards'),
    'WrongRoute': ('wrong_routes', 'wrong_routes'),
    'SpecialOffer': ('special_offers', 'special_offers'),
}


class NotifyService(CPJSONService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('notify_vocabs', '/notify/%s' % config.PBUS_TOPICS['vocabs'], controller=self, action='index')

    def index(self, **params):
        body = cherrypy.request.body.read()
        msg_json = json.loads(body, encoding='utf-8')
        self.process(msg_json)
        return ''

    def process(self, msg_json):
        if isinstance(msg_json, list):
            pass
        elif isinstance(msg_json, dict) and 'event' in msg_json:  # ответ на запрос (например, command get_all)
            msg_json = [msg_json, ]
        else:
            return

        changes = {}
        for event in rx.pbus.vocabulary.VocabularyEvent.from_json(msg_json):

            for cls_name, objects in event.decode(OBJECT_DECODERS):
                vocab_name, table_name = CONTAINERS[cls_name]
                vocab = getV(vocab_name)
                ob_cls = vocab.objectC

                ext_ids = []
                ext_tokens = []
                if 'vocab_id' in ob_cls.p_fields:
                    ext_ids = [ob.vocab_id for ob in objects]
                    ext_tokens = [
                        ITokenizedTerm(ob).token for ob in ob_cls.bulkLoadList(
                            selectFrom(table_name, {'vocab_id': ext_ids}))]

                if event.type == 'change':
                    # пропускаем изменение ключей, кроме случаев,
                    # когда объект содержит vocab_id присутствующий
                    # в измененых объектах
                    for i, ob in enumerate(objects):
                        if ITokenizedTerm(ob).token not in vocab and \
                                getattr(ob, 'vocab_id', None) not in ext_ids:
                            objects.pop(i)

                seen = set(ITokenizedTerm(ob).token for ob in objects)

                if isinstance(vocab, WSVocabularyBase):
                    vocab_changes = event.update_mvcc(
                        objects, vocab, table_name)

                else:
                    vocab_changes = event.update_vocabulary(objects, vocab)
                    for ob in objects:
                        ob.save()

                logging.debug('notify updating vocab %s - %s record(s)' % (
                    vocab_name, len(vocab_changes)))

                # удаляем объекты, имеющие vocab_id и получившие изменение ключа
                # (вместо них были созданы новые объекты)
                for t in ext_tokens:
                    if t not in seen and t in vocab:
                        vocab[t].delete()
                        del vocab[t]

                changes[cls_name] = vocab_changes

        if 'PartnerOffice' in changes:
            contacts = []
            for ob in getV('partner_offices'):
                contacts.extend(ob.contacts)
            getV('partner_office_contacts').rebuild(contacts)

        def update_indexers(success):
            if success:
                INDEXERS = (
                    (('City',), ('cities_by_iata_idx',)),
                    (('Airport',), ('airports_by_iata_idx',)),
                    (('City', 'Airport'), ('airports_by_city_idx',)),
                    (('AirlineServiceClass', 'Airline'), ('airline_service_classes_by_airline_idx',)),
                    (('ServiceClassesLimit', 'AirlineServiceClass'), ('service_classes_limits_by_airline_service_class_idx',)),
                    (('ServiceClassesLimit', 'Airline'), ('service_classes_limits_by_airline_idx',)),
                    (('TariffGroup', 'BookingClass', 'AirlineServiceClass', 'AirlineTariffGroup'), ('booking_classes_by_airline_tariff_group_idx',)),
                    (('AirlineTariffGroup', 'AirlineServiceClass'), ('airline_tariff_groups_by_airline_service_class_idx',)),
                    (('TierLevelFactor', 'Airline'), ('tier_level_factors_by_airline_idx',)),
                    (('Pair', 'Airline', 'Airport'), ('pairs_by_ctx_idx', 'all_pairs_by_ctx_idx')),
                    (('BonusRoute',), ('bonus_routes_by_ctx_idx',)),
                    (('Award', 'BonusRoute'), ('awards_by_bonus_route_idx',)),
                    (('WrongRoute',), ('wrong_routes_by_ctx_idx',)),
                    (('SpecialOffer', 'Partner'), ('special_offers_by_partner_idx',)),
                    (('PartnerAwardCondition', 'Partner'), ('partner_awards_conditions_by_partner_idx',)),
                )

                for c_list, i_list in INDEXERS:
                    if any([c in changes for c in c_list]):
                        for i in i_list:
                            getVI(i)._reindex()
                            logging.debug('notify updating indexer "%s"' % i)

        current = transaction.get()
        current.addAfterCommitHook(update_indexers)


