# -*- coding: utf-8 -*-

"""
$Id: $
"""
from datetime import datetime

from models.air import Airline
from models.award import RedemptionZone, BonusRoute, Award, WrongRoute
from models.geo import City,  Country, Airport
from models.partner import (PartnerCategory, Partner, PartnerOfficeContact,
                            PartnerOffice, PartnerAwardCondition)
from models.route import Pair
from models.bonus import (AirlineServiceClass, SkyTeamServiceClass,
                          ServiceClassesLimit, TierLevel, TierLevelFactor)
from models.bonus import (TariffGroup, AirlineTariffGroup, BookingClass)
from models.special_offer import SpecialOffer


def decode_airline(json_ob):
    # в afl_vocabs тип поля - Choice(required=False)
    # у нас - Int(required=False)
    try:
        parent_airline_id = int(json_ob['parent_airline'])
    except TypeError:
        parent_airline_id = None

    try:
        airport_id = int(json_ob['airport'])
    except TypeError:
        airport_id = None

    return Airline(airline_id=json_ob['airline_id'],
                   iata=json_ob.get('iata'),
                   icao=json_ob.get('icao'),
                   callsign=json_ob.get('callsign'),
                   country=json_ob.get('country'),
                   airport_id=airport_id,
                   alliance=json_ob.get('alliance'),
                   names=json_ob['names'],
                   parent_airline_id=parent_airline_id,
                   url=json_ob.get('url'),
                   weight=json_ob['weight'],
                   miles_minimum=json_ob['miles_minimum'],
                   miles_limitation=json_ob['miles_limitation'],
                   miles_earn_description=json_ob['miles_earn_description'],
                   miles_earn_comment=json_ob['miles_earn_comment']
                   )


def decode_country(json_ob):
    if json_ob['iso_code2']:
        return Country(country=json_ob['iso_code2'],
                       iso_code3=json_ob['iso_code3'],
                       names=json_ob['names'])


def decode_city(json_ob):
    return City(city_id=json_ob['city_id'],
                country_code=json_ob['country_code'],
                tz=json_ob['tz'],
                iata=json_ob.get('iata'),
                lat=json_ob.get('lat'),
                lon=json_ob.get('lon'),
                names=json_ob['names'])


def decode_airport(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    city_id = int(json_ob['city'])

    return Airport(airport_id=json_ob['airport_id'],
                   city_id=city_id,
                   iata=json_ob['iata'],
                   icao=json_ob['icao'],
                   names=json_ob['names'],
                   afl_redemption_zone=json_ob['afl_redemption_zone'],
                   skyteam_redemption_zone=json_ob['skyteam_redemption_zone'],
                   lat=json_ob['lat'],
                   lon=json_ob['lon'],
                   has_upgrade_on_checkin_award=json_ob['has_upgrade_on_checkin_award'])


def decode_pair(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    airline_id = int(json_ob['airline'])
    airport_from_id = int(json_ob['airport_from'])
    airport_to_id = int(json_ob['airport_to'])

    return Pair(pair_id=json_ob['pair_id'],
                airport_from_id=airport_from_id,
                airport_to_id=airport_to_id,
                airline_id=airline_id,
                miles=json_ob['miles'],
                no_spending=json_ob['no_spending'])


def decode_skyteam_service_class(json_ob):
    return SkyTeamServiceClass(skyteam_sc_id=json_ob['skyteam_sc_id'],
                               code=json_ob['code'],
                               names=json_ob['names'],
                               weight=json_ob['weight'])


def decode_airline_service_class(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    airline_id = int(json_ob['airline'])
    skyteam_sc_id = int(json_ob['skyteam_sc'])

    return AirlineServiceClass(airline_sc_id=json_ob['airline_sc_id'],
                               airline_id=airline_id,
                               skyteam_sc_id=skyteam_sc_id)


def decode_service_classes_limit(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    airline_sc_id = int(json_ob['airline_sc'])
    pair_id = int(json_ob['pair'])

    return ServiceClassesLimit(service_classes_limit_id=json_ob['service_classes_limit_id'],
                               airline_sc_id=airline_sc_id,
                               pair_id=pair_id)


def decode_tier_level(json_ob):
    return TierLevel(tier_level=json_ob['tier_level'],
                     names=json_ob['names'],
                     miles=json_ob['miles'],
                     ordering=json_ob.setdefault('ordering', 0),
                     segments=json_ob['segments'])


def decode_tier_level_factor(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    airline_id = int(json_ob['airline'])

    return TierLevelFactor(tier_level_factor_id=json_ob['tier_level_factor_id'],
                           airline_id=airline_id,
                           tier_level=json_ob['tier_level'],
                           factor=json_ob['factor'])


def decode_redemption_zone(json_ob):
    return RedemptionZone(redemption_zone=json_ob['redemption_zone'],
                          names=json_ob['names'])


def decode_bonus_route(json_ob):
    return BonusRoute(bonus_route_id=json_ob['bonus_route_id'],
                      code=json_ob['code'],
                      zone_from=json_ob['zone_from'],
                      zone_via=json_ob['zone_via'],
                      zone_to=json_ob['zone_to'],
                      carrier=json_ob['carrier'])


def decode_award(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    skyteam_service_class_id_1 = int(json_ob['service_classes_1'])
    bonus_route_id =  int(json_ob['route'])

    # в afl_vocabs тип поля - Choice(required=False)
    # у нас - Int(required=False)
    try:
        skyteam_service_class_id_2 = int(json_ob['service_classes_2'])
    except TypeError:
        skyteam_service_class_id_2 = None

    return Award(award_id=json_ob['award_id'],
                 award_type=json_ob['type'],
                 skyteam_service_class_id_1=skyteam_service_class_id_1,
                 skyteam_service_class_id_2=skyteam_service_class_id_2,
                 award_value=json_ob['award_value'],
                 bonus_route_id=bonus_route_id)


def decode_wrong_route(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    city_from_id = int(json_ob['city_from'])
    city_via_id = int(json_ob['city_via'])
    city_to_id = int(json_ob['city_to'])

    return WrongRoute(wrong_route_id=json_ob['wrong_route_id'],
                      city_from_id=city_from_id,
                      city_via_id=city_via_id,
                      city_to_id=city_to_id)


def decode_partner_category(json_ob):
    return PartnerCategory(partner_category_id=json_ob['partner_category_id'],
                           names=json_ob['names'],
                           status=json_ob['status'])


def decode_partner(json_ob):
    partner_categories = json_ob['partner_categories']
    partner_categories = [str(category['partner_category_id']) for category in partner_categories]\
                         if partner_categories else None
    try:
        new_until = datetime.strptime(json_ob['new_until'], "%Y-%m-%d").date()
    except (TypeError, ValueError):
        new_until = None

    return Partner(partner_id=json_ob['partner_id'],
                   names=json_ob['names'],
                   partner_description=json_ob['partner_description'],
                   url=json_ob['url'],
                   partner_categories=partner_categories,
                   status=json_ob['status'],
                   mile_action=json_ob['mile_action'],
                   mile_get_comm=json_ob['mile_get_comm'],
                   mile_waste_comm=json_ob['mile_waste_comm'],
                   short_descr=json_ob['short_descr'],
                   spec_offer_comm=json_ob['spec_offer_comm'],
                   weight=json_ob['weight'], new_until=new_until)


def decode_partner_office_contact(json_ob):
    return PartnerOfficeContact(partner_office_contact_id=json_ob['partner_office_contact_id'],
                                partner_office=json_ob['partner_office'],
                                contact_type=json_ob['contact_type'],
                                contact=json_ob['contact'],
                                main_contact=json_ob['main_contact'])


def decode_partner_office(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    partner = int(json_ob['partner'])

    # в afl_vocabs тип поля - Choice(required=False)
    # у нас - Int(required=False)
    try:
        city = int(json_ob['city'])
    except TypeError:
        city = None

    ob = PartnerOffice(partner_office_id=json_ob['partner_office_id'],
                         partner=partner,
                         city=city,
                         lat=json_ob['lat'],
                         lon=json_ob['lon'],
                         comments=json_ob['comments'],
                         address=json_ob['address'],
                         worktime=json_ob['worktime'],
                         office_type=json_ob['office_type'])

    ob.contacts = [PartnerOfficeContact(partner_office_contact_id=c['partner_office_contact_id'],
                                        contact_type=c['contact_type'],
                                        contact=c['contact'],
                                        main_contact=c['main_contact'])
                   for c in json_ob['contacts']]

    return ob


def decode_partner_award_condition(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    partner = int(json_ob['partner'])

    return PartnerAwardCondition(partner_award_condition_id=json_ob['partner_award_condition_id'],
                                 partner=partner,
                                 award_condition_type=json_ob['award_condition_type'],
                                 award_condition_description=json_ob['award_condition_description'],
                                 weight=json_ob['weight'],
                                 status=json_ob['status'],
                                 miles=json_ob['miles'])


def decode_tariff_group(json_ob):
    return TariffGroup(
        tariff_group_id=json_ob["id_field"],
        skyteam_sc_id=int(json_ob["service_class"]),
        code=json_ob["tariff_group"],
        names=json_ob["names"],
        weight=json_ob["weight"]
    )

def decode_airline_tariff_group(json_ob):
    return AirlineTariffGroup(
        airline_tariff_group_id=json_ob["idField"],
        tariff_group_id=int(json_ob["tariffGroup"]),
        airline_sc_id=int(json_ob["serviceClass"]),
        charge_coef=json_ob["chargeCoef"],
        weight=json_ob["weight"],
        fareCode=json_ob["fareCode"]
    )

def decode_booking_class(json_ob):
    return BookingClass(
        booking_class_id=json_ob["idField"],
        code=json_ob["bcCode"],
        miles_are_charged=json_ob["milesAreCharged"],
        text_comment=json_ob["comment"],
        airline_tariff_group_id=int(json_ob["alTariffGroup"])
    )


def decode_special_offer(json_ob):
    begin_date = json_ob.get('begin_date')
    if not isinstance(begin_date, datetime):
        try:
            begin_date = datetime.strptime(begin_date, "%d.%m.%Y %H:%M:%S")
        except (TypeError, ValueError):
            begin_date = ''

    end_date = json_ob.get('end_date')
    if not isinstance(end_date, datetime):
        try:
            end_date = datetime.strptime(end_date, "%d.%m.%Y %H:%M:%S")
        except (TypeError, ValueError):
            end_date = ''

    return SpecialOffer(
        offer_id=json_ob['offer_id'],
        partner=int(json_ob['partner']),
        names=json_ob['names'],
        begin_date=begin_date,
        end_date=end_date,
        status=json_ob['status'],
        offer_description=json_ob['offer_description'],
        offer_url=json_ob['offer_url'],
        ui_languages=json_ob.get('ui_languages')
    )
