# -*- coding: utf-8 -*-

"""
$Id: log.py 22527 2017-01-18 15:11:43Z isoloduha $
"""

import cherrypy
import copy
import datetime
import logging
import rfc822
import time

from cherrypy import _cplogging, _cperror
from logging.handlers import TimedRotatingFileHandler
from mailinglogger.MailingLogger import MailingLogger

import config


class UserFormatter(logging.Formatter):
    """ Добавляем user_id и IP-адрес в логи
    """
    def format(self, record):
        try:
            ip = cherrypy.request.remote.ip
        except:
            ip = '-'

        new_record = copy.copy(record)
        new_record.msg = '-@%s %s' % (ip, record.msg)
        return logging.Formatter.format(self, new_record)


class AppLogging(object):
    action_logger = None
    notification_logger = None

    formatter = UserFormatter('[%(asctime)s] %(message)s',
                              datefmt='%d/%b/%Y:%H:%M:%S')

    def __init__(self):
        self.action_logger = self._init_logger('action')
        self.notification_logger = self._init_notification_logger('missing_data')

    def _init_logger(self, name, backupCount=90):
        logger = logging.getLogger(name)
        logger.setLevel(config.LOG_LEVEL)
        filename = '%s/%s.log' % (config.LOGDIR, name)
        # Ротация лога раз в сутки
        handler = TimedRotatingFileHandler(filename, when='MIDNIGHT', interval=1, backupCount=backupCount)
        handler.setFormatter(self.formatter)
        logger.addHandler(handler)
        return logger

    def _init_notification_logger(self, name):
        # Logger for missing data for airport (cities, countries, etc.)

        notification = logging.getLogger(name)
        handler = MailingLogger(config.SMTP_FROM,
                                tuple(config.ADMIN_EMAIL),
                                mailhost=(config.SMTP_SERVER, config.SMTP_PORT, ),
                                flood_level=1)
        notification.setLevel(config.LOG_LEVEL)

        fh = logging.FileHandler('%s/%s.log' % (config.LOGDIR, name))
        fh.setFormatter(self.formatter)
        fh.setLevel(config.LOG_LEVEL)

        notification.addHandler(handler)
        notification.addHandler(fh)
        return notification

log = AppLogging()

# Специализированный и сокращенный вариант LogManager. См. cherrypy._cplogging
# Записывает в access.log время выполнения запроса.
class CustomLogManager(object):
    access_log_format = \
        '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" %(e)s'

    def __init__(self, logger_root="cherrypy"):
        self.logger_root = logger_root
        self.error_log = logging.getLogger("%s.error" % logger_root)
        self.access_log = logging.getLogger("%s.access" % logger_root)
        self.error_log.setLevel(logging.DEBUG)
        self.access_log.setLevel(logging.INFO)

    def error(self, msg='', context='', severity=logging.INFO, traceback=False):
        """Write to the error log.
        
        This is not just for errors! Applications may call this at any time
        to log application-specific information.
        """
        if traceback:
            msg += _cperror.format_exc()
        self.error_log.log(severity, ' '.join((self.time(), context, msg)))
    
    def __call__(self, *args, **kwargs):
        """Write to the error log.
        
        This is not just for errors! Applications may call this at any time
        to log application-specific information.
        """
        return self.error(*args, **kwargs)
    
    def access(self):
        """Write to the access log (in Apache/NCSA Combined Log format).
        
        Like Apache started doing in 2.0.46, non-printable and other special
        characters in %r (and we expand that to all parts) are escaped using
        \\xhh sequences, where hh stands for the hexadecimal representation
        of the raw byte. Exceptions from this rule are " and \\, which are
        escaped by prepending a backslash, and all whitespace characters,
        which are written in their C-style notation (\\n, \\t, etc).
        """
        request = cherrypy.request
        remote = request.remote
        response = cherrypy.response
        outheaders = response.headers
        inheaders = request.headers
        try:
            #print time.time(), cherrypy.request.start_time
            elapsed = '%.3f' % (time.time() - cherrypy.request.start_time)
        except AttributeError:
            elapsed = '-'
        
        atoms = {'h': remote.name or remote.ip,
                 'l': '-',
                 'u': getattr(request, 'login', None) or '-',
                 't': self.time(),
                 'r': request.request_line,
                 's': response.status.split(" ", 1)[0],
                 'b': outheaders.get('Content-Length', '') or '-',
                 'f': inheaders.get('Referer', ''),
                 'a': inheaders.get('User-Agent', ''),
                 'e': elapsed,
                 }
        for k, v in atoms.items():
            if isinstance(v, unicode):
                v = v.encode('utf8')
            elif not isinstance(v, str):
                v = str(v)
            # Fortunately, repr(str) escapes unprintable chars, \n, \t, etc
            # and backslash for us. All we have to do is strip the quotes.
            v = repr(v)[1:-1]
            # Escape double-quote.
            atoms[k] = v.replace('"', '\\"')
        
        try:
            self.access_log.log(logging.INFO, self.access_log_format % atoms)
        except:
            self(traceback=True)
    
    def time(self):
        """Return now() in Apache Common Log Format (no timezone)."""
        now = datetime.datetime.now()
        month = rfc822._monthnames[now.month - 1].capitalize()
        return ('[%02d/%s/%04d:%02d:%02d:%02d]' %
                (now.day, month, now.year, now.hour, now.minute, now.second))


def init_cherrypy_loggers():
    log_level = logging.INFO
    
    formatter = logging.Formatter('[%(asctime)s] %(message)s',
        datefmt='%d/%b/%Y:%H:%M:%S')
    
    root = logging.root
    root.setLevel(log_level)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.setLevel(log_level)
    root.addHandler(console)
    
    log = cherrypy.log = CustomLogManager()
    backupCount = getattr(log, "rot_backupCount", 90)
    error_fname = getattr(log, "rot_error_file", config.LOGDIR + "/error.log")
    error_handler = TimedRotatingFileHandler(error_fname, when='midnight', interval=1, backupCount=backupCount)
    error_handler.setLevel(config.LOG_LEVEL)
    error_handler.setFormatter(_cplogging.logfmt)
    log.error_log.addHandler(error_handler)

    access_fname = getattr(log, "rot_access_file", config.LOGDIR + "/access.log")
    access_handler = TimedRotatingFileHandler(access_fname, when='midnight', interval=1, backupCount=backupCount)
    access_handler.setLevel(logging.INFO)
    access_handler.setFormatter(_cplogging.logfmt)
    log.access_log.addHandler(access_handler)
    log.access_log.propagate = False
