# -*- coding: utf-8 -*-
"""
$Id: heartbeat.py 10119 2014-12-18 23:53:11Z ogambaryan $
"""

import threading
import time
import cherrypy
from pyramid.ormlite.dbop import dbquery
import ui.common
import config


class ThreadStatus(object):

    start = None
    end = None
    url = None

    def last_req_time(self):
        if self.end is None:
            return 0
        return self.end - self.start

    def idle_time(self):
        if self.end is None:
            return 0
        return time.time() - self.end


# see http://tools.cherrypy.org/wiki/StatusTool
class StatusMonitor(cherrypy.Tool):
    """Register the status of each thread."""

    def __init__(self):
        self._point = 'on_start_resource'
        self._name = 'status'
        self._priority = 50
        self.seen_threads = {}

    def callable(self):
        threadID = threading._get_ident()
        ts = self.seen_threads.setdefault(threadID, ThreadStatus())
        ts.start = cherrypy.response.time
        ts.url = cherrypy.url()
        ts.end = None

    def unregister(self):
        """Unregister the current thread."""
        threadID = threading._get_ident()
        if threadID in self.seen_threads:
            self.seen_threads[threadID].end = time.time()

    def _setup(self):
        cherrypy.Tool._setup(self)
        cherrypy.request.hooks.attach('on_end_resource', self.unregister)


class HeartbeatService(ui.common.AppPage):
    """Сервис мониторинга. Проверяем, что нет явных нарушений в работе приложения"""

    sectionTitle = u'Heartbeat service'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('heartbeat_svc', '/services/ping', controller=self, action='ping')
        dispatcher.connect('heartbeat_traverse_svc', '/services/ping_traverse', controller=self, action='ping_traverse')
        dispatcher.connect('server_status', '/services/status', controller=self, action='server_status')

    def _check_access(self):
        # доступ снаружи может привести к утечке данных
        if cherrypy.request.remote.ip != '127.0.0.1' or cherrypy.request.headers.get('X-Forwarded-For'):
            raise cherrypy.HTTPError(403, 'Forbidden')

    def ping(self):
        #self._check_access()  # Доступ снаружи нужен для мониторинга
        dbquery("select null from _schema_revisions where 1=0")
        return self.render('PONG!')

#    def ping_traverse(self):
#        self._check_access()
#        svc = PasswdService()
#        start_t = time.time()
#        svc.query(config.AWARD_SEARCH_ACCOUNT)
#        return 'traverse is ok; request time %.2f' % (time.time() - start_t)

    def server_status(self):
        self._check_access()
        if cherrypy.request.remote.ip != '127.0.0.1' or cherrypy.request.headers.get('X-Forwarded-For'):
            raise cherrypy.HTTPError(403, 'Forbidden')
        threadstats = ['<tr><th>%s</th><td>%.4f</td><td>%.4f</td><td>%s</td></tr>'
                       % (thread_id, ts.idle_time(), ts.last_req_time(), ts.url)
                       for thread_id, ts in cherrypy.tools.status.seen_threads.items()]
        return """
<html>
<head>
    <title>CherryPy Status</title>
</head>
<body>
<table>
<tr><th>Thread ID</th><th>Idle Time</th><th>Last Request Time</th><th>URL</th></tr>
%s
</table>
</body>
</html>
""" % '\n'.join(threadstats)
