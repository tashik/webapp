# -*- coding: utf-8 -*-

import config
from itertools import product
from lxml import etree

from pyramid.vocabulary import getV

from i18n import get_languages_with_available_translations
from logic.geo import iata_valid, load_airport
from logic.route import (RouteSolver, available_pairs, airports_by_iata,
                         available_routes, TYPE_SPEND)
from logic.skyteam import load_airline, load_airline_by_iata, AwardsCalculator
from models.route import Pair
from services.base.xml_base import (CommonXMLService, SuccessServiceResponse,
                                    ServiceErrorDescription, ParamsValidationError)
from services.base.lang import languageaware
from services.xml_services import append_lang_nodes


AIRPORT_IATA_RE = '[A-Z]{3}'


class AwardsXMLService(CommonXMLService):
    u"""Сервисы калькулятора премий (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_awards', 'v.0.0.2/xml/airline/:param_airline/awards/from/:param_from/via/:param_via/to/:param_to', action='awards_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('xml_awards', 'v.0.0.2/xml/airline/:param_airline/awards/from/:param_from/to/:param_to', action='awards_v001', controller=self,
                           param_via=None,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    def awards_v001(self, param_airline, param_from, param_to, param_via=None, **params):
        u"""Получение стоимости перелета за мили по заданному маршруту"""

        errors = []

        airline = load_airline_by_iata(param_airline)
        if airline is None:
            errors.append(ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline))

        for param in (param_from, param_to, param_via):
            if param is not None and not iata_valid(param):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param))

        if len(errors):
            raise ParamsValidationError(errors)

        rs = RouteSolver(available_pairs(airline_id=airline.airline_id,
                                         search_type=TYPE_SPEND))
        airport_from_ids = airports_by_iata(param_from, rs.get_locations())
        airport_via_ids = airports_by_iata(param_via, rs.get_locations())
        airport_to_ids = airports_by_iata(param_to, rs.get_locations())

        root = etree.Element('routes')

        for route in available_routes(airport_from_ids, airport_via_ids, airport_to_ids,
                                      airline_id=airline.airline_id):
            a_from_id, a_via_id, a_to_id = route
            if None in (a_from_id, a_to_id):
                continue

            a_from = load_airport(a_from_id)
            a_via = load_airport(a_via_id)
            a_to = load_airport(a_to_id)

            route_el = etree.SubElement(root, 'route')
            route_el.attrib['from'] = a_from.iata
            if a_via is not None:
                route_el.attrib['via'] = a_via.iata
            else:
                route_el.attrib['via'] = ''
            route_el.attrib['to'] = a_to.iata

            c = AwardsCalculator(a_from, a_via, a_to, airline)
            for ob in c.calculate():
                cost_el = etree.SubElement(route_el, 'cost')

                for name, value in ob.attrs():
                    cost_el.attrib[name] = value

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())


class AFLAwardsXMLService(AwardsXMLService):
    u"""Сервисы калькулятора премий (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_awards', 'v.0.0.1/xml/awards/from/:param_from/via/:param_via/to/:param_to', action='awards_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('xml_afl_awards', 'v.0.0.1/xml/awards/from/:param_from/to/:param_to', action='awards_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           param_via=None,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})


class SkyteamAwardsXMLService(CommonXMLService):
    u"""Сервисы калькулятора премий (только для Skyteam)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_skyteam_awards', 'v.0.0.1/xml/skyteam/awards/from/:param_from/to/:param_to', action='awards_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('xml_skyteam_awards', 'v.0.0.1/xml/skyteam/awards/airlines/from/:param_from/to/:param_to', action='airlines_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    def awards_v001(self, param_from, param_to, **params):
        u"""Получение стоимости перелета за мили по заданному маршруту"""

        errors = []

        for param in (param_from, param_to):
            if not iata_valid(param):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param))

        if len(errors):
            raise ParamsValidationError(errors)

        # пары для всех АК (Skyteam + SU)
        rs = RouteSolver(available_pairs(search_type=TYPE_SPEND))
        airport_from_ids = airports_by_iata(param_from, rs.get_locations())
        airport_to_ids = airports_by_iata(param_to, rs.get_locations())

        root = etree.Element('routes')

        for route in available_routes(airport_from_ids, set([]), airport_to_ids):
            a_from_id, a_via_id, a_to_id = route
            if None in (a_from_id, a_to_id):
                continue

            a_from = load_airport(a_from_id)
            a_to = load_airport(a_to_id)

            route_el = etree.SubElement(root, 'route')
            route_el.attrib['from'] = a_from.iata
            route_el.attrib['via'] = ''
            route_el.attrib['to'] = a_to.iata

            c = AwardsCalculator(a_from, None, a_to)
            for ob in c.calculate():
                cost_el = etree.SubElement(route_el, 'cost')

                for name, value in ob.attrs():
                    cost_el.attrib[name] = value

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())

    def airlines_v001(self, param_from, param_to, **params):
        u"""Получение списка авиакомпаний, для которых можно начислить премию по заданному маршруту"""

        errors = []

        for param in (param_from, param_to):
            if not iata_valid(param):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param))

        if len(errors):
            raise ParamsValidationError(errors)

        # пары для всех АК (Skyteam + SU)
        rs = RouteSolver(available_pairs(search_type=TYPE_SPEND))
        airport_from_ids = airports_by_iata(param_from, rs.get_locations())
        airport_to_ids = airports_by_iata(param_to, rs.get_locations())

        routes_available = set([])
        for airport_from_id, airport_to_id in product(airport_from_ids, airport_to_ids):
            airport_from = load_airport(airport_from_id)
            airport_to = load_airport(airport_to_id)

            if airport_from is None or airport_to is None:
                continue

            if airport_from.city_id == airport_to.city_id:
                continue

            # пары для маршрутов с пересадкой
            for airport_via in rs.get_via_locations(airport_from_id, airport_to_id):
                routes_available.add((airport_from_id, airport_via))
                routes_available.add((airport_to_id, airport_via))

            # пара для прямого маршрута
            if rs.check_direct_flight(airport_from_id, airport_to_id):
                routes_available.add((airport_from_id, airport_to_id))

        airlines = set([])
        for route in routes_available:
            for pair in Pair.search_all(*route):
                airlines.add(pair.airline_id)

        root = etree.Element('airlines')
        for airline_id in airlines:
            airline = load_airline(airline_id)
            if airline is not None:
                airline_el = etree.SubElement(root, 'airline')
                airline_el.attrib['code'] = airline.iata
        return self.render(root)


class RedemptionZoneXMLService(CommonXMLService):
    u"""Получение списка премиальных зон программы Аэрофлот Бонус (не зависит от Авиакомпании)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_redemption_zones', 'v.0.0.1/xml/redemption_zones', action='zones_v001', controller=self)

    @languageaware
    def zones_v001(self, message_lang, error_lang, **params):
        languages = get_languages_with_available_translations()
        if message_lang is not None and message_lang in languages:
            languages = [message_lang]

        root = etree.Element('redemptionZones')

        obs = sorted(getV('redemption_zones'), key=lambda x: x.redemption_zone)
        for ob in obs:
            zone_el = etree.SubElement(root, 'redemptionZone')
            zone_el.attrib['code'] = ob.redemption_zone

            append_lang_nodes(ob.title, zone_el, languages)

        return self.render(root)

