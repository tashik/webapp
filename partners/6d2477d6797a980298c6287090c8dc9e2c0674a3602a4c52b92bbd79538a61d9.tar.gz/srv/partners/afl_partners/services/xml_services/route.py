# -*- coding: utf-8 -*-

from itertools import product
from lxml import etree

from pyramid.vocabulary import getV, getVI

import config
from logic.geo import load_city, load_airport, iata_valid, get_airport_city
from logic.route import (RouteSolver, available_pairs, all_available_pairs,
                         airports_by_iata, TYPE_EARN, TYPE_SPEND)
from logic.skyteam import load_airline_by_iata
from services.base.xml_base import (CommonXMLService, SuccessServiceResponse,
                                    ServiceErrorDescription, ParamsValidationError)


AIRLINE_IATA_RE = '[A-Z]{2,3}'
AIRPORT_IATA_RE = '[A-Z]{3}'
SERVICE_CLASS_IATA_RE = '[a-z]+'
TYPE_RE = '%s|%s' % (TYPE_EARN, TYPE_SPEND)


class RouteXMLService(CommonXMLService):
    u"""Сервисы доступных направлений перелётов (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airports/pairs',
                           action='pairs_v001', controller=self)
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/airports/pairs',
                           action='pairs_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/type/:param_type/airports/pairs',
                           action='pairs_v001', controller=self,
                           requirements={'param_type': TYPE_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/type/:param_type/airports/pairs',
                           action='pairs_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE})

        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airports/from',
                           action='airports_from_v001', controller=self)
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/airports/from',
                           action='airports_from_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/type/:param_type/airports/from',
                           action='airports_from_v001', controller=self,
                           requirements={'param_type': TYPE_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/type/:param_type/airports/from',
                           action='airports_from_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE})

        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/type/:param_type/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/type/:param_type/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE})

        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/type/:param_type/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('xml_routes', 'v.0.0.2/xml/airline/:param_airline/type/:param_type/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    def _group_by_city(self, airports):
        airports = sorted(airports, key=lambda x: x.iata)

        result = {}
        for airport in airports:
            result.setdefault(airport.city_id, []).append(airport)

        return result

    def _render_airports(self, airport_ids, root_attrib=None,
                         root_elements=None, direct=None, via=None):
        root_elements = root_elements or []
        direct = direct or []
        via = via or []

        obs = []
        for airport_id in airport_ids:
            airport = load_airport(airport_id)
            if airport is not None:
                obs.append(airport)

        airports_by_city = self._group_by_city(obs)

        root = etree.Element('airports')
        for el in root_elements:
            root.append(el)

        if root_attrib is not None:
            for k, v in root_attrib:
                root.attrib[k] = v

        for city_id, airports in sorted(airports_by_city.items(), key=lambda x: x[0]):
            city = load_city(city_id)
            if city is None:
                continue

            city_el = etree.SubElement(root, 'city')
            city_el.attrib['code'] = city.iata

            for airport in airports:
                airport_el = etree.SubElement(city_el, 'airport')
                airport_el.attrib['code'] = airport.iata

                if airport.airport_id in direct:
                    etree.SubElement(airport_el, 'direct')

                if airport.airport_id in via:
                    etree.SubElement(airport_el, 'via')

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())

    def pairs_v001(self, param_airline=None, param_type=None, **params):
        u"""Получение списка пар аэропортов."""

        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline)])

        if param_type is not None:
            if param_type not in (TYPE_EARN, TYPE_SPEND):
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid search type: "%s"' % param_type)])

        pairs = []

        airline_id = airline.airline_id if airline is not None else None
        pairs_available = available_pairs(airline_id=airline_id,
                                          search_type=param_type)

        for a1, a2 in pairs_available:
            airport1 = load_airport(a1)
            airport2 = load_airport(a2)
            if airport1 is not None and airport2 is not None:
                pairs.append((airport1, airport2))

        root = etree.Element('pairs')
        for a1, a2 in sorted(pairs, key=lambda a: (a[0].iata, a[1].iata)):
            pair_el = etree.SubElement(root, 'pair')
            pair_el.attrib['airport1'] = a1.iata
            pair_el.attrib['airport2'] = a2.iata

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())

    def airports_from_v001(self, param_airline=None, param_type=None, **params):
        u"""Получение списка возможных городов/аэропортов вылета."""

        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline)])

        if param_type is not None:
            if param_type not in (TYPE_EARN, TYPE_SPEND):
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid search type: "%s"' % param_type)])

        airline_id = airline.airline_id if airline is not None else None
        pairs_available = available_pairs(airline_id=airline_id,
                                          search_type=param_type)

        rs = RouteSolver(pairs_available)
        result = rs.get_locations()

        return self._render_airports(result)

    def airports_to_v001(self, param_airline=None, param_type=None,
                         param_from=None, **params):
        u"""Получение списка городов/аэропортов прилета по городу/аэропорту вылета."""

        errors = []

        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                errors.append(ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline))

        if param_type is not None:
            if param_type not in (TYPE_EARN, TYPE_SPEND):
                errors.append(ServiceErrorDescription(111, u'Invalid search type: "%s"' % param_type))

        if not iata_valid(param_from):
            errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param_from))

        if len(errors):
            raise ParamsValidationError(errors)

        airline_id = airline.airline_id if airline is not None else None
        pairs_available = available_pairs(airline_id=airline_id,
                                          search_type=param_type)

        rs = RouteSolver(pairs_available)
        airport_ids = airports_by_iata(param_from, rs.get_locations())

        result = set([])
        exclude = set([])
        direct = set([])
        via = set([])
        for airport_id in airport_ids:
            _r, _d, _v = rs.get_to_locations2(airport_id)
            result |= _r
            direct |= _d
            via |= _v
            if not exclude:
                city = get_airport_city(airport_id)
                exclude = set([ob.airport_id for ob in \
                               getVI('airports_by_city_idx')(context=city)])

        # Из Шереметьево во Внуково никто не полетит
        result -= exclude

        return self._render_airports(result,
                                     root_attrib=(('from', param_from),),
                                     direct=direct, via=via)

    def airports_via_v001(self, param_airline=None, param_type=None,
                          param_from=None, param_to=None, **params):
        u"""Получение списка городов/аэропортов пересадок по городу вылета и прилёта."""

        errors = []

        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                errors.append(ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline))

        if param_type is not None:
            if param_type not in (TYPE_EARN, TYPE_SPEND):
                errors.append(ServiceErrorDescription(111, u'Invalid search type: "%s"' % param_type))

        for param in (param_from, param_to):
            if not iata_valid(param):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param))

        if len(errors):
            raise ParamsValidationError(errors)

        airline_id = airline.airline_id if airline is not None else None
        pairs_available = available_pairs(airline_id=airline_id,
                                          search_type=param_type)

        rs = RouteSolver(pairs_available)
        airport_from_ids = airports_by_iata(param_from, rs.get_locations())
        airport_to_ids = airports_by_iata(param_to, rs.get_locations())

        result = set([])
        direct_flight = False

        for airport_from_id, airport_to_id in product(airport_from_ids, airport_to_ids):
            airport_from = load_airport(airport_from_id)
            airport_to = load_airport(airport_to_id)

            if airport_from is None or airport_to is None:
                continue

            if airport_from.city_id == airport_to.city_id:
                continue

            result |= rs.get_via_locations(airport_from_id, airport_to_id)
            if not direct_flight:
                direct_flight = rs.check_direct_flight(airport_from_id,
                                                       airport_to_id)

        root_elements = [etree.Element('direct')] if direct_flight else None

        return self._render_airports(result, root_attrib=(('from', param_from), ('to', param_to)),
                                     root_elements=root_elements)


class AFLRouteXMLService(RouteXMLService):
    u"""Сервисы доступных направлений перелётов (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_routes', 'v.0.0.1/xml/airports/pairs',
                           action='pairs_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA)
        dispatcher.connect('xml_afl_routes', 'v.0.0.1/xml/airports/from',
                           action='airports_from_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA)
        dispatcher.connect('xml_afl_routes', 'v.0.0.1/xml/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           requirements={'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('xml_afl_routes', 'v.0.0.1/xml/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})


class PairsByAirlineServiceClassXMLService(CommonXMLService):
    u"""
    Получение списка пар аэропортов для запрошенного класса
    обслуживания авиакомпании (для всех Авиакомпаний).
    """

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            'xml_routes_by_service_classes',
            'v.0.0.2/xml/airline/:param_airline/airports/pairs/:service_class',
            action='pairs_v001', controller=self,
            requirements={
                'param_airline': AIRLINE_IATA_RE,
                'service_class': SERVICE_CLASS_IATA_RE
            }
        )

    def pairs_v001(self, param_airline, service_class, **params):
        errors = []
        airline = load_airline_by_iata(param_airline)
        if airline is None:
            errors.append(ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline))

        asc_idx = getVI("airline_service_classes_by_airline_idx")
        scv = getV('skyteam_service_classes')
        try:
            asc = next(
                asc
                for asc in asc_idx(context=airline)
                if scv[asc.skyteam_sc_id].code == service_class
            )
        except StopIteration, KeyError:
            errors.append(ServiceErrorDescription(111, u'Invalid service class: "%s"' % service_class))

        if len(errors):
            raise ParamsValidationError(errors)

        airports = getV("airports")
        pairs = [
            (
                airports[pair.airport_from_id].iata,
                airports[pair.airport_to_id].iata
            )
            for pair in asc.allowed_pairs
        ]

        root = etree.Element('class')
        root.attrib['code'] = service_class

        if not pairs:
            etree.SubElement(root, 'all')

        for p_from, p_to in sorted(pairs, key=lambda x: [0]):
            route_el = etree.SubElement(root, 'pair')
            route_el.attrib['airport1'] = p_from
            route_el.attrib['airport2'] = p_to

        return self.render(root)


class AFLPairsByAirlineServiceClassXMLService(
    PairsByAirlineServiceClassXMLService
    ):
    u"""
    Получение списка пар аэропортов для запрошенного класса
    обслуживания (только для Аэрофлота).
    """

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            'xml_afl_routes_by_service_classes',
            'v.0.0.1/xml/airports/pairs/:service_class',
            action='pairs_v001', controller=self,
            requirements={
                'service_class': SERVICE_CLASS_IATA_RE
            },
            param_airline=config.AFL_AIRLINE_IATA
        )
