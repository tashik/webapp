# -*- coding: utf-8 -*-
from pyramid.i18n import translate
from lxml import etree


def append_lang_nodes(msg, parent, languages, tag_name='name'):
    for lang in languages:
        el = etree.SubElement(parent, tag_name)
        el.attrib['{http://www.w3.org/XML/1998/namespace}lang'] = lang
        el.text = translate(msg, domain='self_translate', target_language=lang)
