# -*- coding: utf-8 -*-

from lxml import etree

from pyramid.vocabulary import getV, getVI

from logic.geo import iata_valid
from logic.route import available_routes, airports_by_iata
from logic.skyteam import load_airline
from models.route import Pair
from services.base.xml_base import (CommonXMLService, SuccessServiceResponse,
                                    ServiceErrorDescription, ParamsValidationError)


AIRPORT_IATA_RE = '[A-Z]{3}'


class AirlinesByRouteXMLService(CommonXMLService):
    u"""Получение списка авиакомпаний, летающих заданным маршрутом."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_airlines_by_route', 'v.0.0.1/xml/airlines/from/:param_from/to/:param_to', action='airlines_by_route_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    def airlines_by_route_v001(self, param_from, param_to, **params):
        errors = []

        for param in (param_from, param_to):
            if not iata_valid(param):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param))

        if len(errors):
            raise ParamsValidationError(errors)


        airport_from_ids = airports_by_iata(param_from)
        airport_to_ids = airports_by_iata(param_to)

        airlines = set([])
        for route in available_routes(airport_from_ids, airport_to_ids):
            for pair in Pair.search_all(*route):
                airlines.add(pair.airline_id)

        root = etree.Element('airlines')
        for airline_id in airlines:
            airline = load_airline(airline_id)
            if airline is not None:
                airline_el = etree.SubElement(root, 'airline')
                airline_el.attrib['code'] = airline.iata
        return self.render(root)

