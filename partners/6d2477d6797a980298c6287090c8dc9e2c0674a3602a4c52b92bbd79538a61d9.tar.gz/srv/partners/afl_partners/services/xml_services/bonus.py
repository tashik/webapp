# -*- coding: utf-8 -*-

"""
$Id: $
"""
import json
import os
from lxml import etree

from pyramid.vocabulary import getV, getVI
from rx.i18n.translation import self_translated

from i18n import get_languages_with_available_translations

from logic.skyteam import load_airline_by_iata
from services.base.lang import languageaware
from services.base.xml_base import (CommonXMLService, SuccessServiceResponse,
                                    ServiceErrorDescription, ParamsValidationError)
from services.xml_services import append_lang_nodes

import config


AIRLINE_IATA_RE = '[A-Z]{2,3}'


class TierLevelXMLService(CommonXMLService):
    u"""Получение списка статусов программ Аэрофлот Бонус (не зависит от Авиакомпании)."""

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            'xml_tier_level',
            'v.0.0.1/xml/tiers',
            action='tier_levels_v001',
            controller=self)

    @languageaware
    def tier_levels_v001(self, message_lang, error_lang, **params):
        languages = get_languages_with_available_translations()
        if message_lang is not None and message_lang in languages:
            languages = [message_lang]

        root = etree.Element('tiers')

        obs = sorted(getV('tier_levels'), key=lambda x: x.ordering)
        for ob in obs:
            level_el = etree.SubElement(root, 'tier')
            level_el.attrib['code'] = ob.tier_level
            level_el.attrib['ordering'] = '%d' % ob.ordering

            append_lang_nodes(ob.title, level_el, languages)

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())


class AirlineServiceClassXMLService(CommonXMLService):
    u"""
    Получение списка классов обслуживания, тарифных групп и классов
    бронирования (для всех Авиакомпаний).
    """

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            "xml_service_class",
            "v.0.0.2/xml/airline/:param_airline/service_classes",
            requirements={'param_airline': AIRLINE_IATA_RE},
            action='service_classes_v001', controller=self
        )

    @staticmethod
    def _check_tag_lang(tag, message_lang):
        tag_lang = tag.attrib.get('{http://www.w3.org/XML/1998/namespace}lang')
        if tag_lang and tag_lang != message_lang:
            tag.getparent().remove(tag)

    @languageaware
    def service_classes_v001(
        self, message_lang, error_lang, param_airline, **params
    ):
        u"""
        Получение списка классов обслуживания, тарифных групп и
        классов бронирования (для заданной авиакомпании)
        """

        airline = load_airline_by_iata(param_airline)
        if airline is None:
            raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline)])

        root = etree.Element('serviceClasses')

        sc_v = getV("skyteam_service_classes")
        asc_idx = getVI('airline_service_classes_by_airline_idx')
        obs = sorted(
            asc_idx(context=airline),
            key=lambda x: sc_v[x.skyteam_sc_id].weight
        )
        languages = get_languages_with_available_translations()
        if message_lang is not None and message_lang in languages:
            languages = [message_lang]
        tariff_groups_by_service_class = getVI(
            "airline_tariff_groups_by_airline_service_class_idx"
        )
        booking_classes_by_tariff_group = getVI(
            "booking_classes_by_airline_tariff_group_idx"
        )
        tgv = getV("tariff_groups")
        for ob in obs:
            sc = sc_v[ob.skyteam_sc_id]
            class_el = etree.SubElement(root, 'class')
            class_el.attrib['code'] = sc.code
            class_el.attrib['ordering'] = unicode(sc.weight)

            append_lang_nodes(sc.title, class_el, languages)

            groups_el = etree.SubElement(class_el, 'groups')

            tg_obs = sorted(tariff_groups_by_service_class(context=ob),
                            key=lambda x: x.weight)
            for tg_ob in tg_obs:
                tga_ob = tgv[tg_ob.tariff_group_id]
                group_el = etree.SubElement(groups_el, 'group')
                group_el.attrib['code'] = tga_ob.code
                group_el.attrib['ordering'] = '%d' % tg_ob.weight
                append_lang_nodes(tga_ob.title, group_el, languages)
                if tg_ob.fareCode:
                    group_el.attrib['fareCode'] = str(tg_ob.fareCode)

                for bc_ob in booking_classes_by_tariff_group(context=tg_ob):
                    booking_class_el = etree.SubElement(group_el, 'fare')
                    booking_class_el.attrib['code'] = bc_ob.code

                    append_lang_nodes(bc_ob.comment, booking_class_el,
                                      languages, tag_name='comment')

        response = SuccessServiceResponse(root)
        return response


class AFLAirlineServiceClassXMLService(AirlineServiceClassXMLService):
    u"""Получение списка классов обслуживания, тарифных групп и классов бронирования (только для Аэрофлота)."""

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            "xml_afl_service_class", "v.0.0.1/xml/service_classes",
            action='service_classes_v001', controller=self,
            param_airline=config.AFL_AIRLINE_IATA
        )

