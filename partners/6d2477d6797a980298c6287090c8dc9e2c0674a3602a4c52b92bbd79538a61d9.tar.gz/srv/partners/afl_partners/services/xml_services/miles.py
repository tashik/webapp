# -*- coding: utf-8 -*-

import config
from lxml import etree

from pyramid.vocabulary import getV, getVI

from logic.geo import iata_valid, load_airport
from logic.route import (RouteSolver, available_pairs, airports_by_iata,
                         available_routes, route_to_segments, TYPE_EARN)
from logic.skyteam import (load_airline, available_tier_levels,
                           available_tariff_groups, resolve_tier_level_factor,
                           load_airline_by_iata, MilesCalculator, available_airline_tariff_groups)
from services.base.xml_base import (CommonXMLService, SuccessServiceResponse,
                                    ServiceErrorDescription, ParamsValidationError)


AIRLINE_IATA_RE = '[A-Z]{2,3}'
AIRPORT_IATA_RE = '[A-Z]{3}'
TARIFF_GROUP_CODE_RE = '[a-z0-9\-]+'
FARE_BASIS_CODE_CODE_RE = '[A-Z]{2}'
TIER_LEVEL_CODE_RE = '[a-z]+'


class MilesXMLService(CommonXMLService):
    u"""Сервисы калькулятора миль (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_miles', 'v.0.0.2/xml/airline/:param_airline/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level/:tariff_group', action='miles_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.2/xml/airline/:param_airline/miles/from/:param_from/to/:param_to/:tier_level/:tariff_group', action='miles_v001', controller=self,
                           param_via=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.2/xml/airline/:param_airline/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level', action='miles_v001', controller=self,
                           tariff_group=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.2/xml/airline/:param_airline/miles/from/:param_from/to/:param_to/:tier_level', action='miles_v001', controller=self,
                           param_via=None,
                           tariff_group=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})

        dispatcher.connect('xml_afl_miles', 'v.0.0.3/xml/airline/:param_airline/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level/:tariff_group/:fare_basis_code', action='miles_v003', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'fare_basis_code': FARE_BASIS_CODE_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.3/xml/airline/:param_airline/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level', action='miles_v003', controller=self,
                           tariff_group=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.3/xml/airline/:param_airline/miles/from/:param_from/to/:param_to/:tier_level/:tariff_group/:fare_basis_code', action='miles_v003', controller=self,
                           param_via=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'fare_basis_code': FARE_BASIS_CODE_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.3/xml/airline/:param_airline/miles/from/:param_from/to/:param_to/:tier_level', action='miles_v003', controller=self,
                           param_via=None,
                           tariff_group=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})

    @staticmethod
    def _validate_params(airline, param_airline, tier_level, param_from, param_to, param_via, tariff_group):
        errors = []
        if airline is None:
            errors.append(ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline))

        if not tier_level in available_tier_levels(airline):
            errors.append(ServiceErrorDescription(111, u'Invalid tier level: "%s"' % tier_level))

        for param in (param_from, param_to, param_via):
            if param is not None and not iata_valid(param):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % param))

        if tariff_group is not None and tariff_group not in available_tariff_groups(airline):
            errors.append(ServiceErrorDescription(111, u'Invalid tariff group: "%s"' % tariff_group))

        return errors

    @staticmethod
    def _get_airport_information(airline, param_from, param_via, param_to):
        rs = RouteSolver(available_pairs(airline_id=airline.airline_id,
                                         search_type=TYPE_EARN))
        return (airports_by_iata(param_from, rs.get_locations()),
                airports_by_iata(param_via, rs.get_locations()),
                airports_by_iata(param_to, rs.get_locations()))

    @staticmethod
    def _generate_route_el(root, a_from_id, a_via_id, a_to_id):
        a_from = load_airport(a_from_id)
        a_via = load_airport(a_via_id)
        a_to = load_airport(a_to_id)

        route_el = etree.SubElement(root, 'route')
        route_el.attrib['from'] = a_from.iata
        if a_via is not None:
            route_el.attrib['via'] = a_via.iata
        else:
            route_el.attrib['via'] = ''
        route_el.attrib['to'] = a_to.iata

        return route_el

    @staticmethod
    def _generate_segment_el(a1_id, a2_id, tier_level_factor, airline_tariff_group, route_el, tariff_group, booking_classes_airline_tariff_group=None):
        c = MilesCalculator(a1_id, a2_id, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        a1 = load_airport(a1_id)
        a2 = load_airport(a2_id)

        segment_el = etree.SubElement(route_el, 'segment')
        segment_el.attrib['from'] = a1.iata
        segment_el.attrib['to'] = a2.iata
        for name, value in result.attrs():
            segment_el.attrib[name] = value

        if tariff_group is None:
            segment_el.attrib['class'] = airline_tariff_group.airline_sc.skyteam_sc.code
            segment_el.attrib['tariffGroup'] = airline_tariff_group.tariff_group.code
            if booking_classes_airline_tariff_group:
                segment_el.attrib['airline_tariff_group'] = airline_tariff_group.fareCode
                segment_el.attrib['booking_classes'] = ', '.join(booking_classes_airline_tariff_group)

    @staticmethod
    def _is_mapping_tariff_group(booking_classes_airline_tariff_group, fare_code, fare_basis_code):
        if fare_basis_code:
            return fare_basis_code in map(lambda bc_atg: u'{0}{1}'.format(bc_atg, fare_code), booking_classes_airline_tariff_group)
        else:
            return True

    @staticmethod
    def _parse_fare_basis_code(fare_basis_code):
        if fare_basis_code is not None and len(fare_basis_code) > 1:
            return fare_basis_code[1], fare_basis_code[0]
        else:
            return None, None

    @staticmethod
    def _get_airline_tariff_groups(airline):
        airline_tariff_groups = []
        for sc in getVI('airline_service_classes_by_airline_idx')(context=airline):
            airline_tariff_groups.extend(getVI('airline_tariff_groups_by_airline_service_class_idx')(context=sc))
        return airline_tariff_groups

    @staticmethod
    def _check_calculate_possibility_v003(tg, atg, atg_code, booking_classes, bcl_code, route):
        if tg is not None and tg != atg.tariff_group.code:
            return False

        if atg_code is not None and atg_code != atg.fareCode:
            return False

        if bcl_code is not None and bcl_code not in booking_classes:
            return False

        # Проверка возможности рассчёта всех сегментов на определённом классе обслуживания
        if not all([atg.airline_sc.pair_allowed(*s) for s in route_to_segments(*route)]):
            return False

        return True

    def _check_calculate_possibility_v001(self, tg, atg, booking_classes, param_airline, fare_basis_code, route):
        if tg is not None and tg != atg.tariff_group.code:
            return False

        booking_classes_airline_tariff_group = [bc.code for bc in booking_classes(context=atg)]

        if param_airline == 'SU' and not self._is_mapping_tariff_group(
                booking_classes_airline_tariff_group, atg.fareCode,
                config.MAP_TF_TO_ATG_SU.get(atg.tariff_group.code)):
            return False

        airline_tariff_group_code, booking_class_code = self._parse_fare_basis_code(fare_basis_code)

        if booking_class_code is not None and booking_class_code not in booking_classes_airline_tariff_group:
            return False

        if airline_tariff_group_code and atg.fareCode != airline_tariff_group_code:
            return False

        # Проверка возможности рассчёта всех сегментов на определённом классе обслуживания
        if not all([atg.airline_sc.pair_allowed(*s) for s in route_to_segments(*route)]):
            return False

        return True

    def miles_v001(self, param_airline, param_from, param_to, tier_level, param_via=None, tariff_group=None, **params):
        u"""Получение сумм начисляемых миль по заданному маршруту"""

        airline = load_airline_by_iata(param_airline)
        errors = self._validate_params(airline, param_airline, tier_level, param_from, param_to, param_via, tariff_group)
        if len(errors):
            raise ParamsValidationError(errors)

        fare_basis_code = config.MAP_TF_TO_ATG_SU.get(tariff_group) if tariff_group and param_airline == 'SU' else None
        booking_classes_by_tariff_group = getVI('booking_classes_by_airline_tariff_group_idx')
        tier_level_factor = resolve_tier_level_factor(tier_level, airline)
        airline_tariff_groups = self._get_airline_tariff_groups(airline)
        airport_from_ids, airport_via_ids, airport_to_ids = self._get_airport_information(
            airline, param_from, param_via, param_to)

        root = etree.Element('routes')
        for route in available_routes(airport_from_ids, airport_via_ids, airport_to_ids,
                                      airline_id=airline.airline_id):
            a_from_id, a_via_id, a_to_id = route
            if None in (a_from_id, a_to_id):
                continue
            route_el = self._generate_route_el(root, a_from_id, a_via_id, a_to_id)

            for airline_tariff_group in airline_tariff_groups:
                if not self._check_calculate_possibility_v001(
                        tariff_group, airline_tariff_group, booking_classes_by_tariff_group,
                        param_airline, fare_basis_code, route):
                    continue
                for a1_id, a2_id in route_to_segments(*route):
                    self._generate_segment_el(a1_id, a2_id, tier_level_factor, airline_tariff_group, route_el, tariff_group)

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())

    def miles_v003(self, param_airline, param_from, param_to, tier_level, param_via=None, tariff_group=None, fare_basis_code=None, **params):
        u"""Получение сумм начисляемых миль по заданному маршруту"""

        airline = load_airline_by_iata(param_airline)
        airline_tariff_group_code, booking_class_code = self._parse_fare_basis_code(fare_basis_code)

        errors = self._validate_params(airline, param_airline, tier_level, param_from, param_to, param_via, tariff_group)
        if airline_tariff_group_code is not None and airline_tariff_group_code not in available_airline_tariff_groups(airline):
            errors.append(ServiceErrorDescription(111, u'Invalid airline tariff group: "%s"' % airline_tariff_group_code))
        if len(errors):
            raise ParamsValidationError(errors)

        tier_level_factor = resolve_tier_level_factor(tier_level, airline)
        airline_tariff_groups = self._get_airline_tariff_groups(airline)
        airport_from_ids, airport_via_ids, airport_to_ids = self._get_airport_information(
            airline, param_from, param_via, param_to)
        booking_classes_by_tariff_group = getVI('booking_classes_by_airline_tariff_group_idx')

        root = etree.Element('routes')
        for route in available_routes(airport_from_ids, airport_via_ids, airport_to_ids,
                                      airline_id=airline.airline_id):
            a_from_id, a_via_id, a_to_id = route
            if None in (a_from_id, a_to_id):
                continue
            route_el = self._generate_route_el(root, a_from_id, a_via_id, a_to_id)

            for airline_tariff_group in airline_tariff_groups:
                booking_classes_airline_tariff_group = [bc.code for bc in booking_classes_by_tariff_group(context=airline_tariff_group)]

                if not self._check_calculate_possibility_v003(
                        tariff_group, airline_tariff_group, airline_tariff_group_code,
                        booking_classes_airline_tariff_group, booking_class_code, route):
                    continue

                for a1_id, a2_id in route_to_segments(*route):
                    self._generate_segment_el(a1_id, a2_id, tier_level_factor, airline_tariff_group, route_el,
                                              tariff_group, sorted(booking_classes_airline_tariff_group))

        response = SuccessServiceResponse(root)
        return self.render(response.to_etree())


class AFLMilesXMLService(MilesXMLService):
    u"""Сервисы калькулятора миль (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_miles', 'v.0.0.1/xml/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level/:tariff_group', action='miles_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.1/xml/miles/from/:param_from/to/:param_to/:tier_level/:tariff_group', action='miles_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           param_via=None,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.1/xml/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level', action='miles_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           tariff_group=None,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('xml_afl_miles', 'v.0.0.1/xml/miles/from/:param_from/to/:param_to/:tier_level', action='miles_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           param_via=None,
                           tariff_group=None,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})


class MilesServiceClassXMLService(CommonXMLService):
    u"""Получение списка классов обслуживания по полётному сегменту (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_miles_service_classes', 'v.0.0.2/xml/airline/:param_airline/miles/service_classes/from/:param_from/to/:param_to',
                           action='service_classes_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    def service_classes_v001(self, param_airline, param_from, param_to, **params):
        errors = []

        airline = load_airline_by_iata(param_airline)
        if airline is None:
            errors.append(ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline))

        for p in (param_from, param_to):
            if not iata_valid(p):
                errors.append(ServiceErrorDescription(111, u'Invalid location: "%s"' % p))

        if len(errors):
            raise ParamsValidationError(errors)

        all_available_pairs = available_pairs(airline_id=airline.airline_id,
                                              search_type=TYPE_EARN)

        rs = RouteSolver(all_available_pairs)
        airports_from_ids = airports_by_iata(param_from, rs.get_locations())
        airports_to_ids = airports_by_iata(param_to, rs.get_locations())

        root = etree.Element('serviceClasses')
        root.attrib['from'] = param_from
        root.attrib['to'] = param_to

        pair_dict = getV('pairs')
        limitations = getVI('service_classes_limits_by_airline_idx')(context=airline)
        for cls in getVI('airline_service_classes_by_airline_idx')(context=airline):
            pairs_to_check = [(pair.airport_from_id, pair.airport_to_id) for pair in
                              [pair_dict[l.pair_id] for l in limitations
                               if l.airline_sc_id == cls.airline_sc_id]] or all_available_pairs

            if any([(pair[0] in airports_from_ids and pair[1] in airports_to_ids) or
                    (pair[1] in airports_from_ids and pair[0] in airports_to_ids)
                    for pair in pairs_to_check]):
                class_el = etree.SubElement(root, 'class')
                class_el.attrib['code'] = getV('skyteam_service_classes')[cls.skyteam_sc_id].code

        return self.render(root)


class AFLMilesServiceClassXMLService(MilesServiceClassXMLService):
    u"""Получение списка классов обслуживания по полётному сегменту (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_miles_service_classes', 'v.0.0.1/xml/miles/service_classes/from/:param_from/to/:param_to',
                           action='service_classes_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})


class MilesTierLevelXMLService(CommonXMLService):
    u"""Получение списка статусов программы Аэрофлот Бонус (не зависит от Авиакомпании)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_miles_tier_levels', 'v.0.0.1/xml/miles/tiers',
                           action='tier_levels_v001', controller=self)

    def tier_levels_v001(self, **params):
        tires_vocabs = getV('tier_levels')
        root = etree.Element('tiers')
        for tier_code in sorted(tires_vocabs.keys()):
            tier_el = etree.SubElement(root, 'tier')
            tier_el.attrib['code'] = tier_code

        return self.render(root)

