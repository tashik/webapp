# -*- coding: utf-8 -*-

"""
$Id: geo.py 15410 2015-10-21 14:36:37Z ogambaryan $
"""
import config
from itertools import groupby
from lxml import etree

from pyramid.vocabulary import getV

from i18n import get_languages_with_available_translations
from logic.route import available_airports, all_available_airports
from logic.skyteam import load_airline_by_iata
from services.base.lang import languageaware
from services.base.xml_base import (CommonXMLService, SuccessServiceResponse,
                                    ParamsValidationError, ServiceErrorDescription)
from services.xml_services import append_lang_nodes


AIRLINE_IATA_RE = '[A-Z]{2,3}'


class CountryXMLService(CommonXMLService):
    u"""Сервис списка стран (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_countries', 'v.0.0.2/xml/countries',
                           action='countries_v001', controller=self)
        dispatcher.connect('xml_countries', 'v.0.0.2/xml/airline/:param_airline/countries',
                           action='countries_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})

    @languageaware
    def countries_v001(self, message_lang, error_lang, param_airline=None, **params):
        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline)])

        languages = get_languages_with_available_translations()
        if message_lang is not None and message_lang in languages:
            languages = [message_lang]

        if airline is None:
            airports = all_available_airports()
        else:
            airports = available_airports(airline.airline_id)

        airports_dict = getV('airports')
        cities_dict = getV('cities')

        country_codes = sorted(set(
            [cities_dict[airports_dict[ap_id].city_id].country_code
             for ap_id in airports]))

        countries_dict = getV('countries')

        root = etree.Element('countries')
        for country_code in country_codes:
            country_el = etree.SubElement(root, 'country')
            country_el.attrib['code'] = country_code
            append_lang_nodes(countries_dict[country_code].title, country_el, languages)

        response = SuccessServiceResponse(root)
        return response


class AFLCountryXMLService(CountryXMLService):
    u"""Сервис списка стран (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_countries', 'v.0.0.1/xml/countries',
                           action='countries_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA)


class CityXMLService(CommonXMLService):
    u"""Сервис списка городов (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_cities', 'v.0.0.2/xml/cities',
                           action='cities_v001', controller=self)
        dispatcher.connect('xml_cities', 'v.0.0.2/xml/airline/:param_airline/cities',
                           action='cities_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})

        dispatcher.connect('xml_cities', 'v.0.0.3/xml/cities',
                           action='cities_v001', controller=self,
                           show_all_zones=True)

    @languageaware
    def cities_v001(self, message_lang, error_lang, param_airline=None,
                    show_all_zones=False, **params):
        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline)])

        languages = get_languages_with_available_translations()
        if message_lang is not None and message_lang in languages:
            languages = [message_lang]

        root = etree.Element('cities')

        airports_dict = getV('airports')

        if show_all_zones:
            if airline is None:
                airports = all_available_airports()
            else:
                airports = available_airports(airline.airline_id)
            redemption_zones = dict([(airports_dict[ap_id].city_id,
                                     dict(afl=airports_dict[ap_id].afl_redemption_zone,
                                          skyteam=airports_dict[ap_id].skyteam_redemption_zone)) for ap_id in airports])
        else:
            if airline is None:
                airports = all_available_airports()
                redemption_zones = {}
            else:
                airports = available_airports(airline.airline_id)
                redemption_zones = dict([(airports_dict[ap_id].city_id,
                                         airports_dict[ap_id].redemption_zone_by_airline(airline)) for ap_id in airports])

        cities_ids = set([airports_dict[ap_id].city_id for ap_id in airports])
        cities_dict = getV('cities')
        cities = sorted([cities_dict[cid] for cid in cities_ids],
                        key=lambda city: (city.country_code, city.iata))
        for country, city_list in groupby(cities, lambda city: city.country_code):
            country_el = etree.SubElement(root, 'country')
            country_el.attrib['code'] = country
            for city in city_list:
                city_el = etree.SubElement(country_el, 'city')
                city_el.attrib['code'] = str(city.iata)

                if city.lat is not None:
                    city_el.attrib['lat'] = str(city.lat)
                if city.lon is not None:
                    city_el.attrib['lon'] = str(city.lon)

                redemption_zone = redemption_zones.get(city.city_id)
                if redemption_zone is not None:
                    if show_all_zones:
                        if redemption_zone['afl']:
                            city_el.attrib['redemptionZoneAFL'] = redemption_zone['afl']
                        if redemption_zone['skyteam']:
                            city_el.attrib['redemptionZoneSkyteam'] = redemption_zone['skyteam']
                    else:
                        city_el.attrib['redemptionZone'] = redemption_zone

                if city.tz is not None:
                    city_el.attrib['tzdata'] = city.tz

                append_lang_nodes(city.title, city_el, languages)

        response = SuccessServiceResponse(root)
        return response


class AFLCityXMLService(CityXMLService):
    u"""Сервис списка городов (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_cities', 'v.0.0.1/xml/cities',
                           action='cities_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA)


class AirportXMLService(CommonXMLService):
    u"""Сервис списка аэропортов (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_airports', 'v.0.0.2/xml/airports',
                           action='airports_v001', controller=self)
        dispatcher.connect('xml_airports', 'v.0.0.2/xml/airline/:param_airline/airports',
                           action='airports_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})

    @languageaware
    def airports_v001(self, message_lang, error_lang, param_airline=None, **params):
        airline = None
        if param_airline is not None:
            airline = load_airline_by_iata(param_airline)
            if airline is None:
                raise ParamsValidationError([ServiceErrorDescription(111, u'Invalid airline IATA code: "%s"' % param_airline)])

        languages = get_languages_with_available_translations()
        if message_lang is not None and message_lang in languages:
            languages = [message_lang]

        root = etree.Element('airports')

        airport_index = {}
        cities = []
        if airline is None:
            airports = all_available_airports()
        else:
            airports = available_airports(airline.airline_id)

        airports_dict = getV('airports')
        cities_dict = getV('cities')

        for ap_id in airports:
            airport = airports_dict[ap_id]
            try:
                airport_index[airport.city_id].append(airport)
            except KeyError:
                airport_index[airport.city_id] = [airport]
                cities.append(cities_dict[airport.city_id])

        cities = sorted(cities, key=lambda city: city.iata)

        for city in cities:
            city_el = etree.SubElement(root, 'city')
            city_el.attrib['code'] = str(city.iata)
            append_lang_nodes(city.title, city_el, languages)

            for airport in airport_index[city.city_id]:
                airport_el = etree.SubElement(city_el, 'airport')
                airport_el.attrib.update({
                    'code': str(airport.iata),
                    'lat': str(airport.lat),
                    'lon': str(airport.lon),
                    'upg_chk': '1' if airport.has_upgrade_on_checkin_award else '0'})
                append_lang_nodes(airport.title, airport_el, languages)

        response = SuccessServiceResponse(root)
        return response


class AFLAirportXMLService(AirportXMLService):
    u"""Сервис списка аэропортов (только для Аэрофлота)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_afl_airports', 'v.0.0.1/xml/airports',
                           action='airports_v001', controller=self,
                           param_airline=config.AFL_AIRLINE_IATA)

