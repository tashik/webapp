# -*- coding: utf-8 -*-

from zope.interface.interface import Interface
from zope.interface.declarations import implements

from pyramid.ui.error import ErrorHandler


class IErrorHandling(Interface):
    pass


class ErrorHandling(object):
    implements(IErrorHandling)

    def __init__(self, *args, **kw):
        super(ErrorHandling, self).__init__(*args, **kw)
        self.errorHandler = ErrorHandler(self)
        self._cp_config['request.error_response'] = self.errorHandler.index