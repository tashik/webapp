# -*- coding: utf-8 -*-

import cherrypy
import testoob
import sys
import time
import unittest

from lxml import etree

from pyramid.tests import testlib

from services.base.xml_base import (CommonXMLService, XMLServiceErrorReporter,
                                    ServiceErrorDescription, ServiceError, 
                                    ParamsValidationError, MalformedRequestError,
                                    InternalServiceError, SuccessServiceResponse,
                                    FailureServiceResponse, ServiceResponse)


class ServiceMock(CommonXMLService):
    pass


class TestServiceError(unittest.TestCase):
    u"""Тест класса ошибки сервисов"""

    def test_create(self):
        error = ServiceErrorDescription(1234, u'xyz')
        self.assertEqual(1234, error.code)
        self.assertEqual(u'xyz', error.message)
        self.assertEqual(None, error.value)
        self.assertEqual(None, error.dbg)

        error = ServiceErrorDescription(code=1234, message=u'xyz', value=u'abcd', dbg=u'5678', error_type=u'qwe')
        self.assertEqual(1234, error.code)
        self.assertEqual(u'xyz', error.message)
        self.assertEqual(u'abcd', error.value)
        self.assertEqual(u'5678', error.dbg)
        self.assertEqual(u'qwe', error.error_type)

    def test_create_error(self):
        self.assertRaises(AssertionError, ServiceErrorDescription, code='1234', message=u'xy')
        self.assertRaises(AssertionError, ServiceErrorDescription, code=1234, message=None)
        self.assertRaises(AssertionError, ServiceErrorDescription, code=-1234, message=u'1234')
        self.assertRaises(AssertionError, ServiceErrorDescription, code=1234, message=u'')


class TestServiceResponse(unittest.TestCase):
    def test_create(self):
        response = ServiceResponse(True, data=u'<root><tree>1234</tree></root>')
        self.assertTrue(response.success)
        self.assertEqual(0, len(response.errors))
        self.assertEqual(etree.tostring(response.data), u'<root><tree>1234</tree></root>')
        
        response = ServiceResponse(False, errors=[ServiceErrorDescription(10, u'1234')])
        self.assertFalse(response.success)
        self.assertEqual(1, len(response.errors))
        self.assertEqual(10, response.errors[0].code)
        self.assertTrue(response.data is None)

    def test_create_error(self):
        self.assertRaises(AssertionError, ServiceResponse, success=1234, data=u'<root/>')
        self.assertRaises(AssertionError, ServiceResponse, success=True, errors=u'1234')

        self.assertRaises(ValueError, ServiceResponse, success=True, errors=[1, 2, 3], data=u'<root/>')
        self.assertRaises(ValueError, ServiceResponse, success=True, errors=[], data=None)

        self.assertRaises(ValueError, ServiceResponse, success=False, errors=[], data=None)
        self.assertRaises(ValueError, ServiceResponse, success=False, errors=[1, 2, 3], data=u'<root/>')

    def test_to_etree(self):
        response = ServiceResponse(True, data=u'<root/>')
        data = response.to_etree()
        self.assertEqual(len(data.xpath('/root')), 1)

        response = ServiceResponse(False, errors=[ServiceErrorDescription(10, u'1234', u'xyz', u'1234567890', u'qwe')])
        data = response.to_etree()
        self.assertEqual(len(data.xpath('/errors/error')), 1)
        self.assertEqual(data.xpath('/errors/error/@code')[0], '10')
        self.assertEqual(data.xpath('/errors/error/@message')[0], '1234')
        self.assertEqual(data.xpath('/errors/error/@value')[0], 'xyz')
        self.assertEqual(data.xpath('/errors/error/@type')[0], 'qwe')
        self.assertEqual(data.xpath('/errors/error[@code="10"]/dbg/text()')[0], '1234567890')


class TestSuccessServiceResponse(unittest.TestCase):
    def test_create(self):
        response = SuccessServiceResponse(etree.Element('root'))
        self.assertTrue(response.success)
        self.assertEqual(0, len(response.errors))
        self.assertEqual(etree.tostring(response.data), u'<root/>')
    
    def test_to_etree(self):
        response = SuccessServiceResponse(etree.Element('root'))
        data = response.to_etree()

        self.assertEqual(len(data.xpath('/root')), 1)

    def test_raw_to_etree(self):
        response = SuccessServiceResponse(u'<root><tree>1234</tree></root>')
        data = response.to_etree()

        self.assertEqual(len(data.xpath('/root/tree')), 1)
        self.assertEqual(data.xpath('/root/tree/text()')[0], '1234')


class TestFailureServiceResponse(unittest.TestCase):
    def test_create(self):
        response = FailureServiceResponse([ServiceErrorDescription(10, u'1234')])
        self.assertFalse(response.success)
        self.assertEqual(1, len(response.errors))
        self.assertEqual(10, response.errors[0].code)
        self.assertTrue(response.data is None)

    def test_to_etree(self):
        response = FailureServiceResponse([ServiceErrorDescription(10, u'1234', u'xyz', u'1234567890', u'qwe')])
        data = response.to_etree()

        self.assertEqual(len(data.xpath('/errors/error')), 1)

        self.assertEqual(data.xpath('/errors/error/@code')[0], '10')
        self.assertEqual(data.xpath('/errors/error/@message')[0], '1234')
        self.assertEqual(data.xpath('/errors/error/@value')[0], 'xyz')
        self.assertEqual(data.xpath('/errors/error/@type')[0], 'qwe')
        self.assertEqual(data.xpath('/errors/error[@code="10"]/dbg/text()')[0], '1234567890')


class TestXMLServiceErrorReporter(testlib.TestCaseWithCP):
    u"""Тест обработчика ошибок сервисов"""

    def setUp(self):
        super(TestXMLServiceErrorReporter, self).setUp()
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            cherrypy.response.headers[key] = 'Test-%s' % key
        cherrypy.response.headers['Content-Type'] = 'text/plain'
        cherrypy.response.status = 100

    def test_param_error(self):
        errs = [
            ServiceErrorDescription(100, u'Error 1', u'param1'),
            ServiceErrorDescription(101, u'Error 2', u'param2')
        ]
        exception = ParamsValidationError(errs)

        reporter = XMLServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)

        response = etree.fromstring(raw_response)

        self.assertEqual(len(response.xpath('/errors/error')), 2)

        self.assertEqual(response.xpath('/errors/error/@code')[0], '100')
        self.assertEqual(response.xpath('/errors/error/@message')[0], 'Error 1')
        self.assertEqual(response.xpath('/errors/error/@value')[0], 'param1')
        self.assertEqual(response.xpath('/errors/error/@type')[0], 'ParamsValidationError')
        self.assertEqual(response.xpath('/errors/error/@code')[1], '101')
        self.assertEqual(response.xpath('/errors/error/@message')[1], 'Error 2')
        self.assertEqual(response.xpath('/errors/error/@value')[1], 'param2')
        self.assertEqual(response.xpath('/errors/error/@type')[1], 'ParamsValidationError')

        self.assertEqual(response.xpath('/errors/error[@code="100"]/dbg'), [])
        self.assertEqual(response.xpath('/errors/error[@code="101"]/dbg'), [])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('text/xml', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_request_error(self):
        err = ServiceErrorDescription(200, u'Error 3')
        exception = MalformedRequestError(err)

        reporter = XMLServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = etree.fromstring(raw_response)

        self.assertEqual(len(response.xpath('/errors/error')), 1)

        self.assertEqual(response.xpath('/errors/error/@code')[0], '200')
        self.assertEqual(response.xpath('/errors/error/@message')[0], 'Error 3')
        self.assertEqual(response.xpath('/errors/error/@value'), [])
        self.assertEqual(response.xpath('/errors/error/@type')[0], 'MalformedRequestError')
        self.assertEqual(response.xpath('/errors/error[@code="200"]/dbg'), [])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('text/xml', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_internal_service_error(self):
        err = ServiceErrorDescription(300, u'Error 4')
        exception = InternalServiceError(err)

        reporter = XMLServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = etree.fromstring(raw_response)

        self.assertEqual(len(response.xpath('/errors/error')), 1)

        self.assertEqual(response.xpath('/errors/error/@code')[0], '300')
        self.assertEqual(response.xpath('/errors/error/@message')[0], 'Error 4')
        self.assertEqual(response.xpath('/errors/error/@value'), [])
        self.assertEqual(response.xpath('/errors/error/@type')[0], 'InternalServiceError')
        self.assertEqual(response.xpath('/errors/error[@code="200"]/dbg'), [])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('text/xml', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_unexpected_error(self):
        exc = None
        tb = None
        try:
            raise ValueError('DB access error')
        except:
            tmp = sys.exc_info()
            exc = tmp[1]
            tb = tmp[2]
        
        reporter = XMLServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exc, tb)
        response = etree.fromstring(raw_response)

        self.assertEqual(len(response.xpath('/errors/error')), 1)

        self.assertEqual(response.xpath('/errors/error/@code')[0], '300000')
        self.assertEqual(response.xpath('/errors/error/@message')[0], 'DB access error')
        self.assertEqual(response.xpath('/errors/error/@value'), [])
        self.assertEqual(response.xpath('/errors/error/@type')[0], 'ValueError')
        #self.assertEqual(len(response.xpath('/errors/error[@code="300000"]/dbg')), 1)
        self.assertEqual(len(response.xpath('/errors/error[@code="300000"]/dbg')), 0)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('text/xml', cherrypy.response.headers['Content-Type'])

        self.assertEqual(500, cherrypy.response.status)

    def test_unexpected_error_message(self):
        exc = None
        tb = None
        try:
            raise ValueError
        except:
            tmp = sys.exc_info()
            exc = tmp[1]
            tb = tmp[2]
        
        reporter = XMLServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exc, tb)
        response = etree.fromstring(raw_response)

        self.assertEqual(len(response.xpath('/errors/error')), 1)

        self.assertEqual(response.xpath('/errors/error/@code')[0], '300000')
        self.assertEqual(response.xpath('/errors/error/@message')[0], 'Unhandled error')
        self.assertEqual(response.xpath('/errors/error/@value'), [])
        self.assertEqual(response.xpath('/errors/error/@type')[0], 'ValueError')
        #self.assertEqual(len(response.xpath('/errors/error[@code="300000"]/dbg')), 1)
        self.assertEqual(len(response.xpath('/errors/error[@code="300000"]/dbg')), 0)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('text/xml', cherrypy.response.headers['Content-Type'])

        self.assertEqual(500, cherrypy.response.status)


class TestCommonXMLService(testlib.TestCaseWithCP):
    u"""Тест базового сервиса"""

    def setUp(self):
        super(TestCommonXMLService, self).setUp()
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            cherrypy.response.headers[key] = 'Test-%s' % key
        cherrypy.response.headers['Content-Type'] = 'text/plain'

    def test_render_cachable(self):
        resp = SuccessServiceResponse(etree.Element('root'));
        svc = ServiceMock()
        svc._cacheable = True
        svc.render(resp.to_etree())

        self.assertFalse('Cache-Control' in cherrypy.response.headers)
        self.assertFalse('Expires' in cherrypy.response.headers)
        self.assertTrue('Last-Modified' in cherrypy.response.headers)
        self.assertTrue('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual(time.strftime('%a, %d %b %Y %H:%M:%S GMT',
           time.gmtime()), cherrypy.response.headers['Last-Modified'])
        self.assertEqual('yes', cherrypy.response.headers['X-Cacheable'])

    def test_render_notcachable(self):
        resp = SuccessServiceResponse(etree.Element('root'));
        svc = ServiceMock()
        svc._cacheable = False
        svc.render(resp.to_etree())

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT',
                         cherrypy.response.headers['Expires'])


if __name__ == '__main__':
    testoob.main()
