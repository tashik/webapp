# -*- coding: utf-8 -*-

"""
$Id: test_base_json.py 4009 2014-04-07 18:03:54Z apinsky $
"""


from zope.component import provideUtility
from zope.component import queryUtility, getUtility
from zope.i18n.interfaces import INegotiator, ILanguageAvailability

from pyramid.i18n.negotiator import LanguageAvailability, Negotiator
from pyramid.tests import testlib

from services.base.json_base import (ServiceErrorDescription, ServiceResponse, SuccessServiceResponse, FailureServiceResponse,
                                     ParamsValidationError, MalformedRequestError, InternalServiceError,
                                     JSONServiceErrorReporter, CommonJSONService)

import sys
import testoob
import time
import unittest
import cherrypy
import json
import config


class ServiceMock(CommonJSONService):
    pass


class TestServiceError(unittest.TestCase):
    u"""Тест класса ошибки сервисов"""

    def test_create(self):
        error = ServiceErrorDescription(1234, u"xyz")
        self.assertEqual(1234, error.code)
        self.assertEqual(u"xyz", error.message)
        self.assertEqual(None, error.value)
        self.assertEqual(None, error.dbg)

        error = ServiceErrorDescription(code=1234, message=u"xyz", value=u"abcd", dbg=u"5678", error_type=u"qwe")
        self.assertEqual(1234, error.code)
        self.assertEqual(u"xyz", error.message)
        self.assertEqual(u"abcd", error.value)
        self.assertEqual(u"5678", error.dbg)
        self.assertEqual(u"qwe", error.error_type)

    def test_create_error(self):
        self.assertRaises(AssertionError, ServiceErrorDescription, code="1234", message=u"xyz")
        self.assertRaises(AssertionError, ServiceErrorDescription, code=1234, message=None)
        self.assertRaises(AssertionError, ServiceErrorDescription, code=-1234, message=u"1234")
        self.assertRaises(AssertionError, ServiceErrorDescription, code=1234, message=u"")


class TestServiceResponse(unittest.TestCase):
    u"""Тест класса ошибки сервисов"""

    def test_create(self):
        response = ServiceResponse(True, data=u"1234")
        self.assertTrue(response.success)
        self.assertEqual(0, len(response.errors))
        self.assertEqual(u"1234", response.data)

        response = ServiceResponse(False, errors=[ServiceErrorDescription(10, u"1234")])
        self.assertFalse(response.success)
        self.assertEqual(1, len(response.errors))
        self.assertEqual(10, response.errors[0].code)
        self.assertTrue(response.data is None)

    def test_create_error(self):
        self.assertRaises(AssertionError, ServiceResponse, success=1234, data=u"1234")
        self.assertRaises(AssertionError, ServiceResponse, success=True, errors=u"1234")

        self.assertRaises(ValueError, ServiceResponse, success=True, errors=[1, 2, 3], data=u"1234")
        self.assertRaises(ValueError, ServiceResponse, success=True, errors=[], data=None)

        self.assertRaises(ValueError, ServiceResponse, success=False, errors=[], data=None)
        self.assertRaises(ValueError, ServiceResponse, success=False, errors=[1, 2, 3], data="1234")

    def test_to_dict(self):
        response = ServiceResponse(True, data=u"1234")
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(True, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))
        self.assertEqual(0, len(data['errors']))
        self.assertEqual(u"1234", data['data'])

        response = ServiceResponse(False, errors=[ServiceErrorDescription(10, u"1234", u"xyz", "1234567890", u"qwe")])
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(False, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))

        self.assertEqual(1, len(data['errors']))
        error = data['errors'][0]
        self.assertTrue(isinstance(error, dict))
        self.assertEqual(5, len(error))
        self.assertEqual(10, error['code'])
        self.assertEqual(u"1234", error['message'])
        self.assertEqual(u"xyz", error['value'])
        self.assertEqual("1234567890", error['dbg'])
        self.assertEqual(u"qwe", error['type'])

        self.assertTrue(data['data'] is None)


class TestSuccessServiceResponse(unittest.TestCase):
    def test_create(self):
        response = SuccessServiceResponse(u"1234")
        self.assertTrue(response.success)
        self.assertEqual(0, len(response.errors))
        self.assertEqual(u"1234", response.data)

    def test_to_dict(self):
        response = SuccessServiceResponse(u"1234")
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(True, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))
        self.assertEqual(0, len(data['errors']))
        self.assertEqual(u"1234", data['data'])


class TestFailureServiceResponse(unittest.TestCase):
    def test_create(self):
        response = FailureServiceResponse([ServiceErrorDescription(10, u"1234")])
        self.assertFalse(response.success)
        self.assertEqual(1, len(response.errors))
        self.assertEqual(10, response.errors[0].code)
        self.assertTrue(response.data is None)

    def test_to_dict(self):
        response = FailureServiceResponse([ServiceErrorDescription(10, u"1234", u"xyz", "1234567890", u"qwe")])
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(False, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))

        self.assertEqual(1, len(data['errors']))
        error = data['errors'][0]
        self.assertTrue(isinstance(error, dict))
        self.assertEqual(5, len(error))
        self.assertEqual(10, error['code'])
        self.assertEqual(u"1234", error['message'])
        self.assertEqual(u"xyz", error['value'])
        self.assertEqual("1234567890", error['dbg'])
        self.assertEqual(u"qwe", error['type'])

        self.assertTrue(data['data'] is None)


class TestJSONServiceErrorReporter(testlib.TestCaseWithCP):
    u"""Тест обработчика ошибок сервисов"""

    def setUp(self):
        super(TestJSONServiceErrorReporter, self).setUp()
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            cherrypy.response.headers[key] = 'Test-%s' % key
        cherrypy.response.headers['Content-Type'] = 'text/plain'
        cherrypy.response.status = 100

    def test_param_error(self):
        errs = [
            ServiceErrorDescription(100, u"Error 1", u"param1"),
            ServiceErrorDescription(101, u"Error 2", u"param2")
        ]
        exception = ParamsValidationError(errs)

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(2, len(response['errors']))

        self.assertEqual(100, response['errors'][0]['code'])
        self.assertEqual("Error 1", response['errors'][0]['message'])
        self.assertEqual("param1", response['errors'][0]['value'])
        #self.assertTrue(response['errors'][0]['dbg'] is None)
        self.assertNotIn('dbg', response['errors'][0])
        self.assertEqual('ParamsValidationError', response['errors'][0]['type'])
        self.assertEqual(101, response['errors'][1]['code'])
        self.assertEqual("Error 2", response['errors'][1]['message'])
        self.assertEqual("param2", response['errors'][1]['value'])
        #self.assertTrue(response['errors'][1]['dbg'] is None)
        self.assertNotIn('dbg', response['errors'][1])
        self.assertEqual('ParamsValidationError', response['errors'][1]['type'])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json, charset=utf-8', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_request_error(self):
        err = ServiceErrorDescription(200, u"Error 3")
        exception = MalformedRequestError(err)

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(200, response['errors'][0]['code'])
        self.assertEqual("Error 3", response['errors'][0]['message'])
        #self.assertTrue(response['errors'][0]['value'] is None)
        #self.assertTrue(response['errors'][0]['dbg'] is None)
        self.assertNotIn('value', response['errors'][0])
        self.assertNotIn('dbg', response['errors'][0])
        self.assertEqual('MalformedRequestError', response['errors'][0]['type'])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json, charset=utf-8', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_service_error(self):
        err = ServiceErrorDescription(300, u"Error 4")
        exception = InternalServiceError(err)

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(300, response['errors'][0]['code'])
        self.assertEqual("Error 4", response['errors'][0]['message'])
        #self.assertTrue(response['errors'][0]['value'] is None)
        #self.assertTrue(response['errors'][0]['dbg'] is None)
        self.assertNotIn('value', response['errors'][0])
        self.assertNotIn('dbg', response['errors'][0])
        self.assertEqual('InternalServiceError', response['errors'][0]['type'])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json, charset=utf-8', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_unexpected_error(self):
        exc = None
        tb = None
        try:
            raise ValueError("DB access error")
        except:
            tmp = sys.exc_info()
            exc = tmp[1]
            tb = tmp[2]

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exc, tb)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(300000, response['errors'][0]['code'])
        self.assertEqual("DB access error", response['errors'][0]['message'])
        #self.assertTrue(response['errors'][0]['value'] is None)
        #self.assertFalse(response['errors'][0]['dbg'] is None)
        self.assertNotIn('value', response['errors'][0])
        self.assertNotIn('dbg', response['errors'][0])
        self.assertEqual('ValueError', response['errors'][0]['type'])

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json, charset=utf-8', cherrypy.response.headers['Content-Type'])

        self.assertEqual(500, cherrypy.response.status)

    def test_unexpected_error_message(self):
        exc = None
        tb = None
        try:
            raise ValueError
        except:
            tmp = sys.exc_info()
            exc = tmp[1]
            tb = tmp[2]

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exc, tb)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(300000, response['errors'][0]['code'])
        self.assertEqual("Unhandled error", response['errors'][0]['message'])
        #self.assertTrue(response['errors'][0]['value'] is None)
        #self.assertFalse(response['errors'][0]['dbg'] is None)
        self.assertNotIn('value', response['errors'][0])
        self.assertNotIn('dbg', response['errors'][0])
    
        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json, charset=utf-8', cherrypy.response.headers['Content-Type'])

        self.assertEqual(500, cherrypy.response.status)


class TestCommonJSONService(testlib.TestCaseWithCP):
    u"""Тест обработчика ошибок сервисов"""

    def setUp(self):
        super(TestCommonJSONService, self).setUp()
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            cherrypy.response.headers[key] = 'Test-%s' % key
        cherrypy.response.headers['Content-Type'] = 'text/plain'

    def test_render_cachable(self):
        resp = SuccessServiceResponse("1234");
        svc = ServiceMock()
        svc._cacheable = True
        svc.render(resp.to_dict())
        self.assertFalse('Cache-Control' in cherrypy.response.headers)
        self.assertFalse('Expires' in cherrypy.response.headers)
        self.assertTrue('Last-Modified' in cherrypy.response.headers)
        self.assertTrue('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual(time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime()), cherrypy.response.headers['Last-Modified'])
        self.assertEqual('yes', cherrypy.response.headers['X-Cacheable'])

    def test_render_notcachable(self):
        resp = SuccessServiceResponse("1234");
        svc = ServiceMock()
        svc._cacheable = False
        svc.render(resp.to_dict())
        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

# class TestDecorators(unittest.TestCase):

    # def setUp(self):
        # super(TestDecorators, self).setUp()
        # provideUtility(LanguageAvailability(['ru', 'en', 'jp']))
        # provideUtility(Negotiator())

    # @languageaware
    # def _test_method(self, *args, **kwargs):
        # return args, kwargs

    # def test_languageaware(self):
        # args, kwargs = self._test_method()
        # self.assertEqual(2, len(args))
        # self.assertTrue(args[0] is None)
        # self.assertEqual('ru', args[1])

        # args, kwargs = self._test_method(lang='')
        # self.assertEqual(2, len(args))
        # self.assertTrue(args[0] is None)
        # self.assertEqual('ru', args[1])

        # args, kwargs = self._test_method(lang='ru')
        # self.assertEqual(2, len(args))
        # self.assertEqual('ru', args[0])
        # self.assertEqual('ru', args[1])

        # args, kwargs = self._test_method(lang='en')
        # self.assertEqual(2, len(args))
        # self.assertEqual('en', args[0])
        # self.assertEqual('en', args[1])

        # args, kwargs = self._test_method(lang='jp')
        # self.assertEqual(2, len(args))
        # self.assertEqual('jp', args[0])
        # self.assertEqual('jp', args[1])

        # args, kwargs = self._test_method(lang='fr')
        # self.assertEqual(2, len(args))
        # self.assertEqual('fr', args[0])
        # self.assertEqual('ru', args[1])


if __name__ == "__main__":
    testoob.main()
