# -*- coding: utf-8 -*-


import json
import testoob
import unittest

from lxml import etree

from pyramid.tests import testlib

from services.base.converter import xml2json, etree_to_dict
from services.base.json_base import (CommonJSONService, ParamsValidationError,
                                     MalformedRequestError, InternalServiceError)
from services.base.xml_base import (CommonXMLService,
                                    ParamsValidationError as XMLParamsValidationError,
                                    MalformedRequestError as XMLMalformedRequestError,
                                    InternalServiceError as XMLInternalServiceError,
                                    ServiceErrorDescription as XMLServiceErrorDescription)


class _TestXMLService(CommonXMLService):
    def _test_method(self, x, *args, **kwargs):
        if x == 100:
            raise XMLParamsValidationError([XMLServiceErrorDescription(100, '100')])
        elif x == 200:
            raise XMLMalformedRequestError(XMLServiceErrorDescription(200, '200'))
        elif x == 300:
            raise XMLInternalServiceError(XMLServiceErrorDescription(300, '300'))

        return u"<?xml version='1.0' encoding='utf-8'?><root><leaf>%s</leaf></root>" % x


class _TestJSONService(CommonJSONService):
    @xml2json
    def _test_method(self, x, *args, **kwargs):
        xml = _TestXMLService()._test_method(x, *args, **kwargs)
        return xml.encode('utf-8')


class TestXML2JSON(testlib.TestCaseWithCP):
    def setUp(self):
        super(TestXML2JSON, self).setUp()
        self.s = _TestJSONService()

    def test_xml2json(self):
        response = self.s._test_method(1)
        json_ob = json.loads(response)
        self.assertEqual(json_ob['isSuccess'], True)
        self.assertEqual(json_ob['errors'], [])
        self.assertTrue('leaf' in json_ob['data'])

    def test_xml2json_errors(self):
        self.assertRaises(ParamsValidationError, self.s._test_method, 100)
        self.assertRaises(MalformedRequestError, self.s._test_method, 200)
        self.assertRaises(InternalServiceError, self.s._test_method, 300)


class TestConverter(unittest.TestCase):
    def setUp(self):
        self.xml = u"""<?xml version='1.0' encoding='utf-8'?>
<cities lang="ru">
  <country code="RU">
    <city lat="10" lon="20.20">
      <name xml:lang="ru">Москва</name>
      <name xml:lang="en">Moscow</name>
      <capital/>
    </city>
    <city lat="20" lon="30.20">
      <name xml:lang="ru">Санкт-Петербург</name>
      <name xml:lang="en">Sankt-Peterburg</name>
    </city>
  </country>
  <country code="DE">
    <city lat="-50">
      <name xml:lang="ru">Берлин</name>
      <name xml:lang="en">Berlin</name>
      <capital/>
      <custom attr="Y" />
    </city>
  </country>
  <country code="FR">
    <city>
      <name xml:lang="ru">Марсель</name>
      <name xml:lang="en">Marseille</name>
    </city>
  </country>
</cities>"""

    def test_etree_to_dict(self):
        root = etree.fromstring(self.xml.encode('utf-8'))
        d = etree_to_dict(root)

        self.assertTrue('country' in d)
        self.assertEqual(d['lang'], 'ru')
        self.assertEqual(len(d['country']), 3)

        country = d['country'][0]
        self.assertEqual(country['code'], 'RU')
        self.assertEqual(len(country['city']), 2)

        city = country['city'][0]
        self.assertTrue('capital' in city)
        self.assertTrue('lat' in city)
        self.assertTrue('lon' in city)
        self.assertTrue('name' in city)
        self.assertEqual(city['capital'], True)
        self.assertEqual(city['lat'], '10')
        self.assertEqual(city['lon'], '20.20')
        self.assertEqual(city['name'][0]['lang'], 'ru')
        self.assertEqual(city['name'][0]['value'], u'Москва')
        self.assertEqual(city['name'][1]['lang'], 'en')
        self.assertEqual(city['name'][1]['value'], u'Moscow')

        country = d['country'][1]
        city = country['city'][0]
        self.assertTrue('custom' in city)
        self.assertEqual(city['custom'][0]['attr'], 'Y')


if __name__ == '__main__':
    testoob.main()

