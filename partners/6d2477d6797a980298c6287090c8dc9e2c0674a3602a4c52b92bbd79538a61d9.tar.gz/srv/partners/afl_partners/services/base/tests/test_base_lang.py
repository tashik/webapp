# -*- coding: utf-8 -*-

"""
$Id: test_base_lang.py 4051 2014-04-11 06:03:28Z apinsky $
"""


from zope.component import provideUtility
from zope.component import queryUtility, getUtility
from zope.component import globalregistry
from zope.i18n.interfaces import ILanguageAvailability, INegotiator, IUserPreferredLanguages

from pyramid.app.i18n import UserPreferredLanguages
from pyramid.i18n.negotiator import LanguageAvailability, Negotiator, CPCookieUserPreferredLanguages
from pyramid.i18n.negotiator import PREFERRED_LANG_KEY
from pyramid.tests import testlib

from services.base.lang import languageaware


import testoob
import cherrypy
from pyramid.utils import Config as config
from services.base.xml_base import SuccessServiceResponse, CommonXMLService
from lxml import etree as et


class TestXMLService(CommonXMLService):
    @languageaware
    def _test(self, mesagge_lang, errors_lang, x, **kwargs):
        return x


class TestLanguageAware(testlib.TestCaseWithCP):
    u"""Тест декоратора установки языков"""
    
    def setUp(self):
        super(TestLanguageAware, self).setUp()
        
        langs = ['ru', 'en', 'jp']
        provideUtility(LanguageAvailability(langs), ILanguageAvailability)
        provideUtility(UserPreferredLanguages(), IUserPreferredLanguages)
        
        self._cookie_key = config.APP_COOKIE + PREFERRED_LANG_KEY
        cherrypy.request.params[PREFERRED_LANG_KEY] = 'de'
        cherrypy.request.cookie.pop(self._cookie_key, None)
        cherrypy.response.cookie.pop(self._cookie_key, None)
        
        self._old_default_lang = config.DEFAULT_SERVICE_LANG
        config.DEFAULT_SERVICE_LANG = 'en'
    
    def tearDown(self):
        config.DEFAULT_SERVICE_LANG = self._old_default_lang
        globalregistry.base.unregisterUtility(provided=ILanguageAvailability)
        globalregistry.base.unregisterUtility(provided=IUserPreferredLanguages)
        super(TestLanguageAware, self).tearDown()
    
    @languageaware
    def _test_method(self, *args, **kwargs):
        return args, kwargs
    
    def test_languageaware_no_params(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method()
        self.assertEqual(2, len(args))
        self.assertTrue(args[0] is None)
        self.assertEqual('en', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('en', user_langs[0])
    
    def test_languageaware_empty_lang(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(lang='')
        self.assertEqual(2, len(args))
        self.assertTrue(args[0] is None)
        self.assertEqual('en', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('en', user_langs[0])
    
    def test_languageaware_known_ru(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(lang='ru')
        self.assertEqual(2, len(args))
        self.assertEqual('ru', args[0])
        self.assertEqual('ru', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('ru', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('ru', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('ru', user_langs[0])
    
    def test_languageaware_known_en(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(lang='en')
        self.assertEqual(2, len(args))
        self.assertEqual('en', args[0])
        self.assertEqual('en', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('en', user_langs[0])
    
    def test_languageaware_known_jp(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(lang='jp')
        self.assertEqual(2, len(args))
        self.assertEqual('jp', args[0])
        self.assertEqual('jp', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('jp', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('jp', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('jp', user_langs[0])
    
    def test_languageaware_unknown(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(lang='fr')

        self.assertEqual(2, len(args))
        self.assertIsNone(args[0])
        self.assertEqual('en', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('en', user_langs[0])

    def test_languageaware_known_en_xml(self):
        t = TestXMLService()
        response = t._test("<root_tag/>", lang="en")
        self.assertEqual(
            response,
            "<root_tag lang=\"en\"/>"
        )
        r = SuccessServiceResponse(et.fromstring("<root_tag/>"))
        response = t._test(r, lang="en")
        self.assertEqual(
            response,
            "<?xml version='1.0' encoding='utf-8'?>"
            "\n<root_tag lang=\"en\"/>\n"
        )
  
        
class TestLanguageAware2(testlib.TestCaseWithCP):
    u"""Тест декоратора установки языков в условиях отсутствия LanguageAvailability"""
    
    def setUp(self):
        super(TestLanguageAware2, self).setUp()
        
        provideUtility(UserPreferredLanguages(), IUserPreferredLanguages)
        
        self._cookie_key = config.APP_COOKIE + PREFERRED_LANG_KEY
        cherrypy.request.params[PREFERRED_LANG_KEY] = 'de'
        cherrypy.request.cookie.pop(self._cookie_key, None)
        cherrypy.response.cookie.pop(self._cookie_key, None)
        
        self._old_default_lang = config.DEFAULT_SERVICE_LANG
        config.DEFAULT_SERVICE_LANG = 'en'
    
    def tearDown(self):
        config.DEFAULT_SERVICE_LANG = self._old_default_lang
        globalregistry.base.unregisterUtility(provided=IUserPreferredLanguages)
        super(TestLanguageAware2, self).tearDown()
    
    @languageaware
    def _test_method(self, *args, **kwargs):
        return args, kwargs
    
    def test_no_avaiblelanguages(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(lang='ru')
        self.assertEqual(2, len(args))
        self.assertEqual('ru', args[0])
        self.assertEqual('en', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('en', user_langs[0])


class TestLanguageAwareErrors(testlib.TestCaseWithCP):
    u"""Тест декоратора установки языков в условиях ошибочных данных"""
    
    def setUp(self):
        super(TestLanguageAwareErrors, self).setUp()
        
        langs = ['ru', 'en', 'jp']
        provideUtility(LanguageAvailability(langs), ILanguageAvailability)
        provideUtility(UserPreferredLanguages(), IUserPreferredLanguages)
        
        self._cookie_key = config.APP_COOKIE + PREFERRED_LANG_KEY
        cherrypy.request.params[PREFERRED_LANG_KEY] = 'de'
        cherrypy.request.cookie.pop(self._cookie_key, None)
        cherrypy.response.cookie.pop(self._cookie_key, None)
        
        self._old_default_lang = config.DEFAULT_SERVICE_LANG
        config.DEFAULT_SERVICE_LANG = 'en'
    
    def tearDown(self):
        config.DEFAULT_SERVICE_LANG = self._old_default_lang
        globalregistry.base.unregisterUtility(provided=ILanguageAvailability)
        globalregistry.base.unregisterUtility(provided=IUserPreferredLanguages)
        super(TestLanguageAwareErrors, self).tearDown()
    
    @languageaware
    def _test_method(self, *args, **kwargs):
        return args, kwargs
    
    def test_languageaware_explicit_params(self):
        self.assertTrue(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertEqual('de', cherrypy.request.params[PREFERRED_LANG_KEY])
        self.assertFalse(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertFalse(cherrypy.response.cookie.has_key(self._cookie_key))
        
        args, kwargs = self._test_method(message_lang='es', error_lang='nl')
        self.assertEqual(2, len(args))
        self.assertTrue(args[0] is None)
        self.assertEqual('en', args[1])
        
        self.assertFalse(PREFERRED_LANG_KEY in cherrypy.request.params)
        self.assertTrue(cherrypy.request.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.request.cookie[self._cookie_key].value)
        self.assertTrue(cherrypy.response.cookie.has_key(self._cookie_key))
        self.assertEqual('en', cherrypy.response.cookie[self._cookie_key].value)
        
        util = queryUtility(IUserPreferredLanguages)
        user_langs = util.getPreferredLanguages()
        self.assertEqual(1, len(user_langs))
        self.assertEqual('en', user_langs[0])


if __name__ == "__main__":
    testoob.main()
