# -*- coding: utf-8 -*-

"""
$Id: lang.py 4441 2014-05-22 08:02:50Z apinsky $
"""

from zope.component import queryUtility
from zope.i18n.interfaces import ILanguageAvailability

from pyramid.i18n.negotiator import CPCookieUserPreferredLanguages
from pyramid.i18n.negotiator import PREFERRED_LANG_KEY

from services.base.xml_base import ServiceResponse

from lxml import etree as et
import cherrypy
import config


def languageaware(method):
    u"""
        Декортатор проверяет наличие в запросе параметра lang:
        * если он есть, то устанавливает язык результата и язык ошибок в соответствие с ним
        * если его нет, то устанавливает язык ошибок в соответствие с текущим окружением, а язык сообщений оставляет неопределенным
        У метода, на котором применяется данный декаратор, в первые два аргумента передаются коды языков:
        * message_lang - запрашиваемый язык текстовых данных, предназначенных для отображения пользователям,
                         может быть None
        * error_lang - запрашиваемый язык сообщений об ошибках,
                       гарантированно имеет значение, отличное от None
    """
    def decorator(self, *args, **kwargs):
        util = None
        lang = kwargs.pop('lang', None)
        if not lang:
            message_lang = None
            error_lang = config.DEFAULT_SERVICE_LANG
        else:
            lang = lang.lower()
            message_lang = lang
            error_lang = lang
            util = queryUtility(ILanguageAvailability)
            if not util:
                error_lang = config.DEFAULT_SERVICE_LANG
            else:
                available = []
                for elem in util.getAvailableLanguages():
                    available.append(elem[0] if isinstance(elem, tuple) else elem)
                if not lang in available:
                    error_lang = config.DEFAULT_SERVICE_LANG
                    message_lang = None
        prefix = config.APP_COOKIE
        one_year = 60 * 60 * 24 * 365
        CPCookieUserPreferredLanguages().setPreferredLanguages(error_lang)
        cp_params = cherrypy.request.params
        if PREFERRED_LANG_KEY in cp_params:
            cp_params.pop(PREFERRED_LANG_KEY)
        response = method(self, message_lang, error_lang, *args, **kwargs)
        if lang is not None and util and lang in available:
            # Дальнейшее -- для XML. Для JSON надо писать отдельно
            if isinstance(response, basestring) and response.startswith("<"):
                xml = et.fromstring(response)
                xml.set("lang", lang)
                response = et.tostring(xml)
            elif isinstance(response, ServiceResponse):
                response.data.set("lang", lang)
                response = self.render(response.to_etree())
        elif isinstance(response, ServiceResponse):
            response = self.render(response.to_etree())
        return response
    return decorator

