# -*- coding: utf-8 -*-

import re
from lxml import etree

from services.base.json_base import (ParamsValidationError, MalformedRequestError,
                                     InternalServiceError, ServiceErrorDescription,
                                     SuccessServiceResponse)
from services.base.xml_base import (ParamsValidationError as XMLParamsValidationError,
                                    MalformedRequestError as XMLMalformedRequestError,
                                    InternalServiceError as XMLInternalServiceError)

def camelcase_to_underscores(name):
    u"""Преобразование из camelCase в имя_через_подчёркивание."""
    tmp = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', tmp).lower()

def etree_to_dict(el):
    def clean_attr(name):
        if name[0] == '{':
            uri, tag = name[1:].split('}')
            return tag
        else:
            return name

    d = {}
    d.update((clean_attr(k), v) for k, v in el.attrib.iteritems())

    for child in el.iterchildren():
        tag_name = child.tag
        d.setdefault(tag_name, [])
        d[tag_name].append(etree_to_dict(child))
        if not any(d[tag_name]):
            d[tag_name] = True

    if el.text and el.text.strip():
        d['value'] = el.text

    return d

def handle_xml_errors(fnc, *args, **kwargs):
    try:
        result = fnc(*args, **kwargs)
    except XMLParamsValidationError, e:
        errors = []
        for error in e.error_descs:
            errors.append(ServiceErrorDescription(error.code,
                                                  error.message))
        raise ParamsValidationError(errors)
    except XMLMalformedRequestError, e:
        error = e.error_desc
        raise MalformedRequestError(ServiceErrorDescription(error.code,
                                                            error.message))
    except XMLInternalServiceError, e:
        error = e.error_desc
        raise InternalServiceError(ServiceErrorDescription(error.code,
                                                           error.message))
    return result

def xml2json(method):
    def decorator(self, *args, **kwargs):
        response = handle_xml_errors(method, *([self] + list(args)), **kwargs)

        root = etree.fromstring(response)
        d = etree_to_dict(root)
        svc_response = SuccessServiceResponse(d)
        response = self.render(svc_response.to_dict())

        return response
    return decorator

