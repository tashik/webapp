# -*- coding: utf-8 -*-

import cherrypy
import time

from lxml import etree
from lxml.builder import E

from zope.interface.declarations import implements
from zope.interface.interface import Interface

from pyramid.exc import PyramidException
from pyramid.ui.page import CPService, Service
from pyramid.ui.error.report import StdErrorReporter, fmt_traceback

from . import ErrorHandling


class ServiceErrorDescription(object):
    u"""Описание ошибки сервиса"""

    def __init__(self, code, message, value=None, dbg=None, error_type=None):
        assert isinstance(code, int)
        assert code > 0
        assert isinstance(message, basestring)
        assert len(message) > 0
        assert (value is None) or isinstance(value, basestring)
        assert (dbg is None) or isinstance(dbg, basestring)
        assert (error_type is None) or isinstance(error_type, basestring)
        self.code = code
        self.message = message
        self.value = value
        self.dbg = dbg
        self.error_type = error_type


class ServiceResponse(object):
    u"""Ответ сервиса"""

    def __init__(self, success, errors=None, data=None):
        assert isinstance(success, bool)
        assert (errors is None) or hasattr(errors, '__iter__')

        if isinstance(data, basestring):
            data = etree.fromstring(data)
        assert (data is None) or hasattr(data, '__iter__')

        has_errors = (not errors is None) and len(errors) > 0
        if success:
            if has_errors:
                raise ValueError, \
                    u'Successful response should not contain errors'
            if data is None:
                raise ValueError, u'Successful response should contain data'
        else:
            if not has_errors:
                raise ValueError, u'Failed response should contain errors'
            if not data is None:
                raise ValueError, u'Failed response should not contain data'

        self.success = success
        self.errors = []
        if errors is not None:
            for error in errors:
                if not isinstance(error, ServiceErrorDescription):
                    actual = '%s.%s' % (error.__module__,
                                        error.__class__.__name__)
                    raise ValueError, \
                        (u'Error should be an object of class '
                         u'ServiceErrorDescription but was %s') % actual
                self.errors.append(error)
        self.data = data

    def to_etree(self):
        if self.success:
            return self.data

        root = etree.Element('errors')
        for error in self.errors:
            error_el = etree.SubElement(root, 'error')
            error_el.attrib['code'] = unicode(error.code)
            error_el.attrib['message'] = unicode(error.message)
            if error.value is not None:
                error_el.attrib['value'] = unicode(error.value)
            if error.dbg is not None:
                error_el.append(E('dbg', unicode(str(error.dbg), 'utf-8')))
            if error.error_type is not None:
                error_el.attrib['type'] = str(error.error_type)
        return root


class SuccessServiceResponse(ServiceResponse):
    u"""Ответ успешно проведенного действия"""

    def __init__(self, data):
        super(SuccessServiceResponse, self).__init__(success=True, data=data)


class FailureServiceResponse(ServiceResponse):
    u"""Ответ ошибочного действия"""

    def __init__(self, errors):
        super(FailureServiceResponse, self).__init__(success=False,
                                                     errors=errors)


class ServiceError(PyramidException):
    msg = u'An error has occurred during service call'


class ParamsValidationError(ServiceError):
    def __init__(self, errors, **kw):
        assert isinstance(errors, (list, tuple, set, frozenset))
        self.error_descs = []
        for error in errors:
            assert isinstance(error, ServiceErrorDescription)
            if error.error_type is None:
                error.error_type = self.__class__.__name__
            self.error_descs.append(error)
        super(ParamsValidationError, self).__init__(**kw)


class MalformedRequestError(ServiceError):
    def __init__(self, error_desc, **kw):
        assert isinstance(error_desc, ServiceErrorDescription)
        if error_desc.error_type is None:
            error_desc.error_type = self.__class__.__name__
        self.error_desc = error_desc
        super(MalformedRequestError, self).__init__(**kw)


class InternalServiceError(ServiceError):
    def __init__(self, error_desc, **kw):
        assert isinstance(error_desc, ServiceErrorDescription)
        if error_desc.error_type is None:
            error_desc.error_type = self.__class__.__name__
        self.error_desc = error_desc
        super(InternalServiceError, self).__init__(**kw)


class XMLService(Service):
    u"""Сервис, поддерживающий формат данных XML"""

    _content_type = 'text/xml'

    def _renderContent(self, content, **kwargs):
        return etree.tostring(content, xml_declaration=True, encoding='utf-8',
                              pretty_print=True)


class CPXMLService(XMLService, CPService):
    u"""Сервис, поддерживающий формат данных XML и использующий CherryPy"""


class ICommonXMLService(Interface):
    pass


class XMLServiceErrorReporter(StdErrorReporter):
    def for_webpage(self, exc, tb):
        if isinstance(exc, ParamsValidationError):
            status = 200
            response = FailureServiceResponse(exc.error_descs)
        elif isinstance(exc, MalformedRequestError):
            status = 200
            response = FailureServiceResponse([exc.error_desc])
        elif isinstance(exc, InternalServiceError):
            status = 200
            response = FailureServiceResponse([exc.error_desc])
        else:
            status = 500
            message = unicode(exc)
            if not message:
                message = 'Unhandled error'
            error_type = exc.__class__.__name__
            #dbg = fmt_traceback(exc, tb, html=False)
            dbg = None
            error = ServiceErrorDescription(code=300000, message=message,
                                            dbg=dbg, error_type=error_type)
            response = FailureServiceResponse([error])

        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            if key in cherrypy.response.headers:
                del cherrypy.response.headers[key]
        cherrypy.response.headers['Cache-Control'] = 'No-Cache'
        cherrypy.response.headers['Expires'] = \
            time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(0))
        cherrypy.response.headers['Content-Type'] = 'text/xml'
        cherrypy.response.status = status

        return etree.tostring(response.to_etree(), xml_declaration=True,
                              encoding='utf-8', pretty_print=True)


class CommonXMLService(ErrorHandling, CPXMLService):
    implements(ICommonXMLService)

    _cacheable = False

    def render(self, *args, **kwargs):
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            if key in cherrypy.response.headers:
                del cherrypy.response.headers[key]

        if self._cacheable:
            cherrypy.response.headers['X-Cacheable'] = 'yes'
            cherrypy.response.headers['Last-Modified'] = \
                time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime())
        else:
            cherrypy.response.headers['Cache-Control'] = 'No-Cache'
            cherrypy.response.headers['Expires'] = \
                time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime(0))

        return super(CommonXMLService, self).render(*args, **kwargs)
