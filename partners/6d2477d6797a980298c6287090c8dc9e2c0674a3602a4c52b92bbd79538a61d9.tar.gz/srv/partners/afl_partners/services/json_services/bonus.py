# -*- coding: utf-8 -*-


from services.base.converter import xml2json
from services.base.json_base import CommonJSONService
from services.xml_services.bonus import AirlineServiceClassXMLService, TierLevelXMLService


AIRLINE_IATA_RE = '[A-Z]{2,3}'


class AirlineServiceClassJSONService(CommonJSONService):
    u"""
    Получение списка классов обслуживания, тарифных групп и классов
    бронирования (для всех Авиакомпаний).
    """

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            "json_service_class",
            "v.0.0.2/json/airline/:param_airline/service_classes",
            requirements={'param_airline': AIRLINE_IATA_RE},
            action='service_classes_v001', controller=self
        )

    @xml2json
    def service_classes_v001(self, param_airline, **params):
        return AirlineServiceClassXMLService().service_classes_v001(param_airline=param_airline, **params)


class TierLevelJSONService(CommonJSONService):
    u"""Получение списка статусов программ Аэрофлот Бонус (не зависит от Авиакомпании)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            'json_tier_level',
            'v.0.0.1/json/tiers',
            action='tier_levels_v001',
            controller=self)

    @xml2json
    def tier_levels_v001(self, **params):
        return TierLevelXMLService().tier_levels_v001(**params)
