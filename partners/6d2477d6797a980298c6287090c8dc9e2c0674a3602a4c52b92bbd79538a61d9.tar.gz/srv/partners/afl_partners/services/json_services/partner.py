# -*- coding: utf-8 -*-

"""
$Id:
"""

from pyramid.i18n import translate
from pyramid.vocabulary import getV

from logic.partners import (countries_available, cities_available,
                            categories_available, search_partners, search_offices)
from services.json_services import get_json_ml
from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse, DATE_FORMAT

import config
import cherrypy

COUNTRY_CODE_RE = '[a-zA-Z]{2}|'
COUNTRY_CODE_NR_RE = '%s|--' % COUNTRY_CODE_RE

class AvailablePartnerCategoriesJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_partner_office_countries', 'v.0.0.1/json/partner/categories', action='v001', controller=self)

    def _make_partner_categoires_dict(self, partner, lang):
        d = {
            'id' : partner.partner_category_id,
            'title' : get_json_ml(partner.names, lang)
        }
        return d

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис доступных категорий партнёров"""

        categories = categories_available()
        data = [self._make_partner_categoires_dict(category, message_lang) \
                for category in categories]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class CitiesByPartnerOfficesJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_any_partner_office_cities','v.0.0.1/json/partner/cities/:country', action='any_partners_v001', controller=self,
                           requirements={'country': COUNTRY_CODE_NR_RE})
        dispatcher.connect('json_some_partner_office_cities','v.0.0.1/json/partner/cities/:country/:partner_id', action='some_partners_v001', controller=self,
                           requirements={'country': COUNTRY_CODE_NR_RE})
    def _make_city_dict(self, city, lang):
        d = {
            'id' : city.city_id,
            'country_code' : city.country_code,
            'title' : get_json_ml(city.names, lang)
        }
        return d

    def generate_output(self, lang, partners, country_code):
        u"""Функция, генерящая JSON список городов, в которых есть филиалы партнёров"""

        if country_code is not None and country_code not in getV('countries').keys():
            raise cherrypy.HTTPError(404)
        cities = cities_available(partners, country_code)
        data = [self._make_city_dict(city, lang) for city in cities]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())

    @languageaware
    def any_partners_v001(self, message_lang, error_lang,  **params):
        u"""Сервис городов, в которых есть филиалы любых партнёров"""

        country_code = params['country'].upper()
        if country_code == '--':
            country_code = None
        return self.generate_output(message_lang, partners=None, country_code=country_code)

    @languageaware
    def some_partners_v001(self, message_lang, error_lang,  **params):
        u"""Сервис городов, в которых есть филиалы конкретного партнёра"""

        country_code = params['country'].upper()
        if country_code == '--':
            country_code = None
        partner_id = params['partner_id']
        partners = getV('partners')
        if partner_id not in partners.keys():
            raise cherrypy.HTTPError(404)
        elif not partners[partner_id].published:
            raise cherrypy.HTTPError(403)
        return self.generate_output(message_lang, [partner_id], country_code)


class CountriesByPartnerOfficesJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_available_any_partner_categories', 'v.0.0.1/json/partner/countries', action='any_partners_v001', controller=self)
        dispatcher.connect('json_available_some_partner_categories', 'v.0.0.1/json/partner/countries/:partner_id', action='some_partners_v001', controller=self)

    def _make_country_dict(self, country, lang):
        d = {
            'code' : country.country,
            'title' : get_json_ml(country.names, lang)
        }
        return d

    def generate_output(self, lang, partners):
        u"""Функция, генерящая JSON список городов, в которых есть филиалы партнёров"""

        countries = countries_available(partners)
        data = [self._make_country_dict(country, lang) for country in countries]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())

    @languageaware
    def any_partners_v001(self, message_lang, error_lang,  **params):
        u"""Сервис стран, в которых есть филиалы любых партн1ров"""

        return self.generate_output(message_lang, partners=None)

    @languageaware
    def some_partners_v001(self, message_lang, error_lang,  **params):
        u"""Сервис стран, в которых есть филиалы конкретного партнёра"""

        partner_id = params['partner_id']
        partners = getV("partners")
        if partner_id not in partners.keys():
            raise cherrypy.HTTPError(404)
        elif not partners[partner_id].published:
            raise cherrypy.HTTPError(403)
        return self.generate_output(message_lang, [partner_id])


class PartnerAndAwardsInfoJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_partner_and_awards', 'v.0.0.1/json/partner/:partner', action='v001', controller=self)

    def _make_special_offer_dict(self, special_offer, lang):
        d = {
            'title': get_json_ml(special_offer.names, lang),
            'description': get_json_ml(special_offer.offer_description, lang),
            'url': get_json_ml(special_offer.safe_offer_url, lang)
        }

        if lang is None:
            d['languages'] = special_offer.ui_languages

        return d

    def _make_award_dic(self, award, lang):
        d = {
            'weight': award.weight,
            'description': get_json_ml(award.award_condition_description, lang),
            'miles': award.miles
        }
        return d

    def _make_partner_dic(self, partner, lang):
        d = {
            'id': partner.partner_id,
            'title': get_json_ml(partner.names, lang),
            'short_description': get_json_ml(partner.short_descr, lang),
            'description': get_json_ml(partner.partner_description, lang),
            'earn_text': get_json_ml(partner.mile_get_comm, lang),
            'spend_text': get_json_ml(partner.mile_waste_comm, lang),
            'special_offers_text': get_json_ml(partner.spec_offer_comm, lang),
            'url': get_json_ml(partner.url, lang),
            'categories': map(lambda x: int(x), partner.partner_categories),
            'weight': partner.weight,
            'mile_action': partner.mile_action,
            'is_new': partner.is_new
        }
        return d

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Условия набоора и траты премиальных миль по id партнёра"""

        partner_id = params['partner']
        partners = getV('partners')
        if partner_id not in partners.keys():
            raise cherrypy.HTTPError(404)
        elif not partners[partner_id].published:
            raise cherrypy.HTTPError(403)
        partner = partners[partner_id]
        awards = partner.get_award_conditions()
        accumulation = []
        spending = []
        for award in awards:
            if award.published:
                award_output = self._make_award_dic(award, message_lang)
                if award.is_earning:
                    accumulation.append(award_output)
                if award.is_spending:
                    spending.append(award_output)

        # Спецпредложения
        special_offers = partner.get_special_offers(message_lang)
        offers_output = [self._make_special_offer_dict(offer, message_lang) for offer in special_offers]

        partner_output = self._make_partner_dic(partner, message_lang)
        partner_output['awards'] = {'accumulation': accumulation,
                                    'spending': spending}

        partner_output['special_offers'] = offers_output

        response = SuccessServiceResponse(partner_output)
        return self.render(response.to_dict())


class PartnerSearchJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_partner_search', 'v.0.0.1/json/partner/search', action='v001', controller=self)

    def _make_partner_dict(self, partner, lang):
        logo_urls = [u'%s:%s' % x for x in partner.logo_svc_urls.iteritems()]
        d = {
                'id': int(partner.id),
                'name': get_json_ml(partner.names, lang),
                'link': get_json_ml(partner.url, lang),
                'image': get_json_ml(logo_urls, lang),
                'new_until': partner.new_until and partner.new_until.strftime(DATE_FORMAT),
                'short_description': get_json_ml(partner.short_descr, lang),
            }
        return d

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Поиск парнеров """
        partners = search_partners(country=params.get('country'),
                                   city=params.get('city'),
                                   categories=params.get('categories[]'),
                                   q=params.get('name'),
                                   search_type=params.get('searchType'),
                                   language=message_lang)
        partners = sorted(partners, key=lambda x: "%d_%d" % (x.weight,x.partner_id))

        start = int(params.get('start', 0))
        limit = int(params.get('limit', 0))
        step = limit or config.PARTNERS_SERVICE_STEP

        end = step + start
        if step == 0 or end > len(partners):
            end = len(partners)

        items = [self._make_partner_dict(partner, message_lang) for partner in partners[start:end]]
        items = sorted(items, key=lambda x: x['name'])

        data = {
            'items': items,
            'paginator': {
                'total': len(partners),
                'start': start,
                'step': step
            }
        }

        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class PartnerOfficeSearchJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_partner_office_search', 'v.0.0.1/json/partner_office/search/:partner_id', action='v001', controller=self)

    def _make_contact_dict(self, contact):
        d = {
            'contact_type': contact.contact_type,
            'contact': contact.contact,
            'main_contact': contact.main_contact
        }
        return d

    def _make_office_dict(self, office, lang, cities, countries):
        city = cities[office.city]
        country = countries[city.country_code]
        d = {
                'id': office.partner_office_id,
                'city': get_json_ml(city.names, lang),
                'country': get_json_ml(country.names, lang),
                'lat': office.lat,
                'lon': office.lon,
                'comments': get_json_ml(office.comments, lang),
                'address': get_json_ml(office.address, lang),
                'worktime': get_json_ml(office.worktime, lang),
                'office_type': office.office_type,
                'contacts': [self._make_contact_dict(contact) for contact in office.contacts]
            }
        return d

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Поиск офисов партнеров """

        partner_id = str(params['partner_id'])
        partners = getV('partners')

        if partner_id not in partners.keys():
            raise cherrypy.HTTPError(404)

        partner = partners[partner_id]
        if not partner.published:
            raise cherrypy.HTTPError(403)

        countries = getV('countries')
        cities = getV('cities')

        offices = search_offices(partner=partner,
                                 country=params.get('country'),
                                 city=params.get('city'))
        offices = sorted(offices, key=lambda x: x.partner_office_id)

        start = int(params.get('start', 0))
        limit = int(params.get('limit', 0))
        step = limit or config.PARTNERS_OFFICE_CONTACTS_SERVICE_STEP

#        errors = []
#        if start < 0 or start > len(offices):
#            errors.append(ServiceErrorDescription(412, "Out of range. start=%d, must be in [%d, %d]" % (start, 0, len(offices))))
#        if len(errors) > 0:
#            return self.render(FailureServiceResponse(errors=errors).to_dict())

        end = step + start
        if step == 0 or end > len(offices):
            end = len(offices)

        items = [self._make_office_dict(office, message_lang, cities, countries) for office in offices[start:end]]
        items = sorted(items, key=lambda x: x['id'])

        data = {
            'items': items,
            'paginator': {
                'total': len(offices),
                'start': start,
                'step': step
            }
        }

        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())
