# -*- coding: utf-8 -*-

from services.base.converter import xml2json
from services.base.json_base import CommonJSONService
from services.xml_services.awards import AwardsXMLService, RedemptionZoneXMLService, SkyteamAwardsXMLService

AIRPORT_IATA_RE = '[A-Z]{3}'


class AwardsJSONService(CommonJSONService):
    u"""Сервисы калькулятора премий (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_afl_awards',
                           'v.0.0.2/json/airline/:param_airline/awards/from/:param_from/via/:param_via/to/:param_to',
                           action='awards_v001',
                           controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('json_afl_awards',
                           'v.0.0.2/json/airline/:param_airline/awards/from/:param_from/to/:param_to',
                           action='awards_v001',
                           controller=self,
                           param_via=None,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    @xml2json
    def awards_v001(self, param_airline, param_from, param_to, param_via=None, **params):
        return AwardsXMLService().awards_v001(param_airline, param_from, param_to, param_via, **params)


class SkyteamAwardsJSONService(CommonJSONService):
    u"""Сервисы калькулятора премий (только для SkyTeam)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_skyteam_awards', 'v.0.0.2/json/skyteam/awards/from/:param_from/to/:param_to',
                           action='awards_v002', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

        dispatcher.connect('json_skyteam_awards', 'v.0.0.2/json/skyteam/awards/airlines/from/:param_from/to/:param_to',
                           action='airlines_v002', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    def __init__(self, *args, **kwargs):
        self.xml_svc = SkyteamAwardsXMLService(*args, **kwargs)

    @xml2json
    def awards_v002(self, param_from, param_to, **params):
        return self.xml_svc.awards_v001(param_from, param_to, **params)

    @xml2json
    def airlines_v002(self, param_from, param_to, **params):
        return self.xml_svc.airlines_v001(param_from, param_to, **params)


class RedemptionZoneJSONService(CommonJSONService):
    u"""Получение списка премиальных зон программы Аэрофлот Бонус (не зависит от Авиакомпании)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_redemption_zones', 'v.0.0.1/json/redemption_zones',
                           action='zones_v001', controller=self)

    @xml2json
    def zones_v001(self, **params):
        return RedemptionZoneXMLService().zones_v001(**params)
