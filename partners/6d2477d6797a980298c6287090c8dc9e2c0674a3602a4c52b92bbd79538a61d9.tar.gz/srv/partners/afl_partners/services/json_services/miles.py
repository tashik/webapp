# -*- coding: utf-8 -*-
from lxml import etree
from pyramid.vocabulary import getV
from services.base.converter import xml2json, etree_to_dict, handle_xml_errors, camelcase_to_underscores
from services.base.json_base import CommonJSONService, SuccessServiceResponse, ParamsValidationError, ServiceErrorDescription, InternalServiceError, json_required
from services.xml_services.miles import MilesXMLService, MilesTierLevelXMLService, MilesServiceClassXMLService

from config import MAP_BS_ATG_TO_SU
from logic.skyteam import load_airline_by_iata, available_booking_classes

from i18n import _

AIRLINE_IATA_RE = '[A-Z]{2,3}'
AIRPORT_IATA_RE = '[A-Z]{3}'
TARIFF_GROUP_CODE_RE = '[a-z0-9\-]+'
TIER_LEVEL_CODE_RE = '[a-z]+'
AEROFLOT_ID = 1

class MilesJSONService(CommonJSONService):
    u"""Сервисы калькулятора миль (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_afl_miles', 'v.0.0.2/json/airline/:param_airline/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level/:tariff_group', action='miles_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('json_afl_miles', 'v.0.0.2/json/airline/:param_airline/miles/from/:param_from/to/:param_to/:tier_level/:tariff_group', action='miles_v001', controller=self,
                           param_via=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tariff_group': TARIFF_GROUP_CODE_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('json_afl_miles', 'v.0.0.2/json/airline/:param_airline/miles/from/:param_from/via/:param_via/to/:param_to/:tier_level', action='miles_v001', controller=self,
                           tariff_group=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_via': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})
        dispatcher.connect('json_afl_miles', 'v.0.0.2/json/airline/:param_airline/miles/from/:param_from/to/:param_to/:tier_level', action='miles_v001', controller=self,
                           param_via=None,
                           tariff_group=None,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE,
                                         'tier_level': TIER_LEVEL_CODE_RE})

    @xml2json
    def miles_v001(self, param_airline, param_from, param_to, tier_level, param_via=None, tariff_group=None, **params):
        u"""Получение сумм начисляемых миль по заданному маршруту"""

        return MilesXMLService().miles_v001(param_airline, param_from, param_to, tier_level, param_via, tariff_group, **params)


class MilesMultipleJSONService(CommonJSONService):
    u"""Сервис калькулятора миль, принимающий сразу несколько сегментов."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_miles_multiple', 'v.0.0.2/json/miles', action='miles_v002', controller=self)
        dispatcher.connect('json_miles_multiple', 'v.0.0.3/json/miles', action='miles_v003', controller=self)

    def _params_to_aeroflot(self, seg, iata, parent_airline_id):
        if (iata == 'SU' or parent_airline_id == AEROFLOT_ID) and not seg.get('fare_basis_code'):
            su_fare = MAP_BS_ATG_TO_SU.get(seg['booking_class'])
            if su_fare:
                seg['fare_basis_code'] = su_fare
                seg['booking_class'] = None
        return seg

    def _validate_params(self, json_params, allowed_params, required_params):
        try:
            segments = json_params['segments']
        except KeyError:
            raise ParamsValidationError([ServiceErrorDescription(207020, u"Ошибка валидации списка сегментов")])
        for i, seg in enumerate(segments):
            unknown_parameters = list(set(seg) - set(allowed_params))
            if unknown_parameters:
                raise ParamsValidationError([ServiceErrorDescription(500000, u'Unknown parameters: %r' % unknown_parameters)])

            missing_params = list(set(required_params) - set(seg))
            if missing_params:
                raise ParamsValidationError([ServiceErrorDescription(500000, u'Parameter %r absent for segment #%d' % (missing_params, i))])

            airline = load_airline_by_iata(seg['airline'])
            if airline is None:
                raise ParamsValidationError([ServiceErrorDescription(500000, u'Invalid airline IATA code: "%s"' % seg['airline'])])

            seg = self._params_to_aeroflot(seg, airline.iata, airline.parent_airline_id)
            seg_fare = seg.get('fare_basis_code')
            if seg_fare:
                if len(seg_fare) >= 2 :
                    #В коде тарифа нам нужны только првые 2 буквы
                    seg['tariff_group'] = self._get_tariff_group_by_airline_tariff_group_code(
                        airline, seg_fare[1], seg_fare[0]
                    )
            else:
                seg['tariff_group'] = self._get_tariff_group_by_booking_class(airline, seg['booking_class'])
        # Отбрасываем сегменты, для которых тарифной группы не нашлось.
        return [seg for seg in segments if seg.get('tariff_group') is not None]

    def _get_tariff_group_by_booking_class(self, airline, bcl_code):
        """Выбираем тарифную группу с максимальным коэффициентом набора,
           привязанную к классу бронирования с заданным кодом
           и выставленным флагом "начисление миль".
        """
        bcl_dict = getV('booking_classes')
        booking_classes = filter(lambda bcl: bcl.miles_are_charged and bcl.code == bcl_code,
                                 [bcl_dict[bcl_id] for bcl_id in available_booking_classes(airline)])
        try:
            return max([bcl.airline_tariff_group for bcl in booking_classes], key=lambda atg: atg.charge_coef).tariff_group.code
        except ValueError:      # max от пустого списка
            return None

    @staticmethod
    def _get_tariff_group_by_airline_tariff_group_code(airline, airline_tariff_group, bcl_code):
        """Выбираем тарифную группу по заданному коду привязанную к классу бронирования с заданным кодом
           и выставленным флагом "начисление миль".
        """
        bcl_dict = getV('booking_classes')
        booking_classes = filter(lambda bcl: bcl.miles_are_charged and bcl.code == bcl_code,
                                 [bcl_dict[bcl_id] for bcl_id in available_booking_classes(airline)])
        result = []

        for bcl in booking_classes:
            if bcl.airline_tariff_group.fareCode == airline_tariff_group:
                result.append(bcl.airline_tariff_group)
        try:
            return max(result, key=lambda atg: atg.charge_coef).tariff_group.code
        except ValueError:      # max от пустого списка
            return None

    @staticmethod
    def _processing_seg(res_item, i, seg):
        res_item = etree_to_dict(etree.fromstring(res_item))
        if not res_item: return None
        try:
            calculated_segment = res_item['route'][0]
        except (KeyError, IndexError) as e:
                raise InternalServiceError(ServiceErrorDescription(300, _(u'Сервис вернул некорректные данные для сегмента %d.') % i),
                                           cause=e)

        if 'segment' not in calculated_segment: return None
        res_item = calculated_segment['segment'][0]

        # Добавляем исходные данные сегмента
        res_item.update(seg)

        # Переименовываем qualifyingMiles в baseMiles
        res_item['baseMiles'] = res_item['qualifyingMiles']

        res_item = {camelcase_to_underscores(key): value for key, value in res_item.iteritems()
                    if key not in ('from', 'to', 'tariff_group', 'qualifyingMiles')}

        return res_item

    @json_required
    def miles_v002(self, json_request=None, **params):
        in_params = ('airline', 'airport_from', 'airport_to', 'tier_level', 'booking_class')
        total = {key: 0 for key in ('base_miles', 'bonus_miles', 'charged_miles', 'distance', 'promo_miles')}
        result = {"segments": [], "total": total}
        miles_xml_service = MilesXMLService()
        for i, seg in enumerate(self._validate_params(json_request, allowed_params=in_params, required_params=in_params)):
            res_item = handle_xml_errors(
                miles_xml_service.miles_v001,
                param_airline=seg['airline'],
                param_from=seg['airport_from'],
                param_to=seg['airport_to'],
                tier_level=seg['tier_level'],
                tariff_group=seg['tariff_group']
            )
            res_item = self._processing_seg(res_item, i, seg)
            if not res_item: continue
            result["segments"].append(res_item)
            for key in total:
                res_item[key] = int(round(float(res_item.get(key, 0))))
                total[key] += res_item[key]
        return self.render(SuccessServiceResponse(data=result).to_dict())

    @json_required
    def miles_v003(self, json_request=None, **params):
        in_params = ('airline', 'airport_from', 'airport_to', 'tier_level', 'fare_basis_code')
        total = {key: 0 for key in ('base_miles', 'bonus_miles', 'charged_miles', 'distance', 'promo_miles')}
        result = {"segments": [], "total": total}
        miles_xml_service = MilesXMLService()
        for i, seg in enumerate(self._validate_params(json_request, allowed_params=in_params, required_params=in_params)):
            res_item = handle_xml_errors(
                miles_xml_service.miles_v003,
                param_airline=seg['airline'],
                param_from=seg['airport_from'],
                param_to=seg['airport_to'],
                tier_level=seg['tier_level'],
                tariff_group=seg['tariff_group'],
                fare_basis_code=seg['fare_basis_code']
            )
            res_item = self._processing_seg(res_item, i, seg)
            if not res_item: continue
            result["segments"].append(res_item)
            for key in total:
                res_item[key] = int(round(float(res_item.get(key, 0))))
                total[key] += res_item[key]
        return self.render(SuccessServiceResponse(data=result).to_dict())


class MilesTierLevelJSONService(CommonJSONService):
    u"""Получение списка статусов программы Аэрофлот Бонус (не зависит от Авиакомпании)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_miles_tier_levels', 'v.0.0.1/json/miles/tiers',
                           action='tier_levels_v001', controller=self)

    @xml2json
    def tier_levels_v001(self, **params):
        return MilesTierLevelXMLService().tier_levels_v001(**params)


class MilesServiceClassJSONService(CommonJSONService):
    u"""Получение списка классов обслуживания по полётному сегменту (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_miles_service_classes', 'v.0.0.2/json/airline/:param_airline/miles/service_classes/from/:param_from/to/:param_to',
                           action='service_classes_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    @xml2json
    def service_classes_v001(self, param_airline, param_from, param_to, **params):
        u"""Получение списка классов обслуживания по полётному сегменту с возможностью выбора авмакомпании."""

        return MilesServiceClassXMLService().service_classes_v001(param_airline, param_from, param_to, **params)
