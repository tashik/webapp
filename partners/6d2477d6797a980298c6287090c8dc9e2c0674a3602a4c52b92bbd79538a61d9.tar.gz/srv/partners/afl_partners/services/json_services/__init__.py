# -*- coding: utf-8 -*-

from pyramid.i18n import translate

from i18n import get_languages_with_available_translations


def get_translate_dict(ml_element):
    u"""преобразует MLField в словарь язык:перевод"""
    result = {}
    for translate in ml_element:
        try:
            index = translate.index(':')
            lang = translate[:index].lower()
            val = translate[index+1:]
            result[lang] = val
        except:
            pass
    return result


def get_json_ml(ml, lang):
    translates = get_translate_dict(ml)
    if lang is None:
        langs = get_languages_with_available_translations()
    else:
        langs = [lang]
    res = {}
    for t_lang in langs:
        msg = translate(translates, domain='self_translate', target_language=t_lang)
        res[t_lang] = msg
    return res
