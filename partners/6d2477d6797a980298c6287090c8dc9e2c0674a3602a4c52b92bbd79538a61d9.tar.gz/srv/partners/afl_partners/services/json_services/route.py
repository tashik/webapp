# -*- coding: utf-8 -*-


from logic.route import TYPE_EARN, TYPE_SPEND
from services.base.converter import xml2json
from services.base.json_base import CommonJSONService
from services.xml_services.route import RouteXMLService, PairsByAirlineServiceClassXMLService


AIRLINE_IATA_RE = '[A-Z]{2,3}'
AIRPORT_IATA_RE = '[A-Z]{3}'
SERVICE_CLASS_IATA_RE = '[a-z]+'
TYPE_RE = '%s|%s' % (TYPE_EARN, TYPE_SPEND)


class RouteJSONService(CommonJSONService):
    u"""Сервисы доступных направлений перелётов (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_routes', 'v.0.0.2/json/airports/pairs',
                           action='pairs_v001', controller=self)
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/airports/pairs',
                           action='pairs_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/type/:param_type/airports/pairs',
                           action='pairs_v001', controller=self,
                           requirements={'param_type': TYPE_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/type/:param_type/airports/pairs',
                           action='pairs_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE})

        dispatcher.connect('json_routes', 'v.0.0.2/json/airports/from',
                           action='airports_from_v001', controller=self)
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/airports/from',
                           action='airports_from_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/type/:param_type/airports/from',
                           action='airports_from_v001', controller=self,
                           requirements={'param_type': TYPE_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/type/:param_type/airports/from',
                           action='airports_from_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE})

        dispatcher.connect('json_routes', 'v.0.0.2/json/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/type/:param_type/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/type/:param_type/airports/from/:param_from/to',
                           action='airports_to_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE})

        dispatcher.connect('json_routes', 'v.0.0.2/json/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/type/:param_type/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})
        dispatcher.connect('json_routes', 'v.0.0.2/json/airline/:param_airline/type/:param_type/airports/from/:param_from/to/:param_to/via',
                           action='airports_via_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE,
                                         'param_type': TYPE_RE,
                                         'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    @xml2json
    def pairs_v001(self, param_airline=None, param_type=None, **params):
        u"""Получение списка пар аэропортов."""

        return RouteXMLService().pairs_v001(param_airline, param_type, **params)

    @xml2json
    def airports_from_v001(self, param_airline=None, param_type=None, **params):
        u"""Получение списка возможных городов/аэропортов вылета."""

        return RouteXMLService().airports_from_v001(param_airline, param_type,
                                                    **params)

    @xml2json
    def airports_to_v001(self, param_airline=None, param_type=None,
                         param_from=None, **params):
        u"""Получение списка городов/аэропортов прилета по городу/аэропорту вылета."""

        return RouteXMLService().airports_to_v001(param_airline, param_type,
                                                  param_from, **params)

    @xml2json
    def airports_via_v001(self, param_airline=None, param_type=None,
                          param_from=None, param_to=None, **params):
        u"""Получение списка городов/аэропортов пересадок по городу вылета и прилёта."""

        return RouteXMLService().airports_via_v001(param_airline, param_type,
                                                   param_from, param_to, **params)


class PairsByAirlineServiceClassJSONService(CommonJSONService):
    u"""
    Получение списка пар аэропортов для запрошенного класса
    обслуживания авиакомпании (для всех Авиакомпаний).
    """

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(
            'json_routes_by_service_classes',
            'v.0.0.2/json/airline/:param_airline/airports/pairs/:service_class',
            action='pairs_v001', controller=self,
            requirements={
                'param_airline': AIRLINE_IATA_RE,
                'service_class': SERVICE_CLASS_IATA_RE
            }
        )

    @xml2json
    def pairs_v001(self, param_airline, service_class, **params):
        return PairsByAirlineServiceClassXMLService().pairs_v001(param_airline, service_class, **params)
