# -*- coding: utf-8 -*-


from services.base.converter import xml2json
from services.base.json_base import CommonJSONService
from services.xml_services.geo import CityXMLService, CountryXMLService, AirportXMLService


AIRLINE_IATA_RE = '[A-Z]{2,3}'


class CityJSONService(CommonJSONService):
    u"""Сервисы получения списка возможных городов / аэропортов пересадок (город вылета и прилета) (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_cities', 'v.0.0.2/json/cities',
                           action='cities_v001', controller=self)
        dispatcher.connect('json_cities', 'v.0.0.2/json/airline/:param_airline/cities',
                           action='cities_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})

        dispatcher.connect('json_cities', 'v.0.0.3/json/cities',
                           action='cities_v001', controller=self,
                           show_all_zones=True)

    @xml2json
    def cities_v001(self, param_airline=None, show_all_zones=False, **params):
        u"""Сервис списка городов (для всех Авиакомпаний)."""
        return CityXMLService().cities_v001(param_airline, show_all_zones, **params)


class CountryJSONService(CommonJSONService):
    u"""Сервис списка стран (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_countries', 'v.0.0.2/json/countries',
                           action='countries_v001', controller=self)
        dispatcher.connect('json_countries', 'v.0.0.2/json/airline/:param_airline/countries',
                           action='countries_v001', controller=self,
                           requirements={'param_airline': AIRLINE_IATA_RE})

    @xml2json
    def countries_v001(self, param_airline=None, **params):
        return CountryXMLService().countries_v001(param_airline, **params)


class AirportJSONService(CommonJSONService):
    u"""Сервис списка аэропортов (для всех Авиакомпаний)."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_airports', 'v.0.0.2/json/airports',
                           action='airports_v001', controller=self)

    @xml2json
    def airports_v001(self, param_airline=None, **params):
        return AirportXMLService().airports_v001(param_airline=None, **params)
