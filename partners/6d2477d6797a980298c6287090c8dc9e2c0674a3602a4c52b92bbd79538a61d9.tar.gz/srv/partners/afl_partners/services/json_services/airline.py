# -*- coding: utf-8 -*-

"""
$Id:
"""
import cherrypy

from pyramid.vocabulary import getV, getVI

from logic.geo import load_airport
from logic.skyteam import (airline_to_dict, search_skyteam_airlines,
                           search_afl_airlines, get_miles_table,
                           extend_miles_table)
from services.json_services import get_json_ml
from services.base.converter import xml2json
from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse
from services.xml_services.airline import AirlinesByRouteXMLService

from i18n import get_languages_with_available_translations


AIRPORT_IATA_RE = '[A-Z]{3}'


def airport_id2iata(airport_id):
    ob = load_airport(airport_id)
    if ob is not None:
        return ob.iata


class AirlineInfoJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_airline_info', 'v.0.0.1/json/airline/:airline', action='v001', controller=self)

    def _make_airline_dict(self, airline, lang):
        d = airline_to_dict(airline, ml_fnc=get_json_ml,
                            fields=['airline_id', 'iata', 'icao', 'alliance',
                                    'callsign', 'country', 'names', 'url', 'weight',
                                    'airport_id', 'miles_minimum', 'miles_limitation',
                                    'miles_earn_description', 'miles_earn_comment'],
                            fieldmap={'airline_id': 'id', 'names': 'title',
                                      'airport_id': 'airport',
                                      'miles_earn_description': 'earn_description',
                                      'miles_earn_comment': 'earn_text'},
                            fieldfmt={'airport_id': airport_id2iata},
                            lang=lang)
        d['parent'] = self._make_airline_minimal_dict(getV('airlines')[airline.parent_airline_id], lang) \
            if airline.parent_airline_id else None

        d['children'] = [self._make_airline_minimal_dict(a, lang)
                         for a in getV('airlines').values()
                         if a.parent_airline_id == airline.airline_id]

        sc_fnc= lambda ob, lang: get_json_ml(ob.names, lang)
        miles_table = get_miles_table(airline, sc_fnc=sc_fnc, lang=lang)

        booking_class_comments = extend_miles_table(miles_table,
                                                    ml_fnc=get_json_ml,
                                                    lang=lang)

        d['miles_table'] = miles_table
        d['booking_class_comments'] = booking_class_comments

        d['elite_coefficients'] = sorted([(tlf.tier_level, tlf.factor)
                                         for tlf in getVI('tier_level_factors_by_airline_idx')(context=airline)],
                                         key=lambda tlf: getV('tier_levels')[tlf[0]].ordering, reverse=True)

        return d

    def _make_airline_minimal_dict(self, airline, lang):
        return airline_to_dict(airline, ml_fnc=get_json_ml,
                               fields=['airline_id', 'iata', 'names', 'url'],
                               fieldmap={'airline_id': 'id', 'names': 'title'},
                               lang=lang)

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Информация об авиакомпании и её родительской/дочерних по её id"""
        airline_id = params['airline']
        airlines = getV('airlines')
        try:
            airline = airlines[airline_id]
        except KeyError:
            raise cherrypy.HTTPError(404)

        lang_not_specified = message_lang is None \
            or message_lang not in get_languages_with_available_translations()
        data = self._make_airline_dict(airline, None if lang_not_specified else message_lang)
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class AirlinesJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_skyteam_airlines', 'v.0.0.1/json/skyteam',
                           action='skyteam_v001', controller=self)
        dispatcher.connect('json_afl_airlines', 'v.0.0.1/json/afl',
                           action='afl_v001', controller=self)

    def _make_airline_dict(self, airline, lang):
        return airline_to_dict(airline, ml_fnc=get_json_ml,
                               fields=['airline_id', 'iata', 'icao', 'country', 'airport_id', 'names', 'url', 'weight'],
                               fieldmap={'airline_id': 'id', 'airport_id': 'airport', 'names': 'title'},
                               fieldfmt={'airport_id': airport_id2iata},
                               lang=lang)

    @languageaware
    def skyteam_v001(self, message_lang, error_lang, **params):
        u"""Сервис авиакомпаний, входящих в SkyTeam."""

        try:
            full = int(params.get("full")) == 1
        except (TypeError, ValueError):
            full = False

        data = [self._make_airline_dict(airline, message_lang)
                for airline in search_skyteam_airlines(
                    q=params.get('name'), language=message_lang, full=full)]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())

    @languageaware
    def afl_v001(self, message_lang, error_lang, **params):
        u"""Сервис авиакомпаний, входящих в AFL."""

        data = [self._make_airline_dict(airline, message_lang)
                for airline in search_afl_airlines(
                    q=params.get('name'), language=message_lang)]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class AirlinesByRouteJSONService(CommonJSONService):
    u"""Получение списка авиакомпаний, летающих заданным маршрутом."""

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_airlines_by_route', 'v.0.0.1/json/airlines/from/:param_from/to/:param_to', action='airlines_by_route_v001', controller=self,
                           requirements={'param_from': AIRPORT_IATA_RE,
                                         'param_to': AIRPORT_IATA_RE})

    @xml2json
    def airlines_by_route_v001(self, param_from, param_to, **params):
        return AirlinesByRouteXMLService().airlines_by_route_v001(param_from, param_to, **params)

