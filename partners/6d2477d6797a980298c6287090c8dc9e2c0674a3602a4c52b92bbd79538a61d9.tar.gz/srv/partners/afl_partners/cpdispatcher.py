# -*- coding: utf-8 -*-

"""
$Id: cpdispatcher.py 37 2012-05-30 11:45:43Z achunaev $
"""

import cherrypy
from pyramid.utils import Config as config
import cpconfig


def _createMountConfig(dispatcher_factory, path):
    u"""Создает конфигурацию для монтирования"""

    mount_cfg = dict()

    import cpconfig
    cfg = cpconfig.app_cfg.copy()
    cfg['request.dispatch'] = dispatcher_factory(prefix=path)

    mount_cfg.update({
        path: cfg
    })

    mount_cfg.update({
        '/favicon.ico': {
            'tools.staticfile.on': True,
            'tools.staticfile.filename': config.STATICDIR + '/favicon.ico',
            'tools.sessions.on': False,
            'request.dispatch': cherrypy.dispatch.Dispatcher(),
        }
    })

    return mount_cfg


def _getMainDispatcher(prefix=None):
    u"""Создает диспетчер и регистрирует маршруты и соответствующие
    им контроллеры.
    """

    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.mapper.prefix = prefix

    from ui.root import RootPage, LoginPage
    # Login/Logout - должны идти первыми
    LoginPage()._connectToDispatcher(dispatcher)
    RootPage()._connectToDispatcher(dispatcher)

    from ui.debug import SetDebugPage
    SetDebugPage()._connectToDispatcher(dispatcher)

    from services.heartbeat import HeartbeatService
    HeartbeatService()._connectToDispatcher(dispatcher)

    # UI
    from ui.partners import SearchFormPage
    SearchFormPage()._connectToDispatcher(dispatcher)

    from ui.partners import SearchResultPage
    SearchResultPage()._connectToDispatcher(dispatcher)
    from ui.partners import SearchOfficesResultPage
    SearchOfficesResultPage()._connectToDispatcher(dispatcher)

    from ui.partners import PartnerPage
    PartnerPage()._connectToDispatcher(dispatcher)

    from ui.airlines import AirlinesPage, AirlinePage
    AirlinesPage()._connectToDispatcher(dispatcher)
    AirlinePage()._connectToDispatcher(dispatcher)

    # Notify
    from notify import NotifyService
    NotifyService()._connectToDispatcher(dispatcher)

    return dispatcher



def _getPDADispatcher(prefix=None):
    u"""Создает диспетчер и регистрирует маршруты и соответствующие
    им контроллеры мобильной версии.
    """

    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.mapper.prefix = prefix

    from ui.mobile.root import LoginPage, RootPage
    # Login/Logout - должны идти первыми
    LoginPage()._connectToDispatcher(dispatcher)
    RootPage()._connectToDispatcher(dispatcher)


    from ui.mobile.partners import SearchFormPage
    SearchFormPage()._connectToDispatcher(dispatcher)

    from ui.mobile.partners import SearchResultPage
    SearchResultPage()._connectToDispatcher(dispatcher)
    from ui.mobile.partners import SearchOfficesResultPage
    SearchOfficesResultPage()._connectToDispatcher(dispatcher)

    from ui.mobile.partners import PartnerPage
    PartnerPage()._connectToDispatcher(dispatcher)

    from ui.mobile.airlines import AirlinesPage, AirlinePage
    AirlinesPage()._connectToDispatcher(dispatcher)
    AirlinePage()._connectToDispatcher(dispatcher)

    return dispatcher


def _getWSDispatcher(prefix=None):
    u"""Создает диспетчер и регистрирует маршруты и соответствующие
    им контроллеры сервисов.
    """

    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.mapper.prefix = prefix

    ############################################################################
    # JSON Services
    ############################################################################

    from services.json_services.partner import (AvailablePartnerCategoriesJSONService,
                                                CountriesByPartnerOfficesJSONService,
                                                CitiesByPartnerOfficesJSONService,
                                                PartnerAndAwardsInfoJSONService,
                                                PartnerSearchJSONService,
                                                PartnerOfficeSearchJSONService)
    AvailablePartnerCategoriesJSONService()._connectToDispatcher(dispatcher)
    CountriesByPartnerOfficesJSONService()._connectToDispatcher(dispatcher)
    CitiesByPartnerOfficesJSONService()._connectToDispatcher(dispatcher)
    PartnerSearchJSONService()._connectToDispatcher(dispatcher)
    PartnerOfficeSearchJSONService()._connectToDispatcher(dispatcher)
    # Должен идти после других сервисов, чей URL начинается на "v.0.0.1/json/partner/"
    PartnerAndAwardsInfoJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.airline import AirlineInfoJSONService, AirlinesJSONService
    AirlineInfoJSONService()._connectToDispatcher(dispatcher)
    AirlinesJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.route import RouteJSONService, PairsByAirlineServiceClassJSONService
    RouteJSONService()._connectToDispatcher(dispatcher)
    PairsByAirlineServiceClassJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.geo import CityJSONService, CountryJSONService, AirportJSONService
    CityJSONService()._connectToDispatcher(dispatcher)
    CountryJSONService()._connectToDispatcher(dispatcher)
    AirportJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.miles import (MilesJSONService, MilesMultipleJSONService,
                                              MilesTierLevelJSONService, MilesServiceClassJSONService)
    MilesJSONService()._connectToDispatcher(dispatcher)
    MilesMultipleJSONService()._connectToDispatcher(dispatcher)
    MilesTierLevelJSONService()._connectToDispatcher(dispatcher)
    MilesServiceClassJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.bonus import AirlineServiceClassJSONService, TierLevelJSONService
    AirlineServiceClassJSONService()._connectToDispatcher(dispatcher)
    TierLevelJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.awards import AwardsJSONService, RedemptionZoneJSONService, SkyteamAwardsJSONService
    AwardsJSONService()._connectToDispatcher(dispatcher)
    SkyteamAwardsJSONService()._connectToDispatcher(dispatcher)
    RedemptionZoneJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.airline import AirlinesByRouteJSONService
    AirlinesByRouteJSONService()._connectToDispatcher(dispatcher)

    ############################################################################
    # XML Services
    ############################################################################

    from services.xml_services.route import (RouteXMLService, AFLRouteXMLService,
                                             PairsByAirlineServiceClassXMLService,
                                             AFLPairsByAirlineServiceClassXMLService)
    RouteXMLService()._connectToDispatcher(dispatcher)
    AFLRouteXMLService()._connectToDispatcher(dispatcher)
    PairsByAirlineServiceClassXMLService()._connectToDispatcher(dispatcher)
    AFLPairsByAirlineServiceClassXMLService()._connectToDispatcher(dispatcher)

    from services.xml_services.geo import (AirportXMLService, AFLAirportXMLService,
                                           CityXMLService, AFLCityXMLService,
                                           CountryXMLService, AFLCountryXMLService)
    AirportXMLService()._connectToDispatcher(dispatcher)
    AFLAirportXMLService()._connectToDispatcher(dispatcher)
    CityXMLService()._connectToDispatcher(dispatcher)
    AFLCityXMLService()._connectToDispatcher(dispatcher)
    CountryXMLService()._connectToDispatcher(dispatcher)
    AFLCountryXMLService()._connectToDispatcher(dispatcher)

    from services.xml_services.bonus import (AirlineServiceClassXMLService,
                                             AFLAirlineServiceClassXMLService,
                                             TierLevelXMLService)
    AirlineServiceClassXMLService()._connectToDispatcher(dispatcher)
    AFLAirlineServiceClassXMLService()._connectToDispatcher(dispatcher)
    TierLevelXMLService()._connectToDispatcher(dispatcher)

    from services.xml_services.miles import (MilesServiceClassXMLService,
                                             AFLMilesServiceClassXMLService,
                                             MilesXMLService, AFLMilesXMLService,
                                             MilesTierLevelXMLService)
    MilesServiceClassXMLService()._connectToDispatcher(dispatcher)
    AFLMilesServiceClassXMLService()._connectToDispatcher(dispatcher)
    MilesXMLService()._connectToDispatcher(dispatcher)
    AFLMilesXMLService()._connectToDispatcher(dispatcher)
    MilesTierLevelXMLService()._connectToDispatcher(dispatcher)

    from services.xml_services.awards import (AwardsXMLService, AFLAwardsXMLService,
                                              SkyteamAwardsXMLService,
                                              RedemptionZoneXMLService)
    AwardsXMLService()._connectToDispatcher(dispatcher)
    AFLAwardsXMLService()._connectToDispatcher(dispatcher)
    SkyteamAwardsXMLService()._connectToDispatcher(dispatcher)
    RedemptionZoneXMLService()._connectToDispatcher(dispatcher)

    from services.xml_services.airline import AirlinesByRouteXMLService
    AirlinesByRouteXMLService()._connectToDispatcher(dispatcher)

    from services.xml_services.errors import ErrorsService
    ErrorsService()._connectToDispatcher(dispatcher)

    return dispatcher


# Конфигурация диспетчеров и локальные параметры CherryPy ----------------------

mount_cfg = _createMountConfig(_getMainDispatcher, config.VIRTUAL_BASE)

mount_cfg.update({
    (config.VIRTUAL_BASE + '/services'): {'tools.savedsesstool.on': False,
                                          'tools.sessions.on': False, },
    (config.VIRTUAL_BASE + '/services/ping'): {'tools.savedsesstool.on': True,
                                               'tools.sessions.on': True, },
})
# mount_cfg.update({
#    (config.VIRTUAL_BASE + '/verify/run'): {'response.stream': True, }
# })

from access import auth_paths
mount_cfg.update(auth_paths())

pda_mount_cfg = _createMountConfig(_getPDADispatcher, config.PDA_BASE)
pda_mount_cfg[config.PDA_BASE].update(cpconfig.pda_cfg)
mount_cfg.update(pda_mount_cfg)

ws_mount_cfg = _createMountConfig(_getWSDispatcher, config.WS_BASE)
mount_cfg.update(ws_mount_cfg)
