# -*- coding: utf-8 -*-

"""
$Id: config_defaults.py 21381 2016-10-27 18:33:46Z oeremeeva $
"""

import os
import os.path
import logging
import pyramid

import socket
socket.setdefaulttimeout(60)

SERVER_PORT = 7881
SERVER_HOST = '127.0.0.1'
PROXY_IP = ['127.0.0.1']  # see initializer.trusted_proxy

COOKIE_DOMAIN = None

VIRTUAL_BASE = '/partners'  # путь до корня приложения
PDA_BASE = VIRTUAL_BASE + '/pda'  # путь до корня приложения
WS_BASE = VIRTUAL_BASE + '/ws'  # путь до корня приложения

EXT_SERVER_URL = 'http://127.0.0.1:7881'  # URL для доступа к веб-серверу приложения, строка вида 'http://127.0.0.1:80'
VIRTUAL_STATIC_BASE = VIRTUAL_BASE

COMMON_STATIC_URL = '//www.aeroflot.ru/cms/sites/all/themes/aeroflot/common/'
MOBILE_SERVER_ROOT_URL = 'https://mobile.afl-test.com.spb.ru'
SITE_HOST = 'www.aeroflot.ru'

LK_URL = 'http://www.aeroflot.ru/personal'  # URL для ссылок на ресурсы "Личного кабинета" (также используется для SSO)

APPDIR = os.path.dirname(__file__)
PYRAMIDDIR = os.path.dirname(pyramid.__file__)
TEMPLATEDIR = [APPDIR + '/templates', PYRAMIDDIR + '/ui/templates']
LOG_LEVEL = logging.DEBUG

LOGDIR = APPDIR + '/log'
ERRORDIR = APPDIR + '/log/errors'
SESSDIR = APPDIR + '/session'
STATICDIR = APPDIR + '/static'
PIDDIR = APPDIR + '/pid'
DATADIR = APPDIR + '/data'

CSS_BASE_PATH = '/static/style'
JS_BASE_PATH = '/static/js'

CSS_MAIN_FILE = 'style.css'

COMPANY_NAME = u'Аэрофлот – Российские авиалинии'  # Set real company name
SYSTEM_NAME = u'Партнёры АФЛ'  # Set real application name
COPYRIGHT_STRING = '&copy; 2014'
COPYRIGHT_NAME = 'Аэрофлот'
FAVICONFILE = STATICDIR + '/favicon.ico'

ENCODING = 'utf-8'

DEFAULT_DB_CON = 'psycopgcon'
DEFAULT_DB_TYPE = 'pg'

POSTGRES_HOST = 'localhost'         # Set real database server host
POSTGRES_PORT = 5432                    # Set real database server port
POSTGRES_DBNAME = 'partner'    # Set real database name

POSTGRES_USER = 'postgres'        # Set real database user name
POSTGRES_PW = '1'      # Set real database user password

POSTGRES_DSN = "host='%s' port=%s dbname='%s' user='%s' password='%s'" % \
    (POSTGRES_HOST, POSTGRES_PORT, POSTGRES_DBNAME, POSTGRES_USER, POSTGRES_PW)



ADMIN_EMAIL = []
SMTP_FROM = 'skel@localhost'
SMTP_SERVER = 'klaus-s.com.spb.ru'
SMTP_PORT = 25

APP_COOKIE = 'AFLCAB'
APP_COOKIE_DOMAIN = '.com.spb.ru'
DEBUG_COOKIE = '_DEBUG'

ENABLE_I18N = True
APP_I18N_DOMAIN = 'messages'
LOCALES_DIR = APPDIR + '/locales'
FALLBACK_LANGUAGES = ['en']
# настройки для общих шаблонов
USE_COMMON_TEMPLATES = True  # использование локальных шаблонов inc_*, высший приоритет
USE_SAVED_TEMPLATES = False  # использовать сохраняемые в templates/temp django-шаблоны
FRONTEND_IP = None  # ip-адрес варниша на стендах
CHECK_TIME_INTERVAL = 5 * 60  # минимальное время для повторной отправки запроса (в сек.)
KNOWN_LANGUAGES = ['ru', 'en', 'de', 'fr', 'es', 'it', 'zh', 'ko', 'ja']
DEFAULT_LOCALIZATION = 'ru'
DEFAULT_LANG = 'ru'

# Компоненты Pyramid ---------------------------------------------------------

INCLUDE_CONTRACTORS = False
INCLUDE_FILES       = False
INCLUDE_PERSONS     = False
INCLUDE_EMPLOYEES   = False
INCLUDE_LOCATIONS   = False
INCLUDE_EMPLOYEES = INCLUDE_CONTRACTORS and INCLUDE_PERSONS

# Google Analytics -----------------------------------------------------------
GA_ACCOUNT = None

# Single Sign-On -------------------------------------------------------------
SSO_CLIENT_NAME = 'partners'
SSO_PASSWORD = '123'
SSO_SERVER = '127.0.0.1:7080'
SSO_URL = 'afl-test.com.spb.ru'
SSO_LOGIN_URL = 'http://%s/personal/login' % SSO_URL
SSO_LOGOUT_URL = 'http://%s/personal/logout' % SSO_URL

SSO_VALIDATE_URL = 'http://%s/personal/services/sso/%s' % (SSO_SERVER, SSO_CLIENT_NAME)

# Pbus -----------------------------------------------------------------------

PBUS_URL = 'http://127.0.0.1:8390'
PBUS_MY_NAME = 'partners'
PBUS_PASSWORD = '123'
PBUS_CALLBACK_HOST = SERVER_HOST
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_CALLBACK_PASSWORD = '123'
PBUS_TOPICS = {
    'vocabs': 'vocabs',
}
PBUS_VOCAB_RECIPIENTS = {
    'vocabs': 'vocabs'
}

# Хэши для доступа к веб-сервисам мониторинга - логи, ошибки, и т.д.
# Для вычисления хэша используем команду: print hashlib.md5('mon-ws-client:aeroflot-digest:PASSWORD').hexdigest()
MONITORING_WS_DIGEST = {
    'mon-ws-client': '################################',
}
# Кто имеет доступ к расширенному отчету об ошибке
ERROR_DETAILS_ACCESS = ['mon-ws-client']

DEFAULT_SERVICE_LANG = 'en'

# Partners settings ----------------------------------------------------------
PARTNERS_PAGINATOR_STEP = 12
PARTNERS_MOBILE_PAGINATOR_STEP = 6
PARTNERS_OFFICE_CONTACTS_PAGINATOR_STEP = 20
PARTNERS_MOBILE_OFFICE_CONTACTS_PAGINATOR_STEP = 20
PARTNERS_SERVICE_STEP = 12
PARTNERS_OFFICE_CONTACTS_SERVICE_STEP = 20

PARTNERS_FILES_URL = '//www.aeroflot.ru/media/aflfiles/afl_partners/partners/'
PARTNERS_SVC_FILES_URL = 'https://www.aeroflot.ru/media/aflfiles/afl_partners/partners/'
SKYTEAM_FILES_URL = '//www.aeroflot.ru/media/aflfiles/afl_partners/skyteam/'
SKYTEAM_LOGO_EXTENSION = 'jpg'
PARTNERS_LOGO_EXTENSION = 'jpg'
SPECIAL_OFFERS_URL = 'http://www.aeroflot.ru/'  # URL для преобразования относительных ссылок на спецпредложения

AFL_AIRLINE_IATA = "SU"

BANNERS_AJAX_URL = '/personal_banners/bulk/'

#URL калькулятора для набора миль
URL_EARN_CALC_MAIN = 'http://afl-test14.com.spb.ru/ikm2/'
URL_EARN_CALC = 'http://afl-test14.com.spb.ru/ikm2/mobile'
#URL калькулятора для траты миль
URL_SPEND_CALC = 'http://www.aeroflot.ru/ikm/mobile/spend?lang={0}'
# URL кнопки назад для Мобильного Сайта с поиска партнеров
URL_BACK_MOBILE_CMS_BONUS = 'https://m.afl-test14.com.spb.ru/cms/'
URL_POSTFIX_BACK_MOBILE_LANGS = {
    'ru': 'menudummy/26383',
    'int': 'en/menudummy/26573'
}
# URL префикса для спецпредложений для Мобильного Сайта
URL_SP_OFFERS_MS_PREFIX = 'http://m.aeroflot.ru'
# URL клика по баннеру банков на МС
URL_BANK_BANNER_MOBILE = {
    'ru': 'http://m.aeroflot.ru/cms/afl_bonus/plastic_card',
    'int': 'http://m.aeroflot.ru/cms/en/afl_bonus/plastic_card',
}

URL_TO_NEW_FARES = {
    'ru': 'http://www.aeroflot.ru/ru-ru/afl_bonus/new_fares/',
    'en': 'http://www.aeroflot.ru/ru-en/afl_bonus/new_fares/',
}

# каталог картинок
URL_PICTURE_CATALOG = '//www.aeroflot.ru/media/aflfiles/afl_partners'

COUNTRY_PRIORITY = ['RU']  # iso коды стран, в соответствии с которым осуществляется сортирвка стран (напр. в select`ах)
CITY_PRIORITY = ['MOW', 'LED']  # iata-area коды городов, в соответствии с которым осуществляется сортирвка городов (напр. в select`ах)

GOOGLE_TAG_MANAGER_ID = NotImplemented

# соответствия старых тарифов новым для аэрофлота и его дочек
MAP_BS_ATG_TO_SU = {
    'C': 'CF', 'D': 'CF', 'J': 'CF',
    'I': 'IC', 'Z': 'IC',
    'W': 'AF',
    'A': 'AC', 'S': 'AC',
    'B': 'BF', 'Y': 'BF', 'H': 'BC', 'K': 'BC', 'L': 'BC', 'M': 'BC', 'U': 'BC',
    'E': 'EV', 'N': 'EV', 'Q': 'EV', 'T': 'EV',
    'P': 'PS', 'R': 'PS'
}

# соответствия старых тарифов новым для аэрофлота и его дочек
MAP_TF_TO_ATG_SU = {
    'business-premium': 'CF',
    'business-optimum': 'IC',
    'comfort-premium': 'AF',
    'comfort-optimum': 'AC',
    'economy-premium': 'BF',
    'economy-optimum': 'BC',
    'economy-budget': 'EV',
    'economy-promo': 'PS'
}

