#!/bin/sh

HOME='/path/to/virtualenv'

for i in 'de' 'en' 'es' 'fr' 'it' 'ja' 'ko' 'ru' 'zh'
do
    $HOME/bin/pybabel compile -l $i -i ../locales/$i/LC_MESSAGES/messages.po -o ../locales/$i/LC_MESSAGES/messages.mo
done
