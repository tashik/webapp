#!/bin/sh

HOME='/path/to/virtualenv'

$HOME/bin/pybabel extract --no-wrap -F ./extract.cfg -k L_ -o ../locales/messages.pot ../
