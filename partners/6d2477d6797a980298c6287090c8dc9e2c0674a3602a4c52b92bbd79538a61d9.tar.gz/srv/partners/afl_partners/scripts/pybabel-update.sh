#!/bin/sh

HOME='/path/to/virtualenv'

for i in 'de' 'en' 'es' 'fr' 'it' 'ja' 'ko' 'ru' 'zh'
do
    $HOME/bin/pybabel update -l $i -i ../locales/messages.pot -o ../locales/$i/LC_MESSAGES/messages.po
done
