# -*- coding: utf-8 -*-

"""
$Id: bonus.py 14779 2015-09-10 13:18:19Z ogambaryan $
"""


from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.ormlite.models import TitleCapable
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexer

from rx.i18n.translation import self_translated

from models.interfaces import ITariffGroup, IBookingClass

from models.base import WSVocabularyBase
from models.interfaces import ITierLevel
from models.interfaces import (IAirline, ISkyTeamServiceClass,
                               IAirlineServiceClass, IServiceClassesLimit,
                               IAirlineTariffGroup, ITierLevelFactor)
from models.ml import MLTitleCapable


class SkyTeamServiceClass(ActiveRecord, MLTitleCapable):
    u"""Класс обслуживания SkyTeam"""

    implements(ISkyTeamServiceClass)
    p_table_name = 'skyteam_service_classes'


class SkyTeamServiceClassesVocabulary(WSVocabularyBase):
    objectC = SkyTeamServiceClass
    makeVocabularyRegisterable('skyteam_service_classes')


class AirlineServiceClass(ActiveRecord, TitleCapable):
    u"""Класс обслуживания SkyTeam"""

    implements(IAirlineServiceClass)
    p_table_name = 'airline_service_classes'

    @property
    def title(self):
        try:
            return self.skyteam_sc.title
        except AttributeError:
            return ''

    @property
    def skyteam_sc(self):
        try:
            return getV('skyteam_service_classes')[self.skyteam_sc_id]
        except LookupError:
            pass

    @property
    def allowed_pairs(self):
        pairs = []
        for ob in getVI('service_classes_limits_by_airline_service_class_idx')(context=self):
            try:
                pairs.append(getV('pairs')[ob.pair_id])
            except LookupError:
                pass
        return pairs

    def pair_allowed(self, a1_id, a2_id):
        pairs = self.allowed_pairs
        if pairs:
            search = set([(ob.airport_from_id, ob.airport_to_id) for ob in pairs])
            if (a1_id, a2_id) in search or (a2_id, a1_id) in search:
                return True
            return False
        return True


class AirlineServiceClassesVocabulary(WSVocabularyBase):
    objectC = AirlineServiceClass
    makeVocabularyRegisterable('airline_service_classes')


class AirlineServiceClassesByAirlineIndexer(VocabularyIndexer):
    vocabulary = 'airline_service_classes'
    contextI = IAirline

    def objectIndex(self, ob):
        return ob.airline_id

    def contextIndex(self, ob):
        if ob is not None:
            return ob.airline_id

    makeIndexerRegisterable('airline_service_classes_by_airline_idx')


class ServiceClassesLimit(ActiveRecord):
    u"""Ограничения для классов обслуживания"""

    implements(IServiceClassesLimit)
    p_table_name = 'service_classes_limits'


class ServiceClassesLimitsVocabulary(WSVocabularyBase):
    objectC = ServiceClassesLimit
    makeVocabularyRegisterable('service_classes_limits')


class ServiceClassesLimitsByAirlineServiceClassIndexer(VocabularyIndexer):
    vocabulary = 'service_classes_limits'
    contextI = IAirlineServiceClass

    def objectIndex(self, ob):
        return ob.airline_sc_id

    def contextIndex(self, ob):
        if ob is not None:
            return ob.airline_sc_id

    makeIndexerRegisterable('service_classes_limits_by_airline_service_class_idx')


class ServiceClassesLimitsByAirlineIndexer(VocabularyIndexer):
    vocabulary = 'service_classes_limits'
    contextI = IAirline

    def objectIndex(self, ob):
        if ob.airline_sc_id is not None:
            try:
                return getV('airline_service_classes')[ob.airline_sc_id].airline_id
            except LookupError:
                pass
            else:
                return

    def contextIndex(self, ob):
        if ob is not None:
            return ob.airline_id

    makeIndexerRegisterable('service_classes_limits_by_airline_idx')


class TariffGroup(ActiveRecord, MLTitleCapable):
    u"""Тарифная группа"""

    implements(ITariffGroup)
    p_table_name = 'tariff_groups'


class TariffGroupsVocabulary(WSVocabularyBase):
    objectC = TariffGroup
    makeVocabularyRegisterable('tariff_groups')


class AirlineTariffGroup(ActiveRecord, TitleCapable):
    u"""Тарифная группа для авиакомпании"""

    implements(IAirlineTariffGroup)
    p_table_name = 'airline_tariff_groups'

    @property
    def title(self):
        try:
            return self.tariff_group.title
        except AttributeError:
            return ''

    @property
    def tariff_group(self):
        try:
            return getV('tariff_groups')[self.tariff_group_id]
        except LookupError:
            pass

    @property
    def airline_sc(self):
        try:
            return getV('airline_service_classes')[self.airline_sc_id]
        except LookupError:
            pass


class AirlineTariffGroupsVocabulary(WSVocabularyBase):
    objectC = AirlineTariffGroup
    makeVocabularyRegisterable('airline_tariff_groups')


class AirlineTariffGroupsByAirlineServiceClassIndexer(VocabularyIndexer):
    vocabulary = 'airline_tariff_groups'
    contextI = IAirlineServiceClass

    def objectIndex(self, ob):
        return ob.airline_sc_id

    def contextIndex(self, ob):
        if ob is None:
            return None
        return ob.airline_sc_id

    makeIndexerRegisterable('airline_tariff_groups_by_airline_service_class_idx')


class BookingClass(ActiveRecord, TitleCapable):
    u"""Класс бронирования"""

    implements(IBookingClass)
    p_table_name = 'booking_classes'

    @property
    def title(self):
        return self.code

    @property
    def comment(self):
        try:
            d = dict([s.split(':', 1) for s in self.text_comment])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.text_comment), tb
        return self_translated(**d)

    @property
    def airline_tariff_group(self):
        return getV('airline_tariff_groups').get(self.airline_tariff_group_id)


class BookingClassesVocabulary(WSVocabularyBase):
    objectC = BookingClass
    makeVocabularyRegisterable('booking_classes')


class BookingClassesByAirlineTariffGroupIndexer(VocabularyIndexer):
    vocabulary = 'booking_classes'
    contextI = IAirlineTariffGroup

    def objectIndex(self, ob):
        return ob.airline_tariff_group_id

    def contextIndex(self, ob):
        if ob is None: return None
        return ob.airline_tariff_group_id

    makeIndexerRegisterable('booking_classes_by_airline_tariff_group_idx')


class TierLevel(ActiveRecord, MLTitleCapable):
    u"""Статус участника"""

    implements(ITierLevel)
    p_table_name = 'tier_levels'


class TierLevelsVocabulary(WSVocabularyBase):
    objectC = TierLevel
    makeVocabularyRegisterable('tier_levels')


class TierLevelFactor(ActiveRecord):
    u"""Коэффициент статуса участника"""

    implements(ITierLevelFactor)
    p_table_name = 'tier_level_factors'


class TierLevelFactorsVocabulary(WSVocabularyBase):
    objectC = TierLevelFactor
    makeVocabularyRegisterable('tier_level_factors')


class TierLevelFactorsByAirlineIndexer(VocabularyIndexer):
    vocabulary = 'tier_level_factors'
    contextI = IAirline

    def objectIndex(self, ob):
        return ob.airline_id

    def contextIndex(self, ob):
        if ob is None:
            return None
        return ob.airline_id

    makeIndexerRegisterable('tier_level_factors_by_airline_idx')

