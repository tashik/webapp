# -*- coding: utf-8 -*-

"""
$Id: $
"""


from zope.schema.interfaces import ITokenizedTerm
from zope.schema.vocabulary import SimpleTerm

from pyramid.ormlite import dbquery
from pyramid.vocabulary.mvcc import MvccVocabulary


class WSVocabularyBase(MvccVocabulary):
    objectC = NotImplemented

    @staticmethod
    def coerce_token(token):
        u"""Приводит токен к общему формату"""
        if isinstance(token, (list, tuple,)):
            return '-'.join([ str(p) for p in token ])
        return str(token)

    def preload(self):
        table_name = self.objectC.p_table_name
        objects = self.objectC.bulkLoadList(
            dbquery('select * from %s' % table_name))
        self.add_many(objects)

    def rebuild(self, objects=None):
        objects = objects or self
        terms = [
            SimpleTerm(token=ITokenizedTerm(o).token, value=o, title=getattr(o, 'title', None))
            for o in objects]
        self.replace_all(terms)


class Published():
    u"""Реализация свойства Published"""

    status = 'U'

    @property
    def published(self):
        return self.status == 'P'
