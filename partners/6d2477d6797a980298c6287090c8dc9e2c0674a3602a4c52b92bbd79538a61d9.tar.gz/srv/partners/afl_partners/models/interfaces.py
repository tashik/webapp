# -*- coding: utf-8 -*-

"""
$Id: $
"""


from zope.interface import Interface, implements
import zope.schema as zs
import zope.schema.interfaces as zsi

from pyramid.ormlite.schema import *

from models.ml import MLNames, TextLineList
from models.uppercase import CodeTextLine, UppercaseTextLine


class ICountry(Interface):
    u"""Страна"""

    country = UppercaseTextLine(db_column='country', title=u'2-значный код ISO', primary_key=True, required=True, min_length=2, max_length=2)
    iso_code3 = UppercaseTextLine(db_column='iso_code3', title=u'3-значный код ISO', required=False, min_length=3, max_length=3)
    names = MLNames(db_column='names', title=u'Название страны', required=True)


class ICity(Interface):
    u"""Населённый пункт"""

    city_id = Int(db_column='city_id', required=True, readonly=True, primary_key=True)
    country_code = UppercaseTextLine(db_column='country', title=u'2-значный код страны', min_length=2, max_length=2, required=False)
    tz = TextLine(db_column='tz', title=u'Часовой пояс', max_length=32, required=True)
    iata = UppercaseTextLine(db_column='iata', title=u'Код города по IATA', min_length=3, max_length=3, required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    names = MLNames(db_column='names', title=u'Название города', required=True)


class IAirport(Interface):
    u"""Аэропорт"""

    airport_id = Int(db_column='airport_id', required=True, readonly=True, primary_key=True)
    city_id = Int(db_column='city_id', title=u'Город', required=True)
    iata = UppercaseTextLine(db_column='iata', title=u'IATA-код аэропорта', min_length=3, max_length=3, required=True)
    icao = UppercaseTextLine(db_column='icao', title=u'ICAO-код аэропорта', min_length=4, max_length=4, required=False)
    names = MLNames(db_column='names', title=u'Название аэропорта', required=True)
    afl_redemption_zone = UppercaseTextLine(db_column='afl_redemption_zone', title=u'Код зоны Аэрофлота', min_length=2, max_length=2, required=False)
    skyteam_redemption_zone = UppercaseTextLine(db_column='skyteam_redemption_zone', title=u'Код зоны SkyTeam', min_length=2, max_length=2, required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    has_upgrade_on_checkin_award = Bool(db_column='has_uc_award', required=False,
                                        title=u'Доступна премия за повышение класса обслуживания на стойке регистрации')


class IPair(Interface):
    u"""Пара"""

    pair_id = Int(db_column='pair_id', required=True, readonly=True, primary_key=True)
    airport_from_id = Int(db_column='airport_from_id', title=u'Аэропорт вылета', required=True)
    airport_to_id = Int(db_column='airport_to_id', title=u'Аэропорт прилёта', required=True)
    airline_id = Int(db_column='airline_id', title=u'Авиакомпания', required=True)
    miles = Int(db_column='miles', title=u'Расстояние', required=True)
    no_spending = Bool(db_column='no_spending', title=u'Не предоставлять трату', default=False, required=False)


class IAirline(Interface):
    u"""Авиакомпания"""

    airline_id = Int(db_column='airline_id', primary_key=True, required=True, readonly=True)
    iata = CodeTextLine(db_column='iata', title=u'IATA-код', min_length=2, max_length=3, required=False)
    icao = CodeTextLine(db_column='icao', title=u'ICAO-код', min_length=3, max_length=3, required=False)
    callsign = UppercaseTextLine(db_column='callsign', title=u'Позывной', max_length=64, required=False)
    country = UppercaseTextLine(db_column='country', title=u'2-значный код ISO', required=False, min_length=2, max_length=2)
    airport_id = Int(db_column='airport_id', title=u'Аэропорт базирования', required=False)
    alliance = TextLine(db_column='alliance', title=u'Альянс', required=False)
    names = MLNames(db_column='names', title=u'Название авиакомпании', required=True)
    parent_airline_id = Int(db_column='parent_airline_id', title=u'Родительская авиакомпания', required=False)
    url = MLNames(db_column='url', title=u'Ссылка на сайт авиакомпании', required=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    miles_minimum = Float(db_column='miles_minimum', title=u'Минимальное количество миль при наборе', required=True)
    miles_limitation = TextLine(db_column='miles_limitation', title=u"Ограничения для минимального количества миль", required=True)
    miles_earn_description = MLNames(db_column="miles_earn_description", title=u"Описание набора миль", required=True)
    miles_earn_comment = MLNames(db_column="miles_earn_comment", title=u"Примечания для набора миль", required=True)


class IPartnerCategory(Interface):
    u"""Категория партнёров-неавиакомпаний"""

    partner_category_id = Int(db_column='partner_category_id', title=u'Id', primary_key=True, required=True)
    names = MLNames(db_column='names', title=u'Наименование категории партнёров', required=True)
    status = TextLine(db_column='status', title=u'Статус категории партнёров', min_length=0, max_length=1, required=True)


class IPartner(Interface):
    u"""Партнёр-неавиакомпания"""

    partner_id = Int(db_column='partner_id', title=u'Id', primary_key=True, required=True)
    names = MLNames(db_column='names', title=u'Название партнёра', required=True)
    partner_description = MLNames(db_column='partner_description', title=u'Описание', required=False)
    url = MLNames(db_column='url', title=u'Ссылка на сайт партнёра', required=True)
    partner_categories = TextLineList(db_column='partner_categories', title=u'Категория партнёра', required=False)
    status = TextLine(db_column='status', title=u'Статус партнёра', min_length=0, max_length=1, required=True)
    mile_action = TextLine(db_column='mile_action', title=u'Действия с милями', min_length=0, max_length=1, required=True)
    mile_get_comm = MLNames(db_column="mile_get_comm", title=u"Комментарий для набора миль", required=False)
    mile_waste_comm = MLNames(db_column="mile_waste_comm", title=u"Комментарий для траты миль", required=False)
    spec_offer_comm = MLNames(db_column="spec_offer_comm", title=u"Комментарий для спецпредложений", required=False)
    short_descr = MLNames(db_column="short_descr", title=u"Краткое описание", required=False)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    new_until = Date(db_column='new_until', title=u'Новый до наступления даты', required=False)


class IPartnerOfficeContact(Interface):
    u"""Контакт филиала партнёра-неавиакомпании"""

    partner_office_contact_id = Int(db_column='partner_office_contact_id', primary_key=True, required=True, readonly=True)
    partner_office = Int(db_column='partner_office_id', required=True)
    contact_type = TextLine(db_column='contact_type', title=u'Тип контакта', min_length=0, max_length=1, required=True)
    contact = TextLine(db_column='contact', title=u'Контактная информация', required=True, max_length=100)
    main_contact = Bool(db_column='main_contact', title=u'Основной контакт', default=False, required=True)


class IPartnerOfficeContactField(zsi.IList):
    pass


class PartnerOfficeContactField(zs.List):
    implements(IPartnerOfficeContactField)


class IPartnerOffice(Interface):
    u"""Филиал партнёра-неавиакомпании"""

    partner_office_id = Int(db_column='partner_office_id', title=u'Id', primary_key=True, required=True)
    partner = Int(db_column='partner_id', title=u'Партнёр', required=True)
    city = Int(db_column='city_id', title=u'Город', required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    comments = MLNames(db_column='comments', title=u'Комментарий', required=False)
    address = MLNames(db_column='address', title=u'Адреса', required=False)
    worktime = MLNames(db_column='worktime', title=u'Время работы', required=False)
    office_type = TextLine(db_column='office_type', title=u'Тип офиса', min_length=0, max_length=1, required=True)
    contacts = PartnerOfficeContactField(title=u'Контакты', required=False, value_type=PartnerOfficeContactField())


class IPartnerAwardCondition(Interface):
    u"""Условие набора и траты миль для партнёров-неавиакомпаний"""

    partner_award_condition_id = Int(db_column='partner_award_condition_id', title=u'Id', primary_key=True, required=True)
    partner = Int(db_column='partner_id', title=u'Партнёр', required=True)
    award_condition_type = TextLine(db_column='award_condition_type', title=u'Тип условия', min_length=0, max_length=1, required=True)
    award_condition_description = MLNames(db_column='award_condition_description', title=u'Описание', required=True)
    weight = Int(db_column='weight', title=u'Вес условия', required=True)
    status = TextLine(db_column='status', title=u'Статус', min_length=0, max_length=1, required=True)
    miles = Float(db_column="miles", title=u"Мили", required=True)


class ISkyTeamServiceClass(Interface):
    u"""Класс обслуживания SkyTeam"""

    skyteam_sc_id = Int(db_column='skyteam_sc_id', primary_key=True, required=True, readonly=True)
    code = TextLine(db_column='code', required=True, min_length=1, max_length=16, title=u'Код класса обслуживания')
    names = MLNames(db_column='names', title=u'Наименование класса обслуживания', required=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)


class IAirlineServiceClass(Interface):
    u"""Класс обслуживания авиакомпании"""

    airline_sc_id = Int(db_column='airline_sc_id', primary_key=True, required=True, readonly=True)
    airline_id = Int(db_column='airline_id', title=u'Авиакомпания', required=True)
    skyteam_sc_id = Int(db_column='skyteam_sc_id', title=u'Класс обслуживания', required=True)


class IServiceClassesLimit(Interface):
    u"""Ограничения для классов обслуживания"""

    service_classes_limit_id = Int(db_column='service_classes_limit_id', primary_key=True, required=True, readonly=True)
    airline_sc_id = Int(db_column='airline_sc_id', title=u'Класс обслуживания авиакомпании', required=True)
    pair_id = Int(db_column='pair_id', title=u'Пары', required=True)


class ITariffGroup(Interface):
    u"""Тарифная группа"""

    tariff_group_id = Int(db_column='tariff_group_id', primary_key=True, required=True, readonly=True)
    skyteam_sc_id = Int(db_column='skyteam_sc_id', title=u'Класс обслуживания', required=True)
    code = TextLine(db_column='code', required=True, title=u'Код', max_length=50)
    names = MLNames(db_column='names', required=True, title=u'Наименование тарифной группы')
    weight = Int(db_column="weight", required=True, title=u"Вес", default=0)


class IAirlineTariffGroup(Interface):
    u"""Тарифная группа для авиакомпании"""

    airline_tariff_group_id = Int(db_column='airline_tariff_group_id', primary_key=True, required=True, readonly=True)
    tariff_group_id = Int(db_column='tariff_group_id', title=u'Тарифная группа', required=True)
    airline_sc_id = Int(db_column='airline_sc_id', title=u'Класс обслуживания авиакомпании', required=True)
    charge_coef = Int(db_column='charge_coef', title=u'Коэффициент для начисления', required=True)
    weight = Int(db_column='weight', required=True, title=u'Вес')
    fareCode = TextLine(db_column='fare_code', required=False, title=u'Код', max_length=50)


class IBookingClass(Interface):
    u"""Класс бронирования"""

    booking_class_id = Int(db_column='booking_class_id', primary_key=True, required=True, readonly=True)
    code = TextLine(db_column='code', required=True, title=u'Код', max_length=50)
    miles_are_charged = Bool(db_column='miles_are_charged', title=u'Мили начисляются', required=False)
    text_comment = MLNames(db_column='text_comment', title=u'Комментарий', required=False)
    airline_tariff_group_id = Int(db_column='airline_tariff_group_id', title=u'Тарифная группа для АК', required=True)


class ITierLevel(Interface):
    u"""Статус участника"""

    tier_level = TextLine(db_column='tier_level', primary_key=True, required=True, min_length=1, max_length=16, title=u'Код статуса участника')
    names = MLNames(db_column='names', title=u'Наименование статуса участника', required=True)
    ordering = Int(db_column='ordering', required=True, title=u'Вес')
    miles = Int(db_column='miles', required=True, title=u'Мили')
    segments = Int(db_column='segments', required=True, title=u'Сегменты')


class ITierLevelFactor(Interface):
    u"""Коэффициент статуса участника"""

    tier_level_factor_id = Int(db_column='tier_level_factor_id', primary_key=True, required=True, readonly=True)
    airline_id = Int(db_column='airline_id', title=u'Авиакомпания', required=True)
    tier_level = TextLine(db_column='tier_level', title=u'Статус участника', required=True)
    factor = Float(db_column='factor', title=u'Коэффициент', required=True)


class IRedemptionZone(Interface):
    u"""Премиальная зона"""

    redemption_zone = UppercaseTextLine(db_column='redemption_zone', primary_key=True, required=True, min_length=2, max_length=2, title=u'Код зоны')
    names = MLNames(db_column='names', required=True, title=u'Название зоны')


class IBonusRoute(Interface):
    u"""Премиальный маршрут"""

    bonus_route_id = Int(db_column='bonus_route_id', primary_key=True, required=True, readonly=True)
    code = TextLine(db_column='code', title=u'Код', min_length=1, max_length=9, required=True)
    zone_from = UppercaseTextLine(db_column='zone_from', title=u'Зона вылета', min_length=2, max_length=2, required=True)
    zone_via = UppercaseTextLine(db_column='zone_via', title=u'Зона пересадки', min_length=2, max_length=2, required=False)
    zone_to = UppercaseTextLine(db_column='zone_to', title=u'Зона прилёта', min_length=2, max_length=2, required=True)
    carrier = TextLine(db_column='carrier', title=u'Перевозчик', min_length=1, max_length=1, required=True)


class IAward(Interface):
    u"""Премия"""

    award_id = Int(db_column='award_id', primary_key=True, required=True, readonly=True)
    award_type = TextLine(db_column='award_type', title=u'Тип пермии', min_length=1, max_length=2, required=True)
    skyteam_service_class_id_1 = Int(db_column='skyteam_service_class_id_1', title=u'Класс обслуживания 1', required=True)
    skyteam_service_class_id_2 = Int(db_column='skyteam_service_class_id_2', title=u'Класс обслуживания 2', required=False)
    award_value = Int(db_column='award_value', title=u'Значение премии', required=True)
    bonus_route_id = Int(db_column='bonus_route_id', title=u'Премиальный маршрут', required=True)


class IWrongRoute(Interface):
    u"""Запрещённый маршрут"""

    wrong_route_id = Int(db_column='wrong_route_id', primary_key=True, required=True, readonly=True)
    city_from_id = Int(db_column='city_from_id', title=u'Город вылета', required=True)
    city_via_id = Int(db_column='city_via_id', title=u'Город пересадки', required=True)
    city_to_id = Int(db_column='city_to_id', title=u'Город прилёта', required=True)


class ISpecialOffer(Interface):
    u"""Спецпредложения"""

    offer_id = Int(db_column='offer_id', primary_key=True, required=True, readonly=True)
    partner = Int(db_column='partner_id', title=u'Партнёр', required=True)
    names = MLNames(db_column='names', title=u'Название', required=True)
    begin_date = Datetime(db_column='begin_date', title=u'Дата/время начала', required=False)
    end_date = Datetime(db_column='end_date', title=u'Дата/время окончания', required=False)
    status = TextLine(db_column='status', title=u'Статус спецпредложения', min_length=0, max_length=1, required=True)
    offer_description = MLNames(db_column='offer_description', title=u'Описание', required=True)
    offer_url = MLNames(db_column='offer_url', title=u'Ссылка на спецпредложение', required=True)
    ui_languages = TextLineList(db_column='ui_languages', title=u'Языки интерфейса', required=False, separator=',')

