# -*- coding: utf-8 -*-

"""
$Id: air.py 13069 2015-05-29 08:42:40Z isoloduha $
"""
import config

from zope.interface.declarations import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import(makeVocabularyRegisterable,
                             makeIndexerRegisterable)
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexer

from rx.i18n.translation import SelfTranslationDomain, self_translated

from models.award import CARRIER_AFL, CARRIER_SKYTEAM
from models.base import WSVocabularyBase, Published
from models.interfaces import IAirline
from models.ml import MLTitleCapable

from i18n import _


MILES_NO_LIMIT = 'N'
MILES_ALL_FLIGHTS_LIMIT = 'A'
MILES_INTERNATIONAL_FLIGHTS_LIMIT = 'I'


class Airline(ActiveRecord, MLTitleCapable, Published):
    u"""Авиакомпания"""

    implements(IAirline)
    p_table_name = 'airlines'

    @property
    def is_su(self):
        return self.iata == config.AFL_AIRLINE_IATA

    @property
    def carrier(self):
        if self.is_su:
            return CARRIER_AFL
        return CARRIER_SKYTEAM

    def check_name(self, q, language):
        u"""Проверка вхождения подстроки в название Авиакомпании"""

        if not q:
            return True

        name = SelfTranslationDomain().translate(self.title.msgid,
                                                 target_language=language)

        return q.lower() in name.lower()

    @property
    def logo_urls(self):
        """ URL логотипа, определяемый по ID. Использовать вместо поля logo_url.
        """
        urldict = {lang_dir: '/'.join([
            s.rstrip('/') for s in (
                config.SKYTEAM_FILES_URL, lang_dir,
                u"%s.%s" % (self.id, config.SKYTEAM_LOGO_EXTENSION))
            ]) for lang_dir in ('logo_rus', 'logo_int')}

        return {lang: urldict.get('logo_rus' if lang == 'ru' else 'logo_int', u'')
                for lang in config.KNOWN_LANGUAGES}

    @property
    def default_logo_url(self):
        return self_translated(**self.logo_urls)

    @property
    def url_local(self):
        if not any(self.url):
            return ''

        def _split_clean(url):
            return 'http://%s' % url if url and not url.startswith('http') \
                    else url

        d = {}
        for s in self.url:
            try:
                lang, url = s.split(':', 1)
            except ValueError, e:
                e.message = repr(self.url)
                raise e
            else:
                url = _split_clean(url)
                if url:
                    d[lang] = url
        return self_translated(**d)

    @property
    def miles_limitation_verbose(self):
        if self.miles_limitation == MILES_ALL_FLIGHTS_LIMIT:
            return _(u'За полёты на расстояние менее # миль начисляется # миль.')
        if self.miles_limitation == MILES_INTERNATIONAL_FLIGHTS_LIMIT:
            return _(u'За полёты на расстояние менее # миль по международным направлениям начисляется # миль.')
        return ''

    @property
    def children(self):
        return sorted([
            ch for ch in getV('airlines').values()
            if ch.parent_airline_id == self.airline_id
            ], key=lambda ch: (ch.weight, ch.sort_title))

    @property
    def sort_title(self):
        u"""Название, по которому будет производиться сортировка."""
        return SelfTranslationDomain().translate(self.title.msgid,
                                                 target_language="en")


class AirlinesVocabulary(WSVocabularyBase):
    objectC = Airline
    makeVocabularyRegisterable('airlines')


class AirlinesByIATAIndexer(VocabularyIndexer):
    vocabulary = "airlines"

    def objectIndex(self, ob):
        return ob.iata

    def contextIndex(self, iata):
        return iata

    makeIndexerRegisterable('airlines_by_iata_idx')
