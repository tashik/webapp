# -*- coding: utf-8 -*-
import sys

from zope.interface import implements

import config

from models.base import Published, WSVocabularyBase
from models.interfaces import ISpecialOffer
from models.ml import MLTitleCapable

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary.indexer import VocabularyIndexer

from rx.i18n.translation import self_translated


class SpecialOffer(ActiveRecord, MLTitleCapable, Published):
    u"""Спецпредложения"""
    implements(ISpecialOffer)
    p_table_name = 'special_offers'

    @property
    def name(self):
        try:
            d = dict([s.split(':', 1) for s in self.names])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.names), tb
        return self_translated(**d)

    @property
    def description(self):
        try:
            d = dict([s.split(':', 1) for s in self.offer_description])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.offer_description), tb
        return self_translated(**d)

    @property
    def image(self):
        return '/'.join([
            config.PARTNERS_FILES_URL.rstrip('/'),
            'special_offers',
            u"%s.%s" % (self.id, config.PARTNERS_LOGO_EXTENSION)])

    @property
    def url(self):
        try:
            d = dict([s.split(':', 1) for s in self.safe_offer_url])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.safe_offer_url), tb

        return self_translated(**d)

    @property
    def safe_offer_url(self):
        try:
            d = dict([s.split(':', 1) for s in self.offer_url])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.offer_url), tb

        result = []
        for k, v in d.iteritems():
            if not v.startswith('http'):  # относительные ссылки преобразовываем в абсолютные
                v = u'%s%s' % (config.SPECIAL_OFFERS_URL, v.lstrip('/'))
            result.append(u'%s:%s' % (k, v))

        return result


class SpecialOffersVocabulary(WSVocabularyBase):
    u"""Справочник спецпредложений"""
    objectC = SpecialOffer
    makeVocabularyRegisterable('special_offers')


class SpecialOffersByPartnerIndexer(VocabularyIndexer):
    vocabulary = 'special_offers'

    def objectIndex(self, ob):
        return ob.partner

    def contextIndex(self, ob):
        if ob is None:
            return None
        return ob.partner_id

    makeIndexerRegisterable('special_offers_by_partner_idx')
