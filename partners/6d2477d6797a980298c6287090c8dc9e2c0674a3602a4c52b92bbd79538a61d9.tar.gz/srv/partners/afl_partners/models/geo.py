# -*- coding: utf-8 -*-

"""
$Id: $
"""
from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexer

from models.award import CARRIER_AFL, CARRIER_SKYTEAM
from models.base import WSVocabularyBase
from models.interfaces import ICountry, ICity, IAirport
from models.ml import MLTitleCapable


class Country(ActiveRecord, MLTitleCapable):
    u"""Страна"""

    implements(ICountry)
    p_table_name = 'countries'


class CountriesVocabulary(WSVocabularyBase):
    objectC = Country
    makeVocabularyRegisterable('countries')


class City(ActiveRecord, MLTitleCapable):
    u"""Населённый пункт"""

    implements(ICity)
    p_table_name = 'cities'


class CitiesVocabulary(WSVocabularyBase):
    objectC = City
    makeVocabularyRegisterable('cities')


class CitiesByIATAIndexer(VocabularyIndexer):
    vocabulary = 'cities'

    def objectIndex(self, ob):
        return ob.iata

    def contextIndex(self, iata):
        return iata

    makeIndexerRegisterable('cities_by_iata_idx')


class Airport(ActiveRecord, MLTitleCapable):
    u"""Аэропорт"""

    implements(IAirport)
    p_table_name = 'airports'

    def redemption_zone_by_airline(self, airline):
        if airline.is_su:
            return self.afl_redemption_zone
        else:
            return self.skyteam_redemption_zone

    def redemption_zone_by_carrier(self, carrier):
        if carrier == CARRIER_AFL:
            return self.afl_redemption_zone
        elif carrier == CARRIER_SKYTEAM:
            return self.skyteam_redemption_zone


class AirportsVocabulary(WSVocabularyBase):
    objectC = Airport
    makeVocabularyRegisterable('airports')


class AirportsByIATAIndexer(VocabularyIndexer):
    vocabulary = 'airports'

    def objectIndex(self, ob):
        return ob.iata

    def contextIndex(self, iata):
        return iata

    makeIndexerRegisterable('airports_by_iata_idx')


class AirportsByCityIndexer(VocabularyIndexer):
    vocabulary = 'airports'
    contextI = ICity

    def objectIndex(self, ob):
        return ob.city_id

    def contextIndex(self, ob):
        if ob is None:
            return None
        return ob.city_id

    makeIndexerRegisterable('airports_by_city_idx')

