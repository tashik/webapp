# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import Interface, implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary import getVI
from pyramid.vocabulary.indexer import VocabularyIndexer

from models.base import WSVocabularyBase
from models.interfaces import IPair


class Pair(ActiveRecord):
    u"""Пара"""

    implements(IPair)
    p_table_name = 'pairs'

    @staticmethod
    def search(a1_id, a2_id, airline_id=None):
        for ctx in (PairCtx(a1_id, a2_id, airline_id),
                    PairCtx(a2_id, a1_id, airline_id)):
            try:
                return getVI('pairs_by_ctx_idx')(context=ctx)[0]
            except IndexError:
                pass

    @staticmethod
    def search_all(a1_id, a2_id):
        result = set([])
        for ctx in (PairCtx(a1_id, a2_id),
                    PairCtx(a2_id, a1_id)):
            result |= set(getVI('all_pairs_by_ctx_idx')(context=ctx))
        return list(result)


class PairsVocabulary(WSVocabularyBase):
    u"""Справочник пар"""

    objectC = Pair
    makeVocabularyRegisterable('pairs')


class IPairCtx(Interface):
    pass


class PairCtx(object):
    implements(IPairCtx)

    def __init__(self, from_id, to_id, airline_id=None):
        self.from_id = from_id
        self.to_id = to_id
        self.airline_id = airline_id

    def to_index(self):
        if self.airline_id is None:
            return (self.from_id, self.to_id)
        return (self.from_id, self.to_id, self.airline_id)


class PairsByCtxIndexer(VocabularyIndexer):
    vocabulary = 'pairs'
    contextI = IPairCtx

    def objectIndex(self, ob):
        return (ob.airport_from_id, ob.airport_to_id, ob.airline_id)

    def contextIndex(self, ob):
        if ob is None:
            return None

        return ob.to_index()

    makeIndexerRegisterable('pairs_by_ctx_idx')


class AllPairsByCtxIndexer(VocabularyIndexer):
    vocabulary = 'pairs'
    contextI = IPairCtx

    def objectIndex(self, ob):
        return (ob.airport_from_id, ob.airport_to_id)

    def contextIndex(self, ob):
        if ob is None:
            return None

        return ob.to_index()

    makeIndexerRegisterable('all_pairs_by_ctx_idx')
