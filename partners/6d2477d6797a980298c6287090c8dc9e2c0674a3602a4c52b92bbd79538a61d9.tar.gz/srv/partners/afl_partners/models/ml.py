# -*- coding: utf-8 -*-

"""
$Id: $
"""
import sys
import zope.schema as zs
import zope.schema.interfaces as zsi
from zope.interface import implements
from pyramid.exc import PyramidException
from pyramid.ormlite.schema import List
from pyramid.ormlite.models import TitleCapable
from rx.i18n.translation import self_translated
from rx.utils.json import record_to_primitive


class MLFormatError(PyramidException):
    def __init__(self, s):
        super(PyramidException, self).__init__(msg=u'Некорректный формат многоязычной строки %r' % s)

class MLTitleCapable(TitleCapable):
    @property
    def title(self):
        try:
            if self.names == [""]:
                self.names = ["ru:"]
            d = dict([s.split(':', 1) for s in self.names])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.names), tb 
        return self_translated(**d)

    def as_primitive(self):
        ob = record_to_primitive(self)
        ob['names'] = self.names


class ITextLineList(zsi.IField):
    u""" Список текстовых строк """
    sepatator = zs.TextLine(title=u'Разделитель строк при сохранении в БД')

class TextLineList(List):
    implements(ITextLineList)

    value_type = zs.TextLine()

    def fromUnicode(self, s):
        value = [ line.strip() for line in s.strip().split('\n') ]
        self.validate(value)
        return value

    def toUnicode(self, value):
        return '\n'.join(value)

    def constraint(self, value):
        if not super(TextLineList, self).constraint(value):
            return False
        for elem in value:
            if self.separator in elem:
                return False
        return True

#    def _validate(self, value):
#        super(TextLineList, self)._validate(value)
#        if not self.constraint(value):
#            print 'hello', value
#            raise ConstraintNotSatisfied(value)


class IMLNames(ITextLineList):
    u""" Словарь многоязычных строк. Каждая строка имеет формат язык:текст """

class MLNames(TextLineList):
    implements(IMLNames)

    def __init__(self, separator='|', **kw):
        super(MLNames, self).__init__(separator=separator, **kw)

# проверку должен выполнять виджет
#    def constraint(self, value):
#        if not super(TextLineList, self).constraint(value):
#            return False
#        for elem in value:
#            if self.separator in elem:
#                return False
#            if len(elem) < 3 or elem[2] != ':':
#                return False
#        return True
