# -*- coding: utf-8 -*-

from zope.interface import Interface, implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.ormlite.models import TitleCapable
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexer

from models.base import WSVocabularyBase
from models.interfaces import IRedemptionZone, IBonusRoute, IAward, IWrongRoute
from models.ml import MLTitleCapable


CARRIER_AFL = 'A'
CARRIER_SKYTEAM = 'S'

AWARD_TYPE_OW = 'OW'
AWARD_TYPE_RT = 'RT'
AWARD_TYPE_UPGRADE_OW = 'UO'
AWARD_TYPE_UPGRADE_RT = 'U'
AWARD_TYPE_UPGRADE_CHECKIN_OW = 'UC'


class RedemptionZone(ActiveRecord, MLTitleCapable):
    u"""Премиальная зона"""

    implements(IRedemptionZone)
    p_table_name = 'redemption_zones'


class RedemptionZonesVocabulary(WSVocabularyBase):
    objectC = RedemptionZone
    makeVocabularyRegisterable('redemption_zones')


class BonusRoute(ActiveRecord, TitleCapable):
    u"""Премиальный маршрут"""

    implements(IBonusRoute)
    p_table_name = 'bonus_routes'

    @property
    def title(self):
        return self.code

    @staticmethod
    def search(z1, z2, z3, carrier=None):
        # AA-BB-CC | CC-BB-AA
        if z2 is not None:
            for ctx in (BonusRouteCtx(z1, z2, z3, carrier),
                        BonusRouteCtx(z3, z2, z1, carrier)):
                try:
                    return getVI('bonus_routes_by_ctx_idx')(context=ctx)[0]
                except IndexError:
                    pass

        # AA-CC | CC-AA
        z2 = None
        for ctx in (BonusRouteCtx(z1, z2, z3, carrier),
                    BonusRouteCtx(z3, z2, z1, carrier)):
            try:
                return getVI('bonus_routes_by_ctx_idx')(context=ctx)[0]
            except IndexError:
                pass


class BonusRoutesVocabulary(WSVocabularyBase):
    objectC = BonusRoute
    makeVocabularyRegisterable('bonus_routes')


class IBonusRouteCtx(Interface):
    pass


class BonusRouteCtx(object):
    implements(IBonusRouteCtx)

    def __init__(self, zone_from, zone_via, zone_to, carrier):
        self.zone_from = zone_from
        self.zone_via = zone_via
        self.zone_to = zone_to
        self.carrier = carrier

    def to_index(self):
        return (self.zone_from, self.zone_via, self.zone_to, self.carrier)


class BonusRoutesByCtxIndexer(VocabularyIndexer):
    vocabulary = 'bonus_routes'
    contextI = IBonusRouteCtx

    def objectIndex(self, ob):
        return (ob.zone_from, ob.zone_via, ob.zone_to, ob.carrier)

    def contextIndex(self, ob):
        if ob is None:
            return None

        return ob.to_index()

    makeIndexerRegisterable('bonus_routes_by_ctx_idx')


class Award(ActiveRecord, TitleCapable):
    u"""Премия"""

    implements(IAward)
    p_table_name = 'awards'

    @property
    def title(self):
        result = ''

        skyteam_sc_1 = self.skyteam_sc_1
        if skyteam_sc_1 is None:
            return result

        skyteam_sc_2 = self.skyteam_sc_2
        if skyteam_sc_2 is not None:
            award_type_map = {
                AWARD_TYPE_UPGRADE_OW: u'OW',
                AWARD_TYPE_UPGRADE_RT: u'RT',
                AWARD_TYPE_UPGRADE_CHECKIN_OW: u'OnCheckin'
            }

            award_type = award_type_map.get(self.award_type, '')

            result = 'upgrade%s2%s%s' % (skyteam_sc_1.code.capitalize(),
                                         skyteam_sc_2.code.capitalize(),
                                         award_type)
        else:
            result = '%s%sMiles' % (skyteam_sc_1.code, self.award_type)

        return result

    @property
    def skyteam_sc_1(self):
        try:
            return getV('skyteam_service_classes')[self.skyteam_service_class_id_1]
        except LookupError:
            pass

    @property
    def skyteam_sc_2(self):
        try:
            return getV('skyteam_service_classes')[self.skyteam_service_class_id_2]
        except LookupError:
            pass


class AwardsVocabulary(WSVocabularyBase):
    objectC = Award
    makeVocabularyRegisterable('awards')


class AwardsByBonusRouteIndexer(VocabularyIndexer):
    vocabulary = 'awards'
    contextI = IBonusRoute

    def objectIndex(self, ob):
        return ob.bonus_route_id

    def contextIndex(self, ob):
        if ob is None:
            return None
        return ob.bonus_route_id

    makeIndexerRegisterable('awards_by_bonus_route_idx')


class WrongRoute(ActiveRecord):
    u"""Запрещённый маршрут"""

    implements(IWrongRoute)
    p_table_name = 'wrong_routes'

    @staticmethod
    def search(c1_id, c2_id, c3_id):
        for ctx in (WrongRouteCtx(c1_id, c2_id, c3_id),
                    WrongRouteCtx(c3_id, c2_id, c1_id)):
            try:
                return getVI('wrong_routes_by_ctx_idx')(context=ctx)[0]
            except IndexError:
                pass


class WrongRoutesVocabulary(WSVocabularyBase):
    objectC = WrongRoute
    makeVocabularyRegisterable('wrong_routes')


class IWrongRouteCtx(Interface):
    pass


class WrongRouteCtx(object):
    implements(IWrongRouteCtx)

    def __init__(self, c1_id, c2_id, c3_id):
        self.c1_id = c1_id
        self.c2_id = c2_id
        self.c3_id = c3_id

    def to_index(self):
        return (self.c1_id, self.c2_id, self.c3_id)


class WrongRoutesByCtxIndexer(VocabularyIndexer):
    vocabulary = 'wrong_routes'
    contextI = IWrongRouteCtx

    def objectIndex(self, ob):
        return (ob.city_from_id, ob.city_via_id, ob.city_to_id)

    def contextIndex(self, ob):
        if ob is None:
            return None

        return ob.to_index()

    makeIndexerRegisterable('wrong_routes_by_ctx_idx')

