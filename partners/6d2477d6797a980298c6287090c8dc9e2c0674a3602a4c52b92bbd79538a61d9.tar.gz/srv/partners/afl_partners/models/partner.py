# -*- coding: utf-8 -*-

"""
$Id: $
"""
import sys
from datetime import datetime, date

from zope.interface import implements
from zope.schema.interfaces import ITokenizedTerm

from pyramid.ormlite.record import ActiveRecord
from pyramid.ormlite.models import TitleCapable
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexer

from rx.i18n.translation import SelfTranslationDomain, self_translated

import config

from models.base import WSVocabularyBase, Published
from models.interfaces import (IPartnerCategory, IPartner, IPartnerOfficeContact,
                               IPartnerOffice, IPartnerAwardCondition)
from models.ml import MLTitleCapable


AC_ALL = 'A'
AC_EARN = 'E'
AC_SPEND = 'S'

CT_PHONE = 'P'
CT_FAX = 'F'
CT_EMAIL = 'E'

OT_MAIN = 'M'
OT_OTHER = 'O'


class PartnerCategory(ActiveRecord, MLTitleCapable, Published):
    u"""Категория партнёров-неавиакомпаний"""

    implements(IPartnerCategory)
    p_table_name = 'partner_categories'


class PartnerCategoriesVocabulary(WSVocabularyBase):
    u"""Справочник категорий партнёров-неавиакомпаний"""

    objectC = PartnerCategory
    makeVocabularyRegisterable('partner_categories')


class Partner(ActiveRecord, MLTitleCapable, Published):
    u"""Партнёр-неавиакомпания"""

    implements(IPartner)
    p_table_name = 'partners'

    @property
    def image(self):
        return '/'.join([config.PARTNERS_FILES_URL.rstrip('/'), 'images',
                         u"%s.%s" % (self.id, config.PARTNERS_LOGO_EXTENSION)])

    @property
    def default_logo_url(self):
        return self_translated(**self.logo_urls)

    def _logo_urls(self, base_url=None):
        """ URL логотипа, определяемый по ID. Использовать вместо поля logo_url.
        """
        base_url = base_url or config.PARTNERS_FILES_URL

        urldict = {lang_dir: '/'.join([
            s.rstrip('/') for s in (
                base_url, lang_dir,
                u"%s.%s" % (self.id, config.PARTNERS_LOGO_EXTENSION))
            ]) for lang_dir in ('logo_rus', 'logo_int')}

        return {lang: urldict.get('logo_rus' if lang == 'ru' else 'logo_int', u'')
                for lang in config.KNOWN_LANGUAGES}

    @property
    def logo_urls(self):
        u"""URL для UI"""
        return self._logo_urls()

    @property
    def logo_svc_urls(self):
        u"""URL для сервисов, которые используют мобильные приложения"""
        return self._logo_urls(base_url=config.PARTNERS_SVC_FILES_URL)

    @property
    def description(self):
        try:
            d = dict([s.split(':', 1) for s in self.partner_description])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.partner_description), tb
        return self_translated(**d)

    @property
    def mile_earn_comment(self):
        try:
            d = dict([s.split(':', 1) for s in self.mile_get_comm])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.mile_get_comm), tb
        return self_translated(**d)

    @property
    def mile_spend_comment(self):
        try:
            d = dict([s.split(':', 1) for s in self.mile_waste_comm])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.mile_waste_comm), tb
        return self_translated(**d)

    @property
    def special_offers_comment(self):
        try:
            d = dict([s.split(':', 1) for s in self.spec_offer_comm if s])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.spec_offer_comm), tb
        return self_translated(**d)

    @property
    def short_description(self):
        try:
            d = dict([s.split(':', 1) for s in self.short_descr])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.short_descr), tb
        return self_translated(**d)

    @property
    def url_local(self):
        if not any(self.url):
            return ''

        def _split_clean(s):
            lang, url = s.split(':', 1)
            if not url.startswith('http'):
                url = 'http://%s' % url
            return [lang, url]

        try:
            d = dict([_split_clean(s) for s in self.url])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.url), tb

        return self_translated(**d)

    @property
    def is_new(self):
        return self.new_until is not None and self.new_until > date.today()

    def get_offices(self):
        u"""Получение списка филиалов партнёра"""

        vocab = getV('partner_offices')
        token = ITokenizedTerm(self).token
        res = []
        for office in vocab:
            if str(office.partner) == token:
                res.append(office)
        return res

    def get_award_conditions(self):
        u"""Получение списка условий набора и траты миль"""
        return [cond for cond in getVI('partner_awards_conditions_by_partner_idx')(context=self)
                if cond.published]

    def get_special_offers(self, lang=None):
        u"""Получение списка специальных предложений"""
        now = datetime.now()

        offer_filter = lambda offer: offer.published \
            and (lang is None or lang in offer.ui_languages) \
            and (not offer.begin_date or offer.begin_date <= now) \
            and (not offer.end_date or offer.end_date >= now)

        return filter(offer_filter, getVI('special_offers_by_partner_idx')(context=self))

    def check_city(self, city):
        u"""Доступен ли партнёр в запрашиваемом городе"""

        #if ICity.providedBy(city):
        #    city = city.city_id

        try:
            city = int(city)
        except ValueError:
            return False

        return city in [x.city for x in self.get_offices()]

    def check_country(self, country):
        u"""Доступен ли партнёр в запрашиваемой стране"""

        #if ICountry.providedBy(country):
        #    country = country.country

        cities_vocab = getV('cities')
        countries = set([])
        for city_id in [x.city for x in self.get_offices()]:
            try:
                city = cities_vocab[city_id]
            except LookupError:
                continue

            countries.add(city.country_code)

        return country in countries

    def check_categories(self, categories):
        u"""Доступен ли партнёр в запрашиваемых категориях"""

        if not isinstance(categories, (list, tuple)):
            categories = [categories]

        if not categories:
            return True

        c1 = set(map(int, categories))
        c2 = set(map(int, self.partner_categories))

        if len(c1 & c2):
            return True
        return False

    def check_name(self, q, language):
        u"""Проверка вхождения подстроки в название партнёра"""

        if not q:
            return True

        name = SelfTranslationDomain().translate(self.title.msgid,
                                                 target_language=language)

        return q.lower() in name.lower()

    def check_award_condition_types(self, types):
        u"""Проверка наличия у партнёра условий набора и траты миль определённого типа"""

        if not isinstance(types, (list, tuple)):
            types = [types]

        if not types:
            return True

        award_condition_types = [x.award_condition_type for x in self.get_award_conditions()]

        if not award_condition_types:
            return False

        if len(set(types) & set(award_condition_types)):
            return True
        return False

    def check_mile_action(self, action):
        u"""Проверка возможности определённого действия с милями"""

        if action not in (AC_ALL, AC_EARN, AC_SPEND):
            return False

        if action == AC_ALL:
            return True

        return self.mile_action in (AC_ALL, action)


class PartnersVocabulary(WSVocabularyBase):
    u"""Справочник партнёров-неавиакомпаний"""

    objectC = Partner
    makeVocabularyRegisterable('partners')


class PartnerOffice(ActiveRecord):
    u"""Филиал партнёра-неавиакомпании"""

    implements(IPartnerOffice)
    p_table_name = 'partner_offices'

    def delete(self):
        self.contacts = []
        super(PartnerOffice, self).delete()

    def get_contacts(self):
        vocab = getV('partner_office_contacts')
        token = ITokenizedTerm(self).token
        contacts = []
        for contact in vocab:
            if str(contact.partner_office) == token:
                contacts.append(contact)
        return contacts

    def set_contacts(self, contacts):
        if contacts is None:
            contacts = []

        input_ids = set([ITokenizedTerm(c).token for c in contacts])

        removed_ids = set([])
        for contact in self.contacts:
            token = ITokenizedTerm(contact).token
            if token not in input_ids:
                removed_ids.add(token)

        vocab = getV('partner_office_contacts')
        for c_id in removed_ids:
            vocab[c_id].delete()
        vocab.delete_many(removed_ids)

        for c in contacts:
            c.partner_office = self.partner_office_id
            c.save()
        vocab.update_many(contacts)

    contacts = property(get_contacts, set_contacts)

    def check_city(self, city):
        u"""Доступен ли Филиал партнёра-неавиакомпании в запрашиваемом городе"""

        try:
            city = int(city)
        except ValueError:
            return False

        return city == self.city

    def check_country(self, country):
        u"""Доступен ли Филиал партнёра-неавиакомпании в запрашиваемой стране"""

        cities_vocab = getV('cities')
        try:
            city = cities_vocab[self.city]
        except LookupError:
            return False

        return country == city.country_code

    @property
    def office_comments(self):
        try:
            d = dict([s.split(':', 1) for s in self.comments])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.comments), tb
        return self_translated(**d)

    @property
    def office_address(self):
        try:
            d = dict([s.split(':', 1) for s in self.address])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.address), tb
        return self_translated(**d)

    @property
    def office_worktime(self):
        try:
            d = dict([s.split(':', 1) for s in self.worktime])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.worktime), tb
        return self_translated(**d)


class PartnerOfficesVocabulary(WSVocabularyBase):
    u"""Справочник филиалов партнёра-неавиакомпании"""

    objectC = PartnerOffice
    makeVocabularyRegisterable('partner_offices')


class PartnerOfficeContact(ActiveRecord, TitleCapable):
    u"""Контакт филиала партнёра-неавиакомпании"""

    implements(IPartnerOfficeContact)
    p_table_name = 'partner_office_contacts'


class PartnerOfficeContactsVocabulary(WSVocabularyBase):
    u"""Справочник контактов филиалов партнёров-неавиакомпаний"""

    objectC = PartnerOfficeContact
    makeVocabularyRegisterable('partner_office_contacts')


class PartnerAwardCondition(ActiveRecord, Published):
    u"""Условие набора и траты миль для партнёров-неавиакомпаний"""

    implements(IPartnerAwardCondition)
    p_table_name = 'partner_award_conditions'

    @property
    def description(self):
        try:
            d = dict([s.split(':', 1) for s in self.award_condition_description])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.names), tb
        return self_translated(**d)

    @property
    def is_earning(self):
        return self.award_condition_type == AC_EARN

    @property
    def is_spending(self):
        return self.award_condition_type == AC_SPEND


class PartnerAwardConditionsVocabulary(WSVocabularyBase):
    u"""Справочник условий набора и траты миль для партнёров-неавиакомпаний"""

    objectC = PartnerAwardCondition
    makeVocabularyRegisterable('partner_award_conditions')


class PartnerAwardConditionsByPartnerIndexer(VocabularyIndexer):
    vocabulary = "partner_award_conditions"

    def objectIndex(self, ob):
        return ob.partner

    def contextIndex(self, ob):
        if ob is not None:
            return ob.partner_id

    makeIndexerRegisterable('partner_awards_conditions_by_partner_idx')
