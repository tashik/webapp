# -*- coding: utf-8 -*-
"""
$Id: __init__.py 7489 2014-10-29 14:23:22Z ogambaryan $
"""

from zope.component import getUtility
from pyramid.auth.interfaces import ICredentialsDataSource,\
    IAuthenticationDataSource, IAuthenticator
from pyramid.auth.exc import AuthorizationError

def authorizeFor(obj):
    return False


def authorize(method):
    """Authorization decorator for object methods.
    
    Usage:
    
    class Foo():
    
        @authorize()
        def some_method(self, params):
            pass
    
    Authorizes method access before calling.
    """
    def decorator(self, *args, **kwargs):
        authorizeFor(self)
        return method(self, *args, **kwargs)
    return decorator
