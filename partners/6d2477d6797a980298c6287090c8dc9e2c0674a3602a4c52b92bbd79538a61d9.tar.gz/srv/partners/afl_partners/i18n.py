# -*- coding: utf-8 -*-

"""
$Id: i18n.py 20261 2016-08-08 11:41:22Z oeremeeva $
"""
import cherrypy

import config

from django.utils.html import conditional_escape
from zope.component import queryUtility, getUtility
from zope.i18n.interfaces import INegotiator, ILanguageAvailability

from pyramid.i18n.message import MessageFactory
from pyramid.i18n.negotiator import CPCookieUserPreferredLanguages

_ = MessageFactory('messages')
__ = unicode


class CookieUserPreferredLocalization(CPCookieUserPreferredLanguages):
    def __init__(self):
        super(CookieUserPreferredLocalization, self).__init__()
        self.key = (self.prefix or '') + config.LOCALE_COOKIE_NAME

    def getPreferredLocalization(self):
        cookie = cherrypy.request.cookie.get(self.key)
        if cookie:
            return cookie.value

def get_available_languages():
    language_names = {
        'ru': u'RUS',
        'en': u'ENG',
        'de': u'DEU',
        'fr': u'FRA',
        'es': u'ESP',
        'it': u'ITA',
        'zh': u'中文',
        'ja': u'日本語',
        'ko': u'한국어'}
    available_langs = config.KNOWN_LANGUAGES
    return [(elem, language_names.get(elem, 'UNK')) for elem in available_langs]


def get_languages_with_available_translations():
    util = queryUtility(ILanguageAvailability)

    available = []
    if util is None:
        return config.KNOWN_LANGUAGES
    for elem in util.getAvailableLanguages():
        available.append(elem[0] if isinstance(elem, tuple) else elem)
    return available


def _get_available_languages():
    result = []
    util = queryUtility(ILanguageAvailability)
    if util is not None:
        for elem in util.getAvailableLanguages():
            if isinstance(elem, (list, tuple)):
                result.append(elem[0])
            else:
                result.append(elem)
    else:
        result = config.KNOWN_LANGUAGES
    return result


def safe_render_multilang(current_lang, multilang_text):
    default_result = ''
    text_localized = None
    for text in multilang_text:
        try:
            l, t = text.split(':', 1)
        except IndexError:
            continue
        else:
            if l == current_lang:
                text_localized = t
            elif l == config.FALLBACK_LANGUAGES[0]:
                default_result = t
    if text_localized is None:
        text_localized = default_result
    safe_text = conditional_escape(text_localized)
    safe_text = safe_text.replace('\n', '<br />\n')
    return safe_text

#
# def get_current_lang():
#     """ Язык интерфейса, отображаемый в переключателе."""
#     negotiator = queryUtility(INegotiator)
#     if negotiator is not None:
#         lang = negotiator.getLanguage(config.KNOWN_LANGUAGES, None)
#         if lang:
#             return lang
#     return config.FALLBACK_LANGUAGES[0]

#def get_current_lang():
#    """ Заглушка для "определения текущего языка"
#
#    см. rx.i18n.get_current_lang
#    """
#    return 'ru'

def _get_lang(available=None):
    negotiator = queryUtility(INegotiator)
    if negotiator is not None:
        if not available:
            available = [elem[0] for elem in getUtility(ILanguageAvailability).getAvailableLanguages()]
        lang = negotiator.getLanguage(available, None)
        if lang:
            return lang
    return config.DEFAULT_LANG

def _get_localization():
    localization = CookieUserPreferredLocalization().getPreferredLocalization()
    return localization.lower() if localization else config.DEFAULT_LOCALIZATION


def get_current_lang():
    return cherrypy.request.current_lang

def get_current_localization():
    return cherrypy.request.current_locale