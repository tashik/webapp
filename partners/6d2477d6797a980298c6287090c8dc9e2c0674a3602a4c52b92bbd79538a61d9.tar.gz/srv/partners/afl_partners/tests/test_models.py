# -*- coding: utf-8 -*-

"""
$Id: test_models.py 7026 2014-10-07 16:06:16Z ogambaryan $
"""


import testoob

from pyramid.ormlite import dbquery
from pyramid.tests import testlib


# Тест на то, что используется тестовая БД
class TestDBConnection(testlib.TestCaseWithPgDB):
    def test_db_connection(self):
        cursor = dbquery("select current_database();").fetchall()
        self.assertEqual(len(cursor), 1)
        self.assertTrue(cursor[0][0].endswith('_test'))


if __name__ == "__main__":
    testoob.main()
