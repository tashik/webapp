# -*- coding: utf-8 -*-

"""
$Id:
"""

import mock
import testoob
import cherrypy

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary

import logic.skyteam
import models.air
import models.bonus
import models.geo
import models.route


class TestLogicSkyTeam(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestLogicSkyTeam, self).setUp()
        cherrypy.request.current_lang = 'ru'

    def registerVocabularies(self):
        super(TestLogicSkyTeam, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer), 'tier_level_factors_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer), 'airline_tariff_groups_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.BookingClassesByAirlineTariffGroupIndexer), 'booking_classes_by_airline_tariff_group_idx')

    @mock.patch('logic.geo.LOG')
    def test_load_airline(self, mock_log):
        ob = logic.skyteam.load_airline(-1)
        self.assertTrue(isinstance(ob, models.air.Airline))
        self.assertTrue(ob.iata, 'ITA')

        ob = logic.geo.load_airport(-100)
        self.assertIsNone(ob)
        self.assertEqual(mock_log.call_count, 1)

    def test_load_airline_by_iata(self):
        ob = logic.skyteam.load_airline_by_iata('SU')
        self.assertTrue(isinstance(ob, models.air.Airline))
        self.assertTrue(ob.airline_id, -1)

        ob = logic.skyteam.load_airline_by_iata('XX')
        self.assertIsNone(ob)

    def test_flight_code(self):
        ob = logic.skyteam.load_airline(-6)
        with mock.patch('logic.skyteam.flight_code_mapping', {'VX': 'XX'}):
            self.assertEqual(logic.skyteam.flight_code(ob), 'VX')

        with mock.patch('logic.skyteam.flight_code_mapping', {'VX': 'SU'}):
            self.assertEqual(logic.skyteam.flight_code(ob), 'SU')
            ob = logic.skyteam.load_airline(-5)
            self.assertEqual(logic.skyteam.flight_code(ob), 'VN')
            ob = logic.skyteam.load_airline(-1)
            self.assertEqual(logic.skyteam.flight_code(ob), 'SU')

    def test_available_tier_levels(self):
        tier_levels = logic.skyteam.available_tier_levels(-1)
        self.assertIn(u'xxx', tier_levels)
        self.assertIn(u'silver', tier_levels)
        self.assertNotIn(u'gold', tier_levels)

        tier_levels = logic.skyteam.available_tier_levels(models.air.Airline.load(airline_id=-1))
        self.assertEqual(len(tier_levels), 2)

        tier_levels = logic.skyteam.available_tier_levels(-2)
        self.assertIn(u'gold', tier_levels)
        self.assertNotIn(u'silver', tier_levels)
        self.assertNotIn(u'xxx', tier_levels)

    def test_resolve_tier_level_factor(self):
        ob = logic.skyteam.resolve_tier_level_factor('xxx', -1)
        self.assertTrue(isinstance(ob, models.bonus.TierLevelFactor))
        self.assertEqual(ob.tier_level, 'xxx')
        self.assertEqual(ob.airline_id, -1)

        ob = logic.skyteam.resolve_tier_level_factor('xxx', models.air.Airline.load(airline_id=-1))
        self.assertTrue(isinstance(ob, models.bonus.TierLevelFactor))
        self.assertEqual(ob.tier_level, 'xxx')
        self.assertEqual(ob.airline_id, -1)

        ob = logic.skyteam.resolve_tier_level_factor('xxx', -2)
        self.assertIsNone(ob)

    def test_tariff_groups_by_booking_class(self):
        tariff_groups = logic.skyteam.tariff_groups_by_booking_class(-1, 'X')
        self.assertTrue(isinstance(tariff_groups, list))
        self.assertEqual(tariff_groups, [u'yyy-vvv'])
        tariff_groups = logic.skyteam.tariff_groups_by_booking_class(airline=models.air.Airline.load(airline_id=-1), booking_class_code='X')
        self.assertTrue(isinstance(tariff_groups, list))
        self.assertEqual(tariff_groups, [u'yyy-vvv'])
        # Проверяем, что если групп несколько, они сортируются по коэффициенту набора
        tariff_groups = logic.skyteam.tariff_groups_by_booking_class(-1, 'A')
        self.assertTrue(isinstance(tariff_groups, list))
        self.assertEqual(tariff_groups, [u'yyy-zzz', u'business-optimum', u'business-optimum'])
        atg_dict = getV('airline_tariff_groups')
        atg = atg_dict["-2"]
        tmp_coef = atg.charge_coef
        atg.charge_coef = 1
        atg_dict.update_many([atg])
        tariff_groups = logic.skyteam.tariff_groups_by_booking_class(-1, 'A')
        self.assertEqual(tariff_groups, [u'business-optimum', u'yyy-zzz', u'business-optimum'])
        atg.charge_coef = tmp_coef
        atg_dict.update_many([atg])

    def test_available_tariff_groups(self):
        tariff_groups = logic.skyteam.available_tariff_groups(-1)
        self.assertIn(u'yyy-zzz', tariff_groups)
        self.assertIn(u'business-optimum', tariff_groups)
        self.assertNotIn(u'business-premium', tariff_groups)

        tariff_groups = logic.skyteam.available_tariff_groups(airline=models.air.Airline.load(airline_id=-1))
        self.assertEqual(len(tariff_groups), 5)

        tariff_groups = logic.skyteam.available_tariff_groups(-3)
        self.assertNotIn(u'yyy-zzz', tariff_groups)
        self.assertNotIn(u'business-optimum', tariff_groups)
        self.assertIn(u'business-premium', tariff_groups)

    def test_available_booking_classes(self):
        bcls = logic.skyteam.available_booking_classes(-1)
        self.assertIn(-1, bcls)
        self.assertIn(-3, bcls)

        bcls = logic.skyteam.available_booking_classes(airline=models.air.Airline.load(airline_id=-1))
        self.assertIn(-1, bcls)
        self.assertIn(-3, bcls)

        self.assertFalse(logic.skyteam.available_booking_classes(-2))

    def test_get_miles_table(self):
        # заглушка - всегда возвращает экземпляр SkyTeamServiceClass
        # вне зависимости от переданного языка
        sc_fnc = lambda ob, lang: ob

        miles_table = logic.skyteam.get_miles_table(-1, sc_fnc=sc_fnc, lang='ru')  # [(-1, [([u'A'], 75), ([], 100)])]
        self.assertEqual(2, len(miles_table))
        self.assertTrue(isinstance(miles_table[0][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:Business', miles_table[0][0].names)
        self.assertIn(u'ru:Бизнес', miles_table[0][0].names)
        self.assertTrue(isinstance(miles_table[1][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:YYY', miles_table[1][0].names)
        self.assertIn(u'ru:XXX', miles_table[1][0].names)
        self.assertEqual(1, len(miles_table[0][1]))
        self.assertEqual(2, len(miles_table[1][1]))
        self.assertIn(([{'code': u'A', 'id': -4}], 150), miles_table[0][1])
        self.assertIn(([{'code': u'A', 'id': -1}], 75), miles_table[1][1])
        self.assertIn(([], 100), miles_table[1][1])

        miles_table = logic.skyteam.get_miles_table(models.air.Airline.load(airline_id=-1), sc_fnc=sc_fnc, lang='ru')
        self.assertEqual(2, len(miles_table))
        self.assertTrue(isinstance(miles_table[0][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:Business', miles_table[0][0].names)
        self.assertIn(u'ru:Бизнес', miles_table[0][0].names)
        self.assertTrue(isinstance(miles_table[1][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:YYY', miles_table[1][0].names)
        self.assertIn(u'ru:XXX', miles_table[1][0].names)
        self.assertEqual(1, len(miles_table[0][1]))
        self.assertEqual(2, len(miles_table[1][1]))
        self.assertIn(([{'code': u'A', 'id': -4}], 150), miles_table[0][1])
        self.assertIn(([{'code': u'A', 'id': -1}], 75), miles_table[1][1])
        self.assertIn(([], 100), miles_table[1][1])

    def test_extend_miles_table(self):
        sc_fnc = lambda ob, lang: ob
        miles_table = logic.skyteam.get_miles_table(-1, sc_fnc=sc_fnc, lang='ru')

        ml_fnc = lambda val, lang: val
        bcc = logic.skyteam.extend_miles_table(miles_table, ml_fnc=ml_fnc, lang='ru')

        self.assertEqual(2, len(bcc))
        self.assertEqual(1, bcc[0][0])
        self.assertIn(u'ru:ruAAA', bcc[0][1])
        self.assertIn(u'en:enAAA', bcc[0][1])
        self.assertEqual(2, bcc[1][0])
        self.assertIn(u'ru:ruA', bcc[1][1])
        self.assertIn(u'en:enA', bcc[1][1])

        row = miles_table[0][1][0]
        booking_class = row[0][0]

        self.assertIn('note', booking_class)
        self.assertEqual(1, booking_class['note'])

        row = miles_table[1][1][1]
        booking_class = row[0][0]
        self.assertIn('note', booking_class)
        self.assertEqual(2, booking_class['note'])


    def test_get_miles_table_with_tariff_code(self):
        # заглушка - всегда возвращает экземпляр SkyTeamServiceClass
        # вне зависимости от переданного языка
        sc_fnc = lambda ob, lang: ob

        miles_table = logic.skyteam.get_miles_table_with_tariff_code(-1, sc_fnc=sc_fnc, lang='ru')
        #[(skyteam_service_classes, [(tariff_groups, [({'code': u'AF', 'id': -7}, coef), ...]), ...]),...]

        self.assertEqual(2, len(miles_table))
        self.assertTrue(isinstance(miles_table[0][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:Business', miles_table[0][0].names)
        self.assertIn(u'ru:Бизнес', miles_table[0][0].names)
        self.assertTrue(isinstance(miles_table[1][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:Comfort', miles_table[1][0].names)
        self.assertIn(u'ru:Комфорт', miles_table[1][0].names)

        self.assertEqual(1, len(miles_table[0][1]))
        self.assertEqual(2, len(miles_table[1][1]))


        self.assertTrue(isinstance(miles_table[0][1][0][0], models.bonus.TariffGroup))
        self.assertTrue(isinstance(miles_table[1][1][0][0], models.bonus.TariffGroup))
        self.assertTrue(isinstance(miles_table[1][1][1][0], models.bonus.TariffGroup))

        self.assertEqual([([{'code': u'GK', 'id': -9}], 200), ([{'code': u'AF', 'id': -7}, {'code': u'ZF', 'id': -8}], 150)], miles_table[0][1][0][1])
        self.assertEqual([([{'code': u'IN', 'id': -10}, {'code': u'KN', 'id': -11}], 250)], miles_table[1][1][0][1])
        self.assertEqual([([{'code': u'QS', 'id': -6}], 125)], miles_table[1][1][1][1])

        miles_table = logic.skyteam.get_miles_table_with_tariff_code(models.air.Airline.load(airline_id=-1), sc_fnc=sc_fnc, lang='ru')
        self.assertEqual(2, len(miles_table))
        self.assertTrue(isinstance(miles_table[0][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:Business', miles_table[0][0].names)
        self.assertIn(u'ru:Бизнес', miles_table[0][0].names)
        self.assertTrue(isinstance(miles_table[1][0], models.bonus.SkyTeamServiceClass))
        self.assertIn(u'en:Comfort', miles_table[1][0].names)
        self.assertIn(u'ru:Комфорт', miles_table[1][0].names)
        self.assertEqual(1, len(miles_table[0][1]))
        self.assertEqual(2, len(miles_table[1][1]))


        self.assertTrue(isinstance(miles_table[0][1][0][0], models.bonus.TariffGroup))
        self.assertTrue(isinstance(miles_table[1][1][0][0], models.bonus.TariffGroup))
        self.assertTrue(isinstance(miles_table[1][1][1][0], models.bonus.TariffGroup))

        self.assertEqual([([{'code': u'GK', 'id': -9}], 200), ([{'code': u'AF', 'id': -7}, {'code': u'ZF', 'id': -8}], 150)], miles_table[0][1][0][1])
        self.assertEqual([([{'code': u'IN', 'id': -10}, {'code': u'KN', 'id': -11}], 250)], miles_table[1][1][0][1])
        self.assertEqual([([{'code': u'QS', 'id': -6}], 125)], miles_table[1][1][1][1])


    def test_extend_miles_table_with_tariff_code(self):
        sc_fnc = lambda ob, lang: ob
        miles_table = logic.skyteam.get_miles_table_with_tariff_code(-1, sc_fnc=sc_fnc, lang='ru')

        ml_fnc = lambda val, lang: val
        bcc = logic.skyteam.extend_miles_table_with_tariff_code(miles_table, ml_fnc=ml_fnc, lang='ru')

        self.assertEqual(6, len(bcc))
        self.assertEqual(1, bcc[0][0])
        self.assertIn(u'ru:Тест новых тарифов Бизнес-Оптимум', bcc[0][1])
        self.assertIn(u'en:New Business-Optimum tariff tests', bcc[0][1])
        self.assertEqual(6, bcc[5][0])
        self.assertIn(u'ru:Тест новых тарифов Бизнес-Премиум', bcc[4][1])
        self.assertIn(u'en:New Business-Premium tariff tests', bcc[4][1])

        row = miles_table[0][1][0]
        booking_class = row[1][0][0][0]

        self.assertIn('note', booking_class)
        self.assertEqual(1, booking_class['note'])

        row = miles_table[1][1][1]
        booking_class = row[1][0][0][0]
        self.assertIn('note', booking_class)
        self.assertEqual(6, booking_class['note'])

    def test_search_skyteam_airlines(self):
        airlines = getV('airlines')
        self.assertEqual(len(airlines), 7)

        skyteam_airlines = logic.skyteam.search_skyteam_airlines()
        self.assertTrue(airlines[-1] in skyteam_airlines)
        self.assertTrue(airlines[-3] in skyteam_airlines)
        self.assertFalse(airlines[-4] in skyteam_airlines)
        self.assertFalse(airlines[-5] in skyteam_airlines)
        self.assertFalse(airlines[-6] in skyteam_airlines)
        self.assertFalse(airlines[-8] in skyteam_airlines)

        skyteam_airlines = logic.skyteam.search_skyteam_airlines(full=True)
        self.assertTrue(airlines[-1] in skyteam_airlines)
        self.assertTrue(airlines[-3] in skyteam_airlines)
        self.assertFalse(airlines[-4] in skyteam_airlines)
        self.assertTrue(airlines[-5] in skyteam_airlines)
        self.assertTrue(airlines[-6] in skyteam_airlines)
        self.assertFalse(airlines[-8] in skyteam_airlines)

        skyteam_airlines = logic.skyteam.search_skyteam_airlines(u'Авиако')
        self.assertFalse(airlines[-1] in skyteam_airlines)  # not match, Skyteam
        self.assertFalse(airlines[-2] in skyteam_airlines)  # match, not Skyteam
        self.assertTrue(airlines[-3] in skyteam_airlines)  # match, Skyteam
        self.assertFalse(airlines[-4] in skyteam_airlines)  # not match, not Skyteam
        self.assertFalse(airlines[-5] in skyteam_airlines)  # not match, Skyteam, has parent airline
        self.assertFalse(airlines[-8] in skyteam_airlines)


class TestMilesCalculator(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def registerVocabularies(self):
        super(TestMilesCalculator, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    def test_calculate_error(self):
        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        self.assertRaises(AssertionError, logic.skyteam.MilesCalculator, -1, -3, 0, 0)
        self.assertRaises(AssertionError, logic.skyteam.MilesCalculator, -1, -3, tier_level_factor, 0)
        self.assertRaises(AssertionError, logic.skyteam.MilesCalculator, -1, -3, models.bonus.TierLevelFactor.load(tier_level_factor_id=-3), airline_tariff_group)

    def test_calculate_standard(self):
        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        c = logic.skyteam.MilesCalculator(-1, -3, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '1000'), attrs)
        self.assertIn(('chargedMiles', '1313'), attrs)
        self.assertIn(('qualifyingMiles', '750'), attrs)
        self.assertIn(('bonusMiles', '563'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)

    def test_calculate_min_tariff_miles(self):
        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        c = logic.skyteam.MilesCalculator(-1, -4, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '500'), attrs)
        self.assertIn(('chargedMiles', '875'), attrs)
        self.assertIn(('qualifyingMiles', '500'), attrs)
        self.assertIn(('bonusMiles', '375'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)

    def test_calculate_charge_coef(self):
        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-2)

        c = logic.skyteam.MilesCalculator(-1, -3, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '1000'), attrs)
        self.assertIn(('chargedMiles', '2250'), attrs)
        self.assertIn(('qualifyingMiles', '1500'), attrs)
        self.assertIn(('bonusMiles', '750'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)

    def test_calculate_wrong_pair(self):
        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        c = logic.skyteam.MilesCalculator(-1, -6, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '0'), attrs)
        self.assertIn(('chargedMiles', '0'), attrs)
        self.assertIn(('qualifyingMiles', '0'), attrs)
        self.assertIn(('bonusMiles', '0'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)

    def test_calculate_miles_no_limit(self):
        airline = models.air.Airline.load(airline_id=-1)
        airline.miles_limitation = models.air.MILES_NO_LIMIT
        airline.save()
        getV('airlines').update_many([airline])

        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        c = logic.skyteam.MilesCalculator(-1, -4, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '500'), attrs)
        self.assertIn(('chargedMiles', '656'), attrs)
        self.assertIn(('qualifyingMiles', '375'), attrs)
        self.assertIn(('bonusMiles', '281'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)

    def test_calculate_miles_international_flights_limit(self):
        airline = models.air.Airline.load(airline_id=-1)
        airline.miles_limitation = models.air.MILES_INTERNATIONAL_FLIGHTS_LIMIT
        airline.save()
        getV('airlines').update_many([airline])

        tier_level_factor = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        airline_tariff_group = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        # не международный перелёт
        c = logic.skyteam.MilesCalculator(-1, -4, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '500'), attrs)
        self.assertIn(('chargedMiles', '656'), attrs)
        self.assertIn(('qualifyingMiles', '375'), attrs)
        self.assertIn(('bonusMiles', '281'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)

        city = models.geo.City.load(city_id=-2)
        city.country_code = 'YY'
        city.save()
        getV('cities').update_many([city])

        # международный перелёт
        c = logic.skyteam.MilesCalculator(-1, -4, tier_level_factor, airline_tariff_group)
        result = c.calculate()

        attrs = result.attrs()
        self.assertIn(('distance', '500'), attrs)
        self.assertIn(('chargedMiles', '875'), attrs)
        self.assertIn(('qualifyingMiles', '500'), attrs)
        self.assertIn(('bonusMiles', '375'), attrs)
        self.assertIn(('promoMiles', '0'), attrs)


class TestAwardsCalculator(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def registerVocabularies(self):
        super(TestAwardsCalculator, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.RedemptionZonesVocabulary)
        setup_vocabulary(models.award.WrongRoutesVocabulary)
        setup_vocabulary(models.award.BonusRoutesVocabulary)
        setup_vocabulary(models.award.AwardsVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.WrongRoutesByCtxIndexer), 'wrong_routes_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.BonusRoutesByCtxIndexer), 'bonus_routes_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.AwardsByBonusRouteIndexer), 'awards_by_bonus_route_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer),'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer),'service_classes_limits_by_airline_service_class_idx')

    def test_calculate_error(self):
        a1 = models.geo.Airport.load(airport_id=-3)
        a2 = models.geo.Airport.load(airport_id=-1)
        a3 = models.geo.Airport.load(airport_id=-4)
        airline = models.air.Airline.load(airline_id=-1)

        self.assertRaises(AssertionError, logic.skyteam.AwardsCalculator, a1, a2, a3, 'X')
        self.assertRaises(AssertionError, logic.skyteam.AwardsCalculator, a1, a2, 'X', airline)
        self.assertRaises(AssertionError, logic.skyteam.AwardsCalculator, a1, 'X', a3, airline)
        self.assertRaises(AssertionError, logic.skyteam.AwardsCalculator, 'X', a2, a3, airline)

    def test_calculate_via(self):
        a1 = models.geo.Airport.load(airport_id=-3)
        a2 = models.geo.Airport.load(airport_id=-1)
        a3 = models.geo.Airport.load(airport_id=-4)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, a2, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn(('from', u'XXA'), attrs)
        self.assertIn(('via', u'XXX'), attrs)
        self.assertIn(('to', u'XXB'), attrs)
        self.assertIn(('name', u'XZXXXV'), attrs)
        self.assertIn((u'yyyOWMiles', '1'), attrs)

    def test_calculate_wrong_route(self):
        a1 = models.geo.Airport.load(airport_id=-1)
        a2 = models.geo.Airport.load(airport_id=-4)
        a3 = models.geo.Airport.load(airport_id=-7)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, a2, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn(('from', u'XXX'), attrs)
        self.assertIn(('to', u'XXB'), attrs)
        self.assertIn(('name', u'XXXV'), attrs)

        attrs = result[1].attrs()
        self.assertIn(('from', u'XXB'), attrs)
        self.assertIn(('to', u'XXE'), attrs)
        self.assertIn(('name', u'XZXV'), attrs)

    def test_calculate_direct(self):
        a1 = models.geo.Airport.load(airport_id=-2)
        a3 = models.geo.Airport.load(airport_id=-5)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, None, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn(('from', u'XXZ'), attrs)
        self.assertIn(('to', u'XXC'), attrs)
        self.assertIn(('name', u'XXXZ'), attrs)
        self.assertIn((u'yyyOWMiles', '1000'), attrs)
        self.assertIn((u'yyyRTMiles', '2000'), attrs)
        self.assertIn((u'yyxOWMiles', '3000'), attrs)
        self.assertIn((u'yyxRTMiles', '4000'), attrs)
        self.assertIn((u'upgradeYyy2YyxRT', '5000'), attrs)
        self.assertIn((u'upgradeYyy2YyxOnCheckin', '6000'), attrs)

    def test_calculate_allowed_by_service_class_direct(self):
        # XXX-XXB содержится в ограничениях для класса обслуживания
        a1 = models.geo.Airport.load(airport_id=-1)
        a3 = models.geo.Airport.load(airport_id=-4)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, None, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn(('from', u'XXX'), attrs)
        self.assertIn(('to', u'XXB'), attrs)
        self.assertIn(('name', u'XXXV'), attrs)
        self.assertIn((u'yyyOWMiles', '100'), attrs)
        self.assertIn((u'yyyRTMiles', '200'), attrs)
        self.assertIn((u'businessOWMiles', '300'), attrs)
        self.assertIn((u'businessRTMiles', '400'), attrs)
        self.assertIn((u'upgradeYyy2BusinessRT', '500'), attrs)
        self.assertIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)
        self.assertIn((u'upgradeYyy2BusinessOW', '700'), attrs)
        self.assertIn((u'upgradeYyy2YyxRT', '800'), attrs)

        # XXZ-XXB не содержится в ограничениях для класса обслуживания,
        # поэтому премии для класса обслуживания SkyTeam "business" не отображаются
        a1 = models.geo.Airport.load(airport_id=-2)
        a3 = models.geo.Airport.load(airport_id=-4)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, None, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn(('from', u'XXZ'), attrs)
        self.assertIn(('to', u'XXB'), attrs)
        self.assertIn(('name', u'XXXV'), attrs)
        self.assertIn((u'yyyOWMiles', '100'), attrs)
        self.assertIn((u'yyyRTMiles', '200'), attrs)
        self.assertNotIn((u'businessOWMiles', '300'), attrs)
        self.assertNotIn((u'businessRTMiles', '400'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessRT', '500'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessOW', '700'), attrs)
        self.assertIn((u'upgradeYyy2YyxRT', '800'), attrs)

    def test_calculate_allowed_by_service_class_wrong_route(self):
        ob = models.award.WrongRoute(
            wrong_route_id=-100,
            city_from_id=-2,
            city_via_id=-3,
            city_to_id=-2
        )
        ob.save()
        getV('wrong_routes').update_many([ob])

        a1 = models.geo.Airport.load(airport_id=-1)
        a2 = models.geo.Airport.load(airport_id=-4)
        a3 = models.geo.Airport.load(airport_id=-2)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, a2, a3, airline)
        result = c.calculate()

        # Сегмент XXX-XXB содержится в ограничениях для класса обслуживания
        attrs = result[0].attrs()
        self.assertIn(('from', u'XXX'), attrs)
        self.assertIn(('to', u'XXB'), attrs)
        self.assertIn(('name', u'XXXV'), attrs)
        self.assertIn((u'yyyOWMiles', '100'), attrs)
        self.assertIn((u'yyyRTMiles', '200'), attrs)
        self.assertIn((u'businessOWMiles', '300'), attrs)
        self.assertIn((u'businessRTMiles', '400'), attrs)
        self.assertIn((u'upgradeYyy2BusinessRT', '500'), attrs)
        self.assertIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)
        self.assertIn((u'upgradeYyy2BusinessOW', '700'), attrs)
        self.assertIn((u'upgradeYyy2YyxRT', '800'), attrs)

        # Сегмент XXB-XXZ не содержится в ограничениях для класса обслуживания,
        # поэтому премии для класса обслуживания SkyTeam "business" на данном сегменте не отображаются
        attrs = result[1].attrs()
        self.assertIn(('from', u'XXB'), attrs)
        self.assertIn(('to', u'XXZ'), attrs)
        self.assertIn(('name', u'XXXV'), attrs)
        self.assertIn((u'yyyOWMiles', '100'), attrs)
        self.assertIn((u'yyyRTMiles', '200'), attrs)
        self.assertNotIn((u'businessOWMiles', '300'), attrs)
        self.assertNotIn((u'businessRTMiles', '400'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessRT', '500'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessOW', '700'), attrs)
        self.assertIn((u'upgradeYyy2YyxRT', '800'), attrs)

    def test_calculate_allowed_by_service_class_via(self):
        # Сегмент XXX-XXB содержится в ограничениях для класса обслуживания,
        # сегмент XXZ-XXB не содержится в ограничениях для класса обслуживания.
        # Премия для класса обслуживания SkyTeam "business" отображается,
        # так как она доступна на одном из сегментов
        a1 = models.geo.Airport.load(airport_id=-1)
        a2 = models.geo.Airport.load(airport_id=-4)
        a3 = models.geo.Airport.load(airport_id=-2)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, a2, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn(('from', u'XXX'), attrs)
        self.assertIn(('via', u'XXB'), attrs)
        self.assertIn(('to', u'XXZ'), attrs)
        self.assertIn(('name', u'XXXVXX'), attrs)
        self.assertIn((u'yyyOWMiles', '100'), attrs)
        self.assertIn((u'yyyRTMiles', '200'), attrs)
        self.assertIn((u'businessOWMiles', '300'), attrs)
        self.assertIn((u'businessRTMiles', '400'), attrs)
        self.assertIn((u'upgradeYyy2BusinessRT', '500'), attrs)
        self.assertNotIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)  # OnCheckin запрещён на маршрутах с пересадкой
        self.assertIn((u'upgradeYyy2BusinessOW', '700'), attrs)
        self.assertIn((u'upgradeYyy2YyxRT', '800'), attrs)


    def test_calculate_checkin_allowed_direct(self):
        # XXX-XXB: для XXX доступна премия за повышение класса обслуживания на стойке регистрации
        a1 = models.geo.Airport.load(airport_id=-1)
        a3 = models.geo.Airport.load(airport_id=-4)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, None, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)

        # XXA-XXB: для XXA недоступна премия за повышение класса обслуживания на стойке регистрации
        a1 = models.geo.Airport.load(airport_id=-3)
        a3 = models.geo.Airport.load(airport_id=-4)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, None, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn((u'upgradeYyy2YyxRT', '100'), attrs)
        self.assertNotIn((u'upgradeYyy2YyxOnCheckin', '200'), attrs)

    def test_calculate_checkin_allowed_wrong_route(self):
        # XXX-XXC-XXA: для запрещенного маршрута премии за повышение класса
        # обслуживания предоставляются отдельно для каждого сегмента
        a1 = models.geo.Airport.load(airport_id=-1)
        a2 = models.geo.Airport.load(airport_id=-4)
        a3 = models.geo.Airport.load(airport_id=-7)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, a2, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)

        attrs = result[1].attrs()
        self.assertNotIn((u'upgradeYyy2YyxOnCheckin', '200'), attrs)

    def test_calculate_checkin_allowed_via(self):
        # XXX-XXB-XXZ: для XXX доступна премия за повышение класса обслуживания на стойке регистрации,
        # так как есть пересадка (стыковка) - пермия не отображается
        a1 = models.geo.Airport.load(airport_id=-1)
        a2 = models.geo.Airport.load(airport_id=-4)
        a3 = models.geo.Airport.load(airport_id=-2)
        airline = models.air.Airline.load(airline_id=-1)

        c = logic.skyteam.AwardsCalculator(a1, a2, a3, airline)
        result = c.calculate()

        attrs = result[0].attrs()
        self.assertNotIn((u'upgradeYyy2BusinessOnCheckin', '600'), attrs)


if __name__ == '__main__':
    testoob.main()
