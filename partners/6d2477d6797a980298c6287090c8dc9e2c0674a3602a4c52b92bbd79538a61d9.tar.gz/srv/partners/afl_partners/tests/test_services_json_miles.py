# -*- coding: utf-8 -*-

"""
$Id: test_services_json_miles.py 21623 2016-11-21 12:53:01Z oeremeeva $
"""
import cherrypy
import json
import mock
import testoob

from StringIO import StringIO

from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
import pyramid.vocabulary

from logic.skyteam import MilesCalculatorResult
import models.air
import models.geo
import models.bonus
import models.route
from services.base.json_base import ParamsValidationError
from services.json_services.miles import MilesMultipleJSONService

import _test_data
from _test_data import setup_vocabulary


class MilesCalculatorMock(object):
    def calculate(self):
        return MilesCalculatorResult(**{key: 100500.0 for key in ('distance', 'charged_miles', 'qualifying_miles',
                                                                  'bonus_miles', 'distance_miles')})


class TestMilesMultipleJSONService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestMilesMultipleJSONService, self).setUp()
        self.s = MilesMultipleJSONService()

    def registerVocabularies(self):
        super(TestMilesMultipleJSONService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.bonus.TierLevelsVocabulary)
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer),
            'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer),
            'tier_level_factors_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer),
            'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer),
            'airline_tariff_groups_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer),
            'service_classes_limits_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.BookingClassesByAirlineTariffGroupIndexer),
            'booking_classes_by_airline_tariff_group_idx')

    def test_service_invalid_params(self):
        params = '{"segments": [{"airline": "SU", "airport_from": "XXZ", "airport_towards": "XXB", "tier_level": "silver", "booking_class": "D"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        try:
            self.s.miles_v002(json_string=json.loads(params))
        except ParamsValidationError, e:
            self.assertEqual(e.error_descs[0].message, "Unknown parameters: [u'airport_towards']")
        else:
            self.assertTrue(False, "Exception not raised")

    def test_service_v3_invalid_params(self):
        params = '{"segments": [{"airline": "SU", "airport_from": "XXZ", "airport_towards": "XXB", "tier_level": "silver", "fare_basis_code": "KN"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        try:
            self.s.miles_v003(json_string=json.loads(params))
        except ParamsValidationError, e:
            self.assertEqual(e.error_descs[0].message, "Unknown parameters: [u'airport_towards']")
        else:
            self.assertTrue(False, "Exception not raised")

    def test_service_no_charging(self):
        params = '{"segments": [{"airline": "RO", "airport_from": "XXX", "airport_to": "XXA", "tier_level": "silver", "booking_class": "B"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.assertEqual(json.loads(self.s.miles_v002(json_string=json.loads(params))),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [],
                 u'total': {
                     u'distance': 0,
                     u'base_miles': 0,
                     u'bonus_miles': 0,
                     u'charged_miles': 0,
                     u'promo_miles': 0}
                 }
             })

    def test_service_v3_no_charging(self):
        params = '{"segments": [{"airline": "SU", "airport_from": "XXX", "airport_to": "XXA", "tier_level": "silver", "fare_basis_code": "KF"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.assertEqual(json.loads(self.s.miles_v003(json_string=json.loads(params))),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [],
                 u'total': {
                     u'distance': 0,
                     u'base_miles': 0,
                     u'bonus_miles': 0,
                     u'charged_miles': 0,
                     u'promo_miles': 0}
                 }
             })

    def test_service_unknown_booking_class(self):
        params = '{"segments": [{"airline": "SU", "airport_from": "XXZ", "airport_to": "XXB", "tier_level": "silver", "booking_class": "Alien"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.assertEqual(json.loads(self.s.miles_v002(json_string=json.loads(params))),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [],
                 u'total': {
                     u'distance': 0,
                     u'base_miles': 0,
                     u'bonus_miles': 0,
                     u'charged_miles': 0,
                     u'promo_miles': 0}
                 }
             })

    def test_service_v3_wrong_fare_basis_code(self):
        params = '{"segments": [{"airline": "SU", "airport_from": "XXZ", "airport_to": "XXB", "tier_level": "silver", "fare_basis_code": "A"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.assertEqual(json.loads(self.s.miles_v003(json_string=json.loads(params))),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [],
                 u'total': {
                     u'distance': 0,
                     u'base_miles': 0,
                     u'bonus_miles': 0,
                     u'charged_miles': 0,
                     u'promo_miles': 0}
                 }
             })

    def test_service_absent_params(self):
        params = '{"segments": [{"airline": "SU", "airport_to": "XXB", "tier_level": "silver", "booking_class": "D"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        try:
            self.s.miles_v002()
        except ParamsValidationError, e:
            self.assertEqual(e.error_descs[0].message, "Parameter ['airport_from'] absent for segment #0")
        else:
            self.assertTrue(False, "Exception not raised")

        params = '{"segments": [{"airline": "SU", "airport_to": "XXB", "tier_level": "silver", "fare_basis_code": "KN"}]}'
        cherrypy.request.body = StringIO(params)
        try:
            self.s.miles_v003()
        except ParamsValidationError, e:
            self.assertEqual(e.error_descs[0].message, u"Parameter ['airport_from'] absent for segment #0")
        else:
            self.assertTrue(False, "Exception not raised")

    @mock.patch('services.xml_services.miles.available_routes')
    @mock.patch('services.xml_services.miles.MilesCalculator')
    def test_no_segment(self, miles_calculator_mock, available_routes_mock):
        available_routes_mock.return_value = []
        miles_calculator_mock.return_value = MilesCalculatorMock()

        params = '{"segments": [{"airline": "SU", "airport_from": "XXX", "airport_to": "XXZ", "tier_level": "silver", "booking_class": "A"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.maxDiff=None
        self.assertEqual(json.loads(self.s.miles_v002()),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [],
                 u'total': {
                     u'distance': 0,
                     u'base_miles': 0,
                     u'bonus_miles': 0,
                     u'charged_miles': 0,
                     u'promo_miles': 0}
                 }
             })

    @mock.patch('services.xml_services.miles.MilesCalculator')
    def test_service(self, miles_calculator_mock):

        miles_calculator_mock.return_value = MilesCalculatorMock()

        params = '{"segments": [{"airline": "ST", "airport_from": "XXX", "airport_to": "XXB", "tier_level": "silver", "booking_class": "A"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.maxDiff=None
        self.assertEqual(json.loads(self.s.miles_v002()),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [{
                     u'distance': 100500,
                     u'bonus_miles': 100500,
                     u'base_miles': 100500,
                     u'airport_from': u'XXX',
                     u'booking_class': u'A',
                     u'airline': u'ST',
                     u'charged_miles': 100500,
                     u'tier_level': u'silver',
                     u'airport_to': u'XXB',
                     u'promo_miles': 100500}],
                 u'total': {
                     u'distance': 100500,
                     u'base_miles': 100500,
                     u'bonus_miles': 100500,
                     u'charged_miles': 100500,
                     u'promo_miles': 100500}
                 }
             })

        params = '{"segments": [{"airline": "ST", "airport_from": "XXX", "airport_to": "XXB", "tier_level": "silver", "booking_class": "A"},' + \
                               '{"airline": "ST", "airport_from": "XXX", "airport_to": "XXA", "tier_level": "silver", "booking_class": "A"}]}'
        # Добавляем вторую разрешённую пару.
        scl = models.bonus.ServiceClassesLimit(service_classes_limit_id=-2, airline_sc_id=-8, pair_id=-12)
        pyramid.vocabulary.getV('service_classes_limits').update_many([scl])
        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)

        self.assertEqual(json.loads(self.s.miles_v002()),
            {u'isSuccess': True,
             u'errors': [],
             u'data': {
                 u'segments': [
                     {u'distance': 100500,
                     u'bonus_miles': 100500,
                     u'base_miles': 100500,
                     u'airport_from': u'XXX',
                     u'booking_class': u'A',
                     u'airline': u'ST',
                     u'charged_miles': 100500,
                     u'tier_level': u'silver',
                     u'airport_to': u'XXB',
                     u'promo_miles': 100500},
                     {u'distance': 100500,
                     u'bonus_miles': 100500,
                     u'base_miles': 100500,
                     u'airport_from': u'XXX',
                     u'booking_class': u'A',
                     u'airline': u'ST',
                     u'charged_miles': 100500,
                     u'tier_level': u'silver',
                     u'airport_to': u'XXA',
                     u'promo_miles': 100500}],
                 u'total': {
                     u'distance': 201000,
                     u'base_miles': 201000,
                     u'bonus_miles': 201000,
                     u'charged_miles': 201000,
                     u'promo_miles': 201000}
                 }})

    @mock.patch('services.xml_services.miles.MilesCalculator')
    def test_service_v3(self, miles_calculator_mock):

        miles_calculator_mock.return_value = MilesCalculatorMock()

        params = '{"segments": [{"airline": "SU", "airport_from": "XXX", "airport_to": "XXB", "tier_level": "silver", "fare_basis_code": "KN"}]}'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.maxDiff=None
        self.assertEqual(json.loads(self.s.miles_v003()),
            {
                u'isSuccess': True,
                u'errors': [],
                u'data': {
                    u'segments': [{
                          u'distance': 100500,
                          u'bonus_miles': 100500,
                          u'airport_from': u'XXX',
                          u'airline': u'SU',
                          u'charged_miles': 100500,
                          u'tier_level': u'silver',
                          u'fare_basis_code': u'KN',
                          u'airport_to': u'XXB',
                          u'base_miles': 100500,
                          u'promo_miles': 100500
                      }],
                    u'total': {
                        u'distance': 100500,
                        u'base_miles': 100500,
                        u'bonus_miles': 100500,
                        u'charged_miles': 100500,
                        u'promo_miles': 100500
                    }
                }
            }
        )

        params = '{"segments": [{"airline": "SU", "airport_from": "XXX", "airport_to": "XXB", "tier_level": "silver", "fare_basis_code": "KN"},' + \
                               '{"airline": "SU", "airport_from": "XXX", "airport_to": "XXA", "tier_level": "silver", "fare_basis_code": "KN"}]}'
        # Добавляем вторую разрешённую пару.
        scl = models.bonus.ServiceClassesLimit(service_classes_limit_id=-2, airline_sc_id=-3, pair_id=-1)
        pyramid.vocabulary.getV('service_classes_limits').update_many([scl])
        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(params)
        self.assertEqual(json.loads(self.s.miles_v003()),
            {
                u'isSuccess': True,
                u'errors': [],
                u'data': {
                    u'segments': [
                        {
                            u'distance': 100500,
                            u'bonus_miles': 100500,
                            u'airport_from': u'XXX',
                            u'fare_basis_code': u'KN',
                            u'airline': u'SU',
                            u'charged_miles': 100500,
                            u'tier_level': u'silver',
                            u'airport_to': u'XXB',
                            u'base_miles': 100500,
                            u'promo_miles': 100500,
                        },
                        {
                            u'distance': 100500,
                            u'bonus_miles': 100500,
                            u'airport_from': u'XXX',
                            u'fare_basis_code': u'KN',
                            u'airline': u'SU',
                            u'charged_miles': 100500,
                            u'tier_level': u'silver',
                            u'airport_to': u'XXA',
                            u'base_miles': 100500,
                            u'promo_miles': 100500
                        }
                    ],
                    u'total': {
                        u'distance': 201000,
                        u'base_miles': 201000,
                        u'bonus_miles': 201000,
                        u'charged_miles': 201000,
                        u'promo_miles': 201000
                    }
                }
            }
        )

if __name__ == "__main__":
    testoob.main()
