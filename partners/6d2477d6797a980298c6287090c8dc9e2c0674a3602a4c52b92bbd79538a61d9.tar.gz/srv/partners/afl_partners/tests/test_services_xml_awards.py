# -*- coding: utf-8 -*-

"""
$Id: $
"""

import mock
import testoob

from lxml import etree

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from zope.component import globalSiteManager as gsm
from rx.i18n.translation import SelfTranslationDomain
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary
import models.air
import models.award
import models.geo
import models.route

from services.base.xml_base import ParamsValidationError
from services.xml_services.awards import (AwardsXMLService, AFLAwardsXMLService,
                                          SkyteamAwardsXMLService,
                                          RedemptionZoneXMLService)


class TestAwardsXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAwardsXMLService, self).setUp()
        self.s = AwardsXMLService()

    def registerVocabularies(self):
        super(TestAwardsXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.award.AwardsVocabulary)
        setup_vocabulary(models.award.BonusRoutesVocabulary)
        setup_vocabulary(models.award.RedemptionZonesVocabulary)
        setup_vocabulary(models.award.WrongRoutesVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.BonusRoutesByCtxIndexer), 'bonus_routes_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.AwardsByBonusRouteIndexer), 'awards_by_bonus_route_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.WrongRoutesByCtxIndexer), 'wrong_routes_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer),'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer),'service_classes_limits_by_airline_service_class_idx')

    def test_awards_v001_invalid_parameters(self):
        self.assertRaises(ParamsValidationError, self.s.awards_v001, 'XX', 'XXX', 'XXA')
        self.assertRaises(ParamsValidationError, self.s.awards_v001, 'SU', 'XXX', 'SSS')
        self.assertRaises(ParamsValidationError, self.s.awards_v001, 'SU', 'XXX', 'XXA', param_via='SSS')

    @mock.patch('logic.geo.LOG')
    def test_awards_v001_direct(self, mock_log):
        # Город, с которым не связан ни один аэропорт
        data = self.s.awards_v001('SU', 'UUY', 'UUW')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertFalse(xml.xpath('/routes/route'))

        # Город - город, несколько маршрутов
        data = self.s.awards_v001('SU', 'UUY', 'UUU')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via=""][@to="XXC"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via=""][@to="XXD"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXD"]'))

        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"][@yyyOWMiles="1000"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"][@yyyRTMiles="2000"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"][@yyxOWMiles="3000"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"][@yyxRTMiles="4000"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"][@upgradeYyy2YyxRT="5000"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"][@upgradeYyy2YyxOnCheckin="6000"]'))

        # Город - аэропорт
        data = self.s.awards_v001('SU', 'UUY', 'XXC')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via=""][@to="XXC"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXC"]'))

        # Аэропорт - аэропорт
        data = self.s.awards_v001('SU', 'XXZ', 'XXD')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via=""][@to="XXD"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXZ"][@to="XXD"]'))

    @mock.patch('services.xml_services.awards.available_pairs')
    @mock.patch('logic.geo.LOG')
    def test_awards_v001_via(self, mock_log, mock_available_pairs):
        mock_available_pairs.return_value = [(-2, -5), (-3, -4), (-2, -6), (-1, -4), (-1, -3), (-2, -4), (-7, -4)]

        # Город - город - город, несколько маршрутов
        data = self.s.awards_v001('SU', 'UUU', 'UUZ', param_via='UUY')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXC"][@via="XXZ"][@to="XXB"][@name="XZXXXV"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXD"][@via="XXZ"][@to="XXB"][@name="XZXXXV"]'))

        # Город - аэропорт - аэропорт
        data = self.s.awards_v001('SU', 'UUZ', 'XXC', param_via='XXZ')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route/cost')), 1)
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXB"][@via="XXZ"][@to="XXC"][@name="XZXXXV"]'))

        # Проверка правильного расчёта зон с пересадкой
        data = self.s.awards_v001('SU', 'XXA', 'XXB', param_via='XXX')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route/cost')), 1)
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXA"][@via="XXX"][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@yyyOWMiles="1"]'))

        # Проверка правильного расчёта составных маршрутов
        data = self.s.awards_v001('SU', 'XXX', 'XXE', param_via='XXB')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertEqual(len(xml.xpath('/routes/route/cost')), 2)

    @mock.patch('logic.geo.LOG')
    def test_awards_v001_skyteam(self, mock_log):
        data = self.s.awards_v001('RO', 'XXA', 'XXX')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route/cost')), 1)
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXA"][@to="XXX"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@yyyOWMiles="2"]'))

        data = self.s.awards_v001('RO', 'XXA', 'XXB', param_via='XXX')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route/cost')), 1)
        self.assertTrue(xml.xpath('/routes/route/cost[@from="XXA"][@via="XXX"][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route/cost[@yyyOWMiles="3"]'))


class TestAFLAwardsXMLService(TestAwardsXMLService):
    def setUp(self):
        super(TestAFLAwardsXMLService, self).setUp()
        self.s = AFLAwardsXMLService()


class TestSkyteamAwardsXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestSkyteamAwardsXMLService, self).setUp()
        self.s = SkyteamAwardsXMLService()

    def registerVocabularies(self):
        super(TestSkyteamAwardsXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.award.AwardsVocabulary)
        setup_vocabulary(models.award.BonusRoutesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.BonusRoutesByCtxIndexer), 'bonus_routes_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.AwardsByBonusRouteIndexer), 'awards_by_bonus_route_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.AllPairsByCtxIndexer), 'all_pairs_by_ctx_idx')

    def test_awards_v001_invalid_parameters(self):
        self.assertRaises(ParamsValidationError, self.s.awards_v001, 'SSS', 'XXX')
        self.assertRaises(ParamsValidationError, self.s.awards_v001, 'XXX', 'SSS')

    @mock.patch('logic.geo.LOG')
    def test_awards_v001(self, mock_log):
        # Город - город
        data = self.s.awards_v001('UUX', 'UUY')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertEqual(len(xml.xpath('/routes/route')), 4)
        self.assertTrue(xml.xpath('/routes/route[@from="XXE"][@via=""][@to="XXX"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXE"][@via=""][@to="XXZ"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXA"][@via=""][@to="XXX"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXA"][@via=""][@to="XXZ"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXE"][@via=""][@to="XXX"]/cost[@name="SXSZ"][@yyyOWMiles="2"]'))

        # Город - аэропорт
        data = self.s.awards_v001('UUY', 'XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via=""][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via=""][@to="XXB"]/cost[@name="XVSX"][@yyyOWMiles="4"]'))

        # Город - аэропорт
        data = self.s.awards_v001('XXX', 'XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXB"]/cost[@name="XVSX"][@yyyOWMiles="4"]'))

    def test_airlines_v001_invalid_parameters(self):
        self.assertRaises(ParamsValidationError, self.s.airlines_v001, 'SSS', 'XXX')
        self.assertRaises(ParamsValidationError, self.s.airlines_v001, 'XXX', 'SSS')

    @mock.patch('logic.geo.LOG')
    def test_airlines_v001(self, mock_log):
        # Город - город
        data = self.s.airlines_v001('UUX', 'UUY')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airlines'))
        self.assertEqual(len(xml.xpath('/airlines/airline')), 3)
        self.assertTrue(xml.xpath('/airlines/airline[@code="SU"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="ST"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="RO"]'))

        # Город - аэропорт
        data = self.s.airlines_v001('FFF', 'FFA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airlines'))
        self.assertEqual(len(xml.xpath('/airlines/airline')), 1)
        self.assertTrue(xml.xpath('/airlines/airline[@code="RO"]'))

        # Aэропорт - аэропорт
        data = self.s.airlines_v001('XXB', 'XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airlines'))
        self.assertEqual(len(xml.xpath('/airlines/airline')), 3)
        self.assertTrue(xml.xpath('/airlines/airline[@code="SU"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="ST"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="RO"]'))

        # Aэропорт - аэропорт, на двух сегментах разные авиакомпании
        data = self.s.airlines_v001('XXX', 'XXE')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airlines'))
        self.assertEqual(len(xml.xpath('/airlines/airline')), 3)
        self.assertTrue(xml.xpath('/airlines/airline[@code="SU"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="ST"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="RO"]'))

        # Aэропорт - аэропорт, флаг NO SPENDING
        data = self.s.airlines_v001('XXD', 'FFA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airlines'))
        self.assertFalse(xml.xpath('/airlines/airline'))

        # Aэропорт - аэропорт, оба в одном городе
        data = self.s.airlines_v001('XXX', 'XXZ')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airlines'))
        self.assertFalse(xml.xpath('/airlines/airline'))


class TestRedemptionZoneXMLService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestRedemptionZoneXMLService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        self.s = RedemptionZoneXMLService()

    def registerVocabularies(self):
        super(TestRedemptionZoneXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.RedemptionZonesVocabulary)

    def test_zones_v001(self):

        data = self.s.zones_v001()
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/redemptionZones'))
        self.assertEqual(len(xml.xpath('/redemptionZones/redemptionZone')), 4)

        self.assertTrue(xml.xpath('/redemptionZones/redemptionZone[@code="XV"]'))
        self.assertEqual(xml.xpath('/redemptionZones/redemptionZone[@code="XV"]/name[@xml:lang="en"]/text()')[0], 'YYY')
        self.assertEqual(xml.xpath('/redemptionZones/redemptionZone[@code="XV"]/name[@xml:lang="ru"]/text()')[0], 'XXX')


if __name__ == "__main__":
    testoob.main()
