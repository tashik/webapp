# -*- coding: utf-8 -*-

"""
$Id: $
"""

import mock
import testoob

from lxml import etree

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary
from logic.route import TYPE_EARN, TYPE_SPEND
import models.air
import models.bonus
import models.geo
import models.route
from services.base.xml_base import ParamsValidationError
from services.xml_services.route import(RouteXMLService, AFLRouteXMLService,
                                        PairsByAirlineServiceClassXMLService,
                                        AFLPairsByAirlineServiceClassXMLService)


class TestRouteXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestRouteXMLService, self).setUp()
        self.s = RouteXMLService()

    def registerVocabularies(self):
        super(TestRouteXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')

    @mock.patch('logic.geo.LOG')
    def test_pairs_v001(self, mock_log):
        # Все авиакомпании, все типы поиска
        data = self.s.pairs_v001()
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="VVV"][@airport2="WWW"]'))

        # SU, все типы поиска
        data = self.s.pairs_v001(param_airline='SU')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

        # Все авиакомпании, earn
        data = self.s.pairs_v001(param_type=TYPE_EARN)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

        # Все авиакомпании, spend
        data = self.s.pairs_v001(param_type=TYPE_SPEND)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

        # SU, earn
        data = self.s.pairs_v001(param_airline='SU', param_type=TYPE_EARN)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

        # SU, spend
        data = self.s.pairs_v001(param_airline='SU', param_type=TYPE_SPEND)
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

        # RO, earn
        data = self.s.pairs_v001(param_airline='RO', param_type=TYPE_EARN)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

        # RO, spend
        data = self.s.pairs_v001(param_airline='RO', param_type=TYPE_SPEND)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXA"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertTrue(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="FFB"]'))
        self.assertFalse(xml.xpath('/pairs/pair[@airport1="FFA"][@airport2="XXD"]'))

    def test_pairs_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.pairs_v001, 'XX')

    def test_pairs_v001_invalid_type(self):
        self.assertRaises(ParamsValidationError, self.s.pairs_v001, None, 'xxxx')

    @mock.patch('logic.geo.LOG')
    def test_airports_from_v001(self, mock_log):
        # Все авиакомпании, все типы поиска
        data = self.s.airports_from_v001()
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # SU, все типы поиска
        data = self.s.airports_from_v001(param_airline='SU')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # Все авиакомпании, earn
        data = self.s.airports_from_v001(param_type=TYPE_EARN)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # Все авиакомпании, spend
        data = self.s.airports_from_v001(param_type=TYPE_SPEND)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # SU, earn
        data = self.s.airports_from_v001(param_airline='SU', param_type=TYPE_EARN)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # SU, spend
        data = self.s.airports_from_v001(param_airline='SU', param_type=TYPE_SPEND)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # RO, earn
        data = self.s.airports_from_v001(param_airline='RO', param_type=TYPE_EARN)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # RO, spend
        data = self.s.airports_from_v001(param_airline='RO', param_type=TYPE_SPEND)
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

    def test_airports_from_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.airports_from_v001, 'XX')

    def test_airports_from_v001_invalid_type(self):
        self.assertRaises(ParamsValidationError, self.s.airports_from_v001, None, 'xxxx')

    @mock.patch('logic.geo.LOG')
    def test_airports_to_v001_all(self, mock_log):
        # Все авиакомпании, все типы поиска
        data = self.s.airports_to_v001(param_from='FFA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # SU, все типы поиска
        data = self.s.airports_to_v001(param_airline='SU', param_from='XXX')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))
        # Проверяем, что в аэропорт того же города не летим
        self.assertFalse(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))

        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]/via'))

        self.assertFalse(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXE"]/via'))

        data = self.s.airports_to_v001(param_airline='SU', param_from='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))

        data = self.s.airports_to_v001(param_airline='SU', param_from='FFA')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/city[@code="FFF"]/airport[@code="FFB"]'))

        # Все авиакомпании, earn
        data = self.s.airports_to_v001(param_type=TYPE_EARN, param_from='FFA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))

        # Все авиакомпании, spend
        data = self.s.airports_to_v001(param_type=TYPE_SPEND, param_from='FFA')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXD"]'))

        # SU, earn
        data = self.s.airports_to_v001(param_airline='SU', param_type=TYPE_EARN, param_from='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # SU, spend
        data = self.s.airports_to_v001(param_airline='SU', param_type=TYPE_SPEND, param_from='XXA')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # RO, earn
        data = self.s.airports_to_v001(param_airline='RO', param_type=TYPE_EARN, param_from='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # RO, spend
        data = self.s.airports_to_v001(param_airline='RO', param_type=TYPE_SPEND, param_from='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

    @mock.patch('logic.geo.LOG')
    def test_airports_to_v001_by_city(self, mock_log):
        data = self.s.airports_to_v001(param_airline='SU', param_from='UUY')
        xml = etree.fromstring(data) 
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))

        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/direct'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/via'))

        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUX"]/airport[@code="XXA"]/via'))

    @mock.patch('logic.geo.LOG')
    def test_airports_to_v001_invalid_airline(self, mock_log):
        self.assertRaises(ParamsValidationError, self.s.airports_to_v001, 'XX', None, 'XXA')

    def test_airports_to_v001_invalid_type(self):
        self.assertRaises(ParamsValidationError, self.s.airports_to_v001, None, 'xxxx')

    @mock.patch('logic.geo.LOG')
    def test_airports_to_v001_invalid_location(self, mock_log):
        self.assertRaises(ParamsValidationError, self.s.airports_to_v001, 'SU', None, 'XXL')

    @mock.patch('logic.geo.LOG')
    def test_airports_via_v001(self, mock_log):
        # Все авиакомпании, все типы поиска
        data = self.s.airports_via_v001(param_from='FFA', param_to='FFB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="FFA"][@to="FFB"]'))
        self.assertTrue(xml.xpath('/airports/direct'))

        # SU, все типы поиска
        data = self.s.airports_via_v001(param_airline='SU', param_from='XXX', param_to='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="XXX"][@to="XXA"]'))
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))

        data = self.s.airports_via_v001(param_airline='SU', param_from='XXZ', param_to='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="XXZ"][@to="XXA"]'))
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))

        data = self.s.airports_via_v001(param_airline='SU', param_from='XXZ', param_to='XXC')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="XXZ"][@to="XXC"]'))
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertFalse(xml.xpath('/airports/city'))

        # Вылет и прилёт - один и тот же город
        data = self.s.airports_via_v001(param_airline='SU', param_from='XXX', param_to='XXZ')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertFalse(xml.xpath('/airports/city'))

        # Вылет и прилёт - один и тот же аэропорт
        data = self.s.airports_via_v001(param_airline='SU', param_from='XXX', param_to='XXX')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertFalse(xml.xpath('/airports/city'))

        # Перелёт осуществляет другая авиакомпания
        data = self.s.airports_via_v001(param_airline='SU', param_from='FFA', param_to='FFB')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertFalse(xml.xpath('/airports/city'))

        # Все авиакомпании, earn
        data = self.s.airports_via_v001(param_type=TYPE_EARN, param_from='XXA', param_to='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # Все авиакомпании, spend
        data = self.s.airports_via_v001(param_type=TYPE_SPEND, param_from='XXA', param_to='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # SU, earn
        data = self.s.airports_via_v001(param_airline='SU', param_type=TYPE_EARN, param_from='XXA', param_to='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # SU, spend
        data = self.s.airports_via_v001(param_airline='SU', param_type=TYPE_SPEND, param_from='XXA', param_to='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # RO, earn
        data = self.s.airports_via_v001(param_airline='RO', param_type=TYPE_EARN, param_from='XXA', param_to='XXB')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

        # RO, spend
        data = self.s.airports_via_v001(param_airline='RO', param_type=TYPE_SPEND, param_from='XXA', param_to='XXB')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXX"]'))

    @mock.patch('logic.geo.LOG')
    def test_airports_via_by_city_v001(self, mock_log):
        # Город - город
        data = self.s.airports_via_v001(param_airline='SU', param_from='UUY', param_to='UUX')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="UUY"][@to="UUX"]'))
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))

        # Город - аэропорт
        data = self.s.airports_via_v001(param_airline='SU', param_from='UUY', param_to='XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports[@from="UUY"][@to="XXA"]'))
        self.assertTrue(xml.xpath('/airports/direct'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUZ"]/airport[@code="XXB"]'))

        # Вылет и прилёт - один и тот же город
        data = self.s.airports_via_v001(param_airline='SU', param_from='UUY', param_to='UUY')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/direct'))
        self.assertFalse(xml.xpath('/airports/city'))

    @mock.patch('logic.geo.LOG')
    def test_airports_via_invalid_airline_v001(self, mock_log):
        self.assertRaises(ParamsValidationError, self.s.airports_via_v001, 'XX', None, 'UUY', 'XXA')

    def test_airports_via_v001_invalid_type(self):
        self.assertRaises(ParamsValidationError, self.s.airports_via_v001, None, 'xxxx', 'UUY', 'XXA')

    @mock.patch('logic.geo.LOG')
    def test_airports_via_invalid_location_v001(self, mock_log):
        self.assertRaises(ParamsValidationError, self.s.airports_via_v001, 'SU', None, 'XXL', 'XXX')


class TestAFLRouteXMLService(TestRouteXMLService):
    def setUp(self):
        super(TestAFLRouteXMLService, self).setUp()
        self.s = AFLRouteXMLService()


class TestPairsByAirlineServiceClassXMLService(
    TestCaseWithPgDBAndVocabs
):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestPairsByAirlineServiceClassXMLService, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.air.AirlinesByIATAIndexer
            ), 'airlines_by_iata_idx'
        )
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.AirlineServiceClassesByAirlineIndexer
            ), 'airline_service_classes_by_airline_idx'
        )
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer
            ), 'service_classes_limits_by_airline_service_class_idx'
        )
        self.s = PairsByAirlineServiceClassXMLService()

    def test_pairs_v001(self):
        data = self.s.pairs_v001('SU', 'business')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/class[@code="business"]'))
        self.assertTrue(xml.xpath('/class/pair[@airport1="XXX"][@airport2="XXB"]'))
        self.assertFalse(xml.xpath('/class/pair[@airport1="XXX"][@airport2="XXA"]'))

        data = self.s.pairs_v001('SU', 'yyx')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/class[@code="yyx"]'))
        self.assertTrue(xml.xpath('/class/all'))
        self.assertFalse(xml.xpath('/class/pair'))

    def test_pairs_invalid_service_class_v001(self):
        self.assertRaises(
            ParamsValidationError,
            self.s.pairs_v001,
            'SU',
            'zzz'
        )

    def test_pairs_invalid_airline_v001(self):
        self.assertRaises(
            ParamsValidationError,
            self.s.pairs_v001,
            'OO',
            'yyx'
        )


class TestAFLPairsByAirlineServiceClassXMLService(
    TestPairsByAirlineServiceClassXMLService
):
    def setUp(self):
        super(
            TestAFLPairsByAirlineServiceClassXMLService, self
        ).setUp()
        self.s = AFLPairsByAirlineServiceClassXMLService()


if __name__ == "__main__":
    testoob.main()
