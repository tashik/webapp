# -*- coding: utf-8 -*-

"""
$Id: test_services_xml_errors.py 10702 2015-01-29 12:02:08Z isoloduha $
"""

import cherrypy
import unittest
from lxml import etree
import mock
import os
import testoob

from services.xml_services.errors import ErrorsService

import config


TEST_INDEX_TSV = '''id\tevent_id\tmessage
182501-ValueError\t123\tError AAA
182502-AssertionError\t456\tError>BBB\textra1=CCC\textra2=DD&D
'''


class TestErrorsService(unittest.TestCase):
    def test_index(self):
        dirname = os.path.join(config.ERRORDIR, '1999-12-30')
        if not os.path.exists(dirname):
            os.mkdir(dirname)

        text = ErrorsService().index()
        xml = etree.fromstring(text)

        self.assertTrue(xml.xpath('/days'))
        self.assertTrue(xml.xpath('/days/day[@date="1999-12-30"]'))

    def test_day(self):
        svc = ErrorsService()

        self.assertRaisesRegexp(cherrypy.HTTPError, "not found", svc.day, '9999-12-30')

        dirname = os.path.join(config.ERRORDIR, '1998-12-31a')
        if not os.path.exists(dirname):
            os.mkdir(dirname)

        self.assertRaisesRegexp(cherrypy.HTTPError, "Invalid Date", svc.day, '1998-12-31a')

        dirname = os.path.join(config.ERRORDIR, '1998-12-31')
        if not os.path.exists(dirname):
            os.mkdir(dirname)

        open(config.ERRORDIR + '/1998-12-31/index.tsv', 'w').write(TEST_INDEX_TSV)

        gen = svc.day('1998-12-31')
        text = ''.join(list(gen))
        xml = etree.fromstring(text)
        self.assertTrue(xml.xpath('/errors[@date="1998-12-31"]'))
        self.assertTrue(xml.xpath('/errors/error[@message="Error AAA"]'))
        self.assertTrue(xml.xpath('/errors/error[@message="Error>BBB"]'))

        self.assertTrue(xml.xpath('/errors/error[@extra1="CCC"]'))
        self.assertTrue(xml.xpath('/errors/error[@extra2="DD&amp;D"]'))

    @mock.patch('config.ERROR_DETAILS_ACCESS', new=[])
    def test_details(self):
        svc = ErrorsService()

        try:
            svc.details(None, None)
        except cherrypy.HTTPError, e:
            self.assertEqual(e.status, 403)
        else:
            self.fail('Must raise HTTPError')

        dirname = os.path.join(config.ERRORDIR, '1998-12-31')
        if not os.path.exists(dirname):
            os.mkdir(dirname)

        self.assertRaisesRegexp(cherrypy.HTTPError, "not found", svc._details, '1998-12-31', '000')

        open(config.ERRORDIR + '/1998-12-31/a@@@', 'w')

        self.assertRaisesRegexp(cherrypy.HTTPError, "Invalid Event Id", svc._details, '1998-12-31', 'a@@@')

        open(config.ERRORDIR + '/1998-12-31/235959.xml', 'w').write('<details />')
        text = svc._details('1998-12-31', '235959.xml')
        self.assertEqual(text, '<details />')


if __name__ == "__main__":
    testoob.main()
