# -*- coding: utf-8 -*-

"""
$Id: $
"""

import testoob

from zope.schema.interfaces import ITokenizedTerm

import pyramid.vocabulary.mvcc
from pyramid.i18n.message import Message
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.vocabulary.interfaces import IVocabulary

from rx.i18n.translation import SelfTranslationDomain

import _test_data
from _test_data import setup_vocabulary
import models.air
import models.award
import models.geo


class TestCountry(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestCountry, self).setUp()
        self.model = models.geo.Country

    def test_model(self):
        ob = self.model.load(country='XX')

        self.assertEqual('XXX', ob.iso_code3)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)

        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestCountryI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.geo.Country.load(country='XX')
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestCountryVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestCountryVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)

    def testVocabulary(self):
        v = getV('countries')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue('XX' in v)
        self.assertFalse('XY' in v)
        ob = v['XX']
        self.assertTrue(isinstance(ob, models.geo.Country))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])


class TestCity(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestCity, self).setUp()
        self.model = models.geo.City

    def test_model(self):
        ob = self.model.load(city_id=-1)

        self.assertEqual('XX', ob.country_code)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertEqual('UTC+5', ob.tz)
        self.assertEqual(u'UUX', ob.iata)
        self.assertEqual(99.9, ob.lat)
        self.assertEqual(77.7, ob.lon)

        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestCityI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.geo.City.load(city_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestCityVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestCityVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)

    def testVocabulary(self):
        v = getV('cities')
        self.assertTrue(-1 in v)
        self.assertFalse(-10 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.geo.City))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.country_code, u'XX')


class TestCitiesByIATAIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestCitiesByIATAIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer),
                                  'cities_by_iata_idx')

    def test_add(self):
        vocab = getV('cities')
        idx = getVI('cities_by_iata_idx')

        self.assertEqual(len(idx(context='UUX')), 1)
        self.assertTrue(isinstance(idx(context='UUX')[0], models.geo.City))
        self.assertEqual(idx(context='UUX')[0].iata, u'UUX')

        self.assertEqual(len(idx(context='AAA')), 0)

        ob = models.geo.City(
            city_id=-100,
            country_code=u'XX',
            tz=u'UTC+5',
            iata=u'AAA',
            lat=10.0,
            lon=-10.10,
            names=[u'ru:AAAAAA', u'en:BBBBBB']
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context='AAA')), 0)

        idx._reindex()

        self.assertEqual(len(idx(context='AAA')), 1)
        self.assertTrue(isinstance(idx(context='AAA')[0], models.geo.City))
        self.assertEqual(idx(context='AAA')[0].iata, u'AAA')

    def test_change(self):
        vocab = getV('cities')
        idx = getVI('cities_by_iata_idx')

        self.assertEqual(len(idx(context='UUX')), 1)
        self.assertEqual(len(idx(context='AAA')), 0)

        ob = models.geo.City(
            city_id=-1,
            country_code=u'XX',
            tz=u'UTC+5',
            iata=u'AAA',
            lat=99.9,
            lon=77.7,
            names=[u'ru:XXX', u'en:YYY']
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context='UUX')), 1)
        self.assertEqual(len(idx(context='AAA')), 0)

        idx._reindex()

        self.assertEqual(len(idx(context='UUX')), 0)
        self.assertEqual(len(idx(context='AAA')), 1)
        self.assertEqual(idx(context='AAA')[0].city_id, -1)

    def test_delete(self):
        vocab = getV('cities')
        idx = getVI('cities_by_iata_idx')

        self.assertEqual(len(idx(context='UUX')), 1)

        ob = idx(context='UUX')[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context='UUX')), 1)

        idx._reindex()

        self.assertEqual(len(idx(context='UUX')), 0)


class TestAirport(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirport, self).setUp()
        pyramid.vocabulary.mvcc.register()
        self.model = models.geo.Airport

    def test_model(self):
        ob = self.model.load(airport_id=-1)

        self.assertEqual(-2, ob.city_id)
        self.assertEqual('XXX', ob.iata)
        self.assertEqual('XXXX', ob.icao)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual(99.9, ob.lat)
        self.assertEqual(77.7, ob.lon)
        self.assertEqual('XX', ob.afl_redemption_zone)
        self.assertEqual('SX', ob.skyteam_redemption_zone)
        self.assertEqual(True, ob.has_upgrade_on_checkin_award)

        airline = models.air.Airline.load(airline_id=-1)
        self.assertEqual('XX', ob.redemption_zone_by_airline(airline))

        airline = models.air.Airline.load(airline_id=-2)
        self.assertEqual('SX', ob.redemption_zone_by_airline(airline))

        self.assertEqual('XX', ob.redemption_zone_by_carrier(models.award.CARRIER_AFL))
        self.assertEqual('SX', ob.redemption_zone_by_carrier(models.award.CARRIER_SKYTEAM))


class TestAirportI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.geo.Airport.load(airport_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestAirportsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirportsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.AirportsVocabulary)

    def testVocabulary(self):
        v = getV('airports')
        self.assertTrue(-1 in v)
        self.assertFalse(-100 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.geo.Airport))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(-2, ob.city_id)


class TestAirportsByIATAIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirportsByIATAIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.AirportsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer),
                                  'airports_by_iata_idx')

    def test_add(self):
        vocab = getV('airports')
        idx = getVI('airports_by_iata_idx')

        self.assertEqual(len(idx(context='XXX')), 1)
        self.assertTrue(isinstance(idx(context='XXX')[0], models.geo.Airport))
        self.assertEqual(idx(context='XXX')[0].iata, u'XXX')

        self.assertEqual(len(idx(context='AAA')), 0)

        ob = models.geo.Airport(
            airport_id=-100,
            city_id=-3,
            iata='AAA',
            icao='AAAA',
            names=[u'ru:AAAAAA', u'en:BBBBBB'],
            afl_redemption_zone='A3',
            lat=10.0,
            lon=-10.10,
            has_upgrade_on_checkin_award=True
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context='AAA')), 0)

        idx._reindex()

        self.assertEqual(len(idx(context='AAA')), 1)
        self.assertTrue(isinstance(idx(context='AAA')[0], models.geo.Airport))
        self.assertEqual(idx(context='AAA')[0].iata, u'AAA')


    def test_change(self):
        vocab = getV('airports')
        idx = getVI('airports_by_iata_idx')

        self.assertEqual(len(idx(context='XXX')), 1)
        self.assertEqual(len(idx(context='AAA')), 0)

        ob = models.geo.Airport(
            airport_id=-1,
            city_id=-2,
            iata='AAA',
            icao='XXXX',
            names=[u'ru:XXX', u'en:YYY'],
            afl_redemption_zone='A3',
            lat=99.9,
            lon=77.7,
            has_upgrade_on_checkin_award=True
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context='XXX')), 1)
        self.assertEqual(len(idx(context='AAA')), 0)

        idx._reindex()

        self.assertEqual(len(idx(context='XXX')), 0)
        self.assertEqual(len(idx(context='AAA')), 1)
        self.assertEqual(idx(context='AAA')[0].airport_id, -1)

    def test_delete(self):
        vocab = getV('airports')
        idx = getVI('airports_by_iata_idx')

        self.assertEqual(len(idx(context='XXX')), 1)

        ob = idx(context='XXX')[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context='XXX')), 1)

        idx._reindex()

        self.assertEqual(len(idx(context='XXX')), 0)


class TestAirportsByCityIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirportsByCityIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.AirportsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer),
                                  'airports_by_city_idx')

    def test_add(self):
        vocab = getV('airports')
        idx = getVI('airports_by_city_idx')

        city = models.geo.City.load(city_id=-2)

        self.assertEqual(len(idx(context=city)), 2)
        self.assertTrue(isinstance(idx(context=city)[0], models.geo.Airport))
        self.assertIn(u'XXX', [ob.iata for ob in idx(context=city)])
        self.assertNotIn(u'AAA', [ob.iata for ob in idx(context=city)])

        ob = models.geo.Airport(
            airport_id=-100,
            city_id=-2,
            iata='AAA',
            icao='AAAA',
            names=[u'ru:AAAAAA', u'en:BBBBBB'],
            afl_redemption_zone='A3',
            lat=10.0,
            lon=-10.10,
            has_upgrade_on_checkin_award=True
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=city)), 2)

        idx._reindex()

        self.assertEqual(len(idx(context=city)), 3)
        self.assertIn(u'AAA', [obj.iata for obj in idx(context=city)])

    def test_change(self):
        vocab = getV('airports')
        idx = getVI('airports_by_city_idx')

        city = models.geo.City.load(city_id=-2)

        self.assertEqual(len(idx(context=city)), 2)
        self.assertIn(u'XXX', [ob.iata for ob in idx(context=city)])

        ob = models.geo.Airport(
            airport_id=-1,
            city_id=-2,
            iata='AAA',
            icao='XXXX',
            names=[u'ru:XXX', u'en:YYY'],
            afl_redemption_zone='A3',
            lat=99.9,
            lon=77.7,
            has_upgrade_on_checkin_award=True
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=city)), 2)
        self.assertIn(u'XXX', [ob.iata for ob in idx(context=city)])
        self.assertNotIn(u'AAA', [ob.iata for ob in idx(context=city)])

        idx._reindex()

        self.assertEqual(len(idx(context=city)), 2)
        self.assertIn(u'AAA', [ob.iata for ob in idx(context=city)])
        self.assertNotIn(u'XXX', [ob.iata for ob in idx(context=city)])

    def test_delete(self):
        vocab = getV('airports')
        idx = getVI('airports_by_city_idx')

        city = models.geo.City.load(city_id=-2)

        self.assertEqual(len(idx(context=city)), 2)

        ob = models.geo.Airport.load(airport_id=-1)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=city)), 2)

        idx._reindex()

        self.assertEqual(len(idx(context=city)), 1)


if __name__ == "__main__":
    testoob.main()
