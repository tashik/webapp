# -*- coding: utf-8 -*-

"""
$Id: test_notify.py 21290 2016-10-25 09:55:58Z oeremeeva $
"""


from datetime import date
import testoob
from itertools import groupby

from zope.schema.interfaces import ITokenizedTerm

import pyramid.i18n
import pyramid.vocabulary.mvcc
from pyramid.ormlite.dbop import selectFrom
from pyramid.ormlite.utils import runSQL
from pyramid.registry import unregisterVocabulary, registerVocabularyIndexer
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.tests import testlib
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

from rx.i18n.translation import init_i18n

import models.geo
import models.partner
import models.route
import models.bonus
import models.special_offer
import notify.decode

from _test_data import setup_vocabulary


def t2l(msg, lang):
    return pyramid.i18n.translate(msg, target_language=lang)


class TestDecode(testlib.TestCaseWithI18N, testlib.TestCaseWithPgDBAndVocabs):
    DEFAULT_NEGOTIATOR_LANG = 'en'

    def setUp(self):
        super(TestDecode, self).setUp()
        init_i18n()
        pyramid.vocabulary.mvcc.register()
        models.partner.PartnerOfficeContactsVocabulary.register()
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)

    def test_decode_airline(self):
        d = {
            u'airline_id': 12345678,
            u'iata': u'AAA',
            u'icao': u'BBB',
            u'callsign': u'ABC',
            u'country': u'RU',
            u'airport': -3,
            u'alliance': u'Skyteam',
            u'names': [u'en:ABC', u'ru:ACB'],
            u'parent_airline': None,
            u'url': [u'en:AAASITE'],
            u'weight': 1,
            u'miles_minimum': 100.0,
            u'miles_limitation': 'I',
            u'miles_earn_description': [u'en:DODO', u'ru:HJHJ'],
            u'miles_earn_comment': [u'en:GHGH', u'ru:SDSD']
        }
        term = notify.decode.decode_airline(d)
        self.assertEqual(term.airline_id, 12345678)
        self.assertEqual(term.iata, u'AAA')
        self.assertEqual(term.icao, u'BBB')
        self.assertEqual(term.callsign, u'ABC')
        self.assertEqual(term.country, u'RU')
        self.assertEqual(term.airport_id, -3)
        self.assertEqual(term.alliance, u'Skyteam'),
        self.assertEqual(t2l(term.title, 'ru'), u'ACB')
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(term.parent_airline_id, None),
        self.assertEqual(term.url, [u'en:AAASITE']),
        self.assertEqual(term.weight, 1)
        self.assertEqual(term.miles_minimum, 100.0)
        self.assertEqual(term.miles_limitation, 'I')

    def test_decode_country(self):
        d = {
            u'iso_code2': u'RU',
            u'iso_code3': u'RUS',
            u'names': [u'en:Russia', u'ru:Россия']
        }
        term = notify.decode.decode_country(d)
        self.assertEqual(t2l(term.title, 'en'), u'Russia')
        self.assertEqual(t2l(term.title, 'ru'), u'Россия')
        self.assertEqual(term.country, u'RU')
        self.assertEqual(term.iso_code3, u'RUS')

        d = {
            u'iso_code2': u'RU',
            u'iso_code3': u'RUS',
            u'names': [u'en:Russia']
        }
        term = notify.decode.decode_country(d)
        self.assertEqual(t2l(term.title, 'en'), u'Russia')
        self.assertEqual(t2l(term.title, 'ru'), u'Russia')

    def test_decode_city(self):
        d = {
            u'city_id': 101,
            u'country_code': u'RU',
            u'names': [u'en:ABC', u'ru:АБВ'],
            u'tz': u'JKL'
        }
        term = notify.decode.decode_city(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(term.city_id, 101)
        self.assertEqual(term.country_code, u'RU')
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.tz, u'JKL')

        d = {
            u'city_id': 101,
            u'country_code': u'RU',
            u'names': [u'en:ABC'],
            u'tz': u'JKL'
        }
        term = notify.decode.decode_city(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'ABC')
        self.assertEqual(term.tz, u'JKL')

    def test_decode_airport(self):
        d = {
            u'airport_id': 101,
            u'city': u'201',
            u'iata': u'XXX',
            u'icao': u'XXXX',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M4',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:ABC', u'ru:АБВ'],
            u'has_upgrade_on_checkin_award': True,
        }
        term = notify.decode.decode_airport(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(term.airport_id, 101)
        self.assertEqual(term.city_id, 201)
        self.assertEqual(term.afl_redemption_zone, u'L2')
        self.assertEqual(term.skyteam_redemption_zone, u'M4')
        self.assertEqual(term.iata, u'XXX')
        self.assertEqual(term.icao, u'XXXX')
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.has_upgrade_on_checkin_award, True)

        d = {
            u'airport_id': 101,
            u'city': u'201',
            u'iata': u'XXX',
            u'icao': u'XXXX',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M4',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:ABC'],
            u'has_upgrade_on_checkin_award': False
        }
        term = notify.decode.decode_airport(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'ABC')
        self.assertEqual(term.afl_redemption_zone, u'L2')
        self.assertEqual(term.skyteam_redemption_zone, u'M4')
        self.assertEqual(term.has_upgrade_on_checkin_award, False)

    def test_decode_pair(self):
        d = {
            u'pair_id': 101,
            u'airport_from': u'201',
            u'airport_to': u'202',
            u'airline': u'1900',
            u'miles': 1000,
            u'no_spending': True
        }
        term = notify.decode.decode_pair(d)
        self.assertEqual(term.pair_id, 101)
        self.assertEqual(term.airport_from_id, 201)
        self.assertEqual(term.airport_to_id, 202)
        self.assertEqual(term.airline_id, 1900)
        self.assertEqual(term.miles, 1000)
        self.assertEqual(term.no_spending, True)

    def test_decode_skyteam_service_class(self):
        d = {
            'skyteam_sc_id': 1,
            'code': 'supereconom',
            'names': [u'en:enxxy', u'ru:ruxxy'],
            'weight': 10,
        }
        term = notify.decode.decode_skyteam_service_class(d)
        self.assertEqual(t2l(term.title, 'ru'), u'ruxxy')
        self.assertEqual(t2l(term.title, 'en'), u'enxxy')
        self.assertEqual(term.skyteam_sc_id, 1)
        self.assertEqual(term.code, 'supereconom')

    def test_decode_airline_service_class(self):
        d = {
            'airline_sc_id': 1,
            'airline': 20,
            'skyteam_sc': 10
        }
        term = notify.decode.decode_airline_service_class(d)
        self.assertEqual(term.airline_sc_id, 1)
        self.assertEqual(term.airline_id, 20)
        self.assertEqual(term.skyteam_sc_id, 10)

    def test_decode_service_classes_limit(self):
        d = {
            'service_classes_limit_id': 1,
            'airline_sc': 5,
            'pair': 100
        }
        term = notify.decode.decode_service_classes_limit(d)
        self.assertEqual(term.service_classes_limit_id, 1)
        self.assertEqual(term.airline_sc_id, 5)
        self.assertEqual(term.pair_id, 100)

    def test_decode_tier_level(self):
        d = {
            'tier_level': '101',
            'names': [u'en:ABC', u'ru:АБВ'],
            'miles': 1,
            'ordering': 1,
            'segments': 3
        }
        term = notify.decode.decode_tier_level(d)
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(term.tier_level, '101')
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.miles, 1)
        self.assertEqual(term.segments, 3)
        self.assertEqual(term.ordering, 1)

    def test_decode_tier_level_factor(self):
        d = {
            u'tier_level_factor_id': 1,
            u'tier_level': u'basic',
            u'airline': u'1',
            u'factor': 75.0,
        }
        term = notify.decode.decode_tier_level_factor(d)
        self.assertEqual(term.tier_level_factor_id, 1)
        self.assertEqual(term.tier_level, u'basic')
        self.assertEqual(term.airline_id, 1)
        self.assertEqual(term.factor, 75)

    def test_decode_tariff_group(self):
        d = {
            "id_field": 1,
            "service_class": 1,
            "tariff_group": "aaa",
            "names": ["ru:aaa"],
            "weight": 10
        }
        term = notify.decode.decode_tariff_group(d)
        self.assertEqual(term.tariff_group_id, 1)
        self.assertEqual(term.skyteam_sc_id, 1)
        self.assertEqual(term.code, "aaa")
        self.assertEqual(term.tariff_group_id, 1)
        self.assertEqual(term.names, ["ru:aaa"])
        self.assertEqual(t2l(term.title, "ru"), "aaa")

    def test_decode_airline_tariff_group(self):
        d = {
            "idField": 1,
            "tariffGroup": 1,
            "serviceClass": 1,
            "chargeCoef": 1,
            "weight": 1,
            "fareCode": ''
        }
        term = notify.decode.decode_airline_tariff_group(d)
        self.assertEqual(term.airline_tariff_group_id, 1)
        self.assertEqual(term.tariff_group_id, 1)
        self.assertEqual(term.airline_sc_id, 1)
        self.assertEqual(term.charge_coef, 1)
        self.assertEqual(term.weight, 1)

    def test_decode_booking_class(self):
        d = {
            "idField": 1,
            "bcCode": "AAA",
            "milesAreCharged": False,
            "comment": ["en:ho!", u"ru:хо!"],
            "alTariffGroup": 1
        }
        term = notify.decode.decode_booking_class(d)
        self.assertEqual(term.booking_class_id, 1)
        self.assertEqual(term.code, "AAA")
        self.assertEqual(term.miles_are_charged, False)
        self.assertEqual(term.text_comment, ["en:ho!", u"ru:хо!"])
        self.assertEqual(term.airline_tariff_group_id, 1)

    def test_decode_redemption_zone(self):
        d = {
            u'redemption_zone': u'A1',
            u'names': [u'en:Asia 1', u'ru:Азия 1'],
        }
        term = notify.decode.decode_redemption_zone(d)
        self.assertEqual(term.redemption_zone, u'A1')
        self.assertEqual(term.names, [u'en:Asia 1', u'ru:Азия 1'])
        self.assertEqual(t2l(term.title, 'en'), u'Asia 1')
        self.assertEqual(t2l(term.title, 'ru'), u'Азия 1')

    def test_decode_bonus_route(self):
        d = {
            u'bonus_route_id': 101,
            u'code': u'A1E1',
            u'zone_from': u'A1',
            u'zone_via': None,
            u'zone_to': u'E1',
            u'carrier': u'A'
        }
        term = notify.decode.decode_bonus_route(d)
        self.assertEqual(term.bonus_route_id, 101)
        self.assertEqual(term.code, u'A1E1')
        self.assertEqual(term.zone_from, u'A1')
        self.assertIsNone(term.zone_via)
        self.assertEqual(term.zone_to, u'E1')
        self.assertEqual(term.carrier, u'A')

    def test_decode_award(self):
        d = {
            u'award_id': 101,
            u'type': u'OW',
            u'service_classes_1': u'2',
            u'service_classes_2': None,
            u'award_value': 15000,
            u'route': u'301',
            u'comment': None
        }
        term = notify.decode.decode_award(d)
        self.assertEqual(term.award_id, 101)
        self.assertEqual(term.award_type, u'OW')
        self.assertEqual(term.skyteam_service_class_id_1, 2)
        self.assertIsNone(term.skyteam_service_class_id_2)
        self.assertEqual(term.award_value, 15000)
        self.assertEqual(term.bonus_route_id, 301)

    def test_decode_wrong_route(self):
        d = {
            u'wrong_route_id': 101,
            u'city_from': 201,
            u'city_via': 202,
            u'city_to': 203
        }
        term = notify.decode.decode_wrong_route(d)
        self.assertEqual(term.wrong_route_id, 101)
        self.assertEqual(term.city_from_id, 201)
        self.assertEqual(term.city_via_id, 202)
        self.assertEqual(term.city_to_id, 203)

    def test_decode_partner_category(self):
        d = {
            u'partner_category_id': 101,
            u'status': u'U',
            u'names': [u'en:ABC', u'ru:АБВ']
        }
        term = notify.decode.decode_partner_category(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(term.partner_category_id, 101)
        self.assertEqual(term.status, u'U')
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])

        d = {
            u'partner_category_id': 101,
            u'status': u'U',
            u'names': [u'en:ABC']
        }
        term = notify.decode.decode_partner_category(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'ABC')

    def test_decode_partner(self):
        d = {
            u'partner_id': 101,
            u'status': u'U',
            u'names': [u'en:ABC', u'ru:АБВ'],
            u'partner_description': [u'en:ABC', u'ru:АБВ'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 201, u'status': u'U', u'names': [u'en:ABC']},
                                    {u'partner_category_id': 202, u'status': u'U', u'names': [u'en:ABC']}],
            u'mile_get_comm': [u'en:ABCD1', u'ru:АБВГ1'],
            u'mile_waste_comm': [u'en:ABCD2', u'ru:АБВГ2'],
            u'short_descr': [u'en:ABCD3', u'ru:АБВГ3'],
            u'spec_offer_comm': [u'en:ABCD4', u'ru:АБВГ4'],
            u'weight': 1,
            u'new_until': u'2015-11-09'
        }
        term = notify.decode.decode_partner(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(term.partner_id, 101)
        self.assertEqual(term.status, u'U')
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.url, [u'en:http://some.ru'])
        self.assertEqual(term.mile_action, u'A')
        self.assertEqual(term.partner_categories, ['201', '202'])
        self.assertEqual(term.mile_get_comm, [u'en:ABCD1', u'ru:АБВГ1'])
        self.assertEqual(term.mile_waste_comm, [u'en:ABCD2', u'ru:АБВГ2'])
        self.assertEqual(term.short_descr, [u'en:ABCD3', u'ru:АБВГ3'])
        self.assertEqual(term.spec_offer_comm, [u'en:ABCD4', u'ru:АБВГ4'])
        self.assertEqual(term.weight, 1)
        self.assertEqual(term.new_until, date(2015, 11, 9))

        d = {
            u'partner_id': 101,
            u'status': u'U',
            u'names': [u'en:ABC'],
            u'partner_description': [u'en:ABC'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 201, u'status': u'U', u'names': [u'en:ABC']},
                                    {u'partner_category_id': 202, u'status': u'U', u'names': [u'en:ABC']}],
            u'mile_get_comm': [u'en:ABCD1', u'ru:АБВГ1'],
            u'mile_waste_comm': [u'en:ABCD2', u'ru:АБВГ2'],
            u'short_descr': [u'en:ABCD3', u'ru:АБВГ3'],
            u'spec_offer_comm': [u'en:ABCD4', u'ru:АБВГ4'],
            u'weight': 1,
            u'new_until': u'2015-11-09'
        }
        term = notify.decode.decode_partner(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'ABC')
        self.assertEqual(term.new_until, date(2015, 11, 9))

    def test_decode_partner_office(self):
        d = {
            u'partner_office_id': 101,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'en:ABC', u'ru:АБВ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'en:ABC', u'ru:АБВ'],
            u'address': [u'en:ABC', u'ru:АБВ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 201,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                },
                {
                    u'partner_office_contact_id': 202,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': False,
                    u'contact_type': u'P'
                },
            ]
        }
        term = notify.decode.decode_partner_office(d)
        self.assertEqual(term.partner_office_id, 101)
        self.assertEqual(term.partner, 301)
        self.assertEqual(term.city, 401)
        self.assertEqual(term.lat, 22.22)
        self.assertEqual(term.lon, 11.11)
        self.assertEqual(term.comments, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.address, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.worktime, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.office_type, u'O')
        self.assertTrue(len(term.contacts), 2)

    def test_decode_partner_office_contact(self):
        d = {
            u'partner_office_contact_id': 101,
            u'partner_office': 201,
            u'contact': u'some@some.ru',
            u'main_contact': True,
            u'contact_type': u'E'
        }
        term = notify.decode.decode_partner_office_contact(d)
        self.assertEqual(term.partner_office_contact_id, 101)
        self.assertEqual(term.partner_office, 201)
        self.assertEqual(term.contact_type, u'E')
        self.assertEqual(term.contact, u'some@some.ru')
        self.assertEqual(term.main_contact, True)

        # Длинный email
        d['contact'] = u'%s@%s.ru' % (u'some' * 12, u'some' * 12)
        term = notify.decode.decode_partner_office_contact(d)
        self.assertEqual(len(term.contact), 100)

    def test_decode_partner_award_condition(self):
        d = {
            u'partner_award_condition_id': 101,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 2.3,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'en:ABC', u'ru:АБВ'],
        }
        term = notify.decode.decode_partner_award_condition(d)
        self.assertEqual(term.partner_award_condition_id, 101)
        self.assertEqual(term.partner, 301)
        self.assertEqual(term.award_condition_type, u'E')
        self.assertEqual(term.award_condition_description, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.weight, 1)
        self.assertEqual(term.miles, 2.3)
        self.assertEqual(term.status, u'P')

    def test_decode_special_offer(self):
        d = {
            u'offer_id': -2,
            u'partner': -1,
            u'names': [u'en:ABC', u'ru:АБВ'],
            u'status': u'P',
            u'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            u'offer_url': [u'ru:http://ya.ru'],
            u'ui_languages': u'en,ru'
        }

        term = notify.decode.decode_special_offer(d)
        self.assertEqual(term.offer_id, -2)
        self.assertEqual(term.partner, -1)
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.status, u'P')
        self.assertEqual(term.offer_description, [u'en:DEF', u'ru:ГДЕ'])
        self.assertEqual(term.offer_url, [u'ru:http://ya.ru'])
        self.assertEqual(term.ui_languages, u'en,ru')


class _CommonNotifyServiceTest(object):
    _vocab = NotImplemented
    _class_name = NotImplemented
    _token_from_dict = NotImplemented
    _attrs_map = {}
    _to_add = []
    _to_change = []
    _to_change_pk = []
    _to_replace = []
    _to_delete = []

    def _registerVocabularies(self):
        pyramid.vocabulary.mvcc.register()
        IRegisterableVocabulary(self._vocab).register()

    def _unregisterVocabularies(self):
        unregisterVocabulary(self._vocab.regName)

    def _run_process(self, objects, event):
        svc = notify.NotifyService()
        for ob in objects:
            ob['class'] = self._class_name
        svc.process([{u'objects': objects, u'event': event}])

    def _test_attrs(self, dict_objects, vocab, get_token):
        for dict_obj in dict_objects:
            token = get_token(dict_obj)
            vocab_obj = vocab[token]
            for key in dict_obj:
                attr = self._attrs_map.get(key, key)
                self._compare_attr(key, attr, dict_obj, vocab_obj)

    def _compare_attr(self, key, attr, dict_obj, model_obj):
        if key == 'class':
            return

        dict_value = dict_obj[key]
        model_value = getattr(model_obj, attr)

        #if type(model_value) is int:
        #    model_value = unicode(model_value)

        if type(model_value) is date:
            model_value = model_value.strftime("%Y-%m-%d")

        self.assertEqual(dict_value, model_value)

    def _get_objs_from_db(self):
        ob_cls = self._vocab.objectC
        return ob_cls.bulkLoadList(selectFrom(ob_cls.p_table_name, {}))

    def _compare_with_db(self, dict_objs, db_objs, get_token=None):
        get_token = get_token or self._token_from_dict
        by_token = {k: list(v)[0] for k, v in
                    groupby(dict_objs, key=get_token)}
        for db_obj in db_objs:
            token = ITokenizedTerm(db_obj).token

            self.assertIn(token, by_token)
            dict_obj = by_token[token]

            for key in dict_obj:
                attr = self._attrs_map.get(key, key)
                if key == 'class':
                    continue
                self._compare_attr(key, attr, dict_obj, db_obj)

    def _test_add(self):
        self._run_process(self._to_add, u'add')
        vocab = getV(self._vocab.regName)
        if isinstance(vocab, pyramid.vocabulary.mvcc.MvccVocabulary):
            vocab.on_commit()

        self._test_attrs(self._to_add, vocab, self._token_from_dict)
        self.assertEqual(len(vocab), 2)

        db_objs = self._get_objs_from_db()
        self.assertEqual(len(db_objs), 2)
        self._compare_with_db(self._to_add, db_objs)

        self._additional_test_add()

    def _test_change(self):
        self._run_process(self._to_change, u'change')
        vocab = getV(self._vocab.regName)
        if isinstance(vocab, pyramid.vocabulary.mvcc.MvccVocabulary):
            vocab.on_commit()

        self._test_attrs(self._to_change, vocab, self._token_from_dict)
        self.assertEqual(len(vocab), 2)

        db_objs = self._get_objs_from_db()
        self.assertEqual(len(db_objs), 2)

        self._additional_test_change()

    def _test_change_pk(self):
        self._run_process(self._to_change_pk, u'change')
        vocab = getV(self._vocab.regName)
        if isinstance(vocab, pyramid.vocabulary.mvcc.MvccVocabulary):
            vocab.on_commit()

        changed_token = self._token_from_dict(self._to_change_pk[0])

        if 'vocab_id' in self._attrs_map.values():
            # если запись содержит vocab_id то создается объект с новым токеном
            self.assertIn(changed_token, vocab)
            self.assertEqual(len(vocab), 2)
        else:
            # если запись не содержит vocab_id то изменение игнорируется
            self.assertNotIn(changed_token, vocab)
            self.assertEqual(len(vocab), 2)

        db_objs = self._get_objs_from_db()
        self.assertEqual(len(db_objs), 2)

        self._additional_test_change_pk()

    def _test_replace_all(self):
        self._run_process(self._to_replace, u'replace_all')
        vocab = getV(self._vocab.regName)
        if isinstance(vocab, pyramid.vocabulary.mvcc.MvccVocabulary):
            vocab.on_commit()

        old_tokens = map(self._token_from_dict, self._to_add)  # from `add`
        for token in old_tokens:
            self.assertNotIn(token, vocab)

        self._test_attrs(self._to_replace, vocab, self._token_from_dict)
        self.assertEqual(len(vocab), 2)

        db_objs = self._get_objs_from_db()
        self.assertEqual(len(db_objs), 2)
        self._compare_with_db(self._to_replace, db_objs)

        self._additional_test_replace_all()

    def _test_delete(self):
        self._run_process(self._to_delete, u'delete')
        vocab = getV(self._vocab.regName)
        if isinstance(vocab, pyramid.vocabulary.mvcc.MvccVocabulary):
            vocab.on_commit()

        deleted_token = self._token_from_dict(self._to_delete[0])
        remaining_tokens = \
            set(map(self._token_from_dict, self._to_replace)) ^ {deleted_token}

        self.assertNotIn(deleted_token, vocab)
        for token in remaining_tokens:
            self.assertIn(token, vocab)
        self.assertEqual(len(vocab), 1)

        if isinstance(vocab, pyramid.vocabulary.mvcc.MvccVocabulary):
            db_objs = self._get_objs_from_db()
            self.assertEqual(len(db_objs), 1)

        self._additional_test_delete()

    def _additional_test_add(self):
        pass

    def _additional_test_change(self):
        pass

    def _additional_test_change_pk(self):
        pass

    def _additional_test_replace_all(self):
        pass

    def _additional_test_delete(self):
        pass

    def test_process(self):
        self._test_add()
        self._test_change()
        self._test_change_pk()
        self._test_replace_all()
        self._test_delete()


class TestNotifyServiceProcessAirline(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.air.AirlinesVocabulary
    _class_name = u'Airline'
    _token_from_dict = lambda s, d: str(d['airline_id'])
    _attrs_map = {
        'parent_airline': 'parent_airline_id',
        'airport': 'airport_id'
    }

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessAirline, self)._registerVocabularies()
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineIndexer), 'service_classes_limits_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer), 'tier_level_factors_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    _to_add = [
        {
            u'airline_id': 12345678,
            u'iata': u'AAA',
            u'icao': u'BBB',
            u'callsign': u'ABC',
            u'country': u'RU',
            u'airport': -3,
            u'parent_airline': None,
            u'alliance': u'Skyteam',
            u'names': [u'en:ABC', u'ru:ACB'],
            u'url': [u'ru:AAASITE'],
            u'weight': 1,
            u'miles_minimum': 100.0,
            u'miles_limitation': 'I',
            u'miles_earn_description': [u'en:EEE', 'ru:FFF'],
            u'miles_earn_comment': [u'en:SSS', 'ru:XXX']
        },
        {
            u'airline_id': 12345679,
            u'iata': u'DDD',
            u'icao': u'EEE',
            u'callsign': u'DEF',
            u'parent_airline': None,
            u'country': u'RU',
            u'airport': -1,
            u'alliance': u'Skyteam',
            u'names': [u'en:DEF', u'ru:DFE'],
            u'url': [u'en:DDDSITE'],
            u'weight': 2,
            u'miles_minimum': 700.0,
            u'miles_limitation': 'A',
            u'miles_earn_description': [u'en:TTT', 'ru:UUU'],
            u'miles_earn_comment': [u'ru:VVV', u'en:WWW']
        }]

    _to_change = [
        {
            u'airline_id': 12345679,
            u'iata': u'DZD',
            u'icao': u'EZE',
            u'callsign': u'DZF',
            u'parent_airline': None,
            u'country': u'RU',
            u'airport': -4,
            u'alliance': u'Skyteam',
            u'names': [u'en:DZF', u'ru:DZE'],
            u'url': [u'en:DDDSITE2'],
            u'weight': 8,
            u'miles_minimum': 800.0,
            u'miles_limitation': 'A',
            u'miles_earn_description': [u'en:NNN', 'ru:MMM'],
            u'miles_earn_comment': [u'ru:LLL', u'en:KKK']
        }]

    _to_change_pk = [
        {
            u'airline_id': 12345680,
            u'iata': u'DZD',
            u'icao': u'EZE',
            u'callsign': u'DZF',
            u'parent_airline': None,
            u'country': u'RU',
            u'airport': -4,
            u'alliance': u'Skyteam',
            u'names': [u'en:DZF', u'ru:DZE'],
            u'url': [u'en:DDDSITE2'],
            u'weight': 8,
            u'miles_minimum': 800.0,
            u'miles_limitation': 'A',
            u'miles_earn_description': [u'en:NNN', 'ru:MMM'],
            u'miles_earn_comment': [u'ru:LLL', u'en:KKK']
        }]

    _to_replace = [
        {
            u'airline_id': 12345680,
            u'iata': u'KKK',
            u'icao': u'LLL',
            u'callsign': u'LMN',
            u'parent_airline': None,
            u'country': u'RU',
            u'airport': -5,
            u'alliance': u'Darkteam',
            u'names': [u'en:MNO', u'ru:OMN'],
            u'url': [u'en:MMMSITE'],
            u'weight': 1,
            u'miles_minimum': 800.0,
            u'miles_limitation': 'A',
            u'miles_earn_description': [u'en:NNN', 'ru:MMM'],
            u'miles_earn_comment': [u'ru:LLL', u'en:KKK']
        },
        {
            u'airline_id': 12345681,
            u'iata': u'GGG',
            u'icao': u'HHH',
            u'callsign': u'GHI',
            u'parent_airline': None,
            u'country': u'RU',
            u'airport': -4,
            u'alliance': u'Skyteam',
            u'names': [u'en:GHI', u'ru:GHI'],
            u'url': [u'en:GGGSITE'],
            u'weight': 1,
            u'miles_minimum': 100.0,
            u'miles_limitation': 'I',
            u'miles_earn_description': [u'en:EEE', 'ru:FFF'],
            u'miles_earn_comment': [u'en:SSS', 'ru:XXX']
        }]

    _to_delete = [
        {
            u'airline_id': 12345680,
            u'iata': u'KKK',
            u'icao': u'LLL',
            u'callsign': u'LMN',
            u'parent_airline': None,
            u'country': u'RU',
            u'airport': -5,
            u'alliance': u'Darkteam',
            u'names': [u'en:MNO', u'ru:OMN'],
            u'url': [u'en:MMMSITE'],
            u'weight': 1,
            u'miles_minimum': 100.0,
            u'miles_limitation': 'I',
            u'miles_earn_description': [u'en:EEE', 'ru:FFF'],
            u'miles_earn_comment': [u'en:SSS', 'ru:XXX']
        }]


class TestNotifyServiceProcessCountry(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.geo.CountriesVocabulary
    _class_name = u'Country'
    _token_from_dict = lambda s, d: d['iso_code2']
    _attrs_map = {
        'iso_code2': 'country'
    }
    _to_add = [
        {
            u'iso_code2': u'AB',
            u'iso_code3': u'ABC',
            u'names': [u'en:Abc', u'ru:Абв']
        },
        {
            u'iso_code2': u'DE',
            u'iso_code3': u'DEF',
            u'names': [u'en:Def', u'ru:Где']
        }
    ]
    _to_change = [
        {
            u'iso_code2': u'AB',
            u'iso_code3': u'CBA',
            u'names': [u'en:Abc']
        }
    ]
    _to_change_pk = [
        {
            u'iso_code2': u'GH',
            u'iso_code3': u'CBA',
            u'names': [u'en:Abc']
        }
    ]
    _to_replace = [
        {
            u'iso_code2': u'GH',
            u'iso_code3': u'GHI',
            u'names': [u'en:Ghi']
        },
        {
            u'iso_code2': u'JK',
            u'iso_code3': u'JKL',
            u'names': [u'en:Jkl']
        }
    ]
    _to_delete = [
        {
            u'iso_code2': u'GH',
            u'iso_code3': u'GHI',
            u'names': [u'en:Ghi']
        }
    ]


class TestNotifyServiceProcessCity(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.geo.CitiesVocabulary
    _class_name = u'City'
    _token_from_dict = lambda s, d: str(d['city_id'])
    _to_add = [
        {
            u'city_id': 101,
            u'country_code': u'RU',
            u'names': [u'en:Saint Petersburg', u'ru:Санкт-Петербург'],
            u'tz': 'Europe/Moscow'
        },
        {
            u'city_id': 102,
            u'country_code': u'RU',
            u'names': [u'en:Moscow', u'ru:Москва'],
            u'tz': 'Europe/Moscow'
        }
    ]
    _to_change = [
        {
            u'city_id': 101,
            u'country_code': u'SU',
            u'names': [u'en:Leningrad', u'ru:Ленинград'],
            u'tz': 'Europe/Moscow'
        }
    ]
    _to_change_pk = [
        {
            u'city_id': 103,
            u'country_code': u'SU',
            u'names': [u'en:Leningrad', u'ru:Ленинград'],
            u'tz': 'Europe/Moscow'
        }
    ]
    _to_replace = [
        {
            u'city_id': 103,
            u'country_code': u'RU',
            u'names': [u'en:Murmansk', u'ru:Мурманск'],
            u'tz': 'Europe/Moscow'
        },
        {
            u'city_id': 104,
            u'country_code': u'RU',
            u'names': [u'en:Vladivostok', u'ru:Владивосток'],
            u'tz': 'Asia/Vladivostok'
        }
    ]
    _to_delete = [
        {
            u'city_id': 103,
            u'country_code': u'RU',
            u'names': [u'en:Murmansk', u'ru:Мурманск'],
            u'tz': 'Europe/Moscow'
        }
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessCity, self)._registerVocabularies()
        setup_vocabulary(models.geo.AirportsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer),
                                  'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer),
                                  'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer),
                                  'airports_by_city_idx')


class TestNotifyServiceProcessAirport(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.geo.AirportsVocabulary
    _class_name = u'Airport'
    _attrs_map = {
        'city': 'city_id'
    }
    _to_add = [
        {
            u'airport_id': 101,
            u'city': u'201',
            u'iata': u'XXX',
            u'icao': u'XXXX',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M4',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Abc', u'ru:Абв'],
            u'has_upgrade_on_checkin_award': True
        },
        {
            u'airport_id': 102,
            u'city': u'201',
            u'iata': u'XXY',
            u'icao': u'XXYY',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M4',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Def', u'ru:Где'],
            u'has_upgrade_on_checkin_award': True
        }
    ]
    _to_change = [
        {
            u'airport_id': 101,
            u'city': u'201',
            u'iata': u'XXZ',
            u'icao': u'XXZZ',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M5',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Igh', u'ru:Жзи'],
            u'has_upgrade_on_checkin_award': False
        }
    ]
    _to_change_pk = [
        {
            u'airport_id': 103,
            u'city': u'201',
            u'iata': u'XXV',
            u'icao': u'XXVV',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M5',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Igh', u'ru:Жзи'],
            u'has_upgrade_on_checkin_award': False
        }
    ]
    _to_replace = [
        {
            u'airport_id': 103,
            u'city': u'201',
            u'iata': u'XXV',
            u'icao': u'XXVV',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M5',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Igh', u'ru:Жзи'],
            u'has_upgrade_on_checkin_award': False
        },
        {
            u'airport_id': 104,
            u'city': u'201',
            u'iata': u'XXQ',
            u'icao': u'XXQQ',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M4',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Klm', u'ru:Клм'],
            u'has_upgrade_on_checkin_award': True
        }
    ]
    _to_delete = [
        {
            u'airport_id': 103,
            u'city': u'201',
            u'iata': u'XXQ',
            u'icao': u'XXQQ',
            u'afl_redemption_zone': u'L2',
            u'skyteam_redemption_zone': u'M5',
            u'lon': 10.1,
            u'lat': -20.2,
            u'names': [u'en:Igh', u'ru:Жзи'],
            u'has_upgrade_on_checkin_award': False
        }
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessAirport, self)._registerVocabularies()
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    def _token_from_dict(self, d):
        return str(d['airport_id'])

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key in ('city',):
            dict_obj[key] = int(dict_obj[key])

        if key == 'redemption_zone':
            self.assertEqual(getattr(vocab_obj, 'afl_redemption_zone'), dict_obj[key])
            return

        super(TestNotifyServiceProcessAirport, self)._compare_attr(
            key, attr, dict_obj, vocab_obj)


class TestNotifyServiceProcessPair(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.route.PairsVocabulary
    _class_name = u'Pair'
    _attrs_map = {
        'airport_from': 'airport_from_id',
        'airport_to': 'airport_to_id',
        'airline': 'airline_id',
    }
    _to_add = [
        {
            u'pair_id': 101,
            u'airport_from': u'201',
            u'airport_to': u'202',
            u'airline': u'301',
            u'miles': 1000,
            u'no_spending': True
        },
        {
            u'pair_id': 102,
            u'airport_from': u'203',
            u'airport_to': u'204',
            u'airline': u'301',
            u'miles': 1000,
            u'no_spending': True
        }
    ]
    _to_change = [
        {
            u'pair_id': 101,
            u'airport_from': u'201',
            u'airport_to': u'202',
            u'airline': u'301',
            u'miles': 500,
            u'no_spending': False
        }
    ]
    _to_change_pk = [
        {
            u'pair_id': 103,
            u'airport_from': u'201',
            u'airport_to': u'202',
            u'airline': u'301',
            u'miles': 500,
            u'no_spending': False
        }
    ]
    _to_replace = [
        {
            u'pair_id': 103,
            u'airport_from': u'205',
            u'airport_to': u'206',
            u'airline': u'301',
            u'miles': 1000,
            u'no_spending': False
        },
        {
            u'pair_id': 104,
            u'airport_from': u'205',
            u'airport_to': u'206',
            u'airline': u'301',
            u'miles': 1000,
            u'no_spending': False
        }
    ]
    _to_delete = [
        {
            u'pair_id': 103,
            u'airport_from': u'201',
            u'airport_to': u'202',
            u'airline': u'301',
            u'miles': 500,
            u'no_spending': False
        }
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessPair, self)._registerVocabularies()
        setup_vocabulary(models.air.AirlinesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    def _unregisterVocabularies(self):
        unregisterVocabulary(models.air.AirlinesVocabulary.regName)
        super(TestNotifyServiceProcessPair, self)._unregisterVocabularies()

    def _token_from_dict(self, d):
        return str(d['pair_id'])

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key in ('airport_from', 'airport_to', 'airline'):
            dict_obj[key] = int(dict_obj[key])

        super(TestNotifyServiceProcessPair, self)._compare_attr(
            key, attr, dict_obj, vocab_obj)


class TestNotifyServiceProcessSkyTeamServiceClass(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.SkyTeamServiceClassesVocabulary
    _class_name = 'SkyTeamServiceClass'
    _token_from_dict = lambda s, d: str(d['skyteam_sc_id'])
    _attrs_map = {}

    _to_add = [
        {
            'skyteam_sc_id': 1,
            'code': 'xxy',
            'names': [u'en:enxxy', u'ru:ruxxy'],
            'weight': 10,
        },
        {
            'skyteam_sc_id': 2,
            'code': 'xxx',
            'names': [u'en:enxxx', u'ru:ruxxx'],
            'weight': 20,
        }
    ]
    _to_change = [
        {
            'skyteam_sc_id': 1,
            'code': 'zzy',
            'names': [u'en:enzzy', u'ru:ruzzy'],
            'weight': 10,
        }
    ]
    _to_change_pk = [
        {
            'skyteam_sc_id': 3,
            'code': 'zzy',
            'names': [u'en:enzzy', u'ru:ruzzy'],
            'weight': 10,
        }
    ]
    _to_replace = [
        {
            'skyteam_sc_id': 3,
            'code': 'zzk',
            'names': [u'en:enzzk', u'ru:ruzzk'],
            'weight': 30,
        },
        {
            'skyteam_sc_id': 4,
            'code': 'ttk',
            'names': [u'en:enttk', u'ru:ruttk'],
            'weight': 40,
        }
    ]
    _to_delete = [
        {
            'skyteam_sc_id': 3,
            'code': 'zzk',
            'names': [u'en:enzzk', u'ru:ruzzk'],
            'weight': 30,
        }
    ]

    def _registerVocabularies(self):
        super(
            TestNotifyServiceProcessSkyTeamServiceClass,
            self
        )._registerVocabularies()
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)


class TestNotifyServiceProcessAirlineServiceClass(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.AirlineServiceClassesVocabulary
    _class_name = 'AirlineServiceClass'
    _token_from_dict = lambda s, d: str(d['airline_sc_id'])
    _attrs_map = {
        'airline': 'airline_id',
        'skyteam_sc': 'skyteam_sc_id'
    }

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessAirlineServiceClass, self)._registerVocabularies()
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer), 'airline_tariff_groups_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.BookingClassesByAirlineTariffGroupIndexer), 'booking_classes_by_airline_tariff_group_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer), 'service_classes_limits_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    _to_add = [
        {
            'airline_sc_id': 1,
            'airline': -1,
            'skyteam_sc': 1
        },
        {
            'airline_sc_id': 2,
            'airline': -1,
            'skyteam_sc': 2
        }
    ]
    _to_change = [
        {
            'airline_sc_id': 1,
            'airline': -2,
            'skyteam_sc': 2
        }
    ]
    _to_change_pk = [
        {
            'airline_sc_id': 3,
            'airline': -2,
            'skyteam_sc': 2
        }
    ]
    _to_replace = [
        {
            'airline_sc_id': 3,
            'airline': -3,
            'skyteam_sc': 3
        },
        {
            'airline_sc_id': 4,
            'airline': -3,
            'skyteam_sc': 3
        }
    ]
    _to_delete = [
        {
            'airline_sc_id': 3,
            'airline': -3,
            'skyteam_sc': 3
        }
    ]


class TestNotifyServiceProcessServiceClassesLimit(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.ServiceClassesLimitsVocabulary
    _class_name = 'ServiceClassesLimit'
    _token_from_dict = lambda s, d: str(d['service_classes_limit_id'])
    _attrs_map = {
        'airline_sc': 'airline_sc_id',
        'pair': 'pair_id',
    }

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessServiceClassesLimit, self)._registerVocabularies()
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer), 'service_classes_limits_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineIndexer), 'service_classes_limits_by_airline_idx')

    _to_add = [
        {
            'service_classes_limit_id': 1,
            'airline_sc': -1,
            'pair': 101
        },
        {
            'service_classes_limit_id': 2,
            'airline_sc': -1,
            'pair': 102
        }
    ]
    _to_change = [
        {
            'service_classes_limit_id': 1,
            'airline_sc': -3,
            'pair': 103
        }
    ]
    _to_change_pk = [
        {
            'service_classes_limit_id': 3,
            'airline_sc': -3,
            'pair': 103
        }
    ]
    _to_replace = [
        {
            'service_classes_limit_id': 3,
            'airline_sc': -4,
            'pair': 104
        },
        {
            'service_classes_limit_id': 4,
            'airline_sc': -5,
            'pair': 105
        }
    ]
    _to_delete = [
        {
            'service_classes_limit_id': 3,
            'airline_sc': -4,
            'pair': 104
        }
    ]


class TestNotifyServiceProcessTariffGroup(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.TariffGroupsVocabulary
    _class_name = 'TariffGroup'
    _token_from_dict = lambda s, d: str(d['id_field'])
    _attrs_map = {
        'id_field': 'tariff_group_id',
        'service_class': 'skyteam_sc_id',
        'tariff_group': 'code',
    }

    def _registerVocabularies(self):
        super(
            TestNotifyServiceProcessTariffGroup,
            self
        )._registerVocabularies()
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.BookingClassesByAirlineTariffGroupIndexer
            ), "booking_classes_by_airline_tariff_group_idx"
        )

    _to_add = [
        {
            'id_field': -4,
            'service_class': -1,
            'tariff_group': 'aaazzz',
            'names': [u'ru:аааззз'],
            'weight': 10
        },
        {
            'id_field': -6,
            'service_class': -1,
            'tariff_group': 'aaazzzx',
            'names': [u'ru:ааазззх'],
            'weight': 10
        }
    ]
    _to_change = [
        {
            'id_field': -4,
            'service_class': -2,
            'tariff_group': 'aaazzzz',
            'names': [u'ru:ааазззз'],
            'weight': 10
        }
    ]
    _to_change_pk = [
        {
            'id_field': -5,
            'service_class': -2,
            'tariff_group': 'aaazzzz',
            'names': [u'ru:ааазззз'],
            'weight': 10
        }
    ]
    _to_replace = [
        {
            'id_field': -5,
            'service_class': -1,
            'tariff_group': 'aaazzz',
            'names': [u'ru:аааззз'],
            'weight': 10
        },
        {
            'id_field': -7,
            'service_class': -1,
            'tariff_group': 'aaazzzx',
            'names': [u'ru:ааазззх'],
            'weight': 10
        }
    ]
    _to_delete = [
        {
            'id_field': -5,
            'service_class': -1,
            'tariff_group': 'aaazzz',
            'names': [u'ru:аааззз'],
            'weight': 10
        }
    ]


class TestNotifyServiceProcessAirlineTariffGroup(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.AirlineTariffGroupsVocabulary
    _class_name = u'AirlineTariffGroup'
    _token_from_dict = lambda s, d: str(d['idField'])
    _attrs_map = {
        'idField': 'airline_tariff_group_id',
        'tariffGroup': 'tariff_group_id',
        'serviceClass': 'airline_sc_id',
        'chargeCoef': 'charge_coef',
    }

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessAirlineTariffGroup, self)._registerVocabularies()
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.BookingClassesByAirlineTariffGroupIndexer), 'booking_classes_by_airline_tariff_group_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer), 'airline_tariff_groups_by_airline_service_class_idx')

    _to_add = [
        {
            'idField': -10,
            'tariffGroup': -1,
            'serviceClass': -1,
            'chargeCoef': 5,
            'weight': 1,
            'fareCode': 'A'
        },
        {
            'idField': -11,
            'tariffGroup': -2,
            'serviceClass': -2,
            'chargeCoef': 5,
            'weight': 1,
            'fareCode': ''

        }
    ]

    _to_change = [
        {
            'idField': -10,
            'tariffGroup': -3,
            'serviceClass': -3,
            'chargeCoef': 3,
            'weight': 2,
            'fareCode': ''
        }
    ]

    _to_change_pk = [
        {
            'idField': -12,
            'tariffGroup': -3,
            'serviceClass': -3,
            'chargeCoef': 3,
            'weight': 2,
            'fareCode': ''
        }
    ]

    _to_replace = [
        {
            'idField': -12,
            'tariffGroup': -1,
            'serviceClass': -1,
            'chargeCoef': 5,
            'weight': 1,
            "fareCode": ''
        },
        {
            'idField': -13,
            'tariffGroup': -2,
            'serviceClass': -2,
            'chargeCoef': 5,
            'weight': 1,
            "fareCode": ''
        },
    ]

    _to_delete = [
        {
            'idField': -13,
            'tariffGroup': -2,
            'serviceClass': -2,
            'chargeCoef': 5,
            'weight': 1,
            "fareCode": ''
        },
    ]


class TestNotifyServiceProcessBookingClass(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.BookingClassesVocabulary
    _class_name = "BookingClass"
    _token_from_dict = lambda s, d: str(d['idField'])
    _attrs_map = {
        "idField": "booking_class_id",
        "bcCode": "code",
        "milesAreCharged": "miles_are_charged",
        "comment": "text_comment",
        "alTariffGroup": "airline_tariff_group_id"
    }

    def _registerVocabularies(self):
        super(
            TestNotifyServiceProcessBookingClass,
            self
        )._registerVocabularies()
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.BookingClassesByAirlineTariffGroupIndexer
            ), "booking_classes_by_airline_tariff_group_idx"
        )

    _to_add = [
        {
            "idField": -10,
            "bcCode": "AAA",
            "milesAreCharged": False,
            "comment": ["en:UUU"],
            "alTariffGroup": -10,
        },
        {
            "idField": -11,
            "bcCode": "BBB",
            "milesAreCharged": True,
            "comment": ["en:OOO"],
            "alTariffGroup": -11,
        },
    ]

    _to_change = [
        {
            "idField": -10,
            "bcCode": "CCC",
            "milesAreCharged": True,
            "comment": ["en:III"],
            "alTariffGroup": -11,
        },
    ]

    _to_change_pk = [
        {
            "idField": -12,
            "bcCode": "CCC",
            "milesAreCharged": True,
            "comment": ["en:III"],
            "alTariffGroup": -11,
        },
    ]

    _to_replace = [
        {
            "idField": -12,
            "bcCode": "DDD",
            "milesAreCharged": True,
            "comment": ["en:FFF"],
            "alTariffGroup": -11,
        },
        {
            "idField": -13,
            "bcCode": "CCC",
            "milesAreCharged": True,
            "comment": ["en:AAA"],
            "alTariffGroup": -12,
        },
    ]

    _to_delete = [
        {
            "idField": -13,
            "bcCode": "CCC",
            "milesAreCharged": True,
            "comment": ["en:AAA"],
            "alTariffGroup": -12,
        },
    ]


class TestNotifyServiceProcessRedemptionZone(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.award.RedemptionZonesVocabulary
    _class_name = u'RedemptionZone'
    _token_from_dict = lambda s, d: str(d['redemption_zone'])

    _to_add = [
        {
            u'redemption_zone': u'A1',
            u'names': [u'en:Asia 1', u'ru:Азия 1'],
        },
        {
            u'redemption_zone': u'A2',
            u'names': [u'en:Asia 2', u'ru:Азия 2'],
        }
    ]

    _to_change = [
        {
            u'redemption_zone': u'A1',
            u'names': [u'en:Asia 3', u'ru:Азия 3'],
        }
    ]

    _to_change_pk = [
        {
            u'redemption_zone': u'A3',
            u'names': [u'en:Asia 3', u'ru:Азия 3'],
        }
    ]

    _to_replace = [
        {
            u'redemption_zone': u'A3',
            u'names': [u'en:Asia 3', u'ru:Азия 3'],
        },
        {
            u'redemption_zone': u'A4',
            u'names': [u'en:Asia 4', u'ru:Азия 4'],
        }
    ]

    _to_delete = [
        {
            u'redemption_zone': u'A3',
            u'names': [u'en:Asia 3', u'ru:Азия 3'],
        }
    ]


class TestNotifyServiceProcessBonusRoute(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.award.BonusRoutesVocabulary
    _class_name = u'BonusRoute'
    _token_from_dict = lambda s, d: str(d['bonus_route_id'])
    _to_add = [
        {
            u'bonus_route_id': 101,
            u'code': u'A1E1',
            u'zone_from': u'A1',
            u'zone_via': None,
            u'zone_to': u'E1',
            u'carrier': u'A'
        },
        {
            u'bonus_route_id': 102,
            u'code': u'A2E2',
            u'zone_from': u'A2',
            u'zone_via': None,
            u'zone_to': u'E2',
            u'carrier': u'A'
        }
    ]
    _to_change = [
        {
            u'bonus_route_id': 101,
            u'code': u'A1E2',
            u'zone_from': u'A1',
            u'zone_via': None,
            u'zone_to': u'E2',
            u'carrier': u'A'
        }
    ]
    _to_change_pk = [
        {
            u'bonus_route_id': 103,
            u'code': u'A1E3',
            u'zone_from': u'A1',
            u'zone_via': None,
            u'zone_to': u'E3',
            u'carrier': u'A'
        }
    ]
    _to_replace = [
        {
            u'bonus_route_id': 103,
            u'code': u'A3E3',
            u'zone_from': u'A3',
            u'zone_via': None,
            u'zone_to': u'E3',
            u'carrier': u'A'
        },
        {
            u'bonus_route_id': 104,
            u'code': u'A4E4',
            u'zone_from': u'A4',
            u'zone_via': None,
            u'zone_to': u'E4',
            u'carrier': u'A'
        }
    ]
    _to_delete = [
        {
            u'bonus_route_id': 103,
            u'code': u'A3E3',
            u'zone_from': u'A3',
            u'zone_via': None,
            u'zone_to': u'E3',
            u'carrier': u'A'
        }
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessBonusRoute, self)._registerVocabularies()
        setup_vocabulary(models.award.AwardsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.BonusRoutesByCtxIndexer), 'bonus_routes_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.AwardsByBonusRouteIndexer), 'awards_by_bonus_route_idx')


class TestNotifyServiceProcessAward(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.award.AwardsVocabulary
    _class_name = u'Award'
    _token_from_dict = lambda s, d: str(d['award_id'])
    _attrs_map = {
        u'type': u'award_type',
        u'service_classes_1': u'skyteam_service_class_id_1',
        u'service_classes_2': u'skyteam_service_class_id_2',
        u'route': u'bonus_route_id',
    }
    _to_add = [
        {
            u'award_id': 101,
            u'type': u'OW',
            u'service_classes_1': u'1',
            u'service_classes_2': None,
            u'award_value': 15000,
            u'route': u'301'
        },
        {
            u'award_id': 102,
            u'type': u'RT',
            u'service_classes_1': u'1',
            u'service_classes_2': None,
            u'award_value': 25000,
            u'route': u'301'
        }
    ]
    _to_change = [
        {
            u'award_id': 101,
            u'type': u'OW',
            u'service_classes_1': u'1',
            u'service_classes_2': None,
            u'award_value': 10000,
            u'route': u'301'
        },
    ]
    _to_change_pk = [
        {
            u'award_id': 103,
            u'type': u'OW',
            u'service_classes_1': u'1',
            u'service_classes_2': None,
            u'award_value': 10000,
            u'route': u'301'
        },
    ]
    _to_replace = [
        {
            u'award_id': 103,
            u'type': u'U',
            u'service_classes_1': u'1',
            u'service_classes_2': u'2',
            u'award_value': 15000,
            u'route': u'301'
        },
        {
            u'award_id': 104,
            u'type': u'UC',
            u'service_classes_1': u'1',
            u'service_classes_2': u'2',
            u'award_value': 25000,
            u'route': u'301'
        }
    ]
    _to_delete = [
        {
            u'award_id': 103,
            u'type': u'U',
            u'service_classes_1': u'1',
            u'service_classes_2': u'2',
            u'award_value': 15000,
            u'route': u'301'
        },
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessAward, self)._registerVocabularies()
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.AwardsByBonusRouteIndexer), 'awards_by_bonus_route_idx')

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key in ('route', 'service_classes_1', 'service_classes_2'):
            try:
                dict_obj[key] = int(dict_obj[key])
            except TypeError:
                pass

        super(TestNotifyServiceProcessAward, self)._compare_attr(
            key, attr, dict_obj, vocab_obj)


class TestNotifyServiceProcessWrongRoute(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.award.WrongRoutesVocabulary
    _class_name = u'WrongRoute'
    _token_from_dict = lambda s, d: str(d['wrong_route_id'])
    _attrs_map = {
        u'city_from': u'city_from_id',
        u'city_via': u'city_via_id',
        u'city_to': u'city_to_id'
    }
    _to_add = [
        {
            u'wrong_route_id': 101,
            u'city_from': 201,
            u'city_via': 202,
            u'city_to': 203
        },
        {
            u'wrong_route_id': 102,
            u'city_from': 204,
            u'city_via': 205,
            u'city_to': 206
        }
    ]
    _to_change = [
        {
            u'wrong_route_id': 101,
            u'city_from': 201,
            u'city_via': 202,
            u'city_to': 208
        }
    ]
    _to_change_pk = [
        {
            u'wrong_route_id': 103,
            u'city_from': 201,
            u'city_via': 202,
            u'city_to': 208
        }
    ]
    _to_replace = [
        {
            u'wrong_route_id': 103,
            u'city_from': 207,
            u'city_via': 208,
            u'city_to': 209
        },
        {
            u'wrong_route_id': 104,
            u'city_from': 210,
            u'city_via': 211,
            u'city_to': 212
        }
    ]
    _to_delete = [
        {
            u'wrong_route_id': 103,
            u'city_from': 207,
            u'city_via': 208,
            u'city_to': 209
        }
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessWrongRoute, self)._registerVocabularies()
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.WrongRoutesByCtxIndexer), 'wrong_routes_by_ctx_idx')


class TestNotifyServiceProcessPartnerCategory(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.partner.PartnerCategoriesVocabulary
    _class_name = u'PartnerCategory'
    _token_from_dict = lambda s, d: str(d['partner_category_id'])
    _to_add = [
        {
            u'partner_category_id': 101,
            u'status': u'U',
            u'names': [u'en:ABC', u'ru:АБВ']
        },
        {
            u'partner_category_id': 102,
            u'status': u'U',
            u'names': [u'en:DEF', u'ru:ГДЕ']
        }
    ]
    _to_change = [
        {
            u'partner_category_id': 101,
            u'status': u'P',
            u'names': [u'en:FGH', u'ru:ЖЗИ']
        }
    ]
    _to_change_pk = [
        {
            u'partner_category_id': 103,
            u'status': u'P',
            u'names': [u'en:FGH', u'ru:ЖЗИ']
        }
    ]
    _to_replace = [
        {
            u'partner_category_id': 103,
            u'status': u'P',
            u'names': [u'en:IKL', u'ru:КЛМ']
        },
        {
            u'partner_category_id': 104,
            u'status': u'P',
            u'names': [u'en:MNO', u'ru:НОП']
        }
    ]
    _to_delete = [
        {
            u'partner_category_id': 104,
            u'status': u'P',
            u'names': [u'en:IKL', u'ru:КЛМ']
        }
    ]


class TestNotifyServiceProcessPartner(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.partner.PartnersVocabulary
    _class_name = u'Partner'
    _token_from_dict = lambda s, d: str(d['partner_id'])
    _to_add = [
        {
            u'partner_id': 101,
            u'status': u'U',
            u'names': [u'en:ABC1', u'ru:АБВ1'],
            u'partner_description': [u'en:ABC1', u'ru:АБВ1'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 201, u'status': u'U', u'names': [u'en:ABC1']},
                                    {u'partner_category_id': 202, u'status': u'U', u'names': [u'en:ABC2']}],
            u'mile_get_comm': [u'en:ABCD11', u'ru:АБВГ11'],
            u'mile_waste_comm': [u'en:ABCD12', u'ru:АБВГ12'],
            u'short_descr': [u'en:ABCD13', u'ru:АБВГ13'],
            u'spec_offer_comm': [u'en:ABCD14', u'ru:АБВГ14'],
            u'weight': 1,
            u'new_until': '2015-04-05'
        },
        {
            u'partner_id': 102,
            u'status': u'U',
            u'names': [u'en:ABC2', u'ru:АБВ2'],
            u'partner_description': [u'en:ABC2', u'ru:АБВ2'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 203, u'status': u'U', u'names': [u'en:ABC3']},
                                    {u'partner_category_id': 204, u'status': u'U', u'names': [u'en:ABC4']}],
            u'mile_get_comm': [u'en:ABCD21', u'ru:АБВГ21'],
            u'mile_waste_comm': [u'en:ABCD22', u'ru:АБВГ22'],
            u'short_descr': [u'en:ABCD23', u'ru:АБВГ23'],
            u'spec_offer_comm': [u'en:ABCD24', u'ru:АБВГ24'],
            u'weight': 2,
            u'new_until': '2015-07-04'
        }
    ]
    _to_change = [
        {
            u'partner_id': 101,
            u'status': u'U',
            u'names': [u'en:DEF1', u'ru:ГДЕ1'],
            u'partner_description': [u'en:DEF1', u'ru:ГДЕ1'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 205, u'status': u'U', u'names': [u'en:ABC5']}],
            u'mile_get_comm': [u'en:ABCD31', u'ru:АБВГ31'],
            u'mile_waste_comm': [u'en:ABCD32', u'ru:АБВГ32'],
            u'short_descr': [u'en:ABCD33', u'ru:АБВГ33'],
            u'spec_offer_comm': [u'en:ABCD34', u'ru:АБВГ34'],
            u'weight': 3,
            u'new_until': '2016-11-01'
        }
    ]
    _to_change_pk = [
        {
            u'partner_id': 103,
            u'status': u'U',
            u'names': [u'en:DEF1', u'ru:ГДЕ1'],
            u'partner_description': [u'en:DEF1', u'ru:ГДЕ1'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 206, u'status': u'U', u'names': [u'en:ABC6']}],
            u'mile_get_comm': [u'en:ABCD41', u'ru:АБВГ41'],
            u'mile_waste_comm': [u'en:ABCD42', u'ru:АБВГ42'],
            u'short_descr': [u'en:ABCD43', u'ru:АБВГ43'],
            u'spec_offer_comm': [u'en:ABCD44', u'ru:АБВГ44'],
            u'weight': 3,
            u'new_until': '2016-11-01'
        }
    ]
    _to_replace = [
        {
            u'partner_id': 103,
            u'status': u'U',
            u'names': [u'en:DEF1', u'ru:ГДЕ1'],
            u'partner_description': [u'en:DEF1', u'ru:ГДЕ1'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 207, u'status': u'U', u'names': [u'en:ABC7']},
                                    {u'partner_category_id': 208, u'status': u'U', u'names': [u'en:ABC8']}],
            u'mile_get_comm': [u'en:ABCD51', u'ru:АБВГ51'],
            u'mile_waste_comm': [u'en:ABCD52', u'ru:АБВГ52'],
            u'short_descr': [u'en:ABCD53', u'ru:АБВГ53'],
            u'spec_offer_comm': [u'en:ABCD54', u'ru:АБВГ54'],
            u'weight': 3,
            u'new_until': '2016-11-01'
        },
        {
            u'partner_id': 104,
            u'status': u'U',
            u'names': [u'en:DEF2', u'ru:ГДЕ2'],
            u'partner_description': [u'en:DEF2', u'ru:ГДЕ2'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 209, u'status': u'U', u'names': [u'en:ABC9']},
                                    {u'partner_category_id': 210, u'status': u'U', u'names': [u'en:ABC10']}],
            u'mile_get_comm': [u'en:ABCD61', u'ru:АБВГ61'],
            u'mile_waste_comm': [u'en:ABCD62', u'ru:АБВГ62'],
            u'short_descr': [u'en:ABCD63', u'ru:АБВГ63'],
            u'spec_offer_comm': [u'en:ABCD64', u'ru:АБВГ64'],
            u'weight': 4,
            u'new_until': '2015-03-04'
        }
    ]
    _to_delete = [
        {
            u'partner_id': 104,
            u'status': u'U',
            u'names': [u'en:DEF2', u'ru:ГДЕ2'],
            u'partner_description': [u'en:DEF2', u'ru:ГДЕ2'],
            u'url': [u'en:http://some.ru'],
            u'mile_action': u'A',
            u'partner_categories': [{u'partner_category_id': 209, u'status': u'U', u'names': [u'en:ABC9']},
                                    {u'partner_category_id': 210, u'status': u'U', u'names': [u'en:ABC10']}],
            u'mile_get_comm': [u'en:ABCD61', u'ru:АБВГ61'],
            u'mile_waste_comm': [u'en:ABCD62', u'ru:АБВГ62'],
            u'short_descr': [u'en:ABCD63', u'ru:АБВГ63'],
            u'spec_offer_comm': [u'en:ABCD64', u'ru:АБВГ64'],
            u'weight': 4,
            u'new_until': '2015-03-04'
        }
    ]

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key == 'partner_categories':
            vocab_partner_categories = vocab_obj.partner_categories
            dict_partner_categories = dict_obj[key]

            self.assertEqual(
                len(vocab_partner_categories),
                len(dict_partner_categories))
        else:
            super(TestNotifyServiceProcessPartner, self)._compare_attr(
                key, attr, dict_obj, vocab_obj)

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessPartner, self)._registerVocabularies()
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer), 'special_offers_by_partner_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.partner.PartnerAwardConditionsByPartnerIndexer),
                                  'partner_awards_conditions_by_partner_idx')


class TestNotifyServiceProcessPartnerOffice(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.partner.PartnerOfficesVocabulary
    _class_name = u'PartnerOffice'
    _to_add = [
        {
            u'partner_office_id': 101,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:АБВ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:АБВ'],
            u'address': [u'ru:АБВ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 201,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                },
                {
                    u'partner_office_contact_id': 202,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': False,
                    u'contact_type': u'P'
                }
            ]
        },
        {
            u'partner_office_id': 102,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:ГДЕ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:ГДЕ'],
            u'address': [u'ru:ГДЕ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 203,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                },
                {
                    u'partner_office_contact_id': 204,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': False,
                    u'contact_type': u'P'
                }
            ]
        }
    ]
    _to_change = [
        {
            u'partner_office_id': 101,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:ГДЕ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:ГДЕ'],
            u'address': [u'ru:ГДЕ'],
            u'contacts': []
        }
    ]
    _to_change_pk = [
        {
            u'partner_office_id': 103,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:ГДЕ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:ГДЕ'],
            u'address': [u'ru:ГДЕ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 206,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                }
            ]
        }
    ]

    _to_replace = [
        {
            u'partner_office_id': 103,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:ГДЕ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:ГДЕ'],
            u'address': [u'ru:ГДЕ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 207,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                },
                {
                    u'partner_office_contact_id': 208,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': False,
                    u'contact_type': u'P'
                }
            ]
        },
        {
            u'partner_office_id': 104,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:ЖЗИ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:ЖЗИ'],
            u'address': [u'ru:ЖЗИ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 209,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                },
                {
                    u'partner_office_contact_id': 210,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': False,
                    u'contact_type': u'P'
                }
            ]
        }
    ]
    _to_delete = [
        {
            u'partner_office_id': 104,
            u'partner': u'301',
            u'city': u'401',
            u'office_type': u'O',
            u'worktime': [u'ru:ЖЗИ'],
            u'lon': 11.11,
            u'lat': 22.22,
            u'comments': [u'ru:ЖЗИ'],
            u'address': [u'ru:ЖЗИ'],
            u'contacts': [
                {
                    u'partner_office_contact_id': 209,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': True,
                    u'contact_type': u'P'
                },
                {
                    u'partner_office_contact_id': 210,
                    u'contact': u'+7 909 123 45 67',
                    u'main_contact': False,
                    u'contact_type': u'P'
                }
            ]
        }
    ]

    def _token_from_dict(self, d):
        return str(d['partner_office_id'])

    def _registerVocabularies(self):
        models.partner.PartnerOfficeContactsVocabulary.register()
        super(TestNotifyServiceProcessPartnerOffice, self)._registerVocabularies()

    def _unregisterVocabularies(self):
        unregisterVocabulary(models.partner.PartnerOfficeContactsVocabulary.regName)
        super(TestNotifyServiceProcessPartnerOffice, self)._unregisterVocabularies()

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key == 'contacts':
            vocab_contacts = vocab_obj.contacts
            dict_contacts = dict_obj[key]
            self.assertEqual(
                len(vocab_contacts),
                len(dict_contacts))
        else:
            if key in ('partner', 'city'):
                dict_obj[key] = int(dict_obj[key])

            super(TestNotifyServiceProcessPartnerOffice, self)._compare_attr(
                key, attr, dict_obj, vocab_obj)

    def _additional_test_add(self):
        vocab = getV(models.partner.PartnerOfficeContactsVocabulary.regName)
        self.assertEqual(len(vocab), 4)
        self.assertEqual(set(c.partner_office_contact_id for c in vocab), {201, 202, 203, 204})

    def _additional_test_change(self):
        vocab = getV(models.partner.PartnerOfficeContactsVocabulary.regName)
        self.assertEqual(len(vocab), 2)
        self.assertEqual(set(c.partner_office_contact_id for c in vocab), {203, 204})

    def _additional_test_change_pk(self):
        vocab = getV(models.partner.PartnerOfficeContactsVocabulary.regName)
        self.assertEqual(len(vocab), 2)
        self.assertEqual(set(c.partner_office_contact_id for c in vocab), {203, 204})

    def _additional_test_replace_all(self):
        vocab = getV(models.partner.PartnerOfficeContactsVocabulary.regName)
        self.assertEqual(len(vocab), 4)
        self.assertEqual(set(c.partner_office_contact_id for c in vocab), {207, 208, 209, 210})

    def _additional_test_delete(self):
        vocab = getV(models.partner.PartnerOfficeContactsVocabulary.regName)
        self.assertEqual(len(vocab), 2)
        self.assertEqual(set(c.partner_office_contact_id for c in vocab), {207, 208})


class TestNotifyServiceProcessPartnerAwardCondition(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.partner.PartnerAwardConditionsVocabulary
    _class_name = u'PartnerAwardCondition'
    _token_from_dict = lambda s, d: str(d['partner_award_condition_id'])
    _to_add = [
        {
            u'partner_award_condition_id': 101,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 1,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: АБВ']
        },
        {
            u'partner_award_condition_id': 102,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 2,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: ГДЕ']
        }
    ]
    _to_change = [
        {
            u'partner_award_condition_id': 101,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 3,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: ГДЕ']
        }
    ]
    _to_change_pk = [
        {
            u'partner_award_condition_id': 103,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 4,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: ГДЕ']
        }
    ]
    _to_replace = [
        {
            u'partner_award_condition_id': 103,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 4,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: ГДЕ']
        },
        {
            u'partner_award_condition_id': 104,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 5,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: ЖЗИ']
        }
    ]
    _to_delete = [
        {
            u'partner_award_condition_id': 104,
            u'partner': u'301',
            u'status': u'P',
            u'weight': 1,
            u'miles': 5,
            u'award_condition_type': u'E',
            u'award_condition_description': [u'ru: ЖЗИ']
        }
    ]

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key == 'partner':
            dict_obj[key] = int(dict_obj[key])

        super(TestNotifyServiceProcessPartnerAwardCondition, self)._compare_attr(
            key, attr, dict_obj, vocab_obj)

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessPartnerAwardCondition, self)._registerVocabularies()
        registerVocabularyIndexer(VocabularyIndexerFactory(models.partner.PartnerAwardConditionsByPartnerIndexer),
                                  'partner_awards_conditions_by_partner_idx')


class TestNotifyServiceProcessTierLevel(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.TierLevelsVocabulary
    _class_name = 'TierLevel'
    _token_from_dict = lambda s, d: d['tier_level']
    _attrs_map = {}
    _to_add = [
        {
            'tier_level': u'101',
            'names': [u'en:ABC', u'ru:АБВ'],
            'miles': 1,
            'ordering': 1,
            'segments': 3
        },
        {
            'tier_level': u'102',
            'names': [u'en:DEF', u'ru:ГДЕ'],
            'miles': 2,
            'ordering': 2,
            'segments': 3
        }
    ]
    _to_change = [
        {
            'tier_level': u'101',
            'names': [u'en:ABC'],
            'miles': 1,
            'ordering': 1,
            'segments': 2
        }
    ]
    _to_change_pk = [
        {
            'tier_level': u'103',
            'names': [u'en:ABC'],
            'miles': 3,
            'ordering': 1,
            'segments': 2
        }
    ]
    _to_replace = [
        {
            'tier_level': u'103',
            'names': [u'en:ABC', u'ru:АБВ'],
            'miles': 1,
            'ordering': 1,
            'segments': 2
        },
        {
            'tier_level': u'104',
            'names': [u'en:DEF', u'ru:ГДЕ'],
            'miles': 1,
            'ordering': 2,
            'segments': 2
        }
    ]
    _to_delete = [
        {
            'tier_level': u'103',
            'names': [u'en:ABC', u'ru:АБВ'],
            'miles': 1,
            'ordering': 1,
            'segments': 2
        }
    ]


class TestNotifyServiceProcessTierLevelFactor(
        _CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.bonus.TierLevelFactorsVocabulary
    _class_name = 'TierLevelFactor'
    _token_from_dict = lambda s, d: str(d['tier_level_factor_id'])
    _attrs_map = {
        'airline': 'airline_id'
    }
    _to_add = [
        {
            'tier_level_factor_id': 1,
            'tier_level': u'basic',
            'airline': u'1',
            'factor': 0.0,
        },
        {
            'tier_level_factor_id': 2,
            'tier_level': u'silver',
            'airline': u'1',
            'factor': 25.0,
        }
    ]
    _to_change = [
        {
            'tier_level_factor_id': 1,
            'tier_level': u'basic',
            'airline': u'1',
            'factor': 50.0,
        },
    ]
    _to_change_pk = [
        {
            'tier_level_factor_id': 3,
            'tier_level': u'basic',
            'airline': u'1',
            'factor': 0.0,
        },
    ]
    _to_replace = [
        {
            'tier_level_factor_id': 3,
            'tier_level': u'gold',
            'airline': u'1',
            'factor': 75.0,
        },
        {
            'tier_level_factor_id': 4,
            'tier_level': u'premiun',
            'airline': u'1',
            'factor': 100.0,
        }
    ]
    _to_delete = [
        {
            'tier_level_factor_id': 3,
            'tier_level': u'gold',
            'airline': u'1',
            'factor': 75.0,
        },
    ]

    def _compare_attr(self, key, attr, dict_obj, vocab_obj):
        if key == 'airline':
            dict_obj[key] = int(dict_obj[key])

        super(TestNotifyServiceProcessTierLevelFactor, self)._compare_attr(
            key, attr, dict_obj, vocab_obj)

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessTierLevelFactor, self)._registerVocabularies()
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer), 'tier_level_factors_by_airline_idx')


class TestNotifyServiceProcessSpecialOffer(_CommonNotifyServiceTest, testlib.TestCaseWithPgDBAndVocabs):
    _vocab = models.special_offer.SpecialOffersVocabulary
    _class_name = u'SpecialOffer'
    _token_from_dict = lambda s, d: str(d['offer_id'])
    _attrs_map = {}

    _to_add = [
        {
            'offer_id': -3,
            'partner': -1,
            'names': [u'en:ABC', u'ru:АБВ'],
            'status': u'P',
            'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            'offer_url': [u'ru:http://ya.ru'],
            'ui_languages': [u'en', u'ru']
        },
        {
            'offer_id': -4,
            'partner': -1,
            'names': [u'en:ABC', u'ru:АБВ'],
            'status': u'P',
            'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            'offer_url': [u'ru:http://ya.ru'],
            'ui_languages': [u'en', u'ru']
        }
    ]

    _to_change = [
        {
            'offer_id': -3,
            'partner': -1,
            'names': [u'en:ABC1', u'ru:АБВ1'],
            'status': u'P',
            'offer_description': [u'en:DEF1', u'ru:ГДЕ1'],
            'offer_url': [u'ru:http://ya.ru'],
            'ui_languages': [u'en', u'ru']
        }
    ]

    _to_change_pk = [
        {
            'offer_id': -5,
            'partner': -1,
            'names': [u'en:ABC', u'ru:АБВ'],
            'status': u'P',
            'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            'offer_url': [u'ru:http://ya.ru'],
            'ui_languages': [u'en', u'ru']
        }
    ]

    _to_replace = [
        {
            'offer_id': -5,
            'partner': -1,
            'names': [u'en:ABC', u'ru:АБВ'],
            'status': u'P',
            'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            'offer_url': [u'ru:http://ya.ru'],
            'ui_languages': [u'en', u'ru']
        },
        {
            'offer_id': -6,
            'partner': -1,
            'names': [u'en:ABC', u'ru:АБВ'],
            'status': u'U',
            'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            'offer_url': [u'ru:aeroflot.ru'],
            'ui_languages': [u'en', u'ru']
        }
    ]

    _to_delete = [
        {
            'offer_id': -6,
            'partner': -1,
            'names': [u'en:ABC', u'ru:АБВ'],
            'status': u'P',
            'offer_description': [u'en:DEF', u'ru:ГДЕ'],
            'offer_url': [u'ru:http://ya.ru'],
            'ui_languages': [u'en', u'ru']
        }
    ]

    def _registerVocabularies(self):
        super(TestNotifyServiceProcessSpecialOffer, self)._registerVocabularies()
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer), 'special_offers_by_partner_idx')


if __name__ == "__main__":
    testoob.main()
