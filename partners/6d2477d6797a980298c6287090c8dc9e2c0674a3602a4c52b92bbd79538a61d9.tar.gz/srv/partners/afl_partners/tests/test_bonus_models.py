# -*- coding: utf-8 -*-

"""
$Id: test_bonus_models.py 20999 2016-09-27 11:26:19Z oeremeeva $
"""


import testoob

from zope.schema.interfaces import ITokenizedTerm

from pyramid.i18n.message import Message
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.registry import registerVocabularyIndexer
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from rx.i18n.translation import SelfTranslationDomain
import pyramid.vocabulary.mvcc

import _test_data

import models.air
import models.bonus
import models.route
from _test_data import setup_vocabulary


class TestSkyTeamServiceClassModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestSkyTeamServiceClassModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        self.model = models.bonus.SkyTeamServiceClass

    def test_model(self):
        ob = self.model.load(skyteam_sc_id=-1)

        # ISkyTeamServiceClass
        self.assertEqual(-1, ob.skyteam_sc_id)
        self.assertEqual('yyy', ob.code)
        self.assertEqual(['ru:XXX', 'en:YYY'], ob.names)
        self.assertEqual(10, ob.weight)

        # ITitleCapable
        self.assertEqual('-1', ob.id)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestSkyTeamServiceClassI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.bonus.SkyTeamServiceClass.load(skyteam_sc_id=-3)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual(
            u'Business', SelfTranslationDomain().translate(
                ob.title.msgid
            )
        )

        self.negotiator.lang = 'ru'
        self.assertEqual(
            u'Бизнес', SelfTranslationDomain().translate(
                ob.title.msgid
            )
        )

class TestSkyTeamServiceClassesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestSkyTeamServiceClassesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)

    def testVocabulary(self):
        v = getV('skyteam_service_classes')
        self.assertTrue('-1' in v)
        self.assertFalse('-5' in v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.bonus.SkyTeamServiceClass))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.weight, 10)


class TestAirlineServiceClassModel(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineServiceClassModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer), 'service_classes_limits_by_airline_service_class_idx')
        self.model = models.bonus.AirlineServiceClass

    def test_model(self):
        ob = self.model.load(airline_sc_id=-2)

        # IAirlineServiceClass
        self.assertEqual(-2, ob.airline_sc_id)
        self.assertEqual(-1, ob.airline_id)
        self.assertEqual(-2, ob.skyteam_sc_id)

        self.assertTrue(isinstance(ob.skyteam_sc, models.bonus.SkyTeamServiceClass))

    def test_allowed_pairs(self):
        ob = self.model.load(airline_sc_id=-3)
        self.assertEqual(1, len(ob.allowed_pairs))
        self.assertTrue(isinstance(ob.allowed_pairs[0], models.route.Pair))
        self.assertEqual(-2, ob.allowed_pairs[0].pair_id)

        ob = self.model.load(airline_sc_id=-2)
        self.assertEqual(0, len(ob.allowed_pairs))

    def test_pair_allowed(self):
        ob = self.model.load(airline_sc_id=-3)

        self.assertTrue(ob.pair_allowed(-1, -4))
        self.assertTrue(ob.pair_allowed(-4, -1))
        self.assertFalse(ob.pair_allowed(-1, -3))

        ob = self.model.load(airline_sc_id=-2)
        self.assertTrue(ob.pair_allowed(-1, -4))
        self.assertTrue(ob.pair_allowed(-1, -3))


class TestAirlineServiceClassI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineServiceClassI18NSupport, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)

    def testModelTitles(self):
        ob = models.bonus.AirlineServiceClass.load(airline_sc_id=-2)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'BBB', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'AAA', SelfTranslationDomain().translate(ob.title.msgid))


class TestAirlineServiceClassesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineServiceClassesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)

    def testVocabulary(self):
        v = getV('airline_service_classes')

        self.assertTrue('-2' in v)
        self.assertFalse('-6' in v)

        ob = v['-2']
        self.assertTrue(isinstance(ob, models.bonus.AirlineServiceClass))
        self.assertEqual(-1, ob.airline_id)


class TestAirlineServiceClassesByAirlineIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineServiceClassesByAirlineIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')

    def test_add(self):
        vocab = getV('airline_service_classes')
        idx = getVI('airline_service_classes_by_airline_idx')

        airline1 = getV('airlines')["-1"]
        airline2 = getV('airlines')["-2"]

        self.assertEqual(len(idx(context=airline1)), 4)
        obs = [ob for ob in idx(context=airline1) if ob.skyteam_sc_id == -3]
        self.assertEqual(len(obs), 1)
        ob = obs[0]
        self.assertEqual(ob.airline_sc_id, -3)

        ob = models.bonus.AirlineServiceClass(
            airline_sc_id=-4,
            airline_id=-2,
            skyteam_sc_id=-4
        )

        vocab.update_many([ob])

        self.assertIn('-4', vocab)
        self.assertEqual(len(idx(context=airline2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=airline2)), 1)
        self.assertTrue(isinstance(idx(context=airline2)[0], models.bonus.AirlineServiceClass))
        self.assertEqual(idx(context=airline2)[0].airline_sc_id, -4)

    def test_change(self):
        vocab = getV('airline_service_classes')
        idx = getVI('airline_service_classes_by_airline_idx')

        airline1 = models.air.Airline.load(airline_id="-1")
        airline2 = models.air.Airline.load(airline_id="-2")

        self.assertEqual(len(idx(context=airline1)), 4)
        self.assertEqual(len(idx(context=airline2)), 0)

        ob = models.bonus.AirlineServiceClass(
            airline_sc_id=-3,
            airline_id=-2,
            skyteam_sc_id=-3
        )

        vocab.update_many([ob])

        self.assertEqual(len(idx(context=airline1)), 4)
        self.assertEqual(len(idx(context=airline2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=airline1)), 3)
        self.assertEqual(len(idx(context=airline2)), 1)
        self.assertEqual(idx(context=airline2)[0].airline_sc_id, -3)
        self.assertEqual(idx(context=airline2)[0].airline_id, -2)

    def test_delete(self):
        vocab = getV('airline_service_classes')
        idx = getVI('airline_service_classes_by_airline_idx')

        airline1 = models.air.Airline.load(airline_id="-1")
        self.assertEqual(len(idx(context=airline1)), 4)
        obs = [ob for ob in idx(context=airline1) if ob.airline_sc_id == -3]
        self.assertEqual(len(obs), 1)
        ob = obs[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-3', vocab)
        self.assertEqual(len(idx(context=airline1)), 4)

        idx._reindex()

        self.assertEqual(len(idx(context=airline1)), 3)


class TestServiceClassesLimitModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestServiceClassesLimitModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        self.model = models.bonus.ServiceClassesLimit

    def test_model(self):
        ob = self.model.load(service_classes_limit_id=-1)

        # IServiceClassesLimit
        self.assertEqual(-1, ob.service_classes_limit_id)
        self.assertEqual(-3, ob.airline_sc_id)
        self.assertEqual(-2, ob.pair_id)


class TestServiceClassesLimitsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestServiceClassesLimitsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)

    def testVocabulary(self):
        v = getV('service_classes_limits')

        self.assertTrue('-1' in v)
        self.assertFalse('-2' in v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.bonus.ServiceClassesLimit))
        self.assertTrue(-2, ob.pair_id)


class TestServiceClassesLimitsByAirlineServiceClassIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestServiceClassesLimitsByAirlineServiceClassIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer), 'service_classes_limits_by_airline_service_class_idx')

    def test_add(self):
        vocab = getV('service_classes_limits')
        idx = getVI('service_classes_limits_by_airline_service_class_idx')

        airline_sc = models.bonus.AirlineServiceClass.load(airline_sc_id=-3)

        self.assertEqual(len(idx(context=airline_sc)), 1)
        self.assertTrue(isinstance(idx(context=airline_sc)[0], models.bonus.ServiceClassesLimit))
        self.assertIn(-1, [ob.service_classes_limit_id for ob in idx(context=airline_sc)])
        self.assertNotIn(-100, [ob.service_classes_limit_id for ob in idx(context=airline_sc)])

        ob = models.bonus.ServiceClassesLimit(
            service_classes_limit_id=-100,
            airline_sc_id=-3,
            pair_id=-1
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=airline_sc)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=airline_sc)), 2)
        self.assertIn(-100, [ob.service_classes_limit_id for ob in idx(context=airline_sc)])

    def test_change(self):
        vocab = getV('service_classes_limits')
        idx = getVI('service_classes_limits_by_airline_service_class_idx')

        airline_sc = models.bonus.AirlineServiceClass.load(airline_sc_id=-3)

        self.assertEqual(len(idx(context=airline_sc)), 1)
        self.assertIn(-1, [ob.service_classes_limit_id for ob in idx(context=airline_sc)])

        ob = models.bonus.ServiceClassesLimit(
            service_classes_limit_id=-1,
            airline_sc_id=-3,
            pair_id=-1
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=airline_sc)), 1)
        self.assertIn(-2, [ob.pair_id for ob in idx(context=airline_sc)])
        self.assertNotIn(-1, [ob.pair_id for ob in idx(context=airline_sc)])

        idx._reindex()

        self.assertEqual(len(idx(context=airline_sc)), 1)
        self.assertIn(-1, [ob.pair_id for ob in idx(context=airline_sc)])
        self.assertNotIn(-2, [ob.pair_id for ob in idx(context=airline_sc)])

    def test_delete(self):
        vocab = getV('service_classes_limits')
        idx = getVI('service_classes_limits_by_airline_service_class_idx')

        airline_sc = models.bonus.AirlineServiceClass.load(airline_sc_id=-3)

        self.assertEqual(len(idx(context=airline_sc)), 1)

        ob = models.bonus.ServiceClassesLimit.load(service_classes_limit_id=-1)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=airline_sc)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=airline_sc)), 0)


class TestServiceClassesLimitsByAirlineIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestServiceClassesLimitsByAirlineIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineIndexer), 'service_classes_limits_by_airline_idx')

    def test_add(self):
        vocab = getV('service_classes_limits')
        idx = getVI('service_classes_limits_by_airline_idx')

        airline1 = getV('airlines')["-1"]
        airline2 = getV('airlines')["-3"]

        self.assertEqual(len(idx(context=airline1)), 1)
        ob = idx(context=airline1)[0]
        self.assertEqual(ob.airline_sc_id, -3)

        ob = models.bonus.ServiceClassesLimit(
            service_classes_limit_id=-2,
            airline_sc_id=-4,
            pair_id=-1
        )

        vocab.update_many([ob])

        self.assertIn('-2', vocab)
        self.assertEqual(len(idx(context=airline2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=airline2)), 1)
        self.assertTrue(isinstance(idx(context=airline2)[0], models.bonus.ServiceClassesLimit))
        self.assertEqual(idx(context=airline2)[0].airline_sc_id, -4)

    def test_change(self):
        vocab = getV('service_classes_limits')
        idx = getVI('service_classes_limits_by_airline_idx')

        airline1 = getV('airlines')["-1"]
        airline2 = getV('airlines')["-3"]

        self.assertEqual(len(idx(context=airline1)), 1)
        ob = idx(context=airline1)[0]
        self.assertEqual(ob.airline_sc_id, -3)

        ob = models.bonus.ServiceClassesLimit(
            service_classes_limit_id=-1,
            airline_sc_id=-4,
            pair_id=-1
        )

        vocab.update_many([ob])
        self.assertEqual(len(idx(context=airline1)), 1)
        self.assertEqual(len(idx(context=airline2)), 0)

        idx._reindex()
        self.assertEqual(len(idx(context=airline1)), 0)
        self.assertEqual(len(idx(context=airline2)), 1)
        ob = idx(context=airline2)[0]
        self.assertEqual(ob.airline_sc_id, -4)

    def test_delete(self):
        vocab = getV('service_classes_limits')
        idx = getVI('service_classes_limits_by_airline_idx')

        airline1 = getV('airlines')["-1"]

        ob = idx(context=airline1)[0]
        self.assertEqual(ob.airline_sc_id, -3)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=airline1)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=airline1)), 0)


class TestTariffGroupModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTariffGroupModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        self.model = models.bonus.TariffGroup

    def test_model(self):
        m = self.model.load(tariff_group_id=-2)
        self.assertEqual(m.skyteam_sc_id, -3)
        self.assertEqual(m.code, u"business-optimum")
        self.assertEqual(m.names,
            [u"en:Business-Optimum", u"ru:Бизнес-Оптимум"]
        )


class TestTariffGroupI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.bonus.TariffGroup.load(tariff_group_id=-2)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'Business-Optimum', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'Бизнес-Оптимум', SelfTranslationDomain().translate(ob.title.msgid))


class TestTariffGroupsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTariffGroupsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)

    def testVocabulary(self):
        v = getV('tariff_groups')

        self.assertIn('-1', v)
        self.assertNotIn('-100', v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.bonus.TariffGroup))
        self.assertEqual(ob.code, 'yyy-zzz')


class TestAirlineTariffGroupModel(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineTariffGroupModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        self.model = models.bonus.AirlineTariffGroup

    def test_model(self):
        ob = self.model.load(airline_tariff_group_id=-1)
        self.assertEqual(ob.tariff_group_id, -1)
        self.assertEqual(ob.airline_sc_id, -1)
        self.assertEqual(ob.charge_coef, 75)
        self.assertEqual(ob.weight, 10)

        self.assertTrue(isinstance(ob.tariff_group, models.bonus.TariffGroup))
        self.assertTrue(isinstance(ob.airline_sc, models.bonus.AirlineServiceClass))


class TestAirlineTariffGroupI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineTariffGroupI18NSupport, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)

    def testModelTitles(self):
        ob = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY-zzz', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'YYY-zzz-ru', SelfTranslationDomain().translate(ob.title.msgid))


class TestAirlineTariffGroupsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineTariffGroupsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)

    def testVocabulary(self):
        v = getV('airline_tariff_groups')

        self.assertIn('-1', v)
        self.assertNotIn('-100', v)

        ob = v['-1']
        self.assertTrue(
            isinstance(ob, models.bonus.AirlineTariffGroup)
        )
        self.assertEqual(ob.tariff_group_id, -1)


class TestAirlineTariffGroupsByAirlineServiceClassIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineTariffGroupsByAirlineServiceClassIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer),
                                  'airline_tariff_groups_by_airline_service_class_idx')

    def test_add(self):
        vocab = getV('airline_tariff_groups')
        idx = getVI('airline_tariff_groups_by_airline_service_class_idx')

        ctx = models.bonus.AirlineServiceClass.load(airline_sc_id=-3)

        self.assertEqual(len(idx(context=ctx)), 3)
        self.assertTrue(isinstance(idx(context=ctx)[0], models.bonus.AirlineTariffGroup))
        self.assertIn(-2, [ob.airline_tariff_group_id for ob in idx(context=ctx)])
        self.assertNotIn(-100, [ob.airline_tariff_group_id for ob in idx(context=ctx)])

        ob = models.bonus.AirlineTariffGroup(
            airline_tariff_group_id=-100,
            tariff_group_id=-3,
            airline_sc_id=-3,
            charge_coef=100,
            weight=10
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=ctx)), 3)

        idx._reindex()

        self.assertEqual(len(idx(context=ctx)), 4)
        self.assertIn(-100, [ob.airline_tariff_group_id for ob in idx(context=ctx)])

    def test_change(self):
        vocab = getV('airline_tariff_groups')
        idx = getVI('airline_tariff_groups_by_airline_service_class_idx')

        ctx = models.bonus.AirlineServiceClass.load(airline_sc_id=-3)

        self.assertEqual(len(idx(context=ctx)), 3)
        self.assertIn(-2, [ob.airline_tariff_group_id for ob in idx(context=ctx)])

        ob = models.bonus.AirlineTariffGroup(
            airline_tariff_group_id=-2,
            tariff_group_id=-3,
            airline_sc_id=-3,
            charge_coef=50,
            weight=10
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=ctx)), 3)
        self.assertIn(150, [ob.charge_coef for ob in idx(context=ctx)])
        self.assertNotIn(50, [ob.charge_coef for ob in idx(context=ctx)])

        idx._reindex()

        self.assertEqual(len(idx(context=ctx)), 3)
        self.assertIn(50, [ob.charge_coef for ob in idx(context=ctx)])
        self.assertNotIn(100, [ob.charge_coef for ob in idx(context=ctx)])


    def test_delete(self):
        vocab = getV('airline_tariff_groups')
        idx = getVI('airline_tariff_groups_by_airline_service_class_idx')

        ctx = models.bonus.AirlineServiceClass.load(airline_sc_id=-3)

        self.assertEqual(len(idx(context=ctx)), 3)

        ob = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-2)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-2', vocab)
        self.assertEqual(len(idx(context=ctx)), 3)

        idx._reindex()

        self.assertEqual(len(idx(context=ctx)), 2)


class TestBookingClassModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestBookingClassModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        self.model = models.bonus.BookingClass

    def test_model(self):
        ob = self.model.load(booking_class_id=-1)

        # IBookingClass
        self.assertEqual(-1, ob.booking_class_id)
        self.assertEqual('A', ob.code)
        self.assertEqual(True, ob.miles_are_charged)
        self.assertEqual(-1, ob.airline_tariff_group_id)
        self.assertEqual(['ru:ruA', 'en:enA'], ob.text_comment)

        # ITitleCapable
        self.assertEqual('-1', ob.id)
        self.assertEqual('A', ob.title)

    def test_airline_tariff_group(self):
        ob = self.model.load(booking_class_id=-1)

        atg = ob.airline_tariff_group
        self.assertTrue(isinstance(atg, models.bonus.AirlineTariffGroup))
        self.assertEqual(-1, atg.airline_tariff_group_id)


class TestBookingClassI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.bonus.BookingClass.load(booking_class_id=-1)
        self.assertTrue(isinstance(ob.comment, Message))

        self.assertEqual(u'enA', SelfTranslationDomain().translate(ob.comment.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'ruA', SelfTranslationDomain().translate(ob.comment.msgid))


class TestBookingClassesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestBookingClassesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.BookingClassesVocabulary)

    def testVocabulary(self):
        v = getV('booking_classes')

        self.assertIn('-1', v)
        self.assertNotIn('-2', v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.bonus.BookingClass))
        self.assertEqual(ob.code, 'A')


class TestBookingClassesByAirlineTariffGroupIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestBookingClassesByAirlineTariffGroupIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.BookingClassesByAirlineTariffGroupIndexer),
            'booking_classes_by_airline_tariff_group_idx')

    def test_add(self):
        vocab = getV('booking_classes')
        idx = getVI('booking_classes_by_airline_tariff_group_idx')

        atg1 = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)
        self.assertEqual(len(idx(context=atg1)), 1)

        ob = models.bonus.BookingClass(
            booking_class_id=-2,
            code='zzz-ppp',
            miles_are_charged=True,
            airline_tariff_group_id=-1
        )

        vocab.update_many([ob])

        self.assertEqual(len(idx(context=atg1)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=atg1)), 2)

    def test_change(self):
        vocab = getV('booking_classes')
        idx = getVI('booking_classes_by_airline_tariff_group_idx')

        atg1 = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)
        atg2 = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-3)
        self.assertEqual(len(idx(context=atg1)), 1)

        ob = models.bonus.BookingClass(
            booking_class_id=-1,
            code='yyy-zzz',
            miles_are_charged=True,
            airline_tariff_group_id=-3,
            text_comment=['ru:'])

        vocab.update_many([ob])

        self.assertEqual(len(idx(context=atg1)), 1)
        self.assertEqual(len(idx(context=atg2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=atg1)), 0)
        self.assertEqual(len(idx(context=atg2)), 1)
        self.assertEqual(idx(context=atg2)[0].code, 'yyy-zzz')

    def test_delete(self):
        vocab = getV('booking_classes')
        idx = getVI('booking_classes_by_airline_tariff_group_idx')

        atg1 = models.bonus.AirlineTariffGroup.load(airline_tariff_group_id=-1)

        ob = idx(context=atg1)[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=atg1)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=atg1)), 0)


class TestTierLevelModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTierLevelModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        self.model = models.bonus.TierLevel

    def test_model(self):
        ob = self.model.load(tier_level='xxx')

        # ITierLevel
        self.assertEqual('xxx', ob.tier_level)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertEqual(1, ob.ordering)
        self.assertEqual(1000, ob.miles)
        self.assertEqual(3, ob.segments)

        # ITitleCapable
        self.assertEqual('xxx', ob.id)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestTierLevelI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.bonus.TierLevel.load(tier_level='xxx')
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestTierLevelsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTierLevelsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TierLevelsVocabulary)

    def testVocabulary(self):
        v = getV('tier_levels')
        self.assertTrue('xxx' in v)
        self.assertFalse('yyy' in v)
        ob = v['xxx']
        self.assertTrue(isinstance(ob, models.bonus.TierLevel))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])


class TestTierLevelFactorModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTierLevelFactorModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        self.model = models.bonus.TierLevelFactor

    def test_model(self):
        ob = self.model.load(tier_level_factor_id=-1)

        # ITierLevelFactor
        self.assertEqual(-1, ob.airline_id)
        self.assertEqual('xxx', ob.tier_level)
        self.assertEqual(75, ob.factor)


class TestTierLevelFactorsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTierLevelFactorsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)

    def testVocabulary(self):
        v = getV('tier_level_factors')
        self.assertTrue('-1' in v)
        self.assertFalse('-100' in v)
        ob = v['-1']
        self.assertTrue(isinstance(ob, models.bonus.TierLevelFactor))
        self.assertEqual(ob.factor, 75)


class TestTierLevelFactorsByAirlineIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTierLevelFactorsByAirlineIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer),
                                  'tier_level_factors_by_airline_idx')

    def test_add(self):
        vocab = getV('tier_level_factors')
        idx = getVI('tier_level_factors_by_airline_idx')

        airline1 = models.air.Airline.load(airline_id=-1)
        airline2 = models.air.Airline.load(airline_id=-2)

        self.assertEqual(len(idx(context=airline1)), 2)
        self.assertTrue(isinstance(idx(context=airline1)[0], models.bonus.TierLevelFactor))
        self.assertIn(-1, [ob.tier_level_factor_id for ob in idx(context=airline1)])
        self.assertIn(-2, [ob.tier_level_factor_id for ob in idx(context=airline1)])
        self.assertNotIn(-3, [ob.tier_level_factor_id for ob in idx(context=airline1)])

        self.assertEqual(len(idx(context=airline2)), 0)

        ob = models.bonus.TierLevelFactor(
            tier_level_factor_id=-100,
            airline_id=-2,
            tier_level=u'xxx',
            factor=100,
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=airline2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=airline2)), 1)
        self.assertTrue(isinstance(idx(context=airline2)[0], models.bonus.TierLevelFactor))
        self.assertEqual(idx(context=airline2)[0].tier_level, u'xxx')

    def test_add(self):
        vocab = getV('tier_level_factors')
        idx = getVI('tier_level_factors_by_airline_idx')

        airline = models.air.Airline.load(airline_id=-1)

        self.assertEqual(len(idx(context=airline)), 2)
        self.assertTrue(isinstance(idx(context=airline)[0], models.bonus.TierLevelFactor))
        self.assertIn(-1, [ob.tier_level_factor_id for ob in idx(context=airline)])
        self.assertNotIn(-3, [ob.tier_level_factor_id for ob in idx(context=airline)])

        ob = models.bonus.TierLevelFactor(
            tier_level_factor_id=-100,
            airline_id=-1,
            tier_level=u'yyy',
            factor=100,
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=airline)), 2)

        idx._reindex()

        self.assertEqual(len(idx(context=airline)), 3)
        self.assertIn(-100, [ob.tier_level_factor_id for ob in idx(context=airline)])

    def test_change(self):
        vocab = getV('tier_level_factors')
        idx = getVI('tier_level_factors_by_airline_idx')

        airline = models.air.Airline.load(airline_id=-1)

        self.assertEqual(len(idx(context=airline)), 2)
        self.assertIn(75, [ob.factor for ob in idx(context=airline)])

        ob = models.bonus.TierLevelFactor(
            tier_level_factor_id=-1,
            airline_id=-1,
            tier_level=u'',
            factor=50,
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=airline)), 2)
        self.assertIn(75, [ob.factor for ob in idx(context=airline)])
        self.assertNotIn(50, [ob.factor for ob in idx(context=airline)])

        idx._reindex()

        self.assertEqual(len(idx(context=airline)), 2)
        self.assertIn(50, [ob.factor for ob in idx(context=airline)])
        self.assertNotIn(75, [ob.factor for ob in idx(context=airline)])

    def test_delete(self):
        vocab = getV('tier_level_factors')
        idx = getVI('tier_level_factors_by_airline_idx')

        airline = models.air.Airline.load(airline_id=-1)

        self.assertEqual(len(idx(context=airline)), 2)

        ob = ob = models.bonus.TierLevelFactor(tier_level_factor_id=-1)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=airline)), 2)

        idx._reindex()

        self.assertEqual(len(idx(context=airline)), 1)


class TestAirlineByIATAIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineByIATAIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.air.AirlinesByIATAIndexer
            ),
            'airlines_by_iata_idx'
        )

    def test_add(self):
        vocab = getV('airlines')
        idx = getVI('airlines_by_iata_idx')

        airline = "AH"

        self.assertEqual(len(idx(context=airline)), 0)
        ob = models.air.Airline(
            airline_id=-6,
            iata="AH",
            alliance="",
            names="en:Air Algerie|ru:Air Algerie",
            weight=0
        )

        vocab.update_many([ob])

        self.assertIn(-6, vocab)
        self.assertEqual(len(idx(context=airline)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=airline)), 1)
        self.assertTrue(
            isinstance(
                idx(context=airline)[0],
                models.air.Airline
            )
        )
        self.assertEqual(
            idx(context=airline)[0].iata,
            "AH"
        )

    def test_change(self):
        vocab = getV('airlines')
        idx = getVI('airlines_by_iata_idx')

        airline1 = "AY"
        airline2 = "AH"

        self.assertEqual(len(idx(context=airline1)), 1)
        self.assertEqual(len(idx(context=airline2)), 0)

        ob = models.air.Airline(
            airline_id=-2,
            iata=airline2
        )

        vocab.update_many([ob])

        self.assertEqual(len(idx(context=airline1)), 1)
        self.assertEqual(len(idx(context=airline2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=airline1)), 0)
        self.assertEqual(len(idx(context=airline2)), 1)
        self.assertEqual(idx(context=airline2)[0].airline_id, -2)
        self.assertEqual(idx(context=airline2)[0].iata, "AH")

    def test_delete(self):
        vocab = getV('airlines')
        idx = getVI('airlines_by_iata_idx')

        airline1 = "AY"
        self.assertEqual(len(idx(context=airline1)), 1)
        obs = [
            ob
            for ob in idx(context=airline1)
            if ob.iata == "AY"
        ]
        self.assertEqual(len(obs), 1)
        ob = obs[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-2', vocab)
        self.assertEqual(len(idx(context=airline1)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=airline1)), 0)


if __name__ == "__main__":
    testoob.main()
