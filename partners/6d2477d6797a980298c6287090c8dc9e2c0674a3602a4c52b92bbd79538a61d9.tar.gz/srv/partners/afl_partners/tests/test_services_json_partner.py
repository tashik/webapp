# -*- coding: utf-8 -*-

"""
$Id:
"""

import cherrypy
import json
import mock
import testoob

from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N, TestCaseWithRoutes
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from rx.i18n.translation import SelfTranslationDomain

import _test_data
import models.air
import models.partner
import models.geo
import models.special_offer
from _test_data import setup_vocabulary
from services.json_services.partner import AvailablePartnerCategoriesJSONService, CitiesByPartnerOfficesJSONService,\
                                           CountriesByPartnerOfficesJSONService, PartnerAndAwardsInfoJSONService, \
                                           PartnerSearchJSONService, PartnerOfficeSearchJSONService


def success_response_check(self, response):
    u"""Проверка заголовка JSON успешного ответа"""

    ob = json.loads(response)
    self.assertEqual(3, len(ob))
    self.assertTrue('isSuccess' in ob)
    self.assertTrue('data' in ob)
    self.assertTrue('errors' in ob)
    self.assertEqual(True, ob['isSuccess'])
    self.assertEqual([], ob['errors'])
    self.assertFalse(ob['data'] is None)
    return ob['data']


class TestAvailablePartnerCategoriesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestAvailablePartnerCategoriesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAvailablePartnerCategoriesService, self).tearDown()

    def registerVocabularies(self):
        super(TestAvailablePartnerCategoriesService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnerCategoriesVocabulary)
        setup_vocabulary(models.partner.PartnersVocabulary)

    def test_service(self):
        svc = AvailablePartnerCategoriesJSONService()
        cherrypy.request.current_lang = 'ru'
        response = svc.v001()

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        category = items[0]
        self.assertTrue(isinstance(category, dict), category.__class__)
        self.assertEqual(2, len(category))
        self.assertTrue('id' in category)
        self.assertTrue('title' in category)
        self.assertEqual(-1, category['id'])
        self.assertTrue(isinstance(category['title'], dict), category['title'].__class__)
        self.assertEqual(2, len(category['title']))
        self.assertTrue('en' in category['title'])
        self.assertTrue('ru' in category['title'])
        self.assertEqual('XXX', category['title']['ru'])
        self.assertEqual('YYY', category['title']['en'])

    def test_service_lang(self):
        svc = AvailablePartnerCategoriesJSONService()
        response = svc.v001(lang='en')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        category = items[0]
        self.assertEqual(2, len(category))
        self.assertEqual(-1, category['id'])
        self.assertEqual(1, len(category['title']))
        self.assertTrue('en' in category['title'])
        self.assertEqual('YYY', category['title']['en'])

    def test_service_langWrong(self):
        svc = AvailablePartnerCategoriesJSONService()
        response = svc.v001(lang='fr')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        category = items[0]
        self.assertEqual(2, len(category))
        self.assertEqual(-1, category['id'])
        self.assertEqual(2, len(category['title']))


class TestCitiesByPartnerOfficesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestCitiesByPartnerOfficesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCitiesByPartnerOfficesService, self).tearDown()

    def registerVocabularies(self):
        super(TestCitiesByPartnerOfficesService, self).registerVocabularies()
        setup_vocabulary(models.partner.PartnerCategoriesVocabulary)
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)

    def test_service(self):
        svc = CitiesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(country='XX')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        city = items[1]
        self.assertTrue(isinstance(city, dict), city.__class__)
        self.assertEqual(3, len(city))
        self.assertTrue('country_code' in city)
        self.assertTrue('title' in city)
        self.assertEqual(-1, city['id'])
        self.assertTrue(isinstance(city['title'], dict), city['title'].__class__)
        self.assertEqual(2, len(city['title']))
        self.assertTrue('en' in city['title'])
        self.assertTrue('ru' in city['title'])
        self.assertEqual('XXX', city['title']['ru'])
        self.assertEqual('YYY', city['title']['en'])

        response = svc.some_partners_v001(country='XX', partner_id='-2')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        city = items[1]
        self.assertTrue(isinstance(city, dict), city.__class__)
        self.assertEqual(3, len(city))
        self.assertTrue('country_code' in city)
        self.assertTrue('title' in city)
        self.assertEqual(-1, city['id'])
        self.assertTrue(isinstance(city['title'], dict), city['title'].__class__)
        self.assertEqual(2, len(city['title']))
        self.assertTrue('en' in city['title'])
        self.assertTrue('ru' in city['title'])
        self.assertEqual('XXX', city['title']['ru'])
        self.assertEqual('YYY', city['title']['en'])

    def test_country_not_define(self):
        svc = CitiesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(country='--')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(len(ob['data']), 3)

    def test_service_lang(self):
        svc = CitiesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(lang='en', country='XX')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        city = items[1]
        self.assertEqual(3, len(city))
        self.assertEqual(-1, city['id'])
        self.assertEqual(1, len(city['title']))
        self.assertTrue('en' in city['title'])
        self.assertEqual('YYY', city['title']['en'])

        response = svc.some_partners_v001(lang='en', country='XX', partner_id='-2')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        city = items[1]
        self.assertEqual(3, len(city))
        self.assertEqual(-1, city['id'])
        self.assertEqual(1, len(city['title']))
        self.assertTrue('en' in city['title'])
        self.assertEqual('YYY', city['title']['en'])

    def test_service_langWrong(self):
        svc = CitiesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(lang='fr', country='XX')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        city = items[1]
        self.assertEqual(3, len(city))
        self.assertEqual(-1, city['id'])
        self.assertEqual(2, len(city['title']))

    def test_service_excessiveParams(self):
        svc = CitiesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(param1='a', some_other='1234', country='XX')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        response = svc.some_partners_v001(param1='a', some_other='1234', country='XX', partner_id='-2')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

    def test_HTTPError_partner(self):
        svc = CitiesByPartnerOfficesJSONService()

        try:
            svc.some_partners_v001(country='XX', partner_id='-1')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(403,e.status)

        try:
            svc.some_partners_v001(country='XX', partner_id='100')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(404,e.status)

        try:
            svc.some_partners_v001(country='YX', partner_id='-10')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(404,e.status)

        try:
            svc.any_partners_v001(country='YX')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(404,e.status)


class TestCountriesByPartnerOfficesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestCountriesByPartnerOfficesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCountriesByPartnerOfficesService, self).tearDown()

    def registerVocabularies(self):
        super(TestCountriesByPartnerOfficesService, self).registerVocabularies()
        setup_vocabulary(models.partner.PartnerCategoriesVocabulary)
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)

    def test_service(self):
        svc = CountriesByPartnerOfficesJSONService()
        response = svc.any_partners_v001()

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        country = items[0]
        self.assertTrue(isinstance(country, dict), country.__class__)
        self.assertEqual(2, len(country))
        self.assertTrue('code' in country)
        self.assertTrue('title' in country)
        self.assertTrue(isinstance(country['title'], dict), country['title'].__class__)
        self.assertEqual(2, len(country['title']))
        self.assertTrue('en' in country['title'])
        self.assertTrue('ru' in country['title'])
        self.assertEqual('XXX', country['title']['ru'])
        self.assertEqual('YYY', country['title']['en'])

        response = svc.some_partners_v001(partner_id='-2')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(1, len(items))

        country = items[0]
        self.assertTrue(isinstance(country, dict), country.__class__)
        self.assertEqual(2, len(country))
        self.assertTrue('code' in country)
        self.assertTrue('title' in country)
        self.assertTrue(isinstance(country['title'], dict), country['title'].__class__)
        self.assertEqual(2, len(country['title']))
        self.assertTrue('en' in country['title'])
        self.assertTrue('ru' in country['title'])
        self.assertEqual('XXX', country['title']['ru'])
        self.assertEqual('YYY', country['title']['en'])

    def test_service_lang(self):
        svc = CountriesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(lang='en')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        country = items[0]
        self.assertEqual(2, len(country))
        self.assertEqual('XX', country['code'])
        self.assertEqual(1, len(country['title']))
        self.assertTrue('en' in country['title'])
        self.assertEqual('YYY', country['title']['en'])

        response = svc.some_partners_v001(lang='en', partner_id='-2')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(1, len(items))

        country = items[0]
        self.assertEqual(2, len(country))
        self.assertEqual('XX', country['code'])
        self.assertEqual(1, len(country['title']))
        self.assertTrue('en' in country['title'])
        self.assertEqual('YYY', country['title']['en'])

    def test_service_langWrong(self):
        svc = CountriesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(lang='fr')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertEqual(2, len(items))

        country = items[0]
        self.assertEqual(2, len(country))
        self.assertEqual(2, len(country['title']))

    def test_service_excessiveParams(self):
        svc = CountriesByPartnerOfficesJSONService()
        response = svc.any_partners_v001(param1='a', some_other='1234')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        response = svc.some_partners_v001(param1='a', some_other='1234', partner_id='-2')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(1, len(items))

    def test_HTTPError_partner(self):
        svc = CountriesByPartnerOfficesJSONService()

        try:
            svc.some_partners_v001(partner_id='-1')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(403,e.status)

        try:
            svc.some_partners_v001(partner_id='100')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(404,e.status)


class TestPartnerAndAwardsInfoService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerAndAwardsInfoService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestPartnerAndAwardsInfoService, self).tearDown()

    def registerVocabularies(self):
        super(TestPartnerAndAwardsInfoService, self).registerVocabularies()
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer), 'special_offers_by_partner_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.partner.PartnerAwardConditionsByPartnerIndexer),
                                  'partner_awards_conditions_by_partner_idx')

    def test_service(self):
        svc = PartnerAndAwardsInfoJSONService()
        response = svc.v001(partner='-2')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        partner = ob['data']
        self.assertTrue(isinstance(partner, dict), partner.__class__)
        self.assertEqual(14, len(partner))

        self.assertTrue('short_description' in partner)
        self.assertTrue('description' in partner)
        self.assertTrue('earn_text' in partner)
        self.assertTrue('spend_text' in partner)
        self.assertTrue('special_offers_text' in partner)
        self.assertTrue('id' in partner)
        self.assertTrue('url' in partner)
        self.assertTrue('categories' in partner)
        self.assertTrue('awards' in partner)
        self.assertTrue('title' in partner)
        self.assertTrue('special_offers' in partner)
        self.assertTrue('weight' in partner)
        self.assertTrue('mile_action' in partner)
        self.assertTrue('is_new' in partner)

        self.assertTrue(isinstance(partner['title'], dict), partner['title'].__class__)
        self.assertEqual(2, len(partner['title']))
        self.assertTrue('en' in partner['title'])
        self.assertTrue('ru' in partner['title'])
        self.assertEqual('XXX', partner['title']['ru'])
        self.assertEqual('YYY', partner['title']['en'])

        self.assertTrue(isinstance(partner['awards'], dict), partner['awards'].__class__)
        self.assertEqual(2, len(partner['awards']))
        self.assertTrue('accumulation' in partner['awards'])
        self.assertTrue('spending' in partner['awards'])

        self.assertTrue(isinstance(partner['awards']['accumulation'], list), partner['awards']['accumulation'].__class__)
        self.assertEqual(1, len(partner['awards']['accumulation']))
        award = partner['awards']['accumulation'][0]
        self.assertTrue(isinstance(award, dict), award.__class__)
        self.assertEqual(3, len(award))
        self.assertTrue('description' in award)
        self.assertTrue('weight' in award)
        self.assertTrue('miles' in award)
        self.assertTrue(isinstance(award['description'], dict), award['description'].__class__)
        self.assertEqual(2, len(award['description']))
        self.assertTrue('en' in award['description'])
        self.assertTrue('ru' in award['description'])
        self.assertEqual('<p>XXXXXX</p>', award['description']['ru'])
        self.assertEqual('<p>YYYYYY</p>', award['description']['en'])
        self.assertEqual(77, award['weight'])
        self.assertEqual(2.0, award['miles'])

        self.assertTrue(isinstance(partner['awards']['spending'], list), partner['awards']['spending'].__class__)
        self.assertEqual(1, len(partner['awards']['spending']))
        award = partner['awards']['spending'][0]
        self.assertTrue(isinstance(award, dict), award.__class__)
        self.assertEqual(3, len(award))
        self.assertTrue('description' in award)
        self.assertTrue('weight' in award)
        self.assertTrue('miles' in award)
        self.assertTrue(isinstance(award['description'], dict), award['description'].__class__)
        self.assertEqual(2, len(award['description']))
        self.assertTrue('en' in award['description'])
        self.assertTrue('ru' in award['description'])
        self.assertEqual('<p>XXXXXX</p>', award['description']['ru'])
        self.assertEqual('<p>YYYYYY</p>', award['description']['en'])
        self.assertEqual(77, award['weight'])
        self.assertEqual(1.0, award['miles'])

        special_offers = partner['special_offers']
        self.assertTrue(isinstance(special_offers, list), special_offers.__class__)
        self.assertEqual(1, len(special_offers))
        special_offer = special_offers[0]
        self.assertTrue('title' in special_offer)
        self.assertTrue('description' in special_offer)
        self.assertTrue('url' in special_offer)
        self.assertTrue('languages' in special_offer)
        self.assertTrue(isinstance(special_offer['title'], dict), special_offer['title'].__class__)
        self.assertTrue(isinstance(special_offer['description'], dict), special_offer['description'].__class__)
        self.assertTrue(isinstance(special_offer['url'], dict), special_offer['url'].__class__)
        self.assertEqual(2, len(special_offer['title']))
        self.assertEqual(2, len(special_offer['description']))
        self.assertEqual(2, len(special_offer['url']))
        self.assertEqual(['en', 'ru'], special_offer['languages'])

    def test_HTTPError_partner(self):
        svc = PartnerAndAwardsInfoJSONService()
        try:
            svc.v001(partner='-1')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(403,e.status)
        try:
            svc.v001(partner='100')
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(404,e.status)


    def test_service_lang(self):
        svc = PartnerAndAwardsInfoJSONService()
        response = svc.v001(lang='en', partner='-2')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        partner = ob['data']

        self.assertEqual(14, len(partner))
        self.assertEqual(1, len(partner['title']))
        self.assertTrue('en' in partner['title'])
        self.assertEqual('YYY', partner['title']['en'])

        self.assertEqual(1, len(partner['description']))
        self.assertTrue('en' in partner['description'])
        self.assertEqual('<p>YYYYYY</p>', partner['description']['en'])

        self.assertEqual(1, len(partner['short_description']))
        self.assertTrue('en' in partner['short_description'])
        self.assertEqual('YYY', partner['short_description']['en'])

        self.assertEqual(1, len(partner['earn_text']))
        self.assertTrue('en' in partner['earn_text'])
        self.assertEqual('YYY', partner['earn_text']['en'])

        self.assertEqual(1, len(partner['spend_text']))
        self.assertTrue('en' in partner['spend_text'])
        self.assertEqual('YYY', partner['spend_text']['en'])

        self.assertEqual(1, len(partner['special_offers_text']))
        self.assertTrue('en' in partner['special_offers_text'])
        self.assertEqual('YYY', partner['special_offers_text']['en'])

        award = partner['awards']['accumulation'][0]
        self.assertEqual(1, len(award['description']))
        self.assertTrue('en' in award['description'])
        self.assertEqual('<p>YYYYYY</p>', award['description']['en'])

        award = partner['awards']['spending'][0]
        self.assertEqual(1, len(award['description']))
        self.assertTrue('en' in award['description'])
        self.assertEqual('<p>YYYYYY</p>', award['description']['en'])

        special_offers = partner['special_offers'][0]
        self.assertEqual(1, len(special_offers['description']))
        self.assertTrue('en' in special_offers['description'])
        self.assertEqual('Super special offer description', special_offers['description']['en'])

    def test_service_langWrong(self):
        svc = PartnerAndAwardsInfoJSONService()
        response = svc.v001(lang='fr', partner='-2')

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        partner = ob['data']

        self.assertEqual(14, len(partner))
        self.assertEqual(2, len(partner['title']))

    def test_service_excessiveParams(self):
        svc = PartnerAndAwardsInfoJSONService()
        response = svc.v001(param1='a', some_other='1234', partner='-2')

        ob = json.loads(response)
        self.assertTrue(isinstance(ob, dict), ob.__class__)

        self.assertEqual(3, len(ob))
        self.assertTrue('isSuccess' in ob)
        self.assertTrue('data' in ob)
        self.assertTrue('errors' in ob)
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        items = ob['data']
        self.assertTrue(isinstance(items, dict), items.__class__)
        self.assertEqual(14, len(items))


class TestPartnerSearchService(TestCaseWithRoutes, TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):

        super(TestPartnerSearchService, self).setUp()
        self.mapper.connect('partner', '/partner/:id', controller=object())
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestPartnerSearchService, self).tearDown()

    def registerVocabularies(self):
        super(TestPartnerSearchService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)

    @mock.patch('config.PARTNERS_SVC_FILES_URL', 'http://localhost/fake_static')
    def test_service(self):
        svc = PartnerSearchJSONService()
        response = svc.v001()

        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)

        self.assertEqual(6, len(ob['data']['items']))

        response = svc.v001(name='YZ')
        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(2, len(ob['data']))

        response = svc.v001(city=-1)
        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(2, len(ob['data']))

        response = svc.v001(city=-1)
        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(2, len(ob['data']))

        response = svc.v001(country='ZZ')
        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(1, len(ob['data']['items']))

        response = svc.v001(city=-1, country='ZZ')
        ob = json.loads(response)
        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(1, len(ob['data']['items']))
        item = ob['data']['items'][0]
        self.assertEqual(item['id'], -4)
        self.assertTrue(isinstance(item['image'], dict), item['image'].__class__)
        self.assertEqual(2, len(item['image']))
        self.assertTrue('en' in item['image'])
        self.assertTrue('ru' in item['image'])
        self.assertEqual('http://localhost/fake_static/logo_int/-4.jpg', item['image']['en'])
        self.assertEqual('http://localhost/fake_static/logo_rus/-4.jpg', item['image']['ru'])
        self.assertTrue(isinstance(item['link'], dict), item['link'].__class__)
        self.assertEqual(2, len(item['link']))
        self.assertTrue('en' in item['link'])
        self.assertTrue('ru' in item['link'])
        self.assertEqual('http://some.url', item['link']['ru'])
        self.assertEqual('http://some.url', item['link']['en'])
        self.assertTrue(isinstance(item['name'], dict), item['name'].__class__)
        self.assertEqual(2, len(item['name']))
        self.assertTrue('en' in item['name'])
        self.assertTrue('ru' in item['name'])
        self.assertEqual('XXX', item['name']['ru'])
        self.assertTrue('en' in item['short_description'])
        self.assertTrue('ru' in item['short_description'])
        self.assertEqual(u'XXX', item['short_description']['ru'])
        self.assertEqual(u'YYY', item['short_description']['en'])
        self.assertEqual(u'2015-03-15', item['new_until'])

        cherrypy.request.current_lang = 'en'
        response = svc.v001(city=-1, country=u'ZZ', name=u'YYY')
        ob = json.loads(response)
        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(1, len(ob['data']['items']))
        item = ob['data']['items'][0]
        self.assertEqual(item['id'], -4)
        self.assertTrue(isinstance(item['image'], dict), item['image'].__class__)
        self.assertEqual(2, len(item['image']))
        self.assertTrue('en' in item['image'])
        self.assertTrue('ru' in item['image'])
        self.assertEqual('http://localhost/fake_static/logo_int/-4.jpg', item['image']['en'])
        self.assertEqual('http://localhost/fake_static/logo_rus/-4.jpg', item['image']['ru'])
        self.assertEqual(2, len(item['link']))
        self.assertTrue('en' in item['link'])
        self.assertTrue('ru' in item['link'])
        self.assertEqual('http://some.url', item['link']['ru'])
        self.assertEqual('http://some.url', item['link']['en'])
        self.assertTrue(isinstance(item['name'], dict), item['name'].__class__)
        self.assertEqual(2, len(item['name']))
        self.assertTrue('en' in item['name'])
        self.assertTrue('ru' in item['name'])
        self.assertEqual('XXX', item['name']['ru'])
        self.assertEqual('YYY', item['name']['en'])

        response = svc.v001(start=2)
        ob = json.loads(response)
        self.assertEqual(4, len(ob['data']['items']))

        response = svc.v001(start=5)
        ob = json.loads(response)
        self.assertEqual(1, len(ob['data']['items']))
        item = ob['data']['items'][0]

        self.assertEqual(item['id'], -7)
        self.assertTrue(isinstance(item['image'], dict), item['image'].__class__)
        self.assertEqual(2, len(item['image']))
        self.assertTrue('en' in item['image'])
        self.assertTrue('ru' in item['image'])
        self.assertEqual('http://localhost/fake_static/logo_int/-7.jpg', item['image']['en'])
        self.assertEqual('http://localhost/fake_static/logo_rus/-7.jpg', item['image']['ru'])
        self.assertEqual(2, len(item['link']))
        self.assertTrue('en' in item['link'])
        self.assertTrue('ru' in item['link'])
        self.assertEqual('http://some.url', item['link']['ru'])
        self.assertEqual('http://some.url', item['link']['en'])
        self.assertTrue(isinstance(item['name'], dict), item['name'].__class__)
        self.assertEqual(2, len(item['name']))
        self.assertTrue('en' in item['name'])
        self.assertTrue('ru' in item['name'])
        self.assertEqual('XXZ', item['name']['ru'])
        self.assertEqual('YYZ', item['name']['en'])

    def test_service2(self):
        svc = PartnerSearchJSONService()
        response = svc.v001()
        cherrypy.request.current_lang = 'ru'
        ob = json.loads(response)
        self.assertEqual(6, len(ob['data']['items']))

        response = svc.v001(start=10)
        ob = json.loads(response)
        self.assertTrue(ob['isSuccess'])
        self.assertEqual(0, len(ob['data']['items']))

    @mock.patch('config.PARTNERS_SVC_FILES_URL', 'http://localhost/fake_static')
    def test_service3(self):
        svc = PartnerSearchJSONService()
        response = svc.v001(lang='ru', name='XZ')
        ob = json.loads(response)

        self.assertEqual(3, len(ob))
        self.assertEqual(True, ob['isSuccess'])
        self.assertEqual([], ob['errors'])
        self.assertFalse(ob['data'] is None)
        self.assertEqual(2, len(ob['data']))

        item = ob['data']['items'][0]
        self.assertEqual(item['id'], -5)
        self.assertTrue(isinstance(item['image'], dict), item['image'].__class__)
        self.assertEqual(1, len(item['image']))
        self.assertTrue('en' not in item['image'])
        self.assertTrue('ru' in item['image'])
        self.assertEqual('http://localhost/fake_static/logo_rus/-5.jpg', item['image']['ru'])
        self.assertTrue(isinstance(item['link'], dict), item['link'].__class__)
        self.assertEqual(1, len(item['link']))
        self.assertTrue('en' not in item['link'])
        self.assertTrue('ru' in item['link'])
        self.assertEqual('http://some.url', item['link']['ru'])
        self.assertTrue(isinstance(item['name'], dict), item['name'].__class__)
        self.assertEqual(1, len(item['name']))
        self.assertTrue('en' not in item['name'])
        self.assertTrue('ru' in item['name'])
        self.assertEqual('XXZ', item['name']['ru'])
        self.assertTrue('en' not in item['short_description'])
        self.assertTrue('ru' in item['short_description'])
        self.assertEqual(u'XXX', item['short_description']['ru'])
        self.assertEqual(u'2015-03-16', item['new_until'])

    @mock.patch('config.PARTNERS_SERVICE_STEP', 2)
    def test_service_search_limit(self):
        svc = PartnerSearchJSONService()
        response = svc.v001()
        ob = json.loads(response)

        self.assertEqual(2, len(ob['data']['items']))
        self.assertEqual(2, ob['data']['paginator']['step'])
        self.assertEqual(6, ob['data']['paginator']['total'])

        svc = PartnerSearchJSONService()
        response = svc.v001(limit=3)
        ob = json.loads(response)

        self.assertEqual(3, len(ob['data']['items']))
        self.assertEqual(3, ob['data']['paginator']['step'])
        self.assertEqual(6, ob['data']['paginator']['total'])


class TestPartnerOfficeSearchService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):

        super(TestPartnerOfficeSearchService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestPartnerOfficeSearchService, self).tearDown()

    def registerVocabularies(self):
        super(TestPartnerOfficeSearchService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.partner.PartnerOfficeContactsVocabulary)

    def test_search(self):
        svc = PartnerOfficeSearchJSONService()
        response = svc.v001(partner_id=-4)
        items = success_response_check(self, response)
        self.assertEqual(len(items['items']), 3)

        response = svc.v001(partner_id=-4, city=-3)
        items = success_response_check(self, response)
        self.assertEqual(len(items['items']), 2)

        response = svc.v001(partner_id=-4, city=-3, country=u'ZZ')
        items = success_response_check(self, response)
        self.assertEqual(len(items['items']), 2)

        response = svc.v001(partner_id=-4, city=-3, country=u'XX')
        items = success_response_check(self, response)
        self.assertEqual(len(items['items']), 0)

        response = svc.v001(partner_id=-4, country=u'XX')
        items = success_response_check(self, response)
        self.assertEqual(len(items['items']), 1)

    @mock.patch('config.PARTNERS_OFFICE_CONTACTS_SERVICE_STEP', 2)
    def test_service_search_limit(self):
        svc = PartnerOfficeSearchJSONService()
        response = svc.v001(partner_id=-4)
        ob = json.loads(response)

        self.assertEqual(2, len(ob['data']['items']))
        self.assertEqual(2, ob['data']['paginator']['step'])
        self.assertEqual(3, ob['data']['paginator']['total'])

        svc = PartnerOfficeSearchJSONService()
        response = svc.v001(partner_id=-4, limit=1)
        ob = json.loads(response)

        self.assertEqual(1, len(ob['data']['items']))
        self.assertEqual(1, ob['data']['paginator']['step'])
        self.assertEqual(3, ob['data']['paginator']['total'])

    def test_model(self):
        svc = PartnerOfficeSearchJSONService()
        response = svc.v001(partner_id=-4, city=-1)
        items = success_response_check(self, response)
        self.assertEqual(len(items['items']), 1)
        item = items['items'][0]
        self.assertEqual(len(item), 10)
        self.assertEqual(item['id'], -5)
        self.assertEqual(item['lat'], 77.77)
        self.assertEqual(item['lon'], 77.77)
        self.assertEqual(item['worktime']['ru'], u'XXX')
        self.assertEqual(item['worktime']['en'], u'YYY')
        self.assertEqual(item['comments']['ru'], u'XXX')
        self.assertEqual(item['comments']['en'], u'YYY')
        self.assertEqual(item['city']['ru'], u'XXX')
        self.assertEqual(item['city']['en'], u'YYY')
        self.assertEqual(item['country']['ru'], u'XXX')
        self.assertEqual(item['country']['en'], u'YYY')
        self.assertEqual(item['address']['ru'], u'XXX')
        self.assertEqual(item['address']['en'], u'YYY')

        self.assertEqual(len(item['contacts']), 1)
        contact = item[u'contacts'][0]
        self.assertEqual(contact['contact'], u'some@some.ru')
        self.assertEqual(contact['contact_type'], u'E')
        self.assertEqual(contact['main_contact'], False)

    @mock.patch('config.PARTNERS_OFFICE_CONTACTS_SERVICE_STEP', 2)
    def test_paginator(self):
        svc = PartnerOfficeSearchJSONService()
        response = svc.v001(partner_id=-4)
        items = success_response_check(self, response)
        self.assertEqual(len(items), 2)
        self.assertEqual(len(items['paginator']), 3)
        paginator = items['paginator']
        self.assertEqual(paginator['total'], 3)
        self.assertEqual(paginator['start'], 0)
        self.assertEqual(paginator['step'], 2)

        response = svc.v001(partner_id=-4, start=1)
        items = success_response_check(self, response)
        self.assertEqual(items['paginator']['start'], 1)

#    def test_error(self):
#        svc = PartnerOfficeSearchJSONService()
#        response = svc.v001(partner_id=-4, start=10)
#        ob = json.loads(response)
#        self.assertFalse(ob['isSuccess'])
#        self.assertEqual(len(ob['errors']), 1)
#        error = ob['errors'][0]
#        self.assertEqual(error['code'], 412)
#        self.assertEqual(error['message'], u'Out of range. start=10, must be in [0, 3]')

    def test_HTTPError_partner(self):
        svc = PartnerOfficeSearchJSONService()

        try:
            svc.v001(partner_id=-100)
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(404, e.status)

        try:
            svc.v001(partner_id=-1)
        except Exception,e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError),e.__class__)
            self.assertEquals(403, e.status)


if __name__ == "__main__":
    testoob.main()
