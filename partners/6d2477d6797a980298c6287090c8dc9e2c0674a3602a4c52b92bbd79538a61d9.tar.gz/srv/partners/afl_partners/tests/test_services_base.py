# -*- coding: utf-8 -*-

"""
$Id: test_services_base.py 10075 2014-12-18 14:56:34Z isoloduha $
"""
import testoob
import unittest

from services.base.converter import camelcase_to_underscores


class TestConverter(unittest.TestCase):
    def test_camel_to_underscores(self):
        self.assertEqual(camelcase_to_underscores("mySmallCamel"), "my_small_camel")
        self.assertEqual(camelcase_to_underscores("MySmallCamel"), "my_small_camel")
        self.assertEqual(camelcase_to_underscores("Camel"), "camel")
        self.assertEqual(camelcase_to_underscores("Ca7mel"), "ca7mel")
        self.assertEqual(camelcase_to_underscores("camel"), "camel")

if __name__ == "__main__":
    testoob.main()
