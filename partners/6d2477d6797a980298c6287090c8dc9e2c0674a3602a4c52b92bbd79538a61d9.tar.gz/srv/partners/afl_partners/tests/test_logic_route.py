# -*- coding: utf-8 -*-

"""
$Id:
"""

import testoob
import unittest

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary

import logic.route
import models.geo
import models.route


class TestLogicRoute(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def registerVocabularies(self):
        super(TestLogicRoute, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    def test_available_pairs(self):
        # все авиакомпании, все типы поиска
        pairs = logic.route.available_pairs()
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertTrue((-10, -11) in pairs)
        self.assertTrue((-10, -6) in pairs)
        self.assertEqual(len(pairs), 9)

        # авиакомпания, все типы поиска
        pairs = logic.route.available_pairs(airline_id=-1)
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertFalse((-10, -11) in pairs)
        self.assertFalse((-10, -6) in pairs)
        self.assertEqual(len(pairs), 7)

        pairs = logic.route.available_pairs(airline_id=-2)
        self.assertEqual(pairs, [])

        # все авиакомпании, тип поиска
        pairs = logic.route.available_pairs(search_type=logic.route.TYPE_EARN)
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertTrue((-10, -11) in pairs)
        self.assertTrue((-10, -6) in pairs)
        self.assertEqual(len(pairs), 9)

        pairs = logic.route.available_pairs(search_type=logic.route.TYPE_SPEND)
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertTrue((-10, -11) in pairs)
        self.assertFalse((-10, -6) in pairs)
        self.assertEqual(len(pairs), 8)

        # авиакомпания, тип поиска
        pairs = logic.route.available_pairs(airline_id=-1, search_type=logic.route.TYPE_EARN)
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertFalse((-10, -11) in pairs)
        self.assertFalse((-10, -6) in pairs)
        self.assertEqual(len(pairs), 7)

        pairs = logic.route.available_pairs(airline_id=-1, search_type=logic.route.TYPE_SPEND)
        self.assertFalse((-1, -3) in pairs)
        self.assertFalse((-1, -4) in pairs)
        self.assertFalse((-10, -11) in pairs)
        self.assertFalse((-10, -6) in pairs)
        self.assertEqual(len(pairs), 5)

        pairs = logic.route.available_pairs(airline_id=-3, search_type=logic.route.TYPE_EARN)
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertTrue((-10, -11) in pairs)
        self.assertTrue((-10, -6) in pairs)
        self.assertEqual(len(pairs), 4)

        pairs = logic.route.available_pairs(airline_id=-3, search_type=logic.route.TYPE_SPEND)
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertTrue((-10, -11) in pairs)
        self.assertFalse((-10, -6) in pairs)
        self.assertEqual(len(pairs), 3)

    def test_available_airports(self):
        airports = logic.route.available_airports(-1)
        self.assertEqual(set(airports), set([-2, -5, -3, -4, -7, -6, -1]))
        self.assertEqual([], logic.route.available_airports(-2))

    def test_all_available_pairs(self):
        pairs = logic.route.all_available_pairs()
        self.assertTrue((-1, -3) in pairs)
        self.assertTrue((-1, -4) in pairs)
        self.assertTrue((-10, -11) in pairs)
        self.assertTrue((-10, -6) in pairs)
        self.assertEqual(len(pairs), 9)

    def test_all_available_airports(self):
        airports = logic.route.all_available_airports()
        self.assertEqual(set(airports), set([-2, -10, -7, -6, -5, -4, -3, -1, -11]))

    def test_airports_by_iata(self):
        airports = logic.route.airports_by_iata('XXX')
        self.assertEqual(len(airports), 1)
        self.assertIn(-1, airports)

        airports = logic.route.airports_by_iata('AAA')
        self.assertEqual(len(airports), 0)

        airports = logic.route.airports_by_iata('UUX')
        self.assertEqual(len(airports), 3)
        self.assertIn(-3, airports)
        self.assertIn(-7, airports)
        self.assertIn(-8, airports)

        available = [-2, -5, -3, -4, -7, -6, -1]
        airports = logic.route.airports_by_iata('UUX', available)
        self.assertEqual(len(airports), 2)
        self.assertIn(-3, airports)
        self.assertIn(-7, airports)
        self.assertNotIn(-8, airports)

    def test_is_pair_international(self):
        ob = models.route.Pair.load(pair_id=-1)
        self.assertFalse(logic.route.is_pair_international(ob))

        ob = models.route.Pair.load(pair_id=-9)
        self.assertTrue(logic.route.is_pair_international(ob))

    def test_available_routes(self):
        # [('XX1',)]
        args = ({'XX1'}, )
        self.assertIn(('XX1',), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 1)

        # [('XX1',), ('XX2',)]
        args = ({'XX1', 'XX2'}, )
        self.assertIn(('XX1',), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX2',), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 2)

        # [('XX1',), ('XX2',), ('XX3',)]
        args = ({'XX1', 'XX2', 'XX3'}, )
        self.assertIn(('XX1',), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX2',), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX3',), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 3)

        # [('XX1', 'YY1')]
        args = ({'XX1'}, {'YY1'}, )
        self.assertIn(('XX1', 'YY1'), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 1)

        # [('XX1', None)]
        args = ({'XX1'}, {}, )
        self.assertIn(('XX1', None), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 1)

        # [('XX1', 'YY1', 'ZZ1')]
        args = ({'XX1'}, {'YY1'}, {'ZZ1'})
        self.assertIn(('XX1', 'YY1', 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 1)

        # [('XX2', 'YY1', 'ZZ1'), ('XX1', 'YY1', 'ZZ1')]
        args = ({'XX1', 'XX2'}, {'YY1'}, {'ZZ1'})
        self.assertIn(('XX2', 'YY1', 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX1', 'YY1', 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 2)

        # [('XX2', 'YY1', 'ZZ2'), ('XX2', 'YY1', 'ZZ1'), ('XX1', 'YY1', 'ZZ2'), ('XX1', 'YY1', 'ZZ1')]
        args = ({'XX1', 'XX2'}, {'YY1'}, {'ZZ1', 'ZZ2'})
        self.assertIn(('XX2', 'YY1', 'ZZ2'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX2', 'YY1', 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX1', 'YY1', 'ZZ2'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX1', 'YY1', 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 4)

        # [('XX2', None, 'ZZ2'), ('XX2', None, 'ZZ1'), ('XX1', None, 'ZZ2'), ('XX1', None, 'ZZ1')]
        args = ({'XX1', 'XX2'}, {}, {'ZZ1', 'ZZ2'})
        self.assertIn(('XX2', None, 'ZZ2'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX2', None, 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX1', None, 'ZZ2'), [x for x in logic.route.available_routes(*args)])
        self.assertIn(('XX1', None, 'ZZ1'), [x for x in logic.route.available_routes(*args)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args)]), 4)

    def test_available_routes_airline_limit(self):
        kwargs = {'airline_id': -1}

        # []
        args = ({'XX1'}, )
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 0)

        # []
        args = ({-1}, )
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 0)

        # [(-1, -3)]
        args = ({-1}, {-3})
        self.assertIn((-1, -3), [x for x in logic.route.available_routes(*args, **kwargs)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 1)

        # []
        args = ({-1}, {-100})
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 0)

        # [(-1, -4, -3)]
        args = ({-1}, {-4}, {-3})
        self.assertIn((-1, -4, -3), [x for x in logic.route.available_routes(*args, **kwargs)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 1)

        # [(-1, -4, -3), (-2, -4, -3)]
        args = ({-1, -2}, {-4}, {-3})
        self.assertIn((-1, -4, -3), [x for x in logic.route.available_routes(*args, **kwargs)])
        self.assertIn((-2, -4, -3), [x for x in logic.route.available_routes(*args, **kwargs)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 2)

        # [(-1, -4, -3), (-2, -4, -3)]
        args = ({-1, -2}, {-4}, {-3, -6})
        self.assertIn((-1, -4, -3), [x for x in logic.route.available_routes(*args, **kwargs)])
        self.assertIn((-2, -4, -3), [x for x in logic.route.available_routes(*args, **kwargs)])
        self.assertEqual(len([x for x in logic.route.available_routes(*args, **kwargs)]), 2)

    def test_route_to_segments(self):
        # []
        args = ('XXX',)
        self.assertEqual(len([x for x in logic.route.route_to_segments(*args)]), 0)

        # [('XXX', 'YYY')]
        args = ('XXX', 'YYY')
        self.assertIn(('XXX', 'YYY'), [x for x in logic.route.route_to_segments(*args)])
        self.assertEqual(len([x for x in logic.route.route_to_segments(*args)]), 1)

        # [('XXX', 'YYY'), ('YYY', 'ZZZ')]
        args = ('XXX', 'YYY', 'ZZZ')
        self.assertIn(('XXX', 'YYY'), [x for x in logic.route.route_to_segments(*args)])
        self.assertIn(('YYY', 'ZZZ'), [x for x in logic.route.route_to_segments(*args)])
        self.assertEqual(len([x for x in logic.route.route_to_segments(*args)]), 2)

        # []
        args = ('XXX', None)
        self.assertEqual(len([x for x in logic.route.route_to_segments(*args)]), 0)

        # [('XXX', 'ZZZ')]
        args = ('XXX', None, 'ZZZ')
        self.assertIn(('XXX', 'ZZZ'), [x for x in logic.route.route_to_segments(*args)])
        self.assertEqual(len([x for x in logic.route.route_to_segments(*args)]), 1)


class TestRouteSolver(unittest.TestCase):
    def setUp(self):
        self.rs =logic.route.RouteSolver(_test_data.ROUTES)

    def test_locations(self):
        result = self.rs.get_locations()
        self.assertEqual(len(result), 13)

    def test_to_locations(self):
        result = self.rs.get_to_locations('SVO')
        self.assertEqual(len(result), 5)
        self.assertTrue('LED' in result)
        self.assertTrue('OSL' in result)
        self.assertTrue('PEK' in result)
        self.assertTrue('AMS' in result)
        self.assertTrue('ROV' in result)

        result = self.rs.get_to_locations('AMS')
        self.assertEqual(len(result), 5)
        self.assertTrue('SVO' in result)
        self.assertTrue('LED' in result)
        self.assertTrue('OSL' in result)
        self.assertTrue('ROV' in result)
        self.assertTrue('TAS' in result)

        result = self.rs.get_to_locations('ROV')
        self.assertEqual(len(result), 3)
        self.assertTrue('SVO' in result)
        self.assertTrue('AMS' in result)
        self.assertTrue('TAS' in result)

        result = self.rs.get_to_locations('TAS')
        self.assertEqual(len(result), 2)
        self.assertTrue('ROV' in result)
        self.assertTrue('AMS' in result)

        result = self.rs.get_to_locations('LED')
        self.assertEqual(len(result), 5)
        self.assertTrue('SVO' in result)
        self.assertTrue('OSL' in result)
        self.assertTrue('PEK' in result)
        self.assertTrue('AMS' in result)
        self.assertTrue('NRT' in result)

        result = self.rs.get_to_locations('OSL')
        self.assertEqual(len(result), 5)
        self.assertTrue('SVO' in result)
        self.assertTrue('LED' in result)
        self.assertTrue('PEK' in result)
        self.assertTrue('AMS' in result)
        self.assertTrue('NRT' in result)

        result = self.rs.get_to_locations('PEK')
        self.assertEqual(len(result), 4)
        self.assertTrue('SVO' in result)
        self.assertTrue('LED' in result)
        self.assertTrue('OSL' in result)
        self.assertTrue('NRT' in result)

        result = self.rs.get_to_locations('NRT')
        self.assertEqual(len(result), 3)
        self.assertTrue('LED' in result)
        self.assertTrue('PEK' in result)
        self.assertTrue('OSL' in result)

        result = self.rs.get_to_locations('UFA')
        self.assertEqual(len(result), 3)
        self.assertTrue('KUF' in result)
        self.assertTrue('TLV' in result)
        self.assertTrue('VIE' in result)

        result = self.rs.get_to_locations('TLV')
        self.assertEqual(len(result), 4)
        self.assertTrue('UFA' in result)
        self.assertTrue('VIE' in result)
        self.assertTrue('SOF' in result)
        self.assertTrue('KUF' in result)

        result = self.rs.get_to_locations('KUF')
        self.assertEqual(len(result), 4)
        self.assertTrue('UFA' in result)
        self.assertTrue('VIE' in result)
        self.assertTrue('SOF' in result)
        self.assertTrue('TLV' in result)

        result = self.rs.get_to_locations('SOF')
        self.assertEqual(len(result), 2)
        self.assertTrue('KUF' in result)
        self.assertTrue('TLV' in result)

    def test_to_locations2(self):
        result, direct, via = self.rs.get_to_locations2('SVO')
        self.assertTrue('LED' in result)
        self.assertTrue('OSL' in result)
        self.assertTrue('PEK' in result)
        self.assertTrue('AMS' in result)
        self.assertTrue('ROV' in result)

        self.assertTrue('LED' in direct)
        self.assertTrue('OSL' in direct)
        self.assertTrue('AMS' in direct)

        self.assertTrue('LED' in via)
        self.assertTrue('OSL' in via)
        self.assertTrue('PEK' in via)
        self.assertTrue('ROV' in via)

        result, direct, via = self.rs.get_to_locations2('PEK')
        self.assertTrue('SVO' in result)
        self.assertTrue('LED' in result)
        self.assertTrue('OSL' in result)
        self.assertTrue('NRT' in result)

        self.assertTrue('LED' in direct)
        self.assertTrue('OSL' in direct)
        self.assertTrue('NRT' in direct)

        self.assertTrue('SVO' in via)
        self.assertTrue('OSL' in via)
        self.assertTrue('LED' in via)

    def test_via_locations(self):
        result = self.rs.get_via_locations('AMS', 'OSL')
        self.assertEqual(len(result), 1)
        self.assertTrue('SVO' in result)

        result = self.rs.get_via_locations('SVO', 'PEK')
        self.assertEqual(len(result), 2)
        self.assertTrue('LED' in result)
        self.assertTrue('OSL' in result)

        result = self.rs.get_via_locations('SVO', 'NRT')
        self.assertEqual(len(result), 0)

    def test_check_direct_flight(self):
        result = self.rs.check_direct_flight('AMS', 'OSL')
        self.assertEqual(result, False)

        result = self.rs.check_direct_flight('AMS', 'SVO')
        self.assertEqual(result, True)


if __name__ == "__main__":
    testoob.main()
