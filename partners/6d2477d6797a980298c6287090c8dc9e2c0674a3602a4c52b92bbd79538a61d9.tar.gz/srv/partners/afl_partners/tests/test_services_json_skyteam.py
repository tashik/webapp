# -*- coding: utf-8 -*-

"""
$Id:
"""

import json
import testoob
import cherrypy

from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N

from rx.i18n.translation import SelfTranslationDomain

import _test_data
import models.air
import models.geo
from _test_data import setup_vocabulary
from services.json_services.airline import AirlinesJSONService
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.registry import registerVocabularyIndexer

def success_response_check(self, response):
    u"""Проверка заголовка JSON успешного ответа"""

    ob = json.loads(response)
    self.assertEqual(3, len(ob))
    self.assertTrue('isSuccess' in ob)
    self.assertTrue('data' in ob)
    self.assertTrue('errors' in ob)
    self.assertEqual(True, ob['isSuccess'])
    self.assertEqual([], ob['errors'])
    self.assertFalse(ob['data'] is None)
    return ob['data']


class TestSkyteamAirlinesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestSkyteamAirlinesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        cherrypy.request.current_lang = 'ru'

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestSkyteamAirlinesService, self).tearDown()

    def registerVocabularies(self):
        super(TestSkyteamAirlinesService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')

    def test_service_skyteam(self):
        svc = AirlinesJSONService()
        response = svc.skyteam_v001()

        items = success_response_check(self, response)
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        airline = items[0]
        self.assertEqual(airline['iata'], 'SU')
        self.assertEqual(airline['icao'], 'AFL')
        self.assertEqual(airline['country'], 'XX')
        self.assertEqual(airline['airport'], 'XXA')
        self.assertEqual('Aeroflot', airline['title']['en'])
        self.assertEqual(u'Аэрофлот', airline['title']['ru'])
        self.assertEqual(airline['url']['ru'], 'site.ru')
        self.assertEqual(airline['weight'], 1)


        response = svc.skyteam_v001(full="0")

        items = success_response_check(self, response)
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        response = svc.skyteam_v001(full="1")

        items = success_response_check(self, response)
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(4, len(items))
        self.assertEqual(1, len([item for item in items if item['id'] == -5]))
        airline = [item for item in items if item['id'] == -5][0]
        self.assertEqual(airline['iata'], 'VN')
        self.assertEqual('Vietnam Airlines', airline['title']['en'])
        self.assertEqual(airline['weight'], 1)

    def test_service_afl(self):
        svc = AirlinesJSONService()
        response = svc.afl_v001()

        items = success_response_check(self, response)
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        airline = items[0]
        self.assertEqual(airline['iata'], 'SU')
        self.assertEqual(airline['icao'], 'AFL')
        self.assertEqual(airline['country'], 'XX')
        self.assertEqual(airline['airport'], 'XXA')
        self.assertEqual('Aeroflot', airline['title']['en'])
        self.assertEqual(u'Аэрофлот', airline['title']['ru'])
        self.assertEqual(airline['url']['ru'], 'site.ru')
        self.assertEqual(airline['weight'], 1)

        airline = items[1]
        self.assertEqual(airline['iata'], u'VX')


if __name__ == "__main__":
    testoob.main()
