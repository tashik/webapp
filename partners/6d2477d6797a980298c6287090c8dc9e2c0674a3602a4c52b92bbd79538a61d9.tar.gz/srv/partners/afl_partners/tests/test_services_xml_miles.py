# -*- coding: utf-8 -*-

"""
$Id: $
"""

import mock
from pyramid.vocabulary import getVI
import testoob

from lxml import etree

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary
import models.air
import models.bonus
import models.geo
import models.route

from services.base.xml_base import ParamsValidationError
from services.xml_services.miles import (MilesXMLService, AFLMilesXMLService,
                                         MilesServiceClassXMLService,
                                         AFLMilesServiceClassXMLService,
                                         MilesTierLevelXMLService)


class TestMilesXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestMilesXMLService, self).setUp()
        self.s = MilesXMLService()

    def registerVocabularies(self):
        super(TestMilesXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.bonus.TierLevelsVocabulary)
        setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        setup_vocabulary(models.bonus.BookingClassesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer), 'tier_level_factors_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer), 'airline_tariff_groups_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineServiceClassIndexer), 'service_classes_limits_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.BookingClassesByAirlineTariffGroupIndexer), 'booking_classes_by_airline_tariff_group_idx')

    def test_miles_v001_invalid_parameters(self):
        self.assertRaises(ParamsValidationError, self.s.miles_v001, 'XX', 'XXX', 'XXA', 'silver')
        self.assertRaises(ParamsValidationError, self.s.miles_v001, 'SU', 'XXX', 'XXA', 'zzzzzzz')
        self.assertRaises(ParamsValidationError, self.s.miles_v001, 'SU', 'XXX', 'XXA', 'silver', tariff_group='zzz')
        self.assertRaises(ParamsValidationError, self.s.miles_v001, 'SU', 'SSS', 'XXA', 'silver')
        self.assertRaises(ParamsValidationError, self.s.miles_v001, 'SU', 'XXX', 'SSS', 'silver')
        self.assertRaises(ParamsValidationError, self.s.miles_v001, 'SU', 'XXX', 'XXA', 'silver', param_via='SSS')

    @mock.patch('logic.geo.LOG')
    def test_miles_v001_direct(self, mock_log):
        # Город, с которым не связан ни один аэропорт
        data = self.s.miles_v001('SU', 'UUY', 'UUW', 'silver')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertFalse(xml.xpath('/routes/route'))

        # Город - город
        data = self.s.miles_v001('SU', 'UUY', 'UUX', 'silver', tariff_group='yyy-zzz')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertEqual(len(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXA"]/segment')), 1)

        # Город - город, несколько маршрутов
        data = self.s.miles_v001('SU', 'UUZ', 'UUX', 'silver', tariff_group='yyy-zzz')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXB"][@via=""][@to="XXA"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXB"][@via=""][@to="XXE"]'))

        # Город - аэропорт
        data = self.s.miles_v001('SU', 'UUZ', 'XXA', 'silver', tariff_group='yyy-zzz')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertEqual(len(xml.xpath('/routes/route[@from="XXB"][@via=""][@to="XXA"]/segment')), 1)

        # Город - аэропорт, несколько маршрутов
        data = self.s.miles_v001('SU', 'UUU', 'XXZ', 'silver', tariff_group='yyy-zzz')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXC"][@via=""][@to="XXZ"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXD"][@via=""][@to="XXZ"]'))

        # Аэропорт - аэропорт
        data = self.s.miles_v001('SU', 'XXX', 'XXA', 'silver', tariff_group='yyy-zzz')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertEqual(len(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXA"]/segment')), 1)

    @mock.patch('logic.geo.LOG')
    def test_miles_v001_via(self, mock_log):
        # Аэропорт - аэропорт - аэропорт
        data = self.s.miles_v001('ST', 'XXZ', 'XXA', 'silver', tariff_group='yyy-zzz', param_via='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertTrue(len(xml.xpath('/routes/route')), 1)
        self.assertTrue(len(xml.xpath('/routes/route/segment')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via="XXB"][@to="XXA"]'))
        self.assertTrue(xml.xpath('/routes/route/segment[@from="XXZ"][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route/segment[@from="XXB"][@to="XXA"]'))

        # Город - аэропорт - аэропорт, несколько маршрутов
        data = self.s.miles_v001('ST', 'UUY', 'XXA', 'silver', tariff_group='business-optimum', param_via='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertTrue(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via="XXB"][@to="XXA"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@via="XXB"][@to="XXA"]'))

        # Город - аэропорт - город, несколько маршрутов
        data = self.s.miles_v001('ST', 'UUY', 'UUX', 'silver', tariff_group='business-optimum', param_via='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertTrue(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@via="XXB"][@to="XXA"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@via="XXB"][@to="XXA"]'))

        # Город - город - город, несколько маршрутов
        data = self.s.miles_v001('ST', 'UUU', 'UUZ', 'silver', tariff_group='business-optimum', param_via='UUY')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertTrue(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXC"][@via="XXZ"][@to="XXB"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXD"][@via="XXZ"][@to="XXB"]'))

    @mock.patch('logic.geo.LOG')
    def test_miles_v001_tariff_group(self, mock_log):
        data = self.s.miles_v001('ST', 'XXX', 'XXA', 'silver')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes/route/segment[@class="yyy"][@tariffGroup="yyy-zzz"]'))

        data = self.s.miles_v001('ST', 'XXX', 'XXA', 'silver', tariff_group='yyy-zzz')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/routes/route/segment[@class="business"][@tariffGroup="yyy-vvv"]'))

    @mock.patch('logic.geo.LOG')
    def test_miles_v001_allowed_by_service_class(self, mock_log):
        data = self.s.miles_v001('ST', 'UUY', 'XXB', 'silver')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@to="XXB"]/segment[@class="business"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXX"][@to="XXB"]/segment[@class="yyy"]'))
        self.assertFalse(xml.xpath('/routes/route[@from="XXZ"][@to="XXB"]/segment[@class="business"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXZ"][@to="XXB"]/segment[@class="yyy"]'))

    def test_miles_v003_invalid_parameters(self):
        self.assertRaises(ParamsValidationError, self.s.miles_v003, 'XX', 'XXX', 'XXA', 'silver')
        self.assertRaises(ParamsValidationError, self.s.miles_v003, 'SU', 'XXX', 'XXA', 'zzzzzzz')
        self.assertRaises(ParamsValidationError, self.s.miles_v003, 'SU', 'XXX', 'XXA', 'silver', tariff_group='business-optimum', fare_basis_code='zzz')
        self.assertRaises(ParamsValidationError, self.s.miles_v003, 'SU', 'SSS', 'XXA', 'silver')
        self.assertRaises(ParamsValidationError, self.s.miles_v003, 'SU', 'XXX', 'SSS', 'silver')
        self.assertRaises(ParamsValidationError, self.s.miles_v003, 'SU', 'XXX', 'XXA', 'silver', param_via='SSS')

    @mock.patch('logic.geo.LOG')
    def test_miles_v003_direct(self, mock_log):
        # Город, с которым не связан ни один аэропорт
        data = self.s.miles_v003('SU', 'UUY', 'UUW', 'silver', tariff_group='yyy-zzz', fare_basis_code='KN', param_via='XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertFalse(xml.xpath('/routes/route'))

        # Город - город
        data = self.s.miles_v003('SU', 'UUY', 'UUX', 'silver', tariff_group='comfort-premium', fare_basis_code='KN')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/routes'))
        self.assertEqual(len(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXA"]/segment')), 1)

        # Город - город, несколько маршрутов
        data = self.s.miles_v003('SU', 'UUZ', 'UUX', 'silver', tariff_group='comfort-premium', fare_basis_code='KN')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXB"][@via=""][@to="XXA"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXB"][@via=""][@to="XXE"]'))

        # Город - аэропорт
        data = self.s.miles_v003('SU', 'UUZ', 'XXA', 'silver', tariff_group='comfort-premium', fare_basis_code='KN')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertEqual(len(xml.xpath('/routes/route[@from="XXB"][@via=""][@to="XXA"]/segment')), 1)

        # Город - аэропорт, несколько маршрутов
        data = self.s.miles_v003('SU', 'UUU', 'XXZ', 'silver', tariff_group='comfort-premium', fare_basis_code='KN')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 2)
        self.assertTrue(xml.xpath('/routes/route[@from="XXC"][@via=""][@to="XXZ"]'))
        self.assertTrue(xml.xpath('/routes/route[@from="XXD"][@via=""][@to="XXZ"]'))

        # Аэропорт - аэропорт
        data = self.s.miles_v003('SU', 'XXX', 'XXA', 'silver', tariff_group='comfort-premium', fare_basis_code='KN')
        xml = etree.fromstring(data)
        self.assertEqual(len(xml.xpath('/routes/route')), 1)
        self.assertEqual(len(xml.xpath('/routes/route[@from="XXX"][@via=""][@to="XXA"]/segment')), 1)

class TestAFLMilesXMLService(TestMilesXMLService):
    def setUp(self):
        super(TestAFLMilesXMLService, self).setUp()
        self.s = AFLMilesXMLService()


class TestMilesServiceClassXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestMilesServiceClassXMLService, self).setUp()
        self.s = MilesServiceClassXMLService()

    def registerVocabularies(self):
        super(TestMilesServiceClassXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.route.PairsVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.bonus.ServiceClassesLimitsVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.ServiceClassesLimitsByAirlineIndexer), 'service_classes_limits_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')

    def test_service_classes_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.service_classes_v001, 'XX', 'XXX', 'XXB')

    def test_service_classes_v001_invalid_location(self):
        self.assertRaises(ParamsValidationError, self.s.service_classes_v001, 'SU', 'XXX', 'ZXZ')

    def test_service_classes_v001(self):
        data = self.s.service_classes_v001('SU', 'XXX','XXA')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyy"]'))
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyx"]'))
        self.assertFalse(xml.xpath('/serviceClasses/class[@code="business"]'))

        data = self.s.service_classes_v001('SU', 'XXX','XXB')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="business"]'))

        data = self.s.service_classes_v001('SU', 'XXX','XXZ')
        xml = etree.fromstring(data)
        #self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyx"]'))
        self.assertFalse(xml.xpath('/serviceClasses/class[@code="yyx"]'))

        data = self.s.service_classes_v001('SU', 'UUX','UUY')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyy"]'))
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyx"]'))

        data = self.s.service_classes_v001('SU', 'XXX','UUX')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyy"]'))
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyx"]'))

        data = self.s.service_classes_v001('SU', 'UUX','UUY')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyy"]'))
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyx"]'))

        data = self.s.service_classes_v001('SU', 'UUU','UUY')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyx"]'))


class TestAFLMilesServiceClassXMLService(TestMilesServiceClassXMLService):
    def setUp(self):
        super(TestAFLMilesServiceClassXMLService, self).setUp()
        self.s = AFLMilesServiceClassXMLService()


class TestMilesTierLevelXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestMilesTierLevelXMLService, self).setUp()
        self.s = MilesTierLevelXMLService()

    def registerVocabularies(self):
        super(TestMilesTierLevelXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TierLevelsVocabulary)

    def test_tier_levels_v001(self):
        data = self.s.tier_levels_v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/tiers'))
        self.assertTrue(xml.xpath('/tiers/tier[@code="xxx"]'))


if __name__ == "__main__":
    testoob.main()

