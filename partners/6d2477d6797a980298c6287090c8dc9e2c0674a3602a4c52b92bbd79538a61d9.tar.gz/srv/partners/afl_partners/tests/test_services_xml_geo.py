# -*- coding: utf-8 -*-

"""
$Id:
"""

import mock
import testoob

from lxml import etree

from zope.component import globalSiteManager as gsm

from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import pyramid.vocabulary.mvcc

from rx.i18n.translation import SelfTranslationDomain
from services.base.xml_base import ParamsValidationError
from services.xml_services.geo import (AirportXMLService, AFLAirportXMLService,
                                       CityXMLService, AFLCityXMLService,
                                       CountryXMLService, AFLCountryXMLService)

import models.air
import models.partner
import models.route
import models.geo

from _test_data import setup_vocabulary, createSkyteamTestData


class TestCountryXMLService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (createSkyteamTestData,)

    def setUp(self):
        super(TestCountryXMLService, self).setUp()

        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        self.s = CountryXMLService()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCountryXMLService, self).tearDown()

    def test_countries_v001(self):
        data = self.s.countries_v001('SU')
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/countries'))
        self.assertEqual(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="en"]/text()')[0], 'YYY')

        self.assertTrue(xml.xpath('/countries/country[@code="XX"]'))
        self.assertFalse(xml.xpath('/countries/country[@code="YY"]'))

        # Все авиакомпании
        data = self.s.countries_v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/countries/country[@code="XX"]'))
        self.assertTrue(xml.xpath('/countries/country[@code="YY"]'))

    def test_countries_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.countries_v001, 'XX')

    def test_countries_v001_language(self):
        data = self.s.countries_v001('SU')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="en"]'))
        self.assertTrue(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="ru"]'))

        data = self.s.countries_v001('SU', lang="ru")
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="en"]'))
        self.assertTrue(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="ru"]'))

        data = self.s.countries_v001('SU', lang="en")
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="en"]'))
        self.assertFalse(xml.xpath('/countries/country[@code="XX"]/name[@xml:lang="ru"]'))


class TestAFLCountryXMLService(TestCountryXMLService):
    def setUp(self):
        super(TestAFLCountryXMLService, self).setUp()
        self.s = AFLCountryXMLService()


class TestCityXMLService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (createSkyteamTestData,)

    def setUp(self):
        super(TestCityXMLService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        self.s = CityXMLService()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCityXMLService, self).tearDown()

    def registerVocabularies(self):
        super(TestCityXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')

    def test_cities_v001(self):
        response = self.s.cities_v001('SU')
        xml = etree.fromstring(response)

        root_element = xml.xpath(u'//cities')
        self.assertEqual(1, len(root_element))
        cities = xml.xpath(u'//cities/country/city')
        self.assertEqual(4, len(cities))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUU"][@lat="10.0"][@lon="20.0"][@redemptionZone="XZ"][@tzdata="UTC+2"]'))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUX"][@lat="99.9"][@lon="77.7"][@redemptionZone="XZ"][@tzdata="UTC+5"]'))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUY"][@lat="11.1"][@lon="22.0"][@redemptionZone="XX"][@tzdata="UTC+0"]'))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUZ"][@lat="1.0"][@lon="12.12"][@redemptionZone="XV"][@tzdata="UTC-7"]'))

        self.assertFalse(xml.xpath('/cities/country[@code="XX"]/city[@code="UUW"]'))  # пары с таким городом нет ни для одной АК
        self.assertFalse(xml.xpath('/cities/country[@code="XX"]/city[@code="FFF"]'))  # пары с таким городом нет для данной АК

        names = xml.xpath(u'//cities/country[@code="XX"]/city/name[@xml:lang="en"]')
        self.assertEqual(4, len(names))
        values = [n.text for n in names]
        self.assertIn('FFF', values)
        self.assertIn('YYY', values)
        self.assertIn('BBB', values)
        self.assertIn('DDD', values)
        self.assertNotIn('enFFF', values)
        self.assertNotIn('LLL', values)

        # Все авиакомпании
        response = self.s.cities_v001()
        xml = etree.fromstring(response)

        cities = xml.xpath(u'//cities/country/city')
        self.assertEqual(6, len(cities))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUU"][@lat="10.0"][@lon="20.0"][@tzdata="UTC+2"]'))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUX"][@lat="99.9"][@lon="77.7"][@tzdata="UTC+5"]'))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUY"][@lat="11.1"][@lon="22.0"][@tzdata="UTC+0"]'))
        self.assertTrue(xml.xpath('/cities/country[@code="XX"]/city[@code="UUZ"][@lat="1.0"][@lon="12.12"][@tzdata="UTC-7"]'))
        self.assertFalse(xml.xpath('/cities/country[@code="XX"]/city[@code="UUZ"][@lat="1.0"][@lon="12.12"][@redemptionZone][@tzdata="UTC-7"]'))

        self.assertFalse(xml.xpath('/cities/country[@code="XX"]/city[@code="UUW"]'))  # пары с таким городом нет ни для одной АК
        self.assertTrue(xml.xpath('/cities/country[@code="YY"]/city[@code="FFF"]'))

        # Все авиакомпании, все зоны
        response = self.s.cities_v001(show_all_zones=True)
        xml = etree.fromstring(response)

        cities = xml.xpath(u'//cities/country/city')
        self.assertEqual(6, len(cities))

        self.assertFalse(xml.xpath('/cities/country[@code="XX"]/city[@code="UUZ"][@lat="1.0"][@lon="12.12"][@redemptionZoneAFL="XZ"][@redemptionZoneSkyteam="XV"][@tzdata="UTC-7"]'))

    def test_cities_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.cities_v001, 'XX')

    def test_cities_v001_language(self):
        response = self.s.cities_v001('SU', lang='en')
        xml = etree.fromstring(response)

        names = xml.xpath(u'//cities/country/city/name')
        self.assertEqual(4, len(names))

        values = [n.text for n in names]
        self.assertIn('FFF', values)
        self.assertIn('YYY', values)
        self.assertIn('BBB', values)
        self.assertIn('DDD', values)
        self.assertNotIn('LLL', values)


class TestAFLCityXMLService(TestCityXMLService):
    def setUp(self):
        super(TestAFLCityXMLService, self).setUp()
        self.s = AFLCityXMLService()


class TestAirportXMLService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (createSkyteamTestData,)

    def setUp(self):
        super(TestAirportXMLService, self).setUp()

        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer), 'airlines_by_iata_idx')
        self.s = AirportXMLService()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAirportXMLService, self).tearDown()

    def test_airports_v001(self):
        data = self.s.airports_v001('SU')
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/airports'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]'))
        self.assertEqual(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="en"]/text()')[0], 'FFF')
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]'))
        self.assertEqual(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="en"]/text()')[0], 'LLL')

        self.assertFalse(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))

        # Все авиакомпании
        data = self.s.airports_v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/airports/city[@code="UUV"]/airport[@code="FFA"]'))

        # атрибуты
        self.assertTrue(xml.xpath('/airports/city[@code="UUY"]/airport[@code="XXZ"][@upg_chk="1"][@lat="11.1"][@lon="22.0"]'))

    def test_airports_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.airports_v001, 'XX')

    def test_airports_v001_language(self):
        data = self.s.airports_v001('SU')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="en"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="ru"]'))

        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="en"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="ru"]'))

        data = self.s.airports_v001('SU', lang='ru')
        xml = etree.fromstring(data)
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="en"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="ru"]'))

        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="en"]'))
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="ru"]'))

        data = self.s.airports_v001('SU', lang='en')
        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="en"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/name[@xml:lang="ru"]'))

        self.assertTrue(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="en"]'))
        self.assertFalse(xml.xpath('/airports/city[@code="UUU"]/airport[@code="XXC"]/name[@xml:lang="ru"]'))


class TestAFLAirportXMLService(TestAirportXMLService):
    def setUp(self):
        super(TestAFLAirportXMLService, self).setUp()
        self.s = AFLAirportXMLService()


if __name__ == "__main__":
    testoob.main()
