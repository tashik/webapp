# -*- coding: utf-8 -*-

"""
$Id: $
"""

import testoob

from lxml import etree

from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

from rx.i18n.translation import SelfTranslationDomain

import _test_data
import models.air
import models.bonus
import models.geo
import models.route
from _test_data import setup_vocabulary
from services.base.xml_base import ParamsValidationError
from services.xml_services.bonus import (TierLevelXMLService,
                                         AirlineServiceClassXMLService,
                                         AFLAirlineServiceClassXMLService)


class TestTierLevelXMLService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestTierLevelXMLService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        self.s = TierLevelXMLService()

    def registerVocabularies(self):
        super(TestTierLevelXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.TierLevelsVocabulary)

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestTierLevelXMLService, self).tearDown()

    def test_tier_levels_v001(self):
        data = self.s.tier_levels_v001()
        xml = etree.fromstring(data)

#       self.assertTrue(xml.xpath('/tiers[@lang="en"]'))
        self.assertTrue(xml.xpath('/tiers/tier[@code="xxx"]'))
        self.assertEqual(xml.xpath('/tiers/tier[@code="xxx"]/name[@xml:lang="en"]/text()')[0], 'YYY')

    def test_tier_levels_v001_languages(self):
        self.langAvail.langs = ['ru']

        data = self.s.tier_levels_v001(lang='ru')
        xml = etree.fromstring(data)

#        self.assertTrue(xml.xpath('/tiers[@lang="ru"]'))
        self.assertTrue(xml.xpath('/tiers/tier[@code="xxx"]'))
        self.assertFalse(xml.xpath('/tiers/tier[@code="xxx"]/name[@xml:lang="en"]'))
        self.assertEqual(xml.xpath('/tiers/tier[@code="xxx"]/name[@xml:lang="ru"]/text()')[0], 'XXX')

        self.langAvail.langs = ['en', 'ru']

        data = self.s.tier_levels_v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/tiers/tier[@code="xxx"]'))
        self.assertEqual(xml.xpath('/tiers/tier[@code="xxx"]/name[@xml:lang="en"]/text()')[0], 'YYY')
        self.assertEqual(xml.xpath('/tiers/tier[@code="xxx"]/name[@xml:lang="ru"]/text()')[0], 'XXX')


class TestAirlineServiceClassXMLService(
    TestCaseWithPgDBAndVocabs, TestCaseWithI18N
):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineServiceClassXMLService, self).setUp()

        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.air.AirlinesVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.air.AirlinesByIATAIndexer
            ),
            "airlines_by_iata_idx"
        )
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        setup_vocabulary(models.bonus.TariffGroupsVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.AirlineServiceClassesByAirlineIndexer
            ),
            "airline_service_classes_by_airline_idx"
        )
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer
            ),
            "airline_tariff_groups_by_airline_service_class_idx"
        )
        setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        registerVocabularyIndexer(
            VocabularyIndexerFactory(
                models.bonus.BookingClassesByAirlineTariffGroupIndexer
            ),
            "booking_classes_by_airline_tariff_group_idx"
        )
        setup_vocabulary(models.bonus.BookingClassesVocabulary)

        self.s = AirlineServiceClassXMLService()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAirlineServiceClassXMLService, self).tearDown()

    def test_service_classes_v001(self):
        data = self.s.service_classes_v001("ST")

        xml = etree.fromstring(data)
        self.assertTrue(xml.xpath('/serviceClasses/class[@code="yyy"]'))
        self.assertTrue(
            xml.xpath('/serviceClasses/class[@code="yyy" and @ordering="10"]'))
        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/name[@xml:lang="en"]/text()')[0],
            'YYY')
        self.assertTrue(
            xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]'))
        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/name[@xml:lang="en"]/text()')[0],
            'YYY-zzz')
        self.assertTrue(xml.xpath(
            '/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/fare[@code="A"]'))
        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/fare[@code="A"]/comment[@xml:lang="en"]/text()')[0],
            'enA')

    def test_service_classes_v001_invalid_airline(self):
        self.assertRaises(ParamsValidationError, self.s.service_classes_v001, 'XX')

    def test_service_classes_v001_languages(self):
        self.langAvail.langs = ['ru']

        data = self.s.service_classes_v001("ST")
        xml = etree.fromstring(data)

        self.assertFalse(xml.xpath('/serviceClasses/class[@code="yyy"]/name[@xml:lang="en"]'))
        self.assertEqual(xml.xpath('/serviceClasses/class[@code="yyy"]/name[@xml:lang="ru"]/text()')[0], 'XXX')

        self.assertFalse(xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/fare[@code="A"]/comment[@xml:lang="en"]'))
        self.assertEqual(xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/fare[@code="A"]/comment[@xml:lang="ru"]/text()')[0],
                         'ruA')

        self.langAvail.langs = ['en', 'ru']

        data = self.s.service_classes_v001("ST")
        xml = etree.fromstring(data)

        self.assertFalse(xml.xpath('/serviceClasses[@lang="ru"]'))
        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/name[@xml:lang="en"]/text()')[0],
            'YYY')
        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/name[@xml:lang="ru"]/text()')[0],
            'XXX')

        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/fare[@code="A"]/comment[@xml:lang="en"]/text()')[0],
            'enA')
        self.assertEqual(
            xml.xpath('/serviceClasses/class[@code="yyy"]/groups/group[@code="yyy-zzz"]/fare[@code="A"]/comment[@xml:lang="ru"]/text()')[0],
            'ruA')


class TestAFLAirlineServiceClassXMLService(TestAirlineServiceClassXMLService):
    def setUp(self):
        super(TestAFLAirlineServiceClassXMLService, self).setUp()
        self.s = AFLAirlineServiceClassXMLService()


if __name__ == "__main__":
    testoob.main()
