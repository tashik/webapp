# -*- coding: utf-8 -*-
"""
$Id: _test_ui_common.py 20345 2016-08-16 19:38:58Z oeremeeva $
"""

import cherrypy
from pyramid.tests import testlib
import re
from rx.i18n.translation import init_i18n


class StdUITest(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithRoutes,
                testlib.TestCaseWithAuth, testlib.TestCaseWithI18N):
    """Базовый класс для тестов на отрисовку страниц."""

    header_pattern = re.compile(r'.*(<div id="header">.*</div>)\s+<!-- /header -->.*', re.DOTALL)
    body_pattern = re.compile(r'.*((<div class="content">.*</div>)|(<div class="content  aflcab">.*</div>))\s+</div>\s+</div>\s+<div class="block-right">.*',
                              re.DOTALL)
    script_pattern = re.compile(r'<script.*>.*</script>', re.DOTALL)

    def setUp(self):
        super(StdUITest, self).setUp()
        self.register_vocabs()
        init_i18n()
        cherrypy.session = {}

    def stripBody(self, html):
        m = self.body_pattern.match(html)
        res = m.groups()[0]
        return self.script_pattern.sub('', res)

    def register_vocabs(self):
        """Регистрация используемых словарей, например:
        from pyramid.registry import registerFromModule
        registerFromModule(models.air)
        """
