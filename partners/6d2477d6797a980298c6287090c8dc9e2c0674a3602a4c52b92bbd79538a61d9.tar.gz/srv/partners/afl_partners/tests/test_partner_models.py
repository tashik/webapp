# -*- coding: utf-8 -*-

"""
$Id: $
"""
import mock
import testoob

from datetime import datetime, date

from zope.schema.interfaces import ITokenizedTerm
import pyramid.vocabulary.mvcc
from pyramid.i18n.message import Message
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.interfaces import IVocabulary
from pyramid.registry import registerVocabularyIndexer
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

from rx.i18n.translation import SelfTranslationDomain

import _test_data
from _test_data import setup_vocabulary
import models.geo
import models.partner
import models.special_offer


class TestPartnerCategory(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerCategory, self).setUp()
        self.model = models.partner.PartnerCategory

    def test_model(self):
        ob = self.model.load(partner_category_id=-1)

        self.assertEqual(u'U', ob.status)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)

        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual(u'', ob.description)


class TestPartnerCategoryI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def testModelTitles(self):
        ob = models.partner.PartnerCategory.load(partner_category_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestPartnerCategoriesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerCategoriesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnerCategoriesVocabulary)

    def testVocabulary(self):
        v = getV('partner_categories')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.partner.PartnerCategory))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])


class TestPartner(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartner, self).setUp()
        self.model = models.partner.Partner
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.partner.PartnerAwardConditionsByPartnerIndexer),
                                  'partner_awards_conditions_by_partner_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer),
                                  'special_offers_by_partner_idx')

    def test_model(self):
        ob = self.model.load(partner_id=-2)

        self.assertEqual(u'P', ob.status)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertEqual([u'-1'], ob.partner_categories)
        self.assertEqual([u'en:some.en', u'ru:http://some.ru'], ob.url)
        self.assertEqual([u'ru:<p>XXXXXX</p>', u'en:<p>YYYYYY</p>'], ob.partner_description)
        self.assertEqual(u'A', ob.mile_action)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.spec_offer_comm)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.short_descr)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.mile_waste_comm)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.mile_get_comm)
        self.assertEqual(date(2015, 3, 13), ob.new_until)

        self.assertTrue(isinstance(ob.title, Message))

    def test_get_offices(self):
        ob = self.model.load(partner_id=-1)
        offices = ob.get_offices()
        self.assertEqual(1, len(offices))
        self.assertTrue(isinstance(offices[0], models.partner.PartnerOffice))

    def test_get_award_conditions(self):
        ob = self.model.load(partner_id=-1)
        award_conditions = ob.get_award_conditions()
        self.assertEqual(4, len(award_conditions))
        self.assertTrue(isinstance(award_conditions[0], models.partner.PartnerAwardCondition))
        award_condition_ids = [c.partner_award_condition_id for c in award_conditions]
        self.assertTrue(all([cid in award_condition_ids for cid in (-5, -6, -7, -8)]))
        self.assertTrue(all([cid not in award_condition_ids for cid in (-9, -10)]))

    @mock.patch('config.PARTNERS_FILES_URL', 'http://localhost/fake_static')
    def test_image(self):
        ob = self.model.load(partner_id=-1)
        self.assertEqual(ob.image, 'http://localhost/fake_static/images/-1.jpg')

    def test_check_city(self):
        ob = self.model.load(partner_id=-1)
        self.assertTrue(ob.check_city(-1))
        self.assertFalse(ob.check_city(-2))

    def test_check_country(self):
        ob = self.model.load(partner_id=-1)
        self.assertTrue(ob.check_country(u'XX'))
        self.assertFalse(ob.check_city(u'YY'))

    def test_check_categories(self):
        ob = self.model.load(partner_id=-1)
        self.assertTrue(ob.check_categories([]))
        self.assertTrue(ob.check_categories(-1))
        self.assertTrue(ob.check_categories([-1, -2]))
        self.assertTrue(ob.check_categories([-2, -3]))
        self.assertTrue(ob.check_categories([-2, -3, -4]))
        self.assertFalse(ob.check_categories([-3, -4]))

    def test_check_name(self):
        ob = models.partner.Partner.load(partner_id=-1)
        self.assertTrue(ob.check_name(u'', 'ru'))
        self.assertTrue(ob.check_name(u'', 'en'))
        self.assertTrue(ob.check_name(u'XX', 'ru'))
        self.assertTrue(ob.check_name(u'YY', 'en'))
        self.assertFalse(ob.check_name(u'ZZ', 'ru'))
        self.assertFalse(ob.check_name(u'ZZ', 'en'))

    def test_check_award_condition_types(self):
        ob = models.partner.Partner.load(partner_id=-1)
        self.assertTrue(ob.check_award_condition_types([]))
        self.assertTrue(ob.check_award_condition_types(u'S'))
        self.assertTrue(ob.check_award_condition_types([u'S', u'E']))
        self.assertTrue(ob.check_award_condition_types([u'E', u'B']))
        self.assertTrue(ob.check_award_condition_types([u'E', u'B', u'C']))
        self.assertFalse(ob.check_award_condition_types([u'B', u'C']))

    def check_mile_action(self):
        ob = models.partner.Partner.load(partner_id=-1)
        self.assertFalse(ob.check_mile_action(''))
        self.assertFalse(ob.check_mile_action('X'))
        self.assertTrue(ob.check_mile_action(u'A'))
        self.assertTrue(ob.check_mile_action([u'E']))
        self.assertTrue(ob.check_mile_action([u'S']))

        ob = models.partner.Partner.load(partner_id=-11)
        self.assertFalse(ob.check_mile_action(''))
        self.assertFalse(ob.check_mile_action('X'))
        self.assertFalse(ob.check_mile_action(u'A'))
        self.assertFalse(ob.check_mile_action([u'E']))
        self.assertTrue(ob.check_mile_action([u'S']))

    @mock.patch('models.partner.datetime')
    def test_get_special_offers(self, datetime_mock):
        datetime_mock.now.return_value = datetime(2014, 12, 10)
        ob = models.partner.Partner.load(partner_id=-1)
        # Если запрошенного языка нет в offer.ui_languages, перевод не возвращается.
        special_offers = ob.get_special_offers(lang='ru')
        self.assertEqual(0, len(special_offers))
        # Если запрошенный язык присутствует в offer.ui_languages, возвращается соответствующий перевод.
        special_offers = ob.get_special_offers(lang='en')
        self.assertEqual(1, len(special_offers))

        offer = special_offers[0]
        self.assertEqual('P', offer.status)
        self.assertEqual('03.12.2014 10:00:00', offer.begin_date.strftime("%d.%m.%Y %H:%M:%S"))
        self.assertEqual('13.01.2015 10:00:00', offer.end_date.strftime("%d.%m.%Y %H:%M:%S"))
        self.assertEqual(-1, offer.partner)
        self.assertEqual([u'ru:http://ya.ru', u'en:http://ya.com'], offer.offer_url)

        ob = models.partner.Partner.load(partner_id=-2)
        # Если не указан язык перевода, возвращаются все переводы не зависимо от наличия языка в offer.ui_languages.
        special_offers = ob.get_special_offers()
        self.assertEqual(1, len(special_offers))
        offer = special_offers[0]
        self.assertEqual(-1, offer.offer_id)

        ob = models.partner.Partner.load(partner_id=-4)
        special_offers = ob.get_special_offers(lang='ru')
        self.assertEqual(0, len(special_offers))


class TestPartnerI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def testModelTitles(self):
        ob = models.partner.Partner.load(partner_id=-2)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertTrue(isinstance(ob.description, Message))
        self.assertTrue(isinstance(ob.short_description, Message))
        self.assertTrue(isinstance(ob.special_offers_comment, Message))
        self.assertTrue(isinstance(ob.mile_spend_comment, Message))
        self.assertTrue(isinstance(ob.mile_earn_comment, Message))
        self.assertTrue(isinstance(ob.url_local, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))
        self.assertEqual(u'<p>YYYYYY</p>', SelfTranslationDomain().translate(ob.description.msgid))
        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.short_description.msgid))
        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.special_offers_comment.msgid))
        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.mile_spend_comment.msgid))
        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.mile_earn_comment.msgid))
        self.assertEqual(u'http://some.en', SelfTranslationDomain().translate(ob.url_local.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))
        self.assertEqual(u'<p>XXXXXX</p>', SelfTranslationDomain().translate(ob.description.msgid))
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.short_description.msgid))
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.special_offers_comment.msgid))
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.mile_spend_comment.msgid))
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.mile_earn_comment.msgid))
        self.assertEqual(u'http://some.ru', SelfTranslationDomain().translate(ob.url_local.msgid))

    @mock.patch('config.PARTNERS_FILES_URL', '//localhost/fake_static')
    @mock.patch('config.KNOWN_LANGUAGES', ('ru', 'en', 'de'))
    def test_default_logo_url(self):
        ob = models.partner.Partner.load(partner_id=-1)
        self.assertTrue(isinstance(ob.default_logo_url, Message))

        logo_url_en = SelfTranslationDomain().translate(ob.default_logo_url.msgid)
        self.assertEqual(logo_url_en, '//localhost/fake_static/logo_int/-1.jpg')

        self.negotiator.lang = 'ru'
        logo_url_ru = SelfTranslationDomain().translate(ob.default_logo_url.msgid)
        self.assertEqual(logo_url_ru, '//localhost/fake_static/logo_rus/-1.jpg')

    @mock.patch('config.PARTNERS_FILES_URL', '//localhost/fake_static')
    @mock.patch('config.KNOWN_LANGUAGES', ('ru', 'en', 'de'))
    def test_logo_urls(self):
        ob = models.partner.Partner.load(partner_id=-1)
        urls = ob.logo_urls
        self.assertIn('ru', urls)
        self.assertIn('en', urls)
        self.assertIn('de', urls)
        self.assertNotIn('it', urls)
        self.assertEqual(urls['ru'], '//localhost/fake_static/logo_rus/-1.jpg')
        self.assertEqual(urls['en'], '//localhost/fake_static/logo_int/-1.jpg')
        self.assertEqual(urls['de'], '//localhost/fake_static/logo_int/-1.jpg')

    @mock.patch('config.PARTNERS_SVC_FILES_URL', 'http://localhost/fake_static')
    @mock.patch('config.KNOWN_LANGUAGES', ('ru', 'en', 'de'))
    def test_logo_svc_urls(self):
        ob = models.partner.Partner.load(partner_id=-1)
        urls = ob.logo_svc_urls
        self.assertIn('ru', urls)
        self.assertIn('en', urls)
        self.assertIn('de', urls)
        self.assertNotIn('it', urls)
        self.assertEqual(urls['ru'], 'http://localhost/fake_static/logo_rus/-1.jpg')
        self.assertEqual(urls['en'], 'http://localhost/fake_static/logo_int/-1.jpg')
        self.assertEqual(urls['de'], 'http://localhost/fake_static/logo_int/-1.jpg')


class TestPartnersVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnersVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnersVocabulary)

    def testVocabulary(self):
        v = getV('partners')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.partner.Partner))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.new_until, date(2015, 4, 10))


class TestPartnerOfficeContact(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerOfficeContact, self).setUp()
        self.model = models.partner.PartnerOfficeContact

    def test_model(self):
        ob = self.model.load(partner_office_contact_id=-1)

        self.assertEqual(-1, ob.partner_office)
        self.assertEqual(u'E', ob.contact_type)
        self.assertEqual(u'some@some.ru', ob.contact)
        self.assertEqual(True, ob.main_contact)


class TestPartnerOfficeContactsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerOfficeContactsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnerOfficeContactsVocabulary)

    def testVocabulary(self):
        v = getV('partner_office_contacts')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.partner.PartnerOfficeContact))
        self.assertEqual(ob.contact, u'some@some.ru')


class TestPartnerOffice(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerOffice, self).setUp()
        self.model = models.partner.PartnerOffice
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnerOfficeContactsVocabulary)

    def test_model_load(self):
        ob = self.model.load(partner_office_id=-1)

        self.assertEqual(-1, ob.partner)
        self.assertEqual(-1, ob.city)
        self.assertEqual(77.77, ob.lat)
        self.assertEqual(77.77, ob.lon)
        self.assertEqual(ob.comments, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.address, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.worktime, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.office_type, u'M')

        self.assertEqual(2, len(ob.contacts))

    def test_model_save(self):
        ob = models.partner.PartnerOffice()
        ob.partner_office_id = -3
        ob.partner = -1
        ob.city = -1
        ob.lat = +77.11
        ob.lon = -77.11
        ob.comments = [u'ru:XXX', u'en:YYY']
        ob.address = [u'ru:XXX', u'en:YYY']
        ob.worktime = [u'ru:XXX', u'en:YYY']
        ob.office_type = u'M'
        ob.contacts = [
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-2,
                contact_type=u'E',
                contact=u'test11@test.com',
                main_contact=False
            ),
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-3,
                contact_type=u'E',
                contact=u'test11@test.com',
                main_contact=False
            ),
        ]
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.partner_office_id, None)
        self.assertEqual(2, len(ob.contacts))


class TestPartnerOfficesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerOfficesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)

    def testVocabulary(self):
        v = getV('partner_offices')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.partner.PartnerOffice))
        self.assertEqual(ob.worktime, [u'ru:XXX', u'en:YYY'])


class TestPartnerAwardCondition(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerAwardCondition, self).setUp()
        self.model = models.partner.PartnerAwardCondition

    def test_model(self):
        ob = self.model.load(partner_award_condition_id=-1)

        self.assertEqual(-2, ob.partner)
        self.assertEqual(u'S', ob.award_condition_type)
        self.assertEqual(77, ob.weight)
        self.assertEqual(ob.award_condition_description, [u'ru:<p>XXXXXX</p>', u'en:<p>YYYYYY</p>'])
        self.assertEqual(ob.status, u'P')
        self.assertEqual(ob.miles, 1)

    def test_types(self):
        ob = self.model.load(partner_award_condition_id=-1)
        self.assertTrue(ob.is_spending)
        self.assertFalse(ob.is_earning)
        ob = self.model.load(partner_award_condition_id=-10)
        self.assertTrue(ob.is_earning)
        self.assertFalse(ob.is_spending)


class TestPartnerAwardConditionI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def testModelTitles(self):
        ob = models.partner.PartnerAwardCondition.load(partner_award_condition_id=-1)
        self.assertTrue(isinstance(ob.description, Message))

        self.assertEqual(u'<p>YYYYYY</p>', SelfTranslationDomain().translate(ob.description.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'<p>XXXXXX</p>', SelfTranslationDomain().translate(ob.description.msgid))


class TestPartnerAwardConditionsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerAwardConditionsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)

    def testVocabulary(self):
        v = getV('partner_award_conditions')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.partner.PartnerAwardCondition))
        self.assertEqual(ob.award_condition_description, [u'ru:<p>XXXXXX</p>', u'en:<p>YYYYYY</p>'])
        self.assertEqual(ob.miles, 1)


class TestPartnerAwardConditionsByPartnerIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestPartnerAwardConditionsByPartnerIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.partner.PartnerAwardConditionsByPartnerIndexer),
                                  'partner_awards_conditions_by_partner_idx')

    def test_add(self):
        key_vocab = getV('partners')
        vocab = getV('partner_award_conditions')
        idx = getVI('partner_awards_conditions_by_partner_idx')

        partner = key_vocab["-1"]

        self.assertEqual(len(idx(context=partner)), 6)
        self.assertTrue(isinstance(idx(context=partner)[0], models.partner.PartnerAwardCondition))
        self.assertEqual(idx(context=partner)[0].partner, -1)

        partner2 = key_vocab["-3"]
        self.assertEqual(len(idx(context=partner2)), 0)

        ob = models.partner.PartnerAwardCondition(
            partner_award_condition_id=-20,
            partner=partner2.partner_id,
            award_condition_type='S',
            award_condition_description='ru:',
            weight=50,
            status='P',
            miles=10)

        vocab.update_many([ob])

        self.assertIn("-20", vocab)
        self.assertEqual(len(idx(context=partner2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=partner2)), 1)
        self.assertTrue(isinstance(idx(context=partner2)[0], models.partner.PartnerAwardCondition))
        self.assertEqual(idx(context=partner2)[0].partner, -3)
        self.assertEqual(idx(context=partner2)[0].partner_award_condition_id, -20)

    def test_change(self):
        key_vocab = getV('partners')
        vocab = getV('partner_award_conditions')
        idx = getVI('partner_awards_conditions_by_partner_idx')

        partner1 = key_vocab["-1"]
        partner2 = key_vocab["-3"]

        self.assertEqual(len(idx(context=partner1)), 6)
        self.assertEqual(len(idx(context=partner2)), 0)

        ob = models.partner.PartnerAwardCondition(
            partner_award_condition_id=-5,
            partner=-3,
            award_condition_type='S',
            award_condition_description='ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>',
            weight=1,
            status='P',
            miles=5
        )

        vocab.update_many([ob])

        self.assertEqual(len(idx(context=partner1)), 6)
        self.assertEqual(len(idx(context=partner2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=partner1)), 5)
        self.assertEqual(len(idx(context=partner2)), 1)
        self.assertEqual(idx(context=partner2)[0].partner_award_condition_id, -5)
        self.assertEqual(idx(context=partner2)[0].partner, -3)

        vocab.update_many([ob])

    def test_delete(self):
        key_vocab = getV('partners')
        vocab = getV('partner_award_conditions')
        idx = getVI('partner_awards_conditions_by_partner_idx')

        partner = key_vocab["-1"]

        self.assertEqual(len(idx(context=partner)), 6)

        ob = vocab["-5"]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-5', vocab)
        self.assertEqual(len(idx(context=partner)), 6)
        self.assertIn('-5', [str(obj.partner_award_condition_id) for obj in idx(context=partner)])

        idx._reindex()

        self.assertEqual(len(idx(context=partner)), 5)
        self.assertNotIn('-5', [str(obj.partner_award_condition_id) for obj in idx(context=partner)])

if __name__ == "__main__":
    testoob.main()
