# -*- coding: utf-8 -*-

"""
$Id: test_special_offer_models.py 13550 2015-06-25 17:02:45Z ogambaryan $
"""
import mock
import testoob

import pyramid.vocabulary.mvcc

from pyramid.i18n.message import Message
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs, TestCaseWithI18N)
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.vocabulary.interfaces import IVocabulary
from zope.schema.interfaces import ITokenizedTerm

from rx.i18n.translation import SelfTranslationDomain

import _test_data
from _test_data import setup_vocabulary
import models.special_offer
import models.partner


class TestSpecialOffer(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestSpecialOffer, self).setUp()
        self.model = models.special_offer.SpecialOffer

    @mock.patch('config.SPECIAL_OFFERS_URL', 'http://test.com/')
    def test_model(self):
        ob = self.model.load(offer_id=-1)
        self.assertEqual([u'en:Super special offer', u'ru:Мега специальное предложение'], ob.names)
        self.assertIsNone(ob.begin_date)
        self.assertIsNone(ob.end_date)
        self.assertEqual(u'P', ob.status)
        self.assertEqual([u'en:Super special offer description', u'ru:Описание мега специального предложения', u'fr:<p>XXXXXX</p>'], ob.offer_description)
        self.assertEqual([u'ru:/cms/ru/123', u'en:/cms/en/123'], ob.offer_url)
        self.assertEqual([u'ru:http://test.com/cms/ru/123', u'en:http://test.com/cms/en/123'], ob.safe_offer_url)
        self.assertEqual([u'en', u'ru'], ob.ui_languages)

    @mock.patch('config.PARTNERS_FILES_URL', 'http://localhost/fake_static')
    def test_image(self):
        ob = self.model.load(offer_id=-1)
        self.assertEqual(ob.image, 'http://localhost/fake_static/special_offers/-1.jpg')


class TestSpecialOfferVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestSpecialOfferVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)

    def testVocabulary(self):
        v = getV('special_offers')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-2 in v)
        self.assertFalse(1 in v)

        ob = v[-2]
        self.assertTrue(isinstance(ob, models.special_offer.SpecialOffer))
        self.assertEqual(ob.names, [u'en:Super special offer', u'ru:Мега специальное предложение'])


class TestSpecialOffersByPartnerIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestSpecialOffersByPartnerIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer),
                                  'special_offers_by_partner_idx')

    def test_add(self):
        vocab = getV('special_offers')
        idx = getVI('special_offers_by_partner_idx')

        partner = getV('partners')[-3]

        ob = models.special_offer.SpecialOffer(
            offer_id=-4,
            partner=-3,
            names=[u'ru:KKK', u'en:LLL'],
            status='P',
            offer_description=[u'en:DEF', u'ru:ГДЕ'],
            offer_url=[u'ru:aeroflot.ru'],
            ui_languages=[u'en', u'ru']
        )

        vocab.update_many([ob])

        self.assertIn(-4, vocab)
        self.assertEqual(len(idx(context=partner)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=partner)), 1)
        self.assertTrue(isinstance(idx(context=partner)[0], models.special_offer.SpecialOffer))
        self.assertEqual(idx(context=partner)[0].offer_id, -4)

    def test_change(self):
        vocab = getV('special_offers')
        idx = getVI('special_offers_by_partner_idx')

        partner1 = getV('partners')[-1]
        partner2 = getV('partners')[-3]

        self.assertEqual(len(idx(context=partner1)), 1)
        self.assertEqual(len(idx(context=partner2)), 0)

        ob = models.special_offer.SpecialOffer(
            offer_id=-2,
            partner=-3,
            names=[u'ru:KKK', u'en:LLL'],
            status='P',
            offer_description=[u'en:DEF', u'ru:ГДЕ'],
            offer_url=[u'ru:aeroflot.ru'],
            ui_languages=[u'en', u'ru']
        )

        vocab.update_many([ob])

        self.assertEqual(len(idx(context=partner1)), 1)
        self.assertEqual(len(idx(context=partner2)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=partner1)), 0)
        self.assertEqual(len(idx(context=partner2)), 1)
        self.assertEqual(idx(context=partner2)[0].offer_id, -2)
        self.assertEqual(idx(context=partner2)[0].partner, -3)

    def test_delete(self):
        vocab = getV('special_offers')
        idx = getVI('special_offers_by_partner_idx')

        partner1 = getV('partners')[-4]
        self.assertEqual(len(idx(context=partner1)), 1)

        ob = idx(context=partner1)[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn(-4, vocab)
        self.assertEqual(len(idx(context=partner1)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=partner1)), 0)


class TestSpecialOfferI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def testModelTitles(self):
        ob = models.special_offer.SpecialOffer.load(offer_id=-2)
        self.assertTrue(isinstance(ob.name, Message))
        self.assertTrue(isinstance(ob.description, Message))
        self.assertTrue(isinstance(ob.url, Message))

        self.assertEqual(u'Super special offer', SelfTranslationDomain().translate(ob.name.msgid))
        self.assertEqual(u'Super special offer description', SelfTranslationDomain().translate(ob.description.msgid))
        self.assertEqual(u'http://ya.com', SelfTranslationDomain().translate(ob.url.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'Мега специальное предложение', SelfTranslationDomain().translate(ob.name.msgid))
        self.assertEqual(u'Описание мега специального предложения', SelfTranslationDomain().translate(ob.description.msgid))
        self.assertEqual(u'http://ya.ru', SelfTranslationDomain().translate(ob.url.msgid))

    @mock.patch('config.SPECIAL_OFFERS_URL', 'http://test.com/')
    def test_url(self):
        ob = models.special_offer.SpecialOffer.load(offer_id=-3)
        self.assertEqual(u'http://test.com/cms/en/123', SelfTranslationDomain().translate(ob.url.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'http://test.com/cms/ru/123', SelfTranslationDomain().translate(ob.url.msgid))

if __name__ == '__main__':
    testoob.main()
