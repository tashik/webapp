# -*- coding: utf-8 -*-
"""
$Id: test_ui_airlines.py 21911 2016-12-07 07:20:29Z oeremeeva $
"""

import testoob
import cherrypy

import pyramid.vocabulary.mvcc
from pyramid.tests import testlib
from pyramid.ui.utils import xmlTree, resolveRoute

import _test_data
import _test_ui_common
from _test_data import setup_vocabulary

from ui import airlines

import models.air


class TestAirlinesPage(_test_ui_common.StdUITest, testlib.TestCaseWithLenientRoutes):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def register_vocabs(self):
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)

    def setUp(self):
        super(TestAirlinesPage, self).setUp()
        self.mapper.connect('airline', '/airlines/:id')
        self.page = airlines.AirlinesPage()
        cherrypy.request.current_locale = 'ru'

    def test_service(self):
        body = self.stripBody(self.page.index())
        xml = xmlTree(body)

        # В данных, загружаемых createSkyteamTestData(), 2 авиакомпании из SkyTeam
        self.assertEqual(1, len(xml.xpath(u'//ul[contains(@class, "airlineContainer")]')))
        self.assertEqual(2, len(xml.xpath(u'//ul[contains(@class, "airlineContainer")]/li[contains(@class, "bo")]')))

        airline_urls = xml.xpath(u'//ul[contains(@class, "airlineContainer")]/li[contains(@class, "bo")]/div[contains(@class, "bi")]/a/@href')
        self.assertEqual(resolveRoute('airline', id=-3), airline_urls[1])
        self.assertNotIn(resolveRoute('airline', id=-5), airline_urls)


if __name__ == "__main__":
    testoob.main()
