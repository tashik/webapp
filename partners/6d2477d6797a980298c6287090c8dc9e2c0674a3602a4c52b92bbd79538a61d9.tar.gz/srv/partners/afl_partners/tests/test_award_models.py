# -*- coding: utf-8 -*-

"""
$Id: $
"""

import testoob

from zope.schema.interfaces import ITokenizedTerm

import pyramid.vocabulary.mvcc
from pyramid.i18n.message import Message
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.vocabulary.interfaces import IVocabulary

from rx.i18n.translation import SelfTranslationDomain

import _test_data
from _test_data import setup_vocabulary
import models.award
import models.bonus


class TestRedemptionZone(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestRedemptionZone, self).setUp()
        self.model = models.award.RedemptionZone

    def test_model(self):
        ob = self.model.load(redemption_zone='XX')

        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)

        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestRedemptionZoneI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.award.RedemptionZone.load(redemption_zone='XX')
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestRedemptionZoneVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestRedemptionZoneVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.RedemptionZonesVocabulary)

    def testVocabulary(self):
        v = getV('redemption_zones')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue('XX' in v)
        self.assertFalse('ZZ' in v)
        ob = v['XX']
        self.assertTrue(isinstance(ob, models.award.RedemptionZone))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])


class TestBonusRouteModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestBonusRouteModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.BonusRoutesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.BonusRoutesByCtxIndexer), 'bonus_routes_by_ctx_idx')
        self.model = models.award.BonusRoute

    def test_model(self):
        ob = self.model.load(bonus_route_id=-1)

        self.assertEqual(-1, ob.bonus_route_id)
        self.assertEqual('XXXZXY', ob.code)
        self.assertEqual('XX', ob.zone_from)
        self.assertEqual('XZ', ob.zone_via)
        self.assertEqual('XY', ob.zone_to)

        self.assertEqual('XXXZXY', ob.title)

    def test_model_empty_zone_via(self):
        ob = self.model.load(bonus_route_id=-2)

        self.assertEqual(-2, ob.bonus_route_id)
        self.assertEqual('XXXY', ob.code)
        self.assertEqual('XX', ob.zone_from)
        self.assertIsNone(ob.zone_via)
        self.assertEqual('XY', ob.zone_to)

        self.assertEqual('XXXY', ob.title)

    def test_search(self):
        # AA-BB-CC
        ob = models.award.BonusRoute.search('XX', 'XZ', 'XY', 'A')
        self.assertEqual(-1, ob.bonus_route_id)

        # CC-BB-AA -> AA-BB-CC
        ob = models.award.BonusRoute.search('XY', 'XZ', 'XX', 'A')
        self.assertEqual(-1, ob.bonus_route_id)

        ob = models.award.BonusRoute.search('XY', 'XZ', 'ZZ', 'A')
        self.assertIsNone(ob)

        # AA-CC
        ob = models.award.BonusRoute.search('XX', None, 'XY', 'A')
        self.assertEqual(-2, ob.bonus_route_id)

        # CC-AA -> AA-CC
        ob = models.award.BonusRoute.search('XY', None, 'XX', 'A')
        self.assertEqual(-2, ob.bonus_route_id)

        ob = models.award.BonusRoute.search('XY', None, 'ZZ', 'A')
        self.assertIsNone(ob)

        # AA-ZZ-CC -> AA-CC
        ob = models.award.BonusRoute.search('XZ', 'ZZ', 'XV', 'A')
        self.assertEqual(-5, ob.bonus_route_id)

        # CC-ZZ-AA -> AA-CC
        ob = models.award.BonusRoute.search('XV', 'ZZ', 'XZ', 'A')
        self.assertEqual(-5, ob.bonus_route_id)


class TestBonusRoutesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestBonusRoutesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.BonusRoutesVocabulary)

    def testVocabulary(self):
        v = getV('bonus_routes')

        self.assertIn('-1', v)
        self.assertNotIn('-100', v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.award.BonusRoute))
        self.assertEqual(ob.code, 'XXXZXY')


class TestBonusRoutesByCtxIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestBonusRoutesByCtxIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.BonusRoutesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.BonusRoutesByCtxIndexer), 'bonus_routes_by_ctx_idx')

    def test_add(self):
        vocab = getV('bonus_routes')
        idx = getVI('bonus_routes_by_ctx_idx')

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 1)
        self.assertTrue(isinstance(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))[0], models.award.BonusRoute))
        self.assertEqual(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))[0].bonus_route_id, -2)

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))), 0)

        ob = models.award.BonusRoute(
            bonus_route_id=-100,
            code='XZXY',
            zone_from='XZ',
            zone_via=None,
            zone_to='XY',
            carrier='A'
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))), 1)
        self.assertTrue(isinstance(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))[0], models.award.BonusRoute))
        self.assertEqual(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))[0].bonus_route_id, -100)

    def test_change(self):
        vocab = getV('bonus_routes')
        idx = getVI('bonus_routes_by_ctx_idx')

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 1)
        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))), 0)

        ob = models.award.BonusRoute(
            bonus_route_id=-2,
            code='XZXY',
            zone_from='XZ',
            zone_via=None,
            zone_to='XY',
            carrier='A'
        )

        vocab.update_many([ob])

        self.assertIn('-2', vocab)
        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 1)
        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 0)
        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))), 1)
        self.assertEqual(idx(context=models.award.BonusRouteCtx('XZ', None, 'XY', 'A'))[0].bonus_route_id, -2)

    def test_delete(self):
        vocab = getV('bonus_routes')
        idx = getVI('bonus_routes_by_ctx_idx')

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 1)

        ob = models.award.BonusRoute.load(bonus_route_id=-2)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-2', vocab)
        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=models.award.BonusRouteCtx('XX', None, 'XY', 'A'))), 0)


class TestAwardModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAwardModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        self.model = models.award.Award

    def test_model(self):
        ob = self.model.load(award_id=-1)

        self.assertEqual(-1, ob.award_id)
        self.assertEqual('OW', ob.award_type)
        self.assertEqual(-1, ob.skyteam_service_class_id_1)
        self.assertIsNone(ob.skyteam_service_class_id_2)
        self.assertEqual(100, ob.award_value)
        self.assertEqual(-1, ob.bonus_route_id)

        self.assertEqual('yyyOWMiles', ob.title)

        self.assertTrue(isinstance(ob.skyteam_sc_1, models.bonus.SkyTeamServiceClass))
        self.assertIsNone(ob.skyteam_sc_2)


class TestAwardsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAwardsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.AwardsVocabulary)

    def testVocabulary(self):
        v = getV('awards')

        self.assertIn('-1', v)
        self.assertNotIn('-100', v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.award.Award))
        self.assertEqual(ob.award_value, 100)


class TestAwardsByBonusRouteIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAwardsByBonusRouteIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.AwardsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.AwardsByBonusRouteIndexer), 'awards_by_bonus_route_idx')

    def test_add(self):
        vocab = getV('awards')
        idx = getVI('awards_by_bonus_route_idx')

        bonus_route = models.award.BonusRoute.load(bonus_route_id=-1)

        self.assertEqual(len(idx(context=bonus_route)), 6)
        self.assertTrue(isinstance(idx(context=bonus_route)[0], models.award.Award))
        self.assertIn(-1, [ob.award_id for ob in idx(context=bonus_route)])
        self.assertNotIn(-100, [ob.award_id for ob in idx(context=bonus_route)])

        ob = models.award.Award(
            award_id=-100,
            award_type='OW',
            skyteam_service_class_id_1=-1,
            skyteam_service_class_id_2=None,
            award_value=1000,
            bonus_route_id=-1
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=bonus_route)), 6)

        idx._reindex()

        self.assertEqual(len(idx(context=bonus_route)), 7)
        self.assertIn(-100, [ob.award_id for ob in idx(context=bonus_route)])

    def test_change(self):
        vocab = getV('awards')
        idx = getVI('awards_by_bonus_route_idx')

        bonus_route = models.award.BonusRoute.load(bonus_route_id=-1)

        self.assertEqual(len(idx(context=bonus_route)), 6)
        self.assertIn(-1, [ob.award_id for ob in idx(context=bonus_route)])

        ob = models.award.Award(
            award_id=-1,
            award_type='OW',
            skyteam_service_class_id_1=-1,
            skyteam_service_class_id_2=None,
            award_value=1000,
            bonus_route_id=-1
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=bonus_route)), 6)
        self.assertIn(100, [ob.award_value for ob in idx(context=bonus_route)])
        self.assertNotIn(1000, [ob.award_value for ob in idx(context=bonus_route)])

        idx._reindex()

        self.assertEqual(len(idx(context=bonus_route)), 6)
        self.assertIn(1000, [ob.award_value for ob in idx(context=bonus_route)])
        self.assertNotIn(100, [ob.award_value for ob in idx(context=bonus_route)])

    def test_delete(self):
        vocab = getV('awards')
        idx = getVI('awards_by_bonus_route_idx')

        bonus_route = models.award.BonusRoute.load(bonus_route_id=-1)

        self.assertEqual(len(idx(context=bonus_route)), 6)

        ob = models.award.Award.load(award_id=-1)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=bonus_route)), 6)

        idx._reindex()

        self.assertEqual(len(idx(context=bonus_route)), 5)


class TestWrongRouteModel(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestWrongRouteModel, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.WrongRoutesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.WrongRoutesByCtxIndexer), 'wrong_routes_by_ctx_idx')
        self.model = models.award.WrongRoute

    def test_model(self):
        ob = self.model.load(wrong_route_id=-1)

        self.assertEqual(-1, ob.wrong_route_id)
        self.assertEqual(-2, ob.city_from_id)
        self.assertEqual(-4, ob.city_via_id)
        self.assertEqual(-1, ob.city_to_id)

    def test_search(self):
        ob = models.award.WrongRoute.search(-2, -4, -1)
        self.assertEqual(-1, ob.wrong_route_id)

        ob = models.award.WrongRoute.search(-1, -4, -2)
        self.assertEqual(-1, ob.wrong_route_id)

        ob = models.award.WrongRoute.search(-2, -4, -100)
        self.assertIsNone(ob)


class TestWrongRoutesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestWrongRoutesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.WrongRoutesVocabulary)

    def testVocabulary(self):
        v = getV('wrong_routes')

        self.assertIn('-1', v)
        self.assertNotIn('-100', v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.award.WrongRoute))
        self.assertEqual(ob.wrong_route_id, -1)


class TestWrongRoutesByCtxIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestWrongRoutesByCtxIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.award.WrongRoutesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.award.WrongRoutesByCtxIndexer), 'wrong_routes_by_ctx_idx')

    def test_add(self):
        vocab = getV('wrong_routes')
        idx = getVI('wrong_routes_by_ctx_idx')

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 1)
        self.assertTrue(isinstance(idx(context=models.award.WrongRouteCtx(-2, -4, -1))[0], models.award.WrongRoute))
        self.assertEqual(idx(context=models.award.WrongRouteCtx(-2, -4, -1))[0].wrong_route_id, -1)

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -100))), 0)

        ob = models.award.WrongRoute(
            wrong_route_id=-100,
            city_from_id=-2,
            city_via_id=-4,
            city_to_id=-100
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -100))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -100))), 1)
        self.assertTrue(isinstance(idx(context=models.award.WrongRouteCtx(-2, -4, -100))[0], models.award.WrongRoute))
        self.assertEqual(idx(context=models.award.WrongRouteCtx(-2, -4, -100))[0].wrong_route_id, -100)

    def test_change(self):
        vocab = getV('wrong_routes')
        idx = getVI('wrong_routes_by_ctx_idx')

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 1)
        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -100))), 0)

        ob = models.award.WrongRoute(
            wrong_route_id=-1,
            city_from_id=-2,
            city_via_id=-4,
            city_to_id=-100
        )

        vocab.update_many([ob])

        self.assertIn('-2', vocab)
        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 1)
        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -100))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 0)
        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -100))), 1)
        self.assertEqual(idx(context=models.award.WrongRouteCtx(-2, -4, -100))[0].wrong_route_id, -1)

    def test_delete(self):
        vocab = getV('wrong_routes')
        idx = getVI('wrong_routes_by_ctx_idx')

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 1)

        ob = models.award.WrongRoute.load(wrong_route_id=-1)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=models.award.WrongRouteCtx(-2, -4, -1))), 0)


if __name__ == "__main__":
    testoob.main()
