# -*- coding: utf-8 -*-

"""
$Id:
"""
import cherrypy

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import testoob
import _test_data
from _test_data import setup_vocabulary
import models.partner
import models.geo
import models.special_offer
import logic.partners


class TestLogicPartners(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def setUp(self):
        super(TestLogicPartners, self).setUp()
        cherrypy.request.current_lang = 'ru'

    def registerVocabularies(self):
        super(TestLogicPartners, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.partner.PartnersVocabulary)
        setup_vocabulary(models.partner.PartnerCategoriesVocabulary)
        setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer), 'special_offers_by_partner_idx')

    def test_categories_available(self):
        category = getV('partner_categories')[-1]

        categories = logic.partners.categories_available()
        self.assertEqual(2, len(categories))
        self.assertEqual(category, categories[0])

    def test_countries_available(self):
        country = getV('countries')['XX']

        partners = [-1, -2]
        countries = logic.partners.countries_available(partners)
        self.assertTrue(isinstance(countries, list), countries.__class__)
        self.assertEqual(1, len(countries))
        self.assertEqual(country, countries[0])

        partners = [-2]
        countries = logic.partners.countries_available(partners)
        self.assertTrue(isinstance(countries, list), countries.__class__)
        self.assertEqual(1, len(countries))
        self.assertEqual(country, countries[0])

    def test_cities_available(self):
        city = getV('cities')[-2]

        partners = [-1, -2]
        cities = logic.partners.cities_available(partners, 'XX')
        self.assertTrue(isinstance(cities, list), cities.__class__)
        self.assertEqual(2, len(cities))
        self.assertEqual(city, cities[0])

        partners = [-2]
        cities = logic.partners.cities_available(partners, 'XX')
        self.assertTrue(isinstance(cities, list), cities.__class__)
        self.assertEqual(2, len(cities))
        self.assertEqual(city, cities[0])

        partners = [-1, -2]
        cities = logic.partners.cities_available(partners, 'YY')
        self.assertTrue(isinstance(cities, list), cities.__class__)
        self.assertEqual(0, len(cities))

        cities = logic.partners.cities_available(partners)
        self.assertEqual(2, len(cities))
        self.assertEqual(city, cities[0])

    def test_search_partners(self):
        obs = logic.partners.search_partners()
        self.assertFalse(getV('partners')[-1] in obs) # unpublished
        self.assertTrue(getV('partners')[-2] in obs)
        self.assertTrue(getV('partners')[-3] in obs)

        obs = logic.partners.search_partners(country='XX')
        self.assertTrue(getV('partners')[-2] in obs)
        self.assertFalse(getV('partners')[-3] in obs) # no offices

        obs = logic.partners.search_partners(city=-1)
        self.assertTrue(getV('partners')[-2] in obs)
        self.assertFalse(getV('partners')[-3] in obs) # no offices

        obs = logic.partners.search_partners(categories=[-2])
        self.assertFalse(getV('partners')[-2] in obs)
        self.assertTrue(getV('partners')[-3] in obs)

        obs = logic.partners.search_partners(q='XX', language='ru')
        self.assertTrue(getV('partners')[-2] in obs)
        self.assertTrue(getV('partners')[-3] in obs)

        obs = logic.partners.search_partners(q='XX', language='en')
        self.assertFalse(getV('partners')[-2] in obs)
        self.assertFalse(getV('partners')[-3] in obs)

        obs = logic.partners.search_partners(search_type='A')
        self.assertTrue(getV('partners')[-2] in obs)
        self.assertTrue(getV('partners')[-3] in obs)

    def test_search_offices(self):
        # no offices exists
        partner = getV('partners')[-3]
        obs = logic.partners.search_offices(partner)
        self.assertEqual(0, len(obs))

        # offices exists
        partner = getV('partners')[-2]
        obs = logic.partners.search_offices(partner)
        self.assertEqual(2, len(obs))

        obs = logic.partners.search_offices(partner, country='XX')
        self.assertEqual(2, len(obs))

        obs = logic.partners.search_offices(partner, country='ZZzz')
        self.assertEqual(0, len(obs))

        obs = logic.partners.search_offices(partner, city=-1)
        self.assertEqual(1, len(obs))

        obs = logic.partners.search_offices(partner, city=1)
        self.assertEqual(0, len(obs))


if __name__ == "__main__":
    testoob.main()
