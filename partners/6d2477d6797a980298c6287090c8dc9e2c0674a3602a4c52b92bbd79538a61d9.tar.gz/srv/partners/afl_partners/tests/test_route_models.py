# -*- coding: utf-8 -*-

"""
$Id: $
"""

import testoob

from zope.schema.interfaces import ITokenizedTerm

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import ModelTest, TestCaseWithPgDBAndVocabs
from pyramid.registry import registerVocabularyIndexer
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.vocabulary.interfaces import IVocabulary

import _test_data
from _test_data import setup_vocabulary
import models.route


class TestPair(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestPair, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.AllPairsByCtxIndexer), 'all_pairs_by_ctx_idx')
        self.model = models.route.Pair

    def test_model(self):
        ob = self.model.load(pair_id=-1)

        self.assertEqual(-1, ob.airport_from_id)
        self.assertEqual(-3, ob.airport_to_id)
        self.assertEqual(-1, ob.airline_id)
        self.assertEqual(1000, ob.miles)
        self.assertEqual(True, ob.no_spending)

    def test_search(self):
        ob = models.route.Pair.search(-1, -3, -1)
        self.assertEqual(-1, ob.pair_id)

        ob = models.route.Pair.search(-3, -1, -1)
        self.assertEqual(-1, ob.pair_id)

        ob = models.route.Pair.search(-1, -6, -1)
        self.assertIsNone(ob)

    def test_search_all(self):
        obs = models.route.Pair.search_all(-1, -3)
        self.assertEqual(len(obs), 3)
        self.assertIn(-1, [ob.pair_id for ob in obs])
        self.assertIn(-8, [ob.pair_id for ob in obs])
        self.assertIn(-12, [ob.pair_id for ob in obs])

        obs = models.route.Pair.search_all(-3, -1)
        self.assertTrue(len(obs), 3)
        self.assertIn(-1, [ob.pair_id for ob in obs])
        self.assertIn(-8, [ob.pair_id for ob in obs])
        self.assertIn(-12, [ob.pair_id for ob in obs])

        obs = models.route.Pair.search_all(-1, -6)
        self.assertEqual(len(obs), 0)


class TestPairsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestPairsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.route.PairsVocabulary)

    def testVocabulary(self):
        v = getV('pairs')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(-100 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.route.Pair))
        self.assertEqual(-1, ob.airport_from_id)
        self.assertEqual(-3, ob.airport_to_id)


class TestPairsByCtxIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestPairsByCtxIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.PairsByCtxIndexer), 'pairs_by_ctx_idx')

    def test_add(self):
        vocab = getV('pairs')
        idx = getVI('pairs_by_ctx_idx')

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 1)
        self.assertTrue(isinstance(idx(context=models.route.PairCtx(-1, -3, -1))[0], models.route.Pair))
        self.assertEqual(idx(context=models.route.PairCtx(-1, -3, -1))[0].pair_id, -1)

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6, -1))), 0)

        ob = models.route.Pair(
            pair_id=-100,
            airport_from_id=-1,
            airport_to_id=-6,
            airline_id=-1,
            miles=1000,
            no_spending=True
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6, -1))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6, -1))), 1)
        self.assertTrue(isinstance(idx(context=models.route.PairCtx(-1, -6, -1))[0], models.route.Pair))
        self.assertEqual(idx(context=models.route.PairCtx(-1, -6, -1))[0].pair_id, -100)

    def test_change(self):
        vocab = getV('pairs')
        idx = getVI('pairs_by_ctx_idx')

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 1)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6, -1))), 0)

        ob = models.route.Pair(
            pair_id=-1,
            airport_from_id=-1,
            airport_to_id=-6,
            airline_id=-1,
            miles=1000,
            no_spending=True
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 1)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6, -1))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 0)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6, -1))), 1)
        self.assertEqual(idx(context=models.route.PairCtx(-1, -6, -1))[0].pair_id, -1)

    def test_delete(self):
        vocab = getV('pairs')
        idx = getVI('pairs_by_ctx_idx')

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 1)

        ob = idx(context=models.route.PairCtx(-1, -3, -1))[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3, -1))), 0)


class TestAllPairsByCtxIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAllPairsByCtxIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.AllPairsByCtxIndexer), 'all_pairs_by_ctx_idx')

    def test_add(self):
        vocab = getV('pairs')
        idx = getVI('all_pairs_by_ctx_idx')

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 3)
        self.assertTrue(isinstance(idx(context=models.route.PairCtx(-1, -3))[0], models.route.Pair))
        self.assertTrue(-1 in [p.pair_id for p in idx(context=models.route.PairCtx(-1, -3))])
        self.assertTrue(-8 in [p.pair_id for p in idx(context=models.route.PairCtx(-1, -3))])
        self.assertTrue(-12 in [p.pair_id for p in idx(context=models.route.PairCtx(-1, -3))])

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6))), 0)

        ob = models.route.Pair(
            pair_id=-100,
            airport_from_id=-1,
            airport_to_id=-3,
            airline_id=-2,
            miles=1000,
            no_spending=True
        )

        vocab.update_many([ob])

        self.assertIn('-100', vocab)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 3)

        idx._reindex()

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 4)
        self.assertTrue(-100 in [p.pair_id for p in idx(context=models.route.PairCtx(-1, -3))])

    def test_change(self):
        vocab = getV('pairs')
        idx = getVI('all_pairs_by_ctx_idx')

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 3)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6))), 0)

        ob = models.route.Pair(
            pair_id=-1,
            airport_from_id=-1,
            airport_to_id=-6,
            airline_id=-1,
            miles=1000,
            no_spending=True
        )

        vocab.update_many([ob])

        self.assertIn('-1', vocab)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 3)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6))), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 2)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -6))), 1)
        self.assertTrue(-1 in [p.pair_id for p in idx(context=models.route.PairCtx(-1, -6))])

    def test_delete(self):
        vocab = getV('pairs')
        idx = getVI('all_pairs_by_ctx_idx')

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 3)

        ob = models.route.Pair.load(pair_id=-1)
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 3)

        idx._reindex()

        self.assertEqual(len(idx(context=models.route.PairCtx(-1, -3))), 2)


if __name__ == '__main__':
    testoob.main()
