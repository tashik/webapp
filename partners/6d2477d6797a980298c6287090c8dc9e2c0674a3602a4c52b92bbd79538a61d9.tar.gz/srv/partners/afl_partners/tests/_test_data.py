# -*- coding: utf-8 -*-

"""
$Id: $
"""


from pyramid.ormlite.utils import runSQL
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.vocabulary import getV


ROUTES = (
    ('SVO', 'AMS'),
    ('AMS', 'ROV'),
    ('ROV', 'TAS'),
    ('SVO', 'LED'),
    ('LED', 'PEK'),
    ('LED', 'OSL'),
    ('PEK', 'NRT'),
    ('SVO', 'OSL'),
    ('OSL', 'PEK'),
    ('UFA', 'TLV'),
    ('TLV', 'KUF'),
    ('KUF', 'SOF'),
    ('TLV', 'VIE'),
)


def createSkyteamTestData():
    sql_text = u'''
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-1, 'SU', 'AFL', NULL, 'XX', -3, 'en:Aeroflot|ru:Аэрофлот', 'SkyTeam', NULL, 'en:http://site.en|ru:site.ru', 1, 500.0, 'A', 'ru:XXX|en:YYY', 'ru:XXXX|en:YYYY');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-2, 'AY', 'FIN', NULL, NULL, NULL, 'en:Finnair|ru:Авиакомпания Finnair', '', NULL, 'en:site.com', 2, 0.0, 'N', 'ru:', 'ru:');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-3, 'RO', NULL, NULL, NULL,  NULL,'en:Tarom|ru:Авиакомпания Tarom', 'SkyTeam', NULL, 'en:site.com', 3, 0.0, 'N', 'ru:', 'ru:');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-4, '7U', NULL, NULL, NULL,  NULL,'en:Aviaenergo|ru:Авиаэнерго', 'DarkTeam', NULL, 'en:site.com', 4, 0.0, 'N', 'ru:', 'ru:');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-5, 'VN', NULL, NULL, NULL,  NULL,'en:Vietnam Airlines|ru:Vietnam Airlines', 'SkyTeam', -3, 'en:site.com', 1, 0.0, 'N', 'ru:', 'ru:');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-6, 'VX', NULL, NULL, NULL,  NULL,'en:Vietnam Airlines|ru:Vietnam Airlines', 'SkyTeam', -1, 'en:site.com', 1, 0.0, 'N', 'ru:', 'ru:');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, parent_airline_id, url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-8, 'ST', 'AFT', NULL, 'XX', -3, 'en:Aeroline|ru:Авиакомпания Aeroline', '', NULL, 'en:site.com', 2, 500.0, 'T', 'ru:XXX|en:YYY', 'ru:XXXX|en:YYYY');

insert into countries (country, iso_code3, names) values ('XX', 'XXX', 'ru:XXX|en:YYY');
insert into countries (country, iso_code3, names) values ('YY', 'YYY', 'ru:ruYYY|en:enYYY');

insert into cities (city_id, country, names, iata, lat, lon, tz) values (-1, 'XX', 'ru:XXX|en:YYY', 'UUX', 99.9, 77.7,'UTC+5');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-2, 'XX', 'ru:AAA|en:BBB', 'UUY', 11.1, 22.0,'UTC+0');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-3, 'XX', 'ru:CCC|en:DDD', 'UUZ', 1.0, 12.12,'UTC-7');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-4, 'XX', 'ru:EEE|en:FFF', 'UUU', 10.0, 20.0,'UTC+2');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-5, 'XX', 'ru:KKK|en:LLL', 'UUW', 20.0, 30.0,'UTC+4');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-6, 'XX', 'ru:MMM|en:NNN', 'UUV', 25.0, 35.0,'UTC+4');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-7, 'XX', 'ru:OOO|en:PPP', 'UUT', NULL, 30.0,'UTC-5');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-8, 'YY', 'ru:ruFFF|en:enFFF', 'FFF', 22.0, 22.0,'UTC-5');
insert into cities (city_id, country, names, iata, lat, lon, tz) values (-9, 'YY', 'ru:ruGGG|en:enGGG', 'FFB', 33.0, 33.0,'UTC-6');

insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-1, -2, 'XXX', 'XXXX', 'ru:XXX|en:YYY', 99.9, 77.7, 'XX', 'SX', TRUE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-2, -2, 'XXZ', 'XXYY', 'ru:AAA|en:BBB', 11.1, 22.0, 'XX', 'SX', TRUE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-3, -1, 'XXA', 'XXAA', 'ru:CCC|en:DDD', 1.0, 12.12, 'XZ', 'SZ', FALSE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-4, -3, 'XXB', 'XXBB', 'ru:EEE|en:FFF', 10.0, 20.0, 'XV', 'XV', FALSE); -- названия зон совпадают
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-5, -4, 'XXC', 'XXCC', 'ru:KKK|en:LLL', 20.0, 30.0, 'XZ', 'SZ', FALSE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-6, -4, 'XXD', 'XXDD', 'ru:MMM|en:NNN', 25.0, 35.0, 'XZ', 'SZ', FALSE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-7, -1, 'XXE', 'XXEE', 'ru:OOO|en:PPP', 15.0, 25.0, 'XZ', 'SZ', FALSE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-8, -1, 'XXF', 'XXFF', 'ru:QQQ|en:RRR', NULL, 25.0, 'XZ', 'SZ', FALSE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-9, -3, 'XXG', 'XXGG', 'ru:SSS|en:TTT', 20.0, NULL, 'XZ', 'SZ', FALSE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-10, -6, 'FFA', 'FFAA', 'ru:ruFFAA|en:enFFAA', 11.0, 11.0, 'XZ', 'SZ', TRUE);
insert into airports (airport_id, city_id, iata, icao, names, lat, lon, afl_redemption_zone, skyteam_redemption_zone, has_uc_award) values (-11, -8, 'FFB', 'FFBB', 'ru:ruFFBB|en:enFFBB', 22.0, 22.0, 'XZ', 'SZ', TRUE);

insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-1, -1, -3, -1, 1000, TRUE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-2, -1, -4, -1, 500, TRUE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-3, -2, -4, -1, 4000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-4, -3, -4, -1, 5000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-5, -2, -5, -1, 6000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-6, -2, -6, -1, 7000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-7, -7, -4, -1, 8000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-8, -1, -3, -3, 1000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-9, -10, -11, -3, 2000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-10, -1, -4, -3, 550, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-11, -10, -6, -3, 550, TRUE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-12, -1, -3, -8, 1000, TRUE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-13, -1, -4, -8, 500, TRUE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-14, -2, -4, -8, 4000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-15, -3, -4, -8, 5000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-16, -2, -5, -8, 6000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-17, -2, -6, -8, 7000, FALSE);
insert into pairs (pair_id, airport_from_id, airport_to_id, airline_id, miles, no_spending) values (-18, -7, -4, -8, 8000, FALSE);

insert into tier_levels (tier_level, names, ordering, miles, segments) values ('xxx', 'ru:XXX|en:YYY', 1, 1000, 3);
insert into tier_levels (tier_level, names, ordering, miles, segments) values ('silver','ru:Серебрянный|en:Silver', 2, 2000, 2);
insert into tier_levels (tier_level, names, ordering, miles, segments) values ('gold','ru:Золотой|en:Gold', 3, 3000, 5);

insert into tier_level_factors (tier_level_factor_id, airline_id, tier_level, factor) values (-1, -1, 'xxx', 75);
insert into tier_level_factors (tier_level_factor_id, airline_id, tier_level, factor) values (-2, -1, 'silver', 25);
insert into tier_level_factors (tier_level_factor_id, airline_id, tier_level, factor) values (-3, -2, 'gold', 100);
insert into tier_level_factors (tier_level_factor_id, airline_id, tier_level, factor) values (-4, -8, 'silver', 25);

insert into skyteam_service_classes (skyteam_sc_id ,code, names, weight) values (-1, 'yyy', 'ru:XXX|en:YYY', 10);
insert into skyteam_service_classes (skyteam_sc_id ,code, names, weight) values (-2, 'yyx', 'ru:AAA|en:BBB', 20);
insert into skyteam_service_classes (skyteam_sc_id, code, names, weight) values (-3, 'business', 'en:Business|ru:Бизнес', 30);
insert into skyteam_service_classes (skyteam_sc_id, code, names, weight) values (-4, 'comfort', 'en:Comfort|ru:Комфорт', 5);

insert into tariff_groups (tariff_group_id, code, skyteam_sc_id, names, weight) values (-1, 'yyy-zzz', -1, 'en:YYY-zzz|ru:YYY-zzz-ru', 50);
insert into tariff_groups (tariff_group_id, code, skyteam_sc_id, names, weight) values (-2, 'business-optimum', -3, 'en:Business-Optimum|ru:Бизнес-Оптимум', 90);
insert into tariff_groups (tariff_group_id, code, skyteam_sc_id, names, weight) values (-3, 'business-premium', -3, 'en:Business-Premium|ru:Бизнес-Премиум', 100);
insert into tariff_groups (tariff_group_id, code, skyteam_sc_id, names, weight) values (-4, 'yyy-vvv', -1, 'en:YYY-vvv|ru:YYY-vvv-ru', 60);
insert into tariff_groups (tariff_group_id, code, skyteam_sc_id, names, weight) values (-5, 'comfort-optimum', -4, 'en:Comfort-Optimum|ru:Комфорт-Оптимум', 70);
insert into tariff_groups (tariff_group_id, code, skyteam_sc_id, names, weight) values (-6, 'comfort-premium', -4, 'en:Comfort-Premium|ru:Комфорт-Премиум', 80);

insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-1, -1, -1);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-2, -1, -2);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-3, -1, -3);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-4, -3, -3);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-5, -1, -4);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-7, -8, -2);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-8, -8, -3);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-9, -8, -1);

insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-1, -1, -1, 75, 10, null);
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-2, -2, -3, 150, 20, null);
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-3, -3, -4, 100, 10, null);
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-4, -4, -1, 100, 15, null);
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-5, -3, -4, 125, 100, null);

insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-6, -5, -5, 125, 0, 'S');
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-7, -2, -3, 150, 5, 'F');
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-8, -2, -3, 200, 10, 'K');
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-9, -6, -5, 250, 15, 'N');

insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-10, -1, -9, 75, 10, null);
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-11, -2, -8, 150, 20, null);
insert into airline_tariff_groups (airline_tariff_group_id, tariff_group_id, airline_sc_id, charge_coef, weight, fare_code) values (-13, -4, -9, 100, 15, null);

insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-1, 'A', TRUE, -1, 'ru:ruA|en:enA');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-3, 'X', FALSE, -4, 'ru:');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-4, 'A', TRUE, -2, 'ru:ruAAA|en:enAAA');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-5, 'B', FALSE, -5, 'ru:ruBBB|en:enBBB');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-6, 'Q', TRUE, -6, 'ru:Тест новых тарифов|en:New tariff tests');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-7, 'A', TRUE, -7, 'ru:Тест новых тарифов Бизнес-Оптимум|en:New Business-Optimum tariff tests');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-8, 'Z', TRUE, -7, 'ru:Тест новых тарифов Бизнес-Оптимум|en:New Business-Optimum tariff tests');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-9, 'G', TRUE, -8, 'ru:Тест новых тарифов Бизнес-Оптимум|en:New Business-Optimum tariff tests');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-10, 'I', TRUE, -9, 'ru:Тест новых тарифов Бизнес-Премиум|en:New Business-Premium tariff tests');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-11, 'K', TRUE, -9, 'ru:Тест новых тарифов Бизнес-Премиум|en:New Business-Premium tariff tests');
insert into booking_classes (booking_class_id, code, miles_are_charged, airline_tariff_group_id, text_comment) values (-12, 'A', TRUE, -10, 'ru:ruA|en:enA');

insert into service_classes_limits (service_classes_limit_id, airline_sc_id, pair_id) values (-1, -3, -2);
insert into service_classes_limits (service_classes_limit_id, airline_sc_id, pair_id) values (-3, -8, -13);


insert into redemption_zones (redemption_zone, names) values ('XX','ru:XXX|en:YYY');
insert into redemption_zones (redemption_zone, names) values ('XY','ru:XXX|en:YYY');
insert into redemption_zones (redemption_zone, names) values ('XZ','ru:XXX|en:YYY');
insert into redemption_zones (redemption_zone, names) values ('XV','ru:XXX|en:YYY');

insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-1, 'XXXZXY', 'XX', 'XZ', 'XY', 'A');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-2, 'XXXY', 'XX', NULL, 'XY', 'A');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-3, 'XXXZ', 'XX', NULL, 'XZ', 'A');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-4, 'XXXV', 'XX', NULL, 'XV', 'A');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-5, 'XZXV', 'XZ', NULL, 'XV', 'A');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-6, 'XZXXXV', 'XZ', 'XX', 'XV', 'A');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-7, 'SXSZ', 'SX', NULL, 'SZ', 'S');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-8, 'SZSXXV', 'SZ', 'SX', 'XV', 'S');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-9, 'XVSX', 'XV', NULL, 'SX', 'S');
insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-10, 'XXXVXX', 'XX', 'XV', 'XX', 'A');

insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-1, 'OW', -1, NULL, 100, -1);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-2, 'RT', -1, NULL, 200, -1);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-3, 'OW', -2, NULL, 300, -1);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-4, 'RT', -2, NULL, 400, -1);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-5, 'U', -1, -2, 500, -1);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-6, 'UC', -1, -2, 600, -1);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-10, 'OW', -1, NULL, 1000, -3);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-11, 'RT', -1, NULL, 2000, -3);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-12, 'OW', -2, NULL, 3000, -3);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-13, 'RT', -2, NULL, 4000, -3);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-14, 'U', -1, -2, 5000, -3);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-15, 'UC', -1, -2, 6000, -3);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-20, 'OW', -1, NULL, 1, -6);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-30, 'OW', -1, NULL, 2, -7);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-40, 'OW', -1, NULL, 3, -8);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-50, 'OW', -1, NULL, 4, -9);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-60, 'OW', -1, NULL, 100, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-61, 'RT', -1, NULL, 200, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-62, 'OW', -3, NULL, 300, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-63, 'RT', -3, NULL, 400, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-64, 'U', -1, -3, 500, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-65, 'UC', -1, -3, 600, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-66, 'UO', -1, -3, 700, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-67, 'U', -1, -2, 800, -4);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-70, 'OW', -1, NULL, 100, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-71, 'RT', -1, NULL, 200, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-72, 'OW', -3, NULL, 300, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-73, 'RT', -3, NULL, 400, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-74, 'U', -1, -3, 500, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-75, 'UC', -1, -3, 600, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-76, 'UO', -1, -3, 700, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-77, 'U', -1, -2, 800, -10);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-80, 'U', -1, -2, 100, -5);
insert into awards (award_id, award_type, skyteam_service_class_id_1, skyteam_service_class_id_2, award_value, bonus_route_id) values (-81, 'UC', -1, -2, 200, -5);

insert into wrong_routes (wrong_route_id, city_from_id, city_via_id, city_to_id) values (-1, -2, -4, -1);
insert into wrong_routes (wrong_route_id, city_from_id, city_via_id, city_to_id) values (-2, -2, -3, -1);
    '''
    runSQL(sql_text)


sql_text = u'''
insert into countries (country, iso_code3, names) values ('XX', 'XXX', 'ru:XXX|en:YYY');

insert into countries (country, iso_code3, names) values ('YY', 'YYY', 'ru:XXX|en:YYY');
insert into countries (country, iso_code3, names) values ('ZZ', 'ZZZ', 'ru:XXZ|en:YYZ');

insert into cities (city_id, country, names, tz) values (-1, 'XX', 'ru:XXX|en:YYY', 'ZZZ');
insert into cities (city_id, country, names, tz) values (-2, 'XX', 'ru:XXX|en:YYY', 'ZZZ');
insert into cities (city_id, country, names, tz) values (-3, 'ZZ', 'ru:XXZ|en:YYZ', 'ZZZ');

insert into partner_categories (partner_category_id, status, names) values (-1, 'U', 'ru:XXX|en:YYY');
insert into partner_categories (partner_category_id, status, names) values (-2, 'P', 'ru:XXX|en:YYY');

insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, spec_offer_comm, weight, new_until) values (-1, 'U', 'ru:XXX|en:YYY', 'en:http://some.url', '-1,-2', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 'A', 'ru:Сецпредложение|en:SpecialOffer', 0, '2015-04-10');
insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, spec_offer_comm, mile_get_comm, mile_waste_comm, short_descr, weight, new_until) values (-2, 'P', 'ru:XXX|en:YYY', 'en:some.en|ru:http://some.ru', '-1', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 'A', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 0, '2015-03-13');
insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, short_descr, weight, new_until) values (-3, 'P', 'ru:XXX|en:YYY', 'en:http://some.url', '-1,-2', 'ru:<p>XXXXXX</p>|en:<p>YYYYYYYYY</p>', 'S', 'ru:XXX|en:YYY', 0, '2015-03-14');
insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, short_descr, weight, new_until) values (-4, 'P', 'ru:XXX|en:YYY', 'en:http://some.url', '-1,-2', 'ru:<p>XXXXXX</p>|en:<p>YYYYYYYYY</p>', 'S', 'ru:XXX|en:YYY', 0, '2015-03-15');
insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, short_descr, weight, new_until) values (-5, 'P', 'ru:XXZ|en:YYZ', 'en:http://some.url', '-1,-2', 'ru:<p>XXXXXX</p>|en:<p>YYYYYYYYY</p>', 'S', 'ru:XXX|en:YYY', 0, '2015-03-16');
insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, short_descr, weight, new_until) values (-6, 'P', 'ru:XXX|en:YYY', 'en:http://some.url', '-1,-2', 'ru:<p>XXXXXXXXX</p>|en:<p>YYYYYY</p>', 'S', 'ru:XXX|en:YYY', 0, '2015-03-17');
insert into partners (partner_id, status, names, url, partner_categories, partner_description, mile_action, short_descr, weight, new_until) values (-7, 'P', 'ru:XXZ|en:YYZ', 'en:http://some.url', '-1,-2', 'ru:<p>XXXXXXXXX</p>|en:<p>YYYYYY</p>', 'S', 'ru:XXX|en:YYY', 0, '2015-03-18');

insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, worktime, office_type) values (-1, -1, -1, 77.77, 77.77, 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'M');
insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, worktime, office_type) values (-2, -2, -2, 55.55, 55.55, 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'O');
insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, worktime, office_type) values (-3, -2, -1, 77.77, 77.77, 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'M');
insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, worktime, office_type) values (-4, -4, -3, 55.55, 55.55, 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'O');
insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, worktime, office_type) values (-5, -4, -1, 77.77, 77.77, 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'M');
insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, worktime, office_type) values (-6, -4, -3, 55.55, 55.55, 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'ru:XXX|en:YYY', 'O');

insert into partner_office_contacts (partner_office_contact_id, partner_office_id, contact_type, contact, main_contact) values (-1, -1, 'E', 'some@some.ru', true);
insert into partner_office_contacts (partner_office_contact_id, partner_office_id, contact_type, contact, main_contact) values (-2, -1, 'E', 'some@some.ru', false);
insert into partner_office_contacts (partner_office_contact_id, partner_office_id, contact_type, contact, main_contact) values (-3, -5, 'E', 'some@some.ru', false);

insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-1, -2, 'S', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 77, 'P', 1);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-2, -2, 'E', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 77, 'P', 2);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-3, -2, 'S', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 77, 'U', 3);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-4, -2, 'E', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 77, 'U', 4);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-5, -1, 'S', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 1, 'P', 5);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-6, -1, 'E', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 1, 'P', 6);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-7, -1, 'S', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 2, 'P', 7);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-8, -1, 'E', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 2, 'P', 8);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-9, -1, 'S', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 3, 'U', 9);
insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status, miles) values (-10, -1, 'E', 'ru:<p>XXXXXX</p>|en:<p>YYYYYY</p>', 3, 'U', 10);

insert into special_offers (offer_id, partner_id, names, status, offer_description, offer_url, ui_languages) values (-1, -2, 'en:Super special offer|ru:Мега специальное предложение', 'P', 'en:Super special offer description|ru:Описание мега специального предложения|fr:<p>XXXXXX</p>', 'ru:/cms/ru/123|en:/cms/en/123', 'en,ru');
insert into special_offers (offer_id, partner_id, names, begin_date, end_date, status, offer_description, offer_url, ui_languages) values (-2, -1, 'en:Super special offer|ru:Мега специальное предложение', '2014-12-03 10:00:00+03', '2015-01-13 10:00:00+03', 'P', 'en:Super special offer description|ru:Описание мега специального предложения', 'ru:http://ya.ru|en:http://ya.com', 'en');
insert into special_offers (offer_id, partner_id, names, status, offer_description, offer_url, ui_languages) values (-3, -4, 'en:Super special offer|ru:Мега специальное предложение', 'P', 'en:Super special offer description|ru:Описание мега специального предложения', 'ru:/cms/ru/123|en:/cms/en/123', '');
    '''
def createPartnerTestData():
    runSQL(sql_text)


def setup_vocabulary(vocab_class):
    IRegisterableVocabulary(vocab_class).register()
    vocab = getV(vocab_class.regName)
    if hasattr(vocab, 'preload'):
        vocab.preload()
    return vocab
