# -*- coding: utf-8 -*-

"""
$Id: test_air_models.py 13272 2015-06-09 16:07:00Z ogambaryan $
"""
import mock
import testoob

import _test_data

from zope.schema import getFieldsInOrder
from zope.schema.interfaces import ITokenizedTerm

from pyramid.i18n.message import Message
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs, TestCaseWithI18N)
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.vocabulary.interfaces import IVocabulary
import pyramid.vocabulary.mvcc

from rx.i18n.translation import SelfTranslationDomain

import models.air
import models.interfaces


class TestAirline(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirline, self).setUp()
        self.model = models.air.Airline
        self.iface = models.interfaces.IAirline
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.air.AirlinesVocabulary)

    def test_model(self):
        ob = self.model.load(airline_id=-1)
        self.assertEqual(15, len(getFieldsInOrder(self.iface)))

        self.assertEqual(-1, ob.airline_id)
        self.assertEqual('SU', ob.iata)
        self.assertEqual('AFL', ob.icao)
        self.assertEqual(None, ob.callsign)
        self.assertEqual('XX', ob.country)
        self.assertEqual(-3, ob.airport_id)
        self.assertEqual([u'en:Aeroflot', u'ru:Аэрофлот'], ob.names)
        self.assertEqual('SkyTeam', ob.alliance)
        self.assertEqual(None, ob.parent_airline_id)
        self.assertEqual([u'en:http://site.en', u'ru:site.ru'], ob.url)
        self.assertEqual(1, ob.weight)
        self.assertEqual(500.0, ob.miles_minimum)
        self.assertEqual('A', ob.miles_limitation)
        self.assertEqual(['ru:XXXX', 'en:YYYY'], ob.miles_earn_comment)
        self.assertEqual(['ru:XXX', 'en:YYY'], ob.miles_earn_description)

    def test_children(self):
        ob = self.model.load(airline_id=-1)
        self.assertTrue(isinstance(ob.children, list))
        self.assertEqual(1, len(ob.children))
        self.assertTrue(isinstance(ob.children[0], self.model))
        self.assertEqual(-6, ob.children[0].airline_id)

        ob = self.model.load(airline_id=-2)
        self.assertTrue(isinstance(ob.children, list))
        self.assertEqual(0, len(ob.children))

    def test_sort_title(self):
        ob = self.model.load(airline_id=-1)
        self.assertTrue(isinstance(ob.sort_title, basestring))
        self.assertEqual(ob.sort_title, "Aeroflot")


class TestAirlineI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def testModelTitles(self):
        ob = models.air.Airline.load(airline_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'Aeroflot', SelfTranslationDomain().translate(ob.title.msgid))
        self.assertEqual(u'http://site.en', SelfTranslationDomain().translate(ob.url_local.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'Аэрофлот', SelfTranslationDomain().translate(ob.title.msgid))
        self.assertEqual(u'http://site.ru', SelfTranslationDomain().translate(ob.url_local.msgid))

    @mock.patch('config.SKYTEAM_FILES_URL', 'http://localhost/fake_static')
    def test_logo_urls(self):
        ob = models.air.Airline.load(airline_id=-1)
        self.assertTrue(isinstance(ob.default_logo_url, Message))

        logo_url_en = SelfTranslationDomain().translate(ob.default_logo_url.msgid)
        self.assertEqual(logo_url_en, 'http://localhost/fake_static/logo_int/-1.jpg')

        self.negotiator.lang = 'ru'
        logo_url_ru = SelfTranslationDomain().translate(ob.default_logo_url.msgid)
        self.assertEqual(logo_url_ru, 'http://localhost/fake_static/logo_rus/-1.jpg')


class TestAirlinesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlinesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.air.AirlinesVocabulary)

    def testVocabulary(self):
        v = getV('airlines')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertIn('-1', v)
        self.assertNotIn('-7', v)

        ob = v['-1']
        self.assertTrue(isinstance(ob, models.air.Airline))
        self.assertEqual(ob.names, [u'en:Aeroflot', u'ru:Аэрофлот'])


class TestAirlinesByIATAIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlinesByIATAIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.air.AirlinesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.air.AirlinesByIATAIndexer),
                                  'airlines_by_iata_ids')

    def test_add(self):
        vocab = getV('airlines')
        idx = getVI('airlines_by_iata_ids')

        self.assertEqual(len(idx(context='SU')), 1)
        self.assertTrue(isinstance(idx(context='SU')[0], models.air.Airline))
        self.assertEqual(idx(context='SU')[0].iata, u'SU')

        self.assertEqual(len(idx(context='AA')), 0)

        ob = models.air.Airline(
            airline_id=-7,
            iata='AA',
            names=[u'ru:KKK', u'en:LLL'],
            miles_minimum=0.0,
            miles_limitation='N'
        )

        vocab.update_many([ob])

        self.assertIn(-7, vocab)
        self.assertEqual(len(idx(context='AA')), 0)

        idx._reindex()

        self.assertEqual(len(idx(context='AA')), 1)
        self.assertTrue(isinstance(idx(context='AA')[0], models.air.Airline))
        self.assertEqual(idx(context='AA')[0].iata, 'AA')

    def test_change(self):
        vocab = getV('airlines')
        idx = getVI('airlines_by_iata_ids')

        self.assertEqual(len(idx(context='SU')), 1)
        self.assertEqual(len(idx(context='AA')), 0)

        ob = models.air.Airline(
            airline_id=-1,
            iata='AA',
            icao='AFL',
            names=[u'ru:Аэрофлот', u'en:Aeroflot'],
            miles_minimum=0.0,
            miles_limitation='N'
        )

        vocab.update_many([ob])

        self.assertEqual(len(idx(context='SU')), 1)
        self.assertEqual(len(idx(context='AA')), 0)

        idx._reindex()

        self.assertEqual(len(idx(context='SU')), 0)
        self.assertEqual(len(idx(context='AA')), 1)
        self.assertEqual(idx(context='AA')[0].airline_id, -1)

    def test_delete(self):
        vocab = getV('airlines')
        idx = getVI('airlines_by_iata_ids')

        self.assertEqual(len(idx(context='SU')), 1)

        ob = idx(context='SU')[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('-1', vocab)
        self.assertEqual(len(idx(context='SU')), 1)

        idx._reindex()

        self.assertEqual(len(idx(context='SU')), 0)


if __name__ == "__main__":
    testoob.main()
