# -*- coding: utf-8 -*-

"""
$Id: test_ui_csrf.py 3840 2014-03-13 14:49:05Z kmakarov $
"""

import cherrypy
import testoob

from pyramid.tests.testlib import TestCaseWithCP
import ui.csrf


class TestChecks(TestCaseWithCP):
    STOP_SERVER = True

    def setUp(self):
        super(TestChecks, self).setUp()

    def test_check_ajax(self):
        cherrypy.request.headers['origin'] = ui.csrf.REFERER_PREFIX
        self.assertIsNone(ui.csrf.check_ajax())

        cherrypy.request.headers['origin'] = None
        cherrypy.request.headers['x-requested-with'] = 'xmlhttprequest'
        self.assertIsNone(ui.csrf.check_ajax())

        cherrypy.request.headers['x-requested-with'] = ''
        self.assertRaises(ui.csrf.CSRFRejected, ui.csrf.check_ajax)

        # имитируем поведение Chrome
        cherrypy.request.headers['origin'] = 'http://bad.domain.org'
        self.assertRaises(ui.csrf.CSRFRejected, ui.csrf.check_ajax)


if __name__ == "__main__":
    testoob.main()
