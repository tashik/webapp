# -*- coding: utf-8 -*-

"""
$Id: test_services_json_airline.py 13304 2015-06-10 16:31:42Z ogambaryan $
"""

import mock
import cherrypy
import json
import testoob

from zope.component import globalSiteManager

from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
import pyramid.vocabulary.mvcc
from rx.i18n.translation import SelfTranslationDomain

import _test_data

import models.air
import models.bonus
import models.geo

from services.json_services.airline import  AirlineInfoJSONService


def success_response_check(self, response):
    u"""Проверка заголовка JSON успешного ответа"""

    ob = json.loads(response)
    self.assertEqual(3, len(ob))
    self.assertTrue('isSuccess' in ob)
    self.assertTrue('data' in ob)
    self.assertTrue('errors' in ob)
    self.assertEqual(True, ob['isSuccess'])
    self.assertEqual([], ob['errors'])
    self.assertFalse(ob['data'] is None)
    return ob['data']


class TestAirlineInfoService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlineInfoService, self).setUp()
        self.td = SelfTranslationDomain()
        globalSiteManager.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        globalSiteManager.unregisterUtility(self.td)
        super(TestAirlineInfoService, self).tearDown()

    def registerVocabularies(self):
        super(TestAirlineInfoService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.air.AirlinesVocabulary)
        _test_data.setup_vocabulary(models.geo.AirportsVocabulary)
        _test_data.setup_vocabulary(models.bonus.SkyTeamServiceClassesVocabulary)
        _test_data.setup_vocabulary(models.bonus.AirlineTariffGroupsVocabulary)
        _test_data.setup_vocabulary(models.bonus.BookingClassesVocabulary)
        _test_data.setup_vocabulary(models.bonus.AirlineServiceClassesVocabulary)
        _test_data.setup_vocabulary(models.bonus.TierLevelsVocabulary)
        _test_data.setup_vocabulary(models.bonus.TierLevelFactorsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineServiceClassesByAirlineIndexer), 'airline_service_classes_by_airline_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.AirlineTariffGroupsByAirlineServiceClassIndexer), 'airline_tariff_groups_by_airline_service_class_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.BookingClassesByAirlineTariffGroupIndexer), 'booking_classes_by_airline_tariff_group_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.bonus.TierLevelFactorsByAirlineIndexer), 'tier_level_factors_by_airline_idx')

    @mock.patch('logic.geo.LOG')
    def test_service(self, mock_log):
        svc = AirlineInfoJSONService()
        response = svc.v001(airline=-1)

        data = success_response_check(self, response)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(19, len(data))
        self.assertEqual(-1, data['id'])
        self.assertEqual('SU', data['iata'])
        self.assertEqual('AFL', data['icao'])
        self.assertEqual(None, data['callsign'])
        self.assertEqual('XX', data['country'])
        self.assertEqual('SkyTeam', data['alliance'])
        self.assertEqual({'en': 'Aeroflot', 'ru': u'Аэрофлот'}, data['title'])
        self.assertEqual(None, data['parent'])
        self.assertEqual({'ru': 'site.ru', 'en': 'http://site.en'}, data['url'])
        self.assertEqual(1, data['weight'])
        self.assertEqual('XXA', data['airport'])
        self.assertEqual(500.0, data['miles_minimum'])
        self.assertEqual('A', data['miles_limitation'])
        self.assertEqual({'ru': u'XXX', 'en': u'YYY'}, data['earn_description'])
        self.assertEqual({'ru': u'XXXX', 'en': u'YYYY'}, data['earn_text'])

        miles_table = data['miles_table']
        self.assertEqual(2, len(miles_table))
        self.assertIn('en', miles_table[0][0])
        self.assertIn('ru', miles_table[0][0])
        self.assertEqual(u'Business', miles_table[0][0]['en'])
        self.assertEqual(u'Бизнес', miles_table[0][0]['ru'])
        self.assertIn('en', miles_table[1][0])
        self.assertIn('ru', miles_table[1][0])
        self.assertEqual(u'YYY', miles_table[1][0]['en'])
        self.assertEqual(u'XXX', miles_table[1][0]['ru'])
        self.assertEqual(1, len(miles_table[0][1]))
        self.assertEqual(2, len(miles_table[1][1]))
        self.assertIn([[{'note': 1, 'code': u'A', 'id': -4}], 150], miles_table[0][1])
        self.assertIn([[{'note': 2, 'code': u'A', 'id': -1}], 75], miles_table[1][1])
        self.assertIn([[], 100], miles_table[1][1])

        bcc = data['booking_class_comments']
        self.assertEqual(2, len(bcc))
        self.assertEqual(1, bcc[0][0])
        self.assertIn('ru', bcc[0][1])
        self.assertIn('en', bcc[0][1])
        self.assertEqual(u'ruAAA', bcc[0][1]['ru'])
        self.assertEqual(u'enAAA', bcc[0][1]['en'])
        self.assertEqual(2, bcc[1][0])
        self.assertIn('ru', bcc[1][1])
        self.assertIn('en', bcc[1][1])
        self.assertEqual(u'ruA', bcc[1][1]['ru'])
        self.assertEqual(u'enA', bcc[1][1]['en'])

        ec = data['elite_coefficients']
        self.assertEqual(2, len(ec))
        self.assertEqual(u'silver', ec[0][0])
        self.assertEqual(25.0, ec[0][1])
        self.assertEqual(u'xxx', ec[1][0])
        self.assertEqual(75.0, ec[1][1])

        response = svc.v001(airline=-3)
        data = success_response_check(self, response)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(19, len(data))
        self.assertEqual(len(data['children']), 1)
        child = data['children'][0]
        self.assertTrue(isinstance(child, dict))
        self.assertEqual(4, len(child))
        self.assertEqual(-5, child['id'])
        self.assertEqual('VN', child['iata'])
        self.assertEqual({'en':'Vietnam Airlines', 'ru': 'Vietnam Airlines'}, child['title'])
        self.assertEqual({'en': 'site.com', 'ru': 'site.com'}, child['url'])

        response = svc.v001(airline=-5)
        data = success_response_check(self, response)
        self.assertTrue(isinstance(data, dict))
        self.assertEqual(19, len(data))
        self.assertTrue(data['parent'])
        parent = data['parent']
        self.assertTrue(isinstance(parent, dict))
        self.assertEqual(4, len(parent))
        self.assertEqual(-3, parent['id'])
        self.assertEqual('RO', parent['iata'])
        self.assertEqual({'en':'Tarom', 'ru': u'Авиакомпания Tarom'}, parent['title'])
        self.assertEqual({'en': 'site.com', 'ru': 'site.com'}, parent['url'])

    def test_HTTPError_airline(self):
        svc = AirlineInfoJSONService()
        try:
            svc.v001(airline=-100)
        except Exception, e:
            self.assertTrue(isinstance(e, cherrypy.HTTPError), e.__class__)
            self.assertEqual(404, e.status)

    @mock.patch('logic.geo.LOG')
    def test_service_lang(self, mock_log):
        svc = AirlineInfoJSONService()
        response = svc.v001(lang='en', airline=-1)

        airline = success_response_check(self, response)

        self.assertEqual(1, len(airline['title']))
        self.assertIn('en', airline['title'])
        self.assertNotIn('ru', airline['title'])
        self.assertEqual('Aeroflot', airline['title']['en'])

        self.assertEqual(1, len(airline['url']))
        self.assertIn('en', airline['url'])
        self.assertNotIn('ru', airline['url'])
        self.assertEqual('http://site.en', airline['url']['en'])
        self.assertEqual('YYY', airline['earn_description']['en'])
        self.assertEqual('YYYY', airline['earn_text']['en'])

        child = airline['children'][0]

        self.assertEqual(1, len(child['title']))
        self.assertIn('en', child['title'])
        self.assertNotIn('ru', child['title'])
        self.assertEqual('Vietnam Airlines', child['title']['en'])

        self.assertEqual(1, len(child['url']))
        self.assertIn('en', child['url'])
        self.assertNotIn('ru', child['url'])
        self.assertEqual('site.com', child['url']['en'])

        miles_table = airline['miles_table']
        self.assertIn('en', miles_table[0][0])
        self.assertNotIn('ru', miles_table[0][0])
        self.assertEqual(u'Business', miles_table[0][0]['en'])
        self.assertIn('en', miles_table[1][0])
        self.assertNotIn('ru', miles_table[1][0])
        self.assertEqual(u'YYY', miles_table[1][0]['en'])

        bcc = airline['booking_class_comments']
        self.assertEqual(2, len(bcc))
        self.assertEqual(1, bcc[0][0])
        self.assertNotIn('ru', bcc[0][1])
        self.assertIn('en', bcc[0][1])
        self.assertEqual(u'enAAA', bcc[0][1]['en'])
        self.assertEqual(2, bcc[1][0])
        self.assertNotIn('ru', bcc[1][1])
        self.assertIn('en', bcc[1][1])
        self.assertEqual(u'enA', bcc[1][1]['en'])

    @mock.patch('logic.geo.LOG')
    def test_service_langWrong(self, mock_log):
        svc = AirlineInfoJSONService()
        response = svc.v001(lang='fr', airline=-1)

        airline = success_response_check(self, response)

        self.assertEqual(2, len(airline['title']))
        self.assertNotIn('fr', airline['title'])
        self.assertEqual(airline['title'], {'ru': u'Аэрофлот', 'en': 'Aeroflot'})

        self.assertEqual(2, len(airline['url']))
        self.assertNotIn('fr', airline['url'])
        self.assertEqual(airline['url'], {'ru': u'site.ru', 'en': 'http://site.en'})

    @mock.patch('logic.geo.LOG')
    def test_service_excessiveParams(self, mock_log):
        svc = AirlineInfoJSONService()
        response = svc.v001(param1='a', airline=-1, some_other='1234')

        airline = success_response_check(self, response)

        self.assertTrue(isinstance(airline, dict), airline.__class__)
        self.assertEqual(19, len(airline))


if __name__ == '__main__':
    testoob.main()
