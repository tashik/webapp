# -*- coding: utf-8 -*-

"""
$Id: $
"""

#import mock
import testoob

from lxml import etree

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary
import models.air
import models.geo
import models.route

from services.base.xml_base import ParamsValidationError
from services.xml_services.airline import AirlinesByRouteXMLService


class TestAirlinesByRouteXMLService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def setUp(self):
        super(TestAirlinesByRouteXMLService, self).setUp()
        self.s = AirlinesByRouteXMLService()

    def registerVocabularies(self):
        super(TestAirlinesByRouteXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AirlinesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        setup_vocabulary(models.route.PairsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer), 'airports_by_city_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer), 'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer), 'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.route.AllPairsByCtxIndexer), 'all_pairs_by_ctx_idx')

    def test_airlines_by_route_v001_invalid_parameters(self):
        self.assertRaises(ParamsValidationError, self.s.airlines_by_route_v001, 'XXX', 'SSS')
        self.assertRaises(ParamsValidationError, self.s.airlines_by_route_v001, 'SSS', 'XXX')

    def test_airlines_by_route_v001_airports(self):
        data = self.s.airlines_by_route_v001('XXX', 'XXA')
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/airlines'))
        self.assertEqual(len(xml.xpath('/airlines/airline')), 3)

        self.assertTrue(xml.xpath('/airlines/airline[@code="RO"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="SU"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="ST"]'))

    def test_airlines_by_route_v001_cities(self):
        data = self.s.airlines_by_route_v001('UUX', 'UUZ')
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/airlines'))
        self.assertEqual(len(xml.xpath('/airlines/airline')), 2)

        self.assertFalse(xml.xpath('/airlines/airline[@code="RO"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="SU"]'))
        self.assertTrue(xml.xpath('/airlines/airline[@code="ST"]'))

    def test_airlines_by_route_v001_no_data(self):
        data = self.s.airlines_by_route_v001('XXC', 'XXD')
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/airlines'))
        self.assertFalse(xml.xpath('/airlines/airline'))


if __name__ == "__main__":
    testoob.main()
