# -*- coding: utf-8 -*-

"""
$Id:
"""

import mock
import testoob
import unittest

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
from _test_data import setup_vocabulary

import logic.geo
import models.geo


class TestLogicGeo(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createSkyteamTestData,)

    def registerVocabularies(self):
        super(TestLogicGeo, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        setup_vocabulary(models.geo.AirportsVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer),
                                  'cities_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByIATAIndexer),
                                  'airports_by_iata_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.AirportsByCityIndexer),
                                  'airports_by_city_idx')

    @mock.patch('logic.geo.LOG')
    def test_load_airport(self, mock_log):
        ob = logic.geo.load_airport(-1)
        self.assertTrue(isinstance(ob, models.geo.Airport))
        self.assertTrue(ob.iata, 'XXX')

        ob = logic.geo.load_airport(-100)
        self.assertIsNone(ob)
        self.assertEqual(mock_log.call_count, 1)

    @mock.patch('logic.geo.LOG')
    def test_load_city(self, mock_log):
        ob = logic.geo.load_city(-1)
        self.assertTrue(isinstance(ob, models.geo.City))
        self.assertTrue(ob.iata, 'UUX')

        ob = logic.geo.load_city(-100)
        self.assertIsNone(ob)
        self.assertEqual(mock_log.call_count, 1)

    @mock.patch('logic.geo.LOG')
    def test_load_country(self, mock_log):
        ob = logic.geo.load_country('XX')
        self.assertTrue(isinstance(ob, models.geo.Country))
        self.assertTrue(ob.iso_code3, 'XXX')

        ob = logic.geo.load_country('ZZ')
        self.assertIsNone(ob)
        self.assertEqual(mock_log.call_count, 1)

    def test_load_airport_by_iata(self):
        ob = logic.geo.load_airport_by_iata('XXX')
        self.assertTrue(isinstance(ob, models.geo.Airport))
        self.assertTrue(ob.airport_id, -1)

        ob = logic.geo.load_airport_by_iata('AAA')
        self.assertIsNone(ob)

    def test_load_city_by_iata(self):
        ob = logic.geo.load_city_by_iata('UUX')
        self.assertTrue(isinstance(ob, models.geo.City))
        self.assertTrue(ob.city_id, -1)

        ob = logic.geo.load_city_by_iata('AAA')
        self.assertIsNone(ob)

    def test_iata_valid(self):
        self.assertTrue(logic.geo.iata_valid, 'XXX')
        self.assertTrue(logic.geo.iata_valid, 'UUX')
        self.assertTrue(logic.geo.iata_valid, 'AAA')

    def test_get_airports_by_iata(self):
        # airport found
        obs = logic.geo.get_airports_by_iata('XXX')
        self.assertEqual(len(obs), 1)
        self.assertTrue(isinstance(obs[0], models.geo.Airport))
        self.assertTrue(obs[0].airport_id, -1)

        # airport not found, city found
        obs = logic.geo.get_airports_by_iata('UUX')
        self.assertEqual(len(obs), 3)
        self.assertTrue(isinstance(obs[0], models.geo.Airport))
        self.assertIn(-3, [ob.airport_id for ob in obs])
        self.assertIn(-7, [ob.airport_id for ob in obs])
        self.assertIn(-8, [ob.airport_id for ob in obs])

        # airport not found, city not found
        obs = logic.geo.get_airports_by_iata('AAA')
        self.assertEqual(len(obs), 0)

        # airport exists and city exists
        obs = logic.geo.get_airports_by_iata('FFB')
        self.assertEqual(len(obs), 1)
        self.assertTrue(isinstance(obs[0], models.geo.Airport))
        self.assertTrue(obs[0].airport_id, -11)

    @mock.patch('logic.geo.LOG')
    def test_get_airport_city(self, mock_log):
        ob = logic.geo.get_airport_city(-1)
        self.assertTrue(ob.city_id, -1)

        ob = logic.geo.get_airport_city(-100)
        self.assertIsNone(ob)
        self.assertEqual(mock_log.call_count, 1)


if __name__ == "__main__":
    testoob.main()

