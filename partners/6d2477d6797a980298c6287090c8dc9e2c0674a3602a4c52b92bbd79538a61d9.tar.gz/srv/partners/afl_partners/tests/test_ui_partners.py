# -*- coding: utf-8 -*-
"""
$Id: test_ui_partners.py 20345 2016-08-16 19:38:58Z oeremeeva $
"""
import cherrypy
from lxml import etree
import testoob
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests import testlib
import pyramid.vocabulary
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

import _test_data
import _test_ui_common

import models.geo
import models.partner
import models.special_offer
from ui import partners


class TestPartnerPage(_test_ui_common.StdUITest, testlib.TestCaseWithLenientRoutes):
    _test_data_initializers = (_test_data.createPartnerTestData,)

    def register_vocabs(self):
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.partner.PartnersVocabulary)
        _test_data.setup_vocabulary(models.partner.PartnerCategoriesVocabulary)
        _test_data.setup_vocabulary(models.partner.PartnerOfficesVocabulary)
        _test_data.setup_vocabulary(models.partner.PartnerAwardConditionsVocabulary)
        _test_data.setup_vocabulary(models.geo.CitiesVocabulary)
        _test_data.setup_vocabulary(models.geo.CountriesVocabulary)
        _test_data.setup_vocabulary(models.special_offer.SpecialOffersVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.partner.PartnerAwardConditionsByPartnerIndexer),
                                  'partner_awards_conditions_by_partner_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.special_offer.SpecialOffersByPartnerIndexer),
                                  'special_offers_by_partner_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByIATAIndexer),
                                  'cities_by_iata_idx')

    def setUp(self):
        super(TestPartnerPage, self).setUp()
        self.page = partners.PartnerPage()
        cherrypy.request.current_locale = 'ru'
        cherrypy.request.current_lang = 'ru'

    def test_partner_page(self):
        self.assertRaises(cherrypy.HTTPError, self.page.index, ("-1",))     # Unpublished Partner.
        body = self.page.index(-2)
        body = self.stripBody(body).replace("&nbsp;", "")
        xml = etree.fromstring(body)
        self.assertEqual(4, len(xml.xpath('/div[@class="content"]/div[@id="pp"]/div[@id="ppTabsContainer"]/div[@id="ppTabs"]/div')))
        self.assertEqual(4, len(xml.xpath('/div[@class="content"]/div[@id="pp"]/div[@id="ppTabsContainer"]/div[@id="ppTabs"]/ul/li')))
        self.assertEqual(1, len(xml.xpath('/div[@class="content"]/div[@id="pp"]/div[@id="ppTabsContainer"]/div[@id="ppTabs"]/div[@id="ppTabsContacts"]/div[@id="ppContactsForm"]/form')))


if __name__ == "__main__":
    testoob.main()
