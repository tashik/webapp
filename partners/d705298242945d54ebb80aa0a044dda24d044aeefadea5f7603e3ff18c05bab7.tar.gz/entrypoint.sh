#!/bin/bash

set -e

: ${PGHOST:=db-partners}
: ${PGPORT:=5432}
: ${PGUSER:=partners}
: ${PGDATABASE:=$PGUSER}

export PGHOST PGPORT PGUSER PGDATABASE

# если конфиги отсутствуют, создаем их на основе шаблонов (файлы .tmpl)
if [ ! -e $INSTANCE_HOME/etc/config.py ]
then
  cp $APPDIR/config.py.tmpl $INSTANCE_HOME/etc/config.py
  cp $APPDIR/config_defaults.py.tmpl $INSTANCE_HOME/etc/config_defaults.py

  cat <<EOF >> $INSTANCE_HOME/etc/config.py

import os

SERVER_HOST = '0.0.0.0'

POSTGRES_DSN = """
    host=%(PGHOST)s
    port=%(PGPORT)s
    dbname=%(PGDATABASE)s
    user=%(PGUSER)s
    password=
""" % os.environ

APP_COOKIE='prtn_'

EOF

fi

if [ ! -e $INSTANCE_HOME/etc/cpconfig.py ]
then
  cp $APPDIR/cpconfig.py.tmpl $INSTANCE_HOME/etc/cpconfig.py

  sed -i -e "s/'tools.trusted_proxy.on'/#'tools.trusted_proxy.on'/" $INSTANCE_HOME/etc/cpconfig.py
fi

mkdir -p $INSTANCE_HOME/log/errors

cd $APPDIR

exec $@
