#export C_FORCE_ROOT='1'
export INSTANCE_HOME=/srv/tms
export PYTHONPATH=$INSTANCE_HOME/lib/python2.7/site-packages
export PATH=$INSTANCE_HOME/bin:$PATH
