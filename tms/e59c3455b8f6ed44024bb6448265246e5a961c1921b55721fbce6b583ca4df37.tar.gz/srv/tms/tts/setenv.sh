#!/bin/bash
# Call `source setenv.sh` to set environment variables

export LC_CTYPE=ru_RU.UTF-8
export PATH=$HOME/bin:$PATH
export PYTHONPATH=$HOME/lib:$HOME/lib/python2.7/site-packages

