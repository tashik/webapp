#!/bin/sh

TTSHOME=/var/lib/jenkins/tts
tracd -d -b localhost -p 3051 --pidfile=$TTSHOME/tracd.3051 --protocol=http -e $TTSHOME
