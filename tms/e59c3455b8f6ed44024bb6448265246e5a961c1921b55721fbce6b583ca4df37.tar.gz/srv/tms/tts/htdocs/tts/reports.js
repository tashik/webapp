jQuery(document).ready(function($) {
    var $report_date = $('input[name="report_date"]');
    var $period_start = $('input[name="period_start"]');
    var $period_end = $('input[name="period_end"]');

    $('select[name="report_type"]').change(function (){
        var type = $(this).val();
        var $report_date_block = $('#report_date_block');
        var $report_period_block = $('#report_period_block');

        if (!type){
            $report_date_block.hide();
            $report_period_block.hide();
        }

        if (type=='date'){
            $report_date_block.show();
            $report_period_block.hide();
            $period_start.val('');
            $period_end.val('');
            $report_date.datepicker('setDate', '-0d');
        }

        if (type=='period'){
            $report_date_block.hide();
            $report_period_block.show();
            $report_date.val('');
            $period_start.datepicker('setDate', '-0d');
            $period_end.datepicker('setDate', '-0d');
        }
        hide_show_submit();
    });

    $report_date.change(function(){
        hide_show_submit();
    });

    $period_start.change(function(){
        hide_show_submit();
    });

    $period_end.change(function(){
        hide_show_submit();
    });

    function hide_show_submit(){
        var type = $('select[name="report_type"]').val();
        var report_date = $('input[name="report_date"]').val();
        var period_start = $('input[name="period_start"]').val();
        var period_end = $('input[name="period_end"]').val();

        var $submit = $('button[name="get_report"]');
        if (!type){
            $submit.hide();
            return;
        }

        if (!report_date && type=='date'){
            $submit.hide();
            return;
        }

        if ((!period_start || !period_end) && type=='period'){
            $submit.hide();
            return;
        }

        $submit.show();
    };
});
