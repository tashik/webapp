jQuery(document).ready(function($) {
    var $notices = $('#notices');
    if($notices.is(':empty'))
        return;

    // go to top
	window.scrollTo(0, 0);
});