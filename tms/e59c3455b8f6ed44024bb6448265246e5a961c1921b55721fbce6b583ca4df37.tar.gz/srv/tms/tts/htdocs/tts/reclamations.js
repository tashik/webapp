var langs_indexes = {};

function create_reclamation(){
    var form_data = $('#reclamations_form').serializeArray();
    var data = {};
    for (var i=0; i<form_data.length; i++)
        data[form_data[i].name] = form_data[i].value;

    if(!data['source']){
        var source_label = $('#source').parent().find('label').text();
        alert('Заполните следующие поля:\n' + source_label);
        return;
    }

    if(!data['target']){
        alert('Не указано ни одного замечания');
        return;
    }

    jQuery.ajax({
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        url: ReclamationsData.url,
        data: JSON.stringify(data),
        success: on_sync,
        error: function(o){
            alert('Не удалось создать замечание. Повторите свою попытку позже');
        }
    });

    function on_sync(data){
        $('#reclamations_form')[0].reset();
        location.reload();
    }
};

function add_target(event){
    var lang = $('#langs').val();
    var $lang_target = $('.lang_target');
    var target_text = $lang_target.val();
    var empty_errors = '';
    if (!target_text)
        empty_errors += 'Комментарий к языку';
    if (!lang)
        empty_errors += $('#langs').parent().find('label').text();

    if (empty_errors){
        alert('Заполните следующие поля:\n' + empty_errors);
        return;
    }

    var $li = $('<li class="word_break_all">'+ lang + ':<br> '+ target_text +'</li>');
    $li.click(function(){
        $this = $(this);
        if ($this.hasClass('selected'))
            $this.removeClass('selected');
        else
            $this.addClass('selected');

    });
    $li.data('lang', lang);
    $li.data('target', target_text);

    $('.all_targets').append($li);
    $lang_target.val('');

    $('#langs option[value="'+ lang +'"]').remove();
    var visible_options = $("#langs option:visible");
    if (! $.isEmptyObject(visible_options)){
        var $option = $(visible_options[0]);
        $("#langs").val($option.val());
    }

    update_target();
};

function remove_target(event){

    var selected_lang = $('#langs option:selected').val();
    var $li_objects = $('.all_targets li.selected')
    $li_objects.each(function(){
        var $li = $(this);
        var lang = $li.data('lang');
        $('#langs').append($('<option></option>').val(lang).html(lang));
    });
    $li_objects.remove();
    sort_langs();
    $('#langs option[value=' + selected_lang + ']').prop('selected','selected');
    update_target();
};

function sort_langs(){
    var $options = $("#langs option");
    $options.detach().sort(function(a,b) {
        var a_index = langs_indexes[$(a).val()];
        var b_index = langs_indexes[$(b).val()];
        return (a_index > b_index)?1:((a_index < b_index)?-1:0);
    });

    $options.appendTo("#langs");
}

function update_target(){
    var data = {};
    $('.all_targets li').each(function(){
        var li_data = $(this).data();
        data[li_data.lang] = li_data.target;
    });

    $('#target').val(JSON.stringify(data));
}

jQuery(document).ready(function($) {
	$('#create_reclamation').click(function(i) {
		create_reclamation();
	});

	$('.add_target').click(add_target);
	$('.remove_target').click(remove_target);

    $('#reclamations').click(function(){
        $('.reclamation.plaintext').each(function() {
            $(this).height($(this).prop('scrollHeight'));
        });
    });

    $('#langs option').each(function (index, item){
        langs_indexes[$(item).val()] = index;
    });
});