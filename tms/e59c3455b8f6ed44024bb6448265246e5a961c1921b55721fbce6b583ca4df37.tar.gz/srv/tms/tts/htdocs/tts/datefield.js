jQuery(document).ready(function($) {
    var $fields = $('.datepick');
    $fields.each(function() {
        var $field = $(this);
        var data = $field.data();
        var options = {
            'minDate': data.mindate,
            'maxDate': data.maxdate,
            'dateFormat': 'dd.mm.yy',
        };
        $fields.datepicker(options);
        var field_value = $field.val();
        if (!field_value && data.field_value){
            if (data.field_value == 'now')
                $field.datepicker('setDate', '-0d');
            else
                $field.datepicker('setDate', data.current);
        }

    })
});