jQuery(document).ready(function($) {
    var $sync_button = $('#translation_cost_button');

    $sync_button.click(onClick);

    function onClick(evt) {

        var $unit_type = $('#'+TicketCostData.unit_type_id);
        var $translation_type = $('#'+TicketCostData.translation_type_id);
        var $cost_type = $('#'+TicketCostData.cost_type_id);

        var data = {
            'unit_type': $unit_type.val(),
            'translation_type': $translation_type.val(),
            'cost_type': $cost_type.val(),
        };

        jQuery.ajax({
            url: TicketCostData.url,
            data: data,
            success: on_sync,
            error: function(o){
                alert("Не удалось получить оценку. Повторите свою попытку позже");
            }
        });
    };

    function on_sync(data){
        location.reload();
    }
});