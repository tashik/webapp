jQuery(document).ready(function($) {
    var $sync_button = $('#synchronize_button');

    $sync_button.click(onClick);

    function onClick(evt) {
        jQuery.ajax({
            url: TicketSynchronizeData.sync_url,
            success: on_sync,
            error: function(){
                alert("Can't synchronize ticket");
            }
        });
    };

    function on_sync(data){
        location.reload();
    }
});
