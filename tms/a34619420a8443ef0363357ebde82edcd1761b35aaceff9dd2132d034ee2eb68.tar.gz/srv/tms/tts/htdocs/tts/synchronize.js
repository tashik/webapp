jQuery(document).ready(function($) {
    var $sync_button = $('#synchronize_button');

    $sync_button.click(onClick);

    function onClick(evt) {
        jQuery.ajax({
            url: TicketSynchronizeData.sync_url,
            success: on_sync,
            error: function(){
                alert("Не удалось синхронизировать задание");
            }
        });
    };

    function on_sync(data){
        location.reload();
    }
});
