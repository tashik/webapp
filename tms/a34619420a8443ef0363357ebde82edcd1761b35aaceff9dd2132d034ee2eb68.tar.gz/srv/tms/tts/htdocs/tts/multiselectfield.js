
function createMultiselectField(field) {
	// Assumes that the previous (hidden) element contains the actual data.
	var dataField = field.prev();
	var uiField = field;

	function updateUiField() {
		var value = dataField.attr('value');
		if (!value)
			return;
		// The value of multiselectfieldDelimiter is passed to js from python.
		var options = JSON.parse(value);
		uiField.val(options);
	}

	updateUiField();

	// Listen to changes in the UI.
	uiField.change(function(event) {
		var values = jQuery(event.target).val();
		if (values === null)  {
			dataField.attr('value', '');
		} else {
			dataField.attr('value', JSON.stringify(values));
		}
	});

	// Listen to changes in the data (like revert).
	dataField.change(function(event) {
		updateUiField();
	});
}

jQuery(document).ready(function($) {
	jQuery('.multiselect').each(function(i) {
		createMultiselectField(jQuery(this));
	});
});
