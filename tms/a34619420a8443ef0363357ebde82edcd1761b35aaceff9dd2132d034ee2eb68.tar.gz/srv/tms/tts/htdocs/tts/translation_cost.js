jQuery(document).ready(function($) {
    var $sync_button = $('#translation_cost_button');

    $sync_button.click(onClick);

    function onClick(evt) {
        $.blockUI({
            message: $('#loadingBox'),
            css: {
                border: 'none',
                top:  ($(window).height() - 400) /2 + 'px',
                left: ($(window).width() - 400) /2 + 'px',
                width: '400px',
                background: 'transparent'
            },
            overlayCSS:  {
                backgroundColor: 'transparent',
                opacity:         0.6,
            },
        });
        jQuery.ajax({
            url: TicketCostData.url,
            success: on_sync,
            error: function(o){
                $.unblockUI();
                alert("Не удалось получить оценку. Повторите свою попытку позже");
            }
        });
    };

    function on_sync(data){
        $.unblockUI();
        location.reload();
    }
});