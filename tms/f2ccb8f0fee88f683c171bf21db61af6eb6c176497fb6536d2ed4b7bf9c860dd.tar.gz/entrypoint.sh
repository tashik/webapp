#!/bin/bash

. /setenv.sh

if [[ -z "$@" ]]; then
    ### default action
    # clean
    rm -f $INSTANCE_HOME/watcher/celerybeat-schedule
    rm -f $INSTANCE_HOME/watcher/celerybeat.pid
    # start
    su - tms -c ". /setenv.sh && cd $INSTANCE_HOME/watcher && celery -A celery_tasks worker -f $INSTANCE_HOME/log/watcher/worker.log &"
    sleep 1
    su - tms -c ". /setenv.sh && cd $INSTANCE_HOME/watcher && celery beat -f $INSTANCE_HOME/log/watcher/beat.log &"
    apache-foreground
else
    ### cutsom cmd (example: /bin/bash)
    exec $@
fi

