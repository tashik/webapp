#!/bin/bash

. /setenv.sh

# Stop Beat
#pkill -INT -F /srv/tms/watcher/celerybeat.pid;
ps ax | grep -E "python.*beat.*beat\.log" | awk '{print $1}' | grep "^[0-9]\+$" | xargs kill
sleep 1

# Stop Celery
ps ax | grep -E "python.*celery.*worker\.log" | awk '{print $1}' | grep "^[0-9]\+$" | xargs kill
sleep 1

# Stop Apache2
ps ax | grep apache-foreground | grep -v grep | awk '{print $1}' | grep "^[0-9]\+$" | xargs kill
