export PBUSDIR=$(cd $(dirname "$BASH_SOURCE") && pwd -P)
export PYTHONPATH=$PBUSDIR:$HOME/lib/python2.7/site-packages
