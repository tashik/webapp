# -*- coding: utf-8 -*-

"""
$Id: $
"""

import cherrypy
from xml_quote import xml_quote
import db

class ServerStatusPage(object):
    def __init__(self, storage):
        self.storage = storage

    
#    @cherrypy.expose
    def index(self):
        rows = ['<th>name</th>'
                '<th>last_msg_seq</th>'
                '<th>subscriptions</th>'
                '<th>next msg</th>'
                '<th>status</th>']
        for topic in sorted(self.storage.topics.values(), key=lambda t: t.name):
            topic_s = '<a href="/status/topic/%s">%s</a>' % (topic.name, topic.name)
            ss = sorted(topic.subscriptions.values(), key=lambda s: s.subscriber_name)
            subscribers_s = ['<a href="/status/topic/%s/subscription/%s">%s</a>' %
                             (topic.name, s.subscriber_name, s.subscriber_name)
                             for s in ss]
            def __format_msg_seq(seq):
                if seq is not None:
                    return '<a href="/status/message/%s">%s</a>' % (seq, seq)
                return '-'
            next_msg_s = [__format_msg_seq(s.next_msg_seq) for s in ss]
            status_s = [(s.status or 'OK') for s in ss]
            row = [topic_s,
                   str(topic.last_msg_seq),
                   '<br/>'.join(subscribers_s),
                   '<br/>'.join(next_msg_s),
                   '<br/>'.join(status_s)]
            rows.append(''.join([('<td>%s</td>' % elem) for elem in row]))
        content = '<table border="1">\n%s\n</table>' % ''.join([('<tr>%s</tr>\n' % row) for row in rows])
        return self.render(content)

    def message(self, seq):
        cherrypy.response.headers['Content-Type'] = 'text/plain'
        c = db.con().cursor()
        c.execute("select body from messages where seq = ?", (seq,))
        return c.fetchone()[0]

    def messages(self, topic_name, subscriber_name, start=-20):
        start = int(start)
        topic = self.storage.topics[topic_name]
        sub = topic.subscriptions[subscriber_name]
        rows = []
        for msg in reversed(sub.queue[start:]):
            output = [ 'seq=<a href="/status/message/%s">%s</a>' % (msg.seq, msg.seq),
                       'sender=%s' % msg.sender,
                       'recipient=%s' % msg.recipient,
                       'in_reply=%s' % (msg.in_reply or ''),
                       xml_quote(msg.body[:100]) + (len(msg.body) > 100 and ' ...' or ''),
                      ]
            row = '<hr/>\n<div>%s</div>' % '<br/>'.join(output)
            rows.append(row)
        return self.render(''.join(rows))

    def subscription(self, topic_name, subscriber_name):
        topic = self.storage.topics[topic_name]
        sub = topic.subscriptions[subscriber_name]
        output = ['subscriber_name=%s' % subscriber_name,
                  'callback_url=%s' % xml_quote(sub.callback_url),
                  'status=%s' % (sub.status or 'OK'),
                  self.messages(topic_name, subscriber_name)]
        content = '<br/>'.join(output)
        
        return self.render(content)

    def topic(self, topic_name):
        topic = self.storage.topics[topic_name]

        output = ['name=%s' % topic.name,
                  'last_msg_seq=%s' % topic.last_msg_seq]
        content = '<br/>'.join(output)
        
        return self.render(content)


    def render(self, text):
        return '<html><body>\n%s\n</body></html>' % text
