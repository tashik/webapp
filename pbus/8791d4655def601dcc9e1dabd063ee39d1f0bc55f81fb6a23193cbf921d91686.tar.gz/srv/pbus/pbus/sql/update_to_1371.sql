begin;

insert into _schema_revisions (revision) values (1371);

alter table messages add column recipient text;

commit;
