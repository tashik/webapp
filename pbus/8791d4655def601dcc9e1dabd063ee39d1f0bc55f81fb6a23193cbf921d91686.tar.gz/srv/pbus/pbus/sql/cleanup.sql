create temp view unread_messages as
  select topic, min(msg_queue_head) as seq from subscriptions group by topic;

select count(*) from messages where seq in (
  select messages.seq from messages, unread_messages where messages.topic=unread_messages.topic and (unread_messages.seq is null or messages.seq < unread_messages.seq)
);

delete from messages where seq in (
  select messages.seq from messages, unread_messages where messages.topic=unread_messages.topic and (unread_messages.seq is null or messages.seq < unread_messages.seq) limit 50
);
