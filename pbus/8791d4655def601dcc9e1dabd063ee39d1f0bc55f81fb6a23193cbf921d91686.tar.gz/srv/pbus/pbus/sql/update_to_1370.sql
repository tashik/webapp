begin;

create table _schema_revisions 
(
  revision integer not null primary key,
  applied timestamp not null default CURRENT_TIMESTAMP
);

insert into _schema_revisions (revision) values (1370);

drop table messages;
create table messages (
  topic text not null,
  seq integer not null,
  content_type text,
  body blob not null,
  timestamp text not null,
  sender text not null,
  in_reply integer,
  primary key (topic, seq)
);


commit;
