create table _schema_revisions 
(
  revision integer not null primary key,
  applied timestamp not null default CURRENT_TIMESTAMP
);

insert into _schema_revisions (revision) values (1371);

create table topics (
  topic text not null primary key
);

create table subscriptions (
  topic text not null,
  subscriber text not null,
  callback_url text,
  msg_queue_head integer, -- NULL if queue is empty
  unique(topic, subscriber)
);

create table messages (
  topic text not null,
  seq integer not null,
  content_type text,
  body blob not null,
  timestamp text not null,
  sender text not null,
  in_reply integer,
  recipient text,
  ttl integer,
  reply_ttl integer,
  status char(1),  -- NULL, 'X'
  primary key (topic, seq)
);
