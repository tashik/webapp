begin;

insert into _schema_revisions (revision) values (1393);

alter table messages add column ttl integer;
alter table messages add column reply_ttl integer;
alter table messages add column status char(1);

commit;
