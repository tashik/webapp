# -*- coding: utf-8 -*-
import thread
import sqlite3 as sqlite
import config

IntegrityError = sqlite.IntegrityError
OperationalError = sqlite.OperationalError

CONNECT_ARGS = {}
cons = {}

def con():
    t_id = thread.get_ident()
    try:
        return cons[t_id]
    except KeyError:
        c = cons[t_id] = sqlite.connect(config.DATABASE, timeout=config.DB_TIMEOUT, isolation_level=None, **CONNECT_ARGS)
        return c

def closeAll():
    for con in cons.values():
        con.interrupt()
        #con.rollback()
        con.close()
        del con
    cons.clear()

def _removeComments(lines):
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('--'):
            continue
        yield line


def runScript(script):
    s = '\n'.join(_removeComments(script.split('\n')))
    for stmt in s.split(';'):
        if not stmt:
            continue
        con().execute(stmt)
        #con().commit()

def createDb():
    createScript = open(config.APPDIR + '/sql/create.sql').read()
    runScript(createScript)

