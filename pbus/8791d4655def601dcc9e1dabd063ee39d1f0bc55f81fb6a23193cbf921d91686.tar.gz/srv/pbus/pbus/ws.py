#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import sys

import cherrypy
import config
import log
from delivery import RetryDeliveryThread
from models.storage import Storage
from services import Root
from ui.status import ServerStatusPage


def setup_dispatcher(controllers):
    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.controllers.update(controllers)
    dispatcher.mapper.connect('/:topic_name/subscribe/:callback_url',
                              controller='root', action='subscribe',
                              conditions=dict(method=['POST']))
    dispatcher.mapper.connect('/:topic_name/unsubscribe',
                              controller='root', action='unsubscribe',
                              conditions=dict(method=['POST']))
    dispatcher.mapper.connect('/:topic_name/post',
                              controller='root', action='post',
                              conditions=dict(method=['POST']))
    dispatcher.mapper.connect('/:topic_name/post/private/:recipient',
                              controller='root', action='post_private',
                              conditions=dict(method=['POST']))
    dispatcher.mapper.connect('/ping', controller='root', action='ping')
    dispatcher.mapper.connect('/status', controller='status', action='index')
    dispatcher.mapper.connect('/status/topic/:topic_name/subscription/:subscriber_name',
                              controller='status', action='subscription')
    dispatcher.mapper.connect('/status/message/:seq',
                              controller='status', action='message')
    dispatcher.mapper.connect('/status/topic/:topic_name',
                              controller='status', action='topic')
    return dispatcher

def check_password(realm, user, password):
    # поддержка логинов подсистем - разные получатели с одинаковым паролем
    auth_user = user.split('@')[0]
    p = config.PASSWD.get(auth_user)
    return p and p == password or False
    
check_password_admin = cherrypy.lib.auth_basic.checkpassword_dict(config.ADMIN_PASSWD)


def create_app(storage, cpconfig={}):

    cherrypy.config.update({
        'log.screen' : True,
        #'log.error_file': os.path.join(os.path.dirname(__file__), 'site.log'),
        #'environment': 'production',
        'tools.decode.on': True,
        'tools.encode.on': True,
        'tools.encode.encoding': 'utf-8',
        'tools.decode.encoding': 'utf-8',
        'server.socket_port': config.SERVER_PORT,
        'server.socket_host': config.SERVER_HOST,
        'server.thread_pool': config.THREAD_POOL,
        })
    cherrypy.config.update(cpconfig)

    if '--no-autoreload' in sys.argv:
        cherrypy.config['engine.autoreload.on'] = False

    root = Root(storage)
    controllers = {
        'root': root,
        'status': ServerStatusPage(storage),
        }
    dispatcher = setup_dispatcher(controllers)

    return cherrypy.tree.mount(root,
                               config={'/': {
                                           'request.dispatch': dispatcher,
                                           'tools.auth_basic.on': True,
                                           'tools.auth_basic.realm': 'pbus',
                                           'tools.auth_basic.checkpassword': check_password,
                                           },
                                       '/ping': {
                                           'tools.auth_basic.on': False,
                                           },
                                       '/status': {
                                           'tools.auth_basic.on': True,
                                           'tools.auth_basic.realm': 'pbus-admin',
                                           'tools.auth_basic.checkpassword': check_password_admin,
                                           },
                                       })

from cherrypy.process.plugins import SimplePlugin

class StorageReloader(SimplePlugin):
    def __init__(self, bus, storage, name=None):
        SimplePlugin.__init__(self, bus)
        self.storage = storage
        self.name = name

    def graceful(self):
        log.CONSOLE('Reloading storage')
        self.storage.reload()

class Options(object):
    no_autoreload = False
    cpu_affinity = None
    profile = None
    remote_debugger = None

    @classmethod
    def parse_args(cls):
        parser = argparse.ArgumentParser(description='Run application server')
        parser.add_argument('--no-autoreload', action='store_true',
                            help='disable automatic reloading on source code change')
        parser.add_argument('--profile', action='store_true',
                            help='run the server under the python profiler')
        parser.add_argument('--remote-debugger', type=str, metavar='HOST[:PORT]',
                            help='connect to remote debugging session')
        args = parser.parse_args()
        cls.no_autoreload = args.no_autoreload
        cls.profile = args.profile
        cls.remote_debugger = args.remote_debugger


def install_profiler(path):
    from cherrypy.lib import profiler
    p_app = profiler.make_app(cherrypy.tree, path)
    cherrypy.server.httpserver.wsgi_app = p_app


def connect_remote_debugger(addr):
    import pydevd
    if ':' in addr:
        host, port = addr.split(':')
    else:
        host, port = addr, 5678
    pydevd.settrace(host, port=int(port), stdoutToServer=True, stderrToServer=True)


def process_options(options):
    if options.no_autoreload:
        cherrypy.config['engine.autoreload.on'] = False

    if options.profile:
        install_profiler(config.APPDIR + '/log/profile')

    if options.remote_debugger:
        connect_remote_debugger(options.remote_debugger)


def get_wsgi_application():
    Options.parse_args()
    process_options(Options)

    storage = Storage()
    application = create_app(storage)

    ar_thread = RetryDeliveryThread(storage)
    cherrypy.engine.subscribe('start', ar_thread.start)
    cherrypy.engine.subscribe('stop', ar_thread.stop)

    from cherrypy.process.plugins import SignalHandler
    signal_handler = SignalHandler(cherrypy.engine)
    signal_handler.subscribe()

    cherrypy.engine.storage_reloader = StorageReloader(cherrypy.engine, storage)
    cherrypy.engine.storage_reloader.subscribe()

    return application


if __name__ == '__main__':
    log.init_cherrypy_loggers()

    if config.PIDDIR and sys.platform != 'win32':
        from util.pidfile import PidFile
        pidfile = PidFile('ws')

    #connect_remote_debugger('192.168.11.2:7111')

    application = get_wsgi_application()
    cherrypy.engine.start()
    cherrypy.engine.block()
