def xml_quote(s):
    s = s.replace("&", "&amp;").replace('"', "&quot;")
    s = s.replace("<", "&lt;").replace(">", "&gt;")
#    s = s.replace("\x00", "&#00;")
    return s
