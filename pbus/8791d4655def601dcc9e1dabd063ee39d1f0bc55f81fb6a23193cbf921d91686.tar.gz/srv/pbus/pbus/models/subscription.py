# -*- coding: utf-8 -*-
import sys
import urllib2
import base64
import time
import traceback
import logging

from log import CONSOLE, DEBUG
from models.nullobject import NullObject
from models.message import Message
import config

STATUS_OK = None
STATUS_ERROR = 'error'

class HardFailure(Exception):
    def __init__(self, error_text, msg):
        self.error_text = error_text
        self.msg = msg

    def __str__(self):
        return '''%s
----------------------------------------------------------------
seq = %s
content_type = %s
''' % (self.error_text, self.msg.seq, self.msg.content_type)


class NullSubscription(object):
    '''Сообщения, доставляемые с помощью этого класса, выбрасываются.
       Пока что это используется только при тестировании.
    '''
    
    def __init__(self, topic, subscriber_name):
        self.subscriber_name = subscriber_name
        self.callback_url = None
        self.topic = topic
        self.storage = topic.storage or NullObject()
        self.queue = []
        self.status = STATUS_OK
        self.next_retry = 0
        self.is_busy = False  # занят доставкой

    def reset_status(self):
        self.status = STATUS_OK
        self.next_retry = 0

    def on_successful_delivery(self):
        self.reset_status()

    def on_soft_error(self):
        self.next_retry = time.time() + config.RETRY_PERIOD

    def on_hard_error(self):
        self.status = STATUS_ERROR
        self.next_retry = time.time() + config.HARD_ERROR_RETRY_PERIOD

    def add(self, msg):
        self.queue.append(msg)
        self.storage.on_msg_queued(self, msg)

    def deliver_msg(self, msg):
        pass

    def flush_queue(self):
        return set()

    @property
    def next_msg_seq(self):
        return self.queue and self.queue[0].seq or None        


class HTTPSubscription(NullSubscription):
    def __init__(self, topic, subscriber_name, callback_url):
        super(HTTPSubscription, self).__init__(topic, subscriber_name)
        self.callback_url = callback_url
        self.opener = self._build_opener()

    def _build_opener(self):
        return urllib2.build_opener() # digest повторяет запрос дважды, это нас не устраивает
        #auth_handler = urllib2.HTTPDigestAuthHandler()
        #auth_handler.add_password('aeroflot-digest', self.callback_url, 'pbus-server', config.CALLBACK_PASSWD)
        #return urllib2.build_opener(auth_handler)


    def deliver_msg(self, msg):
        body_data = msg.body.read(self.storage)
        CONSOLE('#%s START DELIVERY from %s to %s @ %s' % (msg.seq, msg.sender, self.subscriber_name, self.callback_url))

        auth = 'Basic %s' % base64.b64encode('%s:%s' % ('pbus-server', config.CALLBACK_PASSWD)).strip()

        headers = {'Content-Type': msg.content_type,
                   'From': msg.sender,
                   'X-Pbus-Seq': msg.seq,
                   'Authorization': auth,}
        if type(body_data) is unicode:
            body_data = body_data.encode('utf-8')
            if 'charset=' not in msg.content_type:
                headers['Content-Type'] += ';charset=utf-8'
        req = urllib2.Request(url=self.callback_url,
                              data=body_data,
                              headers=headers)

        start_t = time.time()
        response = self.opener.open(req)
        CONSOLE('#%s DELIVERED OK -> %s; elapsed=%.3f' % (msg.seq, self.subscriber_name, time.time() - start_t))

        return response

    def _try_msg(self, msg):
        if msg.ttl is not None and msg.ttl <= 0:
            CONSOLE('#%s EXPIRED' % msg.seq)
            del self.queue[:1]
            self.storage.on_msg_expired(self, msg)
            return

        try:
            response = self.deliver_msg(msg)
        finally:
            if msg.ttl is not None:
                msg.ttl -= 1
                self.storage.save_msg_ttl(msg)

        self.on_successful_delivery()

        reply_body = unicode(response.fp.read(), 'utf-8').strip()
        reply_msg = None
        if msg.in_reply is None and response.code == 200 and reply_body:
            content_type = response.headers['Content-Type']
            reply_msg = Message(body=reply_body, sender=self.subscriber_name, content_type=content_type,
                                in_reply=msg.seq, recipient=msg.sender, ttl=msg.reply_ttl)

        del self.queue[:1]
        self.storage.on_msg_delivered(self, msg)
        return reply_msg

    def flush_queue(self):
        DEBUG('HTTPSubscription.flush_queue')
        if self.next_retry > time.time():
            return []

        replies = []

        for msg in self.queue[:]:
            if msg.sender == self.subscriber_name:
               del self.queue[:1]
               self.storage.on_skip_delivery(self, msg)
               continue

            try:
                reply_msg = self._try_msg(msg)
                if reply_msg:
                    replies.append(reply_msg)
                    self.topic.post(reply_msg, deliver=False)  # put message into queue to be delivered later

            except urllib2.HTTPError as e:
                if e.code in (408, 503, 504):
                    CONSOLE('#%s TEMPORARY ERROR (%s) -> %s @ %s' % (msg.seq, str(e), self.subscriber_name, self.callback_url))
                    return replies
                CONSOLE('#%s FAILED (%s) -> %s @ %s' % (msg.seq, e.code, self.subscriber_name, self.callback_url))
                error_text = '%s\n%s' % (str(e), e.fp.read())
                self.on_hard_error()
                raise HardFailure(error_text, msg)
            except IOError as e:
                CONSOLE('#%s TEMPORARY I/O ERROR (%s) -> %s @ %s' % (msg.seq, str(e), self.subscriber_name, self.callback_url))
                self.on_soft_error()
            except Exception as e:
                CONSOLE('#%s UNKNOWN ERROR (%s) -> %s @ %s' % (msg.seq, sys.exc_info()[0], self.subscriber_name, self.callback_url))
                traceback.print_exc()
                self.on_soft_error()

        return replies
