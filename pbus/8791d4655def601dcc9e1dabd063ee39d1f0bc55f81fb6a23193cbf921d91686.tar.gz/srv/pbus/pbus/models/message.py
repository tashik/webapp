# -*- coding: utf-8 -*-

class Message(object):
    def __init__(self, body, sender, seq=None, content_type='application/octet-stream',
                 in_reply=None, recipient=None, status=None, ttl=None, reply_ttl=None):
        self.body = MessageBodyDescriptor(self, body)
        self.seq = seq
        self.sender = sender
        self.content_type = content_type
        self.in_reply = in_reply  # сообщение является ответом сервера
        self.recipient = recipient  # задается для приватных сообщений
        self.status = status
        self.ttl = ttl
        self.reply_ttl = reply_ttl


# Тело сообщения может быть большим, хранить его в памяти сложно
class MessageBodyDescriptor(object):
    def __init__(self, msg, data=None):
        self.msg = msg
        self.data = data

    def read(self, storage):
        if self.data is not None:
            return self.data
        return storage.get_msg_body(self.msg.seq)

    # освобождаем память, занятую телом сообщения
    def free(self):
        self.data = None
