# -*- coding: utf-8 -*-
from models.nullobject import NullObject

class DummyLock(object):
    def __enter__(self):
        pass
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

class Topic(object):
    last_msg_seq = None

    def __init__(self, name, storage=None, lock=None):
        self.name = name
        self.subscriptions = {}
        self.storage = storage or NullObject()
        self.lock = lock or DummyLock()

    def subscribe(self, subscription):
        self.storage.subscribe(self, subscription)
        self.subscriptions[subscription.subscriber_name] = subscription

    def unsubscribe(self, subscription):
        self.storage.unsubscribe(self, subscription)
        del self.subscriptions[subscription.subscriber_name]

    def _register_msg(self, msg):
        with self.storage.lock:
            self.last_msg_seq += 1
            msg.seq = self.last_msg_seq
            self.storage.save_msg(self, msg)
        return msg

    def post(self, msg, deliver=True):
        """ Добавить сообщение в очередь, произвести попытку доставки """
        msg = self._register_msg(msg)

        for subscription in self.subscriptions.values():
            if msg.recipient is None or msg.recipient == subscription.subscriber_name:
                subscription.add(msg)
                if deliver:
                    subscription.flush_queue()

