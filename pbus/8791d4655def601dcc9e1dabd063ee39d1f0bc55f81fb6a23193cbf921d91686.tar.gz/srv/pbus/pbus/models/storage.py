# -*- coding: utf-8 -*-
import os
import threading
import logging
from datetime import datetime
import db
from models.topic import Topic
from models.subscription import NullSubscription, HTTPSubscription
from models.message import Message, MessageBodyDescriptor

import config

class Storage(object):
    lock = threading.RLock()
    topic_locks = {}
    null_subscription = NullSubscription  # тип подписки, используемый когда нет callback_url

    def __init__(self):
        if not os.path.exists(config.DATABASE):
            db.createDb()
        self._load_all_topics()

    def reload(self):
        self._load_all_topics()

    def _load_msg_queue(self, subscription, msg_queue_head):
        c = db.con().cursor()
        c.execute('''select seq, content_type, sender, in_reply, recipient, status, ttl, reply_ttl from messages where
                     topic = ? and seq >= ?
                     order by seq''',
                  (subscription.topic.name, msg_queue_head))
        for seq, content_type, sender, in_reply, recipient, status, ttl, reply_ttl in c:
            msg = Message(body=None, seq=seq, sender=sender, content_type=content_type,
                          in_reply=in_reply, recipient=recipient, status=status,
                          ttl=ttl, reply_ttl=reply_ttl)
            subscription.queue.append(msg)

    def _load_all_topics(self):
        topics = {}
        c = db.con().cursor()
        c.execute('select max(seq) from messages')
        Topic.last_msg_seq = c.fetchone()[0] or 0

        c = db.con().cursor()
        c.execute('select topic from topics')
        for topic_name, in c.fetchall():
            topics[topic_name] = self._load_topic(topic_name)
        self.topics = topics
        
    def _get_topic_lock(self, topic_name):
        with self.lock:
            try:
                return self.topic_locks[topic_name]
            except KeyError:
                lock = self.topic_locks[topic_name] = threading.RLock()
                return lock

    def _load_topic(self, name):
        topic_lock = self._get_topic_lock(name)
        topic = Topic(name, storage=self, lock=topic_lock)

        c = db.con().cursor()
        c.execute('''select subscriber, callback_url, msg_queue_head
                     from subscriptions
                     where topic=?''', (name,))
        for subscriber_name, callback_url, msg_queue_head in c:
            if callback_url:
                s = HTTPSubscription(topic, subscriber_name, callback_url)
                s.callback_url = callback_url
            else:
                s = self.null_subscription(topic, subscriber_name)
            s.subscriber_name = subscriber_name
            topic.subscriptions[subscriber_name] = s

            if msg_queue_head is not None:
                self._load_msg_queue(s, msg_queue_head)

        return topic

    def get_topic(self, name):
        try:
            return self.topics[name]
        except KeyError:
            topic = Topic(name, storage=self)
            self.save_topic(topic)
            self.topics[name] = topic
            return topic

    def save_topic(self, topic):
        if topic.name not in self.topics:
            db.con().execute("insert into topics values (?)", (topic.name,))
            self.topics[topic.name] = topic
        for subscription in topic.subscriptions.values():
            c = db.con().cursor()
            c.execute("update subscriptions set callback_url=? where topic=? and subscriber=?",
                      (subscription.callback_url, topic.name, subscription.subscriber_name))

    def subscribe(self, topic, subscription):
        c = db.con().cursor()
        if subscription.subscriber_name in topic.subscriptions:
            c.execute('''update subscriptions set callback_url=?
                         where topic=? and subscriber=?''',
                      (subscription.callback_url,
                       topic.name, subscription.subscriber_name))
        else:
            logging.debug('NEW SUBSCRIPTION subscriber=%s topic=%s' % (subscription.subscriber_name, topic.name))
            c.execute('''insert into subscriptions
                         (topic, subscriber, callback_url)
                         values
                         (?, ?, ?)''',
                      (topic.name, subscription.subscriber_name,
                       subscription.callback_url))

    def unsubscribe(self, topic, subscription):
        c = db.con().cursor()
        if subscription.subscriber_name in topic.subscriptions:
            c.execute('''delete from subscriptions where topic=? and subscriber=?''',
                      (topic.name, subscription.subscriber_name))

    def save_msg(self, topic, msg):
        c = db.con().cursor()
        body_data = msg.body.read(self)
        msg.body.free()

        c.execute('''insert into messages
                     (topic, seq, content_type, body, timestamp,
                      sender, in_reply, recipient, ttl, reply_ttl, status)
                     values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  (topic.name, msg.seq, msg.content_type, body_data, datetime.now().isoformat(),
                   msg.sender, msg.in_reply, msg.recipient, msg.ttl, msg.reply_ttl, msg.status))

    def save_msg_ttl(self, msg):
        if msg.ttl <= 0:
            msg.status = 'X'
        c = db.con().cursor()
        c.execute("update messages set ttl=?, status=? where seq=?",
                  (msg.ttl, msg.status, msg.seq))

    def get_msg_body(self, seq):
        c = db.con().cursor()
        c.execute("select body from messages where seq=?", (seq,))
        return c.fetchone()[0]

    def on_msg_queued(self, subscription, msg):
        c = db.con().cursor()
        c.execute('update subscriptions set msg_queue_head=? where '
                  'msg_queue_head is NULL and '
                  'subscriber=? and topic=?',
                  (msg.seq, subscription.subscriber_name, subscription.topic.name))

    def on_skip_delivery(self, subscription, msg):
        self._shift_queue(subscription, msg)

    def on_msg_delivered(self, subscription, msg):
        self._shift_queue(subscription, msg)

    def on_msg_expired(self, subscription, msg):
        self.save_msg_ttl(msg)
        self._shift_queue(subscription, msg)

    def _shift_queue(self, subscription, msg):
        c = db.con().cursor()
        c.execute('update subscriptions set msg_queue_head=? where '
                  'subscriber=? and topic=?',
                  (subscription.next_msg_seq,
                   subscription.subscriber_name, subscription.topic.name))

    def subscriber_exists(self, subscriber):
        c = db.con().cursor()
        c.execute("select count(*) from subscribers where subscriber=?", (subscriber.subscriber_name,))
        return bool(c.fetchone()[0][0])
