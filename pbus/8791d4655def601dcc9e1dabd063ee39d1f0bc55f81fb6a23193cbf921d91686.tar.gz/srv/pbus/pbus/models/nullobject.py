class NullObject:
    def __call__(self, *args, **kwargs): return self.__class__()
    def __getitem__(self, key): return self.__class__()
    def __nonzero__(self): return 0
    def __str__(self): return ''

    def __getattr__(self, name):
        setattr(self, name, NullObject())
        return getattr(self, name)
