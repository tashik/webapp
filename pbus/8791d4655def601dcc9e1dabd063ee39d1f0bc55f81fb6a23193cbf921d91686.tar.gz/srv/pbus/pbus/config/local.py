# -*- coding: utf-8 -*-
from config.defaults import *

SERVER_HOST = '0.0.0.0'

DISABLE_DB_FSYNC = False

STORAGE_BACKEND = 'fs'

SYSTEM_NAME = 'P-Bus Dev (local)'
ADMIN_EMAIL = [] #['an@ramax.ru']

PASSWD = {'aflcab': '123456',
          'vocabs': '456789',
          'booking': '234567',
          'schedule': '111222',
          'ws': 'Iel4VooH',
          'benchmark': '444555',
          'sb': '123',
          'itest_client': '123',
          'itest_client2': '123',
          'itest_server': '123',
          }

ADMIN_PASSWD = {'admin': '123'}

CALLBACK_PASSWD = '112233'

# проверяем, всё ли
for __n, __v in globals().items():
    if __v is NotImplemented:
        raise NameError(__n)
