# -*- coding: utf-8 -*-

# Загрузка конфигов конкретного инстанса. Эти конфиги содержат внешний URL инстанса, адреса соседних подсистем,
# пароли для доступа к этим подсистемам, другую информацию специфичную для развертывания.

# в /cluster-config/config.py монтируется конфиг кластера в случае запуска под Docker или Kubernetes
# в /secrets монтируются секреты при запуске под Kubernetes

import os
import re

from config.defaults import *
# execfile нужен для выполнения частей конфига в общем неймспейсе
# без execfile получаются круговые записимости между конфигами
execfile(os.path.dirname(__file__) + '/local.py')
execfile(os.path.dirname(__file__) + '/cluster.py')

DEPRECATED = {}

def validate_config():
    errors = []
    # Некоторые переменные являются обязательными для переопределения.
    for n, v in globals().items():
        if v is NotImplemented:
            errors.append(n)
        if n in DEPRECATED:
            # logging здесь использовать не получается, так как он еще не сконфигурирован
            import log
            log.CONSOLE('Config parameter %s is deprecated' % n)

    if errors:
        raise NameError(errors)
