# -*- coding: utf-8 -*-
from os.path import abspath, dirname
import logging

PRODUCTION = False

SERVER_PORT = 8390
SERVER_HOST = '127.0.0.1'
THREAD_POOL = 4

APPDIR = abspath(dirname(__file__)  + '/..')
LOGDIR = APPDIR + '/log'
PIDDIR = APPDIR + '/pid'
DATABASE = APPDIR + '/data/db'
DB_TIMEOUT = 30 # 600
DISABLE_DB_FSYNC = False
DELIVERY_THREAD_POOL = 8

LOG_LEVEL = logging.DEBUG

RETRY_PERIOD = 10
HARD_ERROR_RETRY_PERIOD = 600

SYSTEM_NAME = NotImplemented # 'P-Bus Dev (local)'
ADMIN_EMAIL = [] #['an@ramax.ru']

SMTP_SERVER = 'klaus-s.com.spb.ru'
SMTP_PORT = 25
SMTP_FROM = 'pbus@localhost'

PASSWD = {}  # {'subscribed-id': 'password',}
ADMIN_PASSWD = {}  # {'admin': 'admin-password',}

CALLBACK_PASSWD = NotImplemented  # 'callback-password'
