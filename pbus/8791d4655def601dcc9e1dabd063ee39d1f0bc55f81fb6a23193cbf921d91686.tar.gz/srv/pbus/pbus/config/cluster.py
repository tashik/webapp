# -*- coding: utf-8 -*-

# Загрузка конфигов конкретного инстанса. Эти конфиги содержат внешний URL инстанса, адреса соседних подсистем,
# пароли для доступа к этим подсистемам, другую информацию специфичную для развертывания.

# распарсивание многоуровневых ключей, типа PASSWD.sb
def __set_param(key, value):
    container = globals()
    keys = key.split('.')
    inner = keys.pop(-1)
    for k in keys:
        container = container[k]
    container[inner] = value

def __read_secret(d, secret_name):
    with open('%s/%s' % (d, secret_name)) as f:
        return f.read()

def __load_secrets(d):
    for varname in os.listdir(d):
        if re.match('[A-Za-z]+.*', varname):
            __set_param(varname, __read_secret(d, varname))


_CLUSTER_CONFIG = '/cluster-config/config.py'
_CLUSTER_PASSWD = '/cluster-config/passwd.py'
_KUBERNETES_SECRETS_DIR = '/secrets'

if os.path.exists(_CLUSTER_PASSWD):
    execfile(_CLUSTER_PASSWD)

if os.path.exists(_KUBERNETES_SECRETS_DIR):
    __load_secrets(_KUBERNETES_SECRETS_DIR)

if os.path.exists(_CLUSTER_CONFIG):
    execfile(_CLUSTER_CONFIG)
