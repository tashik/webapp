# -*- coding: utf-8 -*-

"""
$Id: $
"""
import os
import pytest

import config
import db
import util.mail

TEST_DB_PATH = '/tmp/testdb'
TABLES = ['messages', 'subscriptions', 'topics']
db.CONNECT_ARGS = {'check_same_thread': False}

class UnittestMail(object):
    SENT = []

    @classmethod
    def sendToAdmin(cls, subject, body, content_type="text/plain"):
        cls.SENT.append(('admin', subject, body))

def pytest_runtest_setup(item):
    # called for running each test in a directory
    config.RETRY_PERIOD = .1
    UnittestMail.SENT = []
    util.mail.sendToAdmin = UnittestMail.sendToAdmin


@pytest.fixture(scope='module')
def init_db(request):
    db.closeAll()

    config.DATABASE = TEST_DB_PATH

    if os.path.exists(TEST_DB_PATH):
        delete_db()

    db.createDb()

    request.addfinalizer(delete_db)

def delete_db():
    try:
        os.unlink(TEST_DB_PATH)
    except OSError:
        return


@pytest.fixture
def clear_tables():
    for t in TABLES:
        try:
            db.con().execute('delete from %s' % t)
        except db.OperationalError:
            pass
    db.con().commit()

