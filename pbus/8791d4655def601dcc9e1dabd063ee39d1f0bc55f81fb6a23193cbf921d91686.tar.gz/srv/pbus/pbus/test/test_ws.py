# -*- coding: utf-8 -*-

import base64
import threading
import time
import urllib2
import urllib
import cherrypy
import delivery
import pytest

from test import testlib
from testlib import dbq

import config
config.RETRY_PERIOD = .1
config.PASSWD = {'sub1': '123', 'sub2': '123'}
config.DATABASE = config.APPDIR + '/testdb'

import db
import models
import ws
from models.storage import Storage
from models.subscription import HTTPSubscription
from models.message import Message

TEST_SERVER_URL = 'http://localhost:18888'
CALLBACK_URL = 'http://localhost:28888/callback'
CALLBACK_URL2 = 'http://localhost:28888/callback#222'

class PermanentFailure(object):
    pass

class SubscriberApp(object):
    """Simplest possible WSGI application object"""

    content_type = None
    received = []
    senders = []
    simulate_failure = False
    simulate_permanent_failure = False
    reply = ['']

    @classmethod
    def __call__(cls, environ, start_response):
        cls.content_type = environ['CONTENT_TYPE'].split(';')[0]
    
        cl = int(environ['CONTENT_LENGTH'])
        body = environ['wsgi.input'].read(cl)
    
        if cls.simulate_failure is PermanentFailure:
            status = '404 Simulated permanent error'
        elif cls.simulate_failure:
            status = '504 Simulated temporary error'
        else:
            status = '200 OK'
            cls.received.append(body)
            cls.senders.append(environ.get('HTTP_FROM'))
    
        response_headers = [('Content-type','text/plain')]
        start_response(status, response_headers)
    
        return cls.reply


def subscribe(topic_name, callback_url=CALLBACK_URL, my_name='sub1'):
    TestPBusApp.auth = my_name + ':123'
    callback_url = urllib.quote(callback_url, safe='')
    url = '%s/%s/subscribe/%s' % (TEST_SERVER_URL, topic_name, callback_url)
    urllib2.urlopen(url, '')

def unsubscribe(topic_name, my_name='sub1'):
    TestPBusApp.auth = my_name + ':123'
    url = '%s/%s/unsubscribe' % (TEST_SERVER_URL, topic_name)
    urllib2.urlopen(url, '')


def post(data, ct='text/plain', url='/t1/post', ttl='', my_name='sub2'):
    TestPBusApp.auth = my_name + ':123'
    conn = wsgi_intercept.WSGI_HTTPConnection('localhost', 18888)
    conn.request('POST', url, data, headers={'content-type': ct, 'x-ttl': ttl})
    return conn.getresponse()


class TestPBusApp():
    auth = 'sub1:123'
    storage = None
    instance = None
    
    def __init__(self):
        TestPBusApp.storage = Storage()
        self._app = ws.create_app(TestPBusApp.storage, {'log.screen': False})
        TestPBusApp.instance = self

    def __call__(self, environ, start_response):
        environ['HTTP_AUTHORIZATION'] = 'basic ' + base64.encodestring(TestPBusApp.auth)
        TestPBusApp.auth = 'sub1:123'
        return self._app(environ, start_response)

def create_subscriber_app():
    return SubscriberApp()

def create_mw_app():
    return TestPBusApp.instance

import wsgi_intercept
w_i_version = '%04d%04d%04d' % tuple([int(s) for s in wsgi_intercept.__version__.split('.')])
assert w_i_version >= '000000030004'

from wsgi_intercept.urllib2_intercept import install_opener, uninstall_opener, WSGI_HTTPHandler

@pytest.fixture()
def subscriber_app(request):
    TestPBusApp()

    HTTPSubscription._old_build_opener = HTTPSubscription._build_opener
    HTTPSubscription._build_opener = lambda self: urllib2.build_opener(WSGI_HTTPHandler())

    install_opener()
    wsgi_intercept.add_wsgi_intercept('localhost', 18888, create_mw_app)
    wsgi_intercept.add_wsgi_intercept('localhost', 28888, create_subscriber_app)

    SubscriberApp.received = []
    SubscriberApp.senders = []
    SubscriberApp.reply = ['']
    
    if cherrypy.engine.state == 0:
        cherrypy.engine.start(False)

    SubscriberApp.simulate_failure = False

    request.addfinalizer(stop_subscriber_app)

def stop_subscriber_app():
    cherrypy.engine.stop()
    HTTPSubscription._build_opener = HTTPSubscription._old_build_opener

    wsgi_intercept.remove_wsgi_intercept('localhost', 18888)
    wsgi_intercept.remove_wsgi_intercept('localhost', 28888)
    uninstall_opener()

pytestmark = pytest.mark.usefixtures('init_db', 'clear_tables', 'subscriber_app')

# ---------------------------------------------------------

def test_subscribe():
    subscribe('t1')
    
    storage = TestPBusApp.instance.storage
    sub = storage.topics['t1'].subscriptions['sub1']
    #rows = dbq("select callback_url from subscribers where topic='t1' and subscription='sub1'")
    assert sub.callback_url == CALLBACK_URL
    
    subscribe('t1')
    subs = storage.topics['t1'].subscriptions
    #rows = dbq("select count(*) from subscribers")
    assert len(subs) == 1

    #subscribe('t2')
    #rows = dbq("select count(*) from subscribers")
    #subs = storage.topics[''].subscribers
    #assert len(subs) == 2

    # изменился URL
    subscribe('t1', CALLBACK_URL2)
    sub = storage.topics['t1'].subscriptions['sub1']
    #rows = dbq("select callback_url from subscribers where topic='t1' and subscription='sub1'")
    assert sub.callback_url == CALLBACK_URL2


def test_unsubscribe():
    from urllib2 import HTTPError
    try:
        unsubscribe('t404')
    except HTTPError as e:
        assert e.code == 404
    else:
        assert 0, 'HTTPError not raised'

    dbq("insert into topics values('t_ws1')")
    dbq("insert into subscriptions values ('t_ws1', 'sub1', 'http://localhost', 1)")
    TestPBusApp.storage._load_all_topics()

    unsubscribe('t_ws1')



def test_rest_api():
    subscribe('t1')

    r1 = post('hello')
    assert r1.status == 200

    assert SubscriberApp.received == ['hello']
    assert len(TestPBusApp.storage.get_topic('t1').subscriptions['sub1'].queue) == 0

    SubscriberApp.simulate_failure = True

    r2 = post('hello2', 'application/x-test-data')
    assert r2.status == 200

    assert SubscriberApp.received == ['hello']

    SubscriberApp.simulate_failure = False

    r3 = post('hello3')
    assert r3.status == 200

    assert SubscriberApp.received == ['hello', 'hello2', 'hello3']

    r4 = post('hi4', 'application/x-test-data')
    assert SubscriberApp.content_type == 'application/x-test-data'

    # simulate restarting receiver application

    SubscriberApp.simulate_failure = True
    r5 = post('hi5')

    assert len(TestPBusApp.storage.get_topic('t1').subscriptions['sub1'].queue) == 1
    SubscriberApp.simulate_failure = False
    subscribe('t1')
    assert len(TestPBusApp.storage.get_topic('t1').subscriptions['sub1'].queue) == 1  # сообщение никуда не делось

    r6 = post('hi6')

    assert SubscriberApp.received == ['hello', 'hello2', 'hello3', 'hi4', 'hi5', 'hi6']


def test_permanent_failure():
    SubscriberApp.received = []
    subscribe('t1')
    SubscriberApp.simulate_failure = True

    def raise_exception(*args, **kw):
        assert 0

    from util import mail
    old_sendToAdmin = mail.sendToAdmin
    mail.sendToAdmin = raise_exception

    SubscriberApp.simulate_failure = PermanentFailure

    storage = cherrypy.tree.apps.values()[0].root.storage
    arThread = delivery.RetryDeliveryThread(storage)
    msg = Message(body='hi7', sender='sender',
                  content_type='text/plain',
                  ttl=100,
                  reply_ttl=100)

    topic_t1 = TestPBusApp.storage.get_topic('t1')
    topic_t1.post(msg, deliver=False)
    arThread._send_messages(TestPBusApp.storage.get_topic('t1').subscriptions.values())

    assert topic_t1.subscriptions['sub1'].status == models.subscription.STATUS_ERROR

    SubscriberApp.simulate_failure = False
    mail.sendToAdmin = old_sendToAdmin


def test_sender():
    subscribe('t1')

    r1 = post('hello')
    assert r1.status == 200
    assert SubscriberApp.senders == ['sub2']


def test_private_post():
    subscribe('t1')

    r1 = post('hello', url='/t1/post/private/invalid2')
    assert r1.status == 200
    assert SubscriberApp.received == []

    r2 = post('hello2', url='/t1/post/private/sub1')
    assert r1.status == 200
    assert SubscriberApp.received == ['hello2']


def test_reply():
    subscribe('t1', my_name='sub1')
    subscribe('t1', my_name='sub2')

    SubscriberApp.reply = ['bye']

    r1 = post('hello')
    assert r1.status == 200
    TestPBusApp.storage.topics['t1'].subscriptions['sub2'].flush_queue()
    assert SubscriberApp.received == ['hello', 'bye']


def test_auto_retry():
    subscribe('t1')

    storage = cherrypy.tree.apps.values()[0].root.storage
    ar_thread = delivery.RetryDeliveryThread(storage)
    ar_thread.start()

    try:
        SubscriberApp.simulate_failure = True

        r2 = post('hello2')
        assert r2.status == 200

        assert len(storage.topics['t1'].subscriptions['sub1'].queue) == 1

        assert SubscriberApp.received == []

        SubscriberApp.simulate_failure = False
        time.sleep(.5)

        assert SubscriberApp.received == ['hello2']

    finally:
        ar_thread.stop_flag = True
        ar_thread.join()


def test_expire():
    subscribe('t1')

    SubscriberApp.simulate_failure = True
    r1 = post('hello1', ttl=1)
    assert r1.status == 200

    SubscriberApp.simulate_failure = False
    r2 = post('hello2', ttl=1)

    assert SubscriberApp.received == ['hello2']
    assert len(TestPBusApp.storage.get_topic('t1').subscriptions['sub1'].queue) == 0


# this test fails under PyCharm, however runs fine from command line
def test_multithreaded_db_access():
    storage = cherrypy.tree.apps.values()[0].root.storage
    subscribe('t1')
    SubscriberApp.simulate_failure = True
    post('hi1')

    class SecondThread(threading.Thread):
        def run(self):
            c = db.con().cursor()
            c.execute('update subscriptions set msg_queue_head=null')
            db.con().commit()

    st = SecondThread()
    st.start()
    st.join()

    c = db.con().cursor()
    c.execute('select msg_queue_head from subscriptions')
    assert c.fetchone()[0] == None


def test_check_password():
    assert ws.check_password('realm', 'sub1', 'xxxx') == False
    assert ws.check_password('realm', 'sub1', '123') == True
    assert ws.check_password('realm', 'sub1@node0', '123') == True
