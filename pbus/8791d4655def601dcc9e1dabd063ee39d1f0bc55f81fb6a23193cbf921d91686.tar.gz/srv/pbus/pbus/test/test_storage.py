# -*- coding: utf-8 -*-

import pytest
from test import testlib
from testlib import dbq

from models.storage import Storage
from models.message import Message
from models.topic import Topic
from models.subscription import NullSubscription

def post(t, body, sender):
    msg = Message(body=body, sender=sender)
    return msg, t.post(msg)

@pytest.fixture
def clean_tables():
    testlib.clearTables()

pytestmark = pytest.mark.usefixtures('init_db', 'clear_tables')

def test_load_seq():
    dbq("insert into topics values('t888')")
    dbq("insert into messages values('t888', 1, 'text/plain', 'aaa', '2007-01-01 12:30:11', 'sub2', NULL, NULL, NULL, NULL, NULL)")
    dbq("insert into messages values('t888', 2, 'text/plain', 'bbb', '2007-01-01 12:30:12', 'sub2', NULL, NULL, NULL, NULL, NULL)")
    dbq("insert into topics values('t889')")
    dbq("insert into messages values('t889', 3, 'text/plain', 'aaa2', '2007-01-01 12:30:22', 'sub2', NULL, NULL, NULL, NULL, NULL)")
    storage = Storage()
    assert Topic.last_msg_seq == 3


def test_load_topic():
    dbq("insert into topics values('t888')")
    dbq("insert into messages values('t888', 1, 'text/plain', 'aaa', '2007-01-01 12:30:11', 'sub2', NULL, NULL, NULL, NULL, NULL)")
    dbq("insert into messages values('t888', 2, 'text/plain', 'bbb', '2007-01-01 12:30:12', 'sub2', 1, 'sub1', 1, NULL, NULL)")
    dbq("insert into subscriptions values ('t888', 'sub9', 'http://localhost', 1)")

    m = Storage()
    t = m._load_topic('t888')
    queue = t.subscriptions['sub9'].queue
    assert queue[0].in_reply == None
    assert queue[0].recipient == None
    assert queue[0].status == None
    assert queue[0].ttl == None
    assert queue[1].in_reply == 1
    assert queue[1].recipient == 'sub1'
    assert queue[1].status == None
    assert queue[1].ttl == 1


def test_save_topic():
    from test_topic import TestSubscription
    m = Storage()
    t = Topic('topic3')
    t.subscribe(TestSubscription(t, 'sub6'))
    t.subscribe(TestSubscription(t, 'sub7'))
    m.save_topic(t)
    rows = dbq("select topic from topics where topic='topic3'")
    assert rows[0] == ('topic3',)

    m.save_topic(t)


def test_save_msg():
    storage = Storage()
    t = storage._load_topic('t777')
    msg = Message(body='t777', seq=3, sender='sub2', content_type='text/plain', in_reply=10, recipient='sub3', ttl=5)
    storage.save_msg(t, msg)
    
    rows = dbq("select recipient, ttl, status from messages where topic='t777' and seq=3")
    assert rows[0] == ('sub3', 5, None)

    msg.ttl = 4
    storage.save_msg_ttl(msg)
    rows = dbq("select recipient, ttl, status from messages where topic='t777' and seq=3")
    assert rows[0] == ('sub3', 4, None)

    msg.ttl = 0
    storage.save_msg_ttl(msg)
    rows = dbq("select recipient, ttl, status from messages where topic='t777' and seq=3")
    assert rows[0] == ('sub3', 0, 'X')


def test_cyrillic():
    text = u'Спасибо Кириллу и Мефодию'

    s = Storage()
    t = s.get_topic('t1')
    msg, reply_topics = post(t, text, 'sub2')

    rows = dbq('select body from messages where seq=? and topic=?', (msg.seq, 't1'))

    assert rows[0][0] == text

    # now let's see how queue loads
    sub = NullSubscription(t, 'sub1')
    t.subscribe(sub)
    text += ' 123'
    post(t, text, 'sub2')

    s = Storage()
    t = s.get_topic('t1')
    assert t.subscriptions['sub1'].queue[0].body.read(s) == text


def test_unsubscribe():
    s = Storage()
    t = s.get_topic('t1')
    sub = NullSubscription(t, 'sub1')
    s.unsubscribe(t, sub)

    dbq("insert into subscriptions values ('t1', 'sub9', 'http://localhost', 1)")
    s._load_all_topics()

    t = s.get_topic('t1')
    sub = NullSubscription(t, 'sub9')
    s.unsubscribe(t, sub)

    rows = dbq("select * from subscriptions where topic='t1' and subscriber='sub9'")
    assert len(rows) == 0
