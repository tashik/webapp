# -*- coding: utf-8 -*-

"""
$Id: $
"""

import config
config.PBUS_MY_NAME = 'benchmark'
config.PBUS_PASSWORD = config.PASSWD['benchmark']
config.PBUS_URL = 'http://127.0.0.1:%s' % config.SERVER_PORT

from rx.pbus.client import post, ping


def bench_post():
    post('benchmark', '{}')
    #print '.'
    #print ping()



if __name__ == '__main__':
    import timeit
    print(timeit.timeit('bench_post()',
                        setup="from __main__ import bench_post",
                        number=1000))
