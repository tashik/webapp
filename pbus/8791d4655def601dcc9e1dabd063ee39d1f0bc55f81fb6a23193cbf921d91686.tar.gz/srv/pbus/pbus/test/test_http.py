# -*- coding: utf-8 -*-

import mock
import pytest

from models.subscription import *
from models.topic import Topic
from models.storage import Storage

import threading
import BaseHTTPServer

TCP_REJECT_URL = 'http://localhost:1'
TCP_DENY_URL = 'http://www.ru:444'

TEST_SERVER_URL = 'http://localhost:18765'

pytestmark = pytest.mark.usefixtures('init_db', 'clear_tables')


class _TestHTTPHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def do_POST(self):
        self.server.content_type = self.headers.get("content-type")
        data = self.rfile.read(int(self.headers["content-length"]))
        print "got POST with data=", repr(data)
        if self.path == '/quit':
            self.server.stop = True
            self.send_response(200, 'Going down')
        elif self.server.simulate_error:
            self.send_response(504, 'Simulated temporary error')
        elif self.server.simulate_permanent:
            self.send_response(500, 'Simulated permanent error')
        elif self.path == '/callback':
            self.server.received.append(data)
            self.send_response(200, 'Ok')
        else:
            self.send_response(404, 'Not found')
            
        self.end_headers()

    def log_request(self, *args, **kw):
        pass


class _TestHTTPServer(BaseHTTPServer.HTTPServer):
    def __init__(self):
        BaseHTTPServer.HTTPServer.__init__(self, ('localhost', 18765),
                                           _TestHTTPHandler)

        self.received = []
        self.simulate_error = False
        self.simulate_permanent = False

    def serve_forever(self):
        """Handle one request at a time until stopped."""
        self.stop = False
        while not self.stop:
            self.handle_request()


class ServerThread(threading.Thread):
    def run(self):
        self.server.serve_forever()

    def stop(self):
        self.server.simulate_error = False
        urllib2.urlopen(TEST_SERVER_URL + '/quit', '1')
        self.join()


def post(t, body, sender='sub2'):
    msg = Message(body=body, sender=sender)
    return msg, t.post(msg)


def setup_http():
    st = ServerThread()
    server = st.server = _TestHTTPServer()
    return server, st

@mock.patch('config.RETRY_PERIOD', 0)
@mock.patch('models.topic.Topic.last_msg_seq', 0)
def test_http():
    server, st = setup_http()
    t = Topic('topic1')
    s = HTTPSubscription(t, 'subscriber1', TEST_SERVER_URL + '/callback')
    t.subscribe(s)

    st.start()
    try:
        msg = Message('hello', 'sub2')
        t.post(msg)
        assert server.received == ['hello']
        assert server.content_type == 'application/octet-stream'

        msg = Message('hello2', 'sub2', content_type='text/plain')
        t.post(msg)
        assert server.received == ['hello', 'hello2']
        assert server.content_type == 'text/plain'

        server.simulate_error = True
        post(t, 'hello3')
        assert server.received == ['hello', 'hello2']

        server.simulate_error = False
        post(t, 'hi4')
        assert server.received == ['hello', 'hello2', 'hello3', 'hi4']

        # closed port
        s.callback_url = 'http://localhost:0'
        post(t, 'hi5')

        assert server.received == ['hello', 'hello2', 'hello3', 'hi4']
        assert len(s.queue) == 1

        s.callback_url = TEST_SERVER_URL + '/callback'
        post(t, 'hi6')

        assert server.received == ['hello', 'hello2', 'hello3', 'hi4', 'hi5', 'hi6']

    finally:
        st.stop()


def test_persistent_queue():
    server, st = setup_http()
    m = Storage()
    t = m.get_topic('topic_p')
    s = HTTPSubscription(t, 'subscriber1', TEST_SERVER_URL + '/callback')
    t.subscribe(s)

    st.start()
    try:
        post(t, 'hello')
        assert server.received == ['hello']

        post(t, 'hello2')
        assert server.received == ['hello', 'hello2']

        server.simulate_error = True
        post(t, 'hello3')
        assert server.received == ['hello', 'hello2']

        m = Storage()
        t = m.get_topic('topic_p')

        assert len(t.subscriptions) == 1
        assert len(t.subscriptions['subscriber1'].queue) == 1

        server.simulate_error = False



        post(t, 'hello4')

        assert server.received == ['hello', 'hello2', 'hello3', 'hello4']


        # перманентная ошибка
        server.simulate_permanent = True
        try:
            post(t, 'hello10')
            assert 0, 'must raise HardFailure'
        except HardFailure, e:
            assert str(e).find('Simulated') != -1
        assert len(server.received) == 4
        assert t.subscriptions['subscriber1'].status == STATUS_ERROR

        # пока статус не сброшен, отсылка ставится на паузу
        server.simulate_permanent = False
        post(t, 'hello11')
        assert len(server.received) == 4

        t.subscriptions['subscriber1'].reset_status()
        post(t, 'hello12')
        assert len(server.received) == 7

        
    finally:
        st.stop()


def test_tcp_reject():
    t = Topic('topic1')
    s = HTTPSubscription(t, 'tcp_reject', TCP_REJECT_URL)
    t.subscribe(s)

    try:
        post(t, 'hello')
    except urllib2.URLError:
        pass


def test_tcp_deny():
    t = Topic('topic1')
    s = HTTPSubscription(t, 'tcp_deny', TCP_DENY_URL)
    t.subscribe(s)

    import socket
    socket.setdefaulttimeout(1)
    try:
        post(t, 'hello')
    except urllib2.URLError:
        pass
    finally:
        socket.setdefaulttimeout(60)
