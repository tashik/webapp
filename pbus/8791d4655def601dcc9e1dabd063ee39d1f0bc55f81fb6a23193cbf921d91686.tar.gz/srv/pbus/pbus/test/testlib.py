# -*- coding: utf-8 -*-
import db

def dbq(query, args=()):
    c = db.con().cursor()
    c.execute(query, args)
    r = c.fetchall()
    c.close()
    return r
