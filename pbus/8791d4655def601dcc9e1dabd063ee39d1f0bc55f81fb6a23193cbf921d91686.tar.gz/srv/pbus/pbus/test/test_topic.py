# -*- coding: utf-8 -*-

from test import testlib
import pytest

import db
from models.message import Message
from models import subscription
from models.storage import Storage
from models.topic import *

from models.subscription import NullSubscription

class TestSubscription(subscription.NullSubscription):
    received = {}
    msg = []

    def add(self, msg):
        TestSubscription.received.setdefault(self.subscriber_name, []).append(msg.seq)
        TestSubscription.msg.append(msg)

    def __init__(self, *args, **kw):
        self.flushed = False
        super(TestSubscription, self).__init__(*args, **kw)

    def flush_queue(self):
        self.flushed = True
        return set()


def post(t, body, sender, in_reply=None):
    msg = Message(body=body, sender=sender, in_reply=in_reply)
    return msg, t.post(msg)


@pytest.fixture()
def setup_subscription(request):
    TestSubscription.received = {}
    TestSubscription.msg = []
    Storage.null_subscription = TestSubscription
    request.addfinalizer(remove_subscription)

def remove_subscription():
    Storage.null_subscription = NullSubscription

pytestmark = pytest.mark.usefixtures('init_db', 'clear_tables', 'setup_subscription')


def test_deliver():
    t = Topic('topic1')
    s = TestSubscription(t, 'sub1')

    t.subscribe(s)

    msg = Message('hello', 'sub2')
    reply_topics = t.post(msg)
    assert msg.seq == 1

    msg = Message('hello2', 'sub3', in_reply=999)
    reply_topics = t.post(msg)
    assert msg.seq == 2
                
    assert s.received['sub1'] == [1, 2]
    assert s.msg[0].sender == 'sub2'
    assert s.msg[1].sender == 'sub3'

    assert s.msg[1].in_reply == 999
    
    msg = Message(body='hello2', sender='sub3', in_reply=999, recipient='sub1')
    reply_topics = t.post(msg)
    assert len(s.msg) == 3
    assert msg.seq == 3
    assert s.msg[2].recipient == 'sub1'

    msg = Message(body='hello2', sender='sub3', in_reply=999, recipient='invalid1')
    reply_topics = t.post(msg)
    assert len(s.msg) == 3  # не доставлено, т.к. нет такого получателя


def test_async_deliver():
    t = Topic('topic1')
    s = TestSubscription(t, 'sub1')
    t.subscribe(s)

    msg = Message('hello', 'sub2')
    reply_topics = t.post(msg, deliver=False)
    assert s.flushed == False

    reply_topics = t.post(msg)
    assert s.flushed == True


def test_persistent():
    m = Storage()
    t = m.get_topic('topic1')
    s = TestSubscription(t, 'sub19')
    t.subscribe(s)

    msg, reply_topics = post(t, 'hello', 'sub1')
    assert msg.seq == 1

    # после перезапуска pbus сообщения должны загружаться из базы
    m = Storage()
    t = m.get_topic('topic1')
    assert len(t.subscriptions) == 1

    msg, reply_topics = post(t, 'hello2', 'sub1')
    assert msg.seq == 2

    # Если этот тест ломается - не забываем про опцию nosetest --with-isolation
    assert s.received['sub19'] == [1, 2]


def test_load_all_topics():
    m = Storage()
    t = m.get_topic('topic1')
    t2 = m.get_topic('topic2')
    s1 = TestSubscription(t, 'sub1')
    s2 = TestSubscription(t, 'sub2')
    s3 = TestSubscription(t2, 'sub3')
    s4 = TestSubscription(t2, 'sub4')

    m = Storage()
    assert len(m.topics) == 2


def test_thread_safety():
    import threading
    import time
    from models.subscription import NullSubscription

    msg_nums = []

    m = Storage()
    t = m.get_topic('topic1')
    s = NullSubscription(t, 'sub1')
    db.con().commit()

    import thread
    lock = thread.allocate_lock()

    class SenderThread(threading.Thread):
        def run(self):

            for n in range(0, 10):
                with lock:
                    msg = Message('hello', 'sub2')
                    reply_topics = t.post(msg)
                    assert msg.seq not in msg_nums
                    msg_nums.append(msg.seq)
                    db.con().commit()

    t1 = SenderThread()
    t1.delay = 0
    t2 = SenderThread()
    t2.delay = 0

    t1.start()
    t2.start()

    t1.join()
    t2.join()



def test_post_to_nonexistant():
    m = Storage()
    t = m.get_topic('topic999')
    post(t, 'hello', 'sub1')


