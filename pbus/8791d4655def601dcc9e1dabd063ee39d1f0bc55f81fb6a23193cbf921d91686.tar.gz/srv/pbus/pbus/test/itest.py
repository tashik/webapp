# -*- coding: utf-8 -*-
import base64
import logging
import os
import sys
import time
import urllib
import urllib2

import config

PBUS_URL = 'http://127.0.0.1:%s/' % config.SERVER_PORT
PBUS_PASSWORD = '123'

class App1:
    port = 8765
    client_name = 'itest_client'
    callback_url = 'http://127.0.0.1:%s/notify' % port

class App2:
    port = 8766
    client_name = 'itest_client2'
    callback_url = 'http://127.0.0.1:%s/notify' % port


class Root(object):
    import cherrypy
    @cherrypy.expose
    def notify(self, **params):
        import cherrypy
        print >>sys.stderr, 'NOTIFY %s' % params, cherrypy.request.body.read()
        return ''

def run_server(app):
    import cherrypy

    cherrypy.config.update({
        'log.screen' : True,
        #'log.error_file': os.path.join(os.path.dirname(__file__), 'site.log'),
        'tools.decode.on': True,
        'tools.encode.on': True,
        'tools.encode.encoding': 'utf-8',
        'tools.decode.encoding': 'utf-8',
        'server.socket_port': app.port,
        'server.socket_host': '127.0.0.1',
        'server.thread_pool': 4,
        })

    cherrypy.quickstart(Root())


class PBusClient(object):
    def __init__(self, name, password):
        basic_auth = 'basic %s' % base64.encodestring('%s:%s' % (name, password)).rstrip()
        self.common_headers = {'Content-Type': 'application/json;charset=utf-8',
                               'Authorization': basic_auth}

    def subscribe(self, topic_name, callback_url):
        callback_url = urllib.quote(callback_url, safe='')
        url = '%s/%s/subscribe/%s' % (PBUS_URL, topic_name, callback_url)
        req = urllib2.Request(url=url, data='', headers=self.common_headers)
        urllib2.urlopen(req)

    def unsubscribe(self, topic_name):
        url = '%s/%s/unsubscribe' % (PBUS_URL, topic_name)
        req = urllib2.Request(url=url, data='', headers=self.common_headers)
        urllib2.urlopen(req)

    def post(self, topic, msg, recipient=None, ttl=None, reply_ttl=None, user_agent=None):
        """ Если указан recipient - сообщение приватное (point-to-point) """
        url = '%s/%s/post' % (PBUS_URL, topic)
        if recipient:
            url += '/private/%s' % recipient

        headers = self.common_headers.copy()
        if ttl is not None:
            headers['X-TTL'] = str(ttl)
        if reply_ttl is not None:
            headers['X-Reply-TTL'] = str(reply_ttl)

        req = urllib2.Request(url=url, data=msg, headers=headers)
        urllib2.urlopen(req)

    @staticmethod
    def ping():
        url = '%s/ping' % PBUS_URL
        return urllib2.urlopen(url, '').read()


def run_client(app):
    itest_svr = PBusClient(app.client_name, '123')
    itest_svr.subscribe('topic', app.callback_url)
    time.sleep(2)

    itest_client = PBusClient(app.client_name, '123')
    itest_client.post('topic', 'hello')

    time.sleep(2)


def main():
    pid = os.fork()
    if not pid:
        run_server(App1)
        sys.exit()

    print('Checking PBUS: %s' % PBusClient.ping())

    run_client(App1)

    print "------- Async delivery test"

    run_client(App2)

    pid2 = os.fork()
    if not pid2:
        run_server(App2)
        sys.exit()

    time.sleep(30)
    os.kill(pid2, 15)
    os.wait()

    os.kill(pid, 15)
    os.wait()

if __name__ == '__main__':
    main()
