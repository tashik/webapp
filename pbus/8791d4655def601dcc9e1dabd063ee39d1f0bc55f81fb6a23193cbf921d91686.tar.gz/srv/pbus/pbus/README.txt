Pre-requisites
--------------

 * CherryPy
 * Routes
 * sqlite 3.4.0 (probably complied with --enable-threadsafe)
 * pysqlite
 * nose
 * wsgi_intercept


Testing
-------

Run tests using py.test test/


Running
-------

Run pbus server:

    pyton ws.py

Reload pbus configuration:

    kill -USR1 `cat pid/ws.pid`
