# -*- coding: utf-8 -*-
from multiprocessing.pool import ThreadPool
import threading
import time
import traceback

from models import subscription
from util import mail
import config

class StopServer(Exception):
    pass


def mail_exception_report(s, e):
    try:
        mail.sendToAdmin('P-Bus critical error / %s' % s.subscriber_name, str(e))
    except Exception:
        traceback.print_exc()


pool = ThreadPool(processes=config.DELIVERY_THREAD_POOL)


class RetryDeliveryThread(threading.Thread):

    def __init__(self, storage):
        super(RetryDeliveryThread, self).__init__(name='RetryDeliveryThread')
        self.storage = storage
        self.stop_flag = False

    def run(self):
        try:
            while 1:
                if self.stop_flag:
                    raise StopServer()

                subs = self._schedule_deliveries()
                if subs:
                    self._send_messages(subs)
                else:
                    time.sleep(.1)

        except StopServer:
            pass

    def _schedule_deliveries(self):
        subs = []
        for t in self.storage.topics.values():
            for sub in t.subscriptions.values():
                if sub.next_retry <= time.time() and sub.queue:
                    subs.append(sub)
        return sorted(subs, key=lambda sub: -sub.next_retry)

    def _send_messages(self, subs):
        for sub in subs:
            if self.stop_flag:
                raise StopServer()
            with sub.topic.lock:
                if not sub.is_busy:
                    sub.is_busy = True
                    pool.apply_async(self._run_delivery, (sub,))

    def _run_delivery(self, sub):
        try:
            sub.flush_queue()
        except subscription.HardFailure as e:
            traceback.print_exc()
            mail_exception_report(sub, e)
        except Exception:
            traceback.print_exc()
        finally:
            sub.is_busy = False

    def start(self):
        self.stop_flag = False
        super(RetryDeliveryThread, self).start()

    def stop(self):
        self.stop_flag = True