#!/bin/bash -eu

count=999999

while :
do
    count=$(sqlite3 data/db < sql/cleanup.sql)
    echo Remaining messages to delete: $count
    if [[ $count -lt 100 ]]; then
	break
    fi
    sleep 60
done

./kube/unsubscribe_dead.py
