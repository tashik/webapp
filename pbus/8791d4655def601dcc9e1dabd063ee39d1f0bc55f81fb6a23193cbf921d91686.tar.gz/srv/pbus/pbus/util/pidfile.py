# -*- coding: utf-8 -*-

"""
$Id: $
"""

import fcntl
import os
import config

class AlreadyRunning(Exception):
    pass

class PidFile(object):

    def __init__(self, appName):
        self.appName = appName

        self._pidFileOk = None
        self.fileName = "%s/%s.pid" % (config.PIDDIR, appName)

        f = open(self.fileName, "a+")
        f.seek(0)
        fcntl.flock(f, fcntl.LOCK_EX)
        try:
            pids = f.read()
            for pid in pids.strip().split(" "):
                if not pid:
                    continue
                try:
                    os.kill(int(pid), 0)
                except OSError:
                    pass
                else:
                    if int(pid) != os.getpid():
                        raise AlreadyRunning("Process already running with pid=%s" % pid)
            f.seek(0)
            f.truncate()
            f.write("%s " % os.getpid())
            self._pidFileOk = 1
        finally:
            fcntl.flock(f, fcntl.LOCK_UN)

    def __del__(self):
        if self._pidFileOk:
            os.unlink(self.fileName)

