# -*- coding: utf-8 -*-
import smtplib
import base64
import config

def base64encode(s):
    return ('=?%s?B?%s?=' % ('utf-8', base64.encodestring(s))).replace('\n', '')

def sendToAdmin(subject, body, content_type="text/plain"):
    for toaddr in config.ADMIN_EMAIL:
        _send(toaddr, toaddr, subject, body, content_type)
       

def _send(envtoaddr, toaddr, subject, body, content_type):
    fromaddr = '%s <%s>' % (base64encode(config.SYSTEM_NAME), config.SMTP_FROM)
    smtp = smtplib.SMTP(config.SMTP_SERVER, config.SMTP_PORT)
    smtp.sendmail(config.SMTP_FROM, envtoaddr,
"""From: %s
To: %s
Subject: %s
Content-Transfer-Encoding: 8bit
Content-Type: %s; charset="utf-8"

%s""" %(fromaddr, toaddr, base64encode(subject),
        content_type, body))
    smtp.quit()
