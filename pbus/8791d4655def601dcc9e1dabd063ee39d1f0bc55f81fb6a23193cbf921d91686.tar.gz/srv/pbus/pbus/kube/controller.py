#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import json
import traceback
from log import CONSOLE as LOG

from kubernetes import client, config, watch

import db
from models.storage import Storage, HTTPSubscription


def parse_cmd_line():
    parser = argparse.ArgumentParser(description='Watch kubernetes pods and update varnish on change')
    parser.add_argument('--namespace')
    parser.add_argument('--run-once', action='store_true')
    parser.add_argument('--verbose', '-v', action='store_true')
    return parser.parse_args()


class Subscriber(object):
    def __init__(self, name, ip, port, topic_name, notify_path):
        self.name = name
        self.ip = ip
        self.port = port
        self.topic_name = topic_name
        self.notify_path = notify_path
    

class PBusController(object):
    def __init__(self):
        self.storage = Storage()
    
    def subscribe(self, subscription):
        callback_url = 'http://%s:%s%s' % (subscription.ip, subscription.port, subscription.notify_path)
        LOG('subscribe update', subscription.name, subscription.topic_name, callback_url)
        c = db.con().cursor()
        c.execute('''replace into subscriptions (topic, subscriber, callback_url) values (?, ?, ?)''',
                  (subscription.topic_name, subscription.name, callback_url))

    def unsubscribe(self, subscription):
        LOG('unsubscribe', subscription.name)
        c = db.con().cursor()
        c.execute('''delete from subscriptions where topic=? and subscriber=?''',
                  (subscription.topic_name, subscription.name))

    def unsubscribe_all(self):
        c = db.con().cursor()
        c.execute("delete from subscriptions")

    def reload_pbus(self):
        #os.system('pkill -f pid/ws.pid' -USR1')
        pass



def main():
    args = parse_cmd_line()

    import kube
    api, namespace = kube.init_connection(args)

    controller = PBusController()
    controller.unsubscribe_all()
    event_loop = EventLoop(api, namespace, controller, debug=args.verbose)

    ret_list = api.list_namespaced_event(namespace).items
    print ret_list
    last_resource_version = 0
    for event in ret_list:
        last_resource_version = max(last_resource_version, int(event.metadata.resource_version))


    ret = api.list_namespaced_pod(namespace, watch=False, label_selector='pbus/subscriber=true')
    if args.verbose:
        LOG(ret)
    for pod in ret.items:
        subscribers = subscribers_from_pod(pod)
        for subscriber in subscribers:
            controller.subscribe(subscriber)

    if not args.run_once:
        controller.reload_pbus()
        while 1:
            last_resource_version = event_loop.run(resource_version=last_resource_version)
            LOG('Restarting event loop')


def subscribers_from_pod(pod):
    try:
        app = pod.metadata.labels.get('app')
        pbus_json = pod.metadata.annotations.get('pbus_subscribe')
    except AttributeError:
        return []
    if pbus_json is None or app is None:
        return []

    try:
        port = pod.spec.containers[0].ports[0].container_port
    except (NameError, IndexError):
        return []

    pbus_subs = json.loads(pbus_json)
    subscribers = []
    for topic_name, notify_path in pbus_subs.items():
        subscribers.append(Subscriber(pod.metadata.name, pod.status.pod_ip, port, topic_name, notify_path))
    return subscribers



class EventLoop(object):
    def __init__(self, api, namespace, controller, debug=False):
        self.api = api
        self.namespace = namespace
        self.controller = controller
        self.debug = debug
        
    def run(self, resource_version):
        print '-' * 80
        w = watch.Watch()
        for event in w.stream(self.api.list_namespaced_pod, self.namespace, include_uninitialized=True,
                              label_selector='pbus/subscriber=true', resource_version=resource_version):
            #resource_version = int(event['metadata']['resource_version'])
            try:
                self.process_event(event)
            except Exception:
                traceback.print_exc()
    
    
    def process_event(self, event):
        if self.debug:
            LOG(event)
        print("Event: %s %s" % (event['type'], event['object'].metadata.name))
    
        #pod_name = event['object']['name']
        #pod = read_namespaced_pod(pod_name, self.namespace)
        pod = event['object']
        subscribers = subscribers_from_pod(pod)
        if not subscribers:
            return

        if event['type'] == 'MODIFIED':
            container_statuses = pod.status.container_statuses
            if container_statuses and all(cs.ready for cs in container_statuses):
                LOG(pod.metadata.name, 'READY')
                for subscriber in subscribers:
                    self.controller.subscribe(subscriber)
                self.controller.reload_pbus()
    
        elif event['type'] == 'DELETED':
            for subscriber in subscribers:
                self.controller.unsubscribe(subscriber)
            self.controller.reload_pbus()


if __name__ == '__main__':
    main()
