# -*- coding: utf-8 -*-

import os
import sys

import kubernetes
from kubernetes import client, config, watch



TOKEN_FILE = '/var/run/secrets/kubernetes.io/serviceaccount/token'
NAMESPACE_FILE = '/var/run/secrets/kubernetes.io/serviceaccount/namespace'

def connect():
    if 'KUBECONFIG' in os.environ:
        config.load_kube_config(os.environ['KUBECONFIG'])
    else:
        api_key = file(TOKEN_FILE).read()
        kube_host = 'https://%(KUBERNETES_SERVICE_HOST)s:%(KUBERNETES_SERVICE_PORT)s' % os.environ

        kubernetes.client.configuration.api_key['authorization'] = api_key
        kubernetes.client.configuration.host = kube_host
        kubernetes.client.configuration.verify_ssl = False
        kubernetes.client.configuration.api_key_prefix['authorization'] = 'Bearer'

    return client.CoreV1Api()


def init_connection(args):
    api = connect()

    if args.namespace:
        namespace = args.namespace
    elif os.path.exists(NAMESPACE_FILE):
        with open(NAMESPACE_FILE) as f:
            namespace = f.read()
    else:
        print >>sys.stderr, 'Unable to determine namespace from Kubernetes API. Use --namespace option.'
        sys.exit(1)

    return api, namespace
