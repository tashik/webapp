#!/usr/bin/env python
# -*- coding: utf-8 -*-
import argparse
import logging
import os
import signal

import db
from log import CONSOLE, DEBUG
import config

def parse_cmd_line():
    parser = argparse.ArgumentParser(description='Watch kubernetes pods and update varnish on change')
    parser.add_argument('--namespace')
    parser.add_argument('--verbose', '-v', action='store_true')
    parser.add_argument('--dry-run', '-n', action='store_true')
    return parser.parse_args()

def reload_pbus():
    with open(config.PIDDIR + '/ws.pid') as pidfile:
        pid = int(pidfile.read())
    os.kill(pid, signal.SIGUSR1)

def main():
    args = parse_cmd_line()
    if args.verbose:
        config.LOG_LEVEL = logging.DEBUG

    import kube
    api, namespace = kube.init_connection(args)

    running_pods = set()

    ret = api.list_namespaced_pod(namespace, watch=False)  # label_selector='pbus/subscriber=true'
    for pod in ret.items:
        running_pods.add(pod.metadata.name)

    pods_cursor = db.con().cursor()
    pods_cursor.execute('select subscriber from subscriptions')
    for subscriber, in pods_cursor:
        if '@' in subscriber:
            pod_name = subscriber.split('@')[1]
            DEBUG('pod %s is subscribed' % pod_name)
            if pod_name not in running_pods:
                CONSOLE('delete subscriber %s' % subscriber)
                if not args.dry_run:
                    db.con().execute('delete from subscriptions where subscriber=?', (subscriber,))

    if not args.dry_run:
        reload_pbus()

if __name__ == '__main__':
    main()
