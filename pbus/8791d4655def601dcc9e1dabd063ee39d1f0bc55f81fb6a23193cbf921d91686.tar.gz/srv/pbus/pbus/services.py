# -*- coding: utf-8 -*-
import urllib

import cherrypy
import config
import db
from models.message import Message
from models.subscription import HTTPSubscription


def to_int(s):
    if not s:
        return None
    return int(s)

def complete_transaction(func):
    def wrapper(*args, **kw):
        if config.DISABLE_DB_FSYNC:
            db.con().execute('PRAGMA synchronous=OFF')
        try:
            r = func(*args, **kw)
        except:
            #db.con().rollback()
            raise
        else:
            #db.con().commit()
            pass
        return r
    return wrapper

class Root(object):
    def __init__(self, storage):
        self.storage = storage

    @complete_transaction
    def subscribe(self, topic_name, callback_url):
        callback_url = urllib.unquote(callback_url)
        subscriber_name = cherrypy.request.login
        # lock нужен, т.к. одновременно может прийти два запроса на подписку на отсутствующий топик
        with self.storage.lock:
            t = self.storage.get_topic(topic_name)
            if subscriber_name in t.subscriptions:
                # if we already have it, then only update its parameters
                subscription = t.subscriptions[subscriber_name]
                subscription.reset_status()
                if subscription.callback_url != callback_url:
                    subscription.callback_url = callback_url
                    self.storage.save_topic(t)
            else:
                s = HTTPSubscription(t, subscriber_name, callback_url)
                t.subscribe(s)
        return ''

    @complete_transaction
    def unsubscribe(self, topic_name):
        subscriber_name = cherrypy.request.login
        if topic_name in self.storage.topics:
            t = self.storage.get_topic(topic_name)
            if subscriber_name in t.subscriptions:
                t.unsubscribe(t.subscriptions[subscriber_name])
                return ''
        raise cherrypy.HTTPError(404, 'Subscription not found')

    @complete_transaction
    def post(self, topic_name, async=False, **kw):
        body = cherrypy.request.body.read()
        body = unicode(body, 'utf-8')
        t = self.storage.get_topic(topic_name)
        msg = Message(body=body, sender=cherrypy.request.login,
                      content_type=cherrypy.request.headers['Content-Type'],
                      ttl=to_int(cherrypy.request.headers.get('X-TTL')),
                      reply_ttl=to_int(cherrypy.request.headers.get('X-Reply-TTL')))
        with t.lock:
            t.post(msg, deliver=not async)
        return ''

    @complete_transaction
    def post_private(self, topic_name, recipient, async=False, **kw):
        body = cherrypy.request.body.read()
        body = unicode(body, 'utf-8')
        t = self.storage.get_topic(topic_name)
        msg = Message(body=body, sender=cherrypy.request.login,
                      content_type=cherrypy.request.headers['Content-Type'],
                      ttl=to_int(cherrypy.request.headers.get('X-TTL')),
                      reply_ttl=to_int(cherrypy.request.headers.get('X-Reply-TTL')),
                      recipient=recipient)
        with t.lock:
            t.post(msg, deliver=not async)
        return ''

    @complete_transaction
    def ping(self):
        return 'PONG!'
