#!/bin/bash -eu

# Когда под /srv/pbus/data монтируется volume, владельцем каталога становится root (в зависимости от типа volume)
chown pbus $INSTANCE_HOME/{log,data} || true

if [[ -z "$@" ]]; then
    exec su-exec pbus python ws.py
else
    exec su-exec pbus $@
fi
