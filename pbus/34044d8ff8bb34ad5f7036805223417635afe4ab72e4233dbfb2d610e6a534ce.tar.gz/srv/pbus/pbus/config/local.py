# -*- coding: utf-8 -*-
PRODUCTION = False

SYSTEM_NAME = 'P-Bus Dev (local)'
ADMIN_EMAIL = [] #['an@ramax.ru']

PIDDIR = '/tmp'

PASSWD = {'aflcab': '######',
          'vocabs': '######',
          'booking': '######',
          }

ADMIN_PASSWD = {'admin': '######'}

CALLBACK_PASSWD = '######'
