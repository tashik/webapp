# -*- coding: utf-8 -*-

"""Aeroflot Cabinet Application Configuration Template.
"""
from config_defaults import *

# Адрес БД берем из переменных окружения PGHOST, PGPORT, PGUSER, PGDATABASE
POSTGRES_DSN = "application_name='%s'" % INSTANCE_ID

# БД системы бронирования (она же afl-mobile)
BOOKING_SERVICE_URL = None

# Внешние ссылки ---------------------------------------------------------------

NEGATIVE_RESPONSE_SECRET = '#######'  # Любая фраза. Изменить после инсталяции ЛК.

PROMO_ACTIONS_SECRET_KEY = '#######'  # Salt для хэширования ссылок промо-акций в письмах

PROXY_IP = ['127.0.0.1']

# Сервис SMS-рассылки
SMS_SUBSCRIPTIONS_URL = None  # None отключает поддержку SMS-шлюза
SMS_SUBSCRIPTIONS_DIGEST_LOGIN = 'personal_login'
SMS_SUBSCRIPTIONS_DIGEST_PASSWORD = 'personal_password'
SMS_SUBSCRIPTIONS_SYSTEM_LOGIN = 'login'
SMS_SUBSCRIPTIONS_SYSTEM_PASSWORD = '#######'

PBUS_URL = None  # 'http://127.0.0.1:8390'
PBUS_MY_NAME = os.environ.get('USER') or os.environ.get('USERNAME')
PBUS_PASSWORD = '#######'
PBUS_CALLBACK_HOST = '127.0.0.1'
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_CALLBACK_PASSWORD = '#######'
PBUS_VOCAB_RECIPIENTS = 'vocabs'
PBUS_TOPICS = 'vocabs'

# Хэши для доступа к веб-сервисам мониторинга - история ретро, ошибки, и т.д.
# Для вычисления хэша используем команду: print hashlib.md5('mon-ws-client:aeroflot-digest:PASSWORD').hexdigest()
MONITORING_WS_DIGEST = {'mon-ws-client': '#######'}
# Кто имеет доступ к расширенному отчету об ошибке
ERROR_DETAILS_ACCESS = ['mon-ws-client']

# Баннер на главной для списка пользователей
ROOT_BANNER_PARTNER_URL = ''  # адрес для отправки персональных данных
ROOT_BANNER_PARTNER_SECRET = '#######'  # Соль для хэширования при отправке

PASSBOOK_WS_URL = 'http://ws:6380/ws2/v.0.0.1/json/passbook/bonus'
PASSBOOK_UPDATE_WS_URL = 'http:/ws:6380/ws2/v.0.0.1/json/passbook/bonus_update'
PASSBOOK_WS_USER = 'ws-passbook'
PASSBOOK_WS_PASSWORD = '#######'

# Для создания ключа можно использовать os.urandom(24)
CSRF_SECRET_KEY = '############################'

# Basic-auth для сервиса обновления пассбука
UPDATE_PASSBOOK_SRV_USERNAME = '#######'
UPDATE_PASSBOOK_SRV_PASSWORD = '#######'

# настройки для общих шаблонов
USE_COMMON_TEMPLATES = True  # использование локальных шаблонов inc_*, высший приоритет
USE_SAVED_TEMPLATES = False  # использовать сохраняемые в templates/temp django-шаблоны
FRONTEND_IP = None  # ip-адрес варниша на стендах
CHECK_TIME_INTERVAL = 60 * 100  # минимальное время для повторной отправки запроса (в сек.)

# Шлюз к Oracle Аэрофлота (CDD и активности)
AFL_DATA_URL = None  # 'http://localhost:3580'
AFL_DATA_LOGIN = ''
AFL_DATA_PASSWORD = '#######'

# Значения с prod/staging
KNOWN_LANGUAGES = ['ru', 'en']
CARD_IMG_WIDTH = 400
MENU_SERVICE_ALLOWED_DOMAINS = ['pay.test.aeroflot.ru']
GOOGLE_TAG_MANAGER_ID = 'GTM-5ZKPBX'
REGISTRATION_EMAIL_CHECK_TIMEOUT = datetime.timedelta(3)

# Старые значения из defaults
BIG_DATA_BANNER_SERVICE_URL = 'https://testbanners.aeroflot.ru:33999'

# Siebel Тестовый!
SIEBEL_WS_USERNAME = '#######'
SIEBEL_WS_PASSWORD = '#######'
SIEBEL_SOAP_URL = 'http://95.143.123.111/eai_anon_enu/start.swe?SWEExtSource=SecureWebService&SWEExtCmd=Execute&WSSOAP=1'

EPR_PI_ADD_BINDING_URL = 'pay.test.aeroflot.ru/test-nf/aeropayment/epr/startbinding.do'
EPR_PI_ADD_BINDING_URL_PDA = 'pay.test.aeroflot.ru/test-nf/aeropayment/epr/startmobilebinding.do'
EPR_PI_SERVICE_URL = 'https://pay.test.aeroflot.ru/test-nf/aeropayment/webservices/binding-ws'
EPR_PI_USERNAME = 'ramax-api'
EPR_PI_PASSWORD = 'ramax-api'

EPRPIN_WS_URL = 'https://test.paymentgate.ru/testaeroflot/webservices/sabreLoyaltyPayment-ws'
EPRPIN_WS_USERNAME = 'testpingen'
EPRPIN_WS_PASSWORD = '#######'

execfile(APPDIR + '/config_cluster.py')
