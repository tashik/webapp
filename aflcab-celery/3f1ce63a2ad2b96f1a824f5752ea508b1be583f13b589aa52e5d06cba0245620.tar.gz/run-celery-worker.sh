#!/bin/sh -eu

: ${CELERY_APP_NAME:=async}
: ${INSTANCE_NUMBER:=0}

mkdir -p $APPDIR/log/celery

exec celery -A ${CELERY_APP_NAME} \
     worker -n worker_siebel_${INSTANCE_NUMBER} -f $APPDIR/log/celery/%n%I.log -l INFO -c 4 -Q siebel,celery \
     --workdir=${AFLCABDIR} \
     --time-limit=200
