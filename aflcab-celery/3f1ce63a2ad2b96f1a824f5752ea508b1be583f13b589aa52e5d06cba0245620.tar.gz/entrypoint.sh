#!/bin/bash -eu

if [[ -z "$@" ]]; then
    # default action
    mkdir -p "$INSTANCE_HOME/log/errors"
    mkdir -p "$INSTANCE_HOME/log/subs"
    # WARNING: umask т.к. ЛК1 без докера
    cd "$INSTANCE_HOME/afl_cabinet" 
    umask 000 
    exec python -u ws.py
else
    # cutsom cmd (example: /bin/bash)
    exec "$@"
fi
