#!/bin/sh -ex

exec python -m vmprof --web --web-url https://vmprof.com.spb.ru ws.py $@
