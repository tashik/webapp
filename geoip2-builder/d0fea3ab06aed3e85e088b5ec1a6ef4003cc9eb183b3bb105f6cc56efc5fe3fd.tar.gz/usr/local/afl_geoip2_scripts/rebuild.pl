#!/usr/bin/env perl
# 2014 год — Крым был де-факто присоединён к Российской Федерации с образованием на его территории двух новых субъектов — Республики Крым и города федерального значения Севастополь
#
# https://dev.maxmind.com/geoip/geoip2/release-notes/
# We currently locate Crimea in Ukraine, as we use GeoNames data and they locate Crimea in Ukraine. If GeoNames locates Crimea in Russia in the future,
# we will follow their change and post an announcement here as well as on https://twitter.com/maxmind
#
# https://github.com/maxmind/MaxMind-DB-Reader-perl
# https://github.com/maxmind/MaxMind-DB-Writer-perl
# Установка через cpan
# $ apt-get install buid-essential
# $ cpan
# cpan[1]> install MaxMind::DB::Writer
# cpan[2]> install MaxMind::DB::Reader
#
use utf8;
use strict;
use warnings;
use feature qw( say );
use Data::Dumper;
use Getopt::Long;

use MaxMind::DB::Reader;
use MaxMind::DB::Writer::Tree;
use Net::Works::Network;

my $indb;
my $outdb;
GetOptions(
    'indb:s' => \$indb,
    'outdb:s' => \$outdb,
);

my $reader = MaxMind::DB::Reader->new(
    file=> $indb
);

my %type_map = (
    accuracy_radius       => 'uint16',
    city                  => 'map',
    continent             => 'map',
    country               => 'map',
    geoname_id            => 'uint32',
    is_anonymous_proxy    => 'boolean',
    is_satellite_provider => 'boolean',
    is_in_european_union  => 'boolean',
    latitude              => 'double',
    location              => 'map',
    postal                => 'map',
    longitude             => 'double',
    names                 => 'map',
    registered_country    => 'map',
    represented_country   => 'map',
    metro_code            => 'uint16',
    subdivisions          => [ 'array', 'map' ],
    traits                => 'map',
);

my $map_key_type_callback = sub { $type_map{ $_[0] } // 'utf8_string' };

my $tree = MaxMind::DB::Writer::Tree->new(
    ip_version            => $reader->metadata()->ip_version(),
    record_size           => $reader->metadata()->record_size(),
    database_type         => $reader->metadata()->database_type(),
    languages             => $reader->metadata()->languages(),
    description           => $reader->metadata()->description(),
    map_key_type_callback => $map_key_type_callback,
    merge_strategy        => 'toplevel',
);

open my $fh, '>:raw', $outdb;

my $data_cb = sub {
    my $ip_as_integer = shift;
    my $mask_length   = shift;
    my $data          = shift;
    my $address = Net::Works::Address->new_from_integer(integer => $ip_as_integer );
    my $network = join '/', $address->as_string, $mask_length;
    # меням гос. принадлежность Севастополя (iso код 40 в UA) и Республики Крым (код 43)
    # заменять региональные iso коды на SEV и CR пока нет нужды
    # временную зону также оставляем без изменений
    if ( exists $data->{'country'} && exists $data->{'subdivisions'} ) {
        if ( $data->{'country'}->{'iso_code'} eq "UA" &&
             ( $data->{'subdivisions'}[0]->{'iso_code'} eq "40" ||
               $data->{'subdivisions'}[0]->{'iso_code'} eq "43" )) {
            say Dumper($network, $data->{'country'}, $data->{'subdivisions'});
            $data->{'country'} = {
                "names" => {
                    "fr" => "Russie",
                    "de" => "Russland",
                    "ja" => "ロシア",
                    "en" => "Russia",
                    "pt-BR" => "Rússia",
                    "zh-CN" => "俄罗斯",
                    "ru" => "Россия",
                    "es" => "Rusia"
                },
                "geoname_id" => 2017370,
                "iso_code" => "RU"
            };
            $data->{'registered_country'} = {
                "names" => {
                    "zh-CN" => "俄罗斯",
                    "ru" => "Россия",
                    "pt-BR" => "Rússia",
                    "es" => "Rusia",
                    "fr" => "Russie",
                    "de" => "Russland",
                    "en" => "Russia",
                    "ja" => "ロシア",
                },
                "iso_code" => "RU",
                "geoname_id" => 2017370,
            };
        };
    };
    $tree->insert_network( $network, $data );
};

$reader->iterate_search_tree( $data_cb );
$tree->write_tree( $fh );
close $fh;
say STDERR "Rebuilded";
