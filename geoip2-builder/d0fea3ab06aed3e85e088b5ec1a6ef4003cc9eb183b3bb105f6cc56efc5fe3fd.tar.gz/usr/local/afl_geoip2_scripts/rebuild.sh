#!/bin/bash -eu
# 24.01.2017
#--------------------------------------------------------------------------------------------------

WORK_DIR=$(cd `dirname "${BASH_SOURCE[0]}"` && pwd)
. "${WORK_DIR}/config.sh"

# cd to directory where the MaxMind database is to be downloaded.
if ! cd "${DATA_DIR}"; then
    exit 1
fi

# Download databases and if applicable, their md5s.
echo "$(date '+%F %T') [..] downloading ..."
echo "${MDB_URL}"
wget -T60 -nv "${MDB_URL}" -O "download.${FILE_NAME}.tar.gz"
wget -T60 -nv "${MD5_URL}" -O "download.${FILE_NAME}.md5"

# Checking MD5
MD5_NEW=`cat "download.${FILE_NAME}.tar.gz" | md5sum | awk '{print $1}'; exit ${PIPESTATUS}`
MD5_CTR=`cat "download.${FILE_NAME}.md5"`
if [ "${MD5_NEW}" != "${MD5_CTR}" ]; then
    echo "$(date '+%F %T') [EE] md5sum for download.${FILE_NAME} failed"
    exit 1
fi

# UnZip
gunzip -f "download.${FILE_NAME}.tar.gz"
tar --wildcards -xf "download.${FILE_NAME}.tar" GeoIP2*/${FILE_NAME} -O > "download.${FILE_NAME}"
rm -f "download.${FILE_NAME}.tar"

# Rebuild
echo "$(date '+%F %T') [..] rebuilding ..."
"${WORK_DIR}/rebuild.pl" --indb="download.${FILE_NAME}" --outdb="rebuild.${FILE_NAME}" > rebuild.log

# Test
echo "$(date '+%F %T') [..] testing ..."
"${WORK_DIR}/test.py" --indb="download.${FILE_NAME}" --outdb="rebuild.${FILE_NAME}"

# Update file
mv --backup -f "rebuild.${FILE_NAME}" "${FILE_NAME}"
md5sum "${FILE_NAME}" | awk '{print $1}' > "${FILE_NAME}.md5"
gzip -k -f "${FILE_NAME}"

echo "[OK] "${DATA_DIR}/${FILE_NAME}" rebuild and updated"
rm -f "download.${FILE_NAME}.md5"

exit 0
