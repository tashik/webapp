#!/usr/bin/python
# -*- coding: utf-8 -*-
# 24.01.2017
#------------------------------------------------------------------------------
# Тестируем случайные адреса - проверяем на различия в данных
import argparse
import random
import sys
from time import sleep
import geoip2.database


def main():
    parser = argparse.ArgumentParser(description='Compare mmdb files')
    parser.add_argument('--indb', action='store', type=str, help="original mmdb file", required=True)
    parser.add_argument("--outdb", action='store', type=str, help="rebuilded mmdb file", required=True)
    args = parser.parse_args()
    reader1 = geoip2.database.Reader(args.indb)
    reader2 = geoip2.database.Reader(args.outdb)
    count = 0
    while True:
        count += 1
        ipv4 = '.'.join('%s'%random.randint(0, 255) for i in range(4))
        #ipv4 = '88.135.80.3' #### TEST
        #ipv4 = '109.200.152.1' #### TEST
        try:
            r1 = reader1.city(ipv4)
        except geoip2.errors.AddressNotFoundError:
            r1 = None
        try:
            r2 = reader2.city(ipv4)
        except geoip2.errors.AddressNotFoundError:
            r2 = None
        if r1 != r2:
            print "!=", ipv4
            #print r1
            #print r2
            print r1.country.iso_code, r2.country.iso_code
            print r1.city.name, r2.city.name
            print r1.subdivisions.most_specific.name, r2.subdivisions.most_specific.name
            if r1.country.iso_code != 'UA' or r2.country.iso_code != 'RU':
                print >> sys.stderr, "ERROR: Check it replaced data"
                return False
            if r1.country.iso_code == 'UA' or r2.country.iso_code == 'RU':
              if r1.subdivisions.most_specific.name.find("Republic of Crimea") < 0 and r2.subdivisions.most_specific.name.find("Republic of Crimea") < 0 and r1.subdivisions.most_specific.name.find("Sebastopol City") < 0:
                print >> sys.stderr, "ERROR: Check it replaced data"
                return False


        else:
            #print "==", ipv4
            pass
        if count % 20000 == 0:
            print "Test counter:", count
        if count > 1000000:
            break
        #break #### TEST
    #______________________________________________________
    print "Test passed"
    return True



#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if __name__ == '__main__':
    #______________________________________________________
    # Main
    sys.exit(not main()) # BASH compatible

