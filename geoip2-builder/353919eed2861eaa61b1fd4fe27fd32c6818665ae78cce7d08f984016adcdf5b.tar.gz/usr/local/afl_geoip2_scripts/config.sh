DATA_DIR="/usr/share/nginx/html"
FILE_NAME="GeoIP2-City.mmdb"
LICENSE=`cat .license`
MDB_URL="https://download.maxmind.com/app/geoip_download?edition_id=GeoIP2-City&suffix=tar.gz&license_key=$LICENSE"
MD5_URL="https://download.maxmind.com/app/geoip_download?edition_id=GeoIP2-City&suffix=tar.gz.md5&license_key=$LICENSE"
