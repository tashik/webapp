#!/bin/sh

/etc/init.d/nginx start

while true; do
    sleep 3600
done
exit 0
