#!/bin/bash

set -e

PIDFILE=$APPDIR/pid/giftcert.pid

cd $APPDIR

# если отсутствуют конфиги, копируем из умолчаний
if [ ! -e $INSTANCE_HOME/etc/config.local.py ]
then
  echo -n "Copying config.local.py template... "
  cp $APPDIR/config/local.py.tmpl $INSTANCE_HOME/etc/config.local.py
  echo Done
fi

#chown -R $APP_USER:$APP_USER $INSTANCE_HOME

if [[ -z "$@" ]]; then
  echo Default action
  # default action
  echo -n "Starting instance @ $APP_USER"
  su-exec $APP_USER python ws.py
else
  # custom cmd (example: /bin/bash)
  echo -n "Running $@"
  exec $@
  echo Done
fi
