# -*- coding: utf-8 -*-

"""Path auth"""

import string
import random
import config

def digest_auth(username, realm, ha1):
    def get_ha1(req_realm, req_username):
        if req_realm == realm and req_username == username:
            return ha1
    private_key = ''.join([random.choice(string.letters) for n in range(40)])
    digest_auth = {'tools.auth_digest.on': True,
                   'tools.auth_digest.realm': realm,
                   'tools.auth_digest.get_ha1': get_ha1,
                   'tools.auth_digest.key': private_key,
                   }
    return digest_auth

def basic_auth(username, password, realm):
    return {'tools.auth_basic.on': True,
            'tools.auth_basic.realm': realm,
            'tools.auth_basic.checkpassword': lambda r, u, p: u == username and p == password,
            }


def auth_paths():
    d = {(config.VIRTUAL_BASE + '/notify'): basic_auth('pbus-server', config.PBUS_CALLBACK_PASSWORD, 'notify'),
        }
    return d
