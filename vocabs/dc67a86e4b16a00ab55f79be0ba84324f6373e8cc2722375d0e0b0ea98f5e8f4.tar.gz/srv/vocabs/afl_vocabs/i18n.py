# -*- coding: utf-8 -*-
"""
$Id: i18n.py 7082 2014-10-10 12:59:49Z mbirin $
"""

from zope.component import queryUtility
from pyramid.i18n import INegotiator
from pyramid.i18n.message import MessageFactory
import pyramid.i18n

_ = MessageFactory('messages')
translate = lambda s: pyramid.i18n.translate(s, domain='messages')
translate2lang = lambda s, lang: pyramid.i18n.translate(s, domain='messages', target_language=lang)

__ = unicode  # __ маркирует строку для будущего перевода, в тех случаях, когда в текущей версии перевод не требуется


def format_datetime(dt, omit_seconds=False):
    # TODO: выводить часовой пояс
    if omit_seconds:
        return '%02d:%02d %s' % (dt.hour, dt.minute, format_date(dt))
    return '%02d:%02d:%02d %s' % (dt.hour, dt.minute, dt.second, format_date(dt))


def format_date(dt):
#    negotiator = queryUtility(INegotiator)
#    if negotiator and negotiator.getLanguage(['ru', 'en'], None) == 'en':
#        return '%02d/%02d/%04d' % (dt.month, dt.day, dt.year)
    return '%02d.%02d.%04d' % (dt.day, dt.month, dt.year)


def encode_multilang_value(multilang_dict):
    """ Собирает multilang-строку
    :param multilang_dict: {'ru': u'Русский текст', 'en': u'English text'}
    :return: 'ru:Русский текст|en:English text'
    """
    lines = []
    if isinstance(multilang_dict, dict):
        for key, val in multilang_dict.items():
            if val is None:
                val = ''
            lines.append(u'%s:%s' % (key, unicode(val)))
    result = u'|'.join(lines)
    return result


def choose_from_multilang(current_lang, multilang_dict):
    """ Возвращает текст на текущем активном языке, либо английский в случае отсутствия оного
    """
    result = u''
    if multilang_dict.get(current_lang):
        result = multilang_dict.get(current_lang)
    elif multilang_dict.get('en'):
        result = multilang_dict.get('en')
    else:
        # если же и английского перевода нет, последней попыткой отдаем ru-вариант
        result = multilang_dict.get('ru', '')
    return result
