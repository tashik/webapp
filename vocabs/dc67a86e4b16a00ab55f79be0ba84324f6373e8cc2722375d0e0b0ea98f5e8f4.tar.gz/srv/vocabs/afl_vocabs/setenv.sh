#!/bin/bash
# ------------------------------------------------------------------------------
# Aeroflot CAB Application Environment Variables
# ------------------------------------------------------------------------------

# Call `source setenv.sh` to set environment variables

export APPDIR=$HOME/afl_vocabs
export LIBROOTDIR=$HOME/pyramid-lib
export APPLIBDIR=$HOME/afl_cabinet-lib
export PYRAMIDDIR=$HOME/pyramid
export PYTHONPATH=$APPDIR:$APPLIBDIR:$LIBROOTDIR:$HOME/lib/python2.7/site-packages
export LD_LIBRARY_PATH=$HOME/lib
