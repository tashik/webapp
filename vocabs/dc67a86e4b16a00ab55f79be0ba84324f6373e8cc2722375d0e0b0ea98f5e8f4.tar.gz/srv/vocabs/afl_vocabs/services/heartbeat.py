# -*- coding: utf-8 -*-

import threading
import time

import cherrypy
from pyramid.app.page import Page
from pyramid.ormlite.dbop import dbquery

import models.version
import config


class HeartbeatService(Page):
    """Сервис мониторинга. Проверяем, что нет явных нарушений в работе ЛК"""

    csrf_enabled = False

    _template = '_layout_page.html'
    sectionTitle = u'Heartbeat service'
    
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('heartbeat_svc', '/services/ping', controller=self, action='ping')
        
    def ping(self):
        try:
            dbquery("select null from _schema_revisions where 1=0")
        except Exception as err:
            raise cherrypy.HTTPError(500, "{}: {}".format(err.__class__.__name__, str(err)))
        return self.render('PONG!\nAPP_VERSION=%s\n' % models.version.APP_VERSION)
