# -*- coding: utf-8 -*-

import logging
import config

# create logger with 'spam_application'
def init_logger(log_level=logging.DEBUG, logfile='update_translate.log'):
    """
    Инициализируем лог скрипта.
    :param log_level:
    :return:
    """
    logger = logging.getLogger(__name__)
    logger.setLevel(log_level)
    # create file handler which logs even debug messages
    fh = logging.FileHandler(logfile)
    fh.setLevel(log_level)
    # create console handler with a higher log level
    ch = logging.StreamHandler()
    ch.setLevel(logging.ERROR)
    # create formatter and add it to the handlers
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)
    # add the handlers to the logger
    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger

INIT_DATA_DIR = config.APPDIR + '/init_data/'


# Соответствие основного пересодимого тега и класса. Если класса нет в этом
# словаре, то используем значение по умолчанию names. Необходимо из-за
# отсутствия в PartnerAwardConditionPage names
FIELD_SEQUENCE = {
    'partner_award_conditions': 'award_condition_description'
}
