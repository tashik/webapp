# -*- coding: utf-8 -*-
import argparse
import logging
import re
import transaction
from time import sleep


from zope.component import getAdapter
from zope.interface import implementedBy
from zope.schema import getFieldsInOrder
from initializer import initialize
from models.validation import get_validation_errors

from pyramid.ormlite import dbquery, dbop
from pyramid.vocabulary import getV


import notify
from scripts.parse_xml import ParseXmlFile
from scripts.utils import init_logger, FIELD_SEQUENCE

from ui.field_adapters import ICSVValueConverter

from ui.csv_io import ImportCSVError


def _parse_skip_vocab_arg(skip_args):
    skip_vocabs = {}
    vocabs = re.findall('([^:]+):([^;]+);?', skip_args)
    for vocab, ids in vocabs:
        skip_vocabs[vocab.strip()] = ids.split(',')
    return skip_vocabs


class UpdateTranslate(object):
    """
    Обновляет данные в базе из поступивщих строк
    Класс не должен знать откуда поступили строки для обновления записей.
    При создании объекта проверяем наличие такого же в словаре.
    Если объекта нет, то в переданной строке должны присутствовать ВСЕ
    обязательные поля
    """

    def __init__(self, page_class, delay=None, repeat=None, create=False):
        self.ob_class = page_class.ob_class
        self.ob_iface = list(implementedBy(self.ob_class))[0]
        self.xml_fields = getFieldsInOrder(self.ob_iface)
        self.vocab_name = page_class.vocab_name
        self.delay = delay / 1000.0 if delay else None
        self.repeat = repeat
        self.create = create
        self.main_field = FIELD_SEQUENCE.get(self.vocab_name, 'names')

    def _check_save_object(self, row_errors, ob):
        """
        Проверяем на соответствие констрейнтам БД
        :param row_errors:
        :param ob:
        :return:
        """
        save_object_error = []
        if not row_errors:
            dbquery('savepoint try_saving')
            try:
                ob.save()
            except dbop.dbapi.DatabaseError as e:
                save_object_error.append(e)
            dbquery('rollback to savepoint try_saving')
            dbquery('release savepoint try_saving')
        return save_object_error

    def _unpack_row_to_obj(self, row, obj=None):
        """
        Распаковать row в объект словаря.
        Создаем новый элемент если obj не был передан.

        :param row: List полей
        :param obj: Объект словаря
        :return:
        """
        new = True
        old_names = None
        ob = self.ob_class()
        if obj:
            ob = obj
            old_names = obj.__getattribute__(self.main_field)
            new = False

        row_errors = []
        for xml_field, (name, field) in zip(row, self.xml_fields):
            if xml_field:
                field = field.bind(ob)
                try:
                    value_converter = getAdapter(field, ICSVValueConverter)
                    v = value_converter.from_csv(xml_field)
                except Exception as e:
                    row_errors.append(e)
                else:
                    setattr(ob, name, v)

        if not row_errors:
            row_errors = list(get_validation_errors(self.ob_iface, ob))
            row_errors += self._check_save_object(row_errors, ob)

        if not row_errors:
            if new:
                logger.info(u'Добавляем строку {0} в {1}'.format(
                    ob.names, getattr(ob, 'p_table_name', '')))
            else:
                logger.info(
                    u'Обновим строку {0},{1} в {2}. '
                    u'Прошлое значение: {3}'.format(
                        ob.id,
                        ob.__getattribute__(self.main_field),
                        ob.p_table_name,
                        old_names))

        return ob, row_errors

    def _generate_objects(self, rows, vocab):
        """
        Сгенерировать объекты из списка полей.
        :param rows: list данных о полях
        :param vocab: словарь
        :return:
        """
        change_imported_objects = []
        add_imported_object = []
        parse_errors = []

        for row_n, row in enumerate(rows):
            if row[0] in vocab:
                obj = vocab[row[0]]
                event = 'change'
            else:
                obj = None
                event = 'add'

            if obj or self.create:
                imported_object, row_errors = self._unpack_row_to_obj(row, obj)
                if row_errors:
                    for e in row_errors:
                        parse_errors.append((row_n, row, e))
                    continue
                if event == 'add':
                    change_imported_objects.append(imported_object)
                else:
                    add_imported_object.append(imported_object)
        return change_imported_objects, add_imported_object, parse_errors

    def _add_obj_to_vocabs(self, vocab, ob):
        """
        Добавить/обновить объект в словарь.
        Если количество попыток исчерпано выкидываем except
        :param vocab:
        :param ob:
        :return:
        """
        mtries = self.repeat
        while mtries > 1:
            try:
                vocab.add(ob)
                ob.save()
                if self.delay:
                    sleep(self.delay)
                return
            except Exception as e:
                logger.info(u'{0}, Повторная попытка через {1} '
                            u'секунд...'.format(str(e), self.delay))
                mtries -= 1
                if not mtries:
                    raise Exception(u'Количество попыток исчерпано')
                sleep(self.delay)

    def import_rows(self, rows):
        """
        Импортировать данные из rows в словари
        :param rows: строки с полями обновляемых объектов
        :type tows: list<String>
        :param create: флаг записи в бд новых строк
        :type create: boolean
        :return:
        """
        vocab = getV(self.vocab_name)
        vocab_values = {}
        # получим один раз словарь, превращаем в dict для удобства поиска по id
        for ob in vocab.values():
            vocab_values[ob.id] = ob

        change_imported_objects, add_imported_objects, parse_errors = self._generate_objects(
            rows, vocab_values)

        # Если у нас есть ошибки парсинга тогда выкидывает
        # raise с последними 20-тью ошибками
        if parse_errors:
            logger.error("Errors occured, showing first 20")
            logger.error(parse_errors[:20])
            raise ImportCSVError(parse_errors[:20])

        count_objs = len(change_imported_objects)+len(add_imported_objects)
        logger.debug(u'Сохраняем сгенерированные объекты. '
                     u'Количество {0}'.format(count_objs))

        for index, ob in enumerate(change_imported_objects):
            if index and not index % 50:
                logger.debug(u'Сохранено {0} обьектов'.format(index))
            self._add_obj_to_vocabs(vocab, ob)

        notify.post_events(('change', change_imported_objects))

        for index, ob in enumerate(add_imported_objects):
            if index and not index % 50:
                logger.debug(u'Добавлено {0} обьектов'.format(index))
            self._add_obj_to_vocabs(vocab, ob)

        notify.post_events(('add', add_imported_objects))

        logger.debug(u'Завершено, импортировано %s '
                     u'объектов' % count_objs)


def coords(s):
    try:
        return s.split(';')
    except:
        raise argparse.ArgumentTypeError(
            u"Coordinates must be VocabName1:id1,id2,id3;VocabName2:id1...")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("-d", "--delay", type=int, default=0,
                        help=u"Опциональный параметр задержки между каждым\n"
                        u"вызовом функции добавления информации в\n"
                        u"справочник (миллисекунды).\nDefault: 0")
    parser.add_argument("-r", "--repeat", type=int, default=5,
                        help=u"Опциональный параметр попытки повторов\n"
                             u"вызова функции добавления информации в\n"
                             u"справочник (количество).\nDefault: 5")
    parser.add_argument("-c", "--create", action='store_true', default=False,
                        help=u"опциональный флаг, при отсутствии записи в БД\n"
                             u"скрипт попытается создавать новую.\n"
                             u"Default: False")
    parser.add_argument("-s", "--skip", type=_parse_skip_vocab_arg, default='',
                        help=u"Опциональный параметр.\r\n"
                             u"Template: VocabName1:id1,id2,id3;VocabName2:id1...\r\n"
                             u"Возможные варианты словарей:\r\n"
                             u"world_region, country, city, redemption_zone,\n"
                             u"office, comments, partner_award_condition,\n"
                             u"professional_area, special_offer,\n"
                             u"office_category_fnl")
    parser.add_argument("files", nargs="+",
                        help=u"Файл [Файл2 …] - один или "
                             u"несколько файлов с переводами\nдля добавления "
                             u"в справочник. Так же поддерживается *.xml")

    args = parser.parse_args()

    initialize()
    logger = init_logger()
    transaction.begin()
    for _file in args.files:
        xml_file = ParseXmlFile(_file, args.skip, logger)
        rows = xml_file.parse_xml()
        translation = UpdateTranslate(
            xml_file.class_obj, args.delay, args.repeat, args.create)
        translation.import_rows(rows)
        transaction.commit()
