#!/usr/bin/env python

from rx.pbus.client import unsubscribe
import config

def main():
    unsubscribe(config.PBUS_TOPICS)

if __name__ == '__main__':
    main()
