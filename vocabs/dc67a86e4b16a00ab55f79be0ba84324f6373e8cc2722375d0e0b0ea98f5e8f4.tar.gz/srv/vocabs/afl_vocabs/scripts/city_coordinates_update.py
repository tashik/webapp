# -*- coding: utf-8 -*-

import csv
import logging
import optparse
import os
import sys
import transaction

from pyramid.vocabulary import getV
from initializer import initialize


class CityCoordinatesUpdater(object):
    def __init__(self, logfile, user=None):
        self.user = user

        # set logger
        self.logger = logging.getLogger('city_coordinates_updater')
        handler = logging.FileHandler(logfile)
        fmt = '[%(asctime)s] %(message)s'
        datefmt = '%d/%b/%Y:%H:%M:%S'
        formatter = logging.Formatter(fmt, datefmt=datefmt)
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)

    def read_csv(self, f_coord):
        try:
            with open(f_coord, mode='rb') as fp_coord:
                reader_coord = csv.reader(fp_coord, delimiter=',')
                # skip header
                reader_coord.next()
                coord = dict((rows[0], (rows[1], rows[2]))
                             for rows in reader_coord)
        except IOError as e:
            print "I/O error({0}): {1}".format(e.errno, e.strerror)
            sys.exit(2)
        return coord

    def update_db(self, coord):
        coord_iata = set(coord.keys())
        updated_cnt = 0

        user_log_prefix = '' if self.user is None else 'Changed by %s: ' % self.user
        for city in getV('cities'):
            if city.iata in coord_iata:
                iata, key, old_lat, old_lon = city.iata, city.city_id, city.lat, city.lon
                city.lat, city.lon = coord[city.iata]
                city.save()
                # write changes in log
                self.logger.info('%s(%s, %s, %s, %s) → (%s, %s, %s, %s)' %
                                 (user_log_prefix,
                                  key, iata, old_lat, old_lon,
                                  key, iata, city.lat, city.lon))
                updated_cnt += 1
            else:
                # write to log
                self.logger.info('City "%s" [%s] is not updated' % (iata, key))

        print "\nRecords updated: %d" % updated_cnt


def main():
    logfile_default = os.path.join("log", "cities_coord.log")

    parser = optparse.OptionParser(usage='%prog [-h | [options]] <filename>')
    parser.add_option("-u", "--user", dest="user", default=None, help="user run the script")
    parser.add_option("-l", "--logfile", dest="logfile", default=logfile_default, help="path to the log file")
    (options, args) = parser.parse_args()

    if not args:
        parser.print_usage()
        sys.exit(1)

    updater = CityCoordinatesUpdater(logfile=options.logfile, user=options.user)
    coord = updater.read_csv(f_coord=args[0])
    initialize()
    transaction.begin()
    try:
        updater.update_db(coord)
    except Exception:
        transaction.abort()
        raise
    else:
        transaction.commit()


if __name__ == '__main__':
    main()
