# -*- coding: utf-8 -*-
from __future__ import absolute_import
from collections import defaultdict
import csv
import optparse
import os
import sys
from pyramid.vocabulary import getV
import transaction
from initializer import initialize
from models.meal import MealRule
import notify

from scripts.utils import init_logger


class MealRulesUpdate(object):

    def __init__(self, logfile='update_meal_rules'):
        # set logger
        self.logger = init_logger(logfile=logfile)
        self.updated_count = 0
        self.error_count = 0

    @staticmethod
    def read_csv(f):
        with open(f, mode='rb') as fp:
            meal_rules = csv.reader(fp, delimiter=';')
            meal_rules.next()
            return [{'number': ','.join(meal_rule[2].split()),
                     'origin': meal_rule[3].strip(),
                     'destination': meal_rule[4].strip(),
                     'booking_classes': meal_rule[5],
                     'special_meal': meal_rule[6]}
                    for meal_rule in meal_rules]

    @staticmethod
    def clean():
        remove_meal_rules = []
        for meal_rule in getV('meal_rules'):
            meal_rule.delete()
            remove_meal_rules.append(meal_rule)
        return remove_meal_rules

    @staticmethod
    def _find_airport(iata, airports):
        return [airport for airport in airports if iata == airport.iata]

    @staticmethod
    def _generate_su_booking_classes():
        su_booking_classes = defaultdict(list)
        for booking_class in getV('booking_classes'):
            if booking_class.alTariffGroup.serviceClass.airline.iata == 'SU':
                su_booking_classes[booking_class.bcCode].append(booking_class)
        return su_booking_classes

    @staticmethod
    def _find_special_meal(special_meals, sp_code):
        for special_meal in special_meals:
            if special_meal.code == sp_code:
                return special_meal

    @staticmethod
    def _generate_booking_classes(meal_rule_bc, booking_classes_su):
        booking_classes = []
        for bcCode in meal_rule_bc.split():
            booking_classes.extend(booking_classes_su.get(bcCode, []))
        return booking_classes

    def _generate_special_meals(self, meal_rule_sm, special_meals):
        special_meals_for_rule = []
        for sp_code in meal_rule_sm.split():
            sp = self._find_special_meal(special_meals, sp_code)
            if sp:
                special_meals_for_rule.append(sp)
        return special_meals_for_rule

    def _get_airlines(self, airline_iatas):
        airlines = getV('airlines')
        meal_airlines = []
        for airline in airlines:
            if airline.iata in airline_iatas:
                meal_airlines.append(airline)
        return meal_airlines

    def update_db(self, meal_rules_list):
        airline_iata = ['FV', 'HZ', 'SU']
        meal_airlines = self._get_airlines(airline_iata)
        meal_airlines_log = ','.join([m.iata for m in meal_airlines])
        airports = getV('airports')
        special_meals = getV('special_meal')
        meal_rules = getV('meal_rules')

        added_meal_rules = []
        booking_classes_su = self._generate_su_booking_classes()

        for meal_rule_row in meal_rules_list:
            origin = self._find_airport(meal_rule_row['origin'], airports)
            destination = self._find_airport(meal_rule_row['destination'], airports)
            booking_classes = self._generate_booking_classes(meal_rule_row['booking_classes'], booking_classes_su)
            special_meal = self._generate_special_meals(meal_rule_row['special_meal'], special_meals)

            if origin and destination and (booking_classes or special_meal):
                meal_rule_obj = MealRule(meal_rule_id=MealRule.getNewId(),
                                         number=meal_rule_row['number'], origin=origin,
                                         destination=destination,
                                         booking_class=booking_classes,
                                         special_meal=special_meal,
                                         airline=meal_airlines)
                meal_rules.add(meal_rule_obj)
                meal_rule_obj.save()
                added_meal_rules.append(meal_rule_obj)
                self.logger.info(
                    u'Create MealRules[id={4}]: origin={0}, destination={1}, booking_classes={2}, special_meal={3}, airline={5}'.format(
                        origin[0].iata,
                        destination[0].iata,
                        ','.join([bc.bcCode for bc in booking_classes]),
                        ','.join([sm.code for sm in special_meal]),
                        meal_rule_obj.meal_rule_id,
                        meal_airlines_log
                    )
                )
            else:
                self.error_count += 1
                self.logger.info(
                    u'Error added MealRules: origin={0}, destination={1}, booking_classes={2}, special_meal={3}'.format(
                        origin[0].iata if origin else u'Not found[{0}]'.format(meal_rule_row['origin']),
                        destination[0].iata if destination else u'Not found[{0}]'.format(meal_rule_row['destination']),
                        ','.join([bc.bcCode for bc in booking_classes]),
                        ','.join([sm.code for sm in special_meal]),
                        meal_airlines_log
                    ))
        return added_meal_rules


def main():
    logfile_default = os.path.join('log', 'update_meal_rules.log')

    parser = optparse.OptionParser(usage='%prog [-h | [options]] <filename>')
    parser.add_option('-l', '--logfile', dest='logfile', default=logfile_default, help='path to the log file')
    (options, args) = parser.parse_args()

    if not args:
        parser.print_usage()
        sys.exit(1)

    updater = MealRulesUpdate(logfile=options.logfile)

    meal_rules = updater.read_csv(f=args[0])
    initialize()
    transaction.begin()
    updater.logger.info(u'Transaction begin')
    try:
        remove_meal_rules = updater.clean()
        add_meal_rules = updater.update_db(meal_rules)
    except Exception:
        transaction.abort()
        updater.logger.info(u'Transaction abort')
        raise
    else:
        transaction.commit()
        updater.logger.info(u'Removed rules: {0}'.format(len(remove_meal_rules)))
        updater.logger.info(u'Added rules: {0}'.format(len(add_meal_rules)))
        updater.logger.info(u'Error rules: {0}'.format(updater.error_count))
    notify.post_events(
        ('delete', remove_meal_rules),
        ('add', add_meal_rules)
    )


if __name__ == '__main__':
    main()
