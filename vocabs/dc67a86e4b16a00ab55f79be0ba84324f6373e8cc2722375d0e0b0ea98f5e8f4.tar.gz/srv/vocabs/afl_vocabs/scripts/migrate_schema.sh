#!/bin/bash -eu

# Обновляет схему БД с помощью скриптов update_to_XXXX.sql. Опционально делает бекап БД.

# Usage: migrate_schema.sh -s migration-script-dir [-b backup-dir] 
# E.g.: migrate_schema.sh -s $HOME/afl_cabinet/sql -b /srv/backups

function usage {
    echo "Usage: migrate_schema.sh [-b backup-dir] -s migration-script-dir"
    exit 2
}


function create_db_backup {
    local db_revision=$1

    backup_name=dump-$db_revision-$(date +"%Y%m%d%H%M%S").sql.gz

    echo "Saving database dump to $backup_name" >&2
    mkdir -p $BACKUP_DIR
    $PG_DUMP -c | gzip -cf > $BACKUP_DIR/$backup_name | cat >&2
    echo $backup_name
}

function restore_db_backup {
    local backup_name=$1
    echo "Reverting database to $backup_name" >&2
    zcat $BACKUP_DIR/$backup_name | $PSQL
}

function migrate_db {
    local script_dir=$1
    shift

    for rev in $@
    do
        echo "### Applying revision $rev" >&2
        (cat $script_dir/update_to_$rev.sql | $PSQL -ev ON_ERROR_STOP=1) || return
	echo >&2
    done
}


function get_db_revision {
    echo $($PSQL -qtc "select max(revision) from _schema_revisions;")
}


function get_new_revisions {
    local db_revision=$1
    local script_dir=$2
    local sql_files=$(ls $script_dir)

    python <<EOF

import re
import sys

sql_files = """
$sql_files
"""

db_version = int('$db_revision')
versions = []

for line in sql_files.split():
    m = re.search(r'update_to_(\d+)\.sql', line)
    if m:
        version = int(m.group(1))
        if version > db_version:
            versions.append(version)

for v in sorted(versions):
    print v

EOF
}



function main {
    local ENABLE_BACKUP=""
    
    while getopts "bs:h" opt
    do
	case $opt in
	    b) ENABLE_BACKUPS=true; BACKUP_DIR=$OPTARG;;
	    s) MIGRATE_SCRIPT_DIR=$OPTARG;;
	    h) usage;;
	    *) usage;;
	esac
    done

    PSQL="psql"
    PG_DUMP="pg_dump"
    
    local DB_REVISION=$(get_db_revision)
    if [[ $DB_REVISION == "" ]]; then
	echo "Missing current schema revision" >&2
	exit 1
    fi
    local NEW_REVISIONS=$(get_new_revisions $DB_REVISION $MIGRATE_SCRIPT_DIR)

    echo "Current schema revision: $DB_REVISION" >&2

    if [[ $NEW_REVISIONS == "" ]]; then
	echo "Nothing to update" >&2
	exit
    fi

    #echo "Applying revisions $NEW_REVISIONS" >&2

    if [[ $ENABLE_BACKUP == "t" ]]; then
	local backup_name=$(create_db_backup $DB_REVISION)
    fi

    migrate_db $MIGRATE_SCRIPT_DIR $NEW_REVISIONS || (
	# ошибка миграции, откатываем БД и образ
        echo "Error during schema migration" >&2
	set -e
	
	if [[ $ENABLE_BACKUP == "t" ]]; then
	    restore_db_backup $backup_name
	    rm -f $backup_name
	fi

	exit 1
    ) || exit 1

    if [[ $ENABLE_BACKUP == "t" ]]; then
	rm -f $backup_name
    fi
}


main $@


