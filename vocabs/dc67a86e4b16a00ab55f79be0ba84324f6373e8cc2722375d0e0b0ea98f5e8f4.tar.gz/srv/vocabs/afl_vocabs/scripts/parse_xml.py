# -*- coding: utf-8 -*-
from lxml.etree import ElementTree

from ui.bonus import RedemptionZonePage
from ui.geo import WorldRegionPage, CountryPage, CityPage
from ui.member import ProfessionalAreaPage
from ui.office import OfficePage, OfficeCategoryPage
from ui.partner import PartnerAwardConditionPage
from ui.service_classes import CommentClassPage
from ui.special_offer import SpecialOfferPage

# Соответствие корневого тега xml файла и класса
IMPORT_SEQUENCE = {
    'world_region': WorldRegionPage,
    'country': CountryPage,
    'city': CityPage,
    'redemption_zone': RedemptionZonePage,
    'office': OfficePage,
    'comments': CommentClassPage,
    'partner_award_condition': PartnerAwardConditionPage,
    'professional_area': ProfessionalAreaPage,
    'special_offer': SpecialOfferPage,
    'office_category_fnl': OfficeCategoryPage
}


class ParseXmlFile(object):
    """
    Парсит входящий xml файл
    Структура xml файла:
    <class_tag>
        <item name="ID">
            <field-# name="Название столбца в Csv(не обязательно)">
                <en>Перевод</en>
                <ru>Перевод</ru>
                <de>Перевод</de>
                <es>Перевод</es>
                <fr>Перевод</fr>
                <it>Перевод</it>
                <ja>Перевод</ja>
                <ko>Перевод</ko>
                <zh>Перевод</zh>
            </field-#>
        </item>
    </class_tag>
    где:
        class_tag - один из ключей  IMPORT_SEQUENCE
        item@name - id обновляемого объекта
        field-# - # номер поля в csv и в классе обновляемого объекта
        field-#@name - Название столбца в Csv(не обязательно)
    """

    def __init__(self, _file, skip_vocabs, logger):
        """
        Сразу получим root тег файла, если файл не корректны или
        указанного файла не существует выкидываем ошибку
        :param _file: файл в формате xml
        :param skip_vocabs: структура содержащая id строк который будут
        пропущены
        """
        self.logger = logger
        tree = ElementTree(file=_file)
        self.root = tree.getroot()
        try:
            self.class_obj = IMPORT_SEQUENCE[self.root.tag]
        except KeyError:
            self.logger.error(u'Нет модели для корневого тега {0}'.format(
                self.root.tag))
            raise KeyError(
                u'Нет модели для корневого тега {0}'.format(self.root.tag))
        self.skip_vocabs_ids = skip_vocabs.get(self.root.tag, [])

    def parse_xml(self):
        """
        Вернуть лист с переводами сгенерированный из xml файла
        :return:
        """
        rows = []
        for item in self.root:
            row = self._parse_item_tag(item)
            if row:
                rows.append(row)
        return rows

    def _parse_item_tag(self, item):
        """
        Распарсим тег одной сущности
        :param item: тег xml дерева
        :return:
        """
        id_item = item.attrib['name']
        if id_item in self.skip_vocabs_ids:
            self.logger.info(
                u'Пропускаем обновление строки с id: {0} в словаре {1}'.format(
                    id_item, self.root.tag
                )
            )
            return None
        fields = [id_item]  # Поля сущности, порядок важен

        for field in item:
            _, number_tag = field.tag.split('-')
            number_tag = int(number_tag)
            text_field = self._parse_field_tag(field)
            if len(fields) < number_tag + 1:
                fields[len(fields):] = [''] * (number_tag - (len(fields) - 1))
            fields[number_tag] = text_field
        return fields

    @staticmethod
    def _parse_field_tag(field):
        """
        Распарсить тег одного поля сущности. Если тег содаржит в себе подтеги
        тогда парсим их, если содержит только текст парсим текст.
        Возвращается строка вида:
        1. ru:Текст|en:Text
        2. Прострая строка
        :param field: поле сущности
        :return:
        """
        locales_text = []
        for locale in field:
            if locale.text:
                locale_text = u'{0}:{1}'.format(locale.tag, locale.text)
                locales_text.append(locale_text)

        if locales_text:
            text = '|'.join(locales_text)
        else:
            text = field.text.strip() if field.text else ''

        return text
