# -*- coding: utf-8 -*-
from __future__ import absolute_import

import csv
import optparse
import os
import sys
import transaction

from pyramid.vocabulary import getV
from initializer import initialize
import notify
from scripts.utils import init_logger


class CitiesUpdater(object):
    def __init__(self, logfile='cities_update'):
        # set logger
        self.logger = init_logger(logfile=logfile)
        self.updated_count = 0
        self.error_count = 0

    def read_csv(self, f):
        with open(f, mode='rb') as fp:
            cities = csv.reader(fp, delimiter=',')
            cities_alt = {rows[0]: rows[1].split(';') for rows in cities}
        return cities_alt

    def _update_city(self, city, alt_cities):
        if alt_cities:
            old_alt_cities = city.alternative_cities
            city.alternative_cities = alt_cities
            city.save()
            self.logger.info(u'City "{1}"[id={0}] updated alternative_cities from {2} to {3}.'.format(
                    city.id, city.iata, old_alt_cities, alt_cities
            ))
            self.updated_count += 1
        else:
            self.logger.info(u'Error update city "{1}[id={0}]. Alternative_cities = {2}'.format(
                    city.id, city.iata, alt_cities
            ))
            self.error_count += 1
        return True

    def update_db(self, cities_atl_cities):
        cities = []
        vocabs_cities = {city.iata: city for city in getV('cities')}
        for city_iata, alt_cities in cities_atl_cities.iteritems():
            if city_iata in vocabs_cities:
                city = vocabs_cities[city_iata]
                city_updated = self._update_city(city, cities_atl_cities[city_iata])
                if city_updated:
                    cities.append(city)
            else:
                self.logger.info(u'City "{0}" is not found'.format(city_iata))
                self.error_count += 1
        self.logger.info(u'Records updated: {0}'.format(self.updated_count))
        self.logger.info(u'Records error: {0}'.format(self.error_count))
        return cities


def main():
    logfile_default = os.path.join('log', 'cities_alternative_cities.log')

    parser = optparse.OptionParser(usage='%prog [-h | [options]] <filename>')
    parser.add_option('-l', '--logfile', dest='logfile', default=logfile_default, help='path to the log file')
    (options, args) = parser.parse_args()

    if not args:
        parser.print_usage()
        sys.exit(1)

    updater = CitiesUpdater(logfile=options.logfile)

    cities_alt = updater.read_csv(f=args[0])
    initialize()
    transaction.begin()
    updater.logger.info(u'Transaction begin')
    try:
        cities = updater.update_db(cities_alt)
    except Exception:
        transaction.abort()
        updater.logger.info(u'Transaction abort')
        raise
    else:
        transaction.commit()
        updater.logger.info(u'Transaction commit')
    notify.post_events(('change', cities))

if __name__ == '__main__':
    main()
