# -*- coding: utf-8 -*-

import os

from pyramid.ormlite import dbquery, dbop
from pyramid.vocabulary import getV
import transaction
from zope.component import getAdapter
from zope.interface import implementedBy
from zope.schema.interfaces import ITokenizedTerm
from zope.schema import getFieldsInOrder

import config
from initializer import initialize
from models.validation import get_validation_errors
import ui.csv_io
from ui.field_adapters import ICSVValueConverter


INIT_DATA_DIR = config.APPDIR + '/init_data/'

import ui.geo
import ui.airport
import ui.bonus
import ui.air
import ui.currency

IMPORT_SEQUENCE = [
    [ui.geo.WorldRegionPage, 'world_region.csv'],
    [ui.currency.CurrencyPage, 'currency.csv'],
    [ui.geo.CountryPage, 'country.csv'],
    [ui.geo.CityPage, 'city.csv'],
    [ui.bonus.RedemptionZonePage, 'redemption_zone.csv'],
    [ui.airport.AirportPage, 'airport.csv'],
    [ui.air.AircraftTypePage, 'aircraft_type.csv'],
]


class Parser(object):
    def __init__(self, page_class):
        self.ob_class = page_class.ob_class
        self.ob_iface = list(implementedBy(self.ob_class))[0]
        self.csv_fields = getFieldsInOrder(self.ob_iface)
        self.vocab_name = page_class.vocab_name

    def _parse_csv_row(self, row):
        ob = self.ob_class()
        row_errors = []
        col_n = 0
        for csv_value, (name, field) in zip(row, self.csv_fields):
            field = field.bind(ob)
            col_n += 1
            try:
                value_converter = getAdapter(field, ICSVValueConverter)
                v = value_converter.from_csv(csv_value)
            except Exception, e:
                row_errors.append(e)
            else:
                setattr(ob, name, v)

        if not row_errors:
            for e in get_validation_errors(self.ob_iface, ob):
                row_errors.append(e)

        if not row_errors:
            dbquery('savepoint try_saving')
            try:
                ob.save()  # проверяем на соответствие констрейнтам БД
            except dbop.dbapi.DatabaseError, e:
                row_errors.append(e)
            dbquery('rollback to savepoint try_saving')
            dbquery('release savepoint try_saving')

        return ob, row_errors

    def import_csv(self, file):
        print 'Import to "%s" started' % self.vocab_name
        imported_objects, parse_errors = ui.csv_io.import_csv(file, 'utf-8', self._parse_csv_row)

        if parse_errors:
            print "Errors occured, showing first 20"
            print parse_errors[:20]
            raise ui.csv_io.ImportCSVError(parse_errors[:20])

        vocab = getV(self.vocab_name)
        added, changed, deleted, merge_errors = ui.csv_io.merge(vocab, imported_objects)

        if merge_errors:
            print "Errors occured, showing first 20"
            raise ui.csv_io.ImportCSVError(merge_errors[:20])

        for ob in added + changed:
            vocab.add(ob)
            ob.save()

        for ob in deleted:
            del vocab[ITokenizedTerm(ob).token]
            ob.delete()

        print ('   Finished, imported %s objects' % len(imported_objects))


if __name__ == '__main__':
    initialize()

    for page_class, filename in IMPORT_SEQUENCE:
        with open(os.path.join(INIT_DATA_DIR, filename)) as f:
            p = Parser(page_class)
            p.import_csv(f)
            transaction.commit()

