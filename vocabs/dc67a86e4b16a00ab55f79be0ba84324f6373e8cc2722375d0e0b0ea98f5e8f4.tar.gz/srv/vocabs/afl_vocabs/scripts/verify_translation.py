# -*- coding: utf-8 -*-
import argparse

from zope.interface import implementedBy
from zope.schema import getFieldsInOrder

from initializer import initialize
from pyramid.vocabulary import getV

from scripts.parse_xml import ParseXmlFile
from scripts.utils import init_logger, FIELD_SEQUENCE


class CheckObjects(object):
    """
    Сверяем данные в базе из поступивщих строк
    Класс не должен знать откуда поступили строки для обновления записей.
    """

    def __init__(self, page_class, languages, field):
        """

        :param page_class: Класс для обновления
        :param language: язык значения которого будут сравниваться.
        :param field: название поля для сверки.
        """
        self.languages = languages
        self.field = field
        self.ob_class = page_class.ob_class
        self.ob_iface = list(implementedBy(self.ob_class))[0]
        self.xml_fields = getFieldsInOrder(self.ob_iface)
        self.vocab_name = page_class.vocab_name
        self.main_field = FIELD_SEQUENCE.get(self.vocab_name, 'names')
        self._check_field_in_model()
        self.count_error_obj = 0

    def _check_field_in_model(self):
        """
        Проверка на существование поля в модели
        :return:
        """
        if not any(self.field in field for field in self.xml_fields):
            raise KeyError(
                u'Поля {0} в модели {1} не существует. Модель имеет '
                u'следующие поля: {2}'.format(
                    self.field,
                    self.vocab_name,
                    ', '.join([field[0] for field in self.xml_fields])
                ))

    def _check_cell(self, id_obj, xml_field_value, obj_value):
        if xml_field_value != obj_value:
            logger.info(
                u'Объект({0}): Файл({1}), БД({2})"'.format(
                    id_obj, xml_field_value, obj_value
                ))
            self.count_error_obj += 1

    def _check_row(self, row, obj):
        """
        Сверяет заданное поле на заданном языке объекта с переданной строкой
        :param row:
        :param obj:
        :return:
        """
        for xml_field, (name, field) in zip(row, self.xml_fields):
            if name == self.field:
                if field._type in (int, float):
                    xml_field_value = field._type(xml_field)
                    obj_value = obj.__getattribute__(self.field)
                    self._check_cell(row[0], xml_field_value, obj_value)
                else:
                    for language in self.languages:
                        obj_value = None
                        xml_field_value = None

                        for lang in xml_field.split('|'):
                            if lang.startswith(language):
                                xml_field_value = lang
                                break

                        for lang in obj.__getattribute__(self.field):
                            if lang.startswith(language):
                                parts_lang = lang.split(':')
                                if len(parts_lang) > 1 and parts_lang[1]:
                                    # Нужно из-за значений в базе вида: 'ru:',
                                    # избавляемся от мусора в логе
                                    obj_value = lang
                                break

                        self._check_cell(row[0], xml_field_value, obj_value)

    def checked_rows(self, rows):
        """
        Сравнивает строки и объекты в базе
        :param rows:
        :return:
        """
        vocab = getV(self.vocab_name)
        vocab_values = {}
        # получим один раз словарь, превращаем в dict для удобства поиска по id
        for ob in vocab.values():
            vocab_values[ob.id] = ob

        for row in rows:
            if row[0] in vocab:
                obj = vocab[row[0]]
                self._check_row(row, obj)

        logger.info(u'{0} объекта имеют расхождения.'.format(
            self.count_error_obj
        ))


def _parse_languages_arg(languages_arg):
    return [language.strip() for language in languages_arg.split(',')]


if __name__ == '__main__':
    parser = argparse.ArgumentParser(
        formatter_class=argparse.RawTextHelpFormatter)
    parser.add_argument("-l", "--languages", type=_parse_languages_arg,
                        default='ru',
                        help=u"Опциональный параметр языков сначения которых\n"
                             u"будут сравниваться. Пример: ru,de,en. \n"
                             u"Default: ru")
    parser.add_argument("-f", "--field", type=str, default='names',
                        help=u"Опциональный параметр название поля значения\n"
                             u"которого будет сравниватья. \nDefault: names")
    parser.add_argument("files", nargs="+",
                        help=u"Файл [Файл2 …] - один или "
                             u"несколько файлов с переводами\nдля добавления "
                             u"в справочник. Так же поддерживается *.xml")

    args = parser.parse_args()
    initialize()
    logger = init_logger()
    logger.info(u'Cкрипт запущен')
    logger.info(u'Инициализация pbus завершена')
    count_error_obj = 0
    for _file in args.files:
        xml_file = ParseXmlFile(_file, {}, logger)
        rows = xml_file.parse_xml()
        check_objects = CheckObjects(
            xml_file.class_obj, args.languages, args.field
        )
        check_objects.checked_rows(rows)
        count_error_obj += check_objects.count_error_obj
    logger.info(u'Всего {0} объекта имеют расхождения в {1} файлах'.format(
        count_error_obj, len(args.files)
    ))
    logger.info(u'Завершение работы скрипта')
