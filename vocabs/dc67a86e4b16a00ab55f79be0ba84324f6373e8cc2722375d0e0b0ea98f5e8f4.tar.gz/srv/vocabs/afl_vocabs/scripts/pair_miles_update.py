# -*- coding: utf-8 -*-

import csv
import logging
import optparse
import os
import re
import sys
import transaction

from pyramid.vocabulary import getV
from initializer import initialize
import notify


class PairMilesUpdater(object):
    def __init__(self, logfile):
        # set logger
        self.logger = logging.getLogger('pair_miles_update')
        handler = logging.FileHandler(logfile)
        fmt = '[%(asctime)s] %(message)s'
        datefmt = '%d/%b/%Y:%H:%M:%S'
        formatter = logging.Formatter(fmt, datefmt=datefmt)
        handler.setFormatter(formatter)
        self.logger.addHandler(handler)
        self.logger.setLevel(logging.INFO)
        self.updated_count = 0
        self.error_count = 0
        self.good_count = 0

    def read_csv(self, f):
        with open(f, mode='rb') as fp:
            reader_coord = csv.reader(fp, delimiter=',')
            # skip header
            reader_coord.next()
            distance = {(rows[0], rows[1]): rows[2] for rows in reader_coord}
        return distance

    def _update_pair(self, pair, pair_iata, distances):
        if type(distances[pair_iata]) != int:
            try:
                distances[pair_iata] = int(re.sub('\s+|\\xa0', '', unicode(distances[pair_iata])))
            except ValueError:
                self.logger.info(u'Wrong value[{1}] of miles to pair "{2}"-"{3}"[id={0}]'.format(
                    pair.id, distances[pair_iata], *pair_iata))
                self.error_count += 1
        miles = distances[pair_iata]
        if pair.miles != miles:
            old_miles = pair.miles
            pair.miles = miles
            self.logger.info(u'{3}. Pair "{4}"-"{5}"[id={0}] updated distance from {1} to {2}.'.format(
                pair.id, old_miles, miles, pair.airline.fullTitle, *pair_iata
            ))
            pair.save()
            self.updated_count += 1
            return True
        else:
            self.logger.info(u'{2}. Pair "{3}"-"{4}"[id={0}] equal miles: {1}'.format(
                pair.id, miles, pair.airline.fullTitle, *pair_iata))
            self.good_count += 1
        return False

    def update_db(self, distances):
        airs_pair = distances.keys()
        pairs = []
        for pair in getV('pairs'):
            pair_iata = (pair.airport_from.iata, pair.airport_to.iata)
            if pair_iata in airs_pair:
                pair_updated = self._update_pair(pair, pair_iata, distances)
                if pair_updated:
                    pairs.append(pair)
            else:
                self.logger.info(u'{1}. Pair "{2}"-"{3}"[id={0}] is not updated'.format(pair.id, pair.airline.fullTitle, *pair_iata))
        self.logger.info(u'Records updated: {0}'.format(self.updated_count))
        self.logger.info(u'Records with equal miles: {0}'.format(self.good_count))
        self.logger.info(u'Records error: {0}'.format(self.error_count))
        return pairs

def main():
    logfile_default = os.path.join('log', 'pair_miles_update.log')

    parser = optparse.OptionParser(usage='%prog [-h | [options]] <filename>')
    parser.add_option('-l', '--logfile', dest='logfile', default=logfile_default, help='path to the log file')
    (options, args) = parser.parse_args()

    if not args:
        parser.print_usage()
        sys.exit(1)

    updater = PairMilesUpdater(logfile=options.logfile)

    coord = updater.read_csv(f=args[0])
    initialize()
    transaction.begin()
    try:
        pairs = updater.update_db(coord)
    except Exception:
        transaction.abort()
        raise
    else:
        transaction.commit()
    notify.post_events(('change', pairs))

if __name__ == '__main__':
    main()
