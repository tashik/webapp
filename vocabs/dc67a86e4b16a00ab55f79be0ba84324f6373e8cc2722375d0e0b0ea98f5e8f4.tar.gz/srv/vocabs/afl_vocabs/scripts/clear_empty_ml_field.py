# -*- coding: utf-8 -*-

import logging
import os
import re
import transaction
import notify

from pyramid.vocabulary import getV
from zope.interface.interfaces import ComponentLookupError

from initializer import initialize
from models.ml import MLNames, MLText, MLTitleCapable
from scripts.utils import init_logger


re_wrong_line_value = re.compile('^\S{2}:$')

vocabs = ['additional_info', 'airlines', 'aircraft_types', 'airports', 'airport_terminals', 'ancillary_services_groups',
          'ancillary_services', 'ancillary_service_statuses', 'vat_rates', 'redemption_zones', 'tier_levels', 'tier_level_factors',
          'tariff_groups', 'airline_tariff_groups', 'booking_classes', 'bonus_routes', 'awards',
          'charity_funds', 'currencies', 'world_regions', 'countries', 'cities', 'languages', 'localizations',
          'meal_types', 'special_meal', 'meal_rules', 'loyalty_programs', 'professional_areas', 'office_categories',
          'offices', 'office_travel_options', 'partner_categories', 'partners', 'partner_offices', 'partner_office_contacts',
          'partner_award_conditions', 'pairs', 'wrong_routes', 'skyteam_service_classes', 'airline_service_classes',
          'comments', 'service_classes_limits', 'special_offers']


class ClearMLFieldUpdater(object):

    def __init__(self, logfile):
        self.logger = init_logger(logfile=logfile)

    def update_db(self, vocabs_name):
        update_items = []
        for item in getV(vocabs_name):
            for p_field_name, p_field in item.p_fields.iteritems():
                if isinstance(p_field, (MLNames, MLText, MLTitleCapable)):
                    lines = getattr(item, p_field_name)
                    result_line = [line for line in lines if not re_wrong_line_value.match(line)]
                    if result_line != lines:
                        p_key = getattr(item, item.p_keys[0]) if len(item.p_keys) else None
                        if p_field.required and not result_line:
                            self.logger.info(
                                u'Обязательное поле {1} для модели {0}({3}) со значением {2} не может быть обновлено'.format(
                                    vocabs_name, p_field_name, lines, p_key
                                )
                            )
                        else:
                            setattr(item, p_field_name, result_line)
                            item.save()
                            update_items.append(item)
                            self.logger.info(
                                u'Установлено новое значение в поле {1}  для модели {0}({3}): {2} -> {3}'.format(
                                    vocabs_name, p_field_name, lines, result_line, p_key
                                )
                            )
        return update_items

def main():
    logfile_default = os.path.join('log', 'clear_empty_ml_field.log')

    initialize()
    updater = ClearMLFieldUpdater(logfile_default)
    transaction.begin()
    for vocab_name in vocabs:
        updater.logger.info(u'Проверяем словарь {0}'.format(vocab_name))
        change_objects = []
        try:
            change_objects = updater.update_db(vocab_name)
        except ComponentLookupError as e:
            logging.debug(u'Vocab "%s" not exist' % vocab_name)
        except Exception:
            transaction.abort()
            raise
        else:
            transaction.commit()
        if change_objects:
            notify.post_events(('change', change_objects))

if __name__ == '__main__':
    main()