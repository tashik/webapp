# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements
from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable
from models.interfaces import IOffice, IOfficeCategory, IOfficeTravelOption
from models.ml import MLTitleCapable
from models.indexer import Indexer, getI
from pyramid.vocabulary import getV
from zope.schema.interfaces import ITokenizedTerm
from i18n import _
from rx.utils.json import IPrimitive
from zope.component import provideAdapter
from pyramid.vocabulary.simple import SimpleVocabulary
from zope.schema.vocabulary import SimpleTerm


class OfficeCategory(MutableElement, MLTitleCapable):
    u"""Категория офисов продаж"""

    implements(IOfficeCategory)
    p_table_name = 'office_categories'


class OfficeCategoryVocabulary(PersistentVocabulary):
    objectC = OfficeCategory
    makeVocabularyRegisterable('office_categories')


class Office(MutableElement, MLTitleCapable):
    u"""Офис"""

    implements(IOffice)
    p_table_name = 'offices'

    def get_travel_options(self):
        vocab = getV('office_travel_options')
        return [vocab[office_travel_option_id]
                for office_travel_option_id in getI('travel_option_by_office_idx')(self.office_id)]

    def set_travel_options(self, travel_options):
        if travel_options is None:
            travel_options = []
        input_ids = set([ITokenizedTerm(t).token for t in travel_options])
        idx = getI('travel_option_by_office_idx')
        removed_ids = set([office_travel_option_id
                           for office_travel_option_id in idx(self.office_id) if office_travel_option_id not in input_ids])
        vocab = getV('office_travel_options')
        for t_id in removed_ids:
            del vocab[t_id]
        for t in travel_options:
            t.office_id = self.office_id
            vocab.add(t)

    travel_options = property(get_travel_options, set_travel_options)

    def as_primitive(self):
        d = {'class': self.__class__.__name__}

        for name in IOffice:
            if name not in ('airport', 'office_category'):
                d[name] = getattr(self, name)
        if self.airport is None:
            d['airport'] = None
        else:
            d['airport'] = self.airport.iata
        d['office_category'] = int(self.p_choice_tokens['office_category'])
        d['travel_options'] = [dict(office_travel_option_id=c.office_travel_option_id,
                                    travel_type=c.p_choice_tokens['travel_type'],
                                    office_travel_option_description=c.office_travel_option_description,
                                    travel_time=c.travel_time) for c in self.travel_options]
        return d

provideAdapter(lambda ob: ob.as_primitive(),
               [IOffice], IPrimitive)

class OfficesVocabulary(PersistentVocabulary):
    objectC = Office
    makeVocabularyRegisterable('offices')


class OfficeTravelOption(MutableElement, TitleCapable):
    u"""Дорога до офиса"""

    implements(IOfficeTravelOption)
    p_table_name = 'office_travel_options'

    @property
    def title(self):
        return self.travel_type


class OfficeTravelOptionVocabulary(PersistentVocabulary):
    u"""Vocab "Дорога до офиса" """

    objectC = OfficeTravelOption
    makeVocabularyRegisterable('office_travel_options')


class TravelOptionByOffice(Indexer):
    u"""Index перемещений до офиса по офисам"""

    name = 'travel_option_by_office_idx'
    parent_vocab = 'office_travel_options'

    def key(self, ob):
        return str(ob.office_id)


class OfficeTravelOptionType(SimpleVocabulary):
    u"""Список способов перемещеня до офиса "Дорога до офиса" """

    items = (
        ('P',   _(u'Общественный транспорт')),
        ('A',   _(u'Автомобиль')),
        ('F',   _(u'Пешком'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('office_travel_option_types')
