# -*- coding: utf-8 -*-

"""
$Id: $
"""
from datetime import date

from zope.component import provideAdapter
from zope.interface import implements
from zope.schema.interfaces import ITokenizedTerm
from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from models.interfaces import IPartnerCategory, IPartner, IPartnerOfficeContact, IPartnerOffice, IPartnerAwardCondition
from pyramid.registry import makeVocabularyRegisterable
from pyramid.ormlite.models import TitleCapable
from models.indexer import Indexer, getI
from pyramid.vocabulary import getV
from models.ml import MLTitleCapable
from pyramid.vocabulary.simple import SimpleVocabulary
from zope.schema.vocabulary import SimpleTerm

from i18n import _
from rx.utils.json import IPrimitive, as_primitive
import notify


class PartnerCategory(MutableElement, MLTitleCapable):
    u"""Категория партнёров-неавиакомпаний"""

    implements(IPartnerCategory)
    p_table_name = 'partner_categories'


class PartnerCategoryVocabulary(PersistentVocabulary):
    u"""Vocabs категории партнёров-неавиакомпаний"""

    objectC = PartnerCategory
    makeVocabularyRegisterable('partner_categories')

    def __delitem__(self, token):
        category = self[token]
        token = ITokenizedTerm(category).token
        partners = getV('partners')
        for partner in partners:
            for category in partner.partner_categories:
                if token == ITokenizedTerm(category).token:
                    partner.partner_categories.remove(category)
                    partner.save()
                    partner.reload()
                    notify.on_object_changed(partner)
        super(PartnerCategoryVocabulary, self).__delitem__(token)


class Partner(MutableElement, MLTitleCapable):
    u"""Партнёр-неавиакомпания"""

    implements(IPartner)
    p_table_name = 'partners'

    def as_primitive(self):
        d = {'class': self.__class__.__name__}

        for name in IPartner:
            if name in ('new_until',):
                val = getattr(self, name)
                if isinstance(val, date):
                    val = val.strftime('%Y-%m-%d')
                d[name] = val
            elif name in ('status', 'mile_action',):
                d[name] = self.p_choice_tokens[name]
            elif name in ('partner_categories',):
                d[name] = as_primitive(getattr(self, name))
            else:
                d[name] = getattr(self, name)
        return d

provideAdapter(lambda partner: partner.as_primitive(),
               [IPartner], IPrimitive)


class PartnerVocabulary(PersistentVocabulary):
    u"""Vocabs партнёров-неавиакомпаний"""

    objectC = Partner
    makeVocabularyRegisterable('partners')


class PartnerOffice(MutableElement):
    u"""Филиал партнёра-неавиакомпании"""

    implements(IPartnerOffice)
    p_table_name = 'partner_offices'

    def get_contacts(self):
        vocab = getV('partner_office_contacts')
        return [vocab[partner_office_contact_id]
                for partner_office_contact_id in getI('contact_by_partner_office_idx')(self.partner_office_id)]

    def set_contacts(self, contacts):
        if contacts is None:
            contacts = []
        input_ids = set([ITokenizedTerm(c).token for c in contacts])
        idx = getI('contact_by_partner_office_idx')
        removed_ids = set([partner_office_contact_id
                           for partner_office_contact_id in idx(self.partner_office_id) if partner_office_contact_id not in input_ids])
        vocab = getV('partner_office_contacts')
        for c_id in removed_ids:
            del vocab[c_id]
        for c in contacts:
            c.partner_office = self.partner_office_id
            vocab.add(c)

    contacts = property(get_contacts, set_contacts)

    def as_primitive(self):
        d = {'class': self.__class__.__name__}

        for name in IPartnerOffice:
            if name not in ('partner', 'city', 'office_type', 'contacts'):
                d[name] = getattr(self, name)
        d['partner'] = self.p_choice_tokens['partner']
        d['city'] = self.p_choice_tokens['city']
        d['office_type'] = self.p_choice_tokens['office_type']
        d['contacts'] = [dict(partner_office_contact_id=c.partner_office_contact_id,
                              contact_type=c.p_choice_tokens['contact_type'],
                              contact=c.contact,
                              main_contact=c.main_contact) for c in self.contacts]
        return d

provideAdapter(lambda ob: ob.as_primitive(),
               [IPartnerOffice], IPrimitive)


class PartnerOfficeVocabulary(PersistentVocabulary):
    u"""Vocabs филиалов партнёров-неавиакомпаний"""

    objectC = PartnerOffice
    makeVocabularyRegisterable('partner_offices')

    #def __delitem__(self, key):
    #    contacts = self[key].get_contacts()
    #    for contact in contacts:
    #        notify.on_object_deleted(contact)
    #        del contact
    #    super(PartnerOfficeVocabulary, self).__delitem__(key)


class PartnerOfficeContact(MutableElement, TitleCapable):
    u"""Контакт филиала партнёра-неавиакомпании"""

    implements(IPartnerOfficeContact)
    p_table_name = 'partner_office_contacts'

    @property
    def title(self):
        return '%s: %s' % (self.contact_type.title, self.contact)


class PartnerOfficeContactVocabulary(PersistentVocabulary):
    u"""Vocab контактов филиала партнёра-неавиакомпании"""

    objectC = PartnerOfficeContact
    makeVocabularyRegisterable('partner_office_contacts')


class ContactByPartnerOffice(Indexer):
    u"""Index контактов филиала партнёра-неавиакомпании"""

    name = 'contact_by_partner_office_idx'
    parent_vocab = 'partner_office_contacts'

    def key(self, ob):
        return str(ob.partner_office)


class PartnerAwardCondition(MutableElement):
    u"""Условия набора и траты миль"""

    implements(IPartnerAwardCondition)
    p_table_name = 'partner_award_conditions'


class PartnerAwardConditionVocabulary(PersistentVocabulary):
    u"""Vocabs условий набора и траты миль для партнёров-неавиакомпаний"""

    objectC = PartnerAwardCondition
    makeVocabularyRegisterable('partner_award_conditions')


class PartnerMileActionVocabulary(SimpleVocabulary):
    u"""Возможные действия с милями для партнёров-неавиакомпаний"""

    items = (
        ('A',   _(u'Набор и трата')),
        ('E',   _(u'Набор')),
        ('S',   _(u'Трата')),
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('partner_mile_actions')


class ContactTypeVocabulary(SimpleVocabulary):
    u"""Список типов контактов"""

    items = (
        ('P',   _(u'Телефон')),
        ('F',   _(u'Факс')),
        ('E',   _(u'Email')),
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('partner_office_contact_types')


class PartnerOfficeTypeVocabulary(SimpleVocabulary):
    u"""Список типов филиалов партнёров-неавикомпаний"""

    items = (
        ('M',   _(u'Головной офис')),
        ('O',   _(u'Филиал'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('partner_office_types')


class PartnerAwardConditionTypeVocabulary(SimpleVocabulary):
    u"""Список типов условий набора и траты миль для партнёров-неавиакомпаний"""

    items = (
        ('E',   _(u'Набор')),
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('partner_award_condition_types')

