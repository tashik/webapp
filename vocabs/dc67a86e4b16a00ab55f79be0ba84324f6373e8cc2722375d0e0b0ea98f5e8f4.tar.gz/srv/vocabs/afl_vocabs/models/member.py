# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable

from models.interfaces import ILoyaltyProgram, IProfessionalArea


class LoyaltyProgram(MutableElement, TitleCapable):
    u"""Программа лояльности"""

    implements(ILoyaltyProgram)
    p_table_name = 'loyalty_programs'

    @property
    def title(self):
        return u'%s' % self.name


class LoyaltyProgramVocabulary(PersistentVocabulary):
    objectC = LoyaltyProgram
    makeVocabularyRegisterable('loyalty_programs')


class ProfessionalArea(MutableElement, TitleCapable):
    u"""Род деятельности"""

    implements(IProfessionalArea)
    p_table_name = 'professional_areas'


class ProfessionalAreaVocabulary(PersistentVocabulary):
    objectC = ProfessionalArea
    makeVocabularyRegisterable('professional_areas')
