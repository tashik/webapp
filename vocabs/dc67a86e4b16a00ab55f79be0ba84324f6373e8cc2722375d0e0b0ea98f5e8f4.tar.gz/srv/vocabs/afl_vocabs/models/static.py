# -*- coding: utf-8 -*-
from pyramid.registry import makeVocabularyRegisterable
from pyramid.vocabulary.simple import SimpleVocabulary
from zope.schema.vocabulary import SimpleTerm

from i18n import _


class ItemStatusVocabulary(SimpleVocabulary):
    u"""Список статусов элемента словаря"""

    vocab_items = (
        ('P',   _(u'Опубликовано')),
        ('U',   _(u'Не опубликовано'))
    )


    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.vocab_items])


    makeVocabularyRegisterable('publication_statuses')
