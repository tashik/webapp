# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable

from rx.i18n.translation import self_translated

from models.interfaces import ISkyTeamServiceClass, IAirlineServiceClass, IComment, IServiceClassesLimit
from models.ml import MLTitleCapable
from pyramid.vocabulary.simple import SimpleVocabulary
from zope.schema.vocabulary import SimpleTerm
from i18n import _

class SkyTeamServiceClass(MutableElement, MLTitleCapable):
    u"""Класс обслуживания SkyTeam"""

    implements(ISkyTeamServiceClass)
    p_table_name = 'skyteam_service_classes'


class SkyTeamServiceClassVocabulary(PersistentVocabulary):
    objectC = SkyTeamServiceClass
    makeVocabularyRegisterable('skyteam_service_classes')


class AirlineServiceClass(MutableElement, MLTitleCapable):
    u"""Класс обслуживания SkyTeam"""

    implements(IAirlineServiceClass)
    p_table_name = 'airline_service_classes'

    @property
    def title(self):
        dal = self.airline.title.msgid
        dal_first = dal.get("ru", next(dal.itervalues()))
        d = self.skyteam_sc.title.msgid
        d_first = d.get("ru", next(d.itervalues()))

        for lang, t in d.iteritems():
            d[lang] = dal.get(lang, dal_first) + u": " + t

        for lang in dal:
            if lang in d: 
                continue
            d[lang] = dal[lang] + u": " + d_first

        return self_translated(**d)

class AirlineServiceClassVocabulary(PersistentVocabulary):
    objectC = AirlineServiceClass
    makeVocabularyRegisterable('airline_service_classes')


class Comment(MutableElement, MLTitleCapable):
    u"""Комментарий"""

    implements(IComment)
    p_table_name = 'comments'


class CommentVocabulary(PersistentVocabulary):
    objectC = Comment
    makeVocabularyRegisterable('comments')


class ServiceClassesLimit(MutableElement):
    u"""Ограничения для классов обслуживания"""

    implements(IServiceClassesLimit)
    p_table_name = 'service_classes_limits'


class ServiceClassesLimitVocabulary(PersistentVocabulary):
    objectC = ServiceClassesLimit
    makeVocabularyRegisterable('service_classes_limits')


class ServiceClassClassificationLevelVocabulary(SimpleVocabulary):
    u"""Список квалификационных уровеней"""

    items = (
        ('E',   _(u'Экономический класс')),
        ('B',   _(u'Бизнес класс'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('service_class_classification_levels')