# -*- coding: utf-8 -*-

"""
$Id: $
"""
import sys

from zope.component import provideAdapter
from zope.interface import implements
from zope.schema.vocabulary import SimpleTerm

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable
from pyramid.vocabulary.simple import SimpleVocabulary

from rx.utils.json import record_to_primitive, IPrimitive
from rx.i18n.translation import self_translated

from i18n import _
from models.interfaces import IRedemptionZone, ITierLevel, ITariffGroup, \
    IBonusRoute, IAward, \
    ITierLevelFactor, IAirlineTariffGroup, IBookingClass
from models.ml import MLTitleCapable

class RedemptionZone(MutableElement, MLTitleCapable):
    u"""Премиальная зона"""

    implements(IRedemptionZone)
    p_table_name = 'redemption_zones'


class RedemptionZonesVocabulary(PersistentVocabulary):

    objectC = RedemptionZone
    makeVocabularyRegisterable('redemption_zones')


class TierLevel(MutableElement, MLTitleCapable):
    u"""Статус участника"""

    implements(ITierLevel)
    p_table_name = 'tier_levels'


class TierLevelVocabulary(PersistentVocabulary):

    objectC = TierLevel
    makeVocabularyRegisterable('tier_levels')


class TierLevelFactor(MutableElement):
    u"""Коэффициент статуса участника"""

    implements(ITierLevelFactor)
    p_table_name = 'tier_level_factors'


class TierLevelFactorVocabulary(PersistentVocabulary):

    objectC = TierLevelFactor
    makeVocabularyRegisterable('tier_level_factors')


class TariffGroup(MutableElement, MLTitleCapable):
    u"""Тарифная группа"""

    def as_primitive(self):
        d = record_to_primitive(self)
        return d

    @property
    def title(self):
        try:
            dsc = dict([
                s.split(':', 1) for s in self.service_class.names
            ])
            dsc_first = self.service_class.names[0].split(":", 1)[-1]
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.service_class.names), tb 
        try:
            d = dict([
                s.split(':', 1) for s in self.names
            ])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.names), tb

        #Если все переводы наименований тарифных групп пустые, то качестве значения возварщаем код тарифноый гуппы
        #переведенный на русский язык, перевод на нужный язык будет сделан автоматически

        tariff_group_names = d.values()
        if tariff_group_names.count(u"") == len(tariff_group_names):
            d = {'ru:': self.tariff_group}
        else:
        #В противном случае возвращаем значение "класс обслуживание: наименование тарифной группы"
            for lang, t in d.iteritems():
                d[lang] = dsc.get(lang, dsc_first) + u": " + t

        return self_translated(**d)

    implements(ITariffGroup)
    p_table_name = 'tariff_groups'


provideAdapter(lambda tariff_group: tariff_group.as_primitive(),
               [ITariffGroup], IPrimitive)


class TariffGroupsVocabulary(PersistentVocabulary):
    objectC = TariffGroup
    makeVocabularyRegisterable('tariff_groups')


class AirlineTariffGroup(MutableElement, TitleCapable):
    u"""Тарифная группа для авиакомпании"""

    implements(IAirlineTariffGroup)
    p_table_name = "airline_tariff_groups"

    @property
    def title(self):
        dsc = self.serviceClass.airline.title.msgid
        dsc_first = dsc.get("ru", next(dsc.itervalues()))
        d = self.tariffGroup.title.msgid
        corf = self.chargeCoef
        for lang, t in d.iteritems():
            d[lang] = u'{0}: {1}: {2}'.format(dsc.get(lang, dsc_first), t, corf)

        return self_translated(**d)


class AirlineTariffGroupsVocabulary(PersistentVocabulary):
    objectC = AirlineTariffGroup
    makeVocabularyRegisterable("airline_tariff_groups")


class BookingClass(MutableElement, MLTitleCapable):
    u"""Класс бронирования"""

    implements(IBookingClass)
    p_table_name = "booking_classes"

    @property
    def title(self):
        return u'{} {}'.format(self.alTariffGroup.title, self.bcCode)


class BookingClassesVocabulary(PersistentVocabulary):
    objectC = BookingClass
    makeVocabularyRegisterable("booking_classes")


class BonusRoute(MutableElement, TitleCapable):
    u"""Премиальный маршрут"""

    implements(IBonusRoute)
    p_table_name = 'bonus_routes'

    @property
    def title(self):
        return "%s: %s" % (self.carrier.title, self.code)


class BonusRoutesVocabulary(PersistentVocabulary):
    objectC = BonusRoute
    makeVocabularyRegisterable('bonus_routes')


class CarrierVocabulary(SimpleVocabulary):
    u"""Список перевозчиков"""

    items = (
        ('A', _(u'Аэрофлот')),
        ('S', _(u'SkyTeam'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('carriers')


class Award(MutableElement):
    u"""Премия"""

    implements(IAward)
    p_table_name = 'awards'


class AwardVocabulary(PersistentVocabulary):
    objectC = Award
    makeVocabularyRegisterable('awards')


class AwardTypesVocabulary(SimpleVocabulary):
    u"""Список типов премий"""

    items = (
        ('OW',  _(u'OW')),
        ('RT',  _(u'RT')),
        ('U',   _(u'Повышение класса обслуживания RT')),
        ('UC',  _(u'Повышение класса обслуживания на стойке регистрации OW')),
        ('UO',  _(u'Повышение класса обслуживания OW'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('award_types')
