# -*- coding: utf-8 -*-

"""
$Id: $
"""
from datetime import date, datetime, timedelta

from zope.component import provideAdapter
from zope.interface import implements
from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from models.interfaces import ICharityFund
from pyramid.registry import makeVocabularyRegisterable
from models.ml import MLTitleCapable

from rx.utils.json import IPrimitive, as_primitive

from pyramid.registry import makeVocabularyRegisterable


class CharityFund(MutableElement, MLTitleCapable):
    u"""Партнёр Благотворительный фонд"""

    implements(ICharityFund)
    p_table_name = 'charity_funds'
    defaults = {
        'create_date': datetime.now(),
        'modify_date': datetime.now(),
        'weight': 10
    }

    def as_primitive(self):
        d = {'class': self.__class__.__name__}
        for name in ICharityFund:
            d[name] = getattr(self, name)
            if name in ("partner", "status",):
                d[name] = self.p_choice_tokens[name]
            if name in ('create_date', 'modify_date') and isinstance(d[name], date):
                d[name] = d[name].strftime('%Y-%m-%d')
        return d

    def save(self, replace=True):
        self.modify_date = datetime.now().strftime('%Y-%m-%d')
        super(CharityFund, self).save(replace)

provideAdapter(lambda info: info.as_primitive(),
               [ICharityFund], IPrimitive)


class CharityFundVocabulary(PersistentVocabulary):
    objectC = CharityFund
    makeVocabularyRegisterable('charity_funds')