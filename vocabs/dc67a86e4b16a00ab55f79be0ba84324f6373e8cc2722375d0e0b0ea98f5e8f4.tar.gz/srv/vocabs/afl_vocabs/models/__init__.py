# -*- coding: utf-8 -*-

import time

_VERSION_SHIFT = 1000000

class VocabDataVersion(object):
    versions = {}
    # Чтобы не заморачиваться с сохранением версии в БД базируем номер версии на времени старта сервера.
    # Инкремент версии будет происходить в нижних разрядах.
    # При рестарте сервера номера версий автоматически увеличатся.
    _base_version = int(time.time()) * _VERSION_SHIFT

    # вызывающий код в notify имеет свой threading lock, поэтому здесь локировать не нужно
    @classmethod
    def increment_version(cls, vocab_name):
        try:
            cls.versions[vocab_name] += 1
        except KeyError:
            cls.versions[vocab_name] = 1
        return cls.versions[vocab_name]

    @classmethod
    def get_version(cls, vocab_name):
        return cls.versions.get(vocab_name, 0) + cls._base_version
