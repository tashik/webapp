# -*- coding: utf-8 -*-
"""
$Id: ancillary_services.py 18871 2016-05-23 13:40:15Z mshevyakov $
"""
from datetime import datetime

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable
from rx.utils.json import IPrimitive
from zope.component import provideAdapter
from zope.interface import implements

from models.interfaces import IAncillaryServicesGroup, IAncillaryService, IRFICCode, IAncillaryServiceStatus, IVatRate
from models.ml import MLTitleCapable


class AncillaryServicesGroup(MutableElement, MLTitleCapable):
    u"""Группа дополнительных услуг"""

    implements(IAncillaryServicesGroup)
    p_table_name = 'ancillary_services_groups'


class AncillaryServicesGroupVocabulary(PersistentVocabulary):
    objectC = AncillaryServicesGroup
    makeVocabularyRegisterable('ancillary_services_groups')


class RFICCode(MutableElement, TitleCapable):
    u"""Код RFIC"""

    implements(IRFICCode)
    p_table_name = 'rfic_codes'

    @property
    def title(self):
        return self.code or u''


class RFICCodeVocabulary(PersistentVocabulary):
    objectC = RFICCode
    makeVocabularyRegisterable('rfic_codes')


class AncillaryService(MutableElement, MLTitleCapable):
    u"""Дополнительная услуга"""

    implements(IAncillaryService)
    p_table_name = 'ancillary_services'


class AncillaryServiceVocabulary(PersistentVocabulary):
    objectC = AncillaryService
    makeVocabularyRegisterable('ancillary_services')


class AncillaryServiceStatus(MutableElement, MLTitleCapable):
    u"""Статус дополнительных услуг"""

    implements(IAncillaryServiceStatus)
    p_table_name = 'ancillary_service_statuses'


class AncillaryServiceStatusVocabulary(PersistentVocabulary):
    objectC = AncillaryServiceStatus
    makeVocabularyRegisterable('ancillary_service_statuses')


class VatRate(MutableElement):
    implements(IVatRate)

    p_table_name = 'vat_rates'

    def as_primitive(self):
        d = {'class': self.__class__.__name__}
        for name in IVatRate:
            field = getattr(self, name)
            if isinstance(field, datetime):
                d[name] = str(field)
            else:
                d[name] = getattr(self, name)

        return d

provideAdapter(lambda partner: partner.as_primitive(),
               [IVatRate], IPrimitive)


class VatRatesVocabulary(PersistentVocabulary):
    objectC = VatRate
    makeVocabularyRegisterable('vat_rates')
