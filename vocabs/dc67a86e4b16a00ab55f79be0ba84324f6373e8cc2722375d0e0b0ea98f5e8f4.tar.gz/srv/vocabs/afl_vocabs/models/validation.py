# -*- coding: utf-8 -*-

"""
$Id: $
"""

import zope.interface
import zope.schema
import models.vocablist
import models.interfaces

def get_validation_errors(schema, object):
    """Return a list of all validation errors.

    """
    errors = get_schema_validation_errors(schema, object)
    if errors:
        return errors

    # Only validate invariants if there were no previous errors. Previous
    # errors could be missing attributes which would most likely make an
    # invariant raise an AttributeError.
    invariant_errors = []
    try:
        schema.validateInvariants(object, invariant_errors)
    except zope.interface.exceptions.Invalid:
        # Just collect errors
        pass
    errors = [(None, e) for e in invariant_errors]
    return errors


def get_schema_validation_errors(schema, object):
    errors = []
    for name in schema.names(all=True):
        if zope.interface.interfaces.IMethod.providedBy(schema[name]):
            continue
        if zope.schema.interfaces.IChoice.providedBy(schema[name]):
            # TODO: валидация пирамидовского choice
            continue
        if models.vocablist.IVocabList.providedBy(schema[name]):
            # TODO: валидация vocablist
            continue
        if models.interfaces.IPartnerOfficeContactField.providedBy(schema[name]):
            # TODO: валидация PartnerOfficeContactField
            continue
        attribute = schema[name]
        if not zope.schema.interfaces.IField.providedBy(attribute):
            continue
        try:
            value = getattr(object, name)
        except AttributeError, error:
            # property for the given name is not implemented
            errors.append((
                name, zope.schema.interfaces.SchemaNotFullyImplemented(error)))
        else:
            #print name, repr(value)
            try:
                attribute.bind(object).validate(value)
            except zope.schema.ValidationError, e:
                errors.append((name, e))
    return errors
