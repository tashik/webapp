# -*- coding: utf-8 -*-
"""
$Id$
"""
from datetime import date

from zope.interface import implements
from zope.component import provideAdapter

from rx.utils.json import IPrimitive
from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable

from models.interfaces import IMealType, ISpecialMeal, IMealRule, IMealTimelimit


class MealType(MutableElement, TitleCapable):
    u"""Тип питания"""

    implements(IMealType)
    p_table_name = 'meal_types'


class MealTypeVocabulary(PersistentVocabulary):
    objectC = MealType
    makeVocabularyRegisterable('meal_types')


class SpecialMeal(MutableElement, TitleCapable):
    u"""Спецпитание"""

    implements(ISpecialMeal)
    p_table_name = 'special_meal'


class SpecialMealVocabulary(PersistentVocabulary):
    objectC = SpecialMeal
    makeVocabularyRegisterable('special_meal')


class MealRule(MutableElement, TitleCapable):
    u"""Правила заказа питания"""

    implements(IMealRule)
    p_table_name = 'meal_rules'

    def as_primitive(self):
        d = {'class': self.__class__.__name__}
        for name in IMealRule:
            d[name] = getattr(self, name)
        if isinstance(d['date_from'], date):
            d['date_from'] = d['date_from'].strftime('%Y-%m-%d')
        if isinstance(d['date_to'], date):
            d['date_to'] = d['date_to'].strftime('%Y-%m-%d')
        if d['airline']:
            d['airline'] = [x.iata for x in d['airline'] if x.iata]
        if d['origin']:
            d['origin'] = [x.iata for x in d['origin'] if x.iata]
        if d['destination']:
            d['destination'] = [x.iata for x in d['destination'] if x.iata]
        if d['booking_class']:
            d['booking_class'] = [x.bcCode for x in d['booking_class']]
        if d['special_meal']:
            d['special_meal'] = [x.code for x in d['special_meal']]
        return d

provideAdapter(lambda x: x.as_primitive(), [IMealRule], IPrimitive)


class MealRulesVocabulary(PersistentVocabulary):
    objectC = MealRule
    makeVocabularyRegisterable('meal_rules')


class MealTimelimit(MutableElement, TitleCapable):
    u"""Ограничение времени выбора питания"""

    implements(IMealTimelimit)
    p_table_name = 'meal_timelimits'

    def as_primitive(self):
        d = {'class': self.__class__.__name__}
        for name in IMealTimelimit:
            d[name] = getattr(self, name)
        if d['origin']:
            d['origin'] = [x.iata for x in d['origin'] if x.iata]
        if d['special_meal']:
            d['special_meal'] = [x.code for x in d['special_meal']]
        return d

provideAdapter(lambda x: x.as_primitive(), [IMealTimelimit], IPrimitive)


class MealTimelimitsVocabulary(PersistentVocabulary):
    objectC = MealTimelimit
    makeVocabularyRegisterable('meal_timelimits')
