# -*- coding: utf-8 -*-

"""
$Id: base.py 21023 2016-09-30 06:41:15Z oeremeeva $
"""

import re
import json
from pyramid.ormlite import dbquery
from pyramid.ormlite.schema import Text, TextLine
from pyramid.vocabulary.mvcc import MvccVocabulary
from zope.interface import implements
from zope.schema.interfaces import IText, ITextLine
from ui.widgets import is_valid_numbers_list

LOYALTY_ID_REGEXP = re.compile(r'^\s*[0-9]+[0-9 ]*$')

class MvccVocabularyBase(MvccVocabulary):
    objectC = NotImplemented

    @classmethod
    def coerce_token(cls, token):
        if isinstance(token, dict):
            k = [str(token[p]) for p in cls.objectC.p_keys]
            return k[0] if len(k) == 1 else tuple(k)
        elif isinstance(token, (list, tuple)):
            return str(token[0]) if len(token) == 1 else tuple(str(p) for p in token)
        else:
            return str(token)

    def preload(self):
        table_name = self.objectC.p_table_name
        objects = self.objectC.bulkLoadList(
            dbquery('select * from {}'.format(table_name)))
        self.add_many(objects)


class FilenameField(TextLine):
    u"""Название файла"""

    def constraint(self, value):
        u"""Маленькие латинские буквы и цифры, начинается с буквы"""
        return super(FilenameField, self).constraint(value) and re.match('^([a-z][a-z0-9_]*)?$', value) is not None


class ILoyaltyField(ITextLine):
    pass


class LoyaltyField(TextLine):
    u"""Номер в системе лояльности"""
    implements(ILoyaltyField)

    def constraint(self, value):
        return super(LoyaltyField, self).constraint(value) and bool(LOYALTY_ID_REGEXP.match(value))


class IJSONConditionField(IText):
    pass


class JSONConditionField(Text):
    """
    Текстовое поле в формате JSON: массив словарей
    """
    implements(IJSONConditionField)

    def fromDbType(self, value):
        if not isinstance(value, basestring):
            value = json.dumps(value, ensure_ascii=False)
        return super(JSONConditionField, self).fromDbType(value)

    def null(self):
        return u'[]'

    def constraint(self, value):
        try:
            value = json.loads(value)
        except (ValueError, TypeError):
            return False
        if not isinstance(value, list):
            return False
        for x in value:
            if not isinstance(x, dict):
                return False
        return True


class INumbersListField(ITextLine):
    pass


class NumbersListField(TextLine):
    implements(INumbersListField)

    def constraint(self, value):
        return is_valid_numbers_list(value)
