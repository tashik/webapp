# -*- coding: utf-8 -*-
"""
$Id: $
"""

from zope.interface import implements
import zope.schema.interfaces as zsi
from pyramid.ormlite.schema import List
import zope.schema as zs
from pyramid.vocabulary import getV
from pyramid.ormlite.schema.interfaces import IORMField
from zope.schema.interfaces import ITitledTokenizedTerm


class IVocabList(zsi.IField):
    pass

class VocabItem(zs.Text):
    implements(IORMField)
    def __init__(self,vocab_name, *args, **kw):
        super(VocabItem, self).__init__(*args, **kw)
        self.vocab_name = vocab_name

    def fromUnicode(self, s):
        try:
            vocab = getV(self.vocab_name)
            res = vocab[s]
        except Exception, e:
            res = None
        return res

    def toUnicode(self, value):
        v = ITitledTokenizedTerm(value)
        return v.token

class VocabList(List):
    implements(IVocabList)

    def __init__(self, source, **kw):
        super(VocabList, self).__init__(**kw)
        self.vocabularyName = source
        self.value_type = VocabItem(source)

    def fromDbType(self, value):
        if value == None:
            value = ""
        res = filter(lambda x: x !=None, super(VocabList, self).fromDbType(value))
        return res