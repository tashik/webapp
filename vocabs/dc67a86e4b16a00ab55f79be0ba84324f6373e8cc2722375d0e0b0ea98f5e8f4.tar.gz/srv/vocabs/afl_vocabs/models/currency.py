# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface.declarations import implements

from pyramid.ormlite.cache import MutableElement
from pyramid.registry import makeVocabularyRegisterable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary

from models.interfaces import ICurrency
from models.ml import MLTitleCapable


class Currency(MutableElement, MLTitleCapable):
    u"""Валюта"""

    implements(ICurrency)
    p_table_name = 'currencies'


class CurrenciesVocabulary(PersistentVocabulary):
    objectC = Currency
    makeVocabularyRegisterable('currencies')
