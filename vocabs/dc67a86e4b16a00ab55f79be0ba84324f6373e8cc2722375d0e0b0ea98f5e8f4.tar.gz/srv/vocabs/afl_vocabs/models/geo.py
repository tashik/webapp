# -*- coding: utf-8 -*-
"""
$Id: geo.py 4287 2014-05-07 09:46:46Z skopeikin $
"""


from zope.interface import implements
from zope.component import adapts, provideAdapter

from pyramid.ormlite.record import ActiveRecord
from pyramid.ormlite.cache import MutableElement
from pyramid.registry import makeVocabularyRegisterable, makeAdapterRegisterable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.ormlite.vocabulary.rdb import RDBVocabulary
from pyramid.vocabulary.adapters import BaseTermAdapter
from pyramid.vocabulary.factory import VocabularyFactory
from rx.utils.json import IPrimitive

from models.base import MvccVocabularyBase
from models.interfaces import ICountry, IWorldRegion, ICity
from models.airport import Airport
from models.ml import MLTitleCapable


class WorldRegion(MutableElement, MLTitleCapable):
    u"""Регион мира"""

    implements(IWorldRegion)
    p_table_name = 'world_regions'


class WorldRegionsVocabulary(PersistentVocabulary):
    objectC = WorldRegion
    makeVocabularyRegisterable('world_regions')


class Country(MutableElement, MLTitleCapable):
    u"""Страна"""

    implements(ICountry)
    p_table_name = 'countries'


class CountriesVocabulary(PersistentVocabulary):
    objectC = Country
    makeVocabularyRegisterable('countries')


class City2TermAdapter(BaseTermAdapter):
    adapts(ICity)
    tokenAttr = ('city_id',)
    titleAttr = 'fullTitle'

    makeAdapterRegisterable()


class City(ActiveRecord, MLTitleCapable):
    u"""Город"""

    implements(ICity)
    p_table_name = 'cities'

    @property
    def fullTitle(self):
        return u'%s, %s' % (self.shortTitle, self.title)

    @property
    def shortTitle(self):
        return self.iata if self.iata else '---'

#    @property
#    def has_afl_flights(self):
#        selectSql = "select c.* from %s a inner join %s c on a.city_id = c.city_id where c.city_id = %i and a.has_afl_flights = 'True'" % \
#                    (Airport.p_table_name, City.p_table_name, self.city_id)
#        if dbquery(selectSql).fetchone():
#            return True
#        return False
#
#    def as_primitive(self):
#        d = record_to_primitive(self)
#        d['has_afl_flights'] = self.has_afl_flights
#        return d
#
#provideAdapter(lambda city: city.as_primitive(),
#               [ICity], IPrimitive)

    # оптимизированный (упрощенный) вариант, в 30 раз быстрее базового
    def as_primitive(self):
        d = {'class': self.__class__.__name__}
        for name in ICity:
            d[name] = getattr(self, name)
        return d

provideAdapter(lambda city: city.as_primitive(),
               [ICity], IPrimitive)


class CitiesVocabulary(MvccVocabularyBase):
    objectC = City
    makeVocabularyRegisterable('cities')


class AFLCitiesVocabulary(RDBVocabulary):
    objectC = City

    def __init__(self, *args, **kwargs):
        self.select = u"select distinct c.* from %s a inner join %s c on a.city_id = c.city_id where a.has_afl_flights = 'True'" % \
                    (Airport.p_table_name, City.p_table_name)
        super(AFLCitiesVocabulary, self).__init__(*args, **kwargs)

    makeVocabularyRegisterable('afl_cities', factory=VocabularyFactory)

