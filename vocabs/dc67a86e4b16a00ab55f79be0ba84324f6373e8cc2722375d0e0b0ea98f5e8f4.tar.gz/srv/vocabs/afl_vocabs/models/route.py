# -*- coding: utf-8 -*-

"""
$Id: $
"""


from zope.component import provideAdapter
from zope.interface import implements

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable
from rx.utils.json import as_primitive, record_to_primitive, IPrimitive

from models.interfaces import IPair, IWrongRoute


class Pair(MutableElement, TitleCapable):
    u"""Пара"""

    implements(IPair)
    p_table_name = 'pairs'

    @property
    def title(self):
        return u'%s: %s - %s' % (self.airline.title, self.airport_from, self.airport_to)


class PairsVocabulary(PersistentVocabulary):
    objectC = Pair
    makeVocabularyRegisterable('pairs')


class WrongRoute(MutableElement, TitleCapable):
    u"""Запрещённый маршрут"""

    implements(IWrongRoute)
    p_table_name = 'wrong_routes'

    @property
    def title(self):
        return u'%s - %s - %s' % (self.city_from, self.city_via, self.city_to)


class WrongRoutesVocabulary(PersistentVocabulary):
    objectC = WrongRoute
    makeVocabularyRegisterable('wrong_routes')

