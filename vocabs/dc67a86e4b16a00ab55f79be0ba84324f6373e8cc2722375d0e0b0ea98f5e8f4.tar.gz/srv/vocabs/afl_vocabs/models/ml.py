# -*- coding: utf-8 -*-

"""
$Id: $
"""
import sys
import re
import zope.schema as zs
import zope.schema.interfaces as zsi
from zope.interface import implements
from pyramid.exc import PyramidException
from pyramid.ormlite.schema import List
from pyramid.ormlite.models import TitleCapable
from rx.i18n.translation import self_translated

WRONG_LINE_VALUE = re.compile('^\S{2}:$')

class MLFormatError(PyramidException):
    def __init__(self, s):
        super(PyramidException, self).__init__(msg=u'Некорректный формат многоязычной строки %r' % s)


class MLTitleCapable(TitleCapable):
    @property
    def title(self):
        try:
            d = dict([s.split(':', 1) for s in self.names])
        except ValueError:
            t, e, tb = sys.exc_info()
            raise t, repr(self.names), tb 
        return self_translated(**d)


class SafeTextLine(zs.TextLine):
    """A text field with no newlines."""

    def fromUnicode(self, value):
        value = value.replace('\n', '').replace('\r', '')
        super(SafeTextLine, self).validate(value)
        return value


class ITextLineList(zsi.IField):
    u""" Список текстовых строк """
    separator = zs.TextLine(title=u'Разделитель строк при сохранении в БД')


class TextLineList(List):
    implements(ITextLineList)

    #value_type = zs.TextLine()

    record_separator = '\n'

    def __init__(self, value_type=SafeTextLine(), **kw):
        super(TextLineList, self).__init__(value_type=value_type, **kw)

    def toDbType(self, value):
        checked_value = []
        for elem in value:
            check_elem = WRONG_LINE_VALUE.match(elem)
            if not check_elem:
                checked_value.append(elem)
        return super(TextLineList, self).toDbType(checked_value)

    def fromUnicode(self, s):
        if isinstance(s, basestring):
            value = [line.strip() for line in s.strip().split(self.record_separator)]
        else:
            value = s
        self.validate(value)
        return value

    def toUnicode(self, value):
        return self.record_separator.join(value)

    def constraint(self, value):
        if not super(TextLineList, self).constraint(value):
            return False
        for elem in value:
            if self.separator in elem:
                return False
        return True


class IMLNames(ITextLineList):
    u""" Список многоязычных строк. Каждая строка имеет формат язык:текст """


class MLNames(TextLineList):
    implements(IMLNames)

    def __init__(self, separator='|', **kw):
        super(MLNames, self).__init__(separator=separator, **kw)


class IStringLineList(ITextLineList):
    u""" Список значений в строке """


class StringLineList(TextLineList):
    implements(IStringLineList)

    def __init__(self, value_type=SafeTextLine(), **kw):
        super(StringLineList, self).__init__(value_type=value_type, **kw)
        self.record_separator = ' '


# проверку должен выполнять виджет
#    def constraint(self, value):
#        if not super(TextLineList, self).constraint(value):
#            return False
#        for elem in value:
#            if self.separator in elem:
#                return False
#            if len(elem) < 3 or elem[2] != ':':
#                return False
#        return True


class SafeText(zs.Text):
    """A multiline text field with no tabs."""

    def fromUnicode(self, value):
        value = value.replace('\t', '    ')
        super(SafeText, self).validate(value)
        return value

    def constraint(self, value):
        return '\t' not in value


class IMLText(ITextLineList):
    u"""
    Список многоязычных текстов, поддерживающих форматирование. Каждая
    строка имеет формат язык:текст
    """


class MLText(TextLineList):
    implements(IMLText)

    # использование переноса строки в качестве раздилителя опасно, так как
    # перенос строк может встречаться в самом тексте
    record_separator = '\t'

    def __init__(self, separator='|', value_type=SafeText(), **kw):
        super(MLText, self).__init__(separator=separator, value_type=value_type,
                                     **kw)
