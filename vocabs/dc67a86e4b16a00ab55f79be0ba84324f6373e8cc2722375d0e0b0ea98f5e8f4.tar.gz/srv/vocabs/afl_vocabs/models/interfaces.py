# -*- coding: utf-8 -*-

"""
$Id: interfaces.py 27929 2017-10-20 11:32:58Z oeremeeva $
"""

from datetime import date, datetime

from pyramid.vocabulary import getV
from zope.interface import Interface, implements
import zope.schema as zs
import zope.schema.interfaces as zsi

from pyramid.ormlite.schema import *

from models.ml import MLNames, TextLineList, MLText, StringLineList
from models.uppercase import UppercaseTextLine, CodeTextLine
from models.tzname import TZName
from models.vocablist import VocabList
from models.base import (FilenameField, JSONConditionField, NumbersListField,
                         LoyaltyField)

from DecNumber import DecNumber


class IWorldRegion(Interface):
    world_region_id = Int(db_column='world_region_id', primary_key=True, required=True, readonly=True)
    names = MLNames(db_column='names', title=u'Название региона', required=True)


class ICountry(Interface):
    iso_code2 = UppercaseTextLine(db_column='country', title=u'2-значный код ISO', primary_key=True, required=True, min_length=2, max_length=2)
    iso_code3 = CodeTextLine(db_column='iso_code3', title=u'3-значный код ISO', required=False, min_length=3, max_length=3)
    world_region = Choice(db_column='world_region_id', source='world_regions', title=u'Регион', required=False)
    names = MLNames(db_column='names', title=u'Название страны', required=True)
    telephone_code = Int(db_column='telephone_code', title=u"Телефонный код страны", required=False)
    use_in_siebel = Bool(db_column='use_in_siebel', title=u'Используется в Siebel', default=True, required=False)
    currency = Choice(db_column='currency_alpha3_code', title=u'Валюта', source='currencies', required=True)
    use_in_pos = Bool(db_column='use_in_pos', required=False, title=u'Используется в AFL_POS', default=False)
    pcc_code = UppercaseTextLine(db_column='pcc_code', title=u'Код PCC', min_length=1, max_length=4, required=False)
    station_code = TextLine(db_column='station_code', title=u"Код Station", required=False, default=u'00000000')
    corporate_pcc_code = UppercaseTextLine(db_column='corporate_pcc_code', title=u'Корпоративный код PCC', min_length=1, max_length=4, required=False)
    corporate_station_code = TextLine(db_column='corporate_station_code', title=u"Корпоративный код Station", required=False, default=u'00000000')
    corporate_currency = Choice(db_column='corporate_currency_alpha3_code', title=u'Корпоративная валюта POS', source='currencies', required=False)
    capital = Choice(db_column='city_id', title=u'Столица', source='cities', required=False)


class ICity(Interface):
    city_id = Int(db_column='city_id', primary_key=True, required=True, readonly=True)
    country_code = UppercaseTextLine(db_column='country', title=u'2-значный код страны', min_length=2, max_length=2, required=False)
    tz = TZName(db_column='tz', title=u'Часовой пояс', required=True)
    iata = CodeTextLine(db_column='iata', title=u'Код города по IATA', min_length=3, max_length=3, required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    can_book = Bool(db_column='can_book', title=u'Допускается бронирование', default=True, required=False)
    names = MLNames(db_column='names', title=u'Название города', required=True)
    alternative_cities = StringLineList(db_column='alternative_cities', title=u'Альтернативные города', required=False, separator=',')


class IAirportTerminal(Interface):
    terminal_id = Int(db_column='terminal_id', primary_key=True, required=True, readonly=True)
    airport_id = Int(db_column='airport_id', required=True)
    #    airport = zs.Object(IAirport)
    code = TextLine(db_column='code', title=u'Код терминала', required=True, max_length=20)
    names = MLNames(db_column='names', title=u'Название терминала', required=False, separator='^')


class IAirportTerminalField(zsi.IField):
    pass


class AirportTerminalField(zs.Object):
    implements(IAirportTerminalField)

    def __init__(self, **kw):
        super(AirportTerminalField, self).__init__(schema=IAirportTerminal, **kw)


class IAirport(Interface):
    airport_id = Int(db_column='airport_id', primary_key=True, required=True, readonly=True)
    iata = CodeTextLine(db_column='iata', title=u'IATA-код аэропорта', min_length=3, max_length=3, required=False)
    icao = CodeTextLine(db_column='icao', title=u'ICAO-код аэропорта', min_length=4, max_length=4, required=False)
    city = Choice(db_column='city_id', title=u'Город', source='cities', required=True)
    has_afl_flights = Bool(db_column='has_afl_flights', title=u'Сюда летает Аэрофлот', required=False)
    names = MLNames(db_column='names', title=u'Название аэропорта', required=True)
    terminals = zs.List(title=u'Терминалы', required=False, value_type=AirportTerminalField())
    afl_redemption_zone = Choice(db_column='afl_redemption_zone', title=u'Премиальная зона Аэрофлота', source='redemption_zones', required=False)
    skyteam_redemption_zone = Choice(db_column='skyteam_redemption_zone', title=u'Премиальная зона Skyteam', source='redemption_zones', required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    has_upgrade_on_checkin_award = Bool(db_column='has_uc_award', required=False, title=u'Доступна премия "Повышение класса обслуживания на стойке регистрации"')


class IAirline(Interface):
    airline_id = Int(db_column='airline_id', title=u'Id', primary_key=True, required=True, readonly=True)
    iata = CodeTextLine(db_column='iata', title=u'IATA-код', min_length=2, max_length=3, required=False)
    icao = CodeTextLine(db_column='icao', title=u'ICAO-код', min_length=3, max_length=3, required=False)
    callsign = UppercaseTextLine(db_column='callsign', title=u'Позывной', max_length=64, required=False)
    country = Choice(db_column='country', source='countries', title=u'Страна', required=False)
    airport = Choice(db_column='airport_id', title=u'Аэропорт базирования', source='airports', required=False)
    alliance = TextLine(db_column='alliance', title=u'Альянс', required=False)
    loyalty_program = Choice(db_column='loyalty_program_id', title=u'Программа лояльности', source='loyalty_programs', required=False)
    names = MLNames(db_column='names', title=u'Название авиакомпании', required=True)
    # parent_airline = Choice(db_column='parent_airline_id', title=u'Родительская авиакомпания', source='airlines', required=False)
    parent_airline = Int(db_column='parent_airline_id', title=u'Родительская авиакомпания', required=False)
    url = MLNames(db_column='url', title=u'Ссылка на сайт авиакомпании', required=False)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    miles_minimum = Float(db_column="miles_minimum", title=u"Минимальное количество миль при наборе", required=True)
    miles_limitation = Choice(db_column='miles_limitation', source='miles_limitations', title=u"Ограничения для минимального количества миль", required=True)
    miles_earn_description = MLText(db_column="miles_earn_description", title=u"Описание набора миль", required=False)
    miles_earn_comment = MLText(db_column="miles_earn_comment", title=u"Примечания для набора миль", required=False)


class IAircraftType(Interface):
    aircraft_type_id = Int(db_column='aircraft_type_id', primary_key=True, required=True, readonly=True)
    ohd_code = TextLine(db_column='ohd_code', title=u'Код ОХД', required=False)
    names = MLNames(db_column='names', title=u'Название модели', required=True)
    iata = UppercaseTextLine(db_column='iata', title=u'IATA-код', min_length=2, max_length=3, required=False)
    icao = UppercaseTextLine(db_column='icao', title=u'ICAO-код', min_length=3, max_length=4, required=False)
    #    mtow = Int(db_column='mtow', title=u'Макс. взлётная масса', required=False)
    #    mldw = Int(db_column='mldw', title=u'Макс. посадочная масса', required=False)
    #    mzfw = Int(db_column='mzfw', title=u'Maximum zero fuel weight', required=False)
    pax_capacity = Int(db_column='pax_capacity', title=u'Число мест', required=False)
    cargo_capacity = Int(db_column='cargo_capacity', title=u'Грузоподъемность', required=False)
    f = Int(db_column='f', title=u'Мест первого класса', required=False)
    c = Int(db_column='c', title=u'Мест бизнес-класса', required=False)
    y = Int(db_column='y', title=u'Мест эконом-класса', required=False)


# length = Float(db_column='length', title=u'Длина', required=False)
#    width = Float(db_column='width', title=u'Ширина', required=False)
#    height = Float(db_column='height', title=u'Высота', required=False)
#    number_engines = TextLine(db_column='number_engines', title=u'Кол-во двигателей', required=False)
#    engine_model = TextLine(db_column='engine_model', title=u'Модель двигателей', required=False)
#    timeslot_normal = TextLine(db_column='timeslot_normal', required=False)
#    timeslot_short = TextLine(db_column='timeslot_short', required=False)
#    stand_time = Int(db_column='stand_time', required=False)


class ICurrency(Interface):
    u"""Валюта"""

    alpha3_code = UppercaseTextLine(db_column='alpha3_code', primary_key=True, required=True, min_length=3, max_length=3, title=u'3-значный код валюты')
    iso_code = CodeTextLine(db_column='iso_code', required=True, min_length=3, max_length=3, title=u'Числовой код валюты (ISO 4217 / ОКВ)')
    cbr_code = CodeTextLine(db_column='cbr_code', required=False, title=u'Код для поиска курса валюты на сайте ЦБ РФ')
    minor_unit = Int(db_column='minor_unit', required=True, title=u'Число знаков разменной единицы')
    names = MLNames(db_column='names', title=u'Наименование валюты', required=True)
    used_in_calc = Bool(db_column='used_in_calc', required=False, title=u'Используется в калькуляторе валют')
    rounding_unit = FixedPoint(db_column='rounding_unit', required=True, title=u'Единица округления', default=DecNumber(1, 2), precision=2, min=DecNumber(0.01, 2))


class IRedemptionZone(Interface):
    u"""Премиальная зоны"""

    redemption_zone = UppercaseTextLine(db_column='redemption_zone', required=True, min_length=2, max_length=2, title=u'Код зоны', primary_key=True)
    names = MLNames(db_column='names', required=True, title=u'Название зоны')


class ITierLevel(Interface):
    u"""Статус участника"""

    tier_level = TextLine(db_column='tier_level', primary_key=True, required=True, min_length=1, max_length=16, title=u'Код статуса участника')
    names = MLNames(db_column='names', title=u'Наименование статуса участника', required=True)
    ordering = Int(db_column='ordering', required=True, title=u'Вес')
    miles = Int(db_column='miles', required=True, title=u'Мили')
    segments = Int(db_column='segments', required=True, title=u'Сегменты')
    business_segments = Int(db_column='business_segments', required=True, title=u'Бизнес сегменты')


class ITariffGroup(Interface):
    u"""Тарифная группа"""

    id_field = Int(db_column="id", required=True, primary_key=True, title=u"ID")
    service_class = Choice(db_column='service_class', source='skyteam_service_classes', title=u'Класс обслуживания', required=False)
    tariff_group = TextLine(db_column='tariff_group', required=True, title=u'Код', max_length=50)
    names = MLNames(db_column='names', title=u'Наименование тарифной группы', required=True)
    weight = Int(db_column="weight", required=False, title=u"Вес", default=0)


class IAirlineTariffGroup(Interface):
    u"""Тарифная группа для авиакомпании"""

    idField = Int(db_column="id", required=True, primary_key=True, title=u"ID")
    tariffGroup = Choice(db_column="tariff_group", source="tariff_groups", title=u"Тарифная группа", required=True)
    serviceClass = Choice(db_column="service_class", source="airline_service_classes", title=u"Класс обслуживания авиакомпании", required=True)
    chargeCoef = Int(db_column="charge_coef", required=True, title=u"Коэффициент для начисления")
    weight = Int(db_column="weight", required=True, title=u"Вес")
    fareCode = TextLine(db_column='fare_code', required=False, title=u'Тариф', max_length=50)


class IBookingClass(Interface):
    u"""Класс бронирования"""

    idField = Int(db_column="id", required=True, primary_key=True, title=u"ID")
    bcCode = TextLine(db_column="bc_code", required=True, title=u'Код', max_length=50)
    milesAreCharged = Bool(db_column="miles_are_charged", title=u"Мили начисляются", required=False)
    comment = MLText(db_column="commentary", title=u"Комментарий", required=False)
    alTariffGroup = Choice(db_column="al_tariff_group", source="airline_tariff_groups", title=u"Тарифная группа для АК", required=True)


class IPair(Interface):
    u"""Пара"""

    pair_id = Int(db_column='pair_id', primary_key=True, required=True, readonly=True)
    airline = Choice(db_column='airline_id', title=u'Авиакомпания', source='airlines', required=True)
    airport_from = Choice(db_column='airport_from_id', title=u'Аэропорт вылета', source='airports', required=True)
    airport_to = Choice(db_column='airport_to_id', title=u'Аэропорт прилёта', source='airports', required=True)
    miles = Int(db_column='miles', title=u'Расстояние', required=True)
    no_spending = Bool(db_column='no_spending', title=u'Не предоставлять трату', default=False, required=False)


class IWrongRoute(Interface):
    u"""Запрещённый маршрут"""

    wrong_route_id = Int(db_column='wrong_route_id', primary_key=True, required=True, readonly=True)
    city_from = Choice(db_column='city_from_id', title=u'Город вылета', source='cities', required=True)
    city_via = Choice(db_column='city_via_id', title=u'Город пересадки', source='cities', required=True)
    city_to = Choice(db_column='city_to_id', title=u'Город прилёта', source='cities', required=True)


class IMealType(Interface):
    u"""Тип питания"""

    mealtype = TextLine(db_column='meal_type', required=True, min_length=1, max_length=1, title=u'Код типа питания', primary_key=True)
    names = MLNames(db_column='names', title=u'Наименование типа питания', required=True)


class IOfficeCategory(Interface):
    u"""Категория офисов продаж"""

    office_category_id = Int(db_column='office_category_id', title=u'Id', primary_key=True, required=True)
    names = MLNames(db_column='names', title=u'Наименование категории офисов продаж', required=True)
    office_category_description = MLText(db_column='office_category_description', title=u'Описание', required=False)
    city = Choice(db_column='city_id', title=u'Город', source='cities', required=True)


class IOfficeTravelOption(Interface):
    u"""Дорога до офиса"""

    office_travel_option_id = Int(db_column='office_travel_option_id', title=u'Id', primary_key=True, required=True)
    office_id = Int(db_column='office_id', title=u'Офис Id', required=True)
    travel_type = Choice(db_column='travel_type', title=u'Тип', source='office_travel_option_types', required=True)
    office_travel_option_description = MLText(db_column='office_travel_option_description', title=u'Описание', required=False)
    travel_time = Int(db_column='travel_time', title=u'Время в пути (мин)', required=False)


class IOfficeTravelOptionField(zsi.IField):
    pass


class OfficeTravelOptionField(zs.Object):
    implements(IOfficeTravelOptionField)

    def __init__(self, **kw):
        super(OfficeTravelOptionField, self).__init__(schema=IOfficeTravelOption, **kw)


class IOffice(Interface):
    u"""Офисы"""

    office_id = Int(db_column='office_id', title=u'Id', primary_key=True, required=True)
    office_weight = Int(db_column='office_weight', title=u'Вес', required=True)
    names = MLNames(db_column='names', title=u'Наименование офиса продаж', required=False)
    office_description = MLNames(db_column='office_description', title=u'Описание', required=False)
    email = TextLineList(db_column='email', title=u'Email', required=False, separator='|')
    fax = TextLineList(db_column='fax', title=u'Факс', required=False, separator='|')
    phone = TextLineList(db_column='phone', title=u'Телефон', required=False, separator='|')
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    address = MLText(db_column='address', title=u'Адрес', required=False)
    worktime = MLText(db_column='working_time', title=u'Время работы', required=False)
    in_airport = Bool(db_column='in_airport', title=u'Признак нахождения на территории аэропорта', default=False, required=False)
    airport = Choice(db_column='airport_id', title=u'Аэропорт', source='airports', required=False)
    distance_to_airport = Int(db_column='distance_to_airport', title=u'Расстояние до аэропорта', required=False)
    insurance_policy = Bool(db_column='insurance_policy', title=u'Признак продажи страховых полисов', required=False)
    noncash_booking = Bool(db_column='noncash_booking', title=u'Признак заказа счёта для безналичной оплаты бронирования', required=False)
    new_office = Bool(db_column='new_office', title=u'Признак того, что офис новый', required=False)
    office_category = Choice(db_column='office_category_id', title=u'Категория офисов продаж', source='office_categories', required=True)
    location_map = MLNames(db_column='location_map', title=u'Схема проезда', required=False)
    transfer_time_public = Int(db_column='transfer_time_public', title=u'Время в пути до аэропорта на общественном транспорте (мин.)', required=False)
    transfer_time_automobile = Int(db_column='transfer_time_automobile', title=u'Время в пути до аэропорта на автомобиле (мин.)', required=False)
    transfer_time_foot = Int(db_column='transfer_time_foot', title=u'Время в пути до аэропорта пешком (мин.)', required=False)
    travel_options = zs.List(title=u'Дорога до офиса', required=False, value_type=OfficeTravelOptionField())
    important_info = MLText(db_column='important_info', title=u'Важная информация', required=False)


class IPartnerCategory(Interface):
    u"""Категория партнёров-неавиакомпаний"""

    partner_category_id = Int(db_column='partner_category_id', title=u'Id', primary_key=True, required=True)
    names = MLNames(db_column='names', title=u'Наименование категории партнёров', required=True)
    status = Choice(db_column='status', title=u'Статус категории партнёров', source='publication_statuses',
                    required=True)


class IPartner(Interface):
    u"""Партнёр-неавиакомпания"""

    partner_id = Int(db_column='partner_id', title=u'Id', primary_key=True, required=True)
    names = MLNames(db_column='names', title=u'Название', required=True)
    partner_description = MLText(db_column='partner_description', title=u'Описание', required=True)
    url = MLNames(db_column='url', title=u'Ссылка на сайт партнёра', required=True)
    partner_categories = VocabList(db_column='partner_categories', title=u'Категории', source='partner_categories', required=False)
    status = Choice(db_column='status', title=u'Статус', source='publication_statuses', required=True)
    mile_action = Choice(db_column='mile_action', title=u'Действия с милями', source='partner_mile_actions', required=True)
    mile_get_comm = MLText(db_column="mile_get_comm", title=u"Комментарий для набора миль", required=False)
    mile_waste_comm = MLText(db_column="mile_waste_comm", title=u"Комментарий для траты миль", required=False)
    spec_offer_comm = MLText(db_column="spec_offer_comm", title=u"Комментарий для спецпредложений", required=False)
    short_descr = MLText(db_column="short_descr", title=u"Краткое описание", required=False)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    new_until = Date(db_column='new_until', title=u'Новый до наступления даты', required=False)


class IPartnerOfficeContact(Interface):
    partner_office_contact_id = Int(db_column='partner_office_contact_id', primary_key=True, required=True, readonly=True)
    partner_office = Int(db_column='partner_office_id', required=True)
    contact_type = Choice(db_column='contact_type', title=u'Тип контакта', source='partner_office_contact_types', required=True)
    contact = TextLine(db_column='contact', title=u'Контактная информация', required=True, max_length=100)
    main_contact = Bool(db_column='main_contact', title=u'Основной контакт', default=False, required=True)


class IPartnerOfficeContactField(zsi.IList):
    pass


class PartnerOfficeContactField(zs.List):
    implements(IPartnerOfficeContactField)


class IPartnerOffice(Interface):
    u"""Филиал партнёра-неавиакомпании"""

    partner_office_id = Int(db_column='partner_office_id', title=u'Id', primary_key=True, required=True)
    partner = Choice(db_column='partner_id', title=u'Партнёр', source='partners', required=True)
    city = Choice(db_column='city_id', title=u'Город', source='cities', required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    comments = MLText(db_column='comments', title=u'Комментарий', required=False)
    address = MLText(db_column='address', title=u'Адреса', required=False)
    worktime = MLText(db_column='working_time', title=u'Время работы', required=False)
    office_type = Choice(db_column='office_type', title=u'Тип офиса', source='partner_office_types', required=False)
    contacts = PartnerOfficeContactField(title=u'Контакты', required=False, value_type=PartnerOfficeContactField())


class IPartnerAwardCondition(Interface):
    u"""Условия набора и траты миль"""

    partner_award_condition_id = Int(db_column='partner_award_condition_id', title=u'Id', primary_key=True, required=True)
    partner = Choice(db_column='partner_id', title=u'Партнёр', source='partners', required=True)
    award_condition_type = Choice(db_column='award_condition_type', title=u'Тип условия', source='partner_award_condition_types', required=True)
    award_condition_description = MLText(db_column='award_condition_description', title=u'Описание', required=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    status = Choice(db_column='status', title=u'Статус', source='publication_statuses', required=True)
    miles = Float(db_column="miles", title=u"Мили", required=True)


class ISkyTeamServiceClass(Interface):
    u"""Класс обслуживания SkyTeam"""

    skyteam_sc_id = Int(db_column='skyteam_sc_id', primary_key=True, required=True, readonly=True)
    code = TextLine(db_column='code', required=True, min_length=1, max_length=16, title=u'Код класса обслуживания')
    names = MLNames(db_column='names', title=u'Наименование класса обслуживания', required=True)
    weight = Int(db_column="weight", title=u"Вес", required=True)
    classification_level = Choice(db_column='classification_level', title=u'Квалификационный уровень',
                                  source='service_class_classification_levels', required=True)


class IAirlineServiceClass(Interface):
    u"""Класс обслуживания авиакомпании"""

    airline_sc_id = Int(db_column='airline_sc_id', primary_key=True, required=True, readonly=True)
    airline = Choice(db_column='airline_id', title=u'Авиакомпания', source='airlines', required=True)
    skyteam_sc = Choice(db_column='skyteam_sc_id', title=u'Класс обслуживания', source='skyteam_service_classes', required=True)


class IComment(Interface):
    u"""Комментарий"""

    comment_id = Int(db_column='comment_id', primary_key=True, required=True, readonly=True)
    names = MLNames(db_column='names', title=u'Комментарий', required=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)


class IServiceClassesLimit(Interface):
    u"""Ограничения для классов обслуживания"""
    service_classes_limit_id = Int(db_column='service_classes_limit_id', primary_key=True, required=True, readonly=True)
    airline_sc = Choice(db_column='airline_sc_id', title=u'Класс обслуживания авиакомпании', source='airline_service_classes', required=True)
    pair = Choice(db_column='pair_id', title=u'Пары', source='pairs', required=True)


class IBonusRoute(Interface):
    u"""Премиальный маршрут"""

    bonus_route_id = Int(db_column='bonus_route_id', primary_key=True, required=True, readonly=True)
    code = TextLine(db_column='code', title=u'Код', min_length=1, max_length=9, required=True)
    zone_from = Choice(db_column='zone_from', title=u'Зона вылета', source='redemption_zones', required=True)
    zone_via = Choice(db_column='zone_via', title=u'Зона пересадки', source='redemption_zones', required=False)
    zone_to = Choice(db_column='zone_to', title=u'Зона прилёта', source='redemption_zones', required=True)
    carrier = Choice(db_column='carrier', title=u'Перевозчик', source='carriers', required=True)


class IAward(Interface):
    u"""Премия"""

    award_id = Int(db_column='award_id', primary_key=True, required=True, readonly=True)
    type = Choice(db_column='type', title=u'Тип', source='award_types', required=True)
    service_classes_1 = Choice(db_column='service_classes_1', title=u'Класс обслуживания 1', source='skyteam_service_classes', required=True)
    service_classes_2 = Choice(db_column='service_classes_2', title=u'Класс обслуживания 2', source='skyteam_service_classes', required=False)
    award_value = Int(db_column='award_value', title=u'Значение премии', required=True)
    route = Choice(db_column='route', title=u'Премиальный маршрут', source='bonus_routes', required=True)
    comment = Choice(db_column='comment', title=u'Комментарий', source='comments', required=False)


class ITierLevelFactor(Interface):
    u"""Коэффициенты статуса участника"""

    tier_level_factor_id = Int(db_column='tier_level_factor_id', primary_key=True, required=True, readonly=True)
    airline = Choice(db_column='airline', title=u'Авиакомпания', source='airlines', required=True)
    tier_level = Choice(db_column='tier_level', title=u'Статус участника', source='tier_levels', required=True)
    factor = Float(db_column='factor', title=u'Коэффициент', required=True)


class ISpecialOffer(Interface):
    u"""Спецпредложения"""

    offer_id = Int(db_column='offer_id', title=u'Id', primary_key=True, required=True, readonly=True)
    partner = Choice(db_column='partner_id', title=u'Партнёр', source='partners', required=True)
    names = MLNames(db_column='names', title=u'Название', required=True)
    begin_date = Datetime(db_column='begin_date', title=u'Дата/время начала', required=False)
    end_date = Datetime(db_column='end_date', title=u'Дата/время окончания', required=False)
    status = Choice(db_column='status', title=u'Статус', source='special_offers_statuses', required=True)
    offer_description = MLText(db_column='offer_description', title=u'Описание', required=False)
    offer_url = MLNames(db_column='offer_url', title=u'Ссылка на спецпредложение', required=True)
    ui_languages = TextLineList(db_column='ui_languages', title=u'Языки интерфейса', required=False, separator=',')


class ILoyaltyProgram(Interface):
    u"""Программа лояльности"""

    loyalty_program_id = Int(db_column='loyalty_program_id', primary_key=True, required=True, readonly=True)
    name = TextLine(db_column='name', title=u'Наименование программы лояльности', required=True, min_length=1,
                    max_length=128)
    siebel_id = CodeTextLine(db_column='siebel_id', title=u'Идентификатор в системе Siebel', min_length=1, max_length=4, required=False)
    sabre_id = CodeTextLine(db_column='sabre_id', title=u'код Sabre', min_length=2, max_length=2, required=False)


class IProfessionalArea(Interface):
    u"""Род деятельности"""

    professional_area_id = Int(db_column='professional_area_id', primary_key=True, required=True, readonly=True)
    names = MLNames(db_column='names', title=u'Наименование рода деятельности', required=True)


class ILanguage(Interface):
    u"""Язык"""

    alpha2_code = UppercaseTextLine(db_column='alpha2_code', primary_key=True, required=True, min_length=2, max_length=2, title=u'Код языка ISO 3166-1 alpha-2')
    alpha3_code = UppercaseTextLine(db_column='alpha3_code', required=True, min_length=3, max_length=3, title=u'Код языка ISO 3166-1 alpha-3')
    selector_code = UppercaseTextLine(db_column='selector_code', required=True, min_length=1, max_length=3, title=u'Сокращение для переключателя языков')
    names = MLNames(db_column='names', title=u'Наименование языка', required=True)
    is_active = Bool(db_column='is_active', title=u'Активен', default=True, required=False)


class ILocalization(Interface):
    u"""Локализация"""

    code = UppercaseTextLine(db_column='code', primary_key=True, required=True, min_length=2, max_length=2, title=u'Код локализации')
    names = MLNames(db_column='names', title=u'Наименование локализации', required=True)
    default_language = Choice(db_column='default_language', source='languages', title=u'Основной язык локализации', required=True)
    allowed_languages = TextLineList(db_column='allowed_languages', title=u'Доступные языки локализации', required=True, separator=',')
    is_active = Bool(db_column='is_active', title=u'Активен', default=True, required=False)


class ISpecialMeal(Interface):
    u"""Спецпитание"""

    code = UppercaseTextLine(db_column='code', primary_key=True, required=True, min_length=4, max_length=4, title=u'Код специального питания')
    names = MLNames(db_column='names', title=u'Наименование специального питания', required=True)


class IAncillaryServicesGroup(Interface):
    u"""Группа дополнительных услуг"""

    ancillary_services_group_id = Int(db_column='ancillary_services_group_id', primary_key=True, required=True, readonly=True)
    ordinal_number = Int(db_column='ordinal_number', title=u'Порядковый номер', required=True)
    names = MLNames(db_column='names', title=u'Название', required=True)
    filename = FilenameField(db_column='filename', title=u'Название файла', required=True, min_length=3, max_length=64)
    message = MLText(db_column='message', title=u'Сообщение', required=False)

class IRFICCode(Interface):
    u"""Код RFIC"""

    code = UppercaseTextLine(db_column='code', primary_key=True, required=True, min_length=1, max_length=1, title=u'Код RFIC')
    names = MLNames(db_column='names', title=u'Название', required=True)


class IAncillaryService(Interface):
    u"""Дополнительная услуга"""

    rfic = Choice(db_column='rfic', title=u'RFIC', source='rfic_codes', required=True, primary_key=True)
    code = UppercaseTextLine(db_column='code', primary_key=True, required=True, min_length=3, max_length=3, title=u'RFISC')
    ancillary_services_group = Choice(db_column='ancillary_services_group_id', title=u'Группа дополнительных услуг', source='ancillary_services_groups', required=True)
    names = MLNames(db_column='names', title=u'Названия', required=True)
    descriptions = MLText(db_column='descriptions', title=u'Описания', required=False)
    doc_prefix = MLText(db_column='doc_prefix', title=u'doc_prefix', required=False)
    emd_message = MLText(db_column='emd_message', title=u'emd_message', required=False)


class IAncillaryServiceStatus(Interface):
    u"""Статус дополнительной услуги"""

    ancillary_service_status_id = Int(db_column='ancillary_service_status_id', primary_key=True, required=True, readonly=True)
    code = UppercaseTextLine(db_column='code', required=True, min_length=2, max_length=2, title=u'Код')
    rfic = Choice(db_column='rfic', title=u'RFIC', source='rfic_codes', required=False)
    rfisc = CodeTextLine(db_column='rfisc', required=False, min_length=3, max_length=3, title=u'RFISC')
    names = MLNames(db_column='names', title=u'Названия', required=True)


class IAdditionalInfo(Interface):
    u"""Дополнительная информация"""

    additional_info_id = Int(db_column='additional_info_id', primary_key=True, required=True, readonly=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    created = Date(db_column='created', title=u'Дата создания', required=False, defaultFactory=date.today, format='%Y-%m-%d')
    names = MLNames(db_column='names', title=u'Сообщение', required=True)
    condition = JSONConditionField(db_column='condition', title=u'Условия отображения', required=True, default=u'[]')


class IVatRate(Interface):
    u"""Хранение информации о ставке НДС для различных типов дополнительных услуг"""
    vat_rate_id = Int(db_column='id', title=u'Id', primary_key=True)
    rfic = UppercaseTextLine(db_column='rfic', title=u'Код RFIC', required=True, min_length=1, max_length=1)
    rfisc = UppercaseTextLine(db_column='rfisc', title=u'Код RFISC', required=True, min_length=3, max_length=3)
    start_date = Datetime(db_column='start_date', title=u'Дата и время начала действия ставки НДС (UTC)', format='%d.%m.%Y %H:%M %Z%z', required=False)
    stop_date = Datetime(db_column='stop_date', title=u'Дата и время завершения действия ставки НДС (UTC)', format='%d.%m.%Y %H:%M %Z%z', required=False)
    rate = Float(db_column='rate', title=u'Ставка НДС', min=0.0, max=100.0, required=True)

    @zope.interface.invariant
    def check_dates(self):
        start_date = self.start_date
        stop_date = self.stop_date
        codes = (self.rfic, self.rfisc)
        for vat_rate in getV('vat_rates'):
            if (vat_rate.rfic, vat_rate.rfisc) == codes:
                other_start_date = vat_rate.start_date
                other_stop_date = vat_rate.stop_date
                if self.vat_rate_id != vat_rate.vat_rate_id and check_overlapping(start_date, stop_date, vat_rate.start_date, vat_rate.stop_date):
                    raise zope.interface.exceptions.Invalid("Dates should not overlap: {} overlap with {}".format(
                        (str(start_date), str(stop_date)), (str(other_start_date), str(other_stop_date))))


def check_overlapping(start_date, stop_date, other_start_date, other_stop_date):
    start_date = start_date or datetime.min
    stop_date = stop_date or datetime.max
    other_start_date = other_start_date or datetime.min
    other_stop_date = other_stop_date or datetime.max

    if stop_date < other_start_date or start_date > other_stop_date:
        return False
    else:
        return True


class IMealRule(Interface):
    u"""Правила выбора питания"""

    meal_rule_id = Int(db_column='meal_rule_id', title=u'ID', primary_key=True, required=True)
    date_from = Date(db_column='date_from', title=u'Дата вылета от', required=False, format='%Y-%m-%d')
    date_to = Date(db_column='date_to', title=u'Дата вылета до', required=False, format='%Y-%m-%d')
    number = NumbersListField(db_column='number', title=u'Номера рейсов', required=False)
    airline = VocabList(db_column='airline', title=u'Авиалинии', source='airlines', required=False)
    origin = VocabList(db_column='origin', title=u'Аэропорты вылета', source='airports', required=False)
    destination = VocabList(db_column='destination', title=u'Аэропорты прибытия', source='airports', required=False)
    booking_class = VocabList(db_column='booking_class', title=u'Классы бронирования', source='booking_classes', required=False)
    special_meal = VocabList(db_column='special_meal', title=u'Спецпитание', source='special_meal', required=False)


class IMealTimelimit(Interface):
    u"""Ограничение времени выбора питания"""

    meal_timelimit_id = Int(db_column='meal_timelimit_id', title=u'ID', primary_key=True, required=True)
    origin = VocabList(db_column='origin', title=u'Аэропорты вылета', source='airports', required=False)
    special_meal = VocabList(db_column='special_meal', title=u'Спецпитание', source='special_meal', required=False)
    timelimit = Int(db_column='timelimit', title=u'Часы до вылета', required=True, min=0)


class ICharityFund(Interface):
    u"""Благотворительные фонды"""

    charity_fund_id = Int(db_column='charity_funds_id', title=u'ID', primary_key=True, required=True)
    charity_id = LoyaltyField(db_column='charity_id', title=u'Номер в системе лояльности', required=True)
    tag = TextLine(db_column='tag', title=u'Теги', required=True)
    names = MLNames(db_column='names', title=u'Название фонда', required=True)
    logo_url = MLNames(db_column='logo_url', title=u'Ссылка на логотип', required=True)
    image_url = MLNames(db_column='image_url', title=u'Ссылка на изображение', required=False)
    charity_short_description = MLNames(db_column='charity_short_description', title=u'Краткое описание фонда', required=True)
    charity_description = MLText(db_column='charity_description', title=u'Описание фонда', required=True)
    url = MLNames(db_column='url', title=u'Ссылка на сайт фонда', required=True)
    transfer_conditions = MLText(db_column='transfer_conditions', title=u'Условия перевода', required=True)
    contacts = MLText(db_column='contacts', title=u'Контакты', required=False)
    news_url = MLNames(db_column='news_url', title=u'Ссылка «Новости фонда» на ОС', required=False)
    news_mv_url = MLNames(db_column='news_mv_url', title=u'Ссылка «Новости фонда» на МС', required=False)
    donate_miles_url = TextLine(db_column='donate_miles_url', title=u'Ссылка «Пожертвовать мили» на ОС', required=True)
    donate_miles_mv_url = TextLine(db_column='donate_miles_mv_url', title=u'Ссылка «Пожертвовать мили» на МС', required=True)
    stats_charity_funds_url = TextLine(db_column='stats_charity_funds_url', title=u'Ссылка на файл «Статистика фонда»', required=True)
    rss_url = TextLine(db_column='rss_url', title=u'RSS-сервис новостей фонда', required=False)
    status = Choice(db_column='status', title=u'Статус', source='publication_statuses', required=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    create_date = Date(db_column='create_date', title=u'Дата создания', required=False, defaultFactory=date.today, format='%Y-%m-%d')
    modify_date = Date(db_column='modify_date', title=u'Дата изменения', required=False, defaultFactory=date.today, format='%Y-%m-%d')
