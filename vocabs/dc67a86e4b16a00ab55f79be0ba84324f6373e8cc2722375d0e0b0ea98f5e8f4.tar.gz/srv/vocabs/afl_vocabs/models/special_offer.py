# -*- coding: utf-8 -*-
from datetime import datetime
from zope.component import provideAdapter
from zope.interface import implements
from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.vocabulary.simple import SimpleVocabulary
from zope.schema.vocabulary import SimpleTerm
from models.interfaces import ISpecialOffer

from pyramid.registry import makeVocabularyRegisterable
from rx.utils.json import IPrimitive
from i18n import _


class SpecialOfferStatusVocabulary(SimpleVocabulary):
    u"""Список статусов спецпредложений"""

    items = (
        ('P',   _(u'Опубликовано')),
        ('U',   _(u'Не опубликовано'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b)
                                 for a, b in cls.items])

    makeVocabularyRegisterable('special_offers_statuses')


class SpecialOffer(MutableElement, TitleCapable):
    u"""Спецпредложения"""

    def as_primitive(self):
        d = {'class': self.__class__.__name__}

        for name in ISpecialOffer:
            if name in ('begin_date', 'end_date'):
                val = getattr(self, name)
                if isinstance(val, datetime):
                    val = val.strftime("%d.%m.%Y %H:%M:%S")
                d[name] = val
            elif name in ("partner", "status",):
                d[name] = self.p_choice_tokens[name]
            else:
                d[name] = getattr(self, name)

        return d

    implements(ISpecialOffer)
    p_table_name = 'special_offers'


provideAdapter(lambda special_offer: special_offer.as_primitive(),
               [ISpecialOffer], IPrimitive)


class SpecialOfferVocabulary(PersistentVocabulary):
    objectC = SpecialOffer
    makeVocabularyRegisterable('special_offers')
