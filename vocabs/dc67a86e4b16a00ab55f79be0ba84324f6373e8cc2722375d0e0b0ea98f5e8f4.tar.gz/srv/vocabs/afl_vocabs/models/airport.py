# -*- coding: utf-8 -*-
"""
$Id: airport.py 24549 2017-04-25 16:07:26Z adobrov $
"""

from zope.interface import implements
from zope.component import adapts, provideAdapter
from zope.schema.interfaces import ITokenizedTerm

from pyramid.vocabulary import getV
from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import (
    makeVocabularyRegisterable, makeAdapterRegisterable,
    makeIndexerRegisterable
)
from pyramid.vocabulary.indexer import VocabularyIndexer
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.ormlite.vocabulary.rdb import RDBVocabulary
from pyramid.vocabulary.adapters import BaseTermAdapter
from pyramid.vocabulary.factory import VocabularyFactory
from rx.utils.json import IPrimitive

from models.base import MvccVocabularyBase
from models.interfaces import IAirportTerminal, IAirport
from models.ml import MLTitleCapable
from models.indexer import Indexer, getI


class Airport2TermAdapter(BaseTermAdapter):
    adapts(IAirport)
    tokenAttr = ('airport_id',)
    titleAttr = 'fullTitle'

    makeAdapterRegisterable()


# ActiveRecord -- потому что вокаб -- MVCC. 
# Использовать MutableElement нельзя, т.к. он -- Persistent,
# и при возникновении новых ссылок на объект
# произойдёт попытка сохранить его,
# но в MVCC-вокабах объекты загружаются в preload,
# т.е. в другой транзакции
class Airport(ActiveRecord, MLTitleCapable):
    u"""Аэропорт"""

    implements(IAirport)
    p_table_name = 'airports'

    @property
    def fullTitle(self):
        return u'%s, %s' % (self.shortTitle, self.title)

    @property
    def shortTitle(self):
        return self.iata if self.iata else '---'

    def get_terminals(self):
        vocab = getV('airport_terminals')
        return [ vocab[terminal_id] for terminal_id in getI('terminals_by_airport_idx')(self.airport_id) ]

    def set_terminals(self, terminals):
        if terminals is None:
            terminals = []
        input_ids = set([ ITokenizedTerm(t).token for t in terminals ])
        idx = getI('terminals_by_airport_idx')
        removed_ids = set([ terminal_id for terminal_id in idx(self.airport_id) if terminal_id not in input_ids ])
        vocab = getV('airport_terminals')
        for t_id in removed_ids:
            del vocab[t_id]
        for t in terminals:
            t.airport_id = self.airport_id
            vocab.add(t)

    terminals = property(get_terminals, set_terminals)

    # оптимизированная имплементация, в 4 раза быстрее универсального record_to_primitive
    def as_primitive(self):
        #d = record_to_primitive(self)
        d = {'class': self.__class__.__name__}
        for name in IAirport:
            if name not in ('city', 'afl_redemption_zone', 'skyteam_redemption_zone', 'terminals'):
                d[name] = getattr(self, name)
        d['city'] = self.p_choice_tokens['city'] #self.city.city_id
        d['afl_redemption_zone'] = self.p_choice_tokens['afl_redemption_zone']
        d['skyteam_redemption_zone'] = self.p_choice_tokens['skyteam_redemption_zone']
        d['terminals'] = [ dict(code=t.code, names=t.names) for t in self.terminals ]
        return d

provideAdapter(lambda airport: airport.as_primitive(),
               [IAirport], IPrimitive)


class AirportsVocabulary(MvccVocabularyBase):
    objectC = Airport
    makeVocabularyRegisterable('airports')


#class AirportsByIATAIndexer(VocabularyIndexer):
#    vocabulary = "airports"
#
#    def objectIndex(self, ob):
#        return ob.iata
#
#    def contextIndex(self, iata):
#        return iata
#
#    makeIndexerRegisterable('airports_by_iata_idx')


class AirportTerminal(MutableElement):
    u"""Терминал аэропорта"""

    implements(IAirportTerminal)
    p_table_name = 'airport_terminals'

    def __unicode__(self):
        return self.code


class AirportTerminalsVocabulary(PersistentVocabulary):
    objectC = AirportTerminal
    makeVocabularyRegisterable('airport_terminals')


class TerminalsByAirport(Indexer):
    name = 'terminals_by_airport_idx'
    parent_vocab = 'airport_terminals'

    def key(self, ob):
        return str(ob.airport_id)


class AFLAirportsVocabulary(RDBVocabulary):
    objectC = Airport

    def __init__(self, *args, **kwargs):
        ids = set([0])
        for p in getV('pairs'):
            ids.add(p.airport_from.airport_id)
            ids.add(p.airport_to.airport_id)

        self.select = u"select * from airports where airport_id in %s" % (tuple(ids), )
        super(AFLAirportsVocabulary, self).__init__(*args, **kwargs)

    makeVocabularyRegisterable('afl_airports', factory=VocabularyFactory)
