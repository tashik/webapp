# -*- coding: utf-8 -*-
"""
$Id$
"""
import json
from datetime import date

from zope.interface import implements
from zope.component import provideAdapter

from rx.utils.json import IPrimitive, as_primitive

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable

from models.ml import MLTitleCapable
from models.interfaces import IAdditionalInfo


class AdditionalInfo(MutableElement, MLTitleCapable):
    u"""Группа дополнительных услуг"""

    implements(IAdditionalInfo)
    p_table_name = 'additional_info'

    def as_primitive(self):
        d = {'class': self.__class__.__name__}
        for name in IAdditionalInfo:
            d[name] = getattr(self, name)
        if isinstance(d['created'], date):
            d['created'] = d['created'].strftime('%Y-%m-%d')
        d['condition'] = json.loads(d['condition'])
        return d

provideAdapter(lambda info: info.as_primitive(),
               [IAdditionalInfo], IPrimitive)


class AdditionalInfoVocabulary(PersistentVocabulary):
    objectC = AdditionalInfo
    makeVocabularyRegisterable('additional_info')
