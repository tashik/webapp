# -*- coding: utf-8 -*-

"""
$Id: $
"""


from zope.interface.declarations import implements
from zope.schema.vocabulary import SimpleTerm

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import(
    makeVocabularyRegisterable, makeIndexerRegisterable
)
from pyramid.vocabulary.indexer import VocabularyIndexer
from pyramid.vocabulary.simple import SimpleVocabulary

from models.interfaces import IAirline, IAircraftType
from models.ml import MLTitleCapable

from i18n import _


class Airline(MutableElement, MLTitleCapable):
    u"""Аэропорт"""

    implements(IAirline)
    p_table_name = 'airlines'


class AirlinesVocabulary(PersistentVocabulary):
    objectC = Airline
    makeVocabularyRegisterable('airlines')


#class AirlinesByIATAIndexer(VocabularyIndexer):
#    vocabulary = "airlines"
#
#    def objectIndex(self, ob):
#        return ob.iata
#
#    def contextIndex(self, iata):
#        return iata
#
#    makeIndexerRegisterable('airlines_by_iata_idx')


class MilesLimitationsVocabulary(SimpleVocabulary):
    u"""Ограничения для минимального количества миль."""

    items = (
        ('N', _(u'Нет минимального количества')),
        ('A', _(u'Минимальное количество на всех рейсах')),
        ('I', _(u'Минимальное количество только на международных рейсах'))
    )

    def __new__(cls, *args, **kwargs):
        return SimpleVocabulary([SimpleTerm(SimpleTerm(a, a, b), a, b) for a, b in cls.items])

    makeVocabularyRegisterable('miles_limitations')


class AircraftType(MutableElement, MLTitleCapable):
    u"""Тип воздушного судна"""

    implements(IAircraftType)
    p_table_name = 'aircraft_types'

class AircraftTypesVocabulary(PersistentVocabulary):
    objectC = AircraftType
    makeVocabularyRegisterable('aircraft_types')
