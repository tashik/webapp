# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements

from pyramid.ormlite.cache import MutableElement
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.registry import makeVocabularyRegisterable

from models.interfaces import ILanguage, ILocalization
from models.ml import MLTitleCapable


class Language(MutableElement, MLTitleCapable):
    u"""Язык"""

    implements(ILanguage)
    p_table_name = 'languages'


class LanguageVocabulary(PersistentVocabulary):
    objectC = Language
    makeVocabularyRegisterable('languages')


class Localization(MutableElement, MLTitleCapable):
    u"""Локализация"""

    implements(ILocalization)
    p_table_name = 'localizations'


class LocalizationVocabulary(PersistentVocabulary):
    objectC = Localization
    makeVocabularyRegisterable('localizations')
