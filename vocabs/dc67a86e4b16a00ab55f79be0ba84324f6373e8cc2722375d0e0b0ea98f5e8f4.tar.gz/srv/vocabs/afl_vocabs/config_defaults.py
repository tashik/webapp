# -*- coding: utf-8 -*-

import os
import sys
import logging
import pyramid

import socket
socket.setdefaulttimeout(120)

USING_PDB = bool(sys.gettrace())

SERVER_PORT = 9880          # Set real application server port
SERVER_HOST = '127.0.0.1'   # Set real application server host
COOKIE_DOMAIN = None

VIRTUAL_BASE = '/vocabs'    # Use for application environment with virtual path
                            # like http://host/path_to_app
                            # e.g.: VIRTUAL_BASE = '/path_to_app'

EXT_SERVER_URL = 'http://127.0.0.1:6380'
VIRTUAL_STATIC_BASE = VIRTUAL_BASE

LK_URL = 'http://127.0.0.1:7080/personal'
#SHARED_STATIC_BASE = 'http://www.aeroflot.ru/static'

COMMON_STATIC_URL = '//www.aeroflot.ru/cms/sites/all/themes/aeroflot/common'
SITE_HOST = 'www.aeroflot.ru'

APPDIR = os.path.dirname(__file__)
PYRAMIDDIR = os.path.dirname(pyramid.__file__)
TEMPLATEDIR = [APPDIR + '/templates', PYRAMIDDIR + '/ui/templates']
LOG_LEVEL = logging.DEBUG

LOGDIR = APPDIR + '/log'
ERRORDIR = APPDIR + '/log/errors'
SESSDIR = APPDIR + '/session'
STATICDIR = APPDIR + '/static'
PIDDIR = APPDIR + '/pid'
DATADIR = APPDIR + '/data'

CSS_BASE_PATH = '/static/style'
JS_BASE_PATH = '/static/js'

CSS_MAIN_FILE = 'style.css'

COMPANY_NAME = u'Аэрофлот – Российские авиалинии' # Set real company name
SYSTEM_NAME = u'Система синхронизации справочников'    # Set real application name
COPYRIGHT_STRING = '&copy; 2012'
COPYRIGHT_NAME = 'Аэрофлот'
FAVICONFILE = STATICDIR + '/favicon.ico'

ENCODING = 'utf-8'

DEFAULT_DB_CON = 'psycopgcon'
DEFAULT_DB_TYPE = 'pg'

POSTGRES_DSN = NotImplemented

ADMIN_EMAIL = []
SMTP_FROM = 'vocabs@localhost'
SMTP_SERVER = 'klaus-s.com.spb.ru'
SMTP_PORT = 25

#Обратный адрес информационных сообщений для пользователей системы
SYSTEM_USER_EMAIL_NAME = u'Аэрофлот'
SYSTEM_USER_EMAIL_ADDRESS = u'noreply@aeroflot.ru'

APP_COOKIE = 'VOCABS'
DEBUG_COOKIE = '_DEBUG'
DEBUG = False
DEFAULT_PAGE_SIZE = 20

DISABLE_JS = False      # Set to disable all javascripts on rendered pages
# Поддержка многоязычности ---------------------------------------------------

ENABLE_I18N = True
APP_I18N_DOMAIN = 'messages'
LOCALES_DIR = APPDIR + '/locales'
KNOWN_LANGUAGES = ['ru', 'en', 'de', 'fr', 'es', 'it', 'zh', 'ko', 'ja']
FALLBACK_LANGUAGES = KNOWN_LANGUAGES

# Компоненты, используемые в приложении --------------------------------------

INCLUDE_CONTRACTORS = False  # Контрагенты
INCLUDE_FILES       = False  # Файлы
INCLUDE_PERSONS     = False  # Персоналии
INCLUDE_EMPLOYEES   = False  # Сотрудники
INCLUDE_LOCATIONS   = False  # Адреса
INCLUDE_EMPLOYEES = INCLUDE_CONTRACTORS and INCLUDE_PERSONS


# Single Sign-On -------------------------------------------------------------
SSO_CLIENT_NAME = 'vocabs'
SSO_PASSWORD = NotImplemented
SSO_SERVER = '127.0.0.1:7080'
SSO_LOGIN_URL = 'http://%s/personal/login' % SSO_SERVER
SSO_LOGOUT_URL = 'http://%s/personal/logout' % SSO_SERVER
SSO_VALIDATE_URL = 'http://%s/personal/services/sso/%s' % (SSO_SERVER, SSO_CLIENT_NAME)

PBUS_URL = None  # 'http://127.0.0.1:8390'
PBUS_MY_NAME = 'vocabs'
PBUS_PASSWORD = None
PBUS_CALLBACK_HOST = '127.0.0.1'
PBUS_CALLBACK_PASSWORD = NotImplemented
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_TOPICS = {
    'vocabs': 'vocabs',
}

# CSV import and export ------------------------------------------------------
ENABLE_CSV_IMPORT = False  # включить импорт из CSV
CSV_IMPORT_ENCODING = 'utf-8'
ENABLE_CSV_EXPORT = True   # включить экспорт в CSV
CSV_EXPORT_ENCODING = 'utf-8'


DEFAULT_ALLOW_ROLES_ADMINS = ['admin', 'vocabs&banners_admin']
