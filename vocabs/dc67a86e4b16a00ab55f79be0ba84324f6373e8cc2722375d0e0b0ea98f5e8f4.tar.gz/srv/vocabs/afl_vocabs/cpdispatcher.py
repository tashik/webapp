# -*- coding: utf-8 -*-

"""
$Id: cpdispatcher.py 37 2012-05-30 11:45:43Z achunaev $
"""

import cherrypy
from pyramid.app import cpdispatcher as _cpdispatcher
from pyramid.utils import Config as config


# копия из пирамиды, для системы с реальным использованием VIRTUAL_BASE
# не монтируем контроллеры на /
def _getMountConfig(main_dispatcher_factory):
    u"""Создает конфигурацию для монтирования"""

    mount_cfg = dict()
    
    mount_cfg.update({
        config.VIRTUAL_BASE: {
            'request.dispatch': main_dispatcher_factory(
                prefix=config.VIRTUAL_BASE),
            'tools.proxy.on': True,
        }
    })

    # Для диспетчера статических файлов ----------------------------------------
    _cpdispatcher._mountStaticPath(mount_cfg)
    if config.VIRTUAL_STATIC_BASE:
        _cpdispatcher._mountStaticPath(mount_cfg, config.VIRTUAL_STATIC_BASE)
        
    return mount_cfg


def _getMainDispatcher(prefix=None):
    u"""Создает диспетчер и регистрирует маршруты и соответствующие
    им контроллеры.
    """

    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.mapper.prefix = prefix

    from ui.root import RootPage, LoginPage
    LoginPage()._connectToDispatcher(dispatcher)
    RootPage()._connectToDispatcher(dispatcher)


    from ui.geo import WorldRegionPage, CountryPage, CityPage
    WorldRegionPage()._connectToDispatcher(dispatcher)
    CountryPage()._connectToDispatcher(dispatcher)
    CityPage()._connectToDispatcher(dispatcher)

    from ui.bonus import RedemptionZonePage, TierLevelPage, TierLevelFactorPage
    from ui.route import PairPage, WrongRoutePage
    RedemptionZonePage()._connectToDispatcher(dispatcher)
    TierLevelPage()._connectToDispatcher(dispatcher)
    TierLevelFactorPage()._connectToDispatcher(dispatcher)
    PairPage()._connectToDispatcher(dispatcher)
    WrongRoutePage()._connectToDispatcher(dispatcher)

    from ui.office import OfficePage, OfficeCategoryPage
    OfficePage()._connectToDispatcher(dispatcher)
    OfficeCategoryPage()._connectToDispatcher(dispatcher)

    from ui.airport import AirportPage
    AirportPage()._connectToDispatcher(dispatcher)

    import ui.airport
    ui.airport.AirportPage()._connectToDispatcher(dispatcher)

    from ui.air import AirlinePage, AircraftTypePage
    AirlinePage()._connectToDispatcher(dispatcher)
    AircraftTypePage()._connectToDispatcher(dispatcher)

    from ui.currency import CurrencyPage
    CurrencyPage()._connectToDispatcher(dispatcher)

    from ui.bonus import TariffGroupPage
    TariffGroupPage()._connectToDispatcher(dispatcher)

    from ui.bonus import AirlineTariffGroupPage, BookingClassPage
    AirlineTariffGroupPage()._connectToDispatcher(dispatcher)
    BookingClassPage()._connectToDispatcher(dispatcher)

    from ui.bonus import BonusRoutePage, AwardsPage
    BonusRoutePage()._connectToDispatcher(dispatcher)
    AwardsPage()._connectToDispatcher(dispatcher)

    from ui.partner import PartnerCategoryPage, PartnerPage, PartnerOfficePage, PartnerAwardConditionPage
    PartnerCategoryPage()._connectToDispatcher(dispatcher)
    PartnerPage()._connectToDispatcher(dispatcher)
    PartnerOfficePage()._connectToDispatcher(dispatcher)
    PartnerAwardConditionPage()._connectToDispatcher(dispatcher)

    from ui.member import LoyaltyProgramPage, ProfessionalAreaPage
    LoyaltyProgramPage()._connectToDispatcher(dispatcher)
    ProfessionalAreaPage()._connectToDispatcher(dispatcher)

    from ui.service_classes import SkyTeamServiceClassPage, AirlineServiceClassPage, CommentClassPage, ServiceClassesLimitPage
    SkyTeamServiceClassPage()._connectToDispatcher(dispatcher)
    AirlineServiceClassPage()._connectToDispatcher(dispatcher)
    CommentClassPage()._connectToDispatcher(dispatcher)
    ServiceClassesLimitPage()._connectToDispatcher(dispatcher)

    from ui.special_offer import SpecialOfferPage
    SpecialOfferPage()._connectToDispatcher(dispatcher)

    from ui.lang import LanguagePage, LocalizationPage
    LanguagePage()._connectToDispatcher(dispatcher)
    LocalizationPage()._connectToDispatcher(dispatcher)

    from ui.ancillary_services import AncillaryServicesGroupPage, RFICCodePage, AncillaryServicePage, AncillaryServiceStatusPage, VatRatesPage
    AncillaryServicesGroupPage()._connectToDispatcher(dispatcher)
    RFICCodePage()._connectToDispatcher(dispatcher)
    AncillaryServicePage()._connectToDispatcher(dispatcher)
    AncillaryServiceStatusPage()._connectToDispatcher(dispatcher)
    VatRatesPage()._connectToDispatcher(dispatcher)

    from ui.additional_info import AdditionalInfoPage
    AdditionalInfoPage()._connectToDispatcher(dispatcher)

    from ui.meal import SpecialMealPage, MealTypePage, MealRulePage, MealTimelimitPage
    SpecialMealPage()._connectToDispatcher(dispatcher)
    MealTypePage()._connectToDispatcher(dispatcher)
    MealRulePage()._connectToDispatcher(dispatcher)
    MealTimelimitPage()._connectToDispatcher(dispatcher)

    from ui.charity_funds import CharityFundPage
    CharityFundPage()._connectToDispatcher(dispatcher)

    from notify.query import QueryService
    QueryService()._connectToDispatcher(dispatcher)

    from services.heartbeat import HeartbeatService
    HeartbeatService()._connectToDispatcher(dispatcher)
    
    return dispatcher

# Конфигурация диспетчеров и локальные параметры CherryPy ----------------------

mount_cfg = _getMountConfig(_getMainDispatcher)
from access import auth_paths
mount_cfg.update(auth_paths())
_cpdispatcher._mountStaticPath(mount_cfg, config.VIRTUAL_BASE)
