# -*- coding: utf-8 -*-

"""
$Id: ssods.py 56 2012-06-15 11:54:44Z anovgorodov $
"""
from datetime import datetime
import cherrypy
from lxml import etree
from zope.interface import implements
from zope.component import getUtility

from pyramid.auth.exc import NoCredentialsError
from pyramid.auth.interfaces import IAuthenticationDataSource,\
    ICredentialsDataSource, IAuthenticator, IPrincipal
from rx.sso.ssoclient import SSOClient
import config


class SSOUser(object):
    implements(IPrincipal)
    
    def __init__(self, user_id, email, first_name, last_name, role, display_name):
        self.identity = int(user_id)
        self.email = email
        self.first_name = first_name
        self.role = role
        self.last_name = last_name
        self.display_name = display_name

    @classmethod
    def from_sso(cls, e):
        user = cls(e.attrib['userId'], e.attrib.get('email'),
                   e.attrib.get('firstName'), e.attrib.get('lastName'), e.attrib.get('role'),
                   e.attrib.get('displayName'))
        return user


class SSOAuthenticationDS(object):
    implements(IAuthenticationDataSource)

    # Аргумент _sso_client нужен для тестирования
    def __init__(self, _sso_client=None):
        service_factory = _sso_client or SSOClient
        self.sso = service_factory(config.SSO_PASSWORD, config.SSO_VALIDATE_URL)

    def authenticate(self, credentials):
        if not credentials:
            raise NoCredentialsError()
        assert isinstance(credentials, str)

        text = self.sso.call(credential_id=credentials)
        if not text:
            # delete cookie
            try:
                cherrypy.response.cookie['sso_session_id'].value = ''
                cherrypy.response.cookie['sso_session_id']['path'] = cherrypy.request.cookie['path']
                if 'domain' in cherrypy.request.cookie:
                    cherrypy.response.cookie['sso_session_id']['domain'] = cherrypy.request.cookie['domain']
                cherrypy.response.cookie['sso_session_id']['expires'] = 0
            except KeyError:
                pass
            raise NoCredentialsError()
        return text


class SSOCredentialsDS(object):
    """CherryPy request params as Data source for credentials data"""
    implements(ICredentialsDataSource)

    # Аргумент _params используется при тестировании
    def getCredentials(self, _params=None):
        cookie = cherrypy.request.cookie
        try:
            sso_session_id = cookie['sso_session_id'].value
        except KeyError:
            return None  # не нашли нужную cookie
        return sso_session_id


class Authenticator(object):
    """Authentication service"""
    implements(IAuthenticator)

    def authenticate(self, force=False, include_personal_data=False):
        """Authenticates context. If 'force', clears current authentication
        status and forces authentication process.
        """
        cred_ds = getUtility(ICredentialsDataSource)
        auth_ds = getUtility(IAuthenticationDataSource)

        try:
            sso_session_id = cherrypy.request.cookie['sso_session_id'].value
        except KeyError:
            sso_session_id = None
        # кэширование результатов SSO
        sso_revalidate = cherrypy.session.get('sso_revalidate')

        do_call_sso = (force or
                       not sso_revalidate or
                       datetime.utcnow() >= sso_revalidate or
                       not sso_session_id or
                       sso_session_id != cherrypy.session.get('from_sso_session_id'))

        if not do_call_sso:
            sso_text = cherrypy.session['sso_text']
            user = SSOUser.from_sso(etree.fromstring(sso_text))
        else:
            sso_text = auth_ds.authenticate(cred_ds.getCredentials())
            e = etree.fromstring(sso_text)
            user = SSOUser.from_sso(e)
            cherrypy.session['sso_text'] = sso_text
            cherrypy.session['from_sso_session_id'] = sso_session_id
            cherrypy.session['sso_revalidate'] = datetime.strptime(e.attrib['revalidate'], '%Y-%m-%dT%H:%M:%S')
            cherrypy.session['user_display_name'] = user.display_name
            cherrypy.session['user_id'] = user.identity
            cherrypy.session['user_email'] = user.email

        return user

    def reset(self):
        for k in 'sso_text', 'sso_revalidate', 'user_display_name':
            try:
                del cherrypy.session[k]
            except KeyError:
                pass
