# -*- coding: utf-8 -*-

from zope.component import getUtility
from pyramid.auth.interfaces import IAuthenticator
from pyramid.auth.exc import AuthorizationError


def authorizeFor(obj):
    """Упрощенная авторизация для afl_vocabs"""
    #cred_ds = getUtility(ICredentialsDataSource)
    #auth_ds = getUtility(IAuthenticationDataSource)
    #return auth_ds.authenticate(cred_ds.getCredentials())

    authenticator = getUtility(IAuthenticator)
    user = authenticator.authenticate()
    if user.role not in obj._allow_roles:
        raise AuthorizationError()


def authorize(method):
    """Authorization decorator for object methods.
    
    Usage:
    
    class Foo():
    
        @authorize()
        def some_method(self, params):
            pass
    
    Authorizes method access before calling.
    """
    def decorator(self, *args, **kwargs):
        authorizeFor(self)
        return method(self, *args, **kwargs)
    return decorator
