create_resources postgres-service.yaml postgres-rc.yaml

wait_for_pod vocabs-postgres-0

if check_db_loaded vocabs-postgres-0 vocabs _schema_revisions; then
    echoerr "$0: database vocabs already populated, skipping dump load"
else
    load_dump vocabs-postgres-0 vocabs $VOCABS_INIT_DUMP
fi

$KUBECTL run vocabs-migrate-schema \
    --restart=Never \
    --image $DOCKER_REGISTRY/vocabs:$DOCKER_TAG \
    --attach=true \
    --rm=true -- \
    scripts/migrate_schema.sh -s sql

create_resources configmap.yaml secrets.yaml
create_resources deployment.yaml
$KUBECTL rollout status deploy vocabs
