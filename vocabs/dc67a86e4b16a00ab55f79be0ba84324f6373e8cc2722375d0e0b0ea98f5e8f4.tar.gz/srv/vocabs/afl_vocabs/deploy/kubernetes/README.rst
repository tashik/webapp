Задаем параметры в переменных окружения шелла::

    KUBERNETES_NODE=afl-kube422
    NAMESPACE=afl-test1
    DOMAIN=afl-test1.com.spb.ru

    is_pod_ready() { [[ $(kubectl get pods $1 -o jsonpath='{.status.containerStatuses[0].ready}') == 'true' ]]; }


Запускаем и инициализируем Postgres::

  ssh $KUBERNETES_NODE sudo mkdir -vm 777 -p /srv/$NAMESPACE/vocabs-postgres/data

  cat pv.yaml | sed s/{{NAMESPACE}}/$NAMESPACE/g | kubectl create -f -
  kubectl create -f postgres-service.yaml -f postgres-rc.yaml

  # ждем старта контейнера
  until is_pod_ready vocabs-postgres-0; do sleep 1; done

  zcat ~/dumps/prod_vocabs2-2016-09-04.sql.gz | kubectl exec -ti vocabs-postgres-0 -- psql -U vocabs


Создаем конфигурацию::

    # заменяем домен
    cat configmap.yaml | sed -e "s/{{DOMAIN}}/$DOMAIN/g" | kubectl create -f -
    # проверяем значения
    kubectl edit cm vocabs-config

    kubectl create -f secrets.yaml
    kubectl edit secrets vocabs-secrets


Запускаем Memcache и ЛК::

    kubectl create -f deployment.yaml
    kubectl rollout status deploy vocabs
