= Сборка образа Docker =

В качестве базового используется образ registry.com.spb.ru/common-os. Он должен
быть предварительно собран. Файлы для его сборки находятся в репозитории 
https://svn.com.spb.ru/afl_site/common-os.docker

::

    ./build-libs.sh
    ./build.sh
    # если требуется другая ветка, указываем ее через переменную окружения:
    # APP_REPO=https://svn.com.spb.ru/afl_site/afl_vocabs/tags/prod DOCKER_TAG=prod ./build.sh



= Запуск СУБД =

::

    docker run --network docker_default --name vocabs-postgres -e POSTGRES_PASSWORD='' -e POSTGRES_USER=vocabs -d postgres:9.3


= Инициализация данных в БД =

::

    # если требуется, пересоздаем БД
    #docker run --rm -t --link vocabs-postgres:db -u vocabs vocabs dropdb vocabs
    #docker run --rm -t --link vocabs-postgres:db -u vocabs vocabs createdb vocabs

    RUN_PSQL="docker run --rm -t -w /srv/vocabs/afl_vocabs --link vocabs-postgres:db vocabs psql -qf"
    $RUN_PSQL sql/create.sql
    $RUN_PSQL sql/insert_data.sql
    $RUN_PSQL sql/insert_users_demo_data.sql

