#!/bin/bash
set -eu
###############################################################################
. ./build-config.sh

echo "[..] AFLCABLIB_REPO = $AFLCABLIB_REPO"
echo "[..] AFLCABLIB_REV  = $AFLCABLIB_REV"
echo "[..] PYRAMID_REPO   = $PYRAMID_REPO"
echo "[..] PYRAMID_REV    = $PYRAMID_REV"

###############################################################################

cd vocabs-libs
mkdir -p checkout
cd checkout

svn_checkout "$AFLCABLIB_REPO/lib" afl_cabinet-lib $AFLCABLIB_REV
svn_checkout "$AFLCABLIB_REPO/lib-src" afl_cabinet-lib-src $AFLCABLIB_REV
svn_checkout "$PYRAMID_REPO/trunk" pyramid $PYRAMID_REV
svn_checkout "$PYRAMID_REPO/lib" pyramid-lib $PYRAMID_REV
svn_checkout "$PYRAMID_REPO/lib-src" pyramid-lib-src $PYRAMID_REV

cd ..

tar c --exclude .svn Dockerfile checkout pydistutils.cfg | \
    docker build -t vocabs-libs --force-rm \
                 --label aflcab_lib_rev=$(svnversion checkout/afl_cabinet-lib) \
                 --label aflcab_lib_src_rev=$(svnversion checkout/afl_cabinet-lib-src) \
                 --label pyramid_rev=$(svnversion checkout/pyramid) \
                 --label pyramid_lib_rev=$(svnversion checkout/pyramid-lib) \
                 --label pyramid_lib_src_rev=$(svnversion checkout/pyramid-lib-src) \
                 -
