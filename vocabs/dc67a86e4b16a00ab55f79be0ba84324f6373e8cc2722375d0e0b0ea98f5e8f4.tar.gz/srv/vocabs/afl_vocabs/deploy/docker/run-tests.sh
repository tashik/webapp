#!/bin/bash -exu

docker_tag=${1-latest}
app=vocabs

DB_CONTAINER="${app}-test-${docker_tag}-db"
NETWORK="${app}-test-${docker_tag}"
IMAGE_NAME="registry.com.spb.ru/${app}-test:${docker_tag}"
APP_CONTAINER="${app}-test-${docker_tag}"
DB_USER=${app}_test
INIT_DB_SCRIPTS=sql/create.sql

wait_for_postgres() {
    local container=$1
    local user=$2
    while :
    do
	(set +e; docker exec $container psql -U $user -c 'select 1;') 2>&1 >/dev/null
	local result=$?
	if [[ $result -eq 0 ]]; then
	    break
	fi
	echo "Waiting for postgres to start" >&2
        sleep 1
    done
}

start_postgres() {
    docker run --name $DB_CONTAINER --network $NETWORK -e POSTGRES_PASSWORD='' -e POSTGRES_USER=$DB_USER -d postgres:9.3
    (set +x; wait_for_postgres $DB_CONTAINER $DB_USER)
}

populate_db() {
    local RUN_SQL="docker run --rm -t --network $NETWORK -e PGHOST=$DB_CONTAINER -e PGUSER=$DB_USER $IMAGE_NAME"
    for sql_script in $@
    do
	$RUN_SQL psql -qf $sql_script
    done
}

copy_reports() {
    local destdir=$1
    local appdir=$(docker inspect --format='{{.Config.WorkingDir}}' $APP_CONTAINER)
    docker cp $APP_CONTAINER:$appdir/log/coverage-report.xml $destdir
    docker cp $APP_CONTAINER:$appdir/log/test-report.xml $destdir
}

cleanup() {
    docker rm -vf $APP_CONTAINER || true
    docker stop $DB_CONTAINER || true
    docker rm -v $DB_CONTAINER || true
    docker network rm $NETWORK || true
}


main() {
    cleanup
    docker network create $NETWORK

    trap true SIGINT SIGTERM
    (
	trap - SIGINT SIGTERM

	start_postgres
	populate_db $INIT_DB_SCRIPTS
	docker run --name $APP_CONTAINER --network $NETWORK -e PGHOST=$DB_CONTAINER -e PGUSER=$DB_USER $IMAGE_NAME coverage.sh
	copy_reports .

    ) || true

    trap - SIGINT SIGTERM
    cleanup
}

main
