#!/bin/bash
. ./build-config.sh

docker build -t registry.com.spb.ru/vocabs-test:$DOCKER_TAG -t vocabs-test vocabs-test
