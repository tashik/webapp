#!/bin/bash

set -exu

rm -rf $INSTANCE_HOME/afl_vocabs/log
ln -s $INSTANCE_HOME/log $INSTANCE_HOME/afl_vocabs/log

rm -rf $INSTANCE_HOME/afl_vocabs/session
ln -s $INSTANCE_HOME/session $INSTANCE_HOME/afl_vocabs/session

chown -R vocabs /srv/vocabs/{log,log/errors,session}

if [[ -z "$@" ]]; then
    # default action
    exec su-exec vocabs python /usr/bin/py.test
else
    # cutsom cmd (example: docker run -ti aflcab /bin/bash)
    exec su-exec vocabs $@
fi
