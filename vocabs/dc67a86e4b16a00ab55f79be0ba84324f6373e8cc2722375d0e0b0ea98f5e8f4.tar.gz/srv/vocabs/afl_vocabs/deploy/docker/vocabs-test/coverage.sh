#!/bin/sh

cd $INSTANCE_HOME

python-coverage run /usr/bin/py.test --junitxml $APPDIR/log/test-report.xml $APPDIR/tests
python-coverage xml --omit="$APPDIR/tests/*" -i -o $APPDIR/log/coverage-report.xml
