get_latest_revision() {
    svn info "$1" | grep 'Last Changed Rev:' | sed -e 's/^.*: //'
}

get_repo_url() {
    svn info "$1" | grep "^URL:" | awk '{print $2}'
}

# Переменные ниже можно переопределять своими значениями из окружения
# (пример: APP_REPO=https://svn.com.spb.ru/afl_site/afl_cabinet/trunk ./build.sh)

: ${APP_REPO:="https://svn.com.spb.ru/afl_site/afl_vocabs/trunk"}
: ${APP_REV:=$(get_latest_revision "$APP_REPO")}

: ${DOCKER_TAG:=latest}

: ${AFLCABLIB_REPO:="https://svn.com.spb.ru/afl_site/afl_cabinet"}
: ${AFLCABLIB_REV:=$(get_latest_revision "$AFLCABLIB_REPO")}
: ${PYRAMID_REPO:="https://svn.com.spb.ru/pyramid"}
: ${PYRAMID_REV:=$(get_latest_revision "$PYRAMID_REPO")}

: ${APT_PROXY_URL:="http://afl-site2.com.spb.ru:3142"}

# Docker registry name
REGISTRY="registry.com.spb.ru"
APP_NAME=vocabs
FULL_NAME="$REGISTRY/$APP_NAME:$DOCKER_TAG"

svn_checkout() {
    local repo="$1"
    local dir="$2"
    local rev=$3

    if [ -e "$dir" ]; then
        svn sw "$repo" "$dir" -r$rev
        if [ -z ${NO_REVERT_ON_BUILD:-} ]; then
            svn revert -R "$dir"
        fi
        find "$dir" -name '*.pyc' -delete
    else
        svn co "$repo" "$dir" -r$rev
    fi
}
