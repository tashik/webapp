# -*- coding: utf-8 -*-

"""Aeroflot B2B Application registrations and initialization.

$Id: initializer.py 41 2012-05-30 14:47:22Z anovgorodov $
"""
import config
import cherrypy

from zope.component import provideUtility
from pyramid.app import initializer as _initializer
from pyramid.vocabulary import getV

from log import init_cherrypy_loggers


def init_vocabularies():
    u"""Регистрирует словари и адаптеры моделей"""
    from pyramid.registry import registerFromModule
    import transaction
    transaction.begin()

    # пирамидовские вокабы
    import pyramid.ui.auto.adapters
    registerFromModule(pyramid.ui.auto.adapters)
    import pyramid.ormlite
    registerFromModule(pyramid.ormlite)
    import pyramid.model
    registerFromModule(pyramid.model)
    
    # наши вокабы
    import models.geo
    registerFromModule(models.geo)
    import models.bonus
    registerFromModule(models.bonus)
    import models.air
    registerFromModule(models.air)
    import models.airport
    registerFromModule(models.airport)
    models.airport.TerminalsByAirport.register()
    import models.currency
    registerFromModule(models.currency)
    import models.route
    registerFromModule(models.route)
    import models.office
    registerFromModule(models.office)
    models.office.TravelOptionByOffice.register()
    import models.member
    registerFromModule(models.member)
    import models.partner
    registerFromModule(models.partner)
    models.partner.ContactByPartnerOffice.register()
    import models.static
    registerFromModule(models.static)
    import models.service_classes
    registerFromModule(models.service_classes)
    import models.special_offer
    registerFromModule(models.special_offer)
    import models.lang
    registerFromModule(models.lang)
    import models.ancillary_services
    registerFromModule(models.ancillary_services)
    import models.additional_info
    registerFromModule(models.additional_info)
    import models.meal
    registerFromModule(models.meal)
    import models.charity_funds
    registerFromModule(models.charity_funds)

    # инициализация MvccVocabulary
    import pyramid.vocabulary.mvcc
    pyramid.vocabulary.mvcc.register()
    getV('cities').preload()
    getV('airports').preload()

    transaction.commit()
    
def init_auth():
    import auth.ssods
    provideUtility(auth.ssods.SSOAuthenticationDS())
    provideUtility(auth.ssods.SSOCredentialsDS())
    provideUtility(auth.ssods.Authenticator())

def init_django():
    # Configure Django settings once, and only once.
    from django.conf import settings
    if not settings.configured:
        settings.configure()
    
    from ui.common import get_current_lang
    from django.utils.translation import activate
    def activate_lang():
        activate(get_current_lang())
    cherrypy.tools.activate_django_translation = cherrypy.Tool('on_start_resource', activate_lang,
                                                               priority=60)  # после tools.session (50)

def fix_session_cookie():
    cookie = cherrypy.response.cookie
    name = cherrypy.config.get('tools.sessions.name', 'session_id')
    if name in cookie:
        del cookie[name]['expires']
        cookie[name]['HttpOnly'] = 1

def start_request_timer():
    import time
    cherrypy.request.start_time = time.time()

def init_cherrypy_tools():
    # aflcab tools
    cherrypy.tools.clear_sess_cookie_expiry = \
        cherrypy.Tool('before_finalize', fix_session_cookie, priority=99)
    cherrypy.tools.request_timer = cherrypy.Tool('on_start_resource', start_request_timer, priority=0)

#    from services.heartbeat import StatusMonitor
#    cherrypy.tools.status = StatusMonitor()
#    cherrypy.tools.trusted_proxy = cherrypy.Tool('before_request_body', trusted_proxy, priority=30)
#    from ui.csrf import check_submit
#    cherrypy.tools.csrf_submit_reject = cherrypy.Tool('before_request_body', check_submit, priority=90)



def init_custom_i18n():
    import rx.i18n.translation
    rx.i18n.translation.init_i18n()

def init_pbus():
    from notify import subscribe
    subscribe(config.PBUS_TOPICS['vocabs'])

    
# Инициализация ----------------------------------------------------------------

def initialize():
    init_cherrypy_loggers()

    _initializer.initMimetypesExtensions()
    _initializer.initAuthServices()

    #_initializer.initVocabularies()
    
    _initializer.initDBConnection()
    _initializer.initCache()
    _initializer.initCPPageTransactionWrapper()
    _initializer.initCPSavedSessionHandler()
    _initializer.initCPNoCacheHandler()
    _initializer.initI18NSupport()
    
    init_vocabularies()

    # В конце делаем пред-загрузку всех persistent-словарей, т.к. их
    # необходимо загружать ДО старта cherrypy-сервера, пока приложение
    # работает в единственном треде.
    _initializer.preloadVocabularies()

    # пред-загрузка Indexer-а
    import models.airport
    models.airport.TerminalsByAirport.new()

    import models.office
    models.office.TravelOptionByOffice.new()

    import models.partner
    models.partner.ContactByPartnerOffice.new()

    import ui.field_adapters
    ui.field_adapters.register_adapters()
    
    init_auth()
    init_django()
    init_custom_i18n()
    init_cherrypy_tools()
    init_pbus()
    

