# -*- coding: utf-8 -*-

"""
$Id: $
"""

data_sql = u'''
insert into world_regions (world_region_id, names) values (-1, 'ru:Европа|en:Europe');

insert into currencies(alpha3_code, minor_unit, names) values('RUR', 2, 'ru:Рубль');
insert into currencies(alpha3_code, minor_unit, names) values('USD', 2, 'ru:Доллар');
insert into countries (country, iso_code3, world_region_id, names, telephone_code, use_in_siebel, currency_alpha3_code) values ('XX', 'XXX', -1, 'ru:Россия|en:Russia', 123, True, 'RUR');
insert into countries (country, iso_code3, world_region_id, names, telephone_code, use_in_siebel, currency_alpha3_code) values ('YY', 'YYY', -1, 'ru:США|en:USA', null, False, 'USD');

insert into cities (city_id, country, tz, iata, names, lat, lon, can_book) values (-1, 'XX', 'UTC+4', 'ZZZ', 'ru:Улетаево', 45.819166676667, 45.091666676667, 'False');
insert into cities (city_id, country, tz, iata, names, lat, lon, can_book) values (-2, 'XX', 'UTC+2', 'ZZX', 'ru:Прилетаево', 55.819166676667, 55.091666676667, 'False');
insert into cities (city_id, country, tz, iata, names, lat, lon, can_book) values (-3, 'XX', 'UTC-1', 'ZZY', 'ru:Пересадково', 65.819166676667, 65.091666676667, 'False');

insert into redemption_zones (redemption_zone, names) values ('WW', 'ru:Атлантида|en:Atlantis');
insert into redemption_zones (redemption_zone, names) values ('TT', 'ru:Таинственный остров|en:The Mysterious Island');

insert into airports (airport_id, iata, icao, city_id, names, lat, lon, has_afl_flights, afl_redemption_zone, has_uc_award) values (-3, 'ZZZ', 'ZZZZ', -1, 'ru:Улетаево', 45.5, 45.5, 'False', 'WW', TRUE);
insert into airports (airport_id, iata, icao, city_id, names, lat, lon, has_afl_flights) values (-4, 'ZZX', 'ZZXX', -2, 'ru:Прилетаево', 55.5, 55.5, 'True');
insert into airports (airport_id, iata, icao, city_id, names, lat, lon, has_afl_flights) values (-5, 'ZZY', 'ZZYY', -2, 'ru:Пересадково', 65.5, 65.5, 'True');

insert into airport_terminals (terminal_id, airport_id, code, names) values (-1, -3, 'Z', 'ru:Терминал Z');

insert into loyalty_programs (loyalty_program_id, name, siebel_id) values (-1,'Frequent flyer program', 'XXXX');
insert into loyalty_programs (loyalty_program_id, name) values (-2,'Cedar Miles');

insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, loyalty_program_id, parent_airline_id, weight, url, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-1, 'ITA', 'ICA', 'ABCD', 'XX', -3, 'ru:Авиакомпания 1|en:Airline 1', 'Skyteam', -1, null, 1, 'ru:http://ramax.ru', 0.0, '', '', '');
insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance, loyalty_program_id, parent_airline_id, weight, url, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values (-2, 'XXX', 'YYY', 'EFGH', 'XX', -4, 'ru:Авиакомпания 2|en:Airline 2', '', -1, -1, 2, 'http://yandex.ru/', 0.0, '', '', '');

insert into skyteam_service_classes (skyteam_sc_id, code, names, weight, classification_level) values (-1, 'xx', 'ru:Первый', 10, 'B');
insert into skyteam_service_classes (skyteam_sc_id, code, names, weight) values (-2, 'yy', 'ru:Второй', 20);

insert into tariff_groups (id, tariff_group, service_class, names, weight) values (-1, 'xxxxxxx-yyyyyyy', -1, 'en:enYYY|ru:ruYYY', 10);

insert into partner_categories (partner_category_id,status, names) values (-2,'P','en:ENG|ru:РУСС');

insert into partners (partner_id, names, partner_description, url, partner_categories, mile_action, spec_offer_comm, weight, new_until, mile_get_comm, mile_waste_comm, short_descr) values (-1, 'en:english|ru:русский', 'en:english|ru:русский', 'http://url.com', '-2', 'A', 'en:comment|ru:коммент', 0, '2015-05-15', '', '', '');

insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, working_time, office_type )  values (-1, -1, -1, 10.10, 11.11, 'en:english|ru:русский', 'en:english|ru:русский', 'en:english|ru:русский', 'M');
insert into partner_offices (partner_office_id, partner_id, city_id, lat, lon, comments, address, working_time, office_type )  values (-2, -1, -1, 10.10, 11.11, 'en:english|ru:русский', 'en:english|ru:русский', 'en:english|ru:русский', 'M');

insert into partner_office_contacts (partner_office_contact_id, partner_office_id, contact_type, contact, main_contact) values (-1, -1, 'E', 'some@some.ru', True);

insert into partner_award_conditions (partner_award_condition_id, partner_id, award_condition_type, award_condition_description, weight, status) values (-1, -1, 'S', 'en:english|ru:русский', 1, 'P');

insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-1, -1, -1);
insert into airline_service_classes (airline_sc_id, airline_id, skyteam_sc_id) values (-2, -1, -2);
insert into airline_tariff_groups(id, tariff_group, service_class, charge_coef, weight, fare_code) values(-1, -1, -1, 0, 0, '');
insert into booking_classes (id, bc_code, miles_are_charged, commentary, al_tariff_group) values (-1, 'Z', TRUE, 'ru:Класс', -1);

insert into comments (comment_id, names, weight) values( -1, 'ru:one', 1);
insert into comments (comment_id, names, weight) values( -2, 'ru:two', 2);

insert into pairs (pair_id, airline_id, airport_from_id, airport_to_id, miles, no_spending) values (-3, -1, -3, -4, 200, TRUE);

insert into service_classes_limits (service_classes_limit_id, airline_sc_id, pair_id) values (-1, -1, -3);

insert into bonus_routes (bonus_route_id, code, zone_from, zone_via, zone_to, carrier) values (-1, 'WWTT', 'WW', null, 'TT', 'A');
insert into awards (award_id, type,service_classes_1,service_classes_2, award_value, route,comment) values  (-1, 'OW',-1,-2, 123, -1,-1);

insert into tier_levels(tier_level, names, ordering, miles, segments, business_segments) values ('TR', 'ru:Рус|en:Eng', 1, 1000, 3, 1);
insert into tier_level_factors(tier_level_factor_id, airline, tier_level, factor) values (-1, -1, 'TR', 1.23);

insert into special_offers (offer_id, partner_id, names, status, offer_description, offer_url, ui_languages) values (-1, -1, 'en:Super special offer|ru:Мега специальное предложение', 'P', 'en:Super special offer description|ru:Описание мега специального предложения', 'ru:http://ya.ru', 'en,ru');

insert into office_categories (office_category_id,office_category_description, names, city_id) values (-3, 'en:ENG|ru:РУС', 'en:ENG|ru:РУС', -3 );

insert into offices (office_id, names, office_description, email,fax, phone, lat, lon, address, working_time, in_airport, insurance_policy, noncash_booking, new_office, airport_id, distance_to_airport, office_category_id, location_map, transfer_time_public, transfer_time_automobile, transfer_time_foot, important_info, office_weight) values (-3, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 99.99, 99.99, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, -3, 123, -3,'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123, '', 0);

insert into office_travel_options (office_travel_option_id, office_id,travel_type, office_travel_option_description,travel_time) values (-3, -3, 'F', 'en:Eng|ru:Рус', 123);

insert into professional_areas (professional_area_id, names) values (-1,'ru:Бухгалтерия, финансы|en:Accountancy');

insert into languages (alpha2_code, alpha3_code, selector_code, names, is_active) values ('XX', 'XXX', 'XXX', 'ru:Русский|en:Russian', 'True');

insert into localizations (code, names, default_language, allowed_languages, is_active) values ('XX', 'ru:Рус|en:Rus', 'XX', 'XX,YY,ZZ', 'True');

insert into special_meal (code, names) values ('XXXX', 'en:English|ru:Английский');

insert into ancillary_services_groups (ancillary_services_group_id, names, ordinal_number, filename, message) values (1, 'en:Ancillary Services|ru:Дополнительные услуги', 10, 'ancillary', 'en:Ancillary Services|ru:Дополнительные услуги'), (2, 'en:Insurance|ru:Страхование', 20, 'insurance', 'en:Insurance|ru:Страхование'), (3, 'en:Aeroexpress|ru:Аэроэкспресс', 30, 'aeroexpress', 'en:Aeroexpress|ru:Аэроэкспресс');
insert into rfic_codes (code, names) values ('A', 'en:Air Transportation'), ('B', 'en:Surface Transportation /Non Air Services'), ('C', 'en:Baggage');
insert into ancillary_services (code, names, ancillary_services_group_id, rfic, descriptions, doc_prefix, emd_message) values ('0EC', 'en:BICYCLE|ru:Перевозка велосипеда', 1, 'C', 'ru:Описание|en:Description', 'ru:префикс|en:prefix', 'ru:емд|en:emd'), ('0BQ', 'en:AEROEXPRESS|ru:Билет на Аэроэкспресс', 3, 'B', '', '', ''), ('TIF', 'en:TRIP INSURANCE|ru:Страхование пассажиров на время перелета', 2, 'A', '', 'ru:префикс|en:prefix', 'ru:емд|en:emd');
insert into ancillary_service_statuses (ancillary_service_status_id, code, rfic, rfisc, names) values (1, 'HI', NULL, NULL, 'ru:Документы оформлены'), (2, 'HI', 'B', '0BQ', 'ru:Оформлено');

insert into additional_info (additional_info_id, weight, created, names, condition) values (1, 10, '2015-10-28', 'ru:Сообщение|en:Message', '[{"airport_from": "SVO"}]'), (2, 20, '2015-10-29', 'ru:Информация|en:Info', '[{"airport_to": "LED"}]');

insert into meal_rules (meal_rule_id, date_from, date_to, number, airline, origin, destination, booking_class, special_meal) values (1, '2010-01-01', '2020-01-01', '1,3-5', '-1,-2', '-3,-4', '-4,-5', '-1', 'XXXX');
insert into meal_timelimits (meal_timelimit_id, origin, special_meal, timelimit) values (1, '-3,-4', 'XXXX', 24);

insert into charity_funds (charity_funds_id, names, logo_url, image_url, charity_short_description, charity_description, url, transfer_conditions, contacts, news_url, news_mv_url, donate_miles_url, donate_miles_mv_url, stats_charity_funds_url, rss_url, status, weight, create_date, modify_date, charity_id, tag) values
(-1, 'en:First charity funds|ru:Первый фонд', 'en:http://aeroflot.ru/logo.png|ru:http://aeroflot.ru/logo.png',
'en:http://aeroflot.ru/image.png|ru:http://aeroflot.ru/image.png', 'ru:Это короткое описание|en:This is short description',
'ru:Это описание|en:This is description', 'en:http://aeroflot.ru/|ru:http://aeroflot.ru/',
'en:http://aeroflot.ru/|ru:http://aeroflot.ru/', 'Москва', 'en:http://aeroflot.ru/news|ru:http://aeroflot.ru/news',
'en:http://aeroflot.ru/pda/news|ru:http://aeroflot.ru/pda/news', 'http://aeroflot.ru/donate_miles_url',
'http://aeroflot.ru/donate_miles_mv_url',
'http://aeroflot.ru/stats', '', 'P', 10, '2015-10-29', '2016-10-30', '12345156', 'KOMMERSANT_FUND_ID')
'''
