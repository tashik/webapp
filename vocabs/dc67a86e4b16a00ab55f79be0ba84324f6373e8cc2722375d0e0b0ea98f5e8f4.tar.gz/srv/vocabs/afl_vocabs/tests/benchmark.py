# -*- coding: utf-8 -*-

"""
$Id: $
"""
from pyramid.vocabulary import getV
from pyramid.ormlite import dbop, dbquery
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
import models.geo
import models.air
import models.airport
import models.bonus
import models.route
from models.airport import AirportTerminal
import _test_data

def load_cities():
    import pyramid.vocabulary.mvcc
    pyramid.vocabulary.mvcc.register()
    models.geo.CitiesVocabulary.register()
    cities = models.geo.City.bulkLoadList(dbquery('select * from cities'))
    getV('cities').add_many(cities)

class Benchmark(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(Benchmark, self).setUp()
        import pyramid.vocabulary.mvcc
        pyramid.vocabulary.mvcc.register()
        load_cities()


    def test_add_speed(self):
        import time
        import transaction
        from models.geo import City
        from cPickle import dumps

        for i in xrange(5):
            start_t = time.time()
            cities = []
            #dbquery('delete from airports')
            dbquery('delete from cities where city_id <= -10')
            for n in xrange(10, 10011):
                city_id = -n
                city_name = u'Город %s' % n
                c = City(city_id=city_id,
                         country_code='XX',
                         tz='Europe/Moscow',
                         iata=None,
                         names=['ru:%s' % city_name],
                         )
                cities.append(c)
                #c.save()
            getV('cities').add_many(cities)
            self.bulkSave(cities)
            #self.copySave(cities)
            #self.dumps(cities)
            dumps(cities)
            commit_t = time.time()
            if i == 1:
                pass
            transaction.commit()
            print '%s: elapsed %.2f commit=%.2f' % (i, time.time() - start_t, time.time() - commit_t)


    def test_load_speed(self):
        import time
        from models.geo import City

        cities = []
        for n in xrange(10, 10011):
            city_id = -n
            city_name = u'Город %s' % n
            c = City(city_id=city_id,
                     country_code='XX',
                     tz='Europe/Moscow',
                     iata=None,
                     names=['ru:%s' % city_name],
                     )
            cities.append(c)
        self.copySave(cities)

        for i in xrange(5):
            start_t = time.time()
            cities = City.bulkLoadList(dbop.dbquery('select * from cities'))
            print len(cities)
            getV('cities').add_many(cities)
            print '%s: elapsed %.2f ' % (i, time.time() - start_t)


    def test_json_speed(self):
        import demjson
        import json
        import time
        from models.geo import City
        from cPickle import dumps

        country = models.geo.Country()
        country.iso_code2 = u'XX'
        country.iso_code3 = u'XXX'
        country.names = [u'ru:Атлантида', u'en:Atlantis']
        country.telephone_code = 999


        city = City(city_id=-1,
                 country_code='XX',
                 tz='Europe/Moscow',
                 iata='MOW',
                 icao='MMMM',
                 names=[u'ru:Москва', 'en:Moscow'],
                 )
        getV('cities').add(city)

        models.airport.AirportTerminalsVocabulary().register()
        models.airport.TerminalsByAirport().register()

        ap = models.airport.Airport()
        ap.airport_id = -5
        ap.iata = u'XYZ'
        ap.icao = u'1234'
        ap.city = city
        ap.has_afl_flights = True
        ap.terminals = [AirportTerminal(terminal_id=-8, code='A2', names=['ru:Terminal A2']),
                        AirportTerminal(terminal_id=-9, code='A3', names=['ru:Terminal A3'])]
        ap.names = [u'ru:Аэропорт 1', u'en:Airoport 1']


        ob = ap
        print ob.as_primitive()

        for i in xrange(3):
            start_t = time.time()
            for n in xrange(10000):
                #for t in enumerate_fields(c): pass
                d = ob.as_primitive()
                json.dumps(d, encoding='utf-8')
                #demjson.encode(d, encoding='utf-8')
                #dumps(c)
            print '%s: elapsed %.2f ' % (i, time.time() - start_t)


    def bulkSave(self, obs):
        from pyramid.ormlite.psycopgcon import sql_repr  # dbop.sql_repr тормозит
        ob = obs[0]

        parts = ['INSERT INTO %s (%s) VALUES ' % (ob.p_table_name, ','.join(ob.p_col_seq))]
        row_tpl = ','.join([('%%(%s)s' % s) for s in ob.p_col_seq])

        rows = []
        for ob in obs:
            columns = {}
            for ob_attr, field in ob.p_fields.items():
                bound_field = field.bind(ob)
                db_column = field.db_column
                val = getattr(ob, ob_attr)
                if val is not None:
                    val = bound_field.toDbType(val)
                columns[db_column] = sql_repr(val)
                #if val is not None:
                #    val = "'%s'" % bound_field.toDbType(val)
                #else:
                #    val = 'NULL'
                #columns[db_column] = str(val)
            row_s = row_tpl % columns
            rows.append('(%s)' % row_s)
        parts.append(',\n'.join(rows))
        q = '\n'.join(parts)
        dbquery(q)


    def copySave(self, obs):
        ob = obs[0]

        rows = []
        for ob in obs:
            row = []
            for ob_attr in ob.p_attr_seq:
                field = ob.p_fields[ob_attr]
                bound_field = field.bind(ob)
                val = getattr(ob, ob_attr)
                if val is not None:
                    val = unicode(bound_field.toDbType(val))
                    val = val.replace('\\', '\\92').replace('\t', '\\9').replace('\n', '\\10').replace('\r', '\\13')
                else:
                    val = '\\N'
                row.append(val)
            rows.append(u'\t'.join(row))
        from cStringIO import StringIO
        sio = StringIO(u'\n'.join(rows).encode('utf-8'))

        dbop.con().cursor().copy_from(sio, ob.p_table_name, columns=ob.p_col_seq)


    def dumps(self, obs):
        from cPickle import dumps
        ob = obs[0]

        rows = []
        for ob in obs:
            row = []
            for ob_attr in ob.p_attr_seq:
                field = ob.p_fields[ob_attr]
                bound_field = field.bind(ob)
                val = getattr(ob, ob_attr)
                if val is not None:
                    val = bound_field.toDbType(val)
                row.append(val)
            rows.append(row)

        dumps(obs)
