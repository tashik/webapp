# -*- coding: utf-8 -*-

""" 
$Id: test_model.py 1767 2012-10-15 18:55:40Z anovgorodov $
"""
import unittest
import testoob

from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from notify.query import QueryService

import _test_data

class Test(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def _registerVocabularies(self):
        from pyramid.registry import registerFromModule
        import models.geo
        registerFromModule(models.geo)
        import models.air
        registerFromModule(models.air)
        import models.currency
        registerFromModule(models.currency)
    
    def test_get_all(self):
        svc = QueryService()
        obs = svc.get_all(vocabularies=['countries'])
        self.assertEqual(len(obs), 2)
        
        ru = [c for c in obs if c['iso_code2'] == 'XX']
        self.assertEqual(len(ru), 1)
        self.assertEqual(ru[0]['iso_code3'], 'XXX')
        

if __name__ == "__main__":
    testoob.main()
