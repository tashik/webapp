# -*- coding: utf-8 -*-

"""
$Id: testvocab.py 15071 2015-09-24 14:01:57Z sbolxzhatov $
"""

from zope.interface import implements
from pyramid.vocabulary.interfaces import IVocabulary
from zope.schema.interfaces import IVocabularyFactory, ITokenizedTerm
from zope.schema.vocabulary import SimpleTerm
from pyramid.vocabulary import _fmtToken


class TestVocab(object):
    implements(IVocabulary, IVocabularyFactory)

    def __init__(self, data):
        self.data = dict([(str(k), v) for (k, v) in data.items()])

    def getTermByToken(self, token): return SimpleTerm(self.data[token], token)
    def getTerm(self, value):
        match = [(k, v) for k, v in self.data.items() if v == value]
        if not match:
            raise LookupError(value)
        term = SimpleTerm(match[0][1], match[0][0])
        return term
    def __iter__(self): return self.data.values().__iter__()
    def __len__(self): return len(self.data)

    def __contains__(self, value):
        u"""BaseVocabulary.__contains__"""
        try:
            term = ITokenizedTerm(value)
            token = term.token
            value = term.value
        except TypeError:
            token = value
            value = None
        token = _fmtToken(token)
        if token in self.data:
            if value is not None:
                return self.data[token] == value
            return True
        return False

    def __getitem__(self, token):
        return self.data[_fmtToken(token)]

    def get(self, token, default=None): return self.data.get(str(token), default)
    def keys(self): return self.data.keys()
    def values(self): return self.data.values()
    def items(self): return self.data.items()

    def __call__(self, context): return self

    def register(self, name):
        from zope.component import provideUtility
        provideUtility(self, IVocabularyFactory, name)


class MutableTestVocab(TestVocab):

    def __init__(self, data, objectC=None):
        super(MutableTestVocab, self).__init__(data)
        self.objectC = objectC

    def _dict2token(self, token):
        if isinstance(token, dict):
            if self.objectC is None:
                token = token.values()
            else:
                token = tuple((token[p] for p in self.objectC.p_keys))
        return token

    def __getitem__(self, token):
        return super(MutableTestVocab, self).__getitem__(self._dict2token(token))

    def add(self, value):
        token = ITokenizedTerm(value).token
        self.data[str(token)] = value

    def __delitem__(self, token):
        del self.data[_fmtToken(self._dict2token(token))]

    def getTerm(self, value):
        match = [(k, v) for k, v in self.data.items() if value in (k, v)]
        if not match:
            raise LookupError(value)
        term = SimpleTerm(match[0][1], match[0][0])
        return term
