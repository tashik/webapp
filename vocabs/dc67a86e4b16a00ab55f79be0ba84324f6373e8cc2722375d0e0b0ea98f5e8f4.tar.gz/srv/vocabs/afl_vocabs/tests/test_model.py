# -*- coding: utf-8 -*-

"""
$Id: test_model.py 1767 2012-10-15 18:55:40Z anovgorodov $
"""
from datetime import date, datetime, timedelta
import unittest
import testoob
from zope.interface.exceptions import Invalid
from zope.schema._bootstrapinterfaces import TooSmall, TooBig, TooShort, RequiredMissing

import mock
from django.core.exceptions import ValidationError
from zope.schema.interfaces import ConstraintNotSatisfied, WrongContainedType, TooLong
from pyramid.vocabulary import getV
from pyramid.ormlite import dbquery
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithVocabs
from pyramid.registry.interfaces import IRegisterable
from models.base import FilenameField, JSONConditionField, NumbersListField
from models.geo import Country
import models.additional_info
import models.air
import models.airport
import models.ancillary_services
import models.bonus
import models.currency
import models.geo
import models.lang
import models.meal
import models.member
import models.partner
import models.route
import models.service_classes
import models.special_offer
import models.charity_funds
import models.static
import _test_data
from models.airport import AirportTerminal
from models.indexer import Indexer, getI
from models.interfaces import IVatRate
from models.office import OfficeTravelOption
from zope.schema.interfaces import ITokenizedTerm
from ui.widgets import JSONCondition, validate_json_condition, NumbersList, is_valid_numbers_list
from psycopg2 import IntegrityError
from notify import as_primitive

from testvocab import MutableTestVocab

def register_cities():
    IRegisterable(models.geo.CitiesVocabulary).register()
    getV('cities').preload()


def register_airports():
    IRegisterable(models.airport.AirportsVocabulary).register()
    getV('airports').preload()


class Test(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(Test, self).setUp()
        import pyramid.vocabulary.mvcc
        pyramid.vocabulary.mvcc.register()

    def test_loyalty_program_load(self):
        dbquery(
            "insert into loyalty_programs (loyalty_program_id, name, siebel_id, sabre_id) values (-100,'Frequent flyer program', 'YYYY', 'XX')")
        ob = models.member.LoyaltyProgram.load(loyalty_program_id=-100)
        self.assertEqual(ob.name, u'Frequent flyer program')
        self.assertEqual(ob.siebel_id, u'YYYY')
        self.assertEqual(ob.sabre_id, u'XX')

    def test_loyalty_program_save(self):
        ob = models.member.LoyaltyProgram()
        ob.loyalty_program_id = -200
        ob.name = u'Frequent flyer program'
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.loyalty_program_id, None)
        self.assertEqual(ob.name, u'Frequent flyer program')

    def test_professional_area_load(self):
        dbquery(
            "insert into professional_areas (professional_area_id, names) values (-100,'ru:Бухгалтерия, финансы|en:Accountancy')")
        ob = models.member.ProfessionalArea.load(professional_area_id=-100)
        self.assertEqual(ob.names, [u'ru:Бухгалтерия, финансы', u'en:Accountancy'])

    def test_professional_area_save(self):
        ob = models.member.ProfessionalArea()
        ob.professional_area_id = -200
        ob.names = [u'ru:Бухгалтерия, финансы', u'en:Accountancy']
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.professional_area_id, None)
        self.assertEqual(ob.names, [u'ru:Бухгалтерия, финансы', u'en:Accountancy'])

    def test_partner_category_load(self):
        dbquery("insert into partner_categories (partner_category_id,status, names) values (-1,'P','en:ENG|ru:РУСС')")
        wr = models.partner.PartnerCategory.load(partner_category_id=-1)
        self.assertEqual(wr.names, [u'en:ENG', u'ru:РУСС'])

    def test_partner_category_save(self):
        models.static.ItemStatusVocabulary.register()
        m = models.partner.PartnerCategory()
        m.partner_category_id = -3
        m.status = getV('publication_statuses')['P']
        m.names = [u'ru:русский', u'en:english']
        m.save()
        m.reload()
        self.assertNotEqual(m.partner_category_id, None)
        self.assertEqual(m.names, [u'ru:русский', u'en:english'])

    def test_partner_load(self):
        models.static.ItemStatusVocabulary.register()
        models.partner.PartnerCategoryVocabulary.register()
        ob = models.partner.Partner.load(partner_id=-1)
        self.assertEqual(ob.names, [u'en:english', u'ru:русский'])
        self.assertEqual(ob.new_until, date(2015, 5, 15))

    def test_partner_save(self):
        models.static.ItemStatusVocabulary.register()
        models.partner.PartnerCategoryVocabulary().register()
        models.partner.PartnerMileActionVocabulary.register()

        ob = models.partner.Partner()
        ob.partner_id = -3
        ob.partner_description = [u'ru:русский', u'en:english']
        ob.names = [u'ru:русский', u'en:english']
        ob.url = [u'ru:http://url.com']
        ob.partner_categories = [models.partner.PartnerCategory.load(partner_category_id=-2)]
        ob.mile_action = getV('partner_mile_actions')['S']
        ob.weight = 0
        ob.new_until = date(2015, 02, 13)
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.partner_id, None)
        self.assertEqual(ob.url, [u'ru:http://url.com'])
        self.assertEqual(ob.new_until, date(2015, 02, 13))

    def test_partner_json(self):

        models.partner.PartnerVocabulary.register()

        p = getV('partners')[-1]
        d = p.as_primitive()
        self.assertEqual(d['class'], 'Partner')
        self.assertEqual(d['partner_id'], -1)
        self.assertEqual(d['names'], [u'en:english', u'ru:русский'])
        self.assertEqual(d['partner_description'], [u'en:english', u'ru:русский'])
        self.assertEqual(d['short_descr'], [])
        self.assertEqual(d['status'], None)
        self.assertEqual(d['partner_categories'], [])
        self.assertEqual(d['url'], [u'http://url.com'])
        self.assertEqual(d['mile_action'], u'A')
        self.assertEqual(d['mile_get_comm'], [])
        self.assertEqual(d['mile_waste_comm'], [])
        self.assertEqual(d['spec_offer_comm'], [u'en:comment', u'ru:коммент'])
        self.assertEqual(d['weight'], 0)
        self.assertEqual(d['new_until'], '2015-05-15')

        d2 = as_primitive(p)
        self.assertEqual(d, d2)

    def test_partner_office_load(self):
        ob = models.partner.PartnerOffice.load(partner_office_id=-1)
        self.assertEqual(ob.address, [u'en:english', u'ru:русский'])

        models.partner.PartnerOfficeVocabulary().register()
        models.partner.PartnerOfficeContactVocabulary().register()
        models.partner.ContactByPartnerOffice().register()
        models.partner.ContactTypeVocabulary.register()

        getI('contact_by_partner_office_idx')._reindex()
        contacts = getI('contact_by_partner_office_idx')(ob.partner_office_id)
        self.assertEqual(len(contacts), 1)

        ob = getV('partner_offices')[-1]
        contacts = getI('contact_by_partner_office_idx')(ob.partner_office_id)
        self.assertEqual(len(contacts), 1)

        dbquery("insert into partner_office_contacts (partner_office_contact_id, partner_office_id, contact_type, contact, main_contact) \
                 values (-2, -1, 'P', '1234567890', False)")
        getV('partner_office_contacts')._reload()
        getI('contact_by_partner_office_idx')._reindex()

        contacts = getI('contact_by_partner_office_idx')(ob.partner_office_id)
        self.assertEqual(len(contacts), 2)

        ob.contacts = [
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-10,
                contact_type=getV('partner_office_contact_types')['E'],
                contact='test10@test.com',
                main_contact=False
            )
        ]
        self.assertEqual(ob.contacts[0].partner_office_contact_id, -10)
        self.assertEqual(ob.contacts[0].partner_office, ob.partner_office_id)
        contacts = getI('contact_by_partner_office_idx')(ob.partner_office_id)
        self.assertEqual(len(contacts), 1)

        ob.contacts = [
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-11,
                contact_type=getV('partner_office_contact_types')['E'],
                contact='test11@test.com',
                main_contact=False
            ),
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-12,
                contact_type=getV('partner_office_contact_types')['E'],
                contact='test12@test.com',
                main_contact=False
            )
        ]
        contacts = getI('contact_by_partner_office_idx')(ob.partner_office_id)
        self.assertEqual(len(contacts), 2)

    def test_partner_office_save(self):
        register_cities()

        models.static.ItemStatusVocabulary.register()
        models.partner.PartnerCategoryVocabulary().register()
        models.partner.PartnerVocabulary().register()
        models.partner.PartnerOfficeTypeVocabulary.register()
        models.partner.PartnerOfficeContactVocabulary().register()
        models.partner.ContactTypeVocabulary.register()

        ob = models.partner.PartnerOffice()
        ob.partner_office_id = -3
        ob.partner = models.partner.Partner.load(partner_id=-1)
        ob.city = models.geo.City.load(city_id=-1)
        ob.lat = +77.11
        ob.lon = -77.11
        ob.comments = [u'ru:русский', u'en:english']
        ob.address = [u'ru:Россия\nЛенинград', u'en:Russia\nLeningrad']
        ob.worktime = [u'99:99\n111', u'88:88\n222']
        ob.office_type = getV('partner_office_types')['O']
        ob.contacts = [
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-13,
                contact_type=getV('partner_office_contact_types')['E'],
                contact='test11@test.com',
                main_contact=False
            ),
            models.partner.PartnerOfficeContact(
                partner_office_contact_id=-14,
                contact_type=getV('partner_office_contact_types')['E'],
                contact='test12@test.com',
                main_contact=False
            )
        ]

        ob.save()
        ob.reload()
        self.assertNotEqual(ob.partner_office_id, None)
        self.assertEqual(ob.worktime, [u'99:99\n111', u'88:88\n222'])
        self.assertEqual(len(ob.contacts), 2)

        # Длинное поле contact
        old_contacts = ob.contacts
        new_contact = models.partner.PartnerOfficeContact(
            partner_office_contact_id=-15,
            contact_type=getV('partner_office_contact_types')['E'],
            contact='%s@%s.ru' % ('test' * 12, 'test' * 12 + 'A'),
            main_contact=False)
        old_contacts.append(new_contact)
        ob.contacts = old_contacts  # ob.contacts.append не сработает, т.к. set_contacts при этом не вызывается
        self.assertEqual(len(ob.contacts), 3)
        self.assertRaises(TooLong, new_contact.save)
        new_contact.contact = '%s@%s.ru' % ('test' * 12, 'test' * 12)
        new_contact.save()
        self.assertEqual(len(ob.contacts), 3)

    def test_partner_office_json(self):
        models.partner.PartnerOfficeVocabulary().register()
        models.partner.PartnerOfficeContactVocabulary().register()
        models.partner.ContactByPartnerOffice().register()

        po = getV('partner_offices')[-1]
        d = po.as_primitive()
        self.assertEqual(d['class'], 'PartnerOffice')
        self.assertEqual(d['city'], -1)
        self.assertEqual(d['partner'], -1)
        self.assertEqual(d['contacts'], [
            {'partner_office_contact_id': -1, 'contact': u'some@some.ru', 'main_contact': True, 'contact_type': u'E'}])
        self.assertEqual(d['office_type'], u'M')
        self.assertEqual(d['worktime'], [u'en:english', u'ru:русский'])
        self.assertEqual(d['lon'], 11.11)
        self.assertEqual(d['lat'], 10.1)
        self.assertEqual(d['comments'], [u'en:english', u'ru:русский'])
        self.assertEqual(d['partner_office_id'], -1)
        self.assertEqual(d['address'], [u'en:english', u'ru:русский'])

        d2 = as_primitive(po)
        self.assertEqual(d, d2)

    # def test_partner_office_contact_load(self):
    #    ob = models.partner.PartnerOfficeContact.load(partner_office_contact_id=-1)
    #    self.assertEqual(ob.contact, 'some@some.ru')

    # def test_partner_office_contact_save(self):
    #    models.partner.PartnerCategoryStatusVocabulary.register()
    #    models.partner.PartnerOfficeTypeVocabulary.register()
    #    register_cities()
    #    models.partner.PartnerOfficeVocabulary.register()
    #    models.partner.ContactTypeVocabulary.register()
    #    m = models.partner.PartnerOfficeContact()
    #    m.partner_office_contact_id = -3
    #    m.partner_office = -1
    #    m.contact_type = getV('partner_office_contact_types')["P"]
    #    m.contact = "+7(999)999-99-99"
    #    m.maint_contact = False
    #    m.save()
    #    m.reload()
    #    self.assertNotEqual(m.partner_office_contact_id, None)
    #    self.assertEqual(m.contact, "+7(999)999-99-99")

    def test_partner_award_condition_load(self):
        ob = models.partner.PartnerAwardCondition.load(partner_award_condition_id=-1)
        self.assertEqual(ob.award_condition_description, [u'en:english', u'ru:русский'])

    def test_partner_award_condition_save(self):
        models.static.ItemStatusVocabulary.register()
        models.partner.PartnerOfficeTypeVocabulary.register()
        models.partner.PartnerCategoryVocabulary.register()
        models.partner.PartnerVocabulary().register()
        models.partner.PartnerAwardConditionTypeVocabulary.register()
        m = models.partner.PartnerAwardCondition()

        m.partner_award_condition_id = -3
        m.partner = models.partner.Partner.load(partner_id=-1)
        m.award_condition_type = getV('partner_award_condition_types')['E']
        m.award_condition_description = [u'ru:русский', u'en:english']
        m.weight = 10
        m.status = getV('publication_statuses')['P']
        m.miles = 1000.0
        m.save()
        m.reload()
        self.assertNotEqual(m.partner_award_condition_id, None)
        self.assertEqual(m.award_condition_description, [u'ru:русский', u'en:english'])

    def test_office_category_load(self):
        register_cities()
        dbquery("insert into office_categories (office_category_id, office_category_description, names, city_id)\
                                        values (-1,'en:ENG|ru:РУС','en:ENG|ru:РУС',-1)")
        wr = models.office.OfficeCategory.load(office_category_id=-1)
        self.assertEqual(wr.office_category_description, [u'en:ENG', u'ru:РУС'])
        self.assertEqual(wr.names, [u'en:ENG', u'ru:РУС'])
        self.assertIsInstance(wr.city, models.geo.City)
        self.assertEquals(wr.city.city_id, -1)

    def test_office_category_save(self):
        register_cities()
        m = models.office.OfficeCategory()
        m.office_category_id = -10
        m.office_category_description = [u'en:ENG', u'ru:РУС']
        m.names = [u'en:ENG', u'ru:РУС']
        m.city = models.geo.City.load(city_id=-1)
        m.save()
        m.reload()
        self.assertNotEqual(m.office_category_id, None)
        self.assertEqual(m.office_category_description, [u'en:ENG', u'ru:РУС'])
        self.assertEqual(m.names, [u'en:ENG', u'ru:РУС'])
        self.assertIsInstance(m.city, models.geo.City)
        self.assertEquals(m.city.city_id, -1)

    def test_office_load(self):
        models.office.OfficeCategoryVocabulary().register()
        register_airports()
        models.office.OfficeTravelOptionVocabulary().register()
        models.office.TravelOptionByOffice().register()
        models.office.OfficeTravelOptionType.register()

        dbquery("insert into offices (office_id, names,office_description, email,fax, phone, lat, lon, address, working_time,\
                                      in_airport, insurance_policy, noncash_booking, new_office, airport_id,\
                                      distance_to_airport, office_category_id, location_map, transfer_time_public,\
                                      transfer_time_automobile, transfer_time_foot,important_info)\
                               values(-1,  'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 99.99, 99.99,\
                                      'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, -3, 123, -3,\
                                      'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123, '');")

        wr = models.office.Office.load(office_id=-1)
        self.assertEqual(wr.names, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(wr.office_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(wr.email, ['some@some.ru'])
        self.assertEqual(wr.fax, ['812-111-11-11'])
        self.assertEqual(wr.phone, ['812-111-11-11'])
        self.assertEqual(wr.lat, 99.99)
        self.assertEqual(wr.lon, 99.99)
        self.assertEqual(wr.address, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(wr.worktime, [u'en:Eng', u'ru:Рус'])
        self.assertTrue(wr.in_airport)
        self.assertTrue(wr.insurance_policy)
        self.assertTrue(wr.noncash_booking)
        self.assertTrue(wr.new_office)
        self.assertIsInstance(wr.airport, models.airport.Airport)
        self.assertEqual(wr.airport.airport_id, -3)
        self.assertEqual(wr.distance_to_airport, 123)
        self.assertIsInstance(wr.office_category, models.office.OfficeCategory)
        self.assertEqual(wr.office_category.office_category_id, -3)
        self.assertEqual(wr.location_map, [u'ru:http://some.ru/ru.jpg', u'en:http://some.ru/en.jpg'])
        self.assertEqual(wr.transfer_time_public, 123)
        self.assertEqual(wr.transfer_time_automobile, 123)
        self.assertEqual(wr.transfer_time_foot, 123)

        travels = getI('travel_option_by_office_idx')(-3)
        self.assertEqual(len(travels), 1)

        dbquery(u"insert into office_travel_options (office_travel_option_id, office_id,travel_type,\
                                                     office_travel_option_description,travel_time) \
                                             values (-1, -1, 'F', 'en:Eng|ru:Рус', 123)")

        travels = getI('travel_option_by_office_idx')(wr.office_id)
        self.assertEqual(len(travels), 0)
        self.assertEquals(len(wr.travel_options), len(travels))

        getV('office_travel_options')._reload()
        getI('travel_option_by_office_idx')._reindex()

        travels = getI('travel_option_by_office_idx')(wr.office_id)
        self.assertEqual(len(travels), 1)
        self.assertEquals(len(wr.travel_options), len(travels))
        travel_option = wr.travel_options[0]
        self.assertEquals(travel_option.office_travel_option_description, [u'en:Eng', u'ru:Рус'])
        self.assertEquals(travel_option.travel_type, getV('office_travel_option_types')['F'])

    def test_office_save(self):
        models.office.OfficeCategoryVocabulary().register()
        register_airports()
        models.office.OfficeTravelOptionVocabulary().register()
        models.office.TravelOptionByOffice().register()
        models.office.OfficeTravelOptionType.register()
        m = models.office.Office()
        m.office_id = -1
        m.office_description = [u'en:Eng', u'ru:Рус']
        m.names = [u'en:Eng', u'ru:Рус']
        m.email = [u'xxx@yyy.zz', u'2xxx@yyy.zz']
        m.fax = [u'9999', u'8888']
        m.phone = [u'7777', u'6666']
        m.lat = +77.12
        m.lot = -99.11
        m.address = [u'en:Eng', u'ru:Рус']
        m.worktime = [u'en:Eng', u'ru:Рус']
        m.in_airport = True
        m.airport = getV('airports')[-3]
        m.distance_to_airport = 123
        m.insurance_policy = True
        m.noncash_booking = True
        m.new_office = True
        m.office_category = getV('office_categories')[-3]
        m.location_map = [u'ru:http://some.ru/ru.jpg', u'en:http://some.ru/en.jpg']
        m.transfer_time_public = 123
        m.transfer_time_automobile = 123
        m.transfer_time_foot = 123
        m.office_weight = 0
        m.office_weight = 123
        m.save()
        m.reload()
        self.assertNotEqual(m.office_id, None)
        self.assertEqual(m.worktime, [u'en:Eng', u'ru:Рус'])

        self.assertEquals(m.travel_options, [])
        travels = getI('travel_option_by_office_idx')(m.office_id)
        self.assertEqual(len(travels), 0)
        m.travel_options = [OfficeTravelOption(office_travel_option_id=-4,
                                               office_id=-1,
                                               travel_type=getV('office_travel_option_types')['F'],
                                               office_travel_option_description=['en:Eng', 'ru:Рус'],
                                               travel_time=123)]

        travels = getI('travel_option_by_office_idx')(m.office_id)
        self.assertEqual(len(travels), 1)

    def test_office_json(self):
        models.office.OfficeCategoryVocabulary().register()
        register_airports()
        models.office.OfficeTravelOptionVocabulary().register()
        models.office.TravelOptionByOffice().register()
        models.office.OfficeTravelOptionType.register()
        models.office.OfficesVocabulary().register()
        ap = getV('offices')[-3]
        d = ap.as_primitive()
        self.assertEquals(d['class'], 'Office')
        self.assertEquals(d['office_id'], -3)
        self.assertEqual(d['address'], [u'en:Eng', u'ru:Рус'])
        self.assertEqual(d['airport'], u'ZZZ')
        self.assertEquals(d['distance_to_airport'], 123)
        self.assertEquals(d['fax'], [u'812-111-11-11'])
        self.assertEquals(d['phone'], [u'812-111-11-11'])
        self.assertEquals(d['in_airport'], True)
        self.assertEquals(d['insurance_policy'], True)
        self.assertEquals(d['new_office'], True)
        self.assertEquals(d['noncash_booking'], True)
        self.assertEquals(d['lat'], 99.99)
        self.assertEquals(d['lon'], 99.99)
        self.assertEquals(d['office_category'], -3)
        self.assertEquals(d['transfer_time_automobile'], 123)
        self.assertEquals(d['transfer_time_foot'], 123)
        self.assertEquals(d['transfer_time_public'], 123)
        self.assertEquals(d['office_description'], [u'en:Eng', u'ru:Рус'])
        self.assertEquals(d['location_map'], [u'ru:http://some.ru/ru.jpg', u'en:http://some.ru/en.jpg'])
        self.assertEquals(d['worktime'], [u'en:Eng', u'ru:Рус'])
        self.assertEqual(d['travel_options'], [{'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                                                'office_travel_option_id': -3,
                                                'travel_time': 123,
                                                'travel_type': u'F'}])

        d2 = as_primitive(ap)
        self.assertEqual(d, d2)

    def test_meal_type_load(self):
        dbquery("insert into meal_types (meal_type, names) values ('Z','ru:Россия 1|en:Russia 1')")
        wr = models.meal.MealType.load(mealtype=u'Z')
        self.assertEqual(wr.names, [u'ru:Россия 1', u'en:Russia 1'])

    def test_meal_type_save(self):
        m = models.meal.MealType()
        m.mealtype = 'W'
        m.names = [u'ru:Россия 1', u'en:Russia 1']
        m.save()
        m.reload()
        self.assertNotEqual(m.mealtype, None)
        self.assertEqual(m.names, [u'ru:Россия 1', u'en:Russia 1'])

    def test_redemption_zone_load(self):
        dbquery("insert into redemption_zones (redemption_zone, names) values ('ZZ','ru:Россия 1|en:Russia 1')")
        wr = models.bonus.RedemptionZone.load(redemption_zone=u'ZZ')
        self.assertEqual(wr.names, [u'ru:Россия 1', u'en:Russia 1'])

    def test_redemption_zone_save(self):
        models.bonus.CarrierVocabulary.register()
        m = models.bonus.RedemptionZone()
        m.redemption_zone = 'WW'
        m.names = [u'ru:Атлантида', u'en:Atlantis']
        m.carrier = getV('carriers')['A']
        m.save()
        m.reload()
        self.assertNotEqual(m.redemption_zone, None)
        self.assertEqual(m.names, [u'ru:Атлантида', u'en:Atlantis'])

    def test_tier_levels_load(self):
        dbquery(
            "insert into tier_levels (tier_level,names,ordering,miles,segments,business_segments) values ('ZZ','ru:Золотой|en:Gold',10,100,3,2)")
        ob = models.bonus.TierLevel.load(tier_level='ZZ')
        self.assertEqual(ob.names, [u'ru:Золотой', u'en:Gold'])
        self.assertEqual(ob.ordering, 10)
        self.assertEqual(ob.miles, 100)
        self.assertEqual(ob.segments, 3)
        self.assertEqual(ob.business_segments, 2)

    def test_teir_levels_save(self):
        m = models.bonus.TierLevel()
        m.tier_level = u'WW'
        m.names = [u'ru:Золотой', u'en:Gold']
        m.ordering = 10
        m.miles = 100
        m.segments = 3
        m.business_segments = 4
        m.save()
        m.reload()
        self.assertNotEqual(m.tier_level, None)
        self.assertEqual(m.names, [u'ru:Золотой', u'en:Gold'])
        self.assertEqual(m.ordering, 10)
        self.assertEqual(m.miles, 100)
        self.assertEqual(m.segments, 3)
        self.assertEqual(m.business_segments, 4)

    def test_tier_level_factor_load(self):
        models.air.AirlinesVocabulary.register()
        models.bonus.TierLevelVocabulary.register()
        ob = models.bonus.TierLevelFactor.load(tier_level_factor_id=-1)
        self.assertEqual(ob.airline, getV('airlines')[-1])
        self.assertEqual(ob.tier_level, getV('tier_levels')['TR'])
        self.assertEqual(ob.factor, 1.23)

    def test_tier_level_factor_save(self):
        models.air.AirlinesVocabulary.register()
        models.bonus.TierLevelVocabulary.register()
        m = models.bonus.TierLevelFactor(tier_level_factor_id=-2)
        m.airline = getV('airlines')[-1]
        m.tier_level = getV('tier_levels')['TR']
        m.factor = 1.23
        m.save()
        m.reload()
        self.assertNotEqual(m.tier_level_factor_id, None)
        self.assertEqual(m.airline, getV('airlines')[-1])
        self.assertEqual(m.tier_level, getV('tier_levels')['TR'])
        self.assertEqual(m.factor, 1.23)

    def test_pair_load(self):
        models.air.AirlinesVocabulary.register()
        register_airports()
        dbquery(
            "insert into pairs (pair_id, airline_id, airport_from_id, airport_to_id, miles, no_spending) values (-1, -1, -3, -4, 12345, TRUE)")
        ob = models.route.Pair.load(pair_id=-1)
        self.assertEqual(ob.airline, getV('airlines')[-1])
        self.assertEqual(ob.airport_from, getV('airports')[-3])
        self.assertEqual(ob.airport_to, getV('airports')[-4])
        self.assertEqual(ob.miles, 12345)
        self.assertEqual(ob.no_spending, True)

    def test_pair_save(self):
        models.air.AirlinesVocabulary.register()
        register_airports()
        m = models.route.Pair()
        m.pair_id = -2
        m.airline = getV('airlines')[-1]
        m.airport_from = getV('airports')[-3]
        m.airport_to = getV('airports')[-4]
        m.miles = 9991
        m.no_spending = True
        m.save()
        m.reload()
        self.assertNotEqual(m.pair_id, None)
        self.assertEqual(m.miles, 9991)
        self.assertEqual(m.airline, getV('airlines')[-1])
        self.assertEqual(m.airport_from, getV('airports')[-3])
        self.assertEqual(m.airport_to, getV('airports')[-4])
        self.assertEqual(m.no_spending, True)

    def test_wrong_route_load(self):
        register_cities()
        dbquery(
            "insert into wrong_routes (wrong_route_id, city_from_id, city_via_id, city_to_id) values (-1, -1, -3, -2)")
        ob = models.route.WrongRoute.load(wrong_route_id=-1)
        self.assertEqual(ob.city_via.id, '-3')

    def test_world_region_load(self):
        dbquery("insert into world_regions (world_region_id, names) values (-2, 'ru:Атлантида|en:Atlantis')")
        wr = models.geo.WorldRegion.load(world_region_id=-2)
        self.assertEqual(wr.names, [u'ru:Атлантида', u'en:Atlantis'])

    def test_world_region_save(self):
        m = models.geo.WorldRegion()
        m.world_region_id = -2
        m.names = [u'ru:Атлантида', u'en:Atlantis']
        m.save()
        m.reload()
        self.assertNotEqual(m.world_region_id, None)
        self.assertEqual(m.names, [u'ru:Атлантида', u'en:Atlantis'])

    def test_country_load(self):
        dbquery(
            "insert into countries (country, iso_code3, names, telephone_code, use_in_siebel, currency_alpha3_code) values ('XU', 'XUS', 'ru:Россия|en:Russia',123, True, 'RUR')")
        c = models.geo.Country.load(iso_code2='XU')
        self.assertTrue(u'ru:Россия' in c.names)

    def test_country_save(self):
        models.geo.WorldRegionsVocabulary().register()
        models.currency.CurrenciesVocabulary().register()
        register_cities()
        m = models.geo.Country()
        m.iso_code2 = u'XX'
        m.iso_code3 = u'XXX'
        m.names = [u'ru:Атлантида', u'en:Atlantis']
        m.telephone_code = 999
        m.use_in_siebel = True
        m.currency = getV('currencies')['RUR']
        m.pcc_code = 'UUU'
        m.station_code = '12345678'
        m.corporate_station_code = '987456321'
        m.corporate_pcc_code = 'UUU'
        m.corporate_currency = getV('currencies')['RUR']
        m.capital = getV('cities')[-1]
        m.save()
        m.reload()
        self.assertNotEqual(m.iso_code2, None)
        self.assertEqual(m.names, [u'ru:Атлантида', u'en:Atlantis'])

    def test_city_load(self):
        register_airports()
        register_cities()

        c = models.geo.City.load(city_id=-1)
        self.assertEqual(c.iata, u'ZZZ')
        self.assertEqual(c.lat, 45.8192)
        self.assertEqual(c.lon, 45.0917)
        self.assertEqual(c.can_book, False)

        c = models.geo.City.load(city_id=-2)
        self.assertEqual(c.iata, u'ZZX')

    def test_city_save(self):
        models.geo.CountriesVocabulary().register()
        m = models.geo.City()
        m.city_id = -2
        m.country_code = u'XX'
        m.tz = u'UTC+5'
        m.iata = u'XYZ'
        m.lat = 56.819166676667
        m.lon = 45.091666676667
        m.radius = 6
        m.can_book = False
        m.names = [u'ru:Атлантида', u'en:Atlantis']
        m.save()
        m.reload()
        self.assertNotEqual(m.city_id, None)
        self.assertEqual(m.names, [u'ru:Атлантида', u'en:Atlantis'])

    def test_city_json(self):
        register_cities()

        c = getV('cities')[-1]
        d = c.as_primitive()
        self.assertEqual(d['class'], 'City')
        self.assertEqual(d['city_id'], -1)
        self.assertEqual(d['iata'], u'ZZZ')
        self.assertEqual(d['country_code'], u'XX')
        self.assertEqual(d['names'], [u'ru:Улетаево'])
        self.assertEqual(d['tz'], u'UTC+4')
        self.assertEqual(d['lat'], 45.8192)
        self.assertEqual(d['lon'], 45.0917)
        self.assertEqual(d['can_book'], False)

        d2 = as_primitive(c)
        self.assertEqual(d, d2)

    def test_airport_load(self):
        ap = models.airport.Airport.load(airport_id=-3)
        self.assertEqual(ap.iata, 'ZZZ')
        self.assertEqual(ap.has_afl_flights, False)
        self.assertEqual(ap.has_upgrade_on_checkin_award, True)

        #        self.assertEqual(ap.terminals, set())
        #
        #        dbquery("insert into airport_terminals (terminal_id, airport_id, code, names) values (-5, -3, 'L', 'ru:Терминал L')")
        #
        #        ap.load_terminals()
        #        self.assertEqual(len(ap.terminals), 2)
        #        self.assertEqual(ap.terminals[0], u'L ru:Терминал L')
        #
        #        ap.terminals[0] = u'L en:Term L'
        #        ap.terminals[1] = u'X1 en:Terminal X1'
        #        ap.save_terminals()
        #        rows = dbquery("select terminal_id, airport_id, code, names from airport_terminals where airport_id=-3").fetchall()
        #        self.assertEqual(len(rows), 2)
        #        self.assertEqual(rows[0], (-5, -3, u'L', u'en:Term L'))
        #        self.assertEqual(rows[1][3], u'en:Terminal X1')
        #
        #        ap.load_terminals()
        #        del ap.terminals[0]
        #        ap.save_terminals()
        #        rows = dbquery("select terminal_id, airport_id, code, names from airport_terminals where airport_id=-3").fetchall()
        #        self.assertEqual(len(rows), 1)
        #        self.assertEqual(rows[0][3], u'en:Terminal X1')
        #
        #        self.assertFalse(ap.terminals_differ_from_db())
        #        ap.terminals[0] = u'XX en:Terminal XX'
        #        self.assertTrue(ap.terminals_differ_from_db())
        #
        #
        #        ap_v = models.geo.AirportsVocabulary()
        #        self.assertEqual(ap_v[-3].terminals, set(['X1 en:Terminal X1']))
        #
        #        ap.delete()
        #        rows = dbquery("select count(*) from airports where airport_id=-3").fetchone()
        #        self.assertEqual(rows[0], 0)
        #        rows = dbquery("select count(*) from airport_terminals where airport_id=-3").fetchone()
        #        self.assertEqual(rows[0], 0)

        register_airports()
        models.airport.AirportTerminalsVocabulary().register()
        models.airport.TerminalsByAirport().register()

        getI('terminals_by_airport_idx')._reindex()
        terminals = getI('terminals_by_airport_idx')(ap.airport_id)
        self.assertEqual(len(terminals), 1)
        ap = getV('airports')[-3]

        terminals = getI('terminals_by_airport_idx')(ap.airport_id)
        self.assertEqual(len(terminals), 1)

        dbquery(
            "insert into airport_terminals (terminal_id, airport_id, code, names) values (-2, -3, 'X', 'ru:Терминал X')")
        getV('airport_terminals')._reload()
        getI('terminals_by_airport_idx')._reindex()

        terminals = getI('terminals_by_airport_idx')(ap.airport_id)
        self.assertEqual(len(terminals), 2)

        ap.terminals = [AirportTerminal(terminal_id=-5, code='A1', names=['ru:Terminal A1'])]
        self.assertEqual(ap.terminals[0].terminal_id, -5)
        self.assertEqual(ap.terminals[0].airport_id, ap.airport_id)
        terminals = getI('terminals_by_airport_idx')(ap.airport_id)
        self.assertEqual(len(terminals), 1)

        ap.terminals = [AirportTerminal(terminal_id=-6, code='A2', names=['ru:Terminal A2']),
                        AirportTerminal(terminal_id=-7, code='A3', names=['ru:Terminal A3'])]
        terminals = getI('terminals_by_airport_idx')(ap.airport_id)
        self.assertEqual(len(terminals), 2)

    def test_airport_save(self):
        register_cities()
        models.bonus.RedemptionZonesVocabulary().register()
        models.airport.AirportTerminalsVocabulary().register()
        models.airport.TerminalsByAirport().register()
        m = models.airport.Airport()
        m.airport_id = -5
        m.iata = u'XYZ'
        m.icao = u'1234'
        m.city = models.geo.City.load(city_id=-1)
        m.has_afl_flights = True
        m.has_upgrade_on_checkin_award = True
        m.terminals = [AirportTerminal(terminal_id=-8, code='A2', names=['ru:Terminal A2']),
                       AirportTerminal(terminal_id=-9, code='A3', names=['ru:Terminal A3'])]
        m.names = [u'ru:Аэропорт 1', u'en:Airoport 1']

        self.test_redemption_zone_load()
        m.redemption_zone = models.bonus.RedemptionZone.load(redemption_zone='ZZ')
        m.save()
        m.reload()
        self.assertNotEqual(m.airport_id, None)
        self.assertEqual(m.names, [u'ru:Аэропорт 1', u'en:Airoport 1'])

    def test_airport_json(self):
        models.geo.WorldRegionsVocabulary().register()
        register_cities()
        register_airports()
        models.airport.AirportTerminalsVocabulary().register()
        models.airport.TerminalsByAirport().register()
        models.airport.TerminalsByAirport().register()
        models.bonus.RedemptionZonesVocabulary().register()

        ap = getV('airports')[-3]
        d = ap.as_primitive()
        self.assertEqual(d['city'], -1)
        self.assertEqual(d['class'], 'Airport')
        self.assertEqual(d['iata'], 'ZZZ')
        self.assertEqual(d['terminals'], [{'code': 'Z', 'names': [u'ru:Терминал Z']}])
        self.assertEqual(d['afl_redemption_zone'], 'WW')
        self.assertEqual(d['skyteam_redemption_zone'], None)
        self.assertEqual(d['has_upgrade_on_checkin_award'], True)

        d2 = as_primitive(ap)
        self.assertEqual(d, d2)

    def test_airline_load(self):
        register_airports()
        models.geo.CountriesVocabulary().register()
        models.air.MilesLimitationsVocabulary.register()
        dbquery(
            "insert into airlines (airline_id, iata, icao, callsign, country, airport_id, names, alliance,  url, weight, miles_minimum, miles_limitation, miles_earn_description, miles_earn_comment) values "
            "(-3, 'Z1', 'XZA', 'XZ AIR', 'XX', -3, 'ru:ХЗ-Аэро', 'Skyteam', 'ru:http://yandex.ru/|en:http://yandex.us/', 3, 100.5, 'I', 'en:Earning is easy!', 'en:just try')")
        ob = models.air.Airline.load(airline_id=-3)
        self.assertEqual(ob.iata, 'Z1')
        self.assertEqual(ob.icao, 'XZA')
        self.assertEqual(ob.callsign, 'XZ AIR')
        self.assertEqual(ob.country.iso_code2, 'XX')
        self.assertEqual(ob.airport.airport_id, -3)
        self.assertEqual(ob.names, [u'ru:ХЗ-Аэро'])
        self.assertEqual(ob.alliance, 'Skyteam')
        self.assertEqual(ob.url, [u'ru:http://yandex.ru/', u'en:http://yandex.us/'])
        self.assertEqual(ob.weight, 3)
        self.assertEqual(ob.miles_minimum, 100.5)
        self.assertEqual(ob.miles_limitation.token, 'I')
        self.assertEqual(ob.miles_earn_description, [u'en:Earning is easy!'])
        self.assertEqual(ob.miles_earn_comment, [u'en:just try'])

    def test_airline_save(self):
        models.air.AirlinesVocabulary().register()
        register_airports()
        models.geo.CountriesVocabulary().register()
        models.air.MilesLimitationsVocabulary.register()
        models.member.LoyaltyProgramVocabulary.register()

        ob = models.air.Airline()
        ob.airline_id = -4
        ob.iata = u'QQQ'
        ob.icao = u'WWW'
        ob.callsign = u'QQWW'
        ob.country = models.geo.Country.load(iso_code2=u'XX')
        ob.city = models.airport.Airport.load(airport_id=-3)
        ob.names = [u'ru:Авиакомпания 1', u'en:Airline 1']
        ob.weight = 10
        ob.miles_minimum = 100.5
        ob.miles_limitation = getV('miles_limitations')['I']
        ob.miles_earn_description = [u'en:Earning is easy!']
        ob.miles_earn_comment = [u'en:just try']
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.airline_id, None)
        self.assertEqual(ob.names, [u'ru:Авиакомпания 1', u'en:Airline 1'])

    def test_airline_parent_airline(self):
        register_airports()
        models.air.AirlinesVocabulary().register()
        models.geo.CountriesVocabulary().register()
        models.air.MilesLimitationsVocabulary.register()
        models.member.LoyaltyProgramVocabulary.register()

        ob = models.air.Airline.load(airline_id=-2)
        self.assertTrue(isinstance(ob.parent_airline, int))
        self.assertEqual(ob.parent_airline, -1)

        ob = models.air.Airline.load(airline_id=-1)
        self.assertEqual(ob.parent_airline, None)

        ob = models.air.Airline()
        ob.airline_id = -5
        ob.iata = u'AAA'
        ob.icao = u'BBB'
        ob.callsign = u'ZXCV'
        ob.country = models.geo.Country.load(iso_code2=u'XX')
        ob.names = [u'ru:Авиакомпания 5', u'en:Airline 5']
        ob.parent_airline = models.air.Airline.load(airline_id=-2).airline_id
        ob.weight = 10
        ob.miles_minimum = 1000.0
        ob.miles_limitation = getV('miles_limitations')['A']
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.airline_id, None)
        self.assertEqual(ob.names, [u'ru:Авиакомпания 5', u'en:Airline 5'])
        self.assertTrue(isinstance(ob.parent_airline, int))
        self.assertEqual(ob.parent_airline, -2)

    def test_aircraft_type_load(self):
        dbquery(("insert into aircraft_types "
                 "(aircraft_type_id,ohd_code,iata,icao,pax_capacity,cargo_capacity,f,c,y,names) "
                 "values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"),
                -1, 'OoOo', None, 'XYZ0', 100, 30, 70, 20, 10, 'en:Boeing 797')
        a_type = models.air.AircraftType.load(aircraft_type_id=-1)
        self.assertEqual(a_type.ohd_code, 'OoOo')
        self.assertEqual(a_type.iata, None)
        self.assertEqual(a_type.icao, 'XYZ0')
        self.assertEqual(a_type.pax_capacity, 100)

        models.air.AircraftTypesVocabulary().register()

    def test_aircraft_type_save(self):
        m = models.air.AircraftType()
        m.aircraft_type_id = -2
        m.ohd_code = u'OoOo'
        m.iata = u'ITA'
        m.icao = u'ICA'
        m.pax_capacity = 99
        m.cargo_capacity = 99
        m.f = 33
        m.c = 33
        m.y = 33
        m.names = [u'ru:Боинг 999', u'en:Boeing 999']
        m.save()
        m.reload()
        self.assertNotEqual(m.aircraft_type_id, None)
        self.assertEqual(m.names, [u'ru:Боинг 999', u'en:Boeing 999'])

    def test_tariff_group_load(self):
        from rx.i18n.translation import SelfTranslationDomain
        models.service_classes.SkyTeamServiceClassVocabulary(
        ).register()
        tg = models.bonus.TariffGroup.load(id_field='-1')
        td = SelfTranslationDomain()
        self.assertEqual(
            td.translate(tg.title.msgid, target_language="ru"),
            u"Первый: ruYYY"
        )
        self.assertEqual(
            td.translate(tg.title.msgid, target_language="en"),
            u"Первый: enYYY"
        )

    def test_tariff_group_vocab_load(self):
        models.bonus.TariffGroupsVocabulary().register()
        self.assertIn('-1', getV('tariff_groups'))

    def test_tariff_group_json(self):
        models.bonus.TariffGroupsVocabulary().register()

        tg = getV('tariff_groups')[-1]
        d = tg.as_primitive()
        self.assertEqual(d['class'], u'TariffGroup')
        self.assertEqual(d['service_class'], -1)
        self.assertEqual(d['tariff_group'], u'xxxxxxx-yyyyyyy')
        self.assertEqual(d['id_field'], -1)
        self.assertEqual(d['names'], [u'en:enYYY', u'ru:ruYYY'])

        d2 = as_primitive(tg)
        self.assertEqual(d, d2)

    def test_tariff_group_save(self):
        models.service_classes.SkyTeamServiceClassVocabulary().register()
        m = models.bonus.TariffGroup()
        m.id_field = 2
        m.tariff_group = 'xxxxxxx-zzzzzzz'
        m.service_class = models.service_classes.SkyTeamServiceClass.load(
            skyteam_sc_id=-1
        )
        m.save()
        m.reload()

    def test_airline_tariff_group_load(self):
        from rx.i18n.translation import SelfTranslationDomain
        models.service_classes.SkyTeamServiceClassVocabulary(
        ).register()
        models.service_classes.AirlineServiceClassVocabulary(
        ).register()
        models.air.AirlinesVocabulary(
        ).register()
        models.bonus.TariffGroupsVocabulary(
        ).register()
        tg = models.bonus.AirlineTariffGroup.load(idField='-1')
        td = SelfTranslationDomain()
        self.assertEqual(
            td.translate(tg.title.msgid, target_language="ru"),
            u"Авиакомпания 1: Первый: ruYYY: 0"
        )
        self.assertEqual(
            td.translate(tg.title.msgid, target_language="en"),
            u"Airline 1: Первый: enYYY: 0"
        )

    def test_airline_tariff_group_vocab(self):
        models.bonus.AirlineTariffGroupsVocabulary(
        ).register()
        self.assertIn(-1, getV("airline_tariff_groups"))

    def test_airline_service_class_load(self):
        from rx.i18n.translation import SelfTranslationDomain
        models.service_classes.SkyTeamServiceClassVocabulary(
        ).register()
        models.air.AirlinesVocabulary(
        ).register()
        asc = models.service_classes.AirlineServiceClass.load(
            airline_sc_id='-1'
        )
        td = SelfTranslationDomain()
        self.assertEqual(
            td.translate(asc.title.msgid, target_language="ru"),
            u"Авиакомпания 1: Первый"
        )
        self.assertEqual(
            td.translate(asc.title.msgid, target_language="en"),
            u"Airline 1: Первый"
        )

    def test_airline_service_class_vocab(self):
        models.service_classes.AirlineServiceClassVocabulary(
        ).register()
        self.assertIn(-1, getV("airline_service_classes"))

    def test_award_load(self):
        models.service_classes.SkyTeamServiceClassVocabulary.register()
        models.bonus.BonusRoutesVocabulary.register()
        models.service_classes.CommentVocabulary.register()
        models.bonus.AwardTypesVocabulary.register()
        ob = models.bonus.Award.load(award_id=-1)
        self.assertEqual(ob.type, getV('award_types')['OW'])
        self.assertEqual(ob.service_classes_1, getV('skyteam_service_classes')[-1])
        self.assertEqual(ob.service_classes_2, getV('skyteam_service_classes')[-2])
        self.assertEqual(ob.award_value, 123)
        self.assertEqual(ob.route, getV('bonus_routes')[-1])
        self.assertEqual(ob.comment, getV('comments')[-1])

    def test_award_save(self):
        models.service_classes.SkyTeamServiceClassVocabulary.register()
        models.bonus.BonusRoutesVocabulary.register()
        models.service_classes.CommentVocabulary.register()
        models.bonus.AwardTypesVocabulary.register()
        m = models.bonus.Award()
        m.award_id = -10
        m.names = ['ru:Рус', 'en:Eng']
        m.type = getV('award_types')['OW']
        m.service_classes_1 = getV('skyteam_service_classes')[-1]
        m.award_value = 123
        m.route = getV('bonus_routes')[-1]
        m.comment = getV('comments')[-1]
        m.save()
        m.reload()
        self.assertNotEqual(m.award_id, None)
        self.assertEqual(m.names, ['ru:Рус', 'en:Eng'])
        self.assertEqual(m.type, getV('award_types')['OW'])
        self.assertEqual(m.service_classes_1, getV('skyteam_service_classes')[-1])
        self.assertIsNone(m.service_classes_2)
        self.assertEqual(m.award_value, 123)
        self.assertEqual(m.route, getV('bonus_routes')[-1])
        self.assertEqual(m.comment, getV('comments')[-1])

    def test_skyteam_service_class_load(self):
        sc = models.service_classes.SkyTeamServiceClass.load(
            skyteam_sc_id=-1
        )
        self.assertEquals(sc.skyteam_sc_id, -1)
        self.assertEquals(sc.code, "xx")
        self.assertEquals(sc.names, [u"ru:Первый"])
        self.assertEquals(sc.weight, 10)

    def test_skyteam_service_class_save(self):
        models.service_classes.ServiceClassClassificationLevelVocabulary.register()
        sc = models.service_classes.SkyTeamServiceClass(
            skyteam_sc_id=-3,
            code="uuu",
            names=[u"ru:Третий"],
            weight=30,
            classification_level=getV('service_class_classification_levels')['B']
        )
        sc.save()
        sc.reload()
        self.assertEquals(sc.skyteam_sc_id, -3)
        self.assertEquals(sc.code, "uuu")
        self.assertEquals(sc.names, [u"ru:Третий"])
        self.assertEquals(sc.weight, 30)
        self.assertEquals(ITokenizedTerm(sc.classification_level).token, u'B')

    def test_special_offers_load(self):
        sp = models.special_offer.SpecialOffer.load(offer_id=-1)
        self.assertEqual(sp.names, [u'en:Super special offer', u'ru:Мега специальное предложение'])

    def test_special_offers_save(self):
        models.partner.PartnerVocabulary().register()
        models.special_offer.SpecialOfferStatusVocabulary.register()

        ob = models.special_offer.SpecialOffer()
        ob.offer_id = -2
        ob.partner = models.partner.Partner.load(partner_id=-1)
        ob.names = [u'en:Sp', u'ru:Сп']
        ob.status = getV('special_offers_statuses')['P']
        ob.offer_description = [u'en:Sp text', u'ru:Сп текст']
        ob.offer_url = [u'en:some_url.com', u'ru:some_url.ru']
        ob.ui_languages = [u'en,ru']

        ob.save()
        ob.reload()

        self.assertEqual(ob.offer_id, -2)
        self.assertNotEqual(ob.status, None)
        self.assertEqual(ob.ui_languages, [u'en', u'ru'])

    def test_special_offers_json(self):

        models.special_offer.SpecialOfferVocabulary.register()

        so = getV('special_offers')[-1]
        d = so.as_primitive()

        self.assertEqual(d['class'], 'SpecialOffer')
        self.assertEqual(d['offer_id'], -1)
        self.assertEqual(d['names'], [u'en:Super special offer', u'ru:Мега специальное предложение'])
        self.assertEqual(d['offer_description'],
                         [u'en:Super special offer description', u'ru:Описание мега специального предложения'])
        self.assertEqual(d['status'], u'P')
        self.assertEqual(d['begin_date'], None)
        self.assertEqual(d['end_date'], None)
        self.assertEqual(d['offer_url'], [u'ru:http://ya.ru'])
        self.assertEqual(d['ui_languages'], [u'en', u'ru'])
        self.assertEqual(d['partner'], -1)

        d2 = as_primitive(so)
        self.assertEqual(d, d2)

    def test_title(self):
        from models.geo import WorldRegion
        from rx.i18n.translation import SelfTranslationDomain, self_translated

        def translate(s): return SelfTranslationDomain().translate(s, target_language='ru')

        wr = WorldRegion(world_region_id=1, names=[u'ru:Африка'])
        self.assertEqual(translate(wr.title.msgid), u'Африка')

    def test_text_line_list(self):
        from models.ml import TextLineList
        tll = TextLineList(db_column='list', separator=',')
        self.assertEqual(tll.fromUnicode(u'aaa\nbbb'), [u'aaa', u'bbb'])
        self.assertRaises(ConstraintNotSatisfied, tll.fromUnicode, 'aa,a\nbbb')

        self.assertEqual(tll.toUnicode([u'ddd', u'eee']), u'ddd\neee')
        self.assertRaises(ConstraintNotSatisfied, tll._validate, [u'ddd', u'ee,e'])

    def test_ml_names(self):
        from models.ml import MLNames
        names = MLNames(db_column='names')
        self.assertEqual(names.fromUnicode(u'ru:Москва\nen:Moscow'), [u'ru:Москва', 'en:Moscow'])
        # self.assertRaises(ConstraintNotSatisfied, names.fromUnicode, 'missing-semicolon')

        self.assertEqual(names.toUnicode([u'ru:Москва', 'en:Moscow']), u'ru:Москва\nen:Moscow')

        self.assertRaises(WrongContainedType, names.validate, [u'en:Moscow\nRussia'])

    def test_ml_text(self):
        from models.ml import MLText
        txt = MLText(db_column='txt')
        self.assertEqual(txt.fromUnicode(u'ru:Москва\nРоссия\ten:Moscow\nRussia'),
                         [u'ru:Москва\nРоссия', 'en:Moscow\nRussia'])

        self.assertEqual(txt.toUnicode([u'ru:Москва\nРоссия', 'en:Moscow\nRussia']),
                         u'ru:Москва\nРоссия\ten:Moscow\nRussia')

        self.assertRaises(WrongContainedType, txt.validate, [u'en:Moscow\tRussia'])

    def test_tz_field(self):
        from models.tzname import TZName
        tzf = TZName(db_column='tz')
        self.assertTrue(tzf.constraint('UTC'))
        self.assertTrue(tzf.constraint('europe/moscow'))
        self.assertFalse(tzf.constraint('xxxzzz'))

        self.assertTrue(tzf.constraint('UTC+1'))
        self.assertTrue(tzf.constraint('UTC+01:30'))
        self.assertTrue(tzf.constraint('UTC-1'))
        self.assertFalse(tzf.constraint('UTC*1'))
        self.assertTrue(tzf.constraint('UTC-04:00'))
        self.assertFalse(tzf.constraint('UTC-xx'))
        self.assertFalse(tzf.constraint('UTC-04:xx'))
        self.assertFalse(tzf.constraint('UTC-04:60'))
        self.assertFalse(tzf.constraint('UTC-24:00'))

    def test_code_field(self):
        from models.uppercase import CodeTextLine
        f = CodeTextLine(db_column='code', required=False)
        self.assertEqual(f.fromUnicode(u'aaa'), u'AAA')
        self.assertEqual(f.fromUnicode(u''), None)

    def test_filename_field(self):
        field = FilenameField(db_column='column')
        self.assertTrue(field.constraint(''))
        self.assertTrue(field.constraint('w'))
        self.assertFalse(field.constraint('w\n'))
        self.assertFalse(field.constraint('4w'))
        self.assertFalse(field.constraint('w%'))
        self.assertFalse(field.constraint('ф'))

    def test_json_condition(self):
        a = JSONCondition()
        self.assertEqual(a.widget_attrs(None), {'cols': '80', 'rows': '6', 'wrap': 'off'})

    def test_validate_json_condition(self):
        with self.assertRaises(ValidationError):
            validate_json_condition(None)
        with self.assertRaises(ValidationError):
            validate_json_condition(u'')
        with self.assertRaises(ValidationError):
            validate_json_condition(u'{')
        with self.assertRaises(ValidationError):
            validate_json_condition(u'{}')
        with self.assertRaises(ValidationError):
            validate_json_condition(u'["text"]')
        self.assertIsNone(validate_json_condition(u'[{}]'))


class TestJSONConditionField(unittest.TestCase):
    def test_fromDbType(self):
        a = JSONConditionField(db_column='column')
        with self.assertRaises(ConstraintNotSatisfied):
            a.fromDbType(u'text')
        with self.assertRaises(ConstraintNotSatisfied):
            a.fromDbType(['text'])
        self.assertEqual(a.fromDbType([{}]), u'[{}]')

    def test_null(self):
        a = JSONConditionField(db_column='column')
        self.assertEqual(a.null(), u'[]')

    def test_constraint(self):
        a = JSONConditionField(db_column='column')
        self.assertFalse(a.constraint(1))
        self.assertFalse(a.constraint(u''))
        self.assertFalse(a.constraint(u'{'))
        self.assertFalse(a.constraint(u'{}'))
        self.assertFalse(a.constraint(u'["text"]'))
        self.assertTrue(a.constraint(u'[{}]'))


class TestJSON(unittest.TestCase):
    def test_encode(self):

        self.assertEqual(as_primitive(123), 123)
        self.assertEqual(as_primitive({'aaa': 123}), {'aaa': 123})

        class Ob:
            pass

        ob = Ob()
        self.assertRaises(ValueError, as_primitive, ob)

        c = Country(iso_code2='RU', iso_code3='RUS', names=[u'ru:Россия', u'en:Russia', u'fr:Russie'],
                    junk='xxxxx')
        d = as_primitive(c)
        self.assertEqual(d['iso_code2'], 'RU')
        self.assertEqual(d['class'], 'Country')
        self.assertTrue('junk' not in d)

        d2 = as_primitive(dict(k=c))
        self.assertEqual(d2['k']['iso_code2'], 'RU')

        d3 = as_primitive([c, c])
        self.assertEqual(d3[0]['iso_code2'], 'RU')
        self.assertEqual(d3[1]['iso_code2'], 'RU')

    def test_encode_derived(self):
        from zope.interface import Interface, implements
        from zope.component import provideAdapter
        from zope.schema import List
        from models.ml import MLNames, MLTitleCapable
        from rx.utils.json import as_primitive, IPrimitive

        class IOb(Interface):
            names = MLNames(db_column='names', title=u'Название региона', required=True)
            elements = List()

        class Ob(MLTitleCapable):
            implements(IOb)

            def as_primitive(self):
                return dict(names=self.names, elements=self.elements)

        provideAdapter(lambda ob: ob.as_primitive(), [IOb], IPrimitive)

        ob = Ob()
        ob.names = ['ru:aaa']
        ob.elements = [1, 2, 3]

        data = as_primitive(ob)
        self.assertTrue('title' not in data)
        self.assertTrue('elements' in data)

        ob.names = ['xxx']
        data = as_primitive(ob)  # no exception


class _TerminalsByAirport(Indexer):
    name = 'tba'

    def key(self, ob): return str(ob.airport_id)


class _TerminalsByAirport2(Indexer):
    name = 'tba2'
    parent_vocab = 'airport_terminals'

    def key(self, ob): return str(ob.airport_id)


class TestIndexer(TestCaseWithPgDBAndVocabs):
    def setUp(self):
        super(TestIndexer, self).setUp()
        import pyramid.vocabulary.mvcc
        pyramid.vocabulary.mvcc.register()

    def test_txn(self):
        import transaction
        _TerminalsByAirport().register()

        t = AirportTerminal(terminal_id=-5, airport_id=-3, code='A1', names=['ru:A1'])
        getI('tba').add(t)
        self.assertEqual(len(getI('tba').map), 1)
        transaction.abort()
        self.assertEqual(len(getI('tba').map), 0)
        getI('tba').add(t)
        transaction.commit()
        self.assertEqual(len(getI('tba').map), 1)
        getI('tba').remove(t)
        transaction.commit()
        transaction.begin()
        self.assertEqual(getI('tba').map, {})

    def test_parent_vocab(self):
        register_airports()
        models.airport.AirportTerminalsVocabulary().register()

        _TerminalsByAirport2().register()
        getI('tba2')._reindex()

        self.assertEqual(getI('tba2').map.get(-1), None)
        self.assertEqual(getI('tba2').revmap.get(-5), None)
        self.assertEqual(getI('tba2')(-1), set())

        t5 = AirportTerminal(terminal_id=-5, airport_id=-1, code='A1', names=['ru:Terminal A1'])
        getV('airport_terminals').add(t5)
        self.assertEqual(set(getI('tba2')(-1)), set(['-5']))

        t5.airport_id = -2
        getV('airport_terminals').add(t5)
        self.assertEqual(set(getI('tba2')(-1)), set())
        self.assertEqual(set(getI('tba2')(-2)), set(['-5']))

        getV('airport_terminals').remove(t5)
        self.assertEqual(getI('tba2')(-2), set())


class TestVocabs(TestCaseWithVocabs):
    def _registerVocabularies(self):
        models.air.MilesLimitationsVocabulary.register()

    def test_miles_limitations(self):
        vocab = getV('miles_limitations')
        valid_tokens = ('I', 'A', 'N')

        for token in valid_tokens:
            self.assertIn(token, vocab)

        self.assertNotIn('X', vocab)


class TestBonusRoutes(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def test_redemption_zone_load(self):
        dbquery("insert into redemption_zones (redemption_zone, names) values ('ZZ','ru:Россия 1|en:Russia 1')")
        wr = models.bonus.RedemptionZone.load(redemption_zone=u'ZZ')
        self.assertEqual(wr.names, [u'ru:Россия 1', u'en:Russia 1'])

    def test_get_bonus_routes(self):
        models.bonus.BonusRoutesVocabulary().register()
        models.bonus.RedemptionZonesVocabulary().register()
        models.bonus.CarrierVocabulary.register()

        obs = getV('bonus_routes')
        rz = getV('redemption_zones')
        self.assertEqual(len(obs), 1)
        self.assertEqual(obs[-1].code, 'WWTT')
        self.assertEqual(obs[-1].zone_from, rz['WW'])
        self.assertEqual(obs[-1].zone_to, rz['TT'])
        self.assertEqual(obs[-1].zone_via, None)
        self.assertEqual(obs[-1].carrier, getV('carriers')['A'])

    def test_add_bonus_routes(self):
        models.bonus.BonusRoutesVocabulary().register()
        models.bonus.RedemptionZonesVocabulary().register()
        models.bonus.CarrierVocabulary.register()

        self.test_redemption_zone_load()
        rz = getV('redemption_zones')

        m = models.bonus.BonusRoute()
        m.bonus_route_id = -5
        m.zone_from = rz['WW']
        m.zone_via = rz['ZZ']
        m.zone_to = rz['TT']
        m.carrier = getV('carriers')['A']
        m.code = 'WWZZTT'
        m.save()
        m.reload()
        self.assertNotEqual(m.bonus_route_id, None)
        self.assertEqual(m.zone_via, rz['ZZ'])

    def test_edit_bonus_routes(self):
        models.bonus.BonusRoutesVocabulary().register()
        models.bonus.RedemptionZonesVocabulary().register()
        models.bonus.CarrierVocabulary.register()

        self.test_redemption_zone_load()
        obs = getV('bonus_routes')
        rz = getV('redemption_zones')

        m = obs[-1]
        m.zone_from = rz['TT']
        m.zone_via = rz['ZZ']
        m.zone_to = rz['WW']
        m.carrier = getV('carriers')['A']
        m.code = 'TTZZWW'
        m.save()
        m.reload()
        self.assertNotEqual(m.bonus_route_id, None)
        self.assertEqual(m.bonus_route_id, -1)
        self.assertEqual(m.zone_from, rz['TT'])
        self.assertEqual(m.zone_via, rz['ZZ'])
        self.assertEqual(m.zone_to, rz['WW'])
        self.assertEqual(m.carrier, getV('carriers')['A'])


class TestLanguages(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestLanguages, self).setUp()

    def test_load(self):
        ob = models.lang.Language.load(alpha2_code='XX')
        self.assertEqual(ob.alpha3_code, u'XXX')

    def test_save(self):
        ob = models.lang.Language(
            alpha2_code=u'YY',
            alpha3_code=u'YYY',
            selector_code=u'YYY',
            names=[u'en:English', u'ru:Английский'],
            is_active=True
        )
        ob.save()
        ob.reload()
        self.assertEquals(ob.alpha2_code, u'YY')
        self.assertEquals(ob.alpha3_code, u'YYY')
        self.assertEquals(ob.selector_code, u'YYY')
        self.assertIn(u'en:English', ob.names)
        self.assertIn(u'ru:Английский', ob.names)
        self.assertEquals(ob.is_active, True)


class TestLocalization(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestLocalization, self).setUp()
        IRegisterable(models.lang.LanguageVocabulary).register()

    def test_load(self):
        ob = models.lang.Localization.load(code='XX')
        self.assertEqual(ob.code, u'XX')
        self.assertIsInstance(ob.default_language, models.lang.Language)

    def test_save(self):
        lang = models.lang.Language.load(alpha2_code='XX')

        ob = models.lang.Localization(
            code=u'YY',
            names=[u'en:Eng', u'ru:Анг'],
            default_language=lang,
            allowed_languages=['XX', 'YY', 'ZZ'],
            is_active=True
        )
        ob.save()
        ob.reload()
        self.assertEquals(ob.code, u'YY')
        self.assertIn(u'en:Eng', ob.names)
        self.assertIn(u'ru:Анг', ob.names)
        self.assertEquals(ob.default_language.alpha2_code, u'XX')
        self.assertEquals(len(ob.allowed_languages), 3)
        self.assertEquals(ob.is_active, True)


class TestSpecialMeal(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def test_load(self):
        ob = models.meal.SpecialMeal.load(code='XXXX')
        self.assertEqual(ob.code, u'XXXX')

    def test_save(self):
        ob = models.meal.SpecialMeal(
            code=u'YYYY',
            names=[u'en:Russian', u'ru:Русский']
        )
        ob.save()
        ob.reload()
        self.assertEquals(ob.code, u'YYYY')
        self.assertIn(u'en:Russian', ob.names)
        self.assertIn(u'ru:Русский', ob.names)


class TestAncillaryServicesGroup(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def test_load(self):
        ob = models.ancillary_services.AncillaryServicesGroup.load(ancillary_services_group_id=1)
        self.assertEqual(ob.ancillary_services_group_id, 1)
        self.assertEqual(ob.names, [u'en:Ancillary Services', u'ru:Дополнительные услуги'])
        self.assertEqual(ob.ordinal_number, 10)
        self.assertEqual(ob.filename, 'ancillary')
        self.assertEqual(ob.message, [u'en:Ancillary Services', u'ru:Дополнительные услуги'])


    def test_save(self):
        ob = models.ancillary_services.AncillaryServicesGroup(
            ancillary_services_group_id=1,
            names=[u'en:Group', u'ru:Группа'],
            ordinal_number=15,
            filename='file',
            message=[u'en:Group', u'ru:Группа']
        )
        ob.save()
        ob.reload()
        self.assertEquals(ob.ancillary_services_group_id, 1)
        self.assertEqual(ob.names, [u'en:Group', u'ru:Группа'])
        self.assertEqual(ob.ordinal_number, 15)
        self.assertEqual(ob.filename, 'file')
        self.assertEqual(ob.message, [u'en:Group', u'ru:Группа'])

class TestRFICCode(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def test_load(self):
        ob = models.ancillary_services.RFICCode.load(code='A')
        self.assertEqual(ob.code, 'A')
        self.assertEqual(ob.names, [u'en:Air Transportation'])

    def test_save(self):
        ob = models.ancillary_services.RFICCode(
            code='D',
            names=[u'en:RFIC Group', u'ru:RFIC Группа']
        )
        ob.save()
        ob.reload()
        self.assertEquals(ob.code, 'D')
        self.assertEqual(ob.names, [u'en:RFIC Group', u'ru:RFIC Группа'])

    def test_title(self):
        ob = models.ancillary_services.RFICCode(code='A')
        self.assertEqual(ob.title, 'A')
        ob.code = None
        self.assertEqual(ob.title, '')


class TestAncillaryService(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAncillaryService, self).setUp()
        IRegisterable(models.ancillary_services.AncillaryServicesGroupVocabulary).register()
        IRegisterable(models.ancillary_services.RFICCodeVocabulary).register()

    def test_load(self):
        rfic = models.ancillary_services.RFICCode.load(code='C')
        ob = models.ancillary_services.AncillaryService.load(code='0EC', rfic=rfic)
        self.assertEqual(ob.code, '0EC')
        self.assertEqual(ob.names, [u'en:BICYCLE', u'ru:Перевозка велосипеда'])
        self.assertEqual(ob.descriptions, [u'ru:Описание', u'en:Description'])
        self.assertEqual(ob.ancillary_services_group, models.ancillary_services.AncillaryServicesGroup(
            ancillary_services_group_id=1,
            names=[u'en:Ancillary Services', u'ru:Дополнительные услуги'],
            ordinal_number=10,
            filename='ancillary',
            message=[u'en:Ancillary Services', u'ru:Дополнительные услуги']
        ))
        self.assertEqual(ob.rfic, rfic)
        self.assertEqual(ob.doc_prefix, ['ru:префикс', 'en:prefix'])
        self.assertEqual(ob.emd_message, ['ru:емд', 'en:emd'])

    def test_save(self):
        group = models.ancillary_services.AncillaryServicesGroup.load(ancillary_services_group_id=2)
        rfic = models.ancillary_services.RFICCode.load(code='A')
        ob = models.ancillary_services.AncillaryService(
            code='0EC',
            names=[u'en:Service', u'ru:Услуга'],
            descriptions=[u'ru:Опис', u'en:Descr'],
            ancillary_services_group=group,
            rfic=rfic,
            doc_prefix=['ru:префикс', 'en:prefix'],
            emd_message=['ru:емд', 'en:emd']
        )
        ob.save()
        ob.reload()
        self.assertEqual(ob.code, '0EC')
        self.assertEqual(ob.names, [u'en:Service', u'ru:Услуга'])
        self.assertEqual(ob.descriptions, [u'ru:Опис', u'en:Descr'])
        self.assertEqual(ob.ancillary_services_group, group)
        self.assertEqual(ob.rfic, rfic)
        self.assertEqual(ob.doc_prefix, ['ru:префикс', 'en:prefix'])
        self.assertEqual(ob.emd_message, ['ru:емд', 'en:emd'])


class TestAncillaryServiceStatus(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAncillaryServiceStatus, self).setUp()
        IRegisterable(models.ancillary_services.RFICCodeVocabulary).register()

    def test_load(self):
        ob = models.ancillary_services.AncillaryServiceStatus.load(ancillary_service_status_id=2)
        self.assertEqual(ob.code, 'HI')
        self.assertEquals(ob.rfic, models.ancillary_services.RFICCode(
            code='B',
            names=[u'en:Surface Transportation /Non Air Services']
        ))
        self.assertEquals(ob.rfisc, '0BQ')
        self.assertEqual(ob.names, [u'ru:Оформлено'])

    def test_save(self):
        rfic = models.ancillary_services.RFICCode(
            code='A',
            names=[u'en:Air Transportation']
        )
        ob = models.ancillary_services.AncillaryServiceStatus(
            ancillary_service_status_id=1,
            code='HI',
            rfic=rfic,
            rfisc='TIF',
            names=[u'ru:Оформлено'],
        )
        ob.save()
        ob.reload()
        self.assertEquals(ob.code, 'HI')
        self.assertEquals(ob.rfic, rfic)
        self.assertEquals(ob.rfisc, 'TIF')
        self.assertEqual(ob.names, [u'ru:Оформлено'])


class TestAdditionalInfo(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAdditionalInfo, self).setUp()
        IRegisterable(models.additional_info.AdditionalInfoVocabulary).register()

    def test_load(self):
        ob = models.additional_info.AdditionalInfo.load(additional_info_id=1)
        self.assertEqual(ob.weight, 10)
        self.assertEqual(ob.created, date(2015, 10, 28))
        self.assertEqual(ob.names, [u'ru:Сообщение', 'en:Message'])
        self.assertEqual(ob.condition, '[{"airport_from": "SVO"}]')

    def test_save(self):
        ob = models.additional_info.AdditionalInfo(
            additional_info_id=1,
            weight=1,
            created=date(2015, 11, 11),
            names=[u'ru:МСДЖ'],
            condition='[{"airport_from": "LED"}]',
        )
        ob.save()
        ob.reload()
        self.assertEqual(ob.weight, 1)
        self.assertEqual(ob.created, date(2015, 11, 11))
        self.assertEqual(ob.names, [u'ru:МСДЖ'])
        self.assertEqual(ob.condition, '[{"airport_from": "LED"}]')


class TestVatRates(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    default_params = dict(
        vat_rate_id=-1,
        rfic=u'A',
        rfisc=u'AAA',
        rate=0.,
        start_date=datetime.now().replace(microsecond=0),
        stop_date=datetime.now().replace(microsecond=0) + timedelta(days=1)
    )

    def setUp(self):
        super(TestVatRates, self).setUp()
        IRegisterable(models.ancillary_services.VatRatesVocabulary).register()

    def test_normal_object(self):
        ob = models.ancillary_services.VatRate(**self.default_params)
        ob.save()
        ob.reload()
        self.assertEqual(self.to_dict(ob), self.default_params)

    def test_with_negative_rate(self):
        params = self.default_params.copy()
        params['rate'] = -1.
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(TooSmall):
            ob.save()

    def test_with_big_value(self):
        params = self.default_params.copy()
        params['rate'] = 100.001
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(TooBig):
            ob.save()

    def test_with_long_rfic(self):
        params = self.default_params.copy()
        params['rfic'] = u'AA'
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(TooLong):
            ob.save()

    def test_with_empty_rfic(self):
        params = self.default_params.copy()
        params['rfic'] = u''
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(RequiredMissing):
            ob.save()

    def test_with_too_long_rfisc(self):
        params = self.default_params.copy()
        params['rfisc'] = u'AAAA'
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(TooLong):
            ob.save()

    def test_with_too_short_rfisc(self):
        params = self.default_params.copy()
        params['rfisc'] = u'A'
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(TooShort):
            ob.save()

    def test_with_empty_rfisc(self):
        params = self.default_params.copy()
        params['rfisc'] = u''
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(RequiredMissing):
            ob.save()

    def test_with_none_dates(self):
        params = self.default_params.copy()
        params['start_date'] = None
        params['stop_date'] = None
        ob = models.ancillary_services.VatRate(**params)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    def test_with_end_date_less_than_start_date(self):
        params = self.default_params.copy()
        params['start_date'], params['stop_date'] = params['stop_date'], params['start_date']
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(IntegrityError):
            ob.save()

    def test_with_equals_start_and_stop_dates(self):
        params = self.default_params.copy()
        params['start_date'], params['stop_date'] = params['stop_date'], params['stop_date']
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(IntegrityError):
            ob.save()

    def test_validation_with_two_equals_date(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params['vat_rate_id'] = -2
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_validation_with_two_equals_date_and_different_rfic(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params['rfic'] = 'B'
        ob = models.ancillary_services.VatRate(**params)
        IVatRate.validateInvariants(ob)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    def test_validation_if_stop_of_old_date_equals_to_start_of_new_date(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(
            vat_rate_id=-2,
            start_date=params['start_date'] + timedelta(days=1),
            stop_date=params['stop_date'] + timedelta(days=1)
        )
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_validation_if_stop_of_new_date_equals_to_start_of_old_date(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(
            vat_rate_id=-2,
            start_date=params['start_date'] + timedelta(days=-1),
            stop_date=params['stop_date'] + timedelta(days=-1)
        )
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_validation_if_dates_intersects(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(vat_rate_id=-2, start_date=datetime.now(), stop_date=datetime.now() + timedelta(hours=20))
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_with_new_date_after_old(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params['start_date'] += timedelta(days=2)
        params['stop_date'] += timedelta(days=2)
        ob = models.ancillary_services.VatRate(**params)
        IVatRate.validateInvariants(ob)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    def test_with_new_date_before_old(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params['start_date'] += timedelta(days=-2)
        params['stop_date'] += timedelta(days=-2)
        ob = models.ancillary_services.VatRate(**params)
        IVatRate.validateInvariants(ob)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    def test_new_with_open_start_and_end_dates(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(start_date=None, stop_date=None, vat_rate_id=-2)

        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_change_of_existing_vat_rate(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(start_date=None, stop_date=None)

        ob = models.ancillary_services.VatRate(**params)
        IVatRate.validateInvariants(ob)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    def test_new_with_open_start_date_valid(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params['stop_date'] = params['start_date'] - timedelta(days=1)
        params['start_date'] = None
        ob = models.ancillary_services.VatRate(**params)
        IVatRate.validateInvariants(ob)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    def test_new_with_open_start_date_overlap(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(vat_rate_id=-2, start_date=None, stop_date=params['start_date'])
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_new_with_open_stop_date_overlap(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params.update(vat_rate_id=-2, start_date=params['stop_date'], stop_date=None)
        ob = models.ancillary_services.VatRate(**params)
        with self.assertRaises(Invalid):
            IVatRate.validateInvariants(ob)

    def test_new_with_open_stop_date_valid(self):
        models.ancillary_services.VatRate(**self.default_params).save()
        params = self.default_params.copy()
        params['start_date'] = params['stop_date'] + timedelta(days=1)
        params['stop_date'] = None
        ob = models.ancillary_services.VatRate(**params)
        IVatRate.validateInvariants(ob)
        ob.save()
        self.assertEqual(self.to_dict(ob.reload()), params)

    @staticmethod
    def to_dict(vat_rate):
        return dict(vat_rate_id=vat_rate.vat_rate_id,
                    rfic=vat_rate.rfic,
                    rfisc=vat_rate.rfisc,
                    start_date=vat_rate.start_date,
                    stop_date=vat_rate.stop_date,
                    rate=vat_rate.rate)


class TestMealRule(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestMealRule, self).setUp()
        register_airports()
        IRegisterable(models.meal.SpecialMealVocabulary).register()
        IRegisterable(models.air.AirlinesVocabulary).register()
        IRegisterable(models.bonus.BookingClassesVocabulary).register()
        IRegisterable(models.meal.MealRulesVocabulary).register()

    def test_load(self):
        ob = models.meal.MealRule.load(meal_rule_id=1)
        self.assertEqual(ob.meal_rule_id, 1)
        self.assertEqual(ob.date_from, date(2010, 1, 1))
        self.assertEqual(ob.date_to, date(2020, 1, 1))
        self.assertEqual(ob.number, '1,3-5')
        self.assertEqual(ob.airline, [getV('airlines')[-1], getV('airlines')[-2]])
        self.assertEqual(ob.origin, [getV('airports')[-3], getV('airports')[-4]])
        self.assertEqual(ob.destination, [getV('airports')[-4], getV('airports')[-5]])
        self.assertEqual(ob.booking_class, [getV('booking_classes')[-1]])
        self.assertEqual(ob.special_meal, [getV('special_meal')['XXXX']])

    def test_save(self):
        ob = models.meal.MealRule(
            meal_rule_id=1,
            date_from=date(2011, 1, 1),
            date_to=date(2021, 1, 1),
            number='10,30-50',
            airline=[getV('airlines')[-2]],
            origin=[getV('airports')[-3]],
            destination=[getV('airports')[-5]],
            booking_class=[],
            special_meal=[],
        )
        ob.save()
        ob.reload()
        self.assertEqual(ob.meal_rule_id, 1)
        self.assertEqual(ob.date_from, date(2011, 1, 1))
        self.assertEqual(ob.date_to, date(2021, 1, 1))
        self.assertEqual(ob.number, '10,30-50')
        self.assertEqual(ob.airline, [getV('airlines')[-2]])
        self.assertEqual(ob.origin, [getV('airports')[-3]])
        self.assertEqual(ob.destination, [getV('airports')[-5]])
        self.assertEqual(ob.booking_class, [])
        self.assertEqual(ob.special_meal, [])

    def test_as_primitive(self):
        ob = models.meal.MealRule.load(meal_rule_id=1)
        self.assertEqual(ob.as_primitive(), {
            'class': 'MealRule',
            'meal_rule_id': 1,
            'date_from': '2010-01-01',
            'date_to': '2020-01-01',
            'number': u'1,3-5',
            'airline': [u'ITA', u'XXX'],
            'origin': [u'ZZZ', u'ZZX'],
            'destination': [u'ZZX', u'ZZY'],
            'booking_class': [u'Z'],
            'special_meal': [u'XXXX'],
        })


class TestNumbersList(unittest.TestCase):

    def test_run_validators(self):
        a = NumbersList()
        a.run_validators('1')
        with self.assertRaises(ValidationError):
            a.run_validators('a')
        with self.assertRaises(ValidationError):
            a.run_validators('1,')
        a.run_validators('1,2')
        with self.assertRaises(ValidationError):
            a.run_validators('1,2-')
        a.run_validators('1,2-3')
        with self.assertRaises(ValidationError):
            a.run_validators('1,3-2')
        with self.assertRaises(ValidationError):
            a.run_validators('1,a-')
        with self.assertRaises(ValidationError):
            a.run_validators('1,-a')
        with self.assertRaises(ValidationError):
            a.run_validators('1,a-a')
        with self.assertRaises(ValidationError):
            a.run_validators('1,2-3-')
        with self.assertRaises(ValidationError):
            a.run_validators('1,2-3-4')

    def test_is_valid_numbers_list(self):
        self.assertTrue(is_valid_numbers_list('1'))
        self.assertFalse(is_valid_numbers_list('a'))
        self.assertFalse(is_valid_numbers_list('1,'))
        self.assertTrue(is_valid_numbers_list('1,2'))
        self.assertFalse(is_valid_numbers_list('1,2-'))
        self.assertTrue(is_valid_numbers_list('1,2-3'))
        self.assertFalse(is_valid_numbers_list('1,3-2'))
        self.assertFalse(is_valid_numbers_list('1,a-'))
        self.assertFalse(is_valid_numbers_list('1,-a'))
        self.assertFalse(is_valid_numbers_list('1,a-a'))
        self.assertFalse(is_valid_numbers_list('1,2-3-'))
        self.assertFalse(is_valid_numbers_list('1,2-3-4'))

    @mock.patch('models.base.is_valid_numbers_list')
    def test_numbers_list_field(self, is_valid_numbers_list_mock):
        field = NumbersListField(db_column='column')
        field.constraint('1,2-3')
        self.assertEqual(is_valid_numbers_list_mock.call_count, 1)


class TestMealTimelimit(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestMealTimelimit, self).setUp()
        register_airports()
        IRegisterable(models.meal.SpecialMealVocabulary).register()

    def test_load(self):
        ob = models.meal.MealTimelimit.load(meal_timelimit_id=1)
        self.assertEqual(ob.meal_timelimit_id, 1)
        self.assertEqual(ob.origin, [getV('airports')[-3], getV('airports')[-4]])
        self.assertEqual(ob.special_meal, [getV('special_meal')['XXXX']])
        self.assertEqual(ob.timelimit, 24)

    def test_save(self):
        ob = models.meal.MealTimelimit(
            meal_timelimit_id=1,
            origin=[getV('airports')[-3]],
            special_meal=[],
            timelimit=0,
        )
        ob.save()
        ob.reload()
        self.assertEqual(ob.meal_timelimit_id, 1)
        self.assertEqual(ob.origin, [getV('airports')[-3]])
        self.assertEqual(ob.special_meal, [])
        self.assertEqual(ob.timelimit, 0)

    def test_as_primitive(self):
        ob = models.meal.MealTimelimit.load(meal_timelimit_id=1)
        self.assertEqual(ob.as_primitive(), {
            'class': 'MealTimelimit',
            'meal_timelimit_id': 1,
            'origin': [u'ZZZ', u'ZZX'],
            'special_meal': [u'XXXX'],
            'timelimit': 24,
        })

class TestCharityFunds(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestCharityFunds, self).setUp()
        IRegisterable(models.charity_funds.CharityFundVocabulary).register()

    def test_charity_funds_load(self):
        models.charity_funds.CharityFundVocabulary.register()
        ob = models.charity_funds.CharityFund.load(charity_fund_id=-1)
        self.assertEqual(ob.names, [u'en:First charity funds', u'ru:Первый фонд'])
        self.assertEqual(ob.create_date, date(2015, 10, 29))

    def test_charity_funds_save(self):
        models.charity_funds.CharityFundVocabulary.register()
        MutableTestVocab({u'P': u'Published'}).register('publication_statuses')

        ob = models.charity_funds.CharityFund()
        ob.charity_fund_id = -2
        ob.charity_id = '123456789'
        ob.tag = 'FUND_ID'
        ob.partner_description = [u'ru:русский', u'en:english']
        ob.names = [u'ru:Второй фонд', u'en:Second fund']
        ob.logo_url = [u'ru:http://url.com/logo']
        ob.image_url = [u'ru:http://url.com/img']
        ob.charity_short_description = [u'en:This is short description|ru:Это короткое описание']
        ob.charity_description = [u'en:This is full description|ru:Это полное описание']
        ob.url = [u'ru:http://url.com|en:http://url.com/en']
        ob.transfer_conditions = [u'ru:http://url.com/transfer_conditions|en:http://url.com/transfer_conditions/en']
        ob.news_url = [u'ru:http://url.com/news_url|en:http://url.com/news_url/en']
        ob.donate_miles_url = [u'ru:http://url.com/donate_miles_url|en:http://url.com/donate_miles_url/en']
        ob.donate_miles_mv_url = [u'ru:http://url.com/donate_miles_mv_url|en:http://url.com/donate_miles_mv_url/en']
        ob.stats_charity_funds_url = u'http://url.com/stats'
        ob.rss_url = u'http://url.com/rss'
        ob.status = 'P'
        ob.weight = 100
        ob.create_date = '2015-10-30'
        ob.save()
        ob.reload()
        self.assertNotEqual(ob.charity_fund_id, None)
        self.assertEqual(ob.url, [u'ru:http://url.com', u'en:http://url.com/en'])
        self.assertEqual(ob.create_date,  date(2015, 10, 30))
        self.assertEqual(ob.modify_date,  date.today())

        self.assertEqual(ob.rss_url, u'http://url.com/rss')

        ob.rss_url = u'http://url.com/rss2'
        ob.save()
        ob.reload()

        self.assertEqual(ob.rss_url, u'http://url.com/rss2')
        self.assertEqual(ob.create_date,  date(2015, 10, 30))
        self.assertEqual(ob.modify_date,  date.today())

    def test_charity_funds_json(self):

        models.charity_funds.CharityFundVocabulary.register()
        MutableTestVocab({u'P': u'Published'}).register('publication_statuses')

        charity_funds = getV('charity_funds')[-1]
        d = charity_funds.as_primitive()

        self.assertEqual(d['class'], 'CharityFund')
        self.assertEqual(d['charity_fund_id'], -1)
        self.assertEqual(d['charity_id'], '12345156')
        self.assertEqual(d['tag'], 'KOMMERSANT_FUND_ID')
        self.assertEqual(d['names'], [u'en:First charity funds', u'ru:Первый фонд'])
        self.assertEqual(d['logo_url'], [u'en:http://aeroflot.ru/logo.png', u'ru:http://aeroflot.ru/logo.png'])
        self.assertEqual(d['image_url'], [u'en:http://aeroflot.ru/image.png', u'ru:http://aeroflot.ru/image.png'])
        self.assertEqual(d['charity_short_description'], [u'ru:Это короткое описание', u'en:This is short description'])
        self.assertEqual(d['charity_description'], [u'ru:Это описание', u'en:This is description'])
        self.assertEqual(d['url'], [u'en:http://aeroflot.ru/', u'ru:http://aeroflot.ru/'])
        self.assertEqual(d['transfer_conditions'],[u'en:http://aeroflot.ru/', u'ru:http://aeroflot.ru/'])
        self.assertEqual(d['contacts'], [u'Москва'])
        self.assertEqual(d['news_url'], [u'en:http://aeroflot.ru/news', u'ru:http://aeroflot.ru/news'])
        self.assertEqual(d['news_mv_url'], [u'en:http://aeroflot.ru/pda/news', u'ru:http://aeroflot.ru/pda/news'])
        self.assertEqual(d['donate_miles_url'], u'http://aeroflot.ru/donate_miles_url')
        self.assertEqual(d['donate_miles_mv_url'], u'http://aeroflot.ru/donate_miles_mv_url')
        self.assertEqual(d['stats_charity_funds_url'], u'http://aeroflot.ru/stats')
        self.assertEqual(d['rss_url'], '')
        self.assertEqual(d['status'], 'P')
        self.assertEqual(d['weight'], 10)
        self.assertEqual(d['create_date'], '2015-10-29')
        self.assertEqual(d['modify_date'], '2016-10-30')

        d2 = as_primitive(charity_funds)
        self.assertEqual(d, d2)

if __name__ == '__main__':
    testoob.main()
