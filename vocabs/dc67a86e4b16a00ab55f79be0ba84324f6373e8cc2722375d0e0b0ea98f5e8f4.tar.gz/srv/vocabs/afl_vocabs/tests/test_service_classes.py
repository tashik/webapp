# -*- coding: utf-8 -*-

""" 
$Id: test_model.py 1767 2012-10-15 18:55:40Z anovgorodov $
"""
import unittest
import testoob

from pyramid.vocabulary import getV, getVI
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, ModelTest
from pyramid.registry.interfaces import IRegisterableVocabulary
import models.service_classes
import models.air
import models.route


import _test_data

class Test(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def _registerVocabularies(self):
        from pyramid.registry import registerFromModule
        import models.service_classes
        registerFromModule(models.service_classes)

    def test_get_skyteam_service_classes(self):
        obs = getV('skyteam_service_classes')
        self.assertEqual(len(obs), 2)

    def test_get_airline_service_classes(self):
        obs = getV('airline_service_classes')
        self.assertEqual(len(obs), 2)

    def test_get_comments(self):
        obs = getV('comments')
        self.assertEqual(len(obs), 2)

    def test_get_comments(self):
        obs = getV('comments')
        self.assertEqual(len(obs), 2)
        self.assertEqual(obs[-1].weight, 1)
        self.assertEqual(obs[-2].weight, 2)
        self.assertEqual(obs[-1].names, [u'ru:one'])


class TestServiceClassesLimit(TestCaseWithPgDBAndVocabs):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestServiceClassesLimit, self).setUp()
        self.model = models.service_classes.ServiceClassesLimit
        IRegisterableVocabulary(models.service_classes.ServiceClassesLimitVocabulary).register()
        IRegisterableVocabulary(models.route.PairsVocabulary).register()
        IRegisterableVocabulary(models.service_classes.AirlineServiceClassVocabulary).register()

    def test_service_classes_limit_load(self):
        item = models.service_classes.ServiceClassesLimit.load(service_classes_limit_id=-1)
        self.assertIsInstance(item.airline_sc, models.service_classes.AirlineServiceClass)
        self.assertIsInstance(item.pair, models.route.Pair)

    def test_service_classes_limit_save(self):
        m = models.service_classes.ServiceClassesLimit()
        m.service_classes_limit_id = -2
        m.airline_sc = getV('airline_service_classes')[-1]
        m.pair = getV('pairs')[-3]
        m.save()
        m.reload()
        self.assertIsInstance(m.airline_sc, models.service_classes.AirlineServiceClass)
        self.assertIsInstance(m.pair, models.route.Pair)

if __name__ == "__main__":
    testoob.main()
