# -*- coding: utf-8 -*-

"""
$Id: test_model.py $
"""
from datetime import date, datetime, timedelta
import logging
from StringIO import StringIO
import unittest

import cherrypy
from django import forms
from django.conf import settings
from django.forms.fields import ValidationError
import mock
from pyramid.auth.authentication import registerAuthenticator, unregisterAuthenticator
from pyramid.auth.exc import AuthorizationError
from pyramid.auth.interfaces import IAuthenticator
from pyramid.model.interfaces import ITitleCapable
from pyramid.ormlite import Record
from pyramid.ormlite.schema import Int, TextLine, Choice, List
from pyramid.registry.interfaces import IRegisterable
from pyramid.tests import testlib
from pyramid.ui.utils import htmlTree
from pyramid.vocabulary import getV
from pyramid.vocabulary.interfaces import IPersistentVocabulary
import pyramid.vocabulary.mvcc
import testoob
from zope.component import provideAdapter
import zope.interface
from zope.interface import Interface, implements
import zope.schema
import zope.schema.interfaces
from zope.schema.interfaces import ITitledTokenizedTerm, ITokenizedTerm, RequiredMissing, TooSmall

from auth import authorize
import models.additional_info
import models.air
import models.airport
from models.airport import Airport, AirportTerminal
import models.ancillary_services
from models.ancillary_services import VatRate
import models.bonus
from models.bonus import TariffGroup
from models.geo import City
from models.indexer import getI, Indexer
import models.meal
import models.member
from models.interfaces import IAirport
from models.ml import MLNames, MLText
from models.partner import Partner, ContactTypeVocabulary
import models.service_classes
from models.service_classes import SkyTeamServiceClass
from models.static import ItemStatusVocabulary
from models.uppercase import UppercaseTextLine
import _test_data
from tests import TestEditorUIPage
from testvocab import TestVocab, MutableTestVocab
import ui.additional_info
import ui.air
import ui.airport
import ui.ancillary_services
from ui.ancillary_services import VatRatesForm
import ui.bonus
import ui.csv_io
from ui.csv_io import ImportCSVError
from ui.edit import ObjectEditPage, form_from_iface
import ui.field_adapters
from ui.field_adapters import DefaultValueConverter, AirportTerminalConverter, ICSVValueConverter, register_adapters
import ui.geo
import ui.lang
import ui.meal
import ui.member
import ui.office
import ui.partner
import ui.route
import ui.service_classes
import ui.widgets
from ui.widgets import (VocabReferenceField, LineListField, StringListField,
                        VocabInput, VocabTokenInput, MLNamesField, MLTextField)


class FakeDispatcher(object):
    u"""Тестовый диспетчер маршрутов для проверки регистрации маршрутов."""
    def __init__(self):
        self.routes = []

    def connect(self, name, route, controller, **kw):
        self.routes.append({
            'name': name, 'route': route, 'controller': controller,
            'params': kw})

    name = property(lambda self: self.routes[-1]['name'])
    route = property(lambda self: self.routes[-1]['route'])
    controller = property(lambda self: self.routes[-1]['controller'])
    params = property(lambda self: self.routes[-1]['params'])


class TestCity(object):
    implements(ITitledTokenizedTerm)

    def __init__(self, iata, name):
        self.iata = iata
        self.name = name

    @property
    def title(self): return self.name

    @property
    def token(self): return self.iata

    @property
    def value(self): return self


class IKVOb(Interface):
    key = TextLine(db_column='k', required=True, primary_key=True)
    value = TextLine(db_column='v', required=False, min_length=1, max_length=10)
    val2 = Int(db_column='v2', default=777)


class KVOb(object):
    implements(IKVOb)


class SimpleTestPage(ObjectEditPage):
    sectionTitle = 'test'
    ob_name = 'testob'
    ob_class = KVOb
    ob_iface = IKVOb


class TestUser(object):
    role = 'admin'


class TestAuth(testlib.TestCaseWithLenientRoutes):
    def setUp(self):
        super(TestAuth, self).setUp()

        class _TestAuthenticator(object):
            implements(IAuthenticator)

            user = TestUser()

            def authenticate(self, force=False, login_form=None):
                return self.user

        self.authenticator = _TestAuthenticator()
        registerAuthenticator(self.authenticator, iface=IAuthenticator)

    def tearDown(self):
        unregisterAuthenticator(self.authenticator, iface=IAuthenticator)
        super(TestAuth, self).tearDown()

    def test_auth(self):
        class TestPage(ui.common.AppPage):
            @authorize
            def index(self):
                return 'hello'

        TestPage().index()
        self.authenticator.user.role = 'limited'
        self.assertRaises(AuthorizationError, TestPage().index)

        class TestPage2(ui.common.AppPage):
            _allow_roles = ['admin', 'limited']

            @authorize
            def index(self):
                return 'hello2'

        TestPage2().index()
        self.authenticator.user.role = 'limited2'
        self.assertRaises(AuthorizationError, TestPage().index)


class TestVocabEdit(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithRoutes):
    def test_vocab_reference_field(self):
        tv = TestVocab(dict(MOW='Moscow', MMK='Murmansk'))
        tv.register('tv')

        f = VocabReferenceField('tv')
        self.assertEqual(f.vocab_name, 'tv')
        self.assertEqual(f.widget.vocab_name, 'tv')
        self.assertEqual(f.to_python('Murmansk'), 'Murmansk')
        self.assertTrue(f.valid_value('Moscow'))
        self.assertTrue(not f.valid_value('London'))

    def test_vocab_token_input(self):
        tv = TestVocab(dict(LED=TestCity('LED', 'Saint-Petersburg'),
                            MOW=TestCity('MOW', 'Moscow'),
                            MMK=TestCity('MMK', 'Murmansk')))
        tv.register('tv')

        vti = VocabTokenInput(vocab_name='tv')
        tokens = [ k for k, v in vti.choices ]
        self.assertEqual(tokens, ['', 'MOW', 'MMK', 'LED'])   # сортировка
        self.assertEqual(vti.value_from_datadict({'f': 'MMK'}, None, 'f'), 'MMK')
        #self.assertEqual(vti.value_from_datadict({'f': ''}, None, 'f'), None)

    def test_vocab_input(self):
        tv = TestVocab(dict(LED=TestCity('LED', 'Saint-Petersburg'),
                            MOW=TestCity('MOW', 'Moscow'),
                            MMK=TestCity('MMK', 'Murmansk')))
        tv.register('tv')

        vi = VocabInput(vocab_name='tv')
        html = vi.render('fff', tv['MOW'])
        self.assertTrue('<option value="MOW" selected="selected"' in html)
        self.assertTrue('<option value=""' in html)
        self.assertEqual(vi.value_from_datadict({'f': 'MMK'}, None, 'f'), tv['MMK'])
        self.assertEqual(vi.value_from_datadict({'f': ''}, None, 'f'), None)

    def test_string_list_field(self):
        f = StringListField()
        self.assertEqual(f.to_python(['aaa', 'bbb', 'sss']), ['aaa', 'bbb', 'sss'])
        self.assertEqual(f.to_python(['aaa', 'bbb', 'ccc', 'ddd', 'eee', 'fff']), ['aaa', 'bbb', 'ccc', 'ddd', 'eee'])
        self.assertRaises(ValidationError, f.validate, [u'aa a', u'bbb'])


    def test_line_list_field(self):
        f = LineListField()
        self.assertEqual(f.to_python(['aaa', 'bbb']), ['aaa', 'bbb'])
        self.assertRaises(ValidationError, f.validate, [u'aa,a', u'bbb'])
        #self.assertEqual(f.to_python(''), [])

    def test_ml_names_field(self):
        f = MLNamesField()
        self.assertRaises(ValidationError, f.validate, [u'Moscow', u'Москва'])
        self.assertRaises(ValidationError, f.validate, [u'en:Moscow|'])

    def test_ml_text_field(self):
        f = MLTextField()
        self.assertRaises(ValidationError, f.validate, [u'Moscow\nRussia', u'Москва\nРоссия'])
        self.assertRaises(ValidationError, f.validate, [u'en:Moscow|'])

    def test_import_csv_error(self):

        error = ImportCSVError([(123, 'field', 'error-in-field')])
        self.assertTrue('123' in error.msg)
        self.assertTrue('field' in error.msg)
        self.assertTrue('error-in-field' in error.msg)

        error = ImportCSVError([(345, ['val1', 'val2'], 'consistency-error')])
        self.assertTrue('345' in error.msg)
        self.assertTrue('val1' in error.msg)
        self.assertTrue('val2' in error.msg)
        self.assertTrue('consistency-error' in error.msg)

    def test_csv_parse(self):
        cities_v = TestVocab({1: 'Moscow', 789: 'Murmansk'})
        cities_v.register('cities')
        ui.field_adapters.register_adapters()

        class IOb(Interface):
            rec_id = Int(db_column='k')
            value = TextLine(db_column='v')
            city = Choice(db_column='city_id', source='cities', required=False)
            names = List(db_column='names', separator='|', required=False)

        class Ob(Record):
            implements(IOb)

            def save(self):
                pass

        class TestPage(ObjectEditPage):
            sectionTitle = 'test'
            ob_name = 'testob'
            #edit_form_factory = NotImplemented
            ob_class = Ob
            ob_iface = IOb

        page = TestPage()
        ob, row_errors = page._parse_csv_row(['1', 'abc', '', 'ff|ss'])
        self.assertEqual(row_errors, [])
        self.assertEqual(ob.rec_id, 1)
        self.assertEqual(ob.value, 'abc')
        self.assertEqual(ob.p_choice_tokens, {'city': None})
        self.assertEqual(ob.names, ['ff', 'ss'])

        ob, row_errors = page._parse_csv_row(['1', 'abc', '789'])
        self.assertEqual(row_errors, [])
        self.assertEqual(ob.p_choice_tokens, {'city': '789'})

        with mock.patch('ui.edit.traceback.print_exc', lambda *args, **kw: None):  # чтобы не мусорить в рез-ты тестов
            ob, row_errors = page._parse_csv_row(['xxx', 'abc', ''])
        self.assertEqual(len(row_errors), 1)

    def test_value_converters(self):
        class ICity(Interface):
            city_id = Int(db_column='city_id', primary_key=True)
            name = TextLine(db_column='name')

        class City(Record):
            implements(ICity)

        cities_v = TestVocab({1: City(city_id=1, name='Moscow'),
                              789: City(city_id=789, name='Murmansk')})
        cities_v.register('cities')

        class IOb(Interface):
            kr = Int(db_column='kr', required=True)
            ko = Int(db_column='ko', required=False)
            so = TextLine(db_column='so', required=False)
            city_r = Choice(db_column='city_id_r', source='cities', required=True)
            city_o = Choice(db_column='city_id_o', source='cities', required=True)

        class Ob(Record):
            implements(IOb)

        ob = Ob()

        bf = IOb['kr'].bind(ob)

        conv = DefaultValueConverter(bf)
        self.assertEqual(conv.to_csv(123), '123')
        self.assertEqual(conv.from_csv('123'), 123)

        self.assertRaises(RequiredMissing, conv.from_csv, '')

        bf = IOb['ko'].bind(ob)
        conv = DefaultValueConverter(bf)
        self.assertEqual(conv.from_csv(''), None)
        self.assertEqual(conv.from_csv(' '), None)

        #bf = IOb['so'].bind(ob)
        #conv = DefaultValueConverter(bf)
        #self.assertEqual(str(conv.from_csv('')), '')

        bf = IOb['city_r'].bind(ob)
        conv = DefaultValueConverter(bf)
        self.assertEqual(conv.to_csv(cities_v[789]), '789')
        self.assertEqual(conv.from_csv('789').name, 'Murmansk')

    def test_list_converters(self):
        provideAdapter(DefaultValueConverter, [zope.schema.interfaces.Interface], ICSVValueConverter)

        class IOb(Interface):
            ints = List(db_column='ints', value_type=zope.schema.Int(min=0))
            obs = List(db_column='obs', value_type=zope.schema.Object(schema=Interface))

        class ISubOb(Interface):
            k = Int(db_column='k')
            v = TextLine(db_column='v')

        class Ob(Record):
            implements(IOb)

        class SubOb(Record):
            implements(ISubOb)

        ob = Ob()

        ob.ints = [3, 2, 1]
        bf = IOb['ints'].bind(ob)
        conv = DefaultValueConverter(bf)
        self.assertEqual(conv.to_csv(ob.ints), '3|2|1')
        self.assertEqual(conv.from_csv('4|5|6'), [4, 5, 6])
        self.assertRaises(TooSmall, conv.from_csv, '4|5|-1')

        ob.obs = [SubOb(k=22, v='aa'), SubOb(k=33, v='bb')]
        bf = IOb['obs'].bind(ob)
        conv = DefaultValueConverter(bf)
        self.assertEqual(conv.to_csv(ob.obs), '{"k": 22, "v": "aa"}|{"k": 33, "v": "bb"}')

    def test_create_form(self):
        ui.field_adapters.register_adapters()

        tv = TestVocab(dict(LED=TestCity('LED', 'Saint-Petersburg'),
                            MOW=TestCity('MOW', 'Moscow'),
                            MMK=TestCity('MMK', 'Murmansk')))
        tv.register('tv')

        class IOb(Interface):
            rec_id = Int(db_column='k', required=True)
            value = TextLine(db_column='v', required=False, min_length=1, max_length=10)
            names = MLNames(db_column='names', title=u'Название')
            text = MLText(db_column='text', title=u'Описание')
            city = zope.schema.Choice(source='tv', required=False)
            iata = UppercaseTextLine(db_column='iata')

        class Ob(object):
            implements(IOb)

        class TestPage(ObjectEditPage):
            sectionTitle = 'test'
            ob_name = 'testob'
            ob_class = Ob
            ob_iface = IOb

        page = TestPage()

        form = form_from_iface(page.iface_fields, page.ob_name)()
        self.assertEqual(type(form['rec_id'].field), forms.IntegerField)
        self.assertEqual(form['rec_id'].field.required, True)

        self.assertEqual(type(form['value'].field), forms.CharField)
        self.assertEqual(form['value'].field.required, False)
        self.assertEqual(form['value'].field.min_length, 1)
        self.assertEqual(form['value'].field.max_length, 10)

        self.assertEqual(type(form['names'].field), ui.widgets.MLNamesField)
        self.assertEqual(type(form['names'].field.widget), ui.widgets.MLNamesInput)
        self.assertEqual(form['names'].label, u'Название')

        self.assertEqual(type(form['text'].field), ui.widgets.MLTextField)
        self.assertEqual(type(form['text'].field.widget), ui.widgets.MLTextInput)
        self.assertEqual(form['text'].label, u'Описание')

        self.assertEqual(type(form['city'].field), ui.widgets.VocabReferenceField)
        self.assertEqual(form['city'].field.vocab_name, 'tv')

        self.assertEqual(type(form['iata'].field.widget), ui.widgets.UppercaseTextInput)

    def test_populate_initial(self):
        page = SimpleTestPage()

        initial, readonly = page._populate_initial(None)

        self.assertEquals(initial, {'key': None, 'value': None, 'val2': 777})
        self.assertEquals(readonly, [])

        ob = KVOb()
        ob.key = 'K'
        ob.value = 'V'
        ob.val2 = 333

        initial, readonly = page._populate_initial(ob)
        self.assertEquals(initial, {'key': 'K', 'value': 'V', 'val2': 333})
        self.assertEquals(readonly, ['key'])

    def test_fmt_cell(self):
        page = SimpleTestPage()
        self.assertEqual(page._fmt_cell(1), '1')
        self.assertEqual(page._fmt_cell(3.456), '3.456')
        self.assertEqual(page._fmt_cell(u'текст'), u'текст')
        self.assertEqual(page._fmt_cell(True), u'Да')
        self.assertEqual(page._fmt_cell(False), u'Нет')

        class TitledOb(object):
            implements(ITitleCapable)
            title = 'hello'

        self.assertEqual(page._fmt_cell(TitledOb()), 'hello')


class TestAirport(testlib.TestCaseWithPgDBAndVocabs):
    def setUp(self):
        super(TestAirport, self).setUp()
        ui.field_adapters.register_adapters()

        t_cities = TestVocab({-11: City(city_id=-11, country_code='RU', tz='UTC', iata='CCCC', names=[u'ru:Егорьевск', 'en:Egoryevsk'])})
        t_cities.register('cities')
        t_airports = TestVocab({-22: Airport(airport_id=-22, iata='PPP', icao='PPPP', city=getV('cities')[-11], names=[u'ru:Незнамово'])})
        t_airports.register('airports')

        t_terminals = TestVocab({-333: AirportTerminal(terminal_id=-333, airport_id=-22, code='Y', names=u'ru:Терминал Y'),
                                 -332: AirportTerminal(terminal_id=-332, airport_id=-22, code='A', names=u'ru:Терминал A'),
                                 -334: AirportTerminal(terminal_id=-334, airport_id=-22, code='X', names=u'ru:Терминал X'),
                                })
        t_terminals.p_subscribe = lambda ob: None
        zope.interface.directlyProvides(t_terminals, IPersistentVocabulary)
        t_terminals.register('airport_terminals')

#        dbop.defer_constraints()
#        dbquery("insert into airport_terminals (terminal_id, airport_id, code, names) values (-333, -22, 'Y', 'ru:Терминал Y')")
#        dbquery("insert into airport_terminals (terminal_id, airport_id, code, names) values (-332, -22, 'A', 'ru:Терминал A')")
#        dbquery("insert into airport_terminals (terminal_id, airport_id, code, names) values (-334, -22, 'X', 'ru:Терминал X')")

        models.airport.TerminalsByAirport().register()

    def test_load_ob(self):
        ob = getV('airports')[-22]
        terminals = ob.terminals
        self.assertEqual(len(terminals), 3)
        terminals.sort(key=lambda t: t.terminal_id)
        self.assertEqual(terminals[0].code, 'X')
        self.assertEqual(terminals[1].code, 'Y')
        self.assertEqual(terminals[2].code, 'A')

    def test_terminal_csv(self):
        a = getV('airports')[-22]
        field = IAirport['terminals'].bind(a)

        conv = AirportTerminalConverter(field)
        t = AirportTerminal(terminal_id=-5, airport_id=-3, code='A1', names=['ru:A1'])
        self.assertEqual(conv.to_csv(t), '-5$A1$ru:A1')

        t2 = conv.from_csv(u'-6$B2$en:B2|ru:Б2')
        self.assertEqual(t2.terminal_id, -6)
        self.assertEqual(t2.code, 'B2')
        self.assertEqual(t2.names, [u'en:B2', u'ru:Б2'])


class TestTariffGroup(testlib.TestCaseWithPgDBAndVocabs):
    def setUp(self):

        super(TestTariffGroup, self).setUp()
        ui.field_adapters.register_adapters()

        t_service_classes = TestVocab({'-1': SkyTeamServiceClass(skyteam_sc_id=-1, code='xxxxxxx', names=[u'ru:Lux', 'en:Люкс'])})
        t_service_classes.register('skyteam_service_classes')
        t_tariff_groups = TestVocab({'xxxxxxx-yyyyyyy': TariffGroup(tariff_group='xxxxxxx-yyyyyyy', service_class=getV('skyteam_service_classes')['-1'], names=[u'ru:Пенсионер'])})
        t_tariff_groups.register('tariff_groups')

    def test_load_ob(self):
        ob = getV('tariff_groups')['xxxxxxx-yyyyyyy']


class TestCSV(unittest.TestCase):
    def test_export(self):

        rows = [['aaa', 'bbb'], ['c;cc', '"ddd"']]
        lines = list(ui.csv_io.export_csv(['Col1', 'Col2'], rows.__iter__()))

        self.assertEqual(lines[0], '"Col1";"Col2"\r\n')
        self.assertEqual(lines[1], '"aaa";"bbb"\r\n')
        self.assertEqual(lines[2], '"c;cc";"""ddd"""\r\n')

    def test_import(self):

        input = StringIO('Col1;Col2\r\n'
                         '1;aaa;bbb\r\n'
                         '2;"c;cc";"""фыва"""\r\n'
                         )

        class IOb(Interface):
            pass

        class Ob(object):
            implements(ITokenizedTerm, IOb)

        def parse_csv_row(row):
            errors = []
            ob = Ob()
            try:
                ob.term = ob.k = int(row[0])
            except ValueError, e:
                errors.append(e)
            ob.v1 = row[1]
            ob.v2 = row[2]
            if '@' in row[2]:
                errors.append('invalid character @')
            return ob, errors

        objects, errors = ui.csv_io.import_csv(input, 'utf-8', parse_csv_row)
        self.assertEqual(errors, [])
        self.assertEqual(len(objects), 2)
        self.assertEqual(objects[1].v2, u'"фыва"')

        input = StringIO('Col1;Col2\r\n'
                         '1;aaa;@\r\n'
                         )

        objects, errors = ui.csv_io.import_csv(input, 'utf-8', parse_csv_row)
        self.assertEqual(errors, [(2, ['1', 'aaa', '@'], 'invalid character @')])

        input = StringIO('Col1;Col2\r\n'
                         '1;;\r\n'
                         )

        objects, errors = ui.csv_io.import_csv(input, 'utf-8', parse_csv_row)
        #print repr(objects[0].v1)

    def test_merge(self):

        class Ob(object):
            implements(ITokenizedTerm)
            def __init__(self, token, value):
                self.token = token
                self.value = value

            def __eq__(self, other):
                return other is not None and self.token == other.token and self.value == other.value

            def __ne__(self, other):
                return not self.__eq__(other)

            def __repr__(self):
                return 'Ob(%r, %r)' % (self.token, self.value)

        existing = {1: Ob(1, 'a'), 2: Ob(2, 'b'), 3: Ob(3, 'c')}
        imported = [Ob(2, 'b'), Ob(3, 'cc'), Ob(4, 'd')]

        added, changed, deleted, errors = ui.csv_io.merge(existing, imported)

        self.assertEqual(errors, [])
        self.assertEqual(added, [Ob(4, 'd')])
        self.assertEqual(changed, [Ob(3, 'cc')])
        self.assertEqual(deleted, [Ob(1, 'a')])
        self.assertEqual(errors, [])

        imported = [Ob(2, 'b'), Ob(3, 'cc'), Ob(4, 'd1'), Ob(4, 'd2')]
        added, changed, deleted, errors = ui.csv_io.merge(existing, imported)
        self.assertEqual(len(errors), 1)
        self.assertEqual(errors[0][0], 5)  # 1-я строка - заголовок, данные начинаются со строки 2


class TestListPage(testlib.TestCaseWithLenientRoutes, testlib.TestCaseWithCP,
                   testlib.TestCaseWithAuth):
    def setUp(self):
        super(TestListPage, self).setUp()

        ui.field_adapters.register_adapters()

        class _TestPage(ObjectEditPage):
            ob_name = 'test_obj'
            ob_class = KVOb
            ob_iface = IKVOb
            vocab_name = 'test_vocab'

        TestVocab({}).register('test_vocab')
        self.page_cls = _TestPage

        self.registerTestAuthenticator()
        self._createTestUser()
        self.user.role = 'admin'
        self.authenticator.user = self.user

    @mock.patch('ui.edit.config')
    def test_connect_to_dispatcher(self, mock_config):
        mock_config.ENABLE_CSV_IMPORT = True
        mock_config.ENABLE_CSV_EXPORT = True

        page = self.page_cls()
        dispatcher = FakeDispatcher()
        page._connectToDispatcher(dispatcher)
        routes = dispatcher.routes
        self.assertEqual(6, len(routes))
        self.assertEqual('test_obj_list', routes[0]['name'])
        self.assertEqual(r'test_obj', routes[0]['route'])
        self.assertEqual(page, routes[0]['controller'])
        self.assertEqual({'action': 'index'}, routes[0]['params'])

        self.assertEqual('test_obj_export', routes[1]['name'])
        self.assertEqual(r'test_obj/export_csv', routes[1]['route'])
        self.assertEqual(page, routes[1]['controller'])
        self.assertEqual({'action': 'export_csv'}, routes[1]['params'])

        self.assertEqual('test_obj_import', routes[2]['name'])
        self.assertEqual(r'test_obj/import_csv', routes[2]['route'])
        self.assertEqual(page, routes[2]['controller'])
        self.assertEqual({'action': 'import_csv'}, routes[2]['params'])

        self.assertEqual('test_obj_new', routes[3]['name'])
        self.assertEqual(r'test_obj/new', routes[3]['route'])
        self.assertEqual(page, routes[3]['controller'])
        self.assertEqual({'action': 'add'}, routes[3]['params'])

        self.assertEqual('test_obj_edit', routes[4]['name'])
        self.assertEqual(r'test_obj/:key/edit', routes[4]['route'])
        self.assertEqual(page, routes[4]['controller'])
        self.assertEqual({'action': 'edit'}, routes[4]['params'])

        self.assertEqual('test_obj_del', routes[5]['name'])
        self.assertEqual(r'test_obj/:key/delete', routes[5]['route'])
        self.assertEqual(page, routes[5]['controller'])
        self.assertEqual({'action': 'delete'}, routes[5]['params'])

        mock_config.ENABLE_CSV_IMPORT = False
        page = self.page_cls()
        dispatcher = FakeDispatcher()
        page._connectToDispatcher(dispatcher)
        routes = dispatcher.routes
        self.assertEqual(5, len(routes))
        self.assertNotIn('test_obj_import', set(r['name'] for r in routes))
        self.assertIn('test_obj_export', set(r['name'] for r in routes))

        mock_config.ENABLE_CSV_EXPORT = False
        page = self.page_cls()
        dispatcher = FakeDispatcher()
        page._connectToDispatcher(dispatcher)
        routes = dispatcher.routes
        self.assertEqual(4, len(routes))
        self.assertNotIn('test_obj_import', set(r['name'] for r in routes))
        self.assertNotIn('test_obj_export', set(r['name'] for r in routes))

    @mock.patch('ui.edit.config')
    def test_buttons(self, mock_config):
        mock_config.ENABLE_CSV_IMPORT = True
        mock_config.ENABLE_CSV_EXPORT = True
        page = self.page_cls()
        body = page.index()
        html = htmlTree(body)

        self.assertTrue(html.xpath(
            u'//li/a[@class="button_link" and @href="/test_obj_new" '
            u'and text()="Добавить"]'))
        self.assertTrue(html.xpath(
            u'//li/a[@href="/test_obj_import" '
            u'and text()="Импорт CSV"]'))
        self.assertTrue(html.xpath(
            u'//li/a[@href="/test_obj_export" '
            u'and text()="Экспорт CSV"]'))

        mock_config.ENABLE_CSV_IMPORT = False
        page = self.page_cls()
        body = page.index()
        html = htmlTree(body)
        self.assertTrue(html.xpath(
            u'//li/a[@class="button_link" and @href="/test_obj_new" '
            u'and text()="Добавить"]'))
        self.assertFalse(html.xpath(
            u'//li/a[@href="/test_obj_import" '
            u'and text()="Импорт CSV"]'))
        self.assertTrue(html.xpath(
            u'//li/a[@href="/test_obj_export" '
            u'and text()="Экспорт CSV"]'))

        mock_config.ENABLE_CSV_EXPORT = False
        page = self.page_cls()
        body = page.index()
        html = htmlTree(body)
        self.assertTrue(html.xpath(
            u'//li/a[@class="button_link" and @href="/test_obj_new" '
            u'and text()="Добавить"]'))
        self.assertFalse(html.xpath(
            u'//li/a[@href="/test_obj_import" '
            u'and text()="Импорт CSV"]'))
        self.assertFalse(html.xpath(
            u'//li/a[@href="/test_obj_export" '
            u'and text()="Экспорт CSV"]'))


class TestAirlineForm(unittest.TestCase):
    def setUp(self):
        super(TestAirlineForm, self).setUp()
        pyramid.vocabulary.mvcc.register()
        models.air.MilesLimitationsVocabulary.register()

        self.airports = TestVocab({
            '-3': Airport(
                airport_id=-3,
                names=[u'ru:Улетаево']
                )
        })
        self.airports.register('airports')

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        params = {
            'submit0': u'1'
        }
        form = ui.air.AirlineForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 4)
        for field in ('names', 'weight', 'miles_minimum', 'miles_limitation'):
            self.assertEqual(form.errors[field], [u'This field is required.'])

        params = {
            'names': u'name1\nname2',
            'submit0': u'1'
        }
        form = ui.air.AirlineForm(params)
        self.assertEqual(len(form.errors), 4)
        self.assertFalse(form.is_valid())
        self.assertEqual(
            form.errors['names'],
            [u'Введите словарь названий в формате код-языка:название. '
             u'(Например: ru:Москва).'])

        params = {
            'names': u'en:name1\nru:name2',
            'url': u'en:http://name1.example.org\nru:http://name2.example.org',
            'weight': u'2',
            'miles_minimum': '100.0',
            'miles_limitation': 'N',
            'miles_earn_description': 'ru:',
            'miles_earn_comment': 'ru:',
            'submit0': u'1'
        }

        form = ui.air.AirlineForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 1)
        self.assertEqual(
            form.errors['miles_minimum'],
            [u'При отсутствии ограничения минимальное количество миль должно быть нулём.'])

        params = {
            'airport': u'-3',
            'names': u'en:name1\nru:name2',
            'url': u'en:http://name1.example.org\nru:http://name2.example.org',
            'weight': u'2',
            'miles_minimum': '0.0',
            'miles_limitation': 'N',
            'miles_earn_description': 'ru:',
            'miles_earn_comment': 'ru:',
            'submit0': u'1'
        }

        form = ui.air.AirlineForm(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['airport'], self.airports["-3"])
        self.assertEqual(len(form.errors), 0)

        params = {
            'airport': u'-3',
            'names': u'en:name1\nru:name2',
            'url': u'en:http://name1.example.org\nru:http://name2.example.org',
            'weight': u'2',
            'miles_minimum': '100.0',
            'miles_limitation': 'I',
            'miles_earn_description': 'ru:AAAA\nen:BBBB',
            'miles_earn_comment': 'ru:CCCC\nen:DDDD',
            'submit0': u'1'
        }

        form = ui.air.AirlineForm(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['airport'], self.airports["-3"])
        self.assertEqual(len(form.errors), 0)


class TestAirportForm(unittest.TestCase):
    def setUp(self):

        self.cities = TestVocab({
            '101': City(
                city_id=101, tz='E/M', names=[u'en:Abc'])
        })
        self.cities.register('cities')

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        params = {
            'submit0': u'1'
        }
        form = ui.airport.AirportForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 2)
        self.assertEqual(form.errors['city'], [u'This field is required.'])
        self.assertEqual(form.errors['names'], [u'This field is required.'])

        params = {
            'city': u'101',
            'names': u'name1\nname2',
            'submit0': u'1'
        }
        form = ui.airport.AirportForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 1)
        self.assertEqual(
            form.errors['names'],
            [u'Введите словарь названий в формате код-языка:название. '
             u'(Например: ru:Москва).'])

        params = {
            'city': u'101',
            'names': u'en:name1\nru:name2',
            'has_afl_flights': u'1',
            'has_upgrade_on_checkin_award': u'1',
            'submit0': u'1'
        }
        form = ui.airport.AirportForm(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(True, form.cleaned_data['has_afl_flights'])
        self.assertEqual(True, form.cleaned_data['has_upgrade_on_checkin_award'])
        self.assertEqual(len(form.errors), 0)


class TestTariffGroupForm(unittest.TestCase):
    def setUp(self):
        self.service_classes = TestVocab({
            '-1': SkyTeamServiceClass(
                skyteam_sc_id=-1,
                code='lux', names=[u'ru:Lux', 'en:Люкс']
            )
        })
        self.service_classes.register('skyteam_service_classes')

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):

        params = {
            'submit0': u'1'
        }
        form = ui.bonus.TariffGroupForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 3)
        self.assertEqual(
            form.errors['tariff_group'], [u'This field is required.'])
        self.assertEqual(
            form.errors['service_class'], [u'This field is required.'])
        self.assertEqual(
            form.errors['names'], [u'This field is required.'])

        params = {
            'id_field': u'101',
            'tariff_group': u'101',
            'service_class': u'',
            'names': u'en:name1\nru:name2',
            'submit0': u'1',
            'weight': u'10'
        }
        form = ui.bonus.TariffGroupForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 1)
        self.assertEqual(
            form.errors['service_class'], [u'This field is required.'])

        params = {
            'id_field': u'101',
            'tariff_group': u'101',
            'service_class': u'-1',
            'names': u'en:name1\nru:name2',
            'submit0': u'1',
            'weight': u'10'
        }
        form = ui.bonus.TariffGroupForm(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 1)
        self.assertEqual(
            form.errors['tariff_group'],
            [u'Неправильное название тарифной группы. '
             u'Название должно начинаться с: "lux-"'])

        params = {
            'id_field': u'101',
            'tariff_group': u'lux-101',
            'service_class': u'-1',
            'names': u'en:name1\nru:name2',
            'submit0': u'1',
            'weight': u'10'
        }
        form = ui.bonus.TariffGroupForm(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(len(form.errors), 0)


class TestCityPage(TestEditorUIPage):
    def setUp(self):
        super(TestCityPage, self).setUp()
        self.cities = MutableTestVocab({
            '101': City(
                city_id=101, tz='E/M', names=[u'en:Abc']
            )
        })
        self.cities.register('cities')

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    def test_delete(self, *args):
        page = ui.geo.CityPage()
        page.delete(city_id=u'101')
        self.assertNotIn('101', self.cities)
        self.assertEqual(len(self.cities), 0)


class TestAwardsPage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAwardsPage, self).setUp()
        MutableTestVocab({u'A': u'Aeroflot'}).register('carriers')
        self.redemption_zones = TestVocab({
            u'A1': models.bonus.RedemptionZone(redemption_zone=u'A1', names=[u'en:Antarctic1']),
            u'L1': models.bonus.RedemptionZone(redemption_zone=u'L1', names=[u'en:Lunar1']),
            u'M1': models.bonus.RedemptionZone(redemption_zone=u'M1', names=[u'en:Martian1']),
            })
        self.redemption_zones.register('redemption_zones')

        IRegisterable(models.air.AirlinesVocabulary).register()
        IRegisterable(models.service_classes.SkyTeamServiceClassVocabulary).register()
        self.service_classes = getV('skyteam_service_classes')

        self.bonus_routes = MutableTestVocab({
            u'1': models.bonus.BonusRoute(bonus_route_id=u'1',
                                          zone_from=self.redemption_zones['A1'],
                                          zone_via=self.redemption_zones['L1'],
                                          zone_to=self.redemption_zones['M1'],
                                          carrier = u'A'),
            u'2': models.bonus.BonusRoute(bonus_route_id=u'2',
                                          zone_from=self.redemption_zones['M1'],
                                          zone_to=self.redemption_zones['L1'],
                                          carrier = u'A')
            })
        self.bonus_routes.register('bonus_routes')
        models.bonus.AwardTypesVocabulary.register()
        self.awards = MutableTestVocab({
            u'-1': models.bonus.Award(award_id='1', type=getV('award_types')[u'U'],
                                      service_classes_1=self.service_classes[u'-1'],
                                      service_classes_2=self.service_classes[u'-2'],
                                      award_value=500, route=self.bonus_routes[u'1'])
            })
        self.awards.register('awards')

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.bonus.AwardsPage.ob_class, 'save')
    def test_add(self, mock_aw_save, *args):
        page = ui.bonus.AwardsPage()
        params = {
            'type': u'UC',
            'service_classes_1': u'-1',
            'service_classes_2': u'-2',
            'award_value': u'300',
            'route': u'1',
            'submit0': u'1'
        }

        self.assertEqual(1, len(getV('awards')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_aw_save.call_count, 1)
        self.assertEqual(2, len(getV('awards')))

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.bonus.BonusRoute.title', new='')
    @mock.patch('models.service_classes.SkyTeamServiceClass.title', new='')
    def test_search(self, *args):
        page = ui.bonus.AwardsPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        for params in ({'bonus_route': u'1'},):
            body = page.index(**params)
            html = htmlTree(body)
            self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        for params in ({'bonus_route': u'2'}, {'bonus_route': u'3'}):
            body = page.index(**params)
            html = htmlTree(body)
            self.assertEqual(0, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestBonusRoutePage(TestEditorUIPage):

    def setUp(self):
        super(TestBonusRoutePage, self).setUp()
        self.redemption_zones = TestVocab({
            u'A1': models.bonus.RedemptionZone(redemption_zone=u'A1', names=[u'en:Antarctic1']),
            u'L1': models.bonus.RedemptionZone(redemption_zone=u'L1', names=[u'en:Lunar1']),
            u'M1': models.bonus.RedemptionZone(redemption_zone=u'M1', names=[u'en:Martian1']),
            })
        self.redemption_zones.register('redemption_zones')

        self.bonus_routes = MutableTestVocab({
            u'1': models.bonus.BonusRoute(zone_from=self.redemption_zones['A1'],
                                          zone_via=self.redemption_zones['L1'],
                                          zone_to=self.redemption_zones['M1'])
            })
        self.bonus_routes.register('bonus_routes')
        models.bonus.CarrierVocabulary.register()

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.bonus.BonusRoutePage.ob_class, 'save')
    def test_add(self, mock_br_save, *args):
        page = ui.bonus.BonusRoutePage()
        params = {
            'zone_from': u'M1',
            'zone_via': u'A1',
            'zone_to': u'L1',
            'carrier': u'S',
            'submit0': u'1'
        }

        self.assertEqual(1, len(getV('bonus_routes')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_br_save.call_count, 1)
        self.assertEqual(2, len(getV('bonus_routes')))

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.bonus.RedemptionZone.title', new='')
    def test_search(self, *args):
        page = ui.bonus.BonusRoutePage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        for params in ({'zone_from': u'A1'}, {'zone_to': u'M1'}, {'zone_from': u'A1', 'zone_to': u'M1'}):
            body = page.index(**params)
            html = htmlTree(body)
            self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        for params in ({'zone_from': u'M1'}, {'zone_to': u'L1'}, {'zone_from': u'A1', 'zone_to': u'L1'}):
            body = page.index(**params)
            html = htmlTree(body)
            self.assertEqual(0, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestAirlineServiceClassPage(TestEditorUIPage):

    def setUp(self):
        super(TestAirlineServiceClassPage, self).setUp()
        self.airlines = MutableTestVocab({
            u'1': models.air.Airline(airline_id=1, names=[u'en:name1', u'ru:name2']),
            u'2': models.air.Airline(airline_id=2, names=[u'en:name1', u'ru:name2'])
        })

        self.airlines.register('airlines')
        self.service_classes = TestVocab({
            'lux': models.service_classes.SkyTeamServiceClass(
                skyteam_sc_id=-1,
                code='xxxxxxx', names=[u'ru:Lux', 'en:Люкс']
            )
        })
        self.service_classes.register('skyteam_service_classes')

        self.airline_service_classes = MutableTestVocab({
            '-1': models.service_classes.AirlineServiceClass(airline=self.airlines['1'], skyteam_sc=self.service_classes['lux'])
            })
        self.airline_service_classes.register('airline_service_classes')

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.service_classes.AirlineServiceClassPage.ob_class, 'save')
    def test_add(self, mock_asc_save, *args):

        page = ui.service_classes.AirlineServiceClassPage()
        params = {
            'airline': u'1',
            'skyteam_sc': 'lux',
            'submit0': u'1'
        }

        self.assertEqual(1, len(getV('airline_service_classes')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_asc_save.call_count, 1)
        self.assertEqual(2, len(getV('airline_service_classes')))

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.air.Airline.title', new='SomeAirlineTitle')
    @mock.patch('models.service_classes.SkyTeamServiceClass.title', new='SomeServiceClassTitle')
    def test_index(self, *args):
        page = ui.service_classes.AirlineServiceClassPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestTariffGroupPage(TestEditorUIPage):

    def setUp(self):
        super(TestTariffGroupPage, self).setUp()
        self.service_classes = TestVocab({
            'lux': SkyTeamServiceClass(
                skyteam_sc_id=-1,
                code='xxxxxxx', names=[u'ru:Lux', 'en:Люкс']
            )
        })
        self.service_classes.register('skyteam_service_classes')

        self.tariff_groups = MutableTestVocab({
            u'-1': models.bonus.TariffGroup(service_class=self.service_classes['lux'])
            })
        self.tariff_groups.register('tariff_groups')

        self.booking_classes = MutableTestVocab({})
        self.booking_classes.register('tariff_group_booking_classes')

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.bonus.TariffGroupPage.ob_class, 'save')
    def test_add(self, mock_tg_save, *args):

        page = ui.bonus.TariffGroupPage()
        params = {
            'tariff_group': u'xxxxxxx-1',
            'service_class': u'lux',
            'names': u'en:name1\nru:name2',
            'submit0': u'1',
            'weight': u'10'
        }

        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_tg_save.call_count, 1)

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.bonus.TariffGroup.title', new='SomeTGTitle')
    @mock.patch('models.service_classes.SkyTeamServiceClass.title', new='SomeServiceClassTitle')
    def test_search(self, *args):
        page = ui.bonus.TariffGroupPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        body = page.index(service_class=u'-1')
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        body = page.index(service_class=u'-2')
        html = htmlTree(body)
        self.assertEqual(0, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestAirlinePage(TestEditorUIPage):
    def setUp(self):
        super(TestAirlinePage, self).setUp()
        pyramid.vocabulary.mvcc.register()
        models.air.MilesLimitationsVocabulary.register()
        models.member.LoyaltyProgramVocabulary.register()
        IRegisterable(models.airport.AirportsVocabulary).register()
        getV('airports').preload()

        self.airlines = MutableTestVocab({})
        self.airlines.register('airlines')

        self.countries = MutableTestVocab({})
        self.countries.register('countries')

        register_adapters()

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    def test_add(self, *args):
        page = ui.air.AirlinePage()
        params = {
            'names': u'en:name1\nru:name2',
            'url': u'en:http://name1.example.org\nru:http://name2.example.org',
            'weight': u'2',
            'miles_minimum': 0.0,
            'miles_limitation': 'N',
            'miles_earn_description': u'ru:ZZZZ\nen:YYYY',
            'miles_earn_comment': u'ru:AAAA\nen:BBBB',
            'submit0': u'1'
        }
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(1, len(self.airlines))


class TestTierLevelFactorPage(TestEditorUIPage):

    def setUp(self):
        super(TestTierLevelFactorPage, self).setUp()

        self.airlines = MutableTestVocab({u'1': models.air.Airline(airline_id=1),
                                          u'2': models.air.Airline(airline_id=2)})

        self.airlines.register('airlines')

        self.tier_levels = MutableTestVocab({u'platinum': models.bonus.TierLevel(tier_level='platinum')})
        self.tier_levels.register('tier_levels')

        self.tier_level_factors = MutableTestVocab({
            u'-1': models.bonus.TierLevelFactor(tier_level_factor_id=-1, airline=getV('airlines')['1'],
                                                tier_level=self.tier_levels['platinum'], factor=100.0)})
        self.tier_level_factors.register('tier_level_factors')

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.bonus.TierLevel.title', new='SomeTierLevelTitle')
    @mock.patch('models.air.Airline.title', new='SomeAirlineTitle')
    def test_search(self, *args):
        page = ui.bonus.TierLevelFactorPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        body = page.index(airline_id=u'1')
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        body = page.index(airline_id=u'2')
        html = htmlTree(body)
        self.assertEqual(0, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.bonus.TierLevelFactorPage.ob_class, 'save')
    def test_add(self, mock_tlf_save, *args):
        page = ui.bonus.TierLevelFactorPage()
        params = {
            'airline': u'1',
            'tier_level': u'platinum',
            'factor': u'345.0',
            'submit0': u'1'
        }

        self.assertEqual(1, len(self.tier_level_factors))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_tlf_save.call_count, 1)
        self.assertEqual(2, len(self.tier_level_factors))


class TestAirportPage(TestEditorUIPage):
    def setUp(self):
        super(TestAirportPage, self).setUp()
        ui.field_adapters.register_adapters()

        self.cities = TestVocab({
            '101': City(
                city_id=101, tz='E/M', names=[u'en:Abc']),
            '102': City(
                city_id=102, tz='A/Y', names=[u'en:Def'])
        })
        self.cities.register('cities')

        self.airports = MutableTestVocab({u'701': models.airport.Airport(airport_id=701, city=self.cities['101'], iata='XXX'),
                                          u'702': models.airport.Airport(airport_id=702, city=self.cities['101'], iata='YYY')})
        self.airports.register('airports')

        self.terminals = MutableTestVocab({})
        self.terminals.p_subscribe = lambda ob: None
        self.terminals.register('airport_terminals')

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.geo.City.title', new='SomeCityTitle')
    @mock.patch('models.airport.Airport.title', new='SomeAirportTitle')
    def test_search(self, *args):
        page = ui.airport.AirportPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(2, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        params = {u'city_id': u'101'}
        body = page.index(**params)
        html = htmlTree(body)
        self.assertEqual(2, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        params = {u'city_id': u'101', 'q': 'XXX'}
        body = page.index(**params)
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        params = {'q': 'XXX'}
        body = page.index(**params)
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        params = {u'city_id': u'102', 'q': 'XXX'}
        body = page.index(**params)
        html = htmlTree(body)
        self.assertFalse(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..'))

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.airport.AirportPage.ob_class, 'save')
    @mock.patch.object(ui.airport.AirportTerminal, 'save')
    def test_add(self, mock_t_save, mock_a_save, *args):
        page = ui.airport.AirportPage()
        params = {
            'iata': u'AAA',
            'icao': u'AAAA',
            'city': u'101',
            'redemption_zone': u'',
            'lat': u'1',
            'lon': u'2',
            'names': u'en:Aaa',
            'has_afl_flights': u'',
            'has_upgrade_on_checkin_award': u'',
            'form-MAX_NUM_FORMS': u'',
            'form-INITIAL_FORMS': u'0',
            'form-TOTAL_FORMS': u'2',
            'form-0-DELETE': u'',
            'form-0-terminal_id': u'',
            'form-0-names': u'en:11',
            'form-0-code': u'1',
            'form-1-DELETE': u'',
            'form-1-names': u'en:22',
            'form-1-code': u'2',
            'submit0': u'1'
        }
        self.assertEqual(2, len(self.airports))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_a_save.call_count, 1)
        self.assertEqual(mock_t_save.call_count, 2)
        self.assertEqual(3, len(self.airports))
        self.assertEqual(2, len(self.terminals))


class TestPartnerPage(TestEditorUIPage):
    _sql = _test_data.data_sql
    def setUp(self):
        super(TestPartnerPage, self).setUp()
        IRegisterable(models.partner.PartnerVocabulary).register()
        IRegisterable(models.static.ItemStatusVocabulary).register()
        IRegisterable(models.partner.PartnerMileActionVocabulary).register()
        IRegisterable(models.partner.PartnerCategoryVocabulary).register()

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.partner.PartnerPage.ob_class, 'save')
    def test_add(self, mock_p_save, *args):
        page = ui.partner.PartnerPage()
        params = {
            'names': u'en:New Partner',
            'partner_description': u'en:desc',
            'url': u'en:http://site.com',
            'partner_categories[]': u'1',
            'status': u'P',
            'mile_action': u'E',
            'weight': u'0',
            'mile_get_comm': u'ru:',
            'mile_waste_comm': u'ru:',
            'spec_offer_comm': u'ru:',
            'short_descr': u'ru:',
            'submit0': u'1'
            }

        self.assertEqual(1, len(getV('partners')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_p_save.call_count, 1)
        self.assertEqual(2, len(getV('partners')))

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.partner.PartnerCategory.title', new='')
    def test_search(self, *args):
        page = ui.partner.PartnerPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        body = page.index(partner_category='-2')
        html = htmlTree(body)
        self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        body = page.index(partner_category='-1')
        html = htmlTree(body)
        self.assertEqual(0, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestPartnerOfficePage(TestEditorUIPage):
    def setUp(self):
        super(TestPartnerOfficePage, self).setUp()
        self.partner_offices =  MutableTestVocab({}).register('partner_offices')
        self.partner_statuses = MutableTestVocab({u'P': u'Published'}).register('publication_statuses')
        self.partner_mile_actions = MutableTestVocab({u'E': u'Earn'}).register('partner_mile_actions')
        self.partner_office_types = MutableTestVocab({u'M': u'Main'}).register('partner_office_types')
        self.partner_office_contacts = MutableTestVocab({}).register('partner_office_contacts')
        ContactTypeVocabulary.register()
        self.partners = MutableTestVocab({ u'201': Partner(partner_id=201, names=[u'en:Partner1'],
                                                          partner_description=[u'en:Desc1'],
                                                          status=u'P', mile_action=u'E'),
                                        })
        self.partners.register('partners')

        self.cities = MutableTestVocab({u'201': City(city_id=201, tz=u'E/M', names=[u'en:City1'])})
        self.cities.register('cities')

        class _ContactByPartnerOffice(Indexer):
            name = 'contact_by_partner_office_idx'
            def key(self, ob):
                return str(ob.partner_office_id)
        _ContactByPartnerOffice().register()

    @mock.patch('django.forms.formsets._')
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.partner.PartnerOfficePage.ob_class, 'save')
    @mock.patch.object(ui.partner.PartnerOfficeContact, 'save')
    def test_add(self, mock_t_save, mock_a_save, *args):
        page = ui.partner.PartnerOfficePage()
        params = {
            'partner': u'201',
            'city': u'201',
            'comments': u'en:Abc',
            'address': u'en:Abc',
            'worktime': u'en:Abc',
            'office_type': u'M',
            'form-MAX_NUM_FORMS': u'',
            'form-INITIAL_FORMS': u'0',
            'form-TOTAL_FORMS': u'2',
            'form-0-partner_office_contact_id': u'',
            'form-0-contact_type': u'P',
            'form-0-contact': u'123' * 10,
            'form-0-main_contact': u'on',
            'form-0-DELETE': u'',
            'form-1-contact_type': u'E',
            'form-1-contact': u'some@some.ru',
            'form-1-DELETE': u'',
             'submit0': u'1'
        }
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_a_save.call_count, 1)
        self.assertEqual(mock_t_save.call_count, 2)
        self.assertEqual(1, len(getV('partner_offices')))
        self.assertEqual(2, len(getV('partner_office_contacts')))


class TestPairPage(TestEditorUIPage):
    def setUp(self):
        super(TestPairPage, self).setUp()

        self.airports = MutableTestVocab({u'1': models.airport.Airport(airport_id=1),
                                          u'2': models.airport.Airport(airport_id=2),
                                          u'3': models.airport.Airport(airport_id=3)}).register('airports')
        self.airlines = MutableTestVocab({u'1': models.air.Airline(airline_id=1),
                                          u'2': models.air.Airline(airline_id=2),
                                          u'3': models.air.Airline(airline_id=3)
                                          }).register('airlines')
        self.pairs = MutableTestVocab({
            u'1': models.route.Pair(pair_id=u'1', airline=u'1', airport_from=u'1', airport_to=u'2', miles=u'101'),
            u'2': models.route.Pair(pair_id=u'2', airline=u'2', airport_from=u'2', airport_to=u'1', miles=u'99')
            }).register('pairs')

    @mock.patch('auth.authorizeFor')
    @mock.patch('models.air.Airline.title', new='SomeAirlineTitle')
    @mock.patch('models.airport.Airport.title', new='SomeAirportTitle')
    def test_search(self, *args):
        page = ui.route.PairPage()
        body = page.index()
        html = htmlTree(body)
        self.assertEqual(2, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        for params in ({u'airline_id': u'1'},
                       {u'airline_id': u'1', 'airport_id': u'1'},
                       {u'airline_id': u'1', 'airport_id': u'2'}):
            body = page.index(**params)
            html = htmlTree(body)
            self.assertEqual(1, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

        params = {u'airline_id': u'1', 'airport_id': u'3'}
        body = page.index(**params)
        html = htmlTree(body)
        self.assertEqual(0, len(html.xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.route.PairPage.ob_class, 'save')
    def test_add(self, mock_pp_save, mock_title, *args):
        mock_title.return_value = 'SomeTitle'
        page = ui.route.PairPage()
        params = {
            'airline': u'3',
            'airport_from': u'1',
            'airport_to': u'2',
            'miles': u'500',
            'submit0': u'1'
        }
        self.assertEqual(2, len(getV('pairs')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_pp_save.call_count, 1)
        self.assertEqual(3, len(getV('pairs')))


class TestAirlineTariffGroupPage(TestEditorUIPage):
    _sql = _test_data.data_sql
    def setUp(self):
        super(TestAirlineTariffGroupPage, self).setUp()
        IRegisterable(models.route.PairsVocabulary).register()
        IRegisterable(models.air.AirlinesVocabulary).register()
        IRegisterable(models.bonus.TariffGroupsVocabulary).register()
        IRegisterable(models.service_classes.AirlineServiceClassVocabulary).register()
        IRegisterable(models.service_classes.SkyTeamServiceClassVocabulary).register()
        IRegisterable(models.airport.AirportsVocabulary).register()
        getV('airports').preload()
        self.airline_tariff_groups = MutableTestVocab({
            u'1': models.bonus.AirlineTariffGroup(idField=u'1', tariffGroup=getV('tariff_groups')['-1'],
                                                  serviceClass=getV('airline_service_classes')['-1'],
                                                  chargeCoef=75, weight=0,
                                                  fareCode='F')
            }).register('airline_tariff_groups')

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.bonus.AirlineTariffGroupPage.ob_class, 'save')
    def test_add(self, mock_atg_save, *args):
        page = ui.bonus.AirlineTariffGroupPage()
        params = {
            'tariffGroup': u'-1',
            'serviceClass': u'-2',
            'chargeCoef': u'60',
            'weight': u'1',
            'submit0': u'1',
            'fareCode': u'S'
        }
        self.assertEqual(1, len(getV('airline_tariff_groups')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_atg_save.call_count, 1)
        self.assertEqual(2, len(getV('airline_tariff_groups')))

        params = {
            'tariffGroup': u'-1',
            'serviceClass': u'-1',
            'chargeCoef': u'60',
            'weight': u'1',
            'submit0': u'1',
        }

        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_atg_save.call_count, 2)
        self.assertEqual(3, len(getV('airline_tariff_groups')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('auth.authorizeFor')
    @mock.patch('models.bonus.TariffGroup.title', new='SomeTGTitle')
    @mock.patch('models.air.Airline.title', new='SomeAirlineTitle')
    @mock.patch('models.service_classes.AirlineServiceClass.title', new='SomeServiceClassTitle')
    def test_search(self, *args):
        page = ui.bonus.AirlineTariffGroupPage()
        self.assertEqual(1, len(htmlTree(page.index()).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        self.assertEqual(1, len(htmlTree(page.index(airline_id=u'-1')).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        self.assertEqual(0, len(htmlTree(page.index(airline_id=u'-2')).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestOfficePage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestOfficePage, self).setUp()
        IRegisterable(models.office.OfficesVocabulary).register()
        IRegisterable(models.office.OfficeCategoryVocabulary).register()
        IRegisterable(models.office.OfficeTravelOptionVocabulary).register()
        IRegisterable(models.office.OfficeTravelOptionType).register()
        IRegisterable(models.airport.AirportsVocabulary).register()
        IRegisterable(models.geo.CitiesVocabulary).register()
        getV('airports').preload()
        getV('cities').preload()

        models.office.TravelOptionByOffice().register()
        getI('travel_option_by_office_idx')._reindex()

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.office.OfficePage.ob_class, 'save')
    @mock.patch.object(models.office.OfficeTravelOption, 'save')
    def test_add(self, mock_office_save, mock_travel_option_save, *args):
        page = ui.office.OfficePage()
        params = {
            'names': u'en:Astrakhanru:Астрахань',
            'office_description': u'en:office at the airport on the 2nd floor (no ticket sales)\nru:Офис в аэропорту на 2 этаже (без продажи авиабилетов)',
            'lat': u'46.2876',
            'lon': u'47.9998',
            'email': u'asftosu@aeroflot.ru',
            'fax': u'+7 (8512) 393139',
            'phone': u'+7 (8512) 393139',
            'office_category': u'-3',
            'airport': u'-3',
            'worktime': u'en:open every day: 24 hours\tru:Ежедневно: круглосуточно',
            'address': u'en:414023\r\nNarimanovo airport\tru:414023\r\nАэропорт "Нариманово"',
            'location_map': u'',
            'important_info': u'',
            'transfer_time_foot': u'',
            'transfer_time_automobile': u'20',
            'transfer_time_public': u'30',
            'distance_to_airport': u'12',
            'noncash_booking': u'on',
            'office_weight': u'123',
            'form-INITIAL_FORMS': u'0',
            'form-TOTAL_FORMS': u'1',
            'form-MAX_NUM_FORMS': u'',
            'form-0-DELETE': u'',
            'form-0-office_travel_option_id': u'',
            'form-0-travel_time': u'100',
            'form-0-office_travel_option_description': u'ru:Рус\nen:ENG',
            'form-0-travel_type': u'A',

            'submit0': u'1',
        }
        self.assertEqual(1, len(getV('offices')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_office_save.call_count, 1)
        self.assertEqual(mock_travel_option_save.call_count, 1)
        self.assertEqual(2, len(getV('offices')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('auth.authorizeFor')
    @mock.patch('models.airport.Airport.title', new='SomeAirportTitle')
    @mock.patch('models.geo.City.title', new='SomeCityTitle')
    @mock.patch('models.office.OfficeCategory.title', new='SomeCatTitle')
    def test_search(self, *args):
        page = ui.office.OfficePage()
        self.assertEqual(1, len(htmlTree(page.index()).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        self.assertEqual(1, len(htmlTree(page.index(city_id=u'-3')).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        self.assertEqual(0, len(htmlTree(page.index(city_id=u'-1')).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestBookingClassPage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestBookingClassPage, self).setUp()
        IRegisterable(models.bonus.AirlineTariffGroupsVocabulary).register()
        IRegisterable(models.route.PairsVocabulary).register()
        IRegisterable(models.air.AirlinesVocabulary).register()
        IRegisterable(models.airport.AirportsVocabulary).register()
        IRegisterable(models.service_classes.AirlineServiceClassVocabulary).register()

        self.service_classes = TestVocab({
            'lux': SkyTeamServiceClass(
                skyteam_sc_id=-1,
                code='xxxxxxx', names=[u'ru:Lux', 'en:Люкс']
            )
        })
        self.service_classes.register('skyteam_service_classes')

        self.tariff_groups = MutableTestVocab({
            u'-1': models.bonus.TariffGroup(
                tariff_group = u'xxxxxxx-1',
                names =[u'en:name1', u'ru:name2'],
                submit0=u'1',
                service_class=self.service_classes['lux']
            )
        })
        self.tariff_groups.register('tariff_groups')

        getV('airports').preload()
        self.booking_classes = MutableTestVocab({
            u'1': models.bonus.BookingClass(idField=u'1', bcCode=u'Z', milesAreCharged=True, alTariffGroup=getV('airline_tariff_groups')['-1'])
            }).register('booking_classes')

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.bonus.BookingClassPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.bonus.BookingClassPage()
        params = {
            'alTariffGroup': u'-1',
            'bcCode': u'E',
            'milesAreCharged': u'0',
            'comment': u'en:Nothing',
            'submit0': u'1'
        }
        self.assertEqual(1, len(getV('booking_classes')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(2, len(getV('booking_classes')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    @mock.patch('auth.authorizeFor')
    @mock.patch('models.bonus.AirlineTariffGroup.title', new='SomeAirlineTitle')
    @mock.patch('models.air.Airline.title', new='SomeAirlineTitle')
    def test_search(self, *args):
        page = ui.bonus.BookingClassPage()
        self.assertEqual(1, len(htmlTree(page.index()).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        self.assertEqual(1, len(htmlTree(page.index(airline_id=u'-1')).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))
        self.assertEqual(0, len(htmlTree(page.index(airline_id=u'-2')).xpath(u'//table[@class="object_list"]/tbody/tr/td/..')))


class TestLanguagePage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestLanguagePage, self).setUp()
        IRegisterable(models.lang.LanguageVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.lang.LanguagePage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.lang.LanguagePage()
        params = {
            'alpha2_code': u'YY',
            'alpha3_code': u'YYY',
            'selector_code': u'YYY',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1'
        }
        self.assertEqual(1, len(getV('languages')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(2, len(getV('languages')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.lang.LanguagePage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 4)
        for field in ('alpha2_code', 'alpha3_code', 'selector_code', 'names'):
            self.assertEqual(form.errors[field], [u'This field is required.'])

        params = {
            'names': u'name1\nname2',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertEqual(len(form.errors), 4)
        self.assertFalse(form.is_valid())
        self.assertEqual(
            form.errors['names'],
            [u'Введите словарь названий в формате код-языка:название. '
             u'(Например: ru:Москва).']
        )

        params = {
            'alpha2_code': u'YY',
            'alpha3_code': u'YYY',
            'selector_code': u'YYY',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertIn(u'ru:YYY', form.cleaned_data['names'])
        self.assertIn(u'en:YYY', form.cleaned_data['names'])
        self.assertEqual(len(form.errors), 0)


class TestLocalizationPage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestLocalizationPage, self).setUp()
        IRegisterable(models.lang.LanguageVocabulary).register()
        IRegisterable(models.lang.LocalizationVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.lang.LocalizationPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.lang.LocalizationPage()
        params = {
            'code': u'YY',
            'names': u'ru:YYY\nen:YYY',
            'default_language': u'XX',
            'allowed_languages': u'XX\nYY',
            'is_active': u'on',
            'submit0': u'1',
        }
        self.assertEqual(1, len(getV('localizations')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(2, len(getV('localizations')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.lang.LocalizationPage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 4)
        for field in ('code', 'names', 'default_language', 'allowed_languages'):
            self.assertEqual(form.errors[field], [u'This field is required.'])

        params = {
            'names': u'name1\nname2',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertEqual(len(form.errors), 4)
        self.assertFalse(form.is_valid())
        self.assertEqual(
            form.errors['names'],
            [u'Введите словарь названий в формате код-языка:название. '
             u'(Например: ru:Москва).']
        )

        params = {
            'code': u'YY',
            'names': u'ru:YYY\nen:YYY',
            'default_language': u'XX',
            'allowed_languages': u'XX\nYY',
            'is_active': u'on',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertIn(u'ru:YYY', form.cleaned_data['names'])
        self.assertIn(u'en:YYY', form.cleaned_data['names'])
        self.assertEqual(len(form.errors), 0)


class TestSpecialMealPage(testlib.TestCaseWithPgDBAndVocabs,
                          testlib.TestCaseWithLenientRoutes):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestSpecialMealPage, self).setUp()
        IRegisterable(models.meal.SpecialMealVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.meal.SpecialMealPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.meal.SpecialMealPage()
        params = {
            'code': u'YYYY',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1'
        }
        self.assertEqual(1, len(getV('special_meal')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(2, len(getV('special_meal')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.meal.SpecialMealPage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(len(form.errors), 2)
        for field in ('code', 'names'):
            self.assertEqual(form.errors[field], [u'This field is required.'])

        params = {
            'names': u'name1\nname2',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertEqual(len(form.errors), 2)
        self.assertFalse(form.is_valid())
        self.assertEqual(
            form.errors['names'],
            [u'Введите словарь названий в формате код-языка:название. '
             u'(Например: ru:Москва).']
        )

        params = {
            'code': u'YYYY',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertIn(u'ru:YYY', form.cleaned_data['names'])
        self.assertIn(u'en:YYY', form.cleaned_data['names'])
        self.assertEqual(len(form.errors), 0)


class TestAncillaryServicesGroupPage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAncillaryServicesGroupPage, self).setUp()
        IRegisterable(models.ancillary_services.AncillaryServicesGroupVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.AncillaryServicesGroupPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.ancillary_services.AncillaryServicesGroupPage()
        params = {
            'names': u'ru:YYY\nen:YYY',
            'ordinal_number': '40',
            'filename': 'yyy',
            'submit0': u'1',
            'message': u'ru:YYY\nen:YYY'
        }
        self.assertEqual(3, len(getV('ancillary_services_groups')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(4, len(getV('ancillary_services_groups')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.ancillary_services.AncillaryServicesGroupPage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'names': [u'This field is required.'],
            'ordinal_number': [u'This field is required.'],
            'filename': [u'This field is required.']
        })

        params = {
            'names': u'YYY\nYYY',
            'ordinal_number': u'40',
            'filename': 'y',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'names': [u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'],
            'filename': [u'Ensure this value has at least 3 characters (it has 1).'],
        })

        params = {
            'names': u'ru:YYY\nen:YYY',
            'ordinal_number': u'40',
            'filename': 'yyy',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data, {
            'names': [u'ru:YYY', u'en:YYY'],
            'ordinal_number': 40,
            'filename': 'yyy',
            'message': []
        })
        self.assertFalse(form.errors)


class TestRFICCodePage(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithLenientRoutes):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestRFICCodePage, self).setUp()
        IRegisterable(models.ancillary_services.RFICCodeVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.RFICCodePage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.ancillary_services.RFICCodePage()
        params = {
            'code': 'Y',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1'
        }
        self.assertEqual(3, len(getV('rfic_codes')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(4, len(getV('rfic_codes')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.ancillary_services.RFICCodePage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'code': [u'This field is required.'],
            'names': [u'This field is required.'],
        })

        params = {
            'code': 'YY',
            'names': u'YYY\nYYY',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'code': [u'Ensure this value has at most 1 characters (it has 2).'],
            'names': [u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'],
        })

        params = {
            'code': 'Y',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data, {'code': u'Y', 'names': [u'ru:YYY', u'en:YYY']})
        self.assertFalse(form.errors)


class TestAncillaryServicePage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAncillaryServicePage, self).setUp()
        IRegisterable(models.ancillary_services.AncillaryServicesGroupVocabulary).register()
        IRegisterable(models.ancillary_services.RFICCodeVocabulary).register()
        IRegisterable(models.ancillary_services.AncillaryServiceVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.AncillaryServicePage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.ancillary_services.AncillaryServicePage()
        params = {
            'code': 'YYY',
            'names': u'ru:YYY\nen:YYY',
            'descriptions': u'ru:AAA\ten:AAA',
            'ancillary_services_group': '1',
            'rfic': 'A',
            'submit0': u'1'
        }
        self.assertEqual(3, len(getV('ancillary_services')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(4, len(getV('ancillary_services')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.ancillary_services.AncillaryServicePage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'code': [u'This field is required.'],
            'names': [u'This field is required.'],
            'ancillary_services_group': [u'This field is required.'],
            'rfic': [u'This field is required.'],
        })

        params = {
            'code': 'Y',
            'names': u'YYY\nYYY',
            'descriptions': u'AAA\tAAA',
            'ancillary_services_group': '1',
            'rfic': 'A',
            'submit0': u'1'
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'code': [u'Ensure this value has at least 3 characters (it has 1).'],
            'names': [u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'],
            'descriptions': [u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'],
        })

        params = {
            'code': 'YYY',
            'names': u'ru:YYY\nen:YYY',
            'descriptions': u'ru:AAA\ten:AAA',
            'ancillary_services_group': '1',
            'rfic': 'A',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data, {
            'code': u'YYY',
            'names': [u'ru:YYY', u'en:YYY'],
            'descriptions': [u'ru:AAA', u'en:AAA'],
            'ancillary_services_group': models.ancillary_services.AncillaryServicesGroup(
                ancillary_services_group_id=1,
                names=[u'en:Ancillary Services', u'ru:Дополнительные услуги'],
                ordinal_number=10,
                filename='ancillary',
                message=[u'en:Ancillary Services', u'ru:Дополнительные услуги']
            ),
            'rfic': models.ancillary_services.RFICCode(
                code='A',
                names=[u'en:Air Transportation'],
            ),
            'doc_prefix': [],
            'emd_message': []
        })
        self.assertFalse(form.errors)

        # Тест поля doc_prefix и emd_message
        params = {
            'code': 'YYY',
            'names': u'ru:YYY\nen:YYY',
            'descriptions': u'ru:AAA\ten:AAA',
            'ancillary_services_group': '1',
            'rfic': 'A',
            'submit0': u'1',
            'doc_prefix': u'ru:Тест\ten:Test',
            'emd_message': u'ru:Тест\ten:Test'
        }

        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data, {
            'code': u'YYY',
            'names': [u'ru:YYY', u'en:YYY'],
            'descriptions': [u'ru:AAA', u'en:AAA'],
            'ancillary_services_group': models.ancillary_services.AncillaryServicesGroup(
                ancillary_services_group_id=1,
                names=[u'en:Ancillary Services', u'ru:Дополнительные услуги'],
                ordinal_number=10,
                filename='ancillary',
                message=[u'en:Ancillary Services', u'ru:Дополнительные услуги']
            ),
            'rfic': models.ancillary_services.RFICCode(
                code='A',
                names=[u'en:Air Transportation'],
            ),
            'doc_prefix': [u'ru:Тест', u'en:Test'],
            'emd_message': [u'ru:Тест', u'en:Test']
        })
        self.assertFalse(form.errors)


class TestAncillaryServiceStatusPage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAncillaryServiceStatusPage, self).setUp()
        IRegisterable(models.ancillary_services.AncillaryServiceStatusVocabulary).register()
        IRegisterable(models.ancillary_services.RFICCodeVocabulary).register()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.AncillaryServiceStatusPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.ancillary_services.AncillaryServiceStatusPage()
        params = {
            'code': 'YY',
            'names': u'ru:YYY\nen:YYY',
            'rfic': u'B',
            'rfisc': u'0BQ',
            'submit0': u'1'
        }
        self.assertEqual(2, len(getV('ancillary_service_statuses')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(3, len(getV('ancillary_service_statuses')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.ancillary_services.AncillaryServiceStatusPage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'code': [u'This field is required.'],
            'names': [u'This field is required.'],
        })

        params = {
            'code': 'Y',
            'names': u'YYY\nYYY',
            'submit0': u'1',
            'rfic': u'A',
            'rfisc': u'Y',
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'rfisc': [u'Ensure this value has at least 3 characters (it has 1).'],
            'code': [u'Ensure this value has at least 2 characters (it has 1).'],
            'names': [u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'],
        })

        params = {
            'code': 'YY',
            'names': u'ru:YYY\nen:YYY',
            'submit0': u'1',
            'rfic': u'A',
            'rfisc': u'YYY',
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['names'], [u'ru:YYY', u'en:YYY'])
        self.assertEqual(form.cleaned_data['rfic'], models.ancillary_services.RFICCode(
            code='A',
            names=[u'en:Air Transportation'],
        ))
        self.assertEqual(form.cleaned_data['rfisc'], u'YYY')
        self.assertFalse(form.errors)


class TestAdditionalInfoPage(TestEditorUIPage):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestAdditionalInfoPage, self).setUp()
        IRegisterable(models.additional_info.AdditionalInfoVocabulary).register()
        ui.field_adapters.register_adapters()
        if not settings.configured:
            settings.configure()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.additional_info.AdditionalInfoPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.additional_info.AdditionalInfoPage()
        params = {
            'additional_info_id': '3',
            'weight': '1',
            'names': u'ru:МСДЖ',
            'created': '2015-01-01',
            'condition': '[{"airport_from": "LED"}]',
            'submit0': u'1'
        }
        self.assertEqual(2, len(getV('additional_info')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(3, len(getV('additional_info')))

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_fields(self, *args):
        page = ui.additional_info.AdditionalInfoPage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'weight': [u'This field is required.'],
            'names': [u'This field is required.'],
            'condition': [u'This field is required.'],
        })

        params = {
            'weight': u'a',
            'created': '2015-01-',
            'names': u'МСДЖ\nMSG',
            'condition': u'[{"airport_from": "LED"}',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'weight': [u'Enter a whole number.'],
            'created': [u'Enter a valid date.'],
            'names': [u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'],
            'condition': [u'Неправильный формат JSON'],
        })

        params = {
            'weight': u'1',
            'created': '2015-01-01',
            'names': u'ru:МСДЖ\nen:MSG',
            'condition': u'[{"airport_from": "LED"}]',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data, {
            'condition': u'[{"airport_from": "LED"}]',
            'created': date(2015, 1, 1),
            'names': [u'ru:МСДЖ', u'en:MSG'],
            'weight': 1,
        })
        self.assertFalse(form.errors)


class TestVatRates(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithLenientRoutes):
    _sql = _test_data.data_sql

    default_params = dict(
        submit0=u'1',
        vat_rate_id=-1,
        rfic=u'A',
        rfisc=u'AAA',
        rate=0.,
        start_date=datetime.now().replace(microsecond=0),
        stop_date=datetime.now().replace(microsecond=0) + timedelta(days=1)
    )

    def setUp(self):
        super(TestVatRates, self).setUp()
        IRegisterable(models.ancillary_services.VatRatesVocabulary).register()
        ui.field_adapters.register_adapters()
        if not settings.configured:
            settings.configure()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.VatRatesPage.ob_class, 'save')
    def test_add_new(self, *args):
        page = ui.ancillary_services.VatRatesPage()
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**self.default_params)

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_form_with_overlapes_dates(self, **args):
        getV('vat_rates').add(VatRate(**self.default_params))
        params = self.default_params.update(vat_rate_id=-2)
        form = VatRatesForm(params)
        self.assertFalse(form.is_valid())

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_change_form(self, **args):
        getV('vat_rates').add(VatRate(**self.default_params))
        form = VatRatesForm(self.default_params)
        self.assertTrue(form.is_valid())

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_form_with_non_overlapes_dates(self, **args):
        getV('vat_rates').add(VatRate(**self.default_params))
        params = self.default_params.copy()
        params['start_date'] = params['stop_date'] + timedelta(days=1)
        params['stop_date'] = None
        form = VatRatesForm(params)
        self.assertTrue(form.is_valid())

    @mock.patch('django.utils.translation.real_ugettext', new=lambda x: x)
    def test_form_with_overlapes_dates_but_different_codes(self, **args):
        getV('vat_rates').add(VatRate(**self.default_params))
        params = self.default_params.copy()
        params['rfic'] = 'B'
        form = VatRatesForm(params)
        self.assertTrue(form.is_valid())


class TestVatRatePage(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithLenientRoutes, testlib.TestCaseWithCP):

    def setUp(self):
        super(TestVatRatePage, self).setUp()
        IRegisterable(models.ancillary_services.VatRatesVocabulary).register()
        ui.field_adapters.register_adapters()
        if not settings.configured:
            settings.configure()
        self.page = ui.ancillary_services.VatRatesPage()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.VatRatesPage.ob_class, 'save')
    def test_page_add_new(self, *args):
        params = dict(submit0=u'1', rate=10, rfic='A', rfisc='AAA')
        self.assertEqual(len(getV('vat_rates')), 0)

        with self.assertRaises(cherrypy.HTTPRedirect):
            self.page.add(**params)

        self.assertEqual(len(getV('vat_rates')), 1)

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.VatRatesPage.ob_class, 'save')
    def test_page_add_new_if_vat_rate_for_this_rfic_and_rfisc_exists_with_overlap(self, *args):
        params = dict(submit0=u'1', rate=10, rfic='A', rfisc='AAA')

        vocab = getV('vat_rates')
        existing_vat_rate = VatRate(stop_date=datetime.now(), vat_rate_id=-1, **params)
        vocab.add(existing_vat_rate)

        self.assertEqual(len(vocab), 1)
        _log_level = logging.root.level
        try:
            logging.root.setLevel(logging.CRITICAL)  # чтобы в тестовую консоль не сыпались ошибки django-формы
            self.page.add(**params)
        finally:
            logging.root.setLevel(_log_level)
        self.assertEqual(len(vocab), 1)

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.VatRatesPage.ob_class, 'save')
    def test_page_add_new_if_vat_rate_for_this_rfic_and_rfisc_exists_with_not_overlap(self, *args):
        params = dict(submit0=u'1', rate=10, rfic='A', rfisc='AAA')

        vocab = getV('vat_rates')
        existing_vat_rate = VatRate(stop_date=datetime.now(), vat_rate_id=-1, **params)
        vocab.add(existing_vat_rate)

        self.assertEqual(len(vocab), 1)

        with self.assertRaises(cherrypy.HTTPRedirect):
            self.page.add(start_date=datetime.now() + timedelta(days=1), **params)

        self.assertEqual(len(vocab), 2)

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.ancillary_services.VatRatesPage.ob_class, 'save')
    def test_page_edit(self, *args):
        params = dict(submit0=u'1', rate=10, rfic='A', rfisc='AAA', vat_rate_id=-1, start_date=datetime.now() + timedelta(days=1))

        vocab = getV('vat_rates')
        existing_vat_rate = VatRate(**params)
        vocab.add(existing_vat_rate)

        self.assertEqual(len(vocab), 1)

        params.update(start_date=None)
        self.page.edit(**params)

        self.assertEqual(len(vocab), 1)


class TestMealRulePage(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithLenientRoutes, testlib.TestCaseWithCP):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestMealRulePage, self).setUp()
        IRegisterable(models.airport.AirportsVocabulary).register()
        getV('airports').preload()
        IRegisterable(models.meal.SpecialMealVocabulary).register()
        IRegisterable(models.air.AirlinesVocabulary).register()
        IRegisterable(models.bonus.BookingClassesVocabulary).register()
        IRegisterable(models.meal.MealRulesVocabulary).register()

        import ui.field_adapters
        ui.field_adapters.register_adapters()
        from django.conf import settings
        if not settings.configured:
            settings.configure()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.meal.MealRulePage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.meal.MealRulePage()
        params = {
            'meal_rule_id': '2',
            'date_from': '2000-01-01',
            'date_to': '2020-01-01',
            'number': '1,3-5',
            'airline': '-1',
            'origin': '-4',
            'destination': '-4',
            'booking_class': '-1',
            'special_meal': 'XXXX',
            'submit0': u'1',
        }
        self.assertEqual(1, len(getV('meal_rules')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(2, len(getV('meal_rules')))

    def test_fields(self, *args):
        page = ui.meal.MealRulePage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {'meal_rule_id': [u'This field is required.']})

        params = {
            'meal_rule_id': 'a',
            'date_from': '2000-01-',
            'date_to': '-01-01',
            'number': '1,',
            'airline': '-1',
            'origin': '-4',
            'destination': '-4',
            'booking_class': '-1',
            'special_meal': 'XXXX',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {
            'meal_rule_id': [u'Enter a whole number.'],
            'date_from': [u'Enter a valid date.'],
            'date_to': [u'Enter a valid date.'],
            'number': [u'Неправильный формат'],
        })

        params = {
            'meal_rule_id': '2',
            'date_from': '2000-01-01',
            'date_to': '2020-01-01',
            'number': '1,3-5',
            'airline': '-1',
            'origin': '-4',
            'destination': '-4',
            'booking_class': '-1',
            'special_meal': 'XXXX',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['meal_rule_id'], 2)
        self.assertEqual(form.cleaned_data['date_from'], date(2000, 1, 1))
        self.assertEqual(form.cleaned_data['date_to'], date(2020, 1, 1))
        self.assertEqual(form.cleaned_data['number'], '1,3-5')
        self.assertEqual(form.cleaned_data['airline'], [getV('airlines')[-1]])
        self.assertEqual(form.cleaned_data['origin'], [getV('airports')[-4]])
        self.assertEqual(form.cleaned_data['destination'], [getV('airports')[-4]])
        self.assertEqual(form.cleaned_data['booking_class'], [getV('booking_classes')[-1]])
        self.assertEqual(form.cleaned_data['special_meal'], [getV('special_meal')['XXXX']])
        self.assertFalse(form.errors)


class TestMealTimelimitPage(testlib.TestCaseWithPgDBAndVocabs, testlib.TestCaseWithLenientRoutes, testlib.TestCaseWithCP):
    _sql = _test_data.data_sql

    def setUp(self):
        super(TestMealTimelimitPage, self).setUp()
        IRegisterable(models.airport.AirportsVocabulary).register()
        getV('airports').preload()
        IRegisterable(models.meal.SpecialMealVocabulary).register()
        IRegisterable(models.meal.MealTimelimitsVocabulary).register()

        from django.conf import settings
        if not settings.configured:
            settings.configure()

    @mock.patch('auth.authorizeFor')
    @mock.patch('ui.edit.notify')
    @mock.patch.object(ui.meal.MealTimelimitPage.ob_class, 'save')
    def test_add(self, mock_bclp_save, *args):
        page = ui.meal.MealTimelimitPage()
        params = {
            'meal_timelimit_id': '2',
            'origin': '-3',
            'special_meal': '',
            'timelimit': '0',
            'submit0': u'1',
        }
        self.assertEqual(1, len(getV('meal_timelimits')))
        with self.assertRaises(cherrypy.HTTPRedirect):
            page.add(**params)

        self.assertEqual(mock_bclp_save.call_count, 1)
        self.assertEqual(2, len(getV('meal_timelimits')))

    def test_fields(self, *args):
        page = ui.meal.MealTimelimitPage()
        form_cls = form_from_iface(page.iface_fields, page.ob_name)

        params = {'submit0': u'1'}
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {'timelimit': [u'This field is required.'], 'meal_timelimit_id': [u'This field is required.']})

        params = {
            'meal_timelimit_id': 'asdf',
            'origin': '-4',
            'special_meal': 'XXXX',
            'timelimit': 'a',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertFalse(form.is_valid())
        self.assertEqual(form.errors, {'timelimit': [u'Enter a whole number.'], 'meal_timelimit_id': [u'Enter a whole number.']})

        params = {
            'meal_timelimit_id': '2',
            'origin': '-4',
            'special_meal': 'XXXX',
            'timelimit': '0',
            'submit0': u'1',
        }
        form = form_cls(params)
        self.assertTrue(form.is_valid())
        self.assertEqual(form.cleaned_data['meal_timelimit_id'], 2)
        self.assertEqual(form.cleaned_data['origin'], [getV('airports')[-4]])
        self.assertEqual(form.cleaned_data['special_meal'], [getV('special_meal')['XXXX']])
        self.assertEqual(form.cleaned_data['timelimit'], 0)
        self.assertFalse(form.errors)


if __name__ == '__main__':
    testoob.main()
