#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
$Id: __init__.py 0 2016-08-10 16:09:00Z kmakarov $
"""
from pyramid.tests import testlib

from rx.i18n.translation import init_i18n


class TestWithI18n(testlib.TestCaseWithI18N):
    def setUp(self):
        super(TestWithI18n, self).setUp()
        init_i18n()

    def tearDown(self):
        super(TestWithI18n, self).tearDown()
        self._unregisterTranslationDomains('self_translate', 'bilingual_translate')


class TestEditorUIPage(TestWithI18n, testlib.TestCaseWithDBAndVocabs, testlib.TestCaseWithLenientRoutes,
                       testlib.TestCaseWithCP, ):
    pass
