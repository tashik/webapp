# -*- coding: utf-8 -*-

"""
$Id: test_notify.py 26302 2017-08-14 10:59:09Z anovgorodov $
"""

import json
import mock
import unittest

from django.conf import settings
from pyramid.tests import testlib
import testoob
from zope.schema.vocabulary import SimpleTerm

from models.air import Airline
from models.airport import Airport
from models.bonus import RedemptionZone, TierLevel, BonusRoute, BookingClass
from models.ancillary_services import AncillaryServicesGroup, RFICCode
from models.geo import City
from models.indexer import Indexer
import models.office
from models.lang import Language
from models.meal import SpecialMeal
from models.partner import PartnerCategory, Partner
from models.route import Pair
from models.service_classes import (SkyTeamServiceClass, AirlineServiceClass,
                                    Comment)
from tests import TestEditorUIPage
from testvocab import MutableTestVocab
import notify
from ui.edit import ObjectEditPage
import ui.additional_info
import ui.air
import ui.airport
import ui.ancillary_services
import ui.bonus
import ui.currency
import ui.geo
import ui.lang
import ui.meal
import ui.member
import ui.office
import ui.partner
import ui.route
import ui.service_classes
from testvocab import MutableTestVocab


if not settings.configured:
    settings.configure()


class TestNotify(unittest.TestCase):

    @mock.patch('notify.as_json')
    @mock.patch('notify.post')
    def test_post_events(self, mock_post, mock_json):
        mock_json.side_effect = lambda d: d
        notify.post_events(('add', {'spam': 42}))
        mock_post.assert_called_once_with(
            'vocabs', [{'objects': {'spam': 42}, 'event': 'add'}])

    @mock.patch('notify.config')
    @mock.patch('notify.pbus_opener')
    def test_on_object_added(self, mock_pbus_opener, mock_config):
        mock_config.PBUS_URL = '127.0.0.1'
        obj = {'spam': 42, 'egg': 777}

        notify.on_object_added(obj)
        self.assertEqual(mock_pbus_opener.open.call_count, 1)
        request = mock_pbus_opener.open.call_args[0][0]
        self.assertEqual(
            json.loads(request.data),
            [{'objects': [{'spam': 42, 'egg': 777}], 'event': 'add'}])

    @mock.patch('notify.config')
    @mock.patch('notify.pbus_opener')
    def test_on_object_changed(self, mock_pbus_opener, mock_config):
        mock_config.PBUS_URL = '127.0.0.1'
        obj = {'spam': 42, 'egg': 777}

        notify.on_object_changed(obj)
        self.assertEqual(mock_pbus_opener.open.call_count, 1)
        request = mock_pbus_opener.open.call_args[0][0]
        self.assertEqual(
            json.loads(request.data),
            [{'objects': [{'spam': 42, 'egg': 777}], 'event': 'change'}])

    @mock.patch('notify.config')
    @mock.patch('notify.pbus_opener')
    def test_on_object_deleted(self, mock_pbus_opener, mock_config):
        mock_config.PBUS_URL = '127.0.0.1'
        obj = {'spam': 42, 'egg': 777}

        notify.on_object_deleted(obj)
        self.assertEqual(mock_pbus_opener.open.call_count, 1)
        request = mock_pbus_opener.open.call_args[0][0]
        self.assertEqual(
            json.loads(request.data),
            [{'objects': [{'spam': 42, 'egg': 777}], 'event': 'delete'}])

    @mock.patch('notify.config')
    @mock.patch('notify.pbus_opener')
    def test_subscribe(self, mock_pbus_opener, mock_config):
        mock_config.PBUS_URL = '127.0.0.1'
        mock_config.PBUS_CALLBACK_HOST = '127.0.0.2'
        mock_config.PBUS_CALLBACK_PORT = '42'
        mock_config.VIRTUAL_BASE = '/base'
        notify.subscribe('some_topic')
        mock_pbus_opener.open.assert_called_once_with(
            '127.0.0.1/some_topic/subscribe/http%253A%252F%252F127.0.0.2'
            '%253A42%252Fbase%252Fnotify%252Fsome_topic', '')


# FIXME: этот класс нужно вынести из тестов, чтобы логика test discovery его не видела
class _BaseTestPageNotify(TestEditorUIPage, testlib.TestCaseWithAuth, ):
    def __init__(self, *args, **kwargs):
        super(_BaseTestPageNotify, self).__init__(*args, **kwargs)

    _allow_roles = ['admin']
    page_cls = NotImplemented
    ob_params = NotImplemented
    ob_edit_params = {}
    extra_form_params = {}
    primary_fields = NotImplemented

    def setUp(self):
        if self.__class__ == _BaseTestPageNotify:
            self.skipTest('Not supposed to be run directly')

        super(_BaseTestPageNotify, self).setUp()

        import ui.field_adapters
        ui.field_adapters.register_adapters()

        self.vocab = MutableTestVocab({}, objectC=self.page_cls.ob_class)
        self.vocab.register(self.page_cls.vocab_name)

        self.registerTestAuthenticator()
        self._createTestUser()
        self.user.role = 'admin'
        self.authenticator.user = self.user

    @mock.patch('django.forms.formsets._')
    @mock.patch('notify.on_object_added')
    @mock.patch('ui.edit.resolveRoute')
    @mock.patch('ui.edit.ui.template.renderTemplate')
    def test_page_add_notify(
            self, mock_render_template, mock_resolve_route,
            mock_on_object_added, translate):
        mock_save = mock.patch.object(self.page_cls.ob_class, 'save')
        mock_page = mock.patch.object(ObjectEditPage, '__bases__', (mock.Mock,))

        with mock_page, mock_save:
            mock_page.is_local = True
            mock_save.is_local = True
            page = self.page_cls()
            page._allow_roles = self._allow_roles
            params = {}
            params.update(self.ob_params)
            params.update({'submit0': '1'})
            params.update(self.extra_form_params)
            # page.add(**params)
            # self.assertEqual(mock_on_object_added.called, 1)

            from zope.interface.interfaces import ComponentLookupError
            try:
                page.add(**params)
            except ComponentLookupError as err:
                page.add(**params)

            if not mock_on_object_added.called:
                page.add(**params)

    @mock.patch('django.forms.formsets._')
    @mock.patch('notify.on_object_changed')
    @mock.patch('ui.edit.resolveRoute')
    @mock.patch('ui.edit.ui.template.renderTemplate')
    def test_page_edit_notify(
            self, mock_render_template, mock_resolve_route,
            mock_on_object_changed, translate):
        mock_save = mock.patch.object(self.page_cls.ob_class, 'save')
        mock_page = mock.patch.object(ObjectEditPage, '__bases__', (mock.Mock,))
        new_ob_params = {}
        new_ob_params.update(self.ob_params)
        new_ob_params.update(self.primary_fields)
        self.vocab.add(self.page_cls.ob_class(**new_ob_params))

        with mock_page, mock_save:
            mock_page.is_local = True
            mock_save.is_local = True
            page = self.page_cls()
            page._allow_roles = self._allow_roles
            params = {}
            params.update(self.ob_params)
            params.update(self.primary_fields)
            params.update({'submit0': '1'})
            params.update(self.ob_edit_params)
            params.update(self.extra_form_params)
            page.edit(**params)
            self.assertEqual(mock_on_object_changed.called, 1)

    @mock.patch('notify.on_object_deleted')
    @mock.patch('ui.edit.resolveRoute')
    @mock.patch('ui.edit.ui.template.renderTemplate')
    def test_page_delete_notify(
            self, mock_render_template, mock_resolve_route,
            mock_on_object_deleted):
        mock_save = mock.patch.object(self.page_cls.ob_class, 'save')
        mock_page = mock.patch.object(ObjectEditPage, '__bases__', (mock.Mock,))
        new_ob_params = {}
        new_ob_params.update(self.ob_params)
        new_ob_params.update(self.primary_fields)
        self.vocab.add(self.page_cls.ob_class(**new_ob_params))

        with mock_page, mock_save:
            mock_page.is_local = True
            mock_save.is_local = True
            page = self.page_cls()
            page._allow_roles = self._allow_roles
            page.delete(**self.primary_fields)
            self.assertEqual(mock_on_object_deleted.called, 1)


class TestWorldRegionPage(_BaseTestPageNotify):
    page_cls = ui.geo.WorldRegionPage
    ob_params = {
        'names': [u'en:Russia', ],
    }
    primary_fields = {'world_region_id': 101}


class TestCountryPage(_BaseTestPageNotify, ):
    page_cls = ui.geo.CountryPage
    ob_params = {
        'iso_code2': u'RU',
        'names': [u'en:Russia', ],
        'currency': u'RUB'
    }
    primary_fields = {'iso_code2': u'DE'}

    def setUp(self):
        super(TestCountryPage, self).setUp()
        v = MutableTestVocab({}, objectC=ui.currency.CurrencyPage.ob_class)
        v.add(ui.currency.CurrencyPage.ob_class(alpha3_code='RUB', iso_code='RUB', minor_unit=2, names=["en:rouble", ]))
        v.register("currencies")

        # currency_class = ui.currency.CurrencyPage.ob_class
        # self.v_currencies = MutableTestVocab({'RUB': currency_class(alpha3_code=u'RUB', iso_code=u'123',
        #                                                             minor_unit=u'2', names=u"en:Ruble'"),
        #                                       },
        #                                      objectC=ui.currency.CurrencyPage.ob_class)
        # self.v_currencies.register(ui.currency.CurrencyPage.vocab_name)

class TestCityPage(_BaseTestPageNotify, ):
    page_cls = ui.geo.CityPage
    ob_params = {
        'country_code': u'RU',
        'tz': u'Europe/Moscow',
        'iata': u'ABC',
        'names': [u'en:Abc', ],
    }
    primary_fields = {'city_id': 101}


class TestAirlinePage(_BaseTestPageNotify, ):
    page_cls = ui.air.AirlinePage
    ob_params = {
        'names': [u'en:Abc', ],
        'weight': u'1',
        'url': u'ru:http://some.ru/ru',
        'miles_minimum': '0.0',
        'miles_limitation': 'N',
        'miles_earn_description': u'ru:AAAA\nen:BBBB',
        'miles_earn_comment': u'ru:CCCC\nen:DDDD'
    }
    primary_fields = {'airline_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({u'N': SimpleTerm('N', 'N')})
        vocab.register('miles_limitations')


class TestAircraftTypePage(_BaseTestPageNotify, ):
    page_cls = ui.air.AircraftTypePage
    ob_params = {
        'names': [u'en:Abc', ]
    }
    primary_fields = {'aircraft_type_id': 101}


class TestAirportPage(_BaseTestPageNotify, ):
    page_cls = ui.airport.AirportPage
    ob_params = {
        'iata': u'ABC',
        'city': u'201',
        'names': [u'en:Abc', ],
    }
    extra_form_params = {
        'form-TOTAL_FORMS': u'1',
        'form-INITIAL_FORMS': u'0',
        'form-MAX_NUM_FORMS': u'',
        'form-0-DELETE': u'',
        'form-0-code': u'',
        'form-0-terminal_id': u'',
        'form-0-names': u''
    }
    primary_fields = {'airport_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            u'201': City(city_id=201, tz=u'E/M', names=[u'en:City1'])
        })
        vocab.register('cities')
        MutableTestVocab({}).register('airport_terminals')

        class _TerminalsByAirport(Indexer):
            name = 'terminals_by_airport_idx'
            def key(self, ob):
                return str(ob.airport_id)
        _TerminalsByAirport().register()


class TestCurrencyPage(_BaseTestPageNotify, ):
    page_cls = ui.currency.CurrencyPage
    ob_params = {
        'alpha3_code': u'RUB',
        'iso_code': u'123',
        'minor_unit': u'2',
        'names': [u'en:Abc', ],
        'rounding_unit': u'1',
    }
    primary_fields = {'alpha3_code': u'ZWD'}


class TestRedemptionZonePage(_BaseTestPageNotify, ):
    page_cls = ui.bonus.RedemptionZonePage
    ob_params = {
        'redemption_zone': u'AA',
        'names': [u'en:Abc', ],
    }
    primary_fields = {'redemption_zone': u'BB'}


class TestTierLevelPage(_BaseTestPageNotify, ):
    page_cls = ui.bonus.TierLevelPage
    ob_params = {
        'tier_level': u'aaa',
        'names': [u'en:Abc', ],
        'ordering': u'1',
        'miles': u'100',
        'segments': u'15',
        'business_segments': u'150'
    }
    primary_fields = {'tier_level': u'abc'}


class TestTariffGroupPage(_BaseTestPageNotify, ):
    page_cls = ui.bonus.TariffGroupPage
    ob_params = {
        'id_field': u'1',
        'tariff_group': u'premium-aaa',
        'service_class': u'premium',
        'names': [u'en:Abc', ],
        'weight': u'10'
    }
    extra_form_params = {
    }
    primary_fields = {'id_field': '2'}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            'premium': SkyTeamServiceClass(
                skyteam_sc_id=-1, code='premium', names=[u'en:SC'],
            )
        })
        vocab.register('skyteam_service_classes')
        MutableTestVocab({}).register('tariff_group_booking_classes')

        class _BookingClassByTariffGroup(Indexer):
            name = 'booking_classes_by_tariff_group_idx'
            def key(self, ob):
                return str(ob.booking_class_id)
        _BookingClassByTariffGroup().register()


class TestMealTypePage(_BaseTestPageNotify, ):
    page_cls = ui.meal.MealTypePage
    ob_params = {
        'mealtype': u'a',
        'names': [u'en:Abc', ],
    }
    primary_fields = {'mealtype': u'b'}


class TestPairPage(_BaseTestPageNotify, ):
    page_cls = ui.route.PairPage
    ob_params = {
        'airline': u'200',
        'airport_from': u'201',
        'airport_to': u'202',
        'miles': u'1'
    }
    primary_fields = {'pair_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            u'201': Airport(airport_id=201, names=[u'en:AA']),
            u'202': Airport(airport_id=202, names=[u'en:BB'])
        })
        vocab.register('airports')
        MutableTestVocab({}).register('afl_airports')
        vocab = MutableTestVocab({
            u'200': Airline(airline_id=200, names=[u'en:AA']),
        })
        vocab.register('airlines')


class TestWrongRoutePage(_BaseTestPageNotify, ):
    page_cls = ui.route.WrongRoutePage
    ob_params = {
        'city_from': u'201',
        'city_via': u'202',
        'city_to': u'203'
    }
    primary_fields = {'wrong_route_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            u'201': City(city_id=201, tz=u'E/M', names=[u'en:City1']),
            u'202': City(city_id=201, tz=u'E/M', names=[u'en:City2']),
            u'203': City(city_id=203, tz=u'E/M', names=[u'en:City3'])
        })
        vocab.register('cities')


class TestPartnerCategoryPage(_BaseTestPageNotify, ):
    page_cls = ui.partner.PartnerCategoryPage
    ob_params = {
        'names': [u'en:Abc', ],
        'status': u'P'
    }
    primary_fields = {'partner_category_id': 101}

    def _registerVocabularies(self):
        MutableTestVocab({u'P': SimpleTerm(u'P', u'Published')}).register('publication_statuses')


class TestPartnerPage(_BaseTestPageNotify, ):
    page_cls = ui.partner.PartnerPage
    ob_params = {
        'partner_id': 3000,
        'names': [u'en:Abc', ],
        'status': u'P',
        'mile_action': u'E',
        'partner_categories': u'201',
        'partner_description': u'ru:Partner',
        'mile_get_comm': u'en:Some coment',
        'mile_waste_comm': u'en:Some coment',
        'short_descr': u'en:Short desc',
        'spec_offer_comm': u'en:special offer comment',
        'url': u'ru:http://some.ru/ru',
        'weight': 0
    }
    extra_form_params = {
        'form-TOTAL_FORMS': u'1',
        'form-INITIAL_FORMS': u'0',
        'form-0-DELETE': u'',
        'form-0-desc_lang': u'en',
        'form-0-desc': u'en:Abc',
        'form-MAX_NUM_FORMS': u''
    }
    primary_fields = {'partner_id': 105}

    def _registerVocabularies(self):
        MutableTestVocab({u'P': SimpleTerm(u'P', u'Published')}).register('publication_statuses')
        MutableTestVocab({u'E': u'Earn'}).register('partner_mile_actions')

        vocab = MutableTestVocab({
            u'201': PartnerCategory(partner_category_id=201, names=[u'en:Category1'], status='P'),
        })
        vocab.register('partner_categories')


class TestPartnerOfficePage(_BaseTestPageNotify, ):
    page_cls = ui.partner.PartnerOfficePage
    ob_params = {
        'partner': u'201',
        'city': u'201',
        'comments': u'en:Abc',
        'address': u'en:Abc',
        'worktime': u'en:Abc',
        'office_type': u'M',
        'contacts': None
    }
    extra_form_params = {
        'form-TOTAL_FORMS': u'1',
        'form-INITIAL_FORMS': u'0',
        'form-0-DELETE': u'',
        'form-0-partner_office_contact_id': u'',
        'form-0-contact_type': u'',
        'form-0-contact': u'',
        'form-0-main_contact': u'',
        'form-MAX_NUM_FORMS': u''
    }
    primary_fields = {'partner_office_id': 101}

    def _registerVocabularies(self):
        MutableTestVocab({u'P': SimpleTerm(u'P', u'Published')}).register('publication_statuses')
        MutableTestVocab({u'E': u'Earn'}).register('partner_mile_actions')
        MutableTestVocab({u'M': u'Main'}).register('partner_office_types')
        MutableTestVocab({}).register('partner_office_contacts')

        vocab = MutableTestVocab({
            u'201': Partner(partner_id=201, names=[u'en:Partner1'],
                            partner_description=[u'en:Desc1'],
                            status=u'P', mile_action=u'E'),
        })
        vocab.register('partners')

        vocab = MutableTestVocab({
            u'201': City(city_id=201, tz=u'E/M', names=[u'en:City1']),
        })
        vocab.register('cities')

        class _ContactByPartnerOffice(Indexer):
            name = 'contact_by_partner_office_idx'
            def key(self, ob):
                return str(ob.partner_office_id)
        _ContactByPartnerOffice().register()


class TestPartnerAwardConditionPage(_BaseTestPageNotify, ):
    page_cls = ui.partner.PartnerAwardConditionPage
    ob_params = {
        'partner': u'201',
        'award_condition_type': u'E',
        'award_condition_description': u'en:Abc',
        'weight': u'10',
        'status': u'P',
        'miles': u'1000.0'
    }
    primary_fields = {'partner_award_condition_id': 101}

    def _registerVocabularies(self):
        MutableTestVocab({u'P': SimpleTerm(u'P', u'Published')}).register('publication_statuses')
        MutableTestVocab({u'E': u'Earn'}).register('partner_mile_actions')
        MutableTestVocab({u'E': u'Earn'}).register('partner_award_condition_types')

        vocab = MutableTestVocab({
            u'201': Partner(partner_id=201, names=[u'en:Partner1'],
                            partner_description=[u'en:Desc1'],
                            status=u'P', mile_action=u'E'),
        })
        vocab.register('partners')


class TestTierLevelFactorPage(_BaseTestPageNotify, ):
    page_cls = ui.bonus.TierLevelFactorPage
    ob_params = {
        'airline': u'201',
        'tier_level': u'201',
        'factor': u'25'
    }
    primary_fields = {'tier_level_factor_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            u'201': Airline(airline_id=201, names=[u'en:Airline1'],
                            weight=u'10'),
        })
        vocab.register('airlines')

        vocab = MutableTestVocab({
            u'201': TierLevel(tier_level=u'basic', names=[u'en:TierLevel1'],
                              ordering=u'10'),
        })
        vocab.register('tier_levels')


class TestBonusRoutePage(_BaseTestPageNotify, ):
    page_cls = ui.bonus.BonusRoutePage
    ob_params = {
        'code': u'A1B1C1',
        'zone_from': u'A1',
        'zone_via': u'B1',
        'zone_to': u'C1',
        'carrier': u'A'
    }
    primary_fields = {'bonus_route_id': 101}

    def _registerVocabularies(self):
        MutableTestVocab({u'A': u'Aeroflot'}).register('carriers')

        vocab = MutableTestVocab({
            u'A1': RedemptionZone(redemption_zone=u'A1', names=[u'en:AAA']),
            u'B1': RedemptionZone(redemption_zone=u'B1', names=[u'en:BBB']),
            u'C1': RedemptionZone(redemption_zone=u'C1', names=[u'en:BBC'])
        })
        vocab.register('redemption_zones')


class TestSkyTeamServiceClassPage(_BaseTestPageNotify, ):
    page_cls = ui.service_classes.SkyTeamServiceClassPage
    ob_params = {
        'code': u'economy',
        'names': [u'en:Abc', ],
        'weight': '30',
        'classification_level': 'E'
    }
    primary_fields = {'skyteam_sc_id': 101}
    def _registerVocabularies(self):
       MutableTestVocab({u'E': u'Econom'}).register('service_class_classification_levels')


class TestAirlineServiceClassPage(_BaseTestPageNotify, ):
    page_cls = ui.service_classes.AirlineServiceClassPage
    ob_params = {
        'airline': '201',
        'skyteam_sc': u'201'
    }
    primary_fields = {'airline_sc_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            u'201': Airline(airline_id=201, names=[u'en:Airline1'],
                            weight=u'10'),
        })
        vocab.register('airlines')

        vocab = MutableTestVocab({
            u'201': SkyTeamServiceClass(skyteam_sc_id=201, names=[u'en:SC1'],
                                        code=u'economy'),
        })
        vocab.register('skyteam_service_classes')


class TestCommentClassPage(_BaseTestPageNotify, ):
    page_cls = ui.service_classes.CommentClassPage
    ob_params = {
        'weight': u'10',
        'names': [u'en:Abc', ],
    }
    primary_fields = {'comment_id': 101}


class TestServiceClassesLimitPage(_BaseTestPageNotify, ):
    page_cls = ui.service_classes.ServiceClassesLimitPage
    ob_params = {
        'airline_sc': u'201',
        'pair': u'201'
    }
    primary_fields = {'service_classes_limit_id': 101}

    def _registerVocabularies(self):
        vocab = MutableTestVocab({
            u'201': Airline(airline_id=201, names=[u'en:Airline1'],
                            weight=u'10'),
        })
        vocab.register('airlines')

        vocab = MutableTestVocab({
            u'201': SkyTeamServiceClass(skyteam_sc_id=201, names=[u'en:SC1'],
                                        code=u'economy'),
        })
        vocab.register('skyteam_service_classes')

        vocab = MutableTestVocab({
            u'201': AirlineServiceClass(airline_sc_id=201, airline=u'201',
                                        skyteam_sc=u'201'),
        })
        vocab.register('airline_service_classes')

        vocab = MutableTestVocab({
            u'201': Airport(airport_id=201, names=[u'en:AA']),
            u'202': Airport(airport_id=202, names=[u'en:BB'])
        })
        vocab.register('airports')

        vocab = MutableTestVocab({
            u'201': Pair(pair_id=201, airport_from=u'201', airport_to=u'202',
                         miles=u'1000', airline=u'201'),
        })
        vocab.register('pairs')


class TestAwardsPage(_BaseTestPageNotify, ):
    page_cls = ui.bonus.AwardsPage
    ob_params = {
        # 'names': [u'en:Abc', ],
        'type': u'OW',
        'service_classes_1': u'201',
        'service_classes_1': u'202',
        'award_value': u'10000',
        'route': u'201',
        'comment': u'201'
    }
    primary_fields = {'award_id': 101}

    def _registerVocabularies(self):
        MutableTestVocab({u'OW': u'OW'}).register('award_types')
        MutableTestVocab({u'A': u'Aeroflot'}).register('carriers')

        vocab = MutableTestVocab({
            u'201': Airline(airline_id=201, names=[u'en:Airline1'],
                            weight=u'10'),
        })
        vocab.register('airlines')

        vocab = MutableTestVocab({
            u'201': SkyTeamServiceClass(skyteam_sc_id=201, names=[u'en:SC1'],
                                        code=u'economy'),
            u'202': SkyTeamServiceClass(skyteam_sc_id=202, names=[u'en:SC2'],
                                        code=u'business'),
        })
        vocab.register('skyteam_service_classes')

        vocab = MutableTestVocab({
            u'201': AirlineServiceClass(airline_sc_id=201, airline=u'201',
                                        skyteam_sc=u'201'),
            u'202': AirlineServiceClass(airline_sc_id=202, airline=u'201',
                                        skyteam_sc=u'202'),
        })
        vocab.register('airline_service_classes')

        vocab = MutableTestVocab({
            u'A1': RedemptionZone(redemption_zone=u'A1', names=[u'en:AAA']),
            u'B1': RedemptionZone(redemption_zone=u'B1', names=[u'en:BBB']),
            u'C1': RedemptionZone(redemption_zone=u'C1', names=[u'en:BBC'])
        })
        vocab.register('redemption_zones')

        vocab = MutableTestVocab({
            u'201': Comment(comment_id=201, names=[u'en:Abc'], weight=u'10'),
        })
        vocab.register('comments')

        vocab = MutableTestVocab({
            u'201': BonusRoute(bonus_route_id=201, code=[u'A1B1C1'],
                               carrier=u'A', zone_from=u'A1', zone_via=u'B1',
                               zone_to=u'C1'),
        })
        vocab.register('bonus_routes')


class TestOfficePage(_BaseTestPageNotify):

    page_cls = ui.office.OfficePage
    _allow_roles = ['admin']
    primary_fields = {'office_id': '-101'}

    ob_params = {
        'office_id': -101,
        'names': [u'en:Astrakhan', u'ru:Астрахань', ],
        'office_description': u'en:office at the airport on the 2nd floor (no ticket sales)\nru:Офис в аэропорту на 2 этаже (без продажи авиабилетов)',
        'lat': u'46.2876',
        'lon': u'47.9998',
        'email': u'asftosu@aeroflot.ru',
        'fax': u'+7 (8512) 393139',
        'phone': u'+7 (8512) 393139',
        'office_category': u'-201',
        'airport': u'-301',
        'worktime': u'en:open every day: 24 hours\tru:Ежедневно: круглосуточно',
        'address': u'en:414023\r\nNarimanovo airport\tru:414023\r\nАэропорт "Нариманово"',
        'location_map': u'',
        'important_info': u'',
        'transfer_time_foot': u'',
        'transfer_time_automobile': u'20',
        'transfer_time_public': u'30',
        'distance_to_airport': u'12',
        'noncash_booking': u'on',
        'office_weight': u'123'
    }
    extra_form_params = {
        'form-INITIAL_FORMS': u'0',
        'form-TOTAL_FORMS': u'1',
        'form-MAX_NUM_FORMS': u'',
        'form-0-DELETE': u'',
        'form-0-office_travel_option_id': u'',
        'form-0-travel_time': u'100',
        'form-0-office_travel_option_description': u'ru:Рус\nen:ENG',
        'form-0-travel_type': u'A',
    }

    def setUp(self):
        super(TestOfficePage, self).setUp()

        import ui.field_adapters
        ui.field_adapters.register_adapters()

        self.vocab = MutableTestVocab({})
        self.vocab.register(self.page_cls.vocab_name)

        self.registerTestAuthenticator()
        self._createTestUser()
        self.user.role = 'admin'
        self.authenticator.user = self.user

    def _registerVocabularies(self):
        MutableTestVocab({}).register('offices')
        MutableTestVocab({}).register('office_travel_options')
        models.office.OfficeTravelOptionType.register()
        city = City(city_id=-201, tz=u'E/M', names=[u'en:City1'])
        MutableTestVocab({u'-201': city}).register('cities')

        airport = Airport(airport_id=-301, city=city, names=[u'en:Airport1'])
        MutableTestVocab({u'-301': airport}).register('airports')

        vocab = MutableTestVocab({u'-201': models.office.OfficeCategory(office_category_id=-201,
                                                             names=[u'ru:Рус'],
                                                             office_category_description=[u'ru:Рус'],
                                                             city=city)})
        vocab.register('office_categories')
        class _TravelOptionByOffice(Indexer):
            name = 'travel_option_by_office_idx'
            def key(self, ob):
                return str(ob.office_id)

        _TravelOptionByOffice().register()

    @mock.patch('django.forms.formsets._')
    @mock.patch('notify.on_object_added')
    @mock.patch('ui.edit.resolveRoute')
    @mock.patch('ui.edit.ui.template.renderTemplate')
    def test_page_add_notify(
            self, mock_render_template, mock_resolve_route,
            mock_on_object_added, translate):
        mock_save_office = mock.patch.object(models.office.Office, 'save')
        mock_save_travel = mock.patch.object(models.office.OfficeTravelOption, 'save')
        mock_page = mock.patch.object(ObjectEditPage, '__bases__', (mock.Mock,))

        with mock_page, mock_save_office, mock_save_travel:
            mock_page.is_local = True
            mock_save_office.is_local = True
            mock_save_travel.is_local = True
            page = self.page_cls()
            page._allow_roles = self._allow_roles
            params = {}
            params.update(self.ob_params)
            params.update({'submit0': '1'})
            params.update(self.extra_form_params)
            page.add(**params)
            self.assertEqual(mock_on_object_added.called, 1)

    @mock.patch('django.forms.formsets._')
    @mock.patch('notify.on_object_changed')
    @mock.patch('ui.edit.resolveRoute')
    @mock.patch('ui.edit.ui.template.renderTemplate')
    def test_page_edit_notify(
            self, mock_render_template, mock_resolve_route,
            mock_on_object_changed, translate):
        mock_save_office = mock.patch.object(models.office.Office, 'save')
        mock_save_travel = mock.patch.object(models.office.OfficeTravelOption, 'save')
        mock_page = mock.patch.object(ObjectEditPage, '__bases__', (mock.Mock,))

        new_ob_params = {}
        new_ob_params.update(self.ob_params)
        new_ob_params.update(self.primary_fields)
        self.vocab.add(self.page_cls.ob_class(**new_ob_params))

        with mock_page, mock_save_office, mock_save_travel:
            mock_page.is_local = True
            mock_save_office.is_local = True
            mock_save_travel.is_local = True
            page = self.page_cls()
            page._allow_roles = self._allow_roles
            params = {}
            params.update(self.ob_params)
            params.update({'submit0': '1'})
            params.update(self.extra_form_params)
            page.edit(**params)
            self.assertEqual(mock_on_object_changed.called, 1)

    @mock.patch('notify.on_object_deleted')
    @mock.patch('ui.edit.resolveRoute')
    @mock.patch('ui.edit.ui.template.renderTemplate')
    def test_page_delete_notify(
            self, mock_render_template, mock_resolve_route,
            mock_on_object_deleted):
        mock_save_office = mock.patch.object(models.office.Office, 'save')
        mock_save_travel = mock.patch.object(models.office.OfficeTravelOption, 'save')

        mock_page = mock.patch.object(ObjectEditPage, '__bases__', (mock.Mock,))
        new_ob_params = {}
        new_ob_params.update(self.ob_params)
        new_ob_params.update(self.primary_fields)
        self.vocab.add(self.page_cls.ob_class(**new_ob_params))

        with mock_page, mock_save_office, mock_save_travel:
            mock_page.is_local = True
            mock_save_office.is_local = True
            mock_save_travel.is_local = True
            page = self.page_cls()
            page._allow_roles = self._allow_roles
            page.delete(**self.primary_fields)
            self.assertEqual(mock_on_object_deleted.called, 1)


class TestLanguagePage(_BaseTestPageNotify, ):
    page_cls = ui.lang.LanguagePage
    ob_params = {
        'alpha2_code': u'YY',
        'alpha3_code': u'YYY',
        'selector_code': u'YYY',
        'names': [u'ru:YYY', u'en:YYY', ],
        'is_active': u'on',
        'submit0': u'1'
    }
    primary_fields = {'alpha2_code': u'ZZ'}


class TestLocalizationPage(_BaseTestPageNotify, ):
    page_cls = ui.lang.LocalizationPage
    ob_params = {
        'code': u'YY',
        'names': [u'ru:YYY', u'en:YYY', ],
        'default_language': u'YY',
        'allowed_languages': u'YY\nZZ',
        'is_active': u'on',
        'submit0': u'1',
    }
    primary_fields = {'code': u'ZZ'}

    def _registerVocabularies(self):
        lang = Language(
            alpha2_code=u'YY',
            alpha3_code=u'YYY',
            selector_code=u'YYY',
            names=[u'ru:YYY', u'en:YYY', ],
            is_active=True
        )
        MutableTestVocab({u'YY': lang}).register('languages')


class TestSpecialMealPage(_BaseTestPageNotify, ):
    page_cls = ui.meal.SpecialMealPage
    ob_params = {
        'code': u'YYYY',
        'names': [u'ru:YYY\nen:YYY', ],
        'submit0': u'1'
    }
    primary_fields = {'code': u'ZZZZ'}


class TestAncillaryServicesGroupPage(_BaseTestPageNotify):
    page_cls = ui.ancillary_services.AncillaryServicesGroupPage
    ob_params = {
        'names': [u'ru:Группа', ],
        'ordinal_number': 10,
        'filename': 'file',
        'message': u'ru:Группа'
    }
    primary_fields = {'ancillary_services_group_id': 1}


class TestRFICCodePage(_BaseTestPageNotify):
    page_cls = ui.ancillary_services.RFICCodePage
    ob_params = {
        'code': u'A',
        'names': [u'ru:Группа RFIC', ],
    }
    primary_fields = {'code': u'A'}


class TestAncillaryServicePage(_BaseTestPageNotify):
    page_cls = ui.ancillary_services.AncillaryServicePage
    ob_params = {
        'code': u'XXX',
        'names': [u'ru:Услуга', u'en:Service', ],
        'descriptions': u'ru:Описание\ten:Description',
        'ancillary_services_group': '1',
        'rfic': u'A',
    }
    primary_fields = {'code': u'XXX', 'rfic': 'A'}

    def _registerVocabularies(self):
        MutableTestVocab({1: AncillaryServicesGroup(
            ancillary_services_group_id=1,
            names=[u'ru:Группа', ],
            ordinal_number=10,
            filename='file',
            message=u'ru:Группа'
        )}).register('ancillary_services_groups')

        MutableTestVocab({'A': RFICCode(
            code=u'A',
            names=[u'ru:Группа RFIC', ],
        )}).register('rfic_codes')


class TestAncillaryServiceStatusesPage(_BaseTestPageNotify):
    page_cls = ui.ancillary_services.AncillaryServiceStatusPage
    ob_params = {
        'code': u'HI',
        'rfic': 'A',
        'rfisc': 'XXX',
        'names': [u'ru:Статус', ]
    }
    primary_fields = {'ancillary_service_status_id': 1}

    def _registerVocabularies(self):
        MutableTestVocab({'A': RFICCode(
            code=u'A',
            names=[u'ru:Группа RFIC', ],
        )}).register('rfic_codes')


class TestAdditionalInfoPage(_BaseTestPageNotify):
    page_cls = ui.additional_info.AdditionalInfoPage
    ob_params = {
        'weight': '1',
        'names': [u'ru:МСДЖ', u'en:MSG', ],  # не уверен, что здесь может быть питонячий список, но вроде так
        'condition': '[{"airport_from": "LED"}]',
    }
    primary_fields = {'additional_info_id': 1}


class TestMealRulePage(_BaseTestPageNotify, testlib.TestCaseWithDBAndVocabs, testlib.TestCaseWithAuth):
    page_cls = ui.meal.MealRulePage
    ob_params = {
        'meal_rule_id': '1',
        'number': '1,3,5,7-10',
        'airline': '1',
        'origin': '1',
        'destination': '2',
        'booking_class': '1',
        'special_meal': 'XXXX',
    }
    primary_fields = {'meal_rule_id': '1'}

    def _registerVocabularies(self):
        MutableTestVocab({
            u'1': Airline(airline_id=1, names=[u'en:AA']),
        }).register('airlines')
        MutableTestVocab({
            u'1': Airport(airport_id=1, names=[u'en:AA']),
            u'2': Airport(airport_id=2, names=[u'en:BB']),
        }).register('airports')
        MutableTestVocab({
            u'1': BookingClass(idField=1, bcCode='Z'),
        }).register('booking_classes')
        MutableTestVocab({
            u'XXXX': SpecialMeal(code='XXXX', names=[u'en:MEAL']),
        }).register('special_meal')


class TestMealTimelimitPage(_BaseTestPageNotify, testlib.TestCaseWithDBAndVocabs, testlib.TestCaseWithAuth):
    page_cls = ui.meal.MealTimelimitPage
    ob_params = {
        'meal_timelimit_id': '1',
        'origin': '1',
        'special_meal': 'XXXX',
        'timelimit': 0,
    }
    primary_fields = {'meal_timelimit_id': '1'}

    def _registerVocabularies(self):
        MutableTestVocab({
            u'1': Airport(airport_id=1, names=[u'en:AA']),
        }).register('airports')
        MutableTestVocab({
            u'XXXX': SpecialMeal(code='XXXX', names=[u'en:MEAL']),
        }).register('special_meal')


if __name__ == '__main__':
    testoob.main()
