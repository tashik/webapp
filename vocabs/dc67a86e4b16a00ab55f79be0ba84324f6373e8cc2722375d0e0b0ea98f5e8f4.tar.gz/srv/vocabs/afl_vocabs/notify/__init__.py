# -*- coding: utf-8 -*-

'''
$Id: $
'''
import urllib
import urllib2
import json
import config
from pyramid.ormlite.interfaces import IRecord
from pyramid.ormlite.schema import IORMField, IChoice
from rx.utils.json import as_primitive as rx_as_primitive
from rx.utils.json import IPrimitive
from rx.utils import enumerate_fields
from DecNumber import DecNumber
from zope.component import provideAdapter


# as_primitive и record_to_primitive переопределены,
# т.к. нет никакой возможности создать адаптер для DecNumber,
# т.к. нет возможности присвоить ему интерфейс

def as_primitive(ob):
    if isinstance(ob, DecNumber):
        ob = str(ob)
    return rx_as_primitive(ob)


def record_to_primitive(ob):
    d = {'class': ob.__class__.__name__}
    for name, field in enumerate_fields(ob):
        if IChoice.providedBy(field):
            d[name] = ob.p_choice_tokens[name]
        elif IORMField.providedBy(field):
            d[name] = as_primitive(field.get(ob))
    return d

provideAdapter(lambda ob: record_to_primitive(ob),
               [IRecord], IPrimitive)


def as_json(ob):
    return json.dumps(as_primitive(ob), encoding='utf-8')


def on_object_added(ob):
    return post_events(('add', [ob]))


def on_object_changed(ob):
    return post_events(('change', [ob]))


def on_object_deleted(ob):
    return post_events(('delete', [ob]))


def post_events(*events):
    data = []
    for event_type, obs in events:
        if obs:
            data.append(dict(event=event_type, objects=obs))
    if data:
        text = as_json(data)
        post(config.PBUS_TOPICS['vocabs'], text)


pbus_auth_handler = urllib2.HTTPBasicAuthHandler()
pbus_auth_handler.add_password('pbus', config.PBUS_URL, config.PBUS_MY_NAME, config.PBUS_PASSWORD)
pbus_opener = urllib2.build_opener(pbus_auth_handler)


def subscribe(topic):
    if not config.PBUS_URL:
        return

    callbackUrl = 'http://%s:%s%s/notify/%s' % (config.PBUS_CALLBACK_HOST, config.PBUS_CALLBACK_PORT, config.VIRTUAL_BASE, topic)
    callbackUrl = urllib.quote(callbackUrl, safe='')
    callbackUrl = urllib.quote(callbackUrl)
    url = '%s/%s/subscribe/%s' % (config.PBUS_URL, topic, callbackUrl)
    pbus_opener.open(url, '')


def post(topic, msg):
    if not config.PBUS_URL:
        return

    url = '%s/%s/post' % (config.PBUS_URL, topic)
    req = urllib2.Request(url=url,
                          data=msg.encode('utf-8'),
                          headers={'content-type': 'application/json;charset=utf-8'})
    pbus_opener.open(req)
