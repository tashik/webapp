# -*- coding: utf-8 -*-

"""
$Id: $
"""
import cherrypy
import logging
import json
import threading
from pyramid.ui.page import CPJSONService
from pyramid.vocabulary import getV

from rx.utils.json import as_primitive

import models
import config

VOCAB_NAMES = {'world_regions', 'countries', 'cities', 'airports', 'aircraft_types', 'airlines',
               'tier_levels', 'tier_level_factors', 'tariff_groups', 'redemption_zones',
               'pairs', 'wrong_routes', 'awards', 'bonus_routes', 'meal_types',
               'partner_categories', 'partners', 'partner_office_contacts',
               'partner_offices', 'partner_award_conditions', 'skyteam_service_classes',
               'airline_service_classes', 'service_classes_limits', 'tariff_groups',
               'airline_tariff_groups', 'booking_classes', 'special_offers',
               'office_categories', 'offices', 'loyalty_programs', 'professional_areas',
               'languages', 'localizations', 'special_meal', 'currencies',
               'ancillary_services_groups', 'rfic_codes', 'ancillary_services', 'ancillary_service_statuses',
               'additional_info', 'vat_rates',
               'meal_rules', 'meal_timelimits', 'charity_funds'}

class QueryService(CPJSONService):
    topic = config.PBUS_TOPICS['vocabs']
    vocab_cache = {}
    _lock = threading.RLock()

    def _connectToDispatcher(self, dispatcher):
        path = '/notify/%s' % self.topic
        dispatcher.connect('service_vocabs_query', path, controller=self, action='index')

    def index(self, **params):
        body = cherrypy.request.body.read()
        sender = cherrypy.request.headers.get('from')
        if sender == config.PBUS_MY_NAME:
            return ''
        d = json.loads(body)
        logging.debug('notify %r' % d)
        if 'command' not in d:
            return ''
        command = d['command']
        if command == 'get_all':
            r = dict(event='replace_all', objects=self.get_all(**d))
            json_text = json.dumps(r, encoding='utf-8')
            #open(config.LOGDIR + '/last_response.json', 'w').write(json_text)
            return json_text
        else:
            raise ValueError(command)

    def get_all(self, vocabularies, **params):
        result = []
        for vocab_name in vocabularies:
            with self._lock:
                try:
                    version, data = self.vocab_cache[vocab_name]
                except KeyError:
                    pass
                else:
                    if version == models.VocabDataVersion.get_version(vocab_name):
                        result += data
                        continue

            if vocab_name in VOCAB_NAMES:
                data = as_primitive(getV(vocab_name).values())
                result += data
            else:
                raise ValueError(vocab_name)

            with self._lock:
                new_version = models.VocabDataVersion.increment_version(vocab_name)
                self.vocab_cache[vocab_name] = new_version, data

        return result
