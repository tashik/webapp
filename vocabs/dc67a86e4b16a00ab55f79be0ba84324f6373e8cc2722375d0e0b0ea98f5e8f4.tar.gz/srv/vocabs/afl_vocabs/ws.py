# -*- coding: utf-8 -*-

"""AFL Public Application Starter.

$Id: $
"""

import config

import os
import sys
import signal

def int_handler(signum, frame):
    # TODO: гасить соединение с БД
    raise KeyboardInterrupt

signal.signal(signal.SIGINT, int_handler)
signal.signal(signal.SIGTERM, int_handler)


def main():
    if sys.platform != 'win32':
        from pyramid.utils.pidfile import PidFile
        pidfile = PidFile("ws")

    import initializer
    initializer.initialize()

    import cherrypy
    import cpconfig
    import cpdispatcher
    cherrypy.config.update(cpconfig.global_cfg)
    if '--no-autoreload' in sys.argv:
        cherrypy.config['engine.autoreload.on'] = False
    cherrypy.tree.mount(None, config=cpdispatcher.mount_cfg)

    cherrypy.request.wsgi_environ = {}
    cherrypy.engine.start()
    cherrypy.engine.block()
    

if __name__ == "__main__":
    main()
