function cloneMore(selector, type) {
    var $newEl = $(selector).clone(true);
    var total = $('#id_' + type + '-TOTAL_FORMS').val();

    $newEl.find(':input').each(function() {
        var _name = $(this).attr('name');
        if (_name) {
            var name = _name.replace('-' + (total - 1) + '-',
                                     '-' + total + '-');
            var id = 'id_' + name;
            $(this).attr({'name': name, 'id': id}).val('').removeAttr('checked');
        }
    });

    $newEl.find('label').each(function() {
        var _for = $(this).attr('for');
        if (_for) {
            var newFor = _for.replace('-' + (total - 1) + '-',
                                      '-' + total + '-');
            $(this).attr('for', newFor);
        }
    });

    total++;
    $('#id_' + type + '-TOTAL_FORMS').val(total);
    $(selector).after($newEl);

    if (typeof(MLWidget) != 'undefined') {
        $newEl.find('.ml-widget').remove();
        MLWidget.createWidgets($newEl);
    }
}
