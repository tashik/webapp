'use strict';


var MLWidget = (function($) {
    var module = {};

    var settings = {
        typeMLNames: 'ml-names',
        typeMLText: 'ml-text',
        separatorN: '\n',
        separatorT: '\t',
        separatorL: ':',
        init_languages: ['ru'],
        num_rows: 2
    };

    var translations = {
        LANGUAGE: 'Language',
        TEXT: 'Text',
        REMOVE: 'Remove',
        ADD: 'Add'
    };

    function t(v) {
        if (translations[v]) {
            return translations[v];
        }
        return v;
    }

    function updateDelBtns($tbl) {
        var $delBtns = $('a', $tbl);
        $delBtns.hide();
        if ($delBtns.length > 1) {
            $($delBtns.get($delBtns.length - 1)).show();
        }
    }

    function removeA(arr, value) {
        var a = arguments, L = a.length, ax;
        while (L > 1 && arr.length) {
            value = a[--L];
            while ((ax= arr.indexOf(value)) !== -1) {
                arr.splice(ax, 1);
            }
        }
        return arr;
    }

    function addRow($tbl, type, lang, text) {
        if (!Boolean(lang)) {
            lang = find_not_used_lang($tbl, lang)
        }
        var rowCount = $('tbody > tr', $tbl).length,
            max_langs = Object.keys(settings.init_languages).length;
        if (rowCount < max_langs) {
            var $row = $(
                '<tr>' +
                '<td><input type="text" maxlength="2" size="2" class="ml-lang" /></td>' +
                '<td>' + getWidget(type) + '</td>' +
                '<td><a href="#" title="' + t('REMOVE') + '" class="ml-btn ml-remove">&times;</a></td>' +
                '</tr>'
            ).appendTo($tbl.children('tbody'));
            var $lang = $('.ml-lang', $row);

            $lang.keyup(function (evt) {
                var $el = $(this);
                $el.val($el.val().toLowerCase());
            });

            $('a', $row).click(function (evt) {
                evt.preventDefault();
                var remove_lang = $lang.val();
                if (settings.init_languages.indexOf(remove_lang) !== -1) {
                    var used_langs = $tbl.data('used_langs');
                    used_langs = removeA(used_langs, remove_lang);
                    $tbl.data({'used_langs': used_langs});
                }
                $row.remove();
                updateDelBtns($tbl);
            });

            if (Boolean(lang)) {
                $lang.val(lang);
            }
            if (Boolean(text)) {
                $('.ml-text', $row).val(text);
            }

            updateDelBtns($tbl);
        } else {
            alert('Разрешено максимум языков: ' + max_langs)
        }

    }

    function getWidget(type) {
        if (type === settings.typeMLNames) {
            return '<input type="text" class="ml-text" />';
        }
        return '<textarea cols="100" rows="5" class="ml-text"></textarea>';
    }

    function find_not_used_lang(parent_element, lang) {
       var used_langs = parent_element.data('used_langs');
       var diff = settings.init_languages.filter(function(el) {
           return used_langs.indexOf(el) < 0;
       });
       if (Object.keys(diff).length) {
           var l = diff[0];
           used_langs.push(l);
           return l
       }
       return ''
    }

    function getSeparator(type) {
        if (type === settings.typeMLNames) {
            return settings.separatorN;
        }
        return settings.separatorT;
    }

    function create($input) {
        $input.hide();
        var type = $input.attr('data-type');

        var $container = $('<div class="ml-widget"></div>').insertAfter($input);
        var $tbl = $('<table><thead><tr><th>' + t('LANGUAGE') + '</th><th>' + t('TEXT') + '</th></tr></thead><tbody></tbody></table>').appendTo($container);
        $tbl.data({'used_langs': []});
        $container.css('display', 'inline-block');

        var lstrings = $input.val().split(getSeparator(type));
        for (var k = 0; k < Math.max(lstrings.length, settings.num_rows); k++) {
            var lang = '';
            var text = '';
            if (k < lstrings.length) {
                var lstring = lstrings[k];
                var index = lstring.indexOf(settings.separatorL);
                var lang_val = lstring.substr(0, index).trim();
                text = lstring.substr(index + 1).trim();
                if (lang_val) {
                    lang = lang_val;
                    var used_langs = $tbl.data('used_langs');
                    used_langs.push(lang);
                    $tbl.data({'used_langs': used_langs});
                }
            } else {
                lang = find_not_used_lang($tbl, lang)
            }
            addRow($tbl, type, lang, text);
        }
        var $btnAdd = $('<a href="#" title="' + t('ADD') + '" class="ml-btn ml-add">+</a>').appendTo($container);
        $btnAdd.click(function(evt) {
            evt.preventDefault();
            addRow($tbl, type, '', '');
        });

        $input.parents('form').submit(function() {
            var value = '';
            var result = [];
            $('tr', $tbl).each(function(i, tr) {
                var $tr = $(tr);
                var $lang = $('.ml-lang', $tr);
                var $text = $('.ml-text', $tr);
                if ($lang.length && $text.length) {
                    var lang = $lang.val().trim().toLowerCase();
                    if (lang) {
                        var text = $text.val().trim();
                        if (text) {
                            result.push(lang + settings.separatorL + text);
                        }
                    }
                }
            });

            if (result.length) {
                value = result.join(getSeparator(type));
            }

            $input.val(value);
        });
    }

    function createWidgets($container) {
        $container.find('textarea[data-type="' + settings.typeMLNames + '"], textarea[data-type="' + settings.typeMLText + '"]').each(function(i, input) {
            create($(input));
        });
    }

    function init() {
        $(document).ready(function() {
            createWidgets($('body'));
        });
    }

    module.createWidgets = createWidgets;

    module.init = function(_settings, _translations) {
        _settings = _settings || {};
        _translations = _translations || {};

        for (var pr in _settings) {
            settings[pr] = _settings[pr];
        }

        for (var pr in _translations) {
            translations[pr] = _translations[pr];
        }

        init();
    };

    return module;
}(jQuery));
