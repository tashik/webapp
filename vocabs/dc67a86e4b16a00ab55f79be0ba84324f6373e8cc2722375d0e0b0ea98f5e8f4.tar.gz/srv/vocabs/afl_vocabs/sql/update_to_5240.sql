insert into _schema_revisions (revision) values (5240);

alter table airlines ADD loyalty_program_id integer references loyalty_programs(loyalty_program_id);