insert into _schema_revisions (revision) values (3669);

ALTER TABLE countries ADD telephone_code integer;