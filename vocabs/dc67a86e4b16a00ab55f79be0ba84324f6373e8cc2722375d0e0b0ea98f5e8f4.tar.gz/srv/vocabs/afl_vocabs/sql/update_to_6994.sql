insert into _schema_revisions (revision) values (6994);

-- Класс бронирования
CREATE TABLE booking_classes(
  id                integer not null primary key,
  bc_code           varchar(50) unique not null,
  miles_are_charged boolean not null,
  comment_id        integer references comments deferrable,
  al_tariff_group   integer references airline_tariff_groups
                    deferrable
);
