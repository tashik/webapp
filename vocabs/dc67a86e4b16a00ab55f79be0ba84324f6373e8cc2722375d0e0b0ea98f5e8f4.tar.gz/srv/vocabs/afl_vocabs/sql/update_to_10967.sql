BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (10967);

ALTER TABLE awards RENAME COLUMN service_classes_1 TO service_classes_1_old;
ALTER TABLE awards RENAME COLUMN service_classes_2 TO service_classes_2_old;

ALTER TABLE awards ADD COLUMN service_classes_1 INTEGER REFERENCES skyteam_service_classes(skyteam_sc_id) ON DELETE CASCADE DEFERRABLE;
ALTER TABLE awards ADD COLUMN service_classes_2 INTEGER REFERENCES skyteam_service_classes(skyteam_sc_id) ON DELETE CASCADE DEFERRABLE;

UPDATE awards SET service_classes_1=ascl.skyteam_sc_id FROM airline_service_classes ascl WHERE awards.service_classes_1_old=ascl.airline_sc_id;
UPDATE awards SET service_classes_2=ascl.skyteam_sc_id FROM airline_service_classes ascl WHERE awards.service_classes_2_old=ascl.airline_sc_id AND awards.service_classes_2_old IS NOT NULL;

ALTER TABLE awards ALTER COLUMN service_classes_1 SET NOT NULL;
ALTER TABLE awards DROP COLUMN service_classes_1_old;
ALTER TABLE awards DROP COLUMN service_classes_2_old;

COMMIT;
