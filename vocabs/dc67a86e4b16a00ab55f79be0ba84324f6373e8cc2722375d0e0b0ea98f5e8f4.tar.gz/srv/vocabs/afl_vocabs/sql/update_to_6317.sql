insert into _schema_revisions (revision) values (6317);

-- обновление таблицы справочник пар для SkyTeam (#14120)
ALTER TABLE pairs DROP COLUMN  bonus_miles;           -- бонусные мили

