insert into _schema_revisions (revision) values (3319);

alter table tier_levels add column ordering integer;
update tier_levels set ordering = 0;
alter table tier_levels alter column ordering set not null;