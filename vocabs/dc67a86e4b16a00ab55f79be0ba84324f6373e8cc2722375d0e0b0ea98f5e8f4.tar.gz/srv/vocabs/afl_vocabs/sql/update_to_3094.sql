insert into _schema_revisions (revision) values (3094);

alter table service_classes add column routes varchar(4096);
update service_classes set routes = '';
alter table service_classes alter column routes set not null;