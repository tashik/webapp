insert into _schema_revisions (revision) values (20420);

ALTER TABLE charity_funds RENAME COLUMN url_logo TO logo_url;
ALTER TABLE charity_funds RENAME COLUMN url_image TO image_url;
ALTER TABLE charity_funds RENAME COLUMN url_to_news TO news_url;
ALTER TABLE charity_funds RENAME COLUMN url_to_news_mv TO news_mv_url;