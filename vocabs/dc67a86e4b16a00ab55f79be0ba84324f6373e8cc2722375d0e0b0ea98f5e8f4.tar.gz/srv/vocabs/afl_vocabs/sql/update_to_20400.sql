﻿BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (20400);

ALTER TABLE airline_tariff_groups ADD COLUMN fare_code varchar(50);

END;