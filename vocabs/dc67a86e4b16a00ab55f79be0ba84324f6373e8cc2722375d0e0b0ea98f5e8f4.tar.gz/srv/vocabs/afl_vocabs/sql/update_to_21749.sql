begin;

insert into _schema_revisions (revision) values (21749);

alter table currencies alter column "rounding_unit" type float;

commit;
