insert into _schema_revisions (revision) values (20411);

ALTER TABLE charity_funds RENAME COLUMN charity_id TO charity_funds_id;
ALTER TABLE charity_funds DROP CONSTRAINT charity_funds_pkey;
ALTER TABLE charity_funds ADD COLUMN charity_id varchar(16) NOT NULL;
ALTER TABLE charity_funds ADD PRIMARY KEY (charity_funds_id);