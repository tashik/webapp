begin;

insert into _schema_revisions (revision) values (19156);

alter table offices alter column important_info type text;

commit;
