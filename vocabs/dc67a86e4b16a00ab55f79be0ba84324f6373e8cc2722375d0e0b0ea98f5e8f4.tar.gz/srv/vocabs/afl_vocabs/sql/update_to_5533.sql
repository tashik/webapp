insert into _schema_revisions (revision) values (5533);

ALTER TABLE partners ADD status varchar (1) NULL;
alter table partners drop column partner_category_id;
ALTER TABLE partners ADD partner_categories varchar (4096);