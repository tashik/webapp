begin;

insert into _schema_revisions (revision) values (14427);

alter table ancillary_services drop constraint ancillary_services_pkey;
alter table ancillary_services add primary key (rfic, code);

commit;
