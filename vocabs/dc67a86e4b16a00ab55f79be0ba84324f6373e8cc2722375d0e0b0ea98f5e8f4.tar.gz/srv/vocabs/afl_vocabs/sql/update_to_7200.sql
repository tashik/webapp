begin;
insert into _schema_revisions (revision) values (7200);

alter table partners alter column partner_description type
    text;
alter table partners alter column partner_description set default '';
alter table partners alter column partner_description set not null;

commit;
