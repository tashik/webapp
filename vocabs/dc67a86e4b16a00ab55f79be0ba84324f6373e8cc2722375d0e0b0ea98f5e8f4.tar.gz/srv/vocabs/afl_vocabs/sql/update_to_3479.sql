insert into _schema_revisions (revision) values (3479);

alter table service_classes add column ordering integer;
update service_classes set ordering = 0;
alter table service_classes alter column ordering set not null;

alter table tariff_groups add column ordering integer;
update tariff_groups set ordering = 0;
alter table tariff_groups alter column ordering set not null;