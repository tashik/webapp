begin;

insert into _schema_revisions (revision) values (13608);

alter table emd_groups rename to ancillary_services_groups;
alter table ancillary_services_groups rename column emd_group_id to ancillary_services_group_id;
alter index emd_groups_pkey rename to ancillary_services_groups_pkey;

alter table emd_services rename to ancillary_services;
alter table ancillary_services rename column emd_group_id to ancillary_services_group_id;
alter table ancillary_services drop constraint emd_services_emd_group_id_fkey;
alter table ancillary_services add constraint ancillary_services_ancillary_services_group_id_fkey foreign key (ancillary_services_group_id) references ancillary_services_groups(ancillary_services_group_id) deferrable;
alter index emd_services_pkey rename to ancillary_services_pkey;

commit;
