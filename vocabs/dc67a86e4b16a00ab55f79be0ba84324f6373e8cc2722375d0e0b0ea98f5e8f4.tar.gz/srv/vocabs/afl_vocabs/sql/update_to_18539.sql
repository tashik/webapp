begin;

insert into _schema_revisions (revision) values (18539);

drop table if exists var_rates;

create table vat_rates (
    id integer primary key,
    rfic char(1) not null,
    rfisc char(3) not null,
    start_date timestamp,
    stop_date timestamp,
    rate float check(rate between 0 and 100) not null,
    check (start_date < stop_date)
);

commit;