begin;

insert into _schema_revisions (revision) values (13789);

delete from ancillary_services;
alter table ancillary_services alter column rfic set not null;

commit;
