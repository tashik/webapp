insert into _schema_revisions (revision) values (6194);

alter table airlines add logo_url varchar(256);
alter table airlines add url varchar(256);
alter table airlines add weight integer;

update airlines set logo_url = '';
update airlines set url = '';
update airlines set weight = 0;

alter table airlines alter column weight set not null;
