begin;
insert into _schema_revisions (revision) values (8084);

alter table airlines drop column logo_url;
commit;
