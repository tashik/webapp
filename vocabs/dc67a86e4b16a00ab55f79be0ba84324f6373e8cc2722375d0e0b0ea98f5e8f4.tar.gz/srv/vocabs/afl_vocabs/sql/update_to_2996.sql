begin;
insert into _schema_revisions (revision) values (2996);
ALTER TABLE member_statuses RENAME COLUMN member_status TO tier_level;
ALTER TABLE member_statuses  RENAME TO tier_levels;
commit;