insert into _schema_revisions (revision) values (6991);

-- Тарифная группа для авиакомпании
create table airline_tariff_groups(
  id integer not null primary key,
  tariff_group integer references tariff_groups(id) deferrable,
  service_class integer references airline_service_classes(airline_sc_id) deferrable,
  charge_coef integer not null,
  weight integer not null
);
