insert into _schema_revisions (revision) values (6293);

-- Категории офисов продаж
create table office_categories(
  office_category_id int not null primary key,
  office_category_description varchar(4096) not null,
  names varchar(4096) not null,
  city_id integer not null references cities(city_id) deferrable
);