insert into _schema_revisions (revision) values (6160);

alter table airlines ADD parent_airline_id integer;
