begin;

insert into _schema_revisions (revision) values (13610);

alter table ancillary_services add column rfic char(1) references ancillary_services_rfic_groups(code) deferrable;

commit;
