-- Маршруты
CREATE TABLE  routes(
  route_id integer not null primary key,
  airport_from_id integer references airports(airport_id), -- аэропорт вылета
  airport_to_id integer references airports(airport_id),   -- аэропорт прилета
  miles integer                                            -- Расстояние
);