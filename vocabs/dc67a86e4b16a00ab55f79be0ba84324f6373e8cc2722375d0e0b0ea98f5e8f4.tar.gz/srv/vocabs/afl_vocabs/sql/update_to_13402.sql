begin;

insert into _schema_revisions (revision) values (13402);

alter table mealtypes rename mealtype to meal_type;
alter table mealtypes rename to meal_types;

commit;
