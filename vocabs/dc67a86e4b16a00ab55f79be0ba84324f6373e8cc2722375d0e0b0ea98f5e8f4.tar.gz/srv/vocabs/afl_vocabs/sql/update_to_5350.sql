insert into _schema_revisions (revision) values (5350);

--Условия набора и траты миль для партнёров-неавиакомпаний
CREATE TABLE partner_award_conditions
(
  partner_award_condition_id integer not null primary key,
  partner_id  integer not null references partners(partner_id) deferrable,
  award_condition_type varchar(1) not null,
  award_condition_description varchar(4096) not null,
  weight integer not null,
  status varchar(1) not null
);
