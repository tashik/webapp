BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (12648);

delete from mealtypes;

insert into mealtypes (mealtype, names) values
('B', 'en:Breakfast|ru:Завтрак|zh:早餐'),
('C', 'en:Alcoholic Beverages---Complimentary|ru:Приветственные алкогольные напитки|zh:免费 含酒精 的 饮料'),
('D', 'en:Dinner|ru:Ужин|zh:晚餐'),
('F', 'en:Food for Purchase|ru:Еда за отдельную плату|zh:在售食物'),
('G', 'en:Food and Beverages for Purchase|ru:Питание-напитки за дополнительную плату|zh:付费餐食和饮品'),
('H', 'en:Hot Meal|ru:Горячее питание|zh:热食'),
('K', 'en:Continental Breakfast|ru:Континентальный завтрак|zh:大陆式早餐'),
('L', 'en:Lunch|ru:Обед|zh:中餐'),
('M', 'en:Meal (to be used as a generalization if no specific meal is intended)|ru:Питание|zh:餐'),
('N','en:No Meal Service|ru:Без питания|zh:不提供餐食'),
('O', 'en:Cold Meal|ru:Холодное питание|zh:非加热 餐'),
('P', 'en:Alcoholic Beverages for Purchase|ru:Алкогольные напитки за отдельную плату|在售的含酒精的饮料'),
('R', 'en:Refreshments---Complimentary|ru:Бесплатные напитки|zh:免费饮品'),
('S', 'en:Snack or Brunch|ru:Лёгкая закуска/сэндвич|zh:小食'),
('V', 'en:Refreshments for Purchase|ru:Напитки за дополнительную плату|zh:付费饮品');

COMMIT;
