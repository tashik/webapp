insert into _schema_revisions (revision) values (5345);
ALTER TABLE partner_office_contacts DROP CONSTRAINT partner_office_contacts_partner_office_id_fkey;
ALTER TABLE partner_office_contacts DROP partner_office_id;
ALTER TABLE partner_office_contacts ADD partner_office_id int NOT NULL;