insert into _schema_revisions (revision) values (3112);

alter table tier_levels add column miles_factor decimal(3,2);
update tier_levels set miles_factor = 0;
alter table tier_levels alter column miles_factor set not null;

alter table tariff_groups add column miles_factor_01 decimal(3,2);
update tariff_groups set miles_factor_01 = 0;
alter table tariff_groups alter column miles_factor_01 set not null;

alter table tariff_groups add column miles_factor_02 decimal(3,2);
update tariff_groups set miles_factor_02 = 0;
alter table tariff_groups alter column miles_factor_02 set not null;

alter table routes add column bonus_miles integer;
update routes set bonus_miles = 0;
alter table routes alter column bonus_miles set not null;