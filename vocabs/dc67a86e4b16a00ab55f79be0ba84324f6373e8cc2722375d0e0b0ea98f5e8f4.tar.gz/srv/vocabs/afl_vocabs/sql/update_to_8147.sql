BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (8147);
ALTER TABLE booking_classes DROP CONSTRAINT booking_classes_bc_code_key;
ALTER TABLE booking_classes ADD UNIQUE(bc_code, al_tariff_group);

COMMIT;
