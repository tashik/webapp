﻿insert into _schema_revisions (revision) values (6422);


 -- Категории офисов продаж
create table office_categories(
  office_category_id int not null primary key,
  office_category_description varchar(4096) not null,
  names varchar(4096) not null,
  city_id integer not null references cities(city_id) deferrable
);
insert into office_categories (office_category_id, office_category_description, names, city_id) values (-1, 'en:Empty category', 'en:Empty', 1);

alter table offices add  in_airport boolean;
alter table offices add  insurance_policy boolean;
alter table offices add  noncash_booking boolean;
alter table offices add  new_office boolean;
alter table offices add  airport_id integer references airports(airport_id) deferrable;
alter table offices add  distance_to_airport integer;
alter table offices add  office_category_id integer references office_categories(office_category_id) deferrable default -1;
alter table offices add  location_map  varchar(4096) default '';
alter table offices add  transfer_time_public  integer;
alter table offices add  transfer_time_automobile  integer;
alter table offices add  transfer_time_foot  integer;
alter table offices drop column city_id;

-- Дорога до офиса
CREATE TABLE office_travel_options
(
  office_travel_option_id integer not null primary key,
  office_id integer not null references offices(office_id) on delete cascade deferrable,
  travel_type varchar(1) not null,
  office_travel_option_description varchar(4096) not null,
  travel_time integer
 );