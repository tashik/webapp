begin;

insert into _schema_revisions (revision) values (19351);

-- Сообщение
ALTER TABLE ancillary_services_groups ADD COLUMN message varchar(4096) not null default '';

ALTER TABLE ancillary_services ADD COLUMN doc_prefix varchar(4096) not null default '';

ALTER TABLE ancillary_services ADD COLUMN emd_message varchar(4096) not null default '';

commit;
