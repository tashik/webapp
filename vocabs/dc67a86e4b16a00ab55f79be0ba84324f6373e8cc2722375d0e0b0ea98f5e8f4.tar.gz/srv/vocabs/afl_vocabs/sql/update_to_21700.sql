begin;

insert into _schema_revisions (revision) values (21700);

-- Единицы округления валют
alter table currencies add column "rounding_unit" integer not null default 1;

commit;
