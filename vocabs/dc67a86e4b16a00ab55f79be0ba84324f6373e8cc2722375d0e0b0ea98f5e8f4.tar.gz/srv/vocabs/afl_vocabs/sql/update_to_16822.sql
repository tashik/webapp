BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (16822);

ALTER TABLE currencies ADD COLUMN used_in_calc boolean NOT NULL DEFAULT FALSE;

COMMIT;
