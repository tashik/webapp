begin;
insert into _schema_revisions (revision) values (2538);

alter table airlines add constraint airlines_country_key foreign key (country) references countries(country) deferrable;

commit;
