insert into _schema_revisions (revision) values (7021);

-- Task #14140
alter table tariff_groups drop constraint tariff_groups_service_class_fkey;
drop table if exists service_classes;


