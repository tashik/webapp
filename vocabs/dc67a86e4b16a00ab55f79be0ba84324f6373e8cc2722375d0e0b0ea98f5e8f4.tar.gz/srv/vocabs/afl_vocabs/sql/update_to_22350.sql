insert into _schema_revisions (revision) values (22350);

ALTER TABLE charity_funds ADD COLUMN tag text default '';
