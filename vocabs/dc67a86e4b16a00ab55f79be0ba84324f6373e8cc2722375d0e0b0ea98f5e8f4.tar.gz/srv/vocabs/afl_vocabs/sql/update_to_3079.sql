insert into _schema_revisions (revision) values (3079);

create table combined_routes (
  combined_route_id integer not null primary key,
  airport_from_id integer references airports(airport_id),  -- аэропорт вылета
  airport_via_id integer references airports(airport_id),   -- аэропорт пересадки
  airport_to_id integer references airports(airport_id)     -- аэропорт прилёта
);