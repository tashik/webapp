begin;

insert into _schema_revisions (revision) values (13616);

-- Статусы дополнительных услуг
create table ancillary_service_statuses (
  code char(2) not null primary key, -- код
  names varchar(4096) not null       -- названия
);

commit;
