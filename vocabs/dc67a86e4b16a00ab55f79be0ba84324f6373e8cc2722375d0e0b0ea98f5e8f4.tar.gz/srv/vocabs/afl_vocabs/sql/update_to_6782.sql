insert into _schema_revisions (revision) values (6782);

CREATE TABLE service_classes_limits(
    service_classes_limit_id int not null primary key,
    airline_id integer not null references airlines(airline_id) on delete cascade deferrable,
    pair_id integer not null references pairs(pair_id) on delete cascade deferrable
);
