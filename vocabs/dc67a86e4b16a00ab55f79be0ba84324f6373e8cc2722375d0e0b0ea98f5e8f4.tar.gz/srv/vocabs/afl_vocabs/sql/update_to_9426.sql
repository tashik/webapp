BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (9426);

-- Добавление колонки "Город базирования" в модель "Авиакомпания".
ALTER TABLE airlines ADD COLUMN city_id INTEGER REFERENCES cities(city_id) DEFERRABLE;

COMMIT;
