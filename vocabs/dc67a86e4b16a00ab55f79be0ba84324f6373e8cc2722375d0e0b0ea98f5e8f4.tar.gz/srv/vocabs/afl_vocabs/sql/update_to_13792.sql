begin;

insert into _schema_revisions (revision) values (13792);

alter table ancillary_services_groups add column ordinal_number integer;
update ancillary_services_groups set ordinal_number = ancillary_services_group_id;
alter table ancillary_services_groups alter column ordinal_number set not null;
alter table ancillary_services_groups add unique (ordinal_number);

commit;
