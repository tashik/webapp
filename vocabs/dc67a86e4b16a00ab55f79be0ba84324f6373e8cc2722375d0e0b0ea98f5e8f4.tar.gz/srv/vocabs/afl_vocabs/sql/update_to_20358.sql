﻿BEGIN;

ALTER TABLE loyalty_programs ADD COLUMN sabre_id character varying(2);

INSERT INTO _schema_revisions (revision) VALUES (20358);

END;