begin;
insert into _schema_revisions (revision) values (7190);

alter table booking_classes drop constraint booking_classes_comment_id_fkey;
alter table booking_classes rename column comment_id to commentary;
alter table booking_classes alter column commentary type text;
update booking_classes set commentary = '' where commentary is null;
alter table booking_classes alter column commentary set not null;

commit;
