insert into _schema_revisions (revision) values (3176);

alter table award_miles rename column award_mile_id to award_id;
alter table award_miles rename to awards;