insert into _schema_revisions (revision) values (7104);

update tariff_groups set service_class=(select skyteam_sc_id::text from skyteam_service_classes where code=tariff_groups.service_class limit 1); 
alter table tariff_groups alter column service_class type integer using trim(service_class)::integer;
alter table tariff_groups alter column service_class set not null;
alter table tariff_groups add foreign key(service_class) references skyteam_service_classes deferrable;
