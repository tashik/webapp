insert into _schema_revisions (revision) values (6869);

alter table service_classes_limits DROP COLUMN airline_id;
alter table service_classes_limits add column  airline_sc_id integer not null references airline_service_classes(airline_sc_id) on delete cascade deferrable;