insert into _schema_revisions (revision) values (3771);

alter table awards rename column upgrade_checkin_ow to upgrade_xo_checkin;
alter table awards add column upgrade_xf_checkin integer;
alter table awards add column upgrade_fo_checkin integer;