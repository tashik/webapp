-- Проставляет has_afl_flights = TRUE для тех аэропортов, в которые летает Аэрофлот.
-- Для всех остальных аэропортов проставляет has_afl_flights = FALSE.
-- Маршруты Аэрофлота берутся из таблицы pairs.

UPDATE airports SET has_afl_flights = FALSE;

UPDATE airports SET has_afl_flights = TRUE WHERE airport_id in(
    SELECT airport_from_id FROM pairs WHERE airline_id = (
        SELECT airline_id FROM airlines where iata = 'SU'
    )
    UNION
    SELECT airport_to_id FROM pairs WHERE airline_id = (
        SELECT airline_id FROM airlines where iata = 'SU'
    )
);

