begin;

insert into _schema_revisions (revision) values (15520);

-- Дополнительная информация
create table additional_info (
  additional_info_id integer not null primary key,
  weight integer not null,                -- вес
  created date not null,                  -- дата создания
  names text not null,                    -- названия на разных языках
  condition json not null default '[]'    -- условия отображения
);

commit;
