begin;
insert into _schema_revisions (revision) values (26650);

ALTER TABLE countries ADD COLUMN city_id integer references cities(city_id) deferrable;

commit;