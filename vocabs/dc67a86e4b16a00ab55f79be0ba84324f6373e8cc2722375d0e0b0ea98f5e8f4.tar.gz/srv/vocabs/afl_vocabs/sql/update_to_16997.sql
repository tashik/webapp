begin;

insert into _schema_revisions (revision) values (16997);

-- Дополнительная колонка Вес для офисов
alter table offices add column "office_weight" integer not null default 50;

commit;
