BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (8426);

-- Добавление колоноки "Бизнес сегменты"
ALTER TABLE tier_levels ADD COLUMN business_segments integer default 0;

COMMIT;
