begin;

insert into _schema_revisions (revision) values (13863);

alter table ancillary_services_groups add column filename varchar(64);
update ancillary_services_groups set filename = 'services' || text(ancillary_services_group_id);
alter table ancillary_services_groups alter column filename set not null;
alter table ancillary_services_groups add unique (filename);

commit;
