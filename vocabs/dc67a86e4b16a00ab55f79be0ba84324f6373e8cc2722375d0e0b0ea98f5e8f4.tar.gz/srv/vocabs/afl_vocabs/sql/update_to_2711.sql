begin;
insert into _schema_revisions (revision) values (2711);

ALTER TABLE airports ADD COLUMN has_afl_flights boolean NOT NULL DEFAULT FALSE;

commit;
