begin;
insert into _schema_revisions (revision) values (3020);
ALTER TABLE airports DROP CONSTRAINT airports_redemption_zone_fkey;
ALTER TABLE airports DROP redemption_zone;
ALTER TABLE redemption_zones DROP redemption_zone_id;
ALTER TABLE redemption_zones ADD PRIMARY KEY ( code );
ALTER TABLE redemption_zones RENAME COLUMN code TO redemption_zone;
ALTER TABLE airports ADD redemption_zone varchar (2) references redemption_zones (redemption_zone);
commit;