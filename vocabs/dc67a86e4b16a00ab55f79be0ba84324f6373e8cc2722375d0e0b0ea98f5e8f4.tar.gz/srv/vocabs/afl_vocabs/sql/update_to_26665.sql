begin;
insert into _schema_revisions (revision) values (26665);

ALTER TABLE cities DROP COLUMN radius;
commit;
