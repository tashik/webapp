insert into _schema_revisions (revision) values (3475);

--Офисы
CREATE TABLE offices
(
  office_id integer not null primary key,
  city varchar(4096) not null,
  country varchar(4096) not null,
  office_description varchar(4096) not null,
  email varchar(4096) not null,
  fax varchar(4096) not null,
  phone varchar(4096) not null,
  lat decimal(7,4),
  lon decimal(7,4),
  address varchar(4096) not null,
  office_title varchar(4096) not null,
  worktime varchar(4096) not null
);

commit;