DO $$
DECLARE
    num_rows numeric;
    x varchar[];
    v varchar[] := array[
        ['AADVANTAGE', 'AA'],
        ['AEROLINEAS Plus', 'AP'],
        ['AEROPLAN', 'AE'],
        ['ALFURSAN', 'AL'],
        ['ANA MILEAGE CLUB', 'AM'],
        ['BONUS CLUB', 'BC'],
        ['CLUB PREMIER', 'CP'],
        ['CEDAR MILES', 'CM'],
        ['DIVIDEND MILES', 'DM'],
        ['DYNASTY', 'DY'],
        ['EASTERN MILES', 'EM'],
        ['EGRET CLUB', 'EC'],
        ['EUROBONUS', 'EU'],
        ['EXECUTIVE CLUB', 'EX'],
        ['FINNAIR PLUS', 'FP'],
        ['FLY MORE', 'FM'],
        ['FLYING BLUE', 'FB'],
        ['FREQUENT FLYER PROGRAM', 'FR'],
        ['FREQUENT FLYER', 'FF'],
        ['GARUDA MILES', 'GM'],
        ['IBERIA PLUS', 'IP'],
        ['MILEAGE BANK', 'MB'],
        ['MILEAGE PLAN', 'MP'],
        ['MILEAGE PLUS', 'MI'],
        ['MILES AND MORE', 'MM'],
        ['MILES&SMILES', 'MS'],
        ['MILLE MIGLIA', 'MG'],
        ['MYJET2', 'MJ'],
        ['OK PLUS', 'OP'],
        ['PHOENIX MILES', 'PM'],
        ['PINS', 'PI'],
        ['ROYAL ORCHID PLUS', 'RO'],
        ['S7 PRIORITY', 'SP'],
        ['SKY MILES', 'SM'],
        ['SKY PEARL CLUB', 'SC'],
        ['SKYPASS', 'SK'],
        ['TRANSAERO PRIVILEGE', 'TP'],
        ['VOYAGER', 'VG'],
        ['CLUB PREMIER', 'CP'],
        ['PRIVILEGE CLUB', 'PC'],
        ['GOLD CIRCLE CLUB', 'GC'],
        ['AIR POINTS', 'AI'],
        ['ASIA MILES', 'AS'],
        ['INFINITY MILEAGELANDS', 'IM'],
        ['ENRICH', 'ER'],
        ['WORLDPERKS', 'WP'],
        ['MABUHAY MILES', 'MA'],
        ['KRISFLYER', 'KF'],
        ['RAPID REWARDS', 'RR'],
        ['SMILES', 'SI'],
        ['FLYING CLUB', 'FC']
    ];
BEGIN
    FOREACH x SLICE 1 IN ARRAY v
    LOOP
        UPDATE loyalty_programs SET siebel_id = UPPER(x[2]) WHERE LOWER(name) = LOWER(x[1]);
        GET DIAGNOSTICS num_rows = ROW_COUNT;
        RAISE INFO 'Insert % rows (%)', num_rows, x[1];
    END LOOP;
END
$$