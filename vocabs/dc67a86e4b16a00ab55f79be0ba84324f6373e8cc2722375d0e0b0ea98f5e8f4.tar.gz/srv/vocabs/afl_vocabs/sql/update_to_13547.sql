begin;

insert into _schema_revisions (revision) values (13547);

-- Услуги EMD
create table emd_services (
  code char(3) not null primary key,                                            -- код услуги EMD
  names varchar(4096) not null,                                                 -- названия услуги EMD на разных языках
  emd_group_id integer not null references emd_groups(emd_group_id) deferrable  -- группа услуг EMD
);

commit;
