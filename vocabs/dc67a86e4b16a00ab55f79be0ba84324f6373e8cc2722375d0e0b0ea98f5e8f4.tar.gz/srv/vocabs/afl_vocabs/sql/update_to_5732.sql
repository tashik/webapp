insert into _schema_revisions (revision) values (5732);

ALTER TABLE partners ALTER COLUMN url TYPE varchar(256) USING url::varchar(256);
ALTER TABLE partners ALTER COLUMN logo_url TYPE varchar(256) USING logo_url::varchar(256);
