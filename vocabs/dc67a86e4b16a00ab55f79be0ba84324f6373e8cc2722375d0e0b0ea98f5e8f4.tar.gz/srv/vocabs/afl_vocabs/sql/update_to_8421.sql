BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (8421);

-- Добавление колоноки "Квалификационный уровень"
ALTER TABLE skyteam_service_classes ADD COLUMN classification_level varchar(1);

COMMIT;
