insert into _schema_revisions (revision) values (5796);

--Категории партнёров-неавиакомпаний
CREATE TABLE partner_categories
(
  partner_category_id integer not null primary key,
  status varchar(1) not null,
  names varchar(4096) not null
);

--Партнёры-неавиакомпании
CREATE TABLE partners
(
  partner_id integer not null primary key,
  names varchar(4096) not null,
  partner_description varchar(4096),
  logo_url varchar(4096),
  url varchar(4096),
  partner_category_id integer not null references partner_categories(partner_category_id) deferrable
);

--Филиалы  партнёров-неавиакомпаний
CREATE TABLE partner_offices
(
  partner_office_id integer not null primary key,
  partner_id  integer not null references partners(partner_id) deferrable,
  city_id integer not null references cities(city_id) deferrable,
  lat decimal(7,4),
  lon decimal(7,4),
  comments varchar(4096),
  address varchar(4096),
  worktime varchar(4096),
  office_type varchar(1)
);

--Контакты филиалов партнёров-неавиакомпаний
CREATE TABLE partner_office_contacts
(
  partner_office_contact_id integer not null primary key,
  partner_office_id integer not null references partner_offices(partner_office_id) on delete cascade deferrable,
  contact_type varchar(1) not null,
  contact varchar(4096) not null,
  main_contact boolean default false
);
