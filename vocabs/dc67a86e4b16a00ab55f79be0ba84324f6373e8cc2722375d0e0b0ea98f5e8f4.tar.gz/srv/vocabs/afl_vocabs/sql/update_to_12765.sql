begin;

insert into _schema_revisions (revision) values (12765);

-- Спецпитание
create table special_meal (
  code char(4) not null primary key,    -- код специального питания
  names varchar(4096) not null          -- наименование специального питания
);

commit;
