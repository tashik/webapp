begin;
insert into _schema_revisions (revision) values (7192);

alter table partners drop column logo_url;
alter table partners add column mile_get_comm text not null default '';
alter table partners add column mile_waste_comm text not null default '';
alter table partners add column short_descr text not null default '';

commit;
