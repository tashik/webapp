BEGIN;

INSERT INTO _schema_revisions (revision) values (7998);

ALTER TABLE airlines ADD COLUMN miles_minimum FLOAT NOT NULL DEFAULT 0.0;
ALTER TABLE airlines ADD COLUMN miles_limitation VARCHAR(1) NOT NULL DEFAULT 'N';

COMMIT;
