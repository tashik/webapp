begin;

insert into _schema_revisions (revision) values (13593);

-- Группы дополнительных услуг RFIC
create table ancillary_services_rfic_groups (
  code char(1) not null primary key,  -- RFIC
  names varchar(4096) not null        -- названия на разных языках
);

commit;
