insert into _schema_revisions (revision) values (7027);

-- Task 14125
alter table awards drop column if exists names;
