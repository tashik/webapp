BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (10383);

UPDATE offices SET important_info = 'ru:' WHERE important_info = '';

COMMIT;
