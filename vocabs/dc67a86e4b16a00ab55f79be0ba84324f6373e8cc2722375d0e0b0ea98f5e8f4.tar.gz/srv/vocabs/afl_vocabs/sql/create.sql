---------------------------------------------------------------------------------
-- Create Application Database Schema
--------------------------------------------------------------------------------

create sequence global_seq start 500001;

create table _schema_revisions (
  revision integer not null primary key,
  applied timestamp not null default NOW()
);
insert into _schema_revisions values (left(right('$Rev: 27929 $', 6), -2)::int, now());

-- Премиальные зоны
create table redemption_zones (
  redemption_zone varchar (2) not null primary key,  -- код премиальной зоны
  names varchar (4096) not null                      -- наименование премиальной зоны
);

-- Регионы мира
create table world_regions (
  world_region_id integer not null primary key,
  names varchar(4096) not null   -- языковые варианты названия объекта в формате [language1[_territory1]:name1|[language2[_territory2]:name2
);

-- Валюты
create table currencies (
  alpha3_code char(3) not null primary key, -- 3-символьный код валюты (ISO 4217 / ОКВ)
  iso_code char(3) unique,                  -- числовой код валюты (ISO 4217 / ОКВ)
  cbr_code varchar(30) unique,              -- код для поиска курса валюты ЦБ РФ
  minor_unit integer not null,              -- число дробных знаков в разменной единице
  names varchar(4096) not null,
  used_in_calc boolean not null default false,
  rounding_unit decimal not null default 1  -- единица округления
);

-- Страны
create table countries (
  country char(2) not null primary key,
  iso_code3 varchar(3) unique,  -- см. http:--en.wikipedia.org/wiki/ISO_3166-1_alpha-3
  world_region_id integer references world_regions(world_region_id),
  names varchar(4096) not null,
  telephone_code integer,       -- телефонный код страны
  use_in_siebel boolean not null,
  currency_alpha3_code char(3) not null default 'RUR' references currencies,
  use_in_pos boolean not null default false, -- используется в AFL_POS
  pcc_code varchar(4) default '',
  station_code varchar(20) default '00000000',
  corporate_station_code varchar(20) default '00000000',
  corporate_pcc_code varchar(4) default '',
  corporate_currency_alpha3_code char(3) references currencies(alpha3_code)
);

-- Города
create table cities (
  city_id integer not null primary key,
  country char(2) not null references countries(country) deferrable,
  tz varchar(32) not null,
  iata varchar(3) unique,
  names varchar(4096) not null,
  lat decimal(7,4),
  lon decimal(7,4),
  can_book boolean default true,
  alternative_cities varchar(512)
);

ALTER TABLE countries ADD COLUMN city_id integer references cities(city_id) deferrable;

-- Аэропорты
create table airports (
  airport_id integer not null primary key,
  iata varchar(3) unique,
  icao varchar(4) unique,
  city_id integer not null references cities(city_id) deferrable,
  names varchar(4096) not null,
  has_afl_flights boolean not null default false,
  afl_redemption_zone varchar (2) references redemption_zones(redemption_zone),
  skyteam_redemption_zone varchar (2) references redemption_zones(redemption_zone),
  lat decimal(7,4),
  lon decimal(7,4),
  has_uc_award boolean not null default false
);

-- Терминалы аэропортов
create table airport_terminals (
  terminal_id integer not null,
  airport_id integer not null references airports(airport_id) on delete cascade deferrable,
  code varchar(20) not null,
  names varchar(4096)
);

-- Программы лояльности
create table loyalty_programs (
  loyalty_program_id integer not null primary key,
  name varchar(128) not null,
  siebel_id varchar(4) unique,                       -- идентификатор в системе Siebel
  sabre_id varchar(2) unique                         -- идентификатор в системе Sabre
);

-- Авиакомпании
create table airlines (
  airline_id integer not null primary key,
  iata varchar(3) unique,
  icao varchar(3) unique,
  callsign varchar(64),
  country char(2) references countries(country) deferrable,
  airport_id integer references airports(airport_id) deferrable,
  names varchar(4096) not null,
  alliance varchar(16),
  loyalty_program_id integer references loyalty_programs(loyalty_program_id),
  parent_airline_id integer,
  url varchar(1024) not null,
  weight integer not null,
  miles_minimum float not null default 0.0,
  miles_limitation varchar(1) not null default 'N',
  miles_earn_description text not null,
  miles_earn_comment text not null
);

-- Типы воздушных судов
create table aircraft_types (
  aircraft_type_id integer not null primary key,
  ohd_code varchar(20),
  iata varchar(3),
  icao varchar(4),
--  mtow integer,
--  mldw integer,
  pax_capacity integer,
  cargo_capacity integer,
  f integer,
  c integer,
  y integer,
--  length decimal(5,2),
--  width decimal(5,2),
--  height decimal(5,2),
--  mzfw integer,
--  number_engines varchar(14),
--  engine_model varchar(50),
--  timeslot_normal varchar(15),
--  timeslot_short varchar(14),
--  stand_time decimal(38,0),
  names varchar(4096) not null
);

-- Статусы учатника
create table tier_levels(
  tier_level varchar(16) not null  primary key, -- код статуса участника
  names varchar (4096) not null,                -- наименование статуса участника
  ordering integer not null,                    -- вес записи
  miles integer,                                -- Мили, количество миль для достижения уровня
  segments integer,                             -- Сегменты, количество перелетов, которое необходимо совершить для достижения урованя
  business_segments integer default 0           --  Бизнес сегменты
);

-- Пары
create table pairs (
  pair_id integer not null primary key,
  airport_from_id integer references airports(airport_id) deferrable, -- аэропорт вылета
  airport_to_id integer references airports(airport_id) deferrable,   -- аэропорт прилета
  miles integer,                                                      -- расстояние
  airline_id integer references airlines(airline_id) deferrable,      -- авиакомпания
  no_spending boolean                                                 -- не предоставлять трату
);

-- Запрещённые маршруты
create table wrong_routes (
  wrong_route_id integer not null primary key,
  city_from_id integer references cities(city_id) deferrable,   -- город вылета
  city_via_id integer references cities(city_id) deferrable,    -- город пересадки
  city_to_id integer references cities(city_id) deferrable      -- город прилета
);

-- Типы питания
create table meal_types
(
  meal_type varchar(1) not null primary key,
  names varchar(4096) not null
);

-- Категории офисов продаж
create table office_categories(
  office_category_id int not null primary key,
  office_category_description text not null,
  names varchar(4096) not null,
  city_id integer not null references cities(city_id) deferrable
);

--Офисы
create table offices
(
  office_id integer not null primary key,
  names varchar(4096),
  office_description varchar(4096) not null,
  email varchar(4096) not null,
  fax varchar(4096) not null,
  phone varchar(4096) not null,
  lat decimal(7,4),
  lon decimal(7,4),
  address text not null,
  working_time text not null,
  in_airport boolean,
  insurance_policy boolean,
  noncash_booking boolean,
  new_office boolean,
  airport_id integer references airports(airport_id) deferrable,
  distance_to_airport integer,
  office_category_id integer references office_categories(office_category_id) deferrable not null,
  location_map  varchar(4096) not null,
  transfer_time_public  integer,
  transfer_time_automobile  integer,
  transfer_time_foot  integer,
  important_info varchar (4096) not null,
  office_weight integer not null default 50
);

-- Дорога до офиса
create table office_travel_options
(
  office_travel_option_id integer not null primary key,
  office_id integer not null references offices(office_id) on delete cascade deferrable,
  travel_type varchar(1) not null,
  office_travel_option_description text not null,
  travel_time integer
 );

-- Категории партнёров-неавиакомпаний
create table partner_categories
(
  partner_category_id integer not null primary key,
  status varchar(1) not null,
  names varchar(4096) not null
);

-- Партнёры-неавиакомпании
create table partners
(
  partner_id integer not null primary key,
  names varchar(4096) not null,
  partner_description text not null,
  url varchar(1024) not null,
  partner_categories varchar (4096) default '',
  status varchar (1),
  mile_action varchar (1),
  mile_get_comm text not null,
  mile_waste_comm text not null,
  short_descr text not null,
  spec_offer_comm text not null,
  weight integer not null,
  new_until date
);

-- Филиалы партнёров-неавиакомпаний
create table partner_offices
(
  partner_office_id integer not null primary key,
  partner_id  integer not null references partners(partner_id) deferrable,
  city_id integer not null references cities(city_id) deferrable,
  lat decimal(7,4),
  lon decimal(7,4),
  comments text not null,
  address text not null,
  working_time text not null,
  office_type varchar(1),
  status varchar(1)
);

-- Контакты филиалов партнёров-неавиакомпаний
create table partner_office_contacts
(
  partner_office_contact_id integer not null primary key,
  partner_office_id integer not null references partner_offices(partner_office_id) on delete cascade deferrable,
  contact_type varchar(1) not null,
  contact varchar(4096) not null,
  main_contact boolean default false
);

-- Условия набора и траты миль для партнёров-неавиакомпаний
create table partner_award_conditions
(
  partner_award_condition_id integer not null primary key,
  partner_id  integer not null references partners(partner_id) deferrable,
  award_condition_type varchar(1) not null,
  award_condition_description text not null,
  weight integer not null,
  status varchar(1) not null,
  miles float not null default 0.0
);


-- Классы обслуживания SkyTeam
create table skyteam_service_classes(
  skyteam_sc_id int not null primary key,
  code varchar(4096) not null,
  names varchar(4096) not null,
  weight integer not null default 0,
  classification_level varchar(1)
);

-- Классы обслуживания авиакомпаний
create table airline_service_classes(
  airline_sc_id int not null primary key,
  airline_id int not null references airlines(airline_id) deferrable,
  skyteam_sc_id int not null references skyteam_service_classes(skyteam_sc_id) deferrable
);

-- Тарифные группы
create table tariff_groups (
  id integer not null primary key,
  service_class integer not null references skyteam_service_classes(skyteam_sc_id) deferrable,
  tariff_group varchar(50) UNIQUE not null,
  names varchar(4096) not null,
  weight integer not null default 0
);

-- Тарифные группы для авиакомпании
create table airline_tariff_groups(
  id integer not null primary key,
  tariff_group integer references tariff_groups(id) deferrable,
  service_class integer references airline_service_classes(airline_sc_id) deferrable,
  charge_coef integer not null,
  weight integer not null,
  fare_code varchar(50)
);

-- Комментарии
create table comments(
  comment_id    int not null primary key,
  names         varchar(4096) not null,
  weight        int not null
);

-- Классы бронирования
create table booking_classes(
  id                integer not null primary key,
  bc_code           varchar(50) not null,
  miles_are_charged boolean not null,
  commentary        text,
  al_tariff_group   integer references airline_tariff_groups deferrable,
  unique(bc_code, al_tariff_group)
);

-- Ограничения для классов обслуживания
create table service_classes_limits(
    service_classes_limit_id int not null primary key,
    airline_sc_id integer not null references airline_service_classes(airline_sc_id) on delete cascade deferrable,
    pair_id integer not null references pairs(pair_id) on delete cascade deferrable
);


-- Премиальные маршруты
create table bonus_routes (
  bonus_route_id  int not null primary key,
  code              varchar(6) not null,
  zone_from         varchar(2) references redemption_zones(redemption_zone) deferrable,
  zone_via          varchar(2) references redemption_zones(redemption_zone) deferrable,
  zone_to           varchar(2) references redemption_zones(redemption_zone) deferrable,
  carrier           varchar(1) not null default 'A'
);

-- Премии
create table awards (
  award_id  int not null primary key,
  type varchar (2) not null,
  service_classes_1 integer not null references skyteam_service_classes(skyteam_sc_id) on delete cascade deferrable,
  service_classes_2 integer references skyteam_service_classes(skyteam_sc_id) on delete cascade deferrable,
  award_value int not null,
  route integer references bonus_routes(bonus_route_id) on delete cascade deferrable,
  comment int references comments(comment_id)   deferrable
);

-- Коэффициенты статуса участника
create table tier_level_factors(
    tier_level_factor_id int not null primary key,
    airline integer references airlines(airline_id) on delete cascade deferrable,
    tier_level varchar(16) references tier_levels(tier_level) on delete cascade deferrable,
    factor decimal(7,4) not null
);


-- Спецпредложения
create table special_offers
(
  offer_id integer not null primary key,
  partner_id integer not null references partners(partner_id) deferrable,
  names varchar(4096) not null,
  begin_date timestamp with time zone,
  end_date timestamp with time zone,
  status varchar(1) not null,
  offer_description text not null,
  offer_url varchar(1024) not null,
  ui_languages varchar(4096)
);

-- Профессиональные области
create table professional_areas (
  professional_area_id integer not null primary key,
  names varchar(4096) not null
);

-- Языки
create table languages (
  alpha2_code char(2) not null primary key, -- код языка ISO 3166-1 alpha-2
  alpha3_code char(3) not null,             -- код языка ISO 3166-1 alpha-3
  selector_code char(3) not null,           -- сокращение для переключателя языков
  names varchar(4096) not null,             -- наименование языка
  is_active boolean not null                -- активен
);

-- Локализации
create table localizations (
  code char(2) not null primary key,                                              -- код локализации
  names varchar(4096) not null,                                                   -- наименование локализации
  default_language char(2) not null references languages(alpha2_code) deferrable, -- основной язык локализации
  allowed_languages varchar(512) not null,                                        -- доступные языки локализации
  is_active boolean not null                                                      -- активен
);

-- Спецпитание
create table special_meal (
  code char(4) not null primary key,    -- код специального питания
  names varchar(4096) not null          -- наименование специального питания
);

-- Группы дополнительных услуг
create table ancillary_services_groups (
  ancillary_services_group_id integer not null primary key,
  names varchar(4096) not null,           -- названия на разных языках
  ordinal_number integer not null unique, -- порядковый номер
  filename varchar(64) not null unique,     -- название файла
  message varchar(4096) not null default '' -- сообщение
);

-- Коды RFIC
create table rfic_codes (
  code char(1) not null primary key, -- код RFIC
  names varchar(4096) not null       -- название на разных языках
);

-- Дополнительные услуги
create table ancillary_services (
  code char(3) not null,                                                                                                     -- RFISC
  names varchar(4096) not null,                                                                                              -- названия на разных языках
  descriptions text not null,                                                                                                -- описания на разных языках
  ancillary_services_group_id integer not null references ancillary_services_groups(ancillary_services_group_id) deferrable, -- группа дополнительных услуг
  rfic char(1) not null references rfic_codes(code) deferrable,                                                              -- RFIC
  doc_prefix varchar(4096) not null default '',                                                                               -- DOC_PREFIX
  emd_message varchar(4096) not null default '',                                                                              -- EMD_MESSAGE
  primary key (rfic, code)
);

-- Статусы дополнительных услуг
create table ancillary_service_statuses (
  code char(2) not null,        -- код
  names varchar(4096) not null, -- названия
  rfic char(1),                 -- RFIC
  rfisc char(3),                -- RFISC
  ancillary_service_status_id serial primary key,
  foreign key (rfic, rfisc) references ancillary_services (rfic, code)
);

create unique index ancillary_service_statuses_code_rfic_rfisc_key on ancillary_service_statuses
  using btree(code, coalesce(rfic, ''), coalesce(rfisc, ''));

-- Дополнительная информация
create table additional_info (
  additional_info_id integer not null primary key,
  weight integer not null,                -- вес
  created date not null,                  -- дата создания
  names text not null,                    -- названия на разных языках
  condition json not null default '[]'    -- условия отображения
);

-- Ставки НДС
create table vat_rates (
    id integer primary key,
    rfic char(1) not null,
    rfisc char(3) not null,
    start_date timestamp,
    stop_date timestamp,
    rate float check(rate between 0 and 100) not null,
    check (start_date < stop_date)
);

-- Правила заказа питания
create table meal_rules (
  meal_rule_id integer not null primary key,
  date_from date,
  date_to date,
  number text,
  airline text,
  origin text,
  destination text,
  booking_class text,
  special_meal text
);

-- Ограничение времени выбора питания
create table meal_timelimits (
  meal_timelimit_id integer not null primary key,
  origin text,
  special_meal text,
  timelimit integer not null
);

-- создание таблицы справочника "Благотворительные фонды" (#2817)
CREATE TABLE charity_funds(
  charity_funds_id integer not null primary key,
  charity_id varchar(16) NOT NULL, -- Номер фонда в системе лояльности (charity_id)	Обязательно
  tag text NOT NULL, -- Тег фонда. Обязательно
  names varchar(4096) not null, -- Название фонда	Многоязычное однострочное текстовое поле	Обязательно
  logo_url text not null, -- Ссылка на логотип	Многоязычное однострочное текстовое поле	Обязательно
  image_url text default '', -- Ссылка на изображение	Многоязычное однострочное текстовое поле	Не обязательно
  charity_short_description text not null, -- Краткое описание фонда	Многоязычное однострочное текстовое поле	Обязательно
  charity_description text not null, -- Описание фонда	Многоязычное многострочное текстовое поле	Обязательно
  url text not null, --  Ссылка на сайт фонда	Многоязычное однострочное текстовое поле	Обязательно
  transfer_conditions text not null, -- Условия перевода	Многоязычное многострочное текстовое поле	Обязательно
  news_url text default '', -- Ссылка «Новости фонда» на ОС	Многоязычное однострочное текстовое поле	Нет
  news_mv_url text default '', -- Ссылка «Новости фонда» на МС	Многоязычное однострочное текстовое поле	Нет
  donate_miles_url varchar (1024) not null, -- Ссылка «Пожертвовать мили» на ОС	Однострочное поле	Да
  donate_miles_mv_url varchar (1024) not null, -- Ссылка «Пожертвовать мили» на МС	Однострочное поле	Да
  stats_charity_funds_url varchar (1024) not null, -- Ссылка на файл «Статистика фонда»	Однострочное поле	Да
  rss_url varchar (1024) default '', -- RSS-сервис новостей фонда	Однострочное поле	Нет
  status varchar (1), -- Статус	Выбор из списка: Опубликовано/ Не опубликовано	Да	Значение по умолчанию – Не опубликовано
  weight integer not null default 0, -- Вес	Числовое	Да	Значение по умолчанию – 0
  create_date date not null, -- create	Дата и время	Да	Системное поле. Указывается дата и время создания записи фонда
  modify_date date not null, -- modify	Дата и время	Да	Системное поле. Указывается дата и время изменений записи фонда
  contacts text default '' -- поле "Контакты" Многоязычное многострочное текстовое поле, Не обязательное для заполнения.
);
