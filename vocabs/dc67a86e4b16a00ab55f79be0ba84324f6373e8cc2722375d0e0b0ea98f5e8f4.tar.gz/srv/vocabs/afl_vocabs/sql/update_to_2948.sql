insert into _schema_revisions (revision) values (2948);

create table service_classes (
  service_class varchar(10) not null primary key,
  names varchar(4096) not null
);

create table tariff_groups (
  tariff_group_id integer not null primary key,
  service_class varchar(10) references service_classes(service_class) deferrable,
  code varchar(10) not null,
  names varchar(4096) not null
);

create table tariff_group_booking_classes (
  booking_class_id integer not null primary key,
  tariff_group_id integer not null references tariff_groups(tariff_group_id) on delete cascade deferrable,
  code char(1) not null
);