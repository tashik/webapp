insert into _schema_revisions (revision) values (3130);
ALTER TABLE airports ADD lat decimal(7,4);
ALTER TABLE airports ADD lon decimal(7,4);