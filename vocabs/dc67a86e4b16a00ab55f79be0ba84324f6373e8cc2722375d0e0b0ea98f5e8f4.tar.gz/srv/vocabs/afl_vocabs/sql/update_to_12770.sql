begin;

insert into _schema_revisions (revision) values (12770);

alter table countries add use_in_siebel boolean;
update countries set use_in_siebel = true;
alter table countries alter use_in_siebel set not null;

commit;
