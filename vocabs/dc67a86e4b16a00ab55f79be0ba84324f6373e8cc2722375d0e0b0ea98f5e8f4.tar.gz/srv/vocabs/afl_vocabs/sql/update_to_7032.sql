insert into _schema_revisions (revision) values (7032);

alter sequence global_seq start with 500001;
alter sequence global_seq restart;