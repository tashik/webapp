insert into _schema_revisions (revision) values (6209);

-- Класс обслуживания SkyTeam
create table skyteam_service_classes(
  skyteam_sc_id int not null primary key,
  code varchar(4096) not null,
  names varchar(4096) not null
);

-- Класс обслуживания авиакомпаний
create table airline_service_classes(
  airline_sc_id int not null primary key,
  airline_id int not null references airlines(airline_id) deferrable,
  skyteam_sc_id int not null references skyteam_service_classes(skyteam_sc_id) deferrable
);
