insert into _schema_revisions (revision) values (6314);

-- обновление таблицы Статуса участника (#14122)
ALTER TABLE tier_levels DROP COLUMN  miles_factor;           -- коэффициент для начисления миль

