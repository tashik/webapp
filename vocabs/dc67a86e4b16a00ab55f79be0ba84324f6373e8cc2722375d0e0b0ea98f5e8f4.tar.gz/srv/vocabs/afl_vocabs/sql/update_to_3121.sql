insert into _schema_revisions (revision) values (3121);

create table award_miles (
  award_mile_id integer not null primary key,
  zone_from varchar(2) references redemption_zones(redemption_zone) deferrable,
  zone_via varchar(2) references redemption_zones(redemption_zone) deferrable,
  zone_to varchar(2) references redemption_zones(redemption_zone) deferrable,
  alias varchar(32) not null,  
  economy_ow integer,
  economy_rt integer,
  comfort_ow integer,
  comfort_rt integer,
  business_ow integer,
  business_rt integer,
  upgrade_xo integer,
  upgrade_xf integer,
  upgrade_fo integer,
  upgrade_checkin_ow integer
);