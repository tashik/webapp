begin;

insert into _schema_revisions (revision) values (13683);

alter table ancillary_services add column descriptions text not null default '';

commit;
