insert into _schema_revisions (revision) values (22355);

ALTER TABLE countries ADD COLUMN pcc_code varchar(4) default '';
ALTER TABLE countries ADD COLUMN station_code integer;
ALTER TABLE countries ADD COLUMN coorporate boolean default FALSE;
ALTER TABLE countries ADD COLUMN pos_currency_alpha3_code char(3) references currencies(alpha3_code);