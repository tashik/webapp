BEGIN;

INSERT INTO _schema_revisions (revision) values (7906);

-- Удаление колонки "перевозчик" из таблицы премиальных зон
ALTER TABLE redemption_zones DROP COLUMN carrier;

COMMIT;
