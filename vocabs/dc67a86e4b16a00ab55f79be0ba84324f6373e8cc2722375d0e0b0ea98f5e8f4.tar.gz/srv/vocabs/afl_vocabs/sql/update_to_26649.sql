insert into _schema_revisions (revision) values (26649);

ALTER TABLE cities ADD COLUMN radius integer;
