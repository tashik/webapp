begin;

insert into _schema_revisions (revision) values (14580);

alter table ancillary_service_statuses add column rfic char(1);
alter table ancillary_service_statuses add column rfisc char(3);
alter table ancillary_service_statuses add foreign key (rfic, rfisc) references ancillary_services (rfic, code);
alter table ancillary_service_statuses drop constraint ancillary_service_statuses_pkey;
alter table ancillary_service_statuses add column ancillary_service_status_id serial primary key;
create unique index ancillary_service_statuses_code_rfic_rfisc_key on ancillary_service_statuses
  using btree(code, coalesce(rfic, ''), coalesce(rfisc, ''));

commit;
