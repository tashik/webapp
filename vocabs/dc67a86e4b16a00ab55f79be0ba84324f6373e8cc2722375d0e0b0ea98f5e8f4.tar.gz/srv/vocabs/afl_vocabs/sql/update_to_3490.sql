insert into _schema_revisions (revision) values (3490);
DROP TABLE offices;
--Офисы
CREATE TABLE offices
(
  office_id integer not null primary key,
  city_id integer not null references cities(city_id) deferrable,
  office_description varchar(4096) not null,
  email varchar(4096) not null,
  fax varchar(4096) not null,
  phone varchar(4096) not null,
  lat decimal(7,4),
  lon decimal(7,4),
  address varchar(4096) not null,
  worktime varchar(4096) not null
);
--remove unique iata
ALTER TABLE cities DROP CONSTRAINT cities_iata_key;

commit;