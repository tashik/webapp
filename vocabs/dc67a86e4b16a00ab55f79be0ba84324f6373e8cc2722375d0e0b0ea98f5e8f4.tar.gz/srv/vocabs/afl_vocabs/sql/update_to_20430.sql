insert into _schema_revisions (revision) values (20430);

ALTER TABLE charity_funds ADD COLUMN contacts text default '';

