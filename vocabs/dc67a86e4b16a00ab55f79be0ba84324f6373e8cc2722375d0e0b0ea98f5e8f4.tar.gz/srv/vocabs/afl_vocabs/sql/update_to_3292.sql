insert into _schema_revisions (revision) values (3192);

--Тип питания
CREATE TABLE mealtypes
(
  mealtype varchar(1) not null primary key,
  names varchar(4096) not null
)