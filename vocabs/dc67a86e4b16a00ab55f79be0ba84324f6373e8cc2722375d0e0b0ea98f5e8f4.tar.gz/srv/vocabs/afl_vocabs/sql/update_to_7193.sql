begin;
insert into _schema_revisions (revision) values (7193);

create table miles_get_waste_conditions(
    id          integer not null primary key,
    partner     integer not null references partners
                on delete cascade deferrable,
    cond_type   varchar(1) not null default 'E',
    description text not null default '',
    weight      integer not null,
    status      varchar(1) not null default 'U'
);

commit;
