ALTER TABLE redemption_zone RENAME COLUMN zone_code_id TO redemption_zone_id;
ALTER TABLE redemption_zone RENAME COLUMN zone_code TO code;
ALTER TABLE redemption_zone RENAME TO redemption_zones;
ALTER TABLE redemption_zones ALTER COLUMN zone_name TYPE varchar(4096) USING zone_name::varchar(4096);;
