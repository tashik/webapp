begin;

insert into _schema_revisions (revision) values (12704);

alter table airlines alter url set not null;
alter table airlines alter miles_earn_description drop default;
alter table airlines alter miles_earn_comment drop default;

alter table office_categories alter office_category_description type text;

alter table office_travel_options alter office_travel_option_description type text;

alter table offices alter address type text;
alter table offices alter worktime type text;
alter table offices alter location_map drop default;
alter table offices alter location_map set not null;
alter table offices alter important_info drop default;
alter table offices alter important_info set not null;

alter table partners alter partner_description drop default;
alter table partners alter url set not null;
alter table partners alter mile_get_comm set not null;
alter table partners alter mile_waste_comm set not null;
alter table partners alter short_descr set not null;
alter table partners alter spec_offer_comm set not null;
alter table partners alter mile_get_comm drop default;
alter table partners alter mile_waste_comm drop default;
alter table partners alter short_descr drop default;
alter table partners alter spec_offer_comm drop default;

alter table partner_offices alter comments type text;
alter table partner_offices alter address type text;
alter table partner_offices alter worktime type text;
alter table partner_offices alter comments set not null;
alter table partner_offices alter address set not null;
alter table partner_offices alter worktime set not null;

alter table partner_award_conditions alter award_condition_description type text;

alter table special_offers alter offer_url type varchar(1024);

update world_regions set names = regexp_replace(names, '\n|\r', '', 'g');

update countries set names = regexp_replace(names, '\n|\r', '', 'g');

update cities set names = regexp_replace(names, '\n|\r', '', 'g');

update airport_terminals set names = regexp_replace(names, '\n|\r', '', 'g');

update airports set names = regexp_replace(names, '\n|\r', '', 'g');

update airlines set names = regexp_replace(names, '\n|\r', '', 'g');
update airlines set miles_earn_description = regexp_replace(miles_earn_description, '\t', '    ', 'g');
update airlines set miles_earn_comment = regexp_replace(miles_earn_comment, '\t', '    ', 'g');

update aircraft_types set names = regexp_replace(names, '\n|\r', '', 'g');

update currencies set names = regexp_replace(names, '\n|\r', '', 'g');

update redemption_zones set names = regexp_replace(names, '\n|\r', '', 'g');

update tier_levels set names = regexp_replace(names, '\n|\r', '', 'g');

update tariff_groups set names = regexp_replace(names, '\n|\r', '', 'g');

update booking_classes set commentary = regexp_replace(commentary, '\t', '    ', 'g');

update mealtypes set names = regexp_replace(names, '\n|\r', '', 'g');

update office_categories set names = regexp_replace(names, '\n|\r', '', 'g');
update office_categories set office_category_description = regexp_replace(office_category_description, '\t', '    ', 'g');

update office_travel_options set office_travel_option_description = regexp_replace(office_travel_option_description, '\t', '    ', 'g');

update offices set names = regexp_replace(names, '\n|\r', '', 'g');
update offices set office_description = regexp_replace(office_description, '\n|\r', '', 'g');
update offices set email = regexp_replace(email, '\n|\r', '', 'g');
update offices set fax = regexp_replace(fax, '\n|\r', '', 'g');
update offices set phone = regexp_replace(phone, '\n|\r', '', 'g');
update offices set address = regexp_replace(address, '\t', '    ', 'g');
update offices set worktime = regexp_replace(worktime, '\t', '    ', 'g');
update offices set location_map = regexp_replace(location_map, '\n|\r', '', 'g');
update offices set important_info = regexp_replace(important_info, '\n|\r', '', 'g');

update partner_categories set names = regexp_replace(names, '\n|\r', '', 'g');

update partners set names = regexp_replace(names, '\n|\r', '', 'g');
update partners set partner_description = regexp_replace(partner_description, '\t', '    ', 'g');
update partners set url = regexp_replace(url, '\n|\r', '', 'g');
update partners set mile_get_comm = regexp_replace(mile_get_comm, '\t', '    ', 'g');
update partners set mile_waste_comm = regexp_replace(mile_waste_comm, '\t', '    ', 'g');
update partners set short_descr = regexp_replace(short_descr, '\t', '    ', 'g');
update partners set spec_offer_comm = regexp_replace(spec_offer_comm, '\t', '    ', 'g');

update partner_offices set comments = regexp_replace(comments, '\t', '    ', 'g');
update partner_offices set address = regexp_replace(address, '\t', '    ', 'g');
update partner_offices set worktime = regexp_replace(worktime, '\t', '    ', 'g');

update partner_award_conditions set award_condition_description = regexp_replace(award_condition_description, '\t', '    ', 'g');

update skyteam_service_classes set names = regexp_replace(names, '\n|\r', '', 'g');

update comments set names = regexp_replace(names, '\n|\r', '', 'g');

update special_offers set names = regexp_replace(names, '\n|\r', '', 'g');
update special_offers set offer_description = regexp_replace(offer_description, '\t', '    ', 'g');
update special_offers set offer_url = regexp_replace(offer_url, '\n|\r', '', 'g');

update professional_areas set names = regexp_replace(names, '\n|\r', '', 'g');

commit;
