insert into _schema_revisions (revision) values (6582);

alter table offices add  names  varchar(4096) default '';
