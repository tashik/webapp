begin;

insert into _schema_revisions (revision) values (7820);

-- Добавление колонки "перевозчик" в таблицу "премиальные зоны".
alter table redemption_zones add column carrier varchar(1) not null default 'A';

commit;
