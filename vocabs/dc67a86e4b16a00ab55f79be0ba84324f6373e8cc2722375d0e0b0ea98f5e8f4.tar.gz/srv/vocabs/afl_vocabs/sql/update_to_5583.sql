insert into _schema_revisions (revision) values (5583);

ALTER TABLE partners ALTER COLUMN partner_categories SET DEFAULT '';
