BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (16573);

ALTER TABLE countries ADD COLUMN currency_alpha3_code VARCHAR(3) NOT NULL DEFAULT 'RUB' REFERENCES currencies;

COMMIT;
