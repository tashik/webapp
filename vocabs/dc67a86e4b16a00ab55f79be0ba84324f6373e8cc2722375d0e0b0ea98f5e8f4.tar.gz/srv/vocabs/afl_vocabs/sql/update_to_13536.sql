begin;

insert into _schema_revisions (revision) values (13536);

-- Группы услуг EMD
create table emd_groups (
  emd_group_id integer not null primary key,
  names varchar(4096) not null      -- названия групп услуг EMD на разных языках
);

commit;
