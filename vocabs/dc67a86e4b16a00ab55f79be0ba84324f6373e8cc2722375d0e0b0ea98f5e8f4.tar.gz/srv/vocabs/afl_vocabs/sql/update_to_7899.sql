begin;
insert into _schema_revisions (revision) values (7899);

-- Изменение полей для спецпредложений
ALTER TABLE special_offers ALTER COLUMN offer_url TYPE character varying(4096);
ALTER TABLE special_offers ADD COLUMN ui_languages character varying(4096);
commit;