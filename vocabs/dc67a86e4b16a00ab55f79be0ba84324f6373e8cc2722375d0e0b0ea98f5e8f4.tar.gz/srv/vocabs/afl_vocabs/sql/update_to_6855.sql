insert into _schema_revisions (revision) values (6855);

-- Коэффициенты статуса участника
create table tier_level_factors(
    tier_level_factor_id int not null primary key,
    airline integer references airlines(airline_id) on delete cascade deferrable,
    tier_level varchar(16) references tier_levels(tier_level) on delete cascade deferrable,
    factor decimal(7,4) not null
);