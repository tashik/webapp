begin;

insert into _schema_revisions (revision) values (13856);

alter table ancillary_services_rfic_groups rename to rfic_codes;

commit;
