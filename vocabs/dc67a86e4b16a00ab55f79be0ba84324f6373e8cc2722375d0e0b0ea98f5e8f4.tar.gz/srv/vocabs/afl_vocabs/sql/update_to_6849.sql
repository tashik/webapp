insert into _schema_revisions (revision) values (6849);

-- Премия
create table awards (
  award_id  int not null primary key,
  names varchar(4096) not null,
  type varchar (2) not null,
  service_classes_1 integer not null references airline_service_classes(airline_sc_id) on delete cascade deferrable,
  service_classes_2 integer references airline_service_classes(airline_sc_id) on delete cascade deferrable,
  award_value int not null,
  route integer references premium_routes(premium_route_id) on delete cascade deferrable,
  comment int references comments(comment_id)   deferrable
);