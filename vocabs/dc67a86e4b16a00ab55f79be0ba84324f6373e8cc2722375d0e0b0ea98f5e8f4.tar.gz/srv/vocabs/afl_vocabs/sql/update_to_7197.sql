begin;
insert into _schema_revisions (revision) values (7197);

drop table miles_get_waste_conditions;
alter table partner_award_conditions add column miles
    float not null default 0.0;

commit;
