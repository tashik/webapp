insert into _schema_revisions (revision) values (6496);

-- создание таблицы комментариев (#14124)
CREATE TABLE comments(
  comment_id    int not null primary key,
  names         varchar(4096) not null,
  weight        int not null
);