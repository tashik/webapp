insert into _schema_revisions (revision) values (6873);

--  Авиакомпания из справочника авиакомпаний
alter table pairs add column airline_id integer references airlines(airline_id) deferrable;