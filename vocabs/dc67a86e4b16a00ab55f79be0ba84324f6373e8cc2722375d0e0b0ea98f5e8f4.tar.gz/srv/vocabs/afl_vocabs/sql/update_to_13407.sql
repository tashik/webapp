begin;

insert into _schema_revisions (revision) values (13407);

alter table offices rename worktime to working_time;
alter table partner_offices rename worktime to working_time;

commit;
