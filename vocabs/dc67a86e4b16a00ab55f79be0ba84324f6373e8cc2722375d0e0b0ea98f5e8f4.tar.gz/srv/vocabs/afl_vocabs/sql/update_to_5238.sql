insert into _schema_revisions (revision) values (5238);

create table loyalty_programs (
  loyalty_program_id integer not null primary key,
  name varchar(128) not null
);

create table professional_areas (
  professional_area_id integer not null primary key,
  names varchar(4096) not null
);