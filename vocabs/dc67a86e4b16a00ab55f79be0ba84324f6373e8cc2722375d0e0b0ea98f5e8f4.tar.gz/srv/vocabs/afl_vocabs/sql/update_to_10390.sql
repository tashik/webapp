BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (10390);

UPDATE airports SET has_afl_flights=FALSE;
UPDATE airports SET has_afl_flights=TRUE WHERE airport_id IN (SELECT airport_from_id FROM pairs WHERE airline_id=1) OR airport_id IN (SELECT airport_to_id FROM pairs WHERE airline_id=1);
COMMIT;
