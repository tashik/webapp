
insert into _schema_revisions (revision) values (7449);
ALTER TABLE airlines DROP url;
ALTER TABLE airlines ADD url varchar (1024) DEFAULT '' NOT NULL;
ALTER TABLE partners DROP url;
ALTER TABLE partners ADD url varchar (1024) DEFAULT '' NOT NULL;
