begin;

insert into _schema_revisions (revision) values (19973);

-- Используется в AFL_POS
ALTER TABLE countries ADD COLUMN use_in_pos boolean not null default false;

commit;
