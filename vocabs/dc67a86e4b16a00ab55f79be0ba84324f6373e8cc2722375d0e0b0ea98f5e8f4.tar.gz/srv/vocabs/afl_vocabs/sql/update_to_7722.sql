begin;
insert into _schema_revisions (revision) values (7722);

-- Спецпредложения
create table special_offers
(
  offer_id integer not null primary key,
  partner_id integer not null references partners(partner_id) deferrable,
  names character varying(4096) not null,
  begin_date timestamp with time zone,
  end_date timestamp with time zone,
  status character varying(1) not null,
  offer_description text not null,
  offer_url character varying(256) not null
);
commit;