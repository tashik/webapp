insert into _schema_revisions (revision) values (3508);

delete from countries where country = 'CS';
update countries set iso_code3 = 'SRB' where country = 'RS';

alter table countries add constraint countries_iso_code3_key unique (iso_code3);
alter table cities add constraint cities_iata_key unique (iata);
alter table currencies add constraint currencies_cbr_code_key unique (cbr_code);
