CREATE TABLE zone(
  zone_code_id integer not null primary key,
  zone_code varchar (2) not null  -- Обозначение зоны
);