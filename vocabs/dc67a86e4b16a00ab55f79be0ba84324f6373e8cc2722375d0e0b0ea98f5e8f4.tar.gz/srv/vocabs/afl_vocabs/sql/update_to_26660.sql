begin;
insert into _schema_revisions (revision) values (26660);

alter table cities add column alternative_cities varchar(512);

commit;
