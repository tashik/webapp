insert into _schema_revisions (revision) values (7109);

drop table tariff_group_booking_classes cascade;
