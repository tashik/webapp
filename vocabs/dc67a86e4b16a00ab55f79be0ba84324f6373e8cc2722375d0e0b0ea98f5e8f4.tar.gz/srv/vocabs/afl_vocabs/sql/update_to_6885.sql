insert into _schema_revisions (revision) values (6885);

/**
 -  tariff_group varchar(32) not null primary key,
 +  id integer not null primary key,
    service_class varchar(16) references service_classes(service_class) deferrable,
    -  names varchar(4096) not null,
    -  miles_factor_01 decimal(3,2) not null,
    -  miles_factor_02 decimal(3,2) not null,
    -  ordering integer not null                                                         -- вес записи
    +  tariff_group varchar(32) not null
     );
*/

ALTER TABLE tariff_groups DROP CONSTRAINT tariff_groups_pkey CASCADE;
ALTER TABLE tariff_groups ALTER COLUMN tariff_group TYPE varchar(50);
ALTER TABLE tariff_groups ADD UNIQUE(tariff_group);
ALTER TABLE tariff_groups ADD id integer not null primary key;
ALTER TABLE tariff_groups DROP COLUMN names;
ALTER TABLE tariff_groups DROP COLUMN miles_factor_01;
ALTER TABLE tariff_groups DROP COLUMN miles_factor_02;
ALTER TABLE tariff_groups DROP COLUMN ordering;
