begin;

insert into _schema_revisions (revision) values (12713);

-- Локализации
create table localizations (
  code char(2) not null primary key,                                              -- код локализации
  names varchar(4096) not null,                                                   -- наименование локализации
  default_language char(2) not null references languages(alpha2_code) deferrable, -- основной язык локализации
  allowed_languages varchar(512) not null,                                        -- доступные языки локализации
  is_active boolean not null                                                      -- активен
);

commit;
