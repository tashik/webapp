-- Статус учатника
CREATE TABLE  member_statuses(
  code varchar(10) not null  primary key , -- код статуса участника
  names varchar (4096) not null  -- наименование статуса участника
);
