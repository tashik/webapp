insert into _schema_revisions (revision) values (6852);

ALTER TABLE premium_routes RENAME TO bonus_routes;
ALTER TABLE bonus_routes RENAME COLUMN premium_route_id TO bonus_route_id;