BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (8123);

-- Добавление колонок "Описание набора миль" и "Примечания для набора миль"
ALTER TABLE airlines ADD COLUMN miles_earn_description TEXT NOT NULL DEFAULT '';
ALTER TABLE airlines ADD COLUMN miles_earn_comment TEXT NOT NULL DEFAULT '';

COMMIT;
