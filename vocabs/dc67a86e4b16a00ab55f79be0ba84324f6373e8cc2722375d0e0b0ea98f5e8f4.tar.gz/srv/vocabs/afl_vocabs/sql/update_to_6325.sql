insert into _schema_revisions (revision) values (6325);

alter table partners add mile_action varchar(1);
update partners set mile_action = 'A';
alter table partners alter column mile_action set not null;
