insert into _schema_revisions (revision) values (3175);

alter table service_classes rename column routes to pairs;
alter table routes rename column route_id to pair_id;
alter table routes rename to pairs;