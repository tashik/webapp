insert into _schema_revisions (revision) values (22365);

ALTER TABLE countries RENAME COLUMN pos_currency_alpha3_code TO coorporate_currency_alpha3_code;
ALTER TABLE countries RENAME COLUMN coorporate_currency_alpha3_code TO corporate_currency_alpha3_code;
ALTER TABLE countries RENAME COLUMN coorporate_station_code TO corporate_station_code;
ALTER TABLE countries RENAME COLUMN coorporate_pcc_code TO corporate_pcc_code;