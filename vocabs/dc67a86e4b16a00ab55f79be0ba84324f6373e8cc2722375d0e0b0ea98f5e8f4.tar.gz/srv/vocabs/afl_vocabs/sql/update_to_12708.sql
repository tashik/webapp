begin;

insert into _schema_revisions (revision) values (12708);

-- Языки
create table languages (
  alpha2_code char(2) not null primary key, -- код языка ISO 3166-1 alpha-2
  alpha3_code char(3) not null,             -- код языка ISO 3166-1 alpha-3
  selector_code char(3) not null,           -- сокращение для переключателя языков
  names varchar(4096) not null,             -- наименование языка
  is_active boolean not null                -- активен
);

commit;
