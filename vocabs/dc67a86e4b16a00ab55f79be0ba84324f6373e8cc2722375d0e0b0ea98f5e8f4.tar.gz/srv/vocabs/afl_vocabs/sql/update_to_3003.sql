insert into _schema_revisions (revision) values (3003);

alter table tier_levels alter column tier_level type varchar(16);
alter table service_classes alter column service_class type varchar(16);

delete from tariff_group_booking_classes;
delete from tariff_groups;

alter table tariff_group_booking_classes drop column tariff_group_id;
alter table tariff_group_booking_classes add column tariff_group varchar(32);

alter table tariff_groups alter column service_class type varchar(16);
alter table tariff_groups alter column code type varchar(32);
alter table tariff_groups rename column code to tariff_group;
alter table tariff_groups drop column tariff_group_id;
alter table tariff_groups add primary key (tariff_group);

alter table tariff_group_booking_classes add constraint tariff_group_booking_classes_tariff_group_fkey foreign key (tariff_group)
    references tariff_groups (tariff_group) match simple
    on update no action on delete cascade deferrable initially immediate;
