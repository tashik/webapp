begin;

insert into _schema_revisions (revision) values (16671);

-- Ограничение времени выбора питания
create table meal_timelimits (
  meal_timelimit_id integer not null primary key,
  origin text,
  special_meal text,
  timelimit integer not null
);

commit;
