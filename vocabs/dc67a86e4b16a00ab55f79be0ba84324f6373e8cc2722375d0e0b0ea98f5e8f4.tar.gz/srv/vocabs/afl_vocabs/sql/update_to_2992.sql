insert into _schema_revisions (revision) values (2992);

alter table member_statuses rename column code TO member_status;