delete from countries;

-- insert into countries (country, iso_code3, names, use_in_siebel) values
-- ('RU', 'RUS', 'ru:Россия|en:Russia', true),
-- ('GB', 'GBR', 'ru:Великобритания|en:Great Britain', true),
-- ('US', 'USA', 'ru:США|en:United States', true);


