insert into _schema_revisions (revision) values (7106);

-- #14122? comment 3
ALTER TABLE tier_levels
    ADD COLUMN miles integer,
    ADD COLUMN segments integer;