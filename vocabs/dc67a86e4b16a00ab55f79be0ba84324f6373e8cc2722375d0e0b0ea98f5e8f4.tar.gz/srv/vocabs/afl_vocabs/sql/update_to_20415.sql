insert into _schema_revisions (revision) values (20415);

ALTER TABLE tariff_groups ADD COLUMN weight integer not null default 0;

