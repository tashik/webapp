begin;

insert into _schema_revisions (revision) values (15407);

update ancillary_services set names ='ru:Билет на Аэроэкспресс|en:Aeroexpress ticket|zh:机场快线车票' where rfic='B' and code='0BQ';

commit;
