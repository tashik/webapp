insert into _schema_revisions (revision) values (22362);

alter table countries add column coorporate_station_code varchar(20) default '00000000';

update countries set coorporate_station_code = '92490716' where pos_currency_alpha3_code = 'RUB' and coorporate_pcc_code = 'DXT';
update countries set coorporate_station_code = '38-495251', station_code = '00000000' where pos_currency_alpha3_code = 'EUR' and coorporate_pcc_code = 'UDN';
update countries set coorporate_station_code = '33-995430', station_code = '00000000' where pos_currency_alpha3_code = 'USD' and coorporate_pcc_code = 'DSV';
update countries set coorporate_station_code = '31-492160', station_code = '00000000' where pos_currency_alpha3_code = 'HUF' and coorporate_pcc_code = 'MCQ';
update countries set coorporate_station_code = '63-492922', station_code = '00000000' where pos_currency_alpha3_code = 'PLN' and coorporate_pcc_code = 'OSP';
update countries set coorporate_station_code = '14-092956', station_code = '00000000' where pos_currency_alpha3_code = 'INR' and coorporate_pcc_code = 'AKD';
update countries set coorporate_station_code = '15-492304', station_code = '00000000' where pos_currency_alpha3_code = 'CZK' and coorporate_pcc_code = 'ZBE';
update countries set coorporate_station_code = '17-494960', station_code = '00000000' where pos_currency_alpha3_code = 'DKK' and coorporate_pcc_code = 'CNL';
update countries set coorporate_station_code = '60-495433', station_code = '00000000' where pos_currency_alpha3_code = 'NOK' and coorporate_pcc_code = 'GLL';
update countries set coorporate_station_code = '80-496931', station_code = '00000000' where pos_currency_alpha3_code = 'SEK' and coorporate_pcc_code = 'EKT';
update countries set coorporate_station_code = '88-494280', station_code = '00000000' where pos_currency_alpha3_code = 'TRY' and coorporate_pcc_code = 'BTZ';
update countries set coorporate_station_code = '61-390652', station_code = '00000000' where pos_currency_alpha3_code = 'AZN' and coorporate_pcc_code = 'KVD';
update countries set coorporate_station_code = '66-390240', station_code = '00000000' where pos_currency_alpha3_code = 'KGS' and coorporate_pcc_code = 'ZME';
update countries set coorporate_station_code = '69-492124', station_code = '00000000' where pos_currency_alpha3_code = 'RON' and coorporate_pcc_code = 'SVA';
update countries set coorporate_station_code = '60-390573', station_code = '00000000' where pos_currency_alpha3_code = 'AMD' and coorporate_pcc_code = 'LWN';
update countries set coorporate_station_code = '09-492943', station_code = '00000000' where pos_currency_alpha3_code = 'BGN' and coorporate_pcc_code = 'GOZ';
update countries set coorporate_station_code = '17-396094', station_code = '00000000' where pos_currency_alpha3_code = 'KRW' and coorporate_pcc_code = 'YNY';
update countries set coorporate_station_code = '72-392633', station_code = '00000000' where pos_currency_alpha3_code = 'UAH' and coorporate_pcc_code = 'UCK';
update countries set coorporate_station_code = '81-496741', station_code = '00000000' where pos_currency_alpha3_code = 'CHF' and coorporate_pcc_code = 'ACH';
update countries set coorporate_station_code = '91-403351', station_code = '00000000' where pos_currency_alpha3_code = 'GBP' and coorporate_pcc_code = 'BOL';
update countries set coorporate_station_code = '08-387385', station_code = '00000000' where pos_currency_alpha3_code = 'CNY' and coorporate_pcc_code = 'IQM';
update countries set coorporate_station_code = '16-399670', station_code = '00000000' where pos_currency_alpha3_code = 'JPY' and coorporate_pcc_code = 'DNA';
update countries set coorporate_station_code = '62-990605', station_code = '00000000' where pos_currency_alpha3_code = 'CAD' and coorporate_pcc_code = 'PIW';

update countries set pos_currency_alpha3_code = 'KGS', use_in_pos = True, coorporate_pcc_code = 'ZME', pcc_code = 'ZME', coorporate_station_code = '66-390240', station_code = '66-390240' where country = 'KG';
update countries set pos_currency_alpha3_code = 'AZN', use_in_pos = True, coorporate_pcc_code = 'KVD', pcc_code = 'KVD', coorporate_station_code = '61-390652', station_code = '61-390652' where country = 'AZ';
update countries set pos_currency_alpha3_code = 'AMD', use_in_pos = True, coorporate_pcc_code = 'LWN', pcc_code = 'LWN', coorporate_station_code = '60-390573', station_code = '60-390573' where country = 'AM';
update countries set pos_currency_alpha3_code = 'UAH', use_in_pos = True, coorporate_pcc_code = 'UCK', pcc_code = 'UCK', coorporate_station_code = '72-392633', station_code = '72-392633' where country = 'UA';

update countries set use_in_pos = True, coorporate_pcc_code = 'DVA', coorporate_station_code = '69-492124', station_code = '00000000' where country = 'RO';
update countries set use_in_pos = True, coorporate_pcc_code = 'BTZ', coorporate_station_code = '88-494280', station_code = '00000000' where country = 'TR';

