-- https://trac.com.spb.ru/afl_lk_crm/ticket/423

DO $$
DECLARE
    num_rows numeric;
    v VARCHAR[] := ARRAY[
        'AAAA',
        'ARAP',
        'ACAE',
        'SVAL',
        'NHAM',
        'OZBC',
        'AMCP',
        'MECM',
        'USDM',
        'AEDY',
        'FMEM',
        'MUEM',
        'MFEC',
        'SKEU',
        'BAEX',
        'AYFP',
        'FBFM',
        'UXFB',
        'KQFB',
        'ROFB',
        'AFFB',
        'KLFB',
        'VNFR',
        'QFFF',
        'GAGM',
        'IBIP',
        'JLMB',
        'ASMP',
        'UAMI',
        'COMI',
        'LHMM',
        'OSMM',
        'LXMM',
        'LOMM',
        'TKMS',
        'AZMG',
        'LSMJ',
        'OKOP',
        'CAPM',
        'BTPI',
        'TGRO',
        'S7SP',
        'DLSM',
        'CZSC',
        'KESK',
        'UNTP',
        'JPPC',
        'EIGC',
        'NZAI',
        'CXAS',
        'BRIM',
        'MHER',
        'NWWP',
        'PRMA',
        'SQKF',
        'WNRR',
        'RGSI',
        'VSFC'
    ];
    x VARCHAR;
    airline VARCHAR;
    loyalty VARCHAR;
BEGIN
    FOREACH x IN ARRAY v
    LOOP
        airline := LEFT(x, 2);
        loyalty := RIGHT(x, 2);

        UPDATE airlines SET loyalty_program_id = (
           SELECT loyalty_program_id FROM loyalty_programs WHERE siebel_id = loyalty
        ) WHERE iata = airline;
        GET DIAGNOSTICS num_rows = ROW_COUNT;
        RAISE INFO 'Insert % rows (air %, lpro %)', num_rows, airline, loyalty;
    END LOOP;
    
    UPDATE airlines SET loyalty_program_id = NULL WHERE iata = 'LO';
END;
$$;