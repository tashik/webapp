begin;

insert into _schema_revisions (revision) values (12862);

alter table loyalty_programs add siebel_id varchar(4);
alter table loyalty_programs add constraint loyalty_programs_siebel_id_key unique (siebel_id);

commit;
