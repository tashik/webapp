DROP TABLE zone;

CREATE TABLE redemption_zone(
  zone_code_id integer not null primary key,
  zone_code varchar (2) not null,  -- код бонусной зоны
  zone_name varchar (50) not null  -- наименование бонусной зоны
);