BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (9528);

-- Добавление колонки "Вес" в модель "Партнёр-неавиакомпания".
ALTER TABLE partners ADD COLUMN weight INTEGER;
UPDATE partners SET weight=0;
ALTER TABLE partners ALTER COLUMN weight SET NOT NULL;

COMMIT;
