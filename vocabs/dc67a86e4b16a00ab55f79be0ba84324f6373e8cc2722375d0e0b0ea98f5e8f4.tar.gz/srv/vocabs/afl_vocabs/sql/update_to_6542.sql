insert into _schema_revisions (revision) values (6542);

-- Премиальный маршрут
create table premium_routes (
  premium_route_id  int not null primary key,
  code              varchar(6) not null,
  zone_from         varchar(2) references redemption_zones(redemption_zone) deferrable,
  zone_via          varchar(2) references redemption_zones(redemption_zone) deferrable,
  zone_to           varchar(2) references redemption_zones(redemption_zone) deferrable,
  carrier           varchar(1) not null default 'A'
);

-- удаление таблицы Премий
DROP TABLE awards;