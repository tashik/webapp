begin;
insert into _schema_revisions (revision) values (7373);

update partners set partner_description=replace(partner_description, E'\r', '');

commit;
