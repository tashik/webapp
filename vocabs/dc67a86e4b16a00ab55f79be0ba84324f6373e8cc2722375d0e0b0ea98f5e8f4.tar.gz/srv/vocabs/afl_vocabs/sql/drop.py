# -*- coding: utf-8 -*-

"""
$Id: $
"""

import sys
import os.path
import re

def generate_drops(create_sql):
    drops = []

    lines = []
    for line in create_sql.split('\n'):
        line = line.strip()
        if not line.startswith('-- '):
            lines.append(line)

    for stmt in '\n'.join(lines).split(';'):
        stmt = stmt.replace(' unique ', ' ')
        m = re.search(r'create (\w+ \w+)', stmt, re.M|re.I)
        if m:
            drops.append('drop %s' % m.group(1))
    
    drops.reverse()
    return drops

def usage():
    print 'usage: drop.py {--print|--execute}'
    sys.exit(1)

def main():
    if len(sys.argv) != 2:
        usage()
        
    mypath = os.path.split(__file__)[0] or '.'
    create_sql = open(mypath + '/create.sql').read()
    drops = generate_drops(create_sql)
    
    if sys.argv[1] == '--print':
        for stmt in drops:
            print '%s;' % stmt
    
    elif sys.argv[1] == '--execute':
        from pyramid.ormlite import dbop, dbquery
        from pyramid.app import initializer as _initializer
        _initializer.initDBConnection()
        for stmt in drops:
            try:
                dbquery(stmt)
                dbop.commit()
            except dbop.dbapi.DatabaseError, e:
                print 'Error while executing statement: %s' % stmt
                print e
                print
                dbop.rollback()

    else:
        usage()

        
if __name__ == '__main__':
    main()
