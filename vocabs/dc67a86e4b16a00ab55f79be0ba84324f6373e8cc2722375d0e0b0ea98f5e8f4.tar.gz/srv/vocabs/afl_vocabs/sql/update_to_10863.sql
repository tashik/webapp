BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (10863);

ALTER TABLE partners ADD COLUMN new_until DATE DEFAULT NULL;

COMMIT;
