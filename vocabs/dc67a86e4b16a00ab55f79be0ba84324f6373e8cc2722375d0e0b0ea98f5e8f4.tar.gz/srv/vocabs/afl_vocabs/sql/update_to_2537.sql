begin;
insert into _schema_revisions (revision) values (2537);

alter table cities add column lat decimal(7,4);
alter table cities add column lon decimal(7,4);
alter table cities add column can_book boolean default true;

alter table airlines add column alliance varchar(16);

commit;
