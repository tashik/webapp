import sys
sys.setdefaultencoding('utf-8')

import os.path
import mimetypes
if mimetypes._winreg:
    mimetypes.init([os.path.dirname(__file__) + '/mime.types'])
    mimetypes.init = str

# Patch for CheryPy bug #1016: WindowsError [Error 6] The handle is invalid in HTTPServer.bind
# https://bitbucket.org/cherrypy/cherrypy/issue/1016/windowserror-error-6-the-handle-is-invalid
try:
    import fcntl
except ImportError:
    try:
        from ctypes import windll, WinError
        import ctypes.wintypes
        _SetHandleInformation = windll.kernel32.SetHandleInformation
        _SetHandleInformation.argtypes = [
            ctypes.wintypes.HANDLE,
            ctypes.wintypes.DWORD,
            ctypes.wintypes.DWORD,
        ]
        _SetHandleInformation.restype = ctypes.wintypes.BOOL
    except ImportError:
        pass
    else:
        def prevent_socket_inheritance(sock):
            """Mark the given socket fd as non-inheritable (Windows)."""
            if not _SetHandleInformation(sock.fileno(), 1, 0):
                raise WinError()
        from cherrypy import wsgiserver
        wsgiserver.prevent_socket_inheritance = prevent_socket_inheritance
