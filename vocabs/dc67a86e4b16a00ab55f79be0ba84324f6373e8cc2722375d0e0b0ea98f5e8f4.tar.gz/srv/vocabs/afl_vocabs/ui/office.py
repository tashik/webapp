# -*- coding: utf-8 -*-

"""
$Id: office.py 24145 2017-03-31 15:46:37Z yumerkulov $
"""

from pyramid.ui.utils import resolveRoute
from pyramid.vocabulary import getV

from django import forms
from django.forms import formsets
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS

import ui.edit
import ui.widgets
from ui import notice
from models.office import Office, OfficeCategory, OfficeTravelOption
from models.indexer import getI


class TravelOptionForm(forms.Form):
    office_travel_option_id = forms.IntegerField(required=False, widget=forms.HiddenInput)
    travel_type = ui.widgets.VocabReferenceField(label=u'Тип', vocab_name='office_travel_option_types', required=True)
    office_travel_option_description = ui.widgets.MLTextField(label=u'Описание', required=False)
    travel_time = forms.IntegerField(label=u'Время пути (мин.)', required=False)


class TravelOptionFormset(formsets.BaseFormSet):
    form = TravelOptionForm
    extra = 1
    can_order = False
    can_delete = True
    max_num = None


class OfficePage(ui.edit.ObjectEditPage):
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['office_vocabs_admin']
    sectionTitle = u'Офисы'
    ob_name = 'office'
    ob_class = Office
    vocab_name = 'offices'
    edit_tpl = '/office/edit.html'
    sort_attrs = ['office_weight', 'title', 'address']
    search_attrs = ['names']
    match_attrs = [('city_id', u'Выберите город', lambda of: of.office_category.city, lambda ci: (ci.city_id, unicode(ci.title)))]
    exclude_fields = ['office_id']
    ws_key_fields = ['office_id', 'travel_options']
    list_exclude_fields =  ['email', 'fax', 'phone', 'lat', 'lon', 'in_airport',
                            'distance_to_airport', 'insurance_policy',
                            'noncash_booking', 'new_office', 'location_map',
                            'transfer_time_public', 'transfer_time_automobile',
                            'transfer_time_foot', 'important_info',
                            'travel_options']

    def _edit(self, ob, params, action='edit'):
        assert action in ('new', 'edit')
        msg = ''
        form_has_error = False
        redirect_on_save = None

        if 'submit0' in params:
            form = self.edit_form_factory(params)
            travel_formset = TravelOptionFormset(params)
            old_obj = None

            if form.is_valid() and travel_formset.is_valid():
                pkey = {}

                if ob is None:
                    if len(self.pkey_fields) == 1 and self.pkey_fields[0][0] not in form.fields:  # объект имеет "синтетический" первичный ключ
                        identifier = self.ob_class.getNewId()
                        pkey[self.pkey_fields[0][0]] = identifier
                    else:
                        pkey = self._pkey_from_params(form.cleaned_data)
                    redirect_on_save = resolveRoute(self.edit_ob_route, **pkey)

                    ob = self.ob_class(**pkey)
                    getV(self.vocab_name).add(ob)
                else:
                    old_obj = ob.copy()
                self._form_to_ob(form, ob, action)
                ob.save()

                for travel_form in travel_formset.forms:
                    if not travel_form.is_valid():
                        continue

                    t_data = travel_form.cleaned_data
                    if not t_data:
                        continue

                    office_travel_option_id = t_data.get('office_travel_option_id')
                    if office_travel_option_id:
                        t = getV('office_travel_options')[office_travel_option_id]
                    else:
                        t = OfficeTravelOption(office_travel_option_id=OfficeTravelOption.getNewId(),
                                               office_id=ob.office_id)
                    t.travel_type = t_data['travel_type']
                    t.office_travel_option_description = t_data['office_travel_option_description']
                    t.travel_time = t_data['travel_time']
                    t.save()

                    getV('office_travel_options').add(t)

                for deleted_form in travel_formset.deleted_forms:
                    if not deleted_form.is_valid():
                        continue

                    office_travel_option_id = deleted_form.cleaned_data['office_travel_option_id']
                    del getV('office_travel_options')[office_travel_option_id]

                self._notify(ob, action)
                self._compare_and_log_objects(old_obj, ob, 'office_id')
                self._on_after_save(ob, action)

                if redirect_on_save:
                    return self.redirect(redirect_on_save)
                notice(u'Данные сохранены')
            else:
                form_has_error = True
        initial, readonly = self._populate_initial(ob, action)

        t_initial = {}
        if ob:
            t_vocab = getV('office_travel_options')
            travels = [t_vocab[t_id] for t_id in sorted(getI('travel_option_by_office_idx')(ob.office_id))]
            t_initial = [dict(office_travel_option_id=t.office_travel_option_id,
                              travel_type=t.travel_type,
                              office_travel_option_description=t.office_travel_option_description,
                              travel_time=t.travel_time)
                         for t in travels]

        if not form_has_error:
            form = self.edit_form_factory(initial=initial)
            travel_formset = TravelOptionFormset(initial=t_initial)

        for name in readonly:
            if name in form.fields:
                form[name].field.widget.attrs['readonly'] = 'readonly'

        content = ui.template.renderTemplate(self.edit_tpl, form=form, page=self, ob=ob,
                                             action=action, travel_formset=travel_formset)
        return self.render(content)


class OfficeCategoryForm(forms.Form):
    names = ui.widgets.MLNamesField(label=u'Название категории офисов продаж', required=True)
    city = ui.widgets.VocabReferenceField(vocab_name='cities', label=u'Город', required=True)
    office_category_description = ui.widgets.MLTextField(label=u'Описание', required=False)


class OfficeCategoryPage(ui.edit.ObjectEditPage):
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['office_vocabs_admin']
    sectionTitle = u'Категории офисов продаж'
    ob_name = 'office_category'
    ob_class = OfficeCategory
    vocab_name = 'office_categories'
    list_exclude_fields = ['office_category_description']
    exclude_fields = ['office_category_id']
    edit_form_factory = OfficeCategoryForm
    ws_key_fields = ['office_category_id']
    search_attrs = ['names', 'office_category_description']
