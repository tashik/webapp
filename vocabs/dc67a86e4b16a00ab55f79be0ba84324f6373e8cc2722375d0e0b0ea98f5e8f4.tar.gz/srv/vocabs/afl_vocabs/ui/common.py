# -*- coding: utf-8 -*-

"""
$Id: $
"""
import cherrypy
import time
from django.utils.html import conditional_escape

from pyramid.app.page import AuthorizablePage
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS
import ui.template

from pyramid.ui.error import ErrorHandler
import rx.sso.error_handling
import rx.sso.url

def info_msg(msg):
    return u'<div class="information"><ul><li>%s</li></ul></div>' % conditional_escape(msg)

def error_msg(msg):
    return u'<div class="error message">%s</div>' % conditional_escape(msg)

def get_current_lang():
    return 'ru'

#    from zope.i18n.interfaces import INegotiator, ILanguageAvailability
#    from zope.component import queryUtility, getUtility
#
#    negotiator = queryUtility(INegotiator)
#    if negotiator is not None:
#        available = 'ru', 'en'
#        lang = negotiator.getLanguage(available, None)
#        if lang:
#            return lang
#    return 'ru'


class AppPage(rx.sso.error_handling.ErrorHandling, AuthorizablePage):
    """ Веб-страница """

    def __init__(self, *args, **kw):
        super(AppPage, self).__init__(*args, **kw)
        self.errorHandler = ErrorHandler(self)
        self._cp_config['request.error_response'] = self.errorHandler.index
        self._allow_roles.extend(AppPage._joker_roles)
    
    _menus = 'main_menu'
    _template = '/layout.html'
    _authObject = 'general'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS
    _joker_roles = ['vocabs_admin']  # роли, допустимые для всез страниц приложения
    active_menu_item = None
    is_mobile_page = False

    # параметр _loginUrl используется в обработчике ошибок для редиректа на страницу логина
    # мы вынуждены динамически вычислять loginUrl из-за необходимости добавлять return_url

    _loginUrl = property(rx.sso.url.get_login_url, lambda self, v: None)

    def render(self, content, **params):
        menu = ui.template.renderTemplate('/vocabs_menu.html')

        x_params = dict(
            page_title=u' | '.join([ unicode(s) for s in (self.title, self.sectionTitle) if s ]),
            section_title=self.sectionTitle is None and self.title or self.sectionTitle,
            user_role=None,
            user_display_name=cherrypy.session.get('user_display_name', ''),
            new_messages='',
            content=content,
            active_menu_item=self.active_menu_item,
            show_breadcrumbs=True,
            menus=[menu],
            current_year=time.localtime()[0],

            user=None,
            user_permissions=[],
            member_tier_level=None,
            member_sabre_id=None,
            member_miles=None,
            member_current_year_miles=None,
            member_current_year_segments=None,

            turned_off_menu=True,
            hide_main_menu=True
        )
        x_params.update(params)

        return ui.template.renderTemplate(self._template, **x_params)
