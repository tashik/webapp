# -*- coding: utf-8 -*-

"""
$Id: $
"""

from django import forms
import zope.schema.interfaces as zsi
from zope.interface import Interface
from zope.component import provideAdapter, getAdapter
from zope.schema.interfaces import IFromUnicode, ITokenizedTerm
from pyramid.vocabulary import getV
from pyramid.ormlite.schema.interfaces import IORMField
from models.partner import PartnerOfficeContact
from rx.utils.json import as_primitive
import json

from models.uppercase import IUppercaseTextLine 
from models.interfaces import IAirportTerminalField, IOfficeTravelOptionField
from models.airport import AirportTerminal
import ui.widgets
import models.base
import models.ml 
import models.tzname
import models.vocablist
from models.vocablist import VocabList
from models.interfaces import IPartnerOfficeContactField
from models.office import OfficeTravelOption


class IDjangoFormsField(Interface):
    "Django Forms field"


class ICSVValueConverter(Interface):
    def to_csv(python_value):
        "Convert a python to a suitable CSV representation"

    def from_csv(form_value):
        "Convert a unicode CSV value to a python object"


def init_field(form_field_cls, schema_field, **extra):
    kw = dict(required = schema_field.required,
              label = schema_field.title or schema_field.getName())
    if zsi.IMinMaxLen.providedBy(schema_field):
        if schema_field.min_length:
            kw['min_length'] = schema_field.min_length
        if schema_field.max_length is not None:
            kw['max_length'] = schema_field.max_length

    if models.ml.ITextLineList.providedBy(schema_field):
        kw['separator'] = schema_field.separator

    kw.update(extra)
    return form_field_cls(**kw)


class DefaultValueConverter(object):
    def __init__(self, field):
        self.field = field
    
    def to_csv(self, python_value):
        if zsi.IChoice.providedBy(self.field):
            if python_value == self.field.missing_value:
                if self.field.required:
                    raise zsi.RequiredMissing(self.field.getName())
                return ''
            return ITokenizedTerm(python_value).token
        if zsi.ISequence.providedBy(self.field):
            parts = []
            for elem in python_value:
                if self.field.value_type:
                    bf = self.field.value_type.bind(python_value)
                    value_converter = getAdapter(bf, ICSVValueConverter)
                    part = value_converter.to_csv(elem)
                    parts.append(part)
                else:
                    parts.append(unicode(elem))
            separator = '|'
            if models.ml.ITextLineList.providedBy(self.field):
                separator = self.field.separator
            return separator.join(parts)
        if IORMField.providedBy(self.field):
            return self.field.toUnicode(python_value)
        if zsi.IObject.providedBy(self.field):
            d = as_primitive(python_value)
            if 'class' in d:
                del d['class']
            return json.dumps(d)  # encoding=?
        if python_value == self.field.missing_value:
            return ''
        return unicode(python_value)

    def from_csv(self, csv_value):
        csv_value = csv_value.strip()
        if csv_value == '':
            if self.field.required:
                raise zsi.RequiredMissing(self.field.getName())
            #return self.field.missing_value
            #if IORMField.providedBy(self.field):
            #    return self.field.null()
            if IORMField.providedBy(self.field):
                if getattr(self.field, '_emptyStringToNone', True):
                    return self.field.null()
                return csv_value
            return None
        if zsi.IChoice.providedBy(self.field):
            vocab = getV(self.field.vocabularyName)
            return vocab[csv_value]

        if zsi.ISequence.providedBy(self.field):
            separator = '|'
            if models.ml.ITextLineList.providedBy(self.field):
                separator = self.field.separator
            parts = []
            for elem in csv_value.split(separator):
                if self.field.value_type:
                    field = self.field.value_type
                    value_converter = getAdapter(field, ICSVValueConverter)
                    v = value_converter.from_csv(elem)
                    #print field.getName(), repr(field), repr(value_converter), repr(v)
                    field.validate(v)
                    parts.append(v)
                else:
                    parts.append(elem)
            return parts
        if IFromUnicode.providedBy(self.field):
            return self.field.fromUnicode(csv_value)
        return csv_value


class AirportTerminalConverter(object):
    def __init__(self, field):
        self.field = field

    def to_csv(self, t):
        return '%s$%s$%s' % (t.terminal_id, t.code, '|'.join(t.names))

    def from_csv(self, csv_value):
        csv_value = csv_value.strip()
        terminal_id, code, names = csv_value.split('$', 2)
        names = names.split('|')
        if not terminal_id:
            terminal_id = AirportTerminal.getNewId()
        else:
            terminal_id = int(terminal_id)
        t = AirportTerminal(terminal_id=terminal_id,
                            airport_id=self.field.context.airport_id,
                            code=code,
                            names=names)
        return t


class VocabClassConverter(object):
    def __init__(self, field):
        self.field = field

    def to_csv(self, bc):
        return self.field.toDbType(bc or [])

    def from_csv(self, csv_value):
        return self.field.fromDbType(csv_value)


class OfficeTravelOptionClassConverter(object):
    def __init__(self, field):
        self.field = field

    def to_csv(self, t):
        return '%s$%s$%s$%s' % (t.office_travel_option_id,
                                ITokenizedTerm(t.travel_type).token,
                                t.travel_time,
                                '^'.join(t.office_travel_option_description))

    def from_csv(self, csv_value):
        csv_value = csv_value.strip()
        id, type, time, desc = csv_value.split('$', 3)
        desc = desc.split('^')
        if not id:
            id = OfficeTravelOption.getNewId()
        else:
            id = int(id)

        try:
            travel_time = int(time)
        except ValueError:
            travel_time = None

        travel_type = getV('office_travel_option_types')[type]
        t = OfficeTravelOption(office_travel_option_id=id,
                               office_id=self.field.context.office_id,
                               travel_type=travel_type,
                               office_travel_option_description=desc,
                               travel_time=travel_time)
        return t


class PartnerOfficeContactClassConverter(object):
    def __init__(self, field):
        self.field = field

    def decode_partner_office_contact(self, json_ob):
        contact_type = getV('partner_office_contact_types')[json_ob['contact_type']]
        return PartnerOfficeContact(partner_office_contact_id=json_ob['partner_office_contact_id'],
                                    partner_office=json_ob['partner_office'],
                                    contact_type=contact_type,
                                    contact=json_ob['contact'],
                                    main_contact=json_ob['main_contact'])

    def to_csv(self, bc):
       return json.dumps(as_primitive(bc))

    def from_csv(self, csv_value):
        json_obs = json.loads(csv_value)
        res = []
        for json_ob in json_obs:
            res.append(self.decode_partner_office_contact(json_ob))
        return res

def register_adapters():
    provideAdapter(lambda field: init_field(forms.CharField, field),
                   [zsi.Interface], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.BooleanField, field),
                   [zsi.IBool], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.IntegerField, field),
                   [zsi.IInt], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.FloatField, field),
                   [zsi.IFloat], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.CharField, field),
                   [zsi.ITextLine], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.CharField, field, widget=ui.widgets.UppercaseTextInput()),
                   [IUppercaseTextLine], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.CharField, field, widget=forms.Textarea(attrs={'cols': '80', 'rows': '6', 'wrap': 'off'})),
                   [zsi.IList], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.LineListField, field),
                   [models.ml.ITextLineList], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.StringListField, field),
                   [models.ml.IStringLineList], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.MLNamesField, field),
                   [models.ml.IMLNames], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.MLTextField, field),
                   [models.ml.IMLText], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.VocabReferenceField, field, vocab_name=field.vocabularyName),
                   [zsi.IChoice], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.VocabReferenceMultiField, field, vocab_name=field.vocabularyName),
                   [models.vocablist.IVocabList], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.ChoiceField, field,
                                            choices=[ ('', '') ] + [ (name, name) for name, country in models.tzname.zoneinfo_names ]),
                   [models.tzname.ITZName], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.NullableTextField, field, widget=ui.widgets.UppercaseTextInput()),
                   [models.uppercase.ICodeTextLine], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.DateField, field, widget=forms.TextInput(attrs={'class': 'date-select'})),
                   [zsi.IDate], IDjangoFormsField)
    provideAdapter(lambda field: init_field(forms.DateTimeField, field, widget=forms.DateTimeInput(attrs={'class': 'datetime-select'})),
                   [zsi.IDatetime], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.JSONCondition, field), [models.base.IJSONConditionField], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.LoyaltyCondition, field), [models.base.ILoyaltyField], IDjangoFormsField)
    provideAdapter(lambda field: init_field(ui.widgets.NumbersList, field, help_text=u'Список чисел и числовых интервалов. Например: 1,2,3,7-10'), [models.base.INumbersListField], IDjangoFormsField)

    provideAdapter(DefaultValueConverter, [zsi.Interface], ICSVValueConverter)
    provideAdapter(AirportTerminalConverter, [IAirportTerminalField], ICSVValueConverter)
    provideAdapter(VocabClassConverter, [models.vocablist.IVocabList], ICSVValueConverter)
    provideAdapter(OfficeTravelOptionClassConverter, [IOfficeTravelOptionField], ICSVValueConverter)
    provideAdapter(PartnerOfficeContactClassConverter, [IPartnerOfficeContactField], ICSVValueConverter)
