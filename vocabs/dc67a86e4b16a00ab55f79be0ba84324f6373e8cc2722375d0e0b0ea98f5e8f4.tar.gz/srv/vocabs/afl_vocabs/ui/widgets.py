# -*- coding: utf-8 -*-

"""
$Id: $
"""
import json
import re
from zope.schema.interfaces import ITitledTokenizedTerm
from pyramid.vocabulary import getV, getVI

from django.forms.util import flatatt

from django.utils.safestring import mark_safe
from django.forms.fields import Field, validators, ValidationError
from django.utils.translation import ugettext_lazy as _d

import rx.forms.djforms as forms
__ = unicode

LOYALTY_ID_REGEXP = re.compile(r'^\s*[0-9]+[0-9 ]*$')
WRONG_LINE_VALUE = re.compile('^\S{2}:$')


class UppercaseTextInput(forms.TextInput):
    def __init__(self, attrs=None):
        _attrs = {'class': 'uppercase'}
        if attrs is not None:
            _attrs.update(attrs)
        super(UppercaseTextInput, self).__init__(_attrs)

    def value_from_datadict(self, data, files, name):
        try:
            return data[name].upper()
        except KeyError:
            return None


class VocabTokenInput(forms.Select):
    def __init__(self, attrs=None, vocab_name=None, filter_fnc=None, item_fnc=None):
        if attrs is not None:
            self.attrs = attrs.copy()
        else:
            self.attrs = {}
        self.vocab_name = vocab_name
        self.filter_fnc = filter_fnc
        self.item_fnc = item_fnc

    @property
    def choices(self):
        vocab = getV(self.vocab_name)
        items = [('', '')]
        for elem in vocab:
            if self.filter_fnc is None or self.filter_fnc(elem):
                if self.item_fnc:
                    items.append(self.item_fnc(elem))
                else:
                    term = ITitledTokenizedTerm(elem)
                    items.append((term.token, unicode(term.title)))
        return sorted(items, key=lambda e: unicode(e[1]))

    def value_from_datadict(self, data, files, name):
        value = data.get(name, None)
        if value == '':
            return None
        return value


class VocabTextInput(forms.TextInput):
    isForChoiceField = False

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if value == '':
            return None
        return value


class VocabInput(VocabTokenInput):
    isForChoiceField = True

    def render(self, name, ob, attrs=None, choices=()):
        from zope.schema.interfaces import ITokenizedTerm
        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select%s>' % flatatt(final_attrs)]
        if ob is not None:
            try:
                selected = [ITokenizedTerm(ob).token]
            except TypeError:
                selected = [
                    ITokenizedTerm(
                        getV(self.vocab_name)[ob]
                    ).token
                ]
        else:
            selected = []
        options = self.render_options(choices, selected)
        if options:
            output.append(options)
        output.append(u'</select>')
        return mark_safe(u'\n'.join(output))

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if value == '':
            return None
        if not self.isForChoiceField:
            return value
        if isinstance(value, basestring):
            value = getV(self.vocab_name)[value]
        return value


class VocabReferenceField(Field):
    widget = VocabInput
    default_error_messages = {
        'invalid_choice': _d(u'Select a valid choice. %(value)s is not one of the available choices.'),
    }

    def __init__(self, vocab_name='', required=True, widget=None, label=None,
                 initial=None, help_text=None, is_for_choice_field=True, *args, **kwargs):
        super(VocabReferenceField, self).__init__(required=required, widget=widget, label=label,
                                                  initial=initial, help_text=help_text, *args, **kwargs)
        self.vocab_name = vocab_name
        self.widget.isForChoiceField = is_for_choice_field

    def _get_vocab_name(self):
        return self._vocab_name

    def _set_vocab_name(self, vocab_name):
        # Setting vocab_name also sets the vocab_name on the widget.
        self._vocab_name = self.widget.vocab_name = vocab_name

    vocab_name = property(_get_vocab_name, _set_vocab_name)

    def to_python(self, value):
        "Returns an object from the vocab"
        if value in validators.EMPTY_VALUES:
            return None
        return value

    def validate(self, value):
        """
        Validates that the input is in the vocab.
        """
        super(VocabReferenceField, self).validate(value)
        if value and not self.valid_value(value):
            raise ValidationError(self.error_messages['invalid_choice'] % {'value': value})

    def valid_value(self, value):
        "Check to see if the provided value is a valid choice"
        try:
            if self.widget.isForChoiceField:
                getV(self.vocab_name).getTerm(value)
            else:
                if value not in getV(self.vocab_name):
                    raise LookupError
            return True
        except LookupError:
            return False


class IndexerReferenceField(VocabReferenceField):
    def __init__(self, indexer_name='', vocab_name='', *args, **kwargs):
        if not vocab_name:
            vocab_name = getVI(indexer_name).vocabulary
        super(IndexerReferenceField, self).__init__(vocab_name=vocab_name, *args, **kwargs)
        self.indexer_name = indexer_name

    def to_python(self, value):
        if value in validators.EMPTY_VALUES:
            return None
        try:
            value = getVI(self.indexer_name)(context=value)[0]
        except IndexError:
            raise ValidationError(self.error_messages['invalid_choice'] % {'value': value})
        else:
            return value
        return None


class VocabMultiSelect(VocabInput):

    def render(self, name, ob, attrs=None, choices=()):
        from zope.schema.interfaces import ITokenizedTerm
        final_attrs = self.build_attrs(attrs, name=name)
        output = [u'<select multiple="multiple"%s>' % flatatt(final_attrs)]
        if isinstance(ob, list):
            selected = []
            for item in ob:
                selected.append(ITokenizedTerm(item).token)
        elif ob is not None:
            selected = [ITokenizedTerm(ob).token]
        else:
            selected = []
        options = self.render_options(choices, selected)
        if options:
            output.append(options)
        output.append(u'</select>')
        return mark_safe(u'\n'.join(output))

    def value_from_datadict(self, data, files, name):
        value = data.get(name)
        if value == '':
            return None
        res = []
        if isinstance(value, basestring):
            res.append(getV(self.vocab_name)[value])
        elif isinstance(value, list):
            for item in value:
                  res.append(getV(self.vocab_name)[item])
        return res


class VocabReferenceMultiField(VocabReferenceField):
    widget = VocabMultiSelect

    def validate(self, value):
        """
        Validates that the input is in the vocab.
        """
        super(VocabReferenceField, self).validate(value)
        if isinstance(value, list):
            for item in value:
                if item and not self.valid_value(item):
                    raise ValidationError(self.error_messages['invalid_choice'] % {'value': item})
        else:
            if value and not self.valid_value(value):
                    raise ValidationError(self.error_messages['invalid_choice'] % {'value': value})

#import models.tzname
#
#class TZNameInput(forms.Select):
#    def __init__(self, attrs=None):
#        super(TZNameInput, self).__init__(attrs=attrs)
#        self.choices = [ (name, name) for name, country in models.tzname.zoneinfo_names ]


class StringListInput(forms.TextInput):
    separator = ' '

    def render(self, name, value, attrs=None):
        if value is None:
            value = ''

        value = self.separator.join(value)
        return super(StringListInput, self).render(name, value, attrs)

    def value_from_datadict(self, data, files, name):
        value = data.get(name)

        if value in validators.EMPTY_VALUES:
            return []

        if isinstance(value, basestring):
            return [ line.strip() for line in value.strip().split(self.separator) ]
        return value

    def _has_changed(self, initial, data):
        if data is not None and all([elem in validators.EMPTY_VALUES for elem in data]):
            data = u''
        return super(StringListInput, self)._has_changed(initial, data)


# noinspection PyInterpreter
class LineListInput(forms.Textarea):
    separator = '\n'

#    def __init__(self, attrs=None):
#        default_attrs = {'cols': '100', 'rows': '8'}
#        if attrs:
#            default_attrs.update(attrs)
#        super(LineListInput, self).__init__(default_attrs)

    def render(self, name, value, attrs=None):
        if value is None:
            value = ''

        value = self.separator.join(value)
        return super(LineListInput, self).render(name, value, attrs)

    def value_from_datadict(self, data, files, name):
        value = data.get(name)

        if value in validators.EMPTY_VALUES:
            return []

        if isinstance(value, basestring):
            #return value.split('\n')
            return [ line.strip() for line in value.strip().split(self.separator) ]
        return value

    def _has_changed(self, initial, data):
        if data is not None and all([elem in validators.EMPTY_VALUES for elem in data]):
            data = u''
        return super(LineListInput, self)._has_changed(initial, data)

#class LineListInputNotRequire(LineListInput):
#    default_datadic = (u'', "ru:")
#    default_render = (['ru:'], '')
#
#    def render(self, name, value, attrs=None):
#
#        if value == self.default_render[0]:
#            value = self.default_render[1]
#        return super(LineListInputNotRequire, self).render(name, value, attrs)
#
#    def value_from_datadict(self, data, files, name):
#        value = data.get(name)
#
#        if value == self.default_datadic[0]:
#            data[name] = self.default_datadic[1]
#        return super(LineListInputNotRequire, self).value_from_datadict(data,file,name)


class StringListField(forms.Field):
    default_error_messages = {
        'separator_present': __(u'Символ %s недопустим для использования в названиях'),
    }
    widget = StringListInput

    def __init__(self, separator=' ', max_limit=5, *args, **kwargs):
        super(StringListField, self).__init__(*args, **kwargs)
        self.separator = separator
        self.max_limit = max_limit

    def validate(self, value):
        """
        Validates that the input format is good
        """

        super(StringListField, self).validate(value)

        if value in validators.EMPTY_VALUES:
            value = []

        if all([elem in validators.EMPTY_VALUES for elem in value]) and self.required:
            raise ValidationError(self.error_messages['required'])

        for elem in value:
            if elem in validators.EMPTY_VALUES:
                continue

            if self.separator in elem:
                raise ValidationError(self.error_messages['separator_present'] % self.separator)

    def to_python(self, value):
        value = super(StringListField, self).to_python(value)

        if value in validators.EMPTY_VALUES:
            return None

        if len(value) > self.max_limit:
            value = value[:self.max_limit]

        return value


class LineListField(forms.Field):
    default_error_messages = {
        'separator_present': __(u'Символ %s недопустим для использования в названиях'),
    }
    widget = LineListInput

    def __init__(self, separator=',', *args, **kwargs):
        super(LineListField, self).__init__(*args, **kwargs)
        self.separator = separator

    def validate(self, value):
        """
        Validates that the input format is good
        """

        super(LineListField, self).validate(value)

        if value in validators.EMPTY_VALUES:
            value = []

        if all([elem in validators.EMPTY_VALUES for elem in value]) and self.required:
            raise ValidationError(self.error_messages['required'])

        for elem in value:
            if elem in validators.EMPTY_VALUES:
                continue

            if self.separator in elem:
                raise ValidationError(self.error_messages['separator_present'] % self.separator)


class MLNamesInput(LineListInput):
    def __init__(self, attrs=None):
        if attrs is None:
            attrs = {}
        attrs['data-type'] = 'ml-names'
        super(MLNamesInput, self).__init__(attrs=attrs)


class MLNamesField(LineListField):
    u"""
    Мультиязычное поле, поддерживающее однострочные переводы без форматирования
    """

    default_error_messages = {
        'invalid': __(u'Введите словарь названий в формате код-языка:название. (Например: ru:Москва).'),
    }
    widget = MLNamesInput

    def __init__(self, separator='|', *args, **kwargs):
        super(MLNamesField, self).__init__(*args, **kwargs)
        self.separator = separator

    def validate(self, value):
        """
        Validates that the input format is good
        """

        super(MLNamesField, self).validate(value)

        for elem in value:
            if elem in validators.EMPTY_VALUES:
                continue

            if WRONG_LINE_VALUE.match(elem) and self.required:
                raise ValidationError(self.error_messages['invalid'])

            if len(elem) < 3 or elem[2] != ':':
                raise ValidationError(self.error_messages['invalid'])


class MLTextInput(LineListInput):
    # использование переноса строки в качестве раздилителя опасно, так как
    # перенос строк может встречаться в самом тексте
    separator = '\t'

    def __init__(self, attrs=None):
        if attrs is None:
            attrs = {}
        attrs['data-type'] = 'ml-text'
        super(MLTextInput, self).__init__(attrs=attrs)


class MLTextField(MLNamesField):
    u"""
    Мультиязычное поле, поддерживающее многострочные переводы и форматирование
    """

    widget = MLTextInput


class NullableTextField(forms.CharField):
    def to_python(self, value):
        value = super(NullableTextField, self).to_python(value)

        if value in validators.EMPTY_VALUES:
            return None

        return value


def validate_loyalty_condition(value):
    # Длинна взята из аналогичного поля в ЛК
    if len(value) > 10:
        raise ValidationError(u'Длина номера не должна привышать 10 символов')

    if not LOYALTY_ID_REGEXP.match(value):
        raise ValidationError(u'Неправильный формат ')


def validate_json_condition(value):
    try:
        condition = json.loads(value)
    except (ValueError, TypeError):
        raise ValidationError(u'Неправильный формат JSON')

    if not isinstance(condition, list):
        raise ValidationError(u'Условия должны быть списком')

    for x in condition:
        if not isinstance(x, dict):
            raise ValidationError(u'Условия должны быть списком словарей')


class LoyaltyCondition(forms.CharField):
    widget = forms.TextInput
    default_validators = [validate_loyalty_condition]


class JSONCondition(forms.CharField):

    widget = forms.Textarea
    default_validators = [validate_json_condition]

    def widget_attrs(self, widget):
        default_attrs = {'cols': '80', 'rows': '6', 'wrap': 'off'}
        attrs = super(JSONCondition, self).widget_attrs(widget)
        if attrs is not None:
            default_attrs.update(attrs)
        return default_attrs


def is_valid_numbers_list(value):
    split = value.split(',')
    for number in split:
        interval = number.split('-')
        if len(interval) == 2:
            if interval[0].isdigit() and interval[1].isdigit():
                if int(interval[0]) >= int(interval[1]):
                    return False
            else:
                return False
        elif len(interval) == 1:
            if not number.isdigit():
                return False
        else:
            return False
    return True


def validate_numbers_list(value):
    if not is_valid_numbers_list(value):
        raise ValidationError(u'Неправильный формат')


class NumbersList(forms.CharField):
    default_validators = [validate_numbers_list]
