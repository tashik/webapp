# -*- coding: utf-8 -*-

"""
$Id: geo.py 27929 2017-10-20 11:32:58Z oeremeeva $
"""

import ui.widgets
from django import forms

from models.geo import WorldRegion, Country, City
import ui.edit


class WorldRegionPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Регионы'
    ob_name = 'world_region'
    ob_class = WorldRegion
    vocab_name = 'world_regions'
    exclude_fields = ['world_region_id']


class CountryPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Страны'
    ob_name = 'country'
    ob_class = Country
    vocab_name = 'countries'
    search_attrs = ['iso_code2', 'iso_code3', 'names']
    ws_key_fields = ['iso_code2']
    edit_tpl = '/country/edit.html'

    list_col_attrs = dict(
        iso_code2={'width': '70'},
        iso_code3={'width': '70'},
        world_region={'width': '250'},
        names={'width': '350'},
        capital={'width': '250'},
        _={'width': '120'},
    )
    list_exclude_fields = ['use_in_pos', 'pcc_code', 'station_code',
                           'corporate_station_code', 'corporate_pcc_code',
                           'corporate_currency', 'capital']
    fixed_list_layout = True


class CityPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Города'
    ob_name = 'city'
    ob_class = City
    vocab_name = 'cities'
    exclude_fields = ['city_id']
    sort_attrs = ['iata', 'city_id']
    search_attrs = ['iata', 'names']
    ws_key_fields = ['iata']
    list_exclude_fields = ['alternative_cities']

    list_col_attrs = dict(
        country_code={'width': '70'},
        tz={'width': '100'},
        iata={'width': '70'},
        lat={'width': '60'},
        lon={'width': '60'},
        radius={'width': '60'},
        can_book={'width': '70'},
        names={'width': '350'},
        _={'width': '120'},
    )
    fixed_list_layout = True

    def edit_form_factory(self, *args, **kw):
        form_cls = ui.edit.form_from_iface(self.iface_fields, self.ob_name)
        form_cls.base_fields['country_code'] = forms.CharField(label=u'Страна',
                                                               max_length=2,
                                                               min_length=2,
                                                               required=True,
                                                               widget=ui.widgets.VocabTokenInput(vocab_name='countries'))
        return form_cls(*args, **kw)
