# -*- coding: utf-8 -*-

"""
$Id: $
"""
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS

from ui.edit import ObjectEditPage
from models.charity_funds import CharityFund
from models.interfaces import ICharityFund


class CharityFundPage(ObjectEditPage):
    sectionTitle = u'Благотворительные фонды'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['partner_vocabs_admin']
    ob_name = 'charity_fund'
    ob_class = CharityFund
    ob_iface = ICharityFund
    vocab_name = 'charity_funds'
    ws_key_fields = ['charity_fund_id']
    exclude_fields = ['charity_fund_id', 'create_date', 'modify_date']
    list_exclude_fields = ['logo_url', 'image_url', 'charity_description',
                           'charity_description', 'transfer_conditions',
                           'news_url', 'news_mv_url', 'donate_miles_url',
                           'donate_miles_mv_url', 'stats_charity_funds_url', 'rss_url',
                           'charity_short_description', 'url', 'create_date',
                           'modify_date', 'contacts', 'tag']
