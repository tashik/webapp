# -*- coding: utf-8 -*-
"""
$Id: ancillary_services.py 22376 2016-12-26 14:03:57Z oeremeeva $
"""
from datetime import datetime

from django import forms
from django.forms import DateTimeField, FloatField, DateTimeInput
from django.forms.forms import NON_FIELD_ERRORS
from pyramid.vocabulary import getV
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS

from models.ancillary_services import AncillaryServicesGroup, AncillaryService, RFICCode, AncillaryServiceStatus
from models.ancillary_services import VatRate
from models.interfaces import check_overlapping
from ui.edit import ObjectEditPage
from ui.widgets import NullableTextField, UppercaseTextInput, __


class AncillaryServicesGroupPage(ObjectEditPage):
    sectionTitle = u'Группы дополнительных услуг'
    ob_name = 'ancillary_services_group'
    ob_class = AncillaryServicesGroup
    vocab_name = 'ancillary_services_groups'
    exclude_fields = ['ancillary_services_group_id']
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS +  ['ancillary_services_vocabs_admin']
    sort_attrs = ['ordinal_number']


class RFICCodePage(ObjectEditPage):
    sectionTitle = u'Коды RFIC'
    ob_name = 'rfic_code'
    ob_class = RFICCode
    vocab_name = 'rfic_codes'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['ancillary_services_vocabs_admin']


class VatRatesForm(forms.Form):
    rfic = forms.RegexField(regex='^[A-Z0-9]+$', label=u'RFIC-код', min_length=1, max_length=1, required=True, widget=UppercaseTextInput())
    rfisc = forms.RegexField(regex='^[A-Z0-9]+$', label=u'RFISC-код', min_length=3, max_length=3, required=True, widget=UppercaseTextInput())
    start_date = DateTimeField(label=u'Дата и время начала действия ставки НДС (UTC)', required=False, widget=DateTimeInput(attrs={'class': 'datetime-select'}))
    stop_date = DateTimeField(label=u'Дата и время завершения действия ставки НДС (UTC)', required=False, widget=DateTimeInput(attrs={'class': 'datetime-select'}))
    rate = FloatField(label=u'ставка НДС', min_value=0.0, max_value=100.0, required=True)

    def clean(self):
        super(VatRatesForm, self).clean()
        start_date = self.cleaned_data.get('start_date') or datetime.min
        stop_date = self.cleaned_data.get('stop_date') or datetime.max

        if stop_date <= start_date:
            self.cleaned_data.pop('start_date')
            self.cleaned_data.pop('stop_date')
            raise forms.ValidationError(__(u'Начало ставки НДС должно быть до его конца'))

        for vat_rate in getV('vat_rates'):
            if (self.cleaned_data.get('rfic'), self.cleaned_data.get('rfisc')) == (vat_rate.rfic, vat_rate.rfisc):
                if 'vat_rate_id' in self.data and int(self.data['vat_rate_id']) == vat_rate.vat_rate_id:  # меняется существующиая запись
                    continue

                other_start_date = vat_rate.start_date
                other_stop_date = vat_rate.stop_date

                if check_overlapping(start_date, stop_date, other_start_date, other_stop_date):
                    self.cleaned_data.pop('start_date')
                    self.cleaned_data.pop('stop_date')

                    raise forms.ValidationError(
                        __(u'Время действия данной ставки НДС пересекается с временем действия аналогичной ставки: {} - {}'
                           .format(other_start_date or u'открытая дата', other_stop_date or u'открытая дата')))

        return self.cleaned_data


class VatRatesPage(ObjectEditPage):
    sectionTitle = u'Ставки НДС'
    edit_form_factory = VatRatesForm
    ob_name = 'vat_rate'
    ob_class = VatRate
    vocab_name = 'vat_rates'
    exclude_fields = ['vat_rate_id']
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['ancillary_services_vocabs_admin']


class AncillaryServicePage(ObjectEditPage):
    sectionTitle = u'Дополнительные услуги'
    ob_name = 'ancillary_service'
    ob_class = AncillaryService
    vocab_name = 'ancillary_services'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['ancillary_services_vocabs_admin']


class AncillaryServiceStatusPage(ObjectEditPage):
    sectionTitle = u'Статусы дополнительных услуг'
    ob_name = 'ancillary_service_status'
    ob_class = AncillaryServiceStatus
    vocab_name = 'ancillary_service_statuses'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['ancillary_services_vocabs_admin']
    exclude_fields = ['ancillary_service_status_id']
    sort_attrs = ['code', 'rfic', 'rfisc']
