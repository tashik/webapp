# -*- coding: utf-8 -*-

"""
$Id: $
"""

import csv
from cStringIO import StringIO
from zope.schema.interfaces import ITokenizedTerm
from pyramid.ui.exc import FormError
from django.utils.html import mark_safe, conditional_escape
import config

class excel_quote_all(csv.excel):
    quoting = csv.QUOTE_ALL

class DuplicateToken(ValueError):
    pass

class ImportCSVError(FormError):
    msg = u'Ошибка импорта данных'
    def __init__(self, errors, *args, **kw):
        super(ImportCSVError, self).__init__(*args, **kw)
        self.errors = errors
        parts = [self.msg]
        for e in errors:
            row_n, data, exc = e
            if isinstance(data, int):
                m = conditional_escape('Строка %s: Колонка %s: %s' % e)
            else:
                m = conditional_escape('Строка %s: Запись %r: %s' % e)
            parts.append(m)
        self.msg = mark_safe('<br>\n'.join(parts))


def export_csv(header_row, row_iterator):
    queue = StringIO()
    writer = csv.writer(queue, dialect=excel_quote_all, delimiter=';')
    row = header_row
    while 1:
        writer.writerow(row)
        yield queue.getvalue().encode(config.CSV_EXPORT_ENCODING, 'replace')
        queue.truncate(0)
        try:
            row = row_iterator.next()
        except StopIteration:
            break


def import_csv(input_file, input_charset, parse_csv_row):
    reader = csv.reader(input_file, dialect=excel_quote_all, delimiter=';')
    objects = []
    errors = []
    # пропускаем первую строку - это заголовок таблицы
    header_row = reader.next()

    for row_n, row in enumerate(reader, 2):
        unicode_row = [ unicode(v, input_charset) for v in row ]
        ob, row_errors = parse_csv_row(unicode_row)
        if row_errors:
            for e in row_errors:
                errors.append((row_n, row, e))
            continue
        objects.append(ob)

    return objects, errors


def merge(existing_objects_dict, imported_objects):
    # existing_objects_dict is a mapping
    # imported_objects is a sequence
    imported_tokens = set()
    added = []
    changed = []
    deleted = []
    errors = []

    for row_n, ob in enumerate(imported_objects, 2):
        token = ITokenizedTerm(ob).token
        if token in imported_tokens:
            errors.append((row_n, token, DuplicateToken(token)))
            continue
        imported_tokens.add(token)
        try:
            existing_ob = existing_objects_dict[token]
        except LookupError:
            added.append(ob)
            continue
        if ob != existing_ob:
            changed.append(ob)

    for ob in existing_objects_dict.values():
        if ITokenizedTerm(ob).token not in imported_tokens:
            deleted.append(ob)

    return added, changed, deleted, errors
