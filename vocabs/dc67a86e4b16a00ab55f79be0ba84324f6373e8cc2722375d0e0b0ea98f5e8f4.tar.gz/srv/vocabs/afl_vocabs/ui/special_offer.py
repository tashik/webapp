# -*- coding: utf-8 -*-
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS

from models.interfaces import ISpecialOffer
from models.special_offer import SpecialOffer
import ui.edit

import ui.edit
import ui.widgets


class SpecialOfferPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Спецпредложения'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['partner_vocabs_admin']
    ob_name = 'special_offer'
    ob_class = SpecialOffer
    ob_iface = ISpecialOffer
    vocab_name = 'special_offers'
    ws_key_fields = ['offer_id']
    exclude_fields = ['offer_id']
