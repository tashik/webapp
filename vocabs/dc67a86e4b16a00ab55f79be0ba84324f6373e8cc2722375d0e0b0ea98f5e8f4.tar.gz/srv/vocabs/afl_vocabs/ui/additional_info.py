# -*- coding: utf-8 -*-
"""
$Id: ancillary_services.py 15071 2015-09-24 14:01:57Z sbolxzhatov $
"""
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS
from ui.edit import ObjectEditPage
from models.additional_info import AdditionalInfo


class AdditionalInfoPage(ObjectEditPage):
    sectionTitle = u'Дополнительная информация'
    ob_name = 'additional_info'
    ob_class = AdditionalInfo
    vocab_name = 'additional_info'
    exclude_fields = ['additional_info_id']
    list_exclude_fields = ['condition']
    sort_attrs = ['weight', 'created']
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['addinfo_vocabs_admin']
