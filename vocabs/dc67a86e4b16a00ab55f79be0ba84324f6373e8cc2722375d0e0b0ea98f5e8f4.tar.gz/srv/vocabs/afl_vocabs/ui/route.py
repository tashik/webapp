# -*- coding: utf-8 -*-

"""
$Id: route.py 12252 2015-04-02 16:17:45Z ogambaryan $
"""

from pyramid.vocabulary import getV

from django import forms
from django.utils.html import conditional_escape

import ui.edit
import ui.widgets
from models.route import Pair, WrongRoute


class PairForm(forms.Form):
    airline = ui.widgets.VocabReferenceField(vocab_name='airlines', label=u'Авиакомпания', required=True)
    airport_from = ui.widgets.VocabReferenceField(vocab_name='airports', label=u'Аэропорт вылета', required=True)
    airport_to = ui.widgets.VocabReferenceField(vocab_name='airports', label=u'Аэропорт прилёта', required=True)
    miles = forms.IntegerField(label=u'Расстояние', required=True)
    no_spending = forms.BooleanField(label=u'Не предоставлять трату', required=False)

    def clean(self):
        cleaned_data = super(PairForm, self).clean()
        airline = cleaned_data.get('airline')
        airport_from = cleaned_data.get('airport_from')
        airport_to = cleaned_data.get('airport_to')

        if airport_from and airport_from == airport_to:
            self._errors['airport_to'] = self.error_class([u'Неправильный аэропорт прилёта.'])

        current_pair_id = int(self.data.get('pair_id', 0))
        for ob in getV('pairs').values():
            if current_pair_id != ob.pair_id \
                and (airline == ob.airline and airport_from == ob.airport_from and airport_to == ob.airport_to or \
                airline == ob.airline and airport_to == ob.airport_from and airport_from == ob.airport_to):
                self._errors['airport_to'] = self.error_class([u'Пара уже существует.'])
                break

        return cleaned_data


class PairPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Пары'
    ob_name = 'pair'
    ob_class = Pair
    vocab_name = 'pairs'
    edit_form_factory = PairForm
    exclude_fields = ['pair_id']
    sort_attrs = ['title']
    #ws_key_fields = ['airport_from', 'airport_to']
    match_attrs = [('airline_id', u'Выберите авиакомпанию', lambda p: p.airline, lambda al: (al.airline_id, u"%s, %s" % (al.iata, unicode(al.title)))),
            ('airport_id', u'Выберите аэропорт вылета/прилёта', lambda p: (p.airport_from, p.airport_to), lambda ap: (ap.airport_id, u"%s, %s" % (ap.iata, unicode(ap.title)))),
            ('airport_other_id', u'Выберите аэропорт вылета/прилёта', lambda p: (p.airport_from, p.airport_to), lambda ap: (ap.airport_id, u"%s, %s" % (ap.iata, unicode(ap.title))))]

    def _fmt_cell(self, value):
        from models.airport import IAirport
        if IAirport.providedBy(value):
            try:
                title = value.shortTitle
            except ValueError, e:
                title = repr(e)
            return conditional_escape(title)
        return super(PairPage, self)._fmt_cell(value)


class WrongRouteForm(forms.Form):
    city_from = ui.widgets.VocabReferenceField(vocab_name='cities', label=u'Город вылета', required=True)
    city_via = ui.widgets.VocabReferenceField(vocab_name='cities', label=u'Город пересадки', required=True)
    city_to = ui.widgets.VocabReferenceField(vocab_name='cities', label=u'Город прилёта', required=True)

    def clean(self):
        cleaned_data = super(WrongRouteForm, self).clean()
        city_from = cleaned_data.get('city_from')
        city_via = cleaned_data.get('city_via')
        city_to = cleaned_data.get('city_to')

        if city_from and city_from == city_via:
            self._errors['city_via'] = self.error_class([u'Неправильный город пересадки.'])

        if city_from and city_via and (city_from == city_to or city_via == city_to):
            self._errors['city_to'] = self.error_class([u'Неправильный город прилёта.'])

        current_route_id = int(self.data.get('wrong_route_id', 0))
        for ob in getV('wrong_routes').values():
            if current_route_id != ob.wrong_route_id \
                and (city_from == ob.city_from and city_to == ob.city_to and city_via == ob.city_via or \
                city_to == ob.city_from and city_from == ob.city_to and city_via == ob.city_via):
                self._errors['city_to'] = self.error_class([u'Маршрут уже существует.'])
                break

        return cleaned_data


class WrongRoutePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Запрещённые маршруты'
    ob_name = 'wrong_route'
    ob_class = WrongRoute
    vocab_name = 'wrong_routes'
    edit_form_factory = WrongRouteForm
    exclude_fields = ['wrong_route_id']
    sort_attrs = ['title']
    ws_key_fields = ['city_from', 'city_via', 'city_to']
    match_attrs = [('city_from', u'Выберите город вылета/прилёта', lambda r: (r.city_from, r.city_to), lambda c: (c.city_id, u"%s, %s" % (c.iata, c.title))),
        ('city_via', u'Выберите город пересадки', lambda r: r.city_via, lambda c: (c.city_id, u"%s, %s" % (c.iata, c.title))),
        ('city_to', u'Выберите город вылета/прилёта', lambda r: (r.city_from, r.city_to), lambda c: (c.city_id, u"%s, %s" % (c.iata, c.title)))]

    def _fmt_cell(self, value):
        from models.geo import ICity
        if ICity.providedBy(value):
            try:
                title = value.shortTitle
            except ValueError, e:
                title = repr(e)
            return conditional_escape(title)
        return super(WrongRoutePage, self)._fmt_cell(value)
