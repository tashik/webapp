# -*- coding: utf-8 -*-

"""
$Id: $
"""

from django import forms

from pyramid.ormlite import dbquery

import ui.edit
from models.member import LoyaltyProgram, ProfessionalArea
from ui.widgets import NullableTextField


class LoyaltyProgramForm(forms.Form):
    name = forms.CharField(label=u'Наименование программы лояльности',
                           required=True, min_length=1, max_length=128)
    siebel_id = NullableTextField(label=u'Идентификатор в системе Siebel',
                                  required=False, min_length=1, max_length=4,
                                  widget=forms.TextInput(attrs={'class': 'uppercase'}))
    sabre_id = NullableTextField(label=u'код Sabre',
                                  required=False, min_length=2, max_length=2,
                                  widget=forms.TextInput(attrs={'class': 'uppercase'}))

    def clean(self):
        cleaned_data = super(LoyaltyProgramForm, self).clean()
        siebel_id = cleaned_data.get('siebel_id')
        sabre_id = cleaned_data.get('sabre_id')
        current_id = int(self.data.get('loyalty_program_id', 0))

        if siebel_id:
            siebel_id_not_unique = dbquery("select count(*) from loyalty_programs where loyalty_program_id != %s and siebel_id = %s", current_id, siebel_id).fetchone()[0]
            if siebel_id_not_unique:
                self._errors['siebel_id'] = self.error_class([u'Программа с таким идентификатором в системе Siebel уже существует.'])
        if sabre_id:
            sabre_id_not_unique = dbquery("select count(*) from loyalty_programs where loyalty_program_id != %s and sabre_id = %s", current_id, sabre_id).fetchone()[0]
            if sabre_id_not_unique:
                self._errors['sabre_id'] = self.error_class([u'Программа с таким кодом в системе Sabre уже существует.'])
        return cleaned_data


class LoyaltyProgramPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Программы лояльности'
    ob_name = 'loyalty_program'
    ob_class = LoyaltyProgram
    vocab_name = 'loyalty_programs'
    edit_form_factory = LoyaltyProgramForm
    exclude_fields = ['loyalty_program_id']


class ProfessionalAreaPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Роды деятельности'
    ob_name = 'professional_area'
    ob_class = ProfessionalArea
    vocab_name = 'professional_areas'
    exclude_fields = ['professional_area_id']
