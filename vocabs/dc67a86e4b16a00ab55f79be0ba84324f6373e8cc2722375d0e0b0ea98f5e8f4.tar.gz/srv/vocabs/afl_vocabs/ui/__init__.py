# -*- coding: utf-8 -*-
import cherrypy
from pyramid.i18n.message import Message


def remove_duplicates(seq):
    # Удаление дублей из списка, с сохраненим порядка следования элементов
    seen = set()
    seen_add = seen.add
    return [x for x in seq if not (x in seen or seen_add(x))]


def notice(message, category=None, translate=True):
    """
        Сохранение, сообщений в сессию пользователя
    """
    notices = cherrypy.session.get('_notices', [])

    def add_notice(msg):
        if isinstance(msg, (Message, str)) or translate is False:
            msg = unicode(msg)
        elif isinstance(msg, unicode):
            pass  # оставляем message как есть
        else:
            raise TypeError
        _notice = (category or 'info', msg)
        if _notice not in notices:
            notices.append((category or 'info', msg))

    if isinstance(message, list):
        for mess in message:
            add_notice(mess)
    else:
        add_notice(message)

    cherrypy.session['_notices'] = notices
    cherrypy.session.save()


def get_notices(with_categories=False, category_filter=[]):
    """
        Получение сообщений, которые есть у пользователя.
        С фильтрацией по категориям.
    """
    notices = cherrypy.session.pop('_notices') if '_notices' in cherrypy.session else []
    cherrypy.session.save()
    if category_filter:
        notices = list(filter(lambda f: f[0] in category_filter, notices))
    notices = remove_duplicates(notices)
    if not with_categories:
        return [x[1] for x in notices]
    return notices