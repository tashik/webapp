# -*- coding: utf-8 -*-

"""
$Id: airport.py 24145 2017-03-31 15:46:37Z yumerkulov $
"""

from pyramid.vocabulary import getV
from pyramid.ui.utils import resolveRoute
from django import forms
from django.forms import formsets

import ui.common
import ui.widgets
import ui.edit
from ui import notice
from models.interfaces import IAirportTerminal
from models.airport import Airport, AirportTerminal
from models.indexer import getI


class TerminalForm(forms.Form):
    terminal_id = forms.IntegerField(required=False, widget=forms.HiddenInput)
    code = forms.CharField(label=u'Код', required=True, max_length=20)
    names = ui.widgets.MLNamesField(label=u'Названия', required=False)


class TerminalsFormset(formsets.BaseFormSet):
    form = TerminalForm
    extra = 1
    can_order = False
    can_delete = True
    max_num = None

#    def add_fields(self, form, index):
#        form.fields[formsets.DELETION_FIELD_NAME] = forms.BooleanField(required=False, widget=forms.HiddenInput)


class AirportForm(forms.Form):
    iata = ui.widgets.NullableTextField(label=u'IATA-код аэропорта', min_length=3, max_length=3, required=False,
                                        widget=ui.widgets.UppercaseTextInput)
    icao = ui.widgets.NullableTextField(label=u'ICAO-код аэропорта', min_length=4, max_length=4, required=False,
                                        widget=ui.widgets.UppercaseTextInput)
    lat = forms.FloatField(label=u'Широта', required=False)
    lon = forms.FloatField(label=u'Долгота', required=False)
    city = ui.widgets.VocabReferenceField(vocab_name='cities', label=u'Город', required=True)
    names = ui.widgets.MLNamesField(label=u'Названия', required=True)
    afl_redemption_zone = ui.widgets.VocabReferenceField(vocab_name='redemption_zones', label=u'Премиальная зона Аэрофлота', required=False)
    skyteam_redemption_zone = ui.widgets.VocabReferenceField(vocab_name='redemption_zones', label=u'Премиальная зона SkyTeam', required=False)
    has_afl_flights = forms.BooleanField(label=u'Сюда летает Аэрофлот', required=False)
    has_upgrade_on_checkin_award = forms.BooleanField(label=u'Доступна премия "Повышение класса обслуживания на стойке регистрации"', required=False)


class AirportPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Аэропорты'
    ob_name = 'airport'
    ob_class = Airport
    vocab_name = 'airports'
    exclude_fields = ['airport_id']
    sort_attrs = ['iata', 'icao', 'airport_id']
    search_attrs = ['iata', 'icao', 'names']
    match_attrs = [('city_id', u'Выберите город', lambda ap: ap.city, lambda ci: (ci.city_id, u"%s, %s" % (ci.iata, unicode(ci.title))))]
    edit_form_factory = AirportForm
    edit_tpl = '/airport/edit.html'
    ws_key_fields = ['iata']
    list_exclude_fields = ['has_afl_flights', 'has_upgrade_on_checkin_award', 'terminals', 'lat', 'lon']

    @staticmethod
    def _generate_terminal_initial(airport):
        t_initial = {}
        if airport:
            t_vocab = getV('airport_terminals')
            terminals = [
                t_vocab[t_id] for t_id in
                sorted(getI('terminals_by_airport_idx')(airport.airport_id))]
            t_initial = [
                dict(terminal_id=IAirportTerminal['terminal_id'].toUnicode(t.terminal_id),
                     code=IAirportTerminal['code'].toUnicode(t.code),
                     names=[IAirportTerminal['names'].toUnicode(t.names)])
                for t in terminals]
        return t_initial

    def _save_terminals(self, terminals_formset_forms, airport):
        for terminal_form in terminals_formset_forms:
            old_obj = None
            if not terminal_form.is_valid():
                continue
            t_data = terminal_form.cleaned_data
            if not t_data:
                continue
            terminal_id = t_data.get('terminal_id')

            if terminal_id:
                t = getV('airport_terminals')[terminal_id]
                old_obj = t.copy()
            else:
                t = AirportTerminal(terminal_id=AirportTerminal.getNewId(), airport_id=airport.airport_id)
            t.code = IAirportTerminal['code'].fromUnicode(t_data['code'])
            t.names = IAirportTerminal['names'].fromUnicode(t_data['names'])

            t.save()
            self._compare_and_log_objects(old_obj, t, 'terminal_id', 'airport_terminals')
            getV('airport_terminals').add(t)

    def _remove_terminals(self, deleted_forms):
        for deleted_form in deleted_forms:
            if not deleted_form.is_valid():
                continue
            terminal_id = deleted_form.cleaned_data['terminal_id']
            del getV('airport_terminals')[terminal_id]

    def _edit(self, airport, params, action='edit'):
        msg = ''
        form_has_error = False
        redirect_on_save = None
        old_obj = None

        if 'submit0' in params:
            form = self.edit_form_factory(params)
            terminals_formset = TerminalsFormset(params)

            if form.is_valid() and terminals_formset.is_valid():
                if not airport:
                    airport = Airport(airport_id=Airport.getNewId())
                    airport.has_afl_flights = False
                    getV(self.vocab_name).add(airport)
                    redirect_on_save = resolveRoute(self.edit_ob_route, airport_id=airport.airport_id)
                else:
                    old_obj = airport.copy()
                self._form_to_ob(form, airport, action)
                airport.save()
                self._compare_and_log_objects(old_obj, airport, 'airport_id')
                self._save_terminals(terminals_formset.forms, airport)
                self._remove_terminals(terminals_formset.deleted_forms)

                self._notify(airport, action)

                self._on_after_save(airport, action)

                if redirect_on_save:
                    return self.redirect(redirect_on_save)
                notice(u'Данные сохранены')
            else:
                form_has_error = True

        initial, readonly = self._populate_initial(airport, action)
        t_initial = self._generate_terminal_initial(airport)

        if not form_has_error:
            form = AirportForm(initial=initial)
            terminals_formset = TerminalsFormset(initial=t_initial)

        for name in readonly:
            if name in form.fields:
                form[name].field.widget.attrs['readonly'] = 'readonly'

        content = ui.template.renderTemplate(self.edit_tpl, form=form, page=self, ob=airport,
                                             formset=terminals_formset, action=action)
        return self.render(content)
