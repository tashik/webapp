# -*- coding: utf-8 -*-

import cherrypy
from mako import exceptions
from mako.lookup import TemplateLookup
from rx.i18n import _
from pyramid.ui.utils import resolveRoute
import config

tplLookup = TemplateLookup(directories=config.TEMPLATEDIR, input_encoding='utf-8')


def renderTemplate(tpl_file_name, **kw):
    B = resolveRoute('root')
    if B == '/':
        B = ''        
    tpl = tplLookup.get_template(tpl_file_name)
    
    from ui.common import get_current_lang

    context = dict(kw,
                   B=B, LK=config.LK_URL,
                   R=resolveRoute,
                   current_lang=get_current_lang(),
                   current_locale='ru',  # админку отображаем всегда для русской локали
                   url=cherrypy.url(),
                   is_endpoint=lambda x: False,
                   config=config,
                   GOOGLE_TAG_MANAGER_ID=None,
                   COMMON_STATIC_URL=config.COMMON_STATIC_URL,
                   SITE_HOST=config.SITE_HOST)
    try:
        return tpl.render(_=_, __=unicode, **context)
    except Exception as e:
        # TODO: сделать сохранение в лог
        if config.DEBUG:
            # отображаем ошибку шаблона в браузере
            return unicode(exceptions.html_error_template().render())
        raise
