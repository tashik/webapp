# -*- coding: utf-8 -*-

"""
$Id: $
"""
from django import forms

from models.air import Airline, AircraftType
import ui.edit

__ = unicode


class AirlineForm(forms.Form):
    iata = ui.widgets.NullableTextField(label=u'IATA-код', min_length=2, max_length=3, required=False,
                                        widget=ui.widgets.UppercaseTextInput)
    icao = ui.widgets.NullableTextField(label=u'ICAO-код', min_length=3, max_length=3, required=False,
                                        widget=ui.widgets.UppercaseTextInput)
    callsign = ui.widgets.NullableTextField(label=u'Позывной',max_length=64, required=False,
                                            widget=ui.widgets.UppercaseTextInput)
    country = ui.widgets.VocabReferenceField(vocab_name='countries', label=u'Страна', required=False)
    airport = ui.widgets.VocabReferenceField(vocab_name='airports', label=u'Аэропорт базирования', required=False)
    alliance = ui.widgets.NullableTextField(label=u'Альянс', max_length=16, required=False)
    loyalty_program = ui.widgets.VocabReferenceField(vocab_name='loyalty_programs', label=u'Программа лояльности', required=False)
    names = ui.widgets.MLNamesField(label=u'Название авиакомпании', required=True)
    parent_airline = ui.widgets.VocabReferenceField(vocab_name='airlines', label=u'Родительская авиакомпания', required=False, is_for_choice_field=False)
    url = ui.widgets.MLNamesField(label=u'Ссылка на сайт авиакомпании', required=False)
    weight = forms.IntegerField(label=u'Вес', required=True)

    miles_minimum = forms.FloatField(
            label=u'Минимальное количество миль при наборе', required=True)
    miles_limitation = ui.widgets.VocabReferenceField(
            vocab_name='miles_limitations',
            label=u'Ограничения для минимального количества миль', required=True)
    miles_earn_description = ui.widgets.MLTextField(label=u'Описание набора миль', required=False)
    miles_earn_comment = ui.widgets.MLTextField(label=u'Примечания для набора миль', required=False)


    def clean(self):
        miles_limitation = self.cleaned_data.get('miles_limitation')
        miles_minimum = self.cleaned_data.get('miles_minimum')
        if miles_limitation is not None and miles_limitation.token == 'N' and miles_minimum != 0.0:
            self._errors['miles_minimum'] = [__(u'При отсутствии ограничения минимальное количество миль должно быть нулём.')]
        return self.cleaned_data


class AirlinePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Авиакомпании'
    ob_name = 'airline'
    ob_class = Airline
    vocab_name = 'airlines'
    # exclude_fields = ['airline_id']  #NB! id ДОЛЖЕН отображаться
    search_attrs = ['iata', 'icao', 'names']
    edit_form_factory = AirlineForm
    list_exclude_fields = ['country', 'url', 'miles_limitation', 'miles_earn_comment', 'callsign', 'miles_minimum', 'miles_earn_description']



class AircraftTypePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Типы воздушных судов'
    ob_name = 'aircraft_type'
    ob_class = AircraftType
    vocab_name = 'aircraft_types'
    exclude_fields = ['aircraft_type_id']
    search_attrs = ['ohd_code', 'iata', 'icao', 'names']
