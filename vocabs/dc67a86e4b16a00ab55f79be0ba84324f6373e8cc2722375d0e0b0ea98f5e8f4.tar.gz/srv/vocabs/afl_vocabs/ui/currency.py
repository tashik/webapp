# -*- coding: utf-8 -*-

"""
$Id: $
"""

from models.currency import Currency
import ui.edit


class CurrencyPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Валюты'
    ob_name = 'currency'
    ob_class = Currency
    vocab_name = 'currencies'
    #exclude_fields = []
    search_attrs = ['alpha3_code', 'iso_code', 'cbr_code', 'names']
