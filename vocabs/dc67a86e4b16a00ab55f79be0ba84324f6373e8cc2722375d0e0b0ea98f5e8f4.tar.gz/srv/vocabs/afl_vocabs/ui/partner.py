# -*- coding: utf-8 -*-

"""
$Id: $
"""

from django import forms
from django.forms import formsets

from pyramid.vocabulary import getV
from pyramid.ui.utils import resolveRoute
from config_defaults import DEFAULT_ALLOW_ROLES_ADMINS

import ui.edit
import ui.widgets
from ui import notice
from models.partner import (PartnerCategory, Partner, PartnerOffice,
                            PartnerOfficeContact, PartnerAwardCondition)
from models.interfaces import IPartner, IPartnerOfficeContact
from models.indexer import getI

from rx.utils import enumerate_iface_fields


class PartnerCategoryPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Категории партнёров-неавиакомпаний'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['partner_vocabs_admin']
    ob_name = 'partner_category'
    ob_class = PartnerCategory
    vocab_name = 'partner_categories'
    exclude_fields = ['partner_category_id']
    ws_key_fields = ['partner_category_id']


class PartnerPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Партнёры-неавиакомпании'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['partner_vocabs_admin']
    ob_name = 'partner'
    ob_class = Partner
    ob_iface = IPartner
    vocab_name = 'partners'
    search_attrs = ['names']
    match_attrs = [('partner_category', u'Выберите категорию', lambda partner: partner.partner_categories,
                    lambda cat: (cat.partner_category_id, unicode(cat.title)))]
    ws_key_fields = ['partner_id']
    list_exclude_fields = ['partner_description', 'mile_get_comm', 'mile_waste_comm', 'spec_offer_comm','url']  # NB! id ДОЛЖЕН отображаться

    def __init__(self, *args, **kw):
        super(PartnerPage, self).__init__(*args, **kw)

        self.edit_form_factory = ui.edit.form_from_iface([
            (name, fld) for name, fld in
            enumerate_iface_fields(self.ob_iface, exclude=self.exclude_fields)
            if not ui.edit.field_in_pkey(fld)], self.ob_name)


class PartnerOfficeContactForm(forms.Form):
    partner_office_contact_id = forms.IntegerField(required=False, widget=forms.HiddenInput)
    contact_type = ui.widgets.VocabReferenceField(label=u'Тип контакта', vocab_name='partner_office_contact_types', required=True)
    contact = forms.CharField(label=u'Описание контакта', max_length=100, required=True)
    main_contact = forms.BooleanField(label=u'Основной контакт', required=False)


class PartnerOfficeContactFormset(formsets.BaseFormSet):
    form = PartnerOfficeContactForm
    extra = 1
    can_order = False
    can_delete = True
    max_num = None
    prefix = 'contacts'


class PartnerOfficeForm(forms.Form):
    partner = ui.widgets.VocabReferenceField(vocab_name='partners', label=u'Партнёр', required=True)
    city = ui.widgets.VocabReferenceField(vocab_name='cities', label=u'Город', required=True)
    lat = forms.FloatField(label=u'Широта', required=False)
    lon = forms.FloatField(label=u'Долгота', required=False)
    comments = ui.widgets.MLTextField(label=u"Комментарий", required=False)
    address = ui.widgets.MLTextField(label=u"Адрес", required=False)
    worktime = ui.widgets.MLTextField(label=u"Время работы", required=False)
    office_type = ui.widgets.VocabReferenceField(vocab_name='partner_office_types', label=u'Тип офиса', required=True)


class PartnerOfficePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Филиалы партнёров-неавиакомпаний'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['partner_vocabs_admin']
    ob_name = 'partner_office'
    ob_class = PartnerOffice
    vocab_name = 'partner_offices'
    exclude_fields = ['partner_office_id']
    edit_form_factory = PartnerOfficeForm
    edit_tpl = '/partner_office/edit.html'
    search_attrs = ['partner']
    ws_key_fields = ['partner_office_id']
    list_exclude_fields =  ['lat', 'lon', 'worktime', 'contacts']

    def _edit(self, ob, params, action='edit'):
        msg = ''
        form_has_error = False
        redirect_on_save = None

        if 'submit0' in params:
            form = self.edit_form_factory(params)
            contacts_formset = PartnerOfficeContactFormset(params)
            old_obj = None

            if form.is_valid() and contacts_formset.is_valid():
                if not ob:
                    ob = PartnerOffice(partner_office_id=PartnerOffice.getNewId())
                    getV(self.vocab_name).add(ob)
                    redirect_on_save = resolveRoute(self.edit_ob_route, partner_office_id=ob.partner_office_id)
                else:
                    old_obj = ob.copy()
                self._form_to_ob(form, ob, action)
                ob.save()

                for contact_form in contacts_formset.forms:
                    if not contact_form.is_valid():
                        continue
                    c_data = contact_form.cleaned_data
                    if not c_data:
                        continue
                    partner_office_contact_id = c_data.get('partner_office_contact_id')

                    if partner_office_contact_id:
                        c = getV('partner_office_contacts')[partner_office_contact_id]
                    else:
                        c = PartnerOfficeContact(partner_office_contact_id=PartnerOfficeContact.getNewId(),
                                                 partner_office=ob.partner_office_id)

                    c.contact_type = IPartnerOfficeContact['contact_type'].fromUnicode(c_data['contact_type'])
                    c.contact = IPartnerOfficeContact['contact'].fromUnicode(c_data['contact'])
                    c.main_contact = c_data['main_contact']

                    c.save()
                    getV('partner_office_contacts').add(c)

                for deleted_form in contacts_formset.deleted_forms:
                    if not contact_form.is_valid():
                        continue
                    partner_office_contact_id = deleted_form.cleaned_data['partner_office_contact_id']
                    del getV('partner_office_contacts')[partner_office_contact_id]

                self._notify(ob, action)
                self._compare_and_log_objects(old_obj, ob, 'partner_office_id')
                self._on_after_save(ob, action)

                if redirect_on_save:
                    return self.redirect(redirect_on_save)
                notice(u'Данные сохранены')
            else:
                form_has_error = True

        initial, readonly = self._populate_initial(ob, action)
        c_initial = {}
        if ob:
            c_vocab = getV('partner_office_contacts')
            contacts = [c_vocab[c_id] for c_id in sorted(getI('contact_by_partner_office_idx')(ob.partner_office_id))]
            c_initial = [dict(partner_office_contact_id=IPartnerOfficeContact['partner_office_contact_id'].toUnicode(c.partner_office_contact_id),
                              contact_type=c.contact_type,
                              main_contact=c.main_contact,
                              contact=IPartnerOfficeContact['contact'].toUnicode(c.contact))
                         for c in contacts]

        if not form_has_error:
            form = PartnerOfficeForm(initial=initial)
            contacts_formset = PartnerOfficeContactFormset(initial=c_initial)

        for name in readonly:
            if name in form.fields:
                form[name].field.widget.attrs['readonly'] = 'readonly'

        content = ui.template.renderTemplate(self.edit_tpl, form=form, page=self, ob=ob,
                                             formset=contacts_formset, action=action)
        return self.render(content)


class PartnerAwardConditionPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Условия набора и траты миль'
    _allow_roles = DEFAULT_ALLOW_ROLES_ADMINS + ['partner_vocabs_admin']
    ob_name = 'partner_award_condition'
    ob_class = PartnerAwardCondition
    vocab_name = 'partner_award_conditions'
    exclude_fields = ['partner_award_condition_id']
    search_attrs = ['partner', 'award_condition_type']
    ws_key_fields = ['partner_award_condition_id']
