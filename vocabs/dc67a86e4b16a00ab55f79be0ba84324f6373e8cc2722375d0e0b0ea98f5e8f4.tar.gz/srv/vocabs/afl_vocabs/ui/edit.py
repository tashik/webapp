# -*- coding: utf-8 -*-

"""
$Id: edit.py 23946 2017-03-17 16:00:12Z yumerkulov $
"""

import cgi
import logging
import re
import traceback
import urllib

import cherrypy
from django import forms
from django.utils.html import conditional_escape
from pyramid.model.interfaces import IIdCapable
from pyramid.ormlite import dbquery, dbop
from pyramid.ormlite.schema import IORMField
from pyramid.ui.utils import resolveRoute
from pyramid.vocabulary import getV
from rx.utils import enumerate_iface_fields, enumerate_fields
from zope.component import getAdapter
import zope.interface
import zope.schema
from zope.schema.interfaces import RequiredMissing, ITokenizedTerm
from zope.schema.vocabulary import SimpleTerm

from auth import authorize
import config
import log
from models import VocabDataVersion
from models.validation import get_validation_errors
import notify
import ui.common
import ui.csv_io
from ui.field_adapters import IDjangoFormsField, ICSVValueConverter
import ui.template
from ui import notice

LOG = log.log.action_logger.info


def field_in_pkey(field):
    return IORMField.providedBy(field) and field.primary_key

class ImportCSVForm(forms.Form):
    f = forms.FileField(label=u'Файл для импорта в формате CSV', required=True)

# для совместимости с django forms
class UploadedFile(object):
    def __init__(self, file, name, content_type, size, charset):
        self.file = file
        self.name = name
        self.content_type = content_type
        self.size = size
        self.charset = charset

    @classmethod
    def from_FieldStorage(cls, fs):
        assert isinstance(fs, cgi.FieldStorage)
        fs.file.seek(0, 2)
        size = fs.file.tell()
        fs.file.seek(0)
        ct = fs.headers.get('content-type')
        charset = config.CSV_IMPORT_ENCODING
        if ct:
            m = re.match('([^; ]+)\s*;(?:|\s*encoding=([^; ]))', ct)
            if m:
                ct = m.group(0)
                charset = m.group(1)
        return cls(fs.file, fs.filename, ct, size, charset)

    def __repr__(self):
        return 'UploadedFile(%r, %r, %r, %r, %r)' % (self.file, self.name, self.size, self.content_type, self.charset)


def form_from_iface(iface_fields, ob_name):
    #class _AutoForm(forms.Form): pass
    #form = _AutoForm
    # динамически создаем класс, наследующий от forms.Form
    cls_name = '_AutoForm_%s' % ob_name
    form_cls = type(cls_name, (forms.Form,), {}) 

    for name, schema_field in iface_fields:
        form_field = getAdapter(schema_field, IDjangoFormsField)
        form_cls.base_fields[name] = form_field
    return form_cls


class Paginator(object):
    page_param = '_page'
    objects_per_page = 100
    tpl = '/paginator.html'
    pass_all_parameters = True
    parameters_to_pass = []

    def __init__(self, objects, params=None, qs=None, parameters_to_pass=None):
        self.objects = objects

        params = params or {}
        try:
            self.page = int(params.get(self.page_param, 0))
        except ValueError:
            self.page = 0

        self.qs = qs or ''

        self.page_count = len(self.objects) / self.objects_per_page + 1

        self.prev = self.page - 1
        if self.prev < 0:
            self.prev = 0

        self.next = self.page + 1
        if self.next > self.page_count - 1:
            self.next = self.page_count - 1

        if parameters_to_pass is None:
            parameters_to_pass = self.parameters_to_pass or (
                    [key for key in params if key != self.page_param]
                    if self.pass_all_parameters else [])

        self.extra_params = {key: value for key, value in params.iteritems()
                             if key in parameters_to_pass} if params else {}

    def get_objects(self):
        start = self.page * self.objects_per_page
        return self.objects[start:start + self.objects_per_page]

    def render(self):
        return ui.template.renderTemplate(self.tpl, paginator=self,
                                          extra_params=urllib.urlencode(self.extra_params, doseq=True))


class FilterForm(forms.Form):
    q = forms.CharField(label=u'Поиск', required=False)


class ObFilter(object):
    search_param = 'q'
    tpl = '/filter.html'
    form_class = None       # Форма генерится динамически

    def __init__(self, objects, search_attrs=None, params=None, **kwargs):
        """ В kwargs принимается дополнительный параметр match_attrs -- список кортежей из 4 элементов:
            (key, label, match_fnc, item_fnc).

            key -- название параметра адресной строки, оно же поле формы;
            label -- текст поля формы ("Выберите ...").
            match_fnc -- функция, сопоставляющая элементу objects элемент списка выбора, кортеж из нескольких элементов, или None.
            item_fnc -- функция, возвращающая по элементу списка выбора его текстовое представление.
        """
        self.objects = objects
        self.search_attrs = search_attrs or []
        self.match_attrs = kwargs.get('match_attrs') or []

        params = params or {}
        self.q_original = params.get(self.search_param, '')
        self.q = self.q_original.lower()

        self.iface_fields = []
        try:
            ob_class = objects[0].__class__
            ob_iface = list(zope.interface.implementedBy(ob_class))[0]
            self.iface_fields = list(enumerate_iface_fields(ob_iface, include=self.search_attrs))
        except IndexError:
            pass

        self.form_initial = {self.search_param: self.q_original}
        for key, label, match_fnc, item_fnc in self.match_attrs:
            self.form_initial[key] = params.get(key, '')

    def get_values_with_unique_id(self, objects, fnc):
        """Собирает список значений функции fnc на списке objects, с неповторяющимися id."""
        vals = []
        ids = set([])
        for ob in objects:
            val = fnc(ob)
            if not isinstance(val, (tuple, list)):
                val = (val,)
            for val_item in val:
                if val_item is not None:
                    if isinstance(val_item, SimpleTerm) and val_item.token not in ids:
                        vals.append(val_item)
                        ids.add(val_item.token)

                    elif IIdCapable.providedBy(val_item) and val_item.id not in ids:
                        vals.append(val_item)
                        ids.add(val_item.id)
        return vals

    def get_search_form(self):
        """Форма поиска."""
        if self.form_class:
            return self.form_class

        cls_name = '_AutoForm_Search'
        form_cls = type(cls_name, (forms.Form,), {})

        if self.search_attrs:
            form_cls.base_fields['q'] = forms.CharField(label=u'Поиск', required=False)
            form_cls.base_fields['q'].help_text = u'Поиск по полям: %s' % ', '.join([field.title for attr, field in self.iface_fields])

        for key, label, match_fnc, item_fnc in self.match_attrs:
            choices = [('', u'- %s -' % label)] + sorted(map(item_fnc, self.get_values_with_unique_id(self.objects, match_fnc)), key=lambda ch: ch[1])
            form_cls.base_fields[key] = forms.ChoiceField(label=label, choices=choices, required=False)

        return form_cls

    def get_objects(self):
        return [ob for ob in self.objects if self._match(ob)]

    def get_qs(self):
        return u'&amp;%s=%s' % (self.search_param, self.q) if self.q else ''

    def render(self):
        if not self.search_attrs and not self.match_attrs:
            return ''

        form_class = self.get_search_form()
        form = form_class(initial=self.form_initial)
        return ui.template.renderTemplate(self.tpl, form=form, obfilter=self)

    def _match(self, ob):
        if self.match_attrs:
            for key, label, match_fnc, item_fnc in self.match_attrs:
                value = self.form_initial.get(key)
                if value:
                    attrs_to_match = match_fnc(ob)
                    if not isinstance(attrs_to_match, (tuple, list)):
                        attrs_to_match = (attrs_to_match,)
                    if not any([
                        IIdCapable.providedBy(attr_val) and attr_val.id == value
                        or isinstance(attr_val, SimpleTerm) and attr_val.token == value
                        or attr_val == value
                        for attr_val in attrs_to_match]):
                        return False
        if self.search_attrs and self.q:
            for attr, field in self.iface_fields:
                v = getattr(ob, attr)
                if v is not None:
                    if ITokenizedTerm.providedBy(v):
                        val = v.title
                    else:
                        val = field.toUnicode(v)
                    if self.q in val.lower():
                        return True
            return False
        return True


class ObjectEditPage(ui.common.AppPage):

    sectionTitle = NotImplemented
    ob_name = NotImplemented
    ob_class = NotImplemented
    exclude_fields = []
    list_exclude_fields = []
    edit_form_factory = None
    list_edit_form_factory = None
    ob_iface = None
    vocab_name = None
    sort_attrs = []
    ws_key_fields = []  # поля, являющиеся ключами в afl_ws

    list_tpl = '/object_list.html'
    edit_tpl = '/object_edit.html'

    fixed_list_layout = False
    list_col_attrs = {}

    filter_class = ObFilter
    search_attrs = []
    match_attrs = []

    paginator_class = Paginator

    def __init__(self, *args, **kw):
        super(ObjectEditPage, self).__init__(*args, **kw)

        if self.ob_iface is None:
            self.ob_iface = list(zope.interface.implementedBy(self.ob_class))[0]

        self.iface_fields = list(enumerate_iface_fields(self.ob_iface, exclude=self.exclude_fields))
        list_exclude_fields = self.exclude_fields + self.list_exclude_fields
        self.list_iface_fields = list(enumerate_iface_fields(self.ob_iface, exclude=list_exclude_fields))
        self.pkey_fields = [(name, field) for name, field in zope.schema.getFieldsInOrder(self.ob_iface)
                            if field_in_pkey(field)]
        self.csv_fields = zope.schema.getFieldsInOrder(self.ob_iface)

        if self.edit_form_factory is None:
            self.edit_form_factory = form_from_iface(self.iface_fields, self.ob_name)
        if self.list_edit_form_factory is None:
            self.list_edit_form_factory = form_from_iface(self.list_iface_fields, self.ob_name)
        self.list_obs_route = '%s_list' % self.ob_name
        self.export_obs_route = '%s_export' % self.ob_name
        self.import_obs_route = '%s_import' % self.ob_name
        self.add_ob_route = '%s_new' % self.ob_name
        self.edit_ob_route = '%s_edit' % self.ob_name
        self.del_ob_route = '%s_del' % self.ob_name


    @property
    def return_link(self):
        return u'<a href="%s">Вернуться</a>' % resolveRoute(self.list_obs_route)

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect(self.list_obs_route, self.ob_name, controller=self, action='index')
        if config.ENABLE_CSV_EXPORT:
            dispatcher.connect(self.export_obs_route,
                               '%s/export_csv' % self.ob_name,
                               controller=self, action='export_csv')
        if config.ENABLE_CSV_IMPORT:
            dispatcher.connect(self.import_obs_route,
                               '%s/import_csv' % self.ob_name,
                               controller=self, action='import_csv')
        
        dispatcher.connect(self.add_ob_route, ('%s/new' % self.ob_name), controller=self, action='add')
        pkey_tpl = ''.join([ ('/:%s' % name) for (name, field) in self.pkey_fields ])
        dispatcher.connect(self.edit_ob_route, ('%s%s/edit' % (self.ob_name, pkey_tpl)), controller=self, action='edit')
        dispatcher.connect(self.del_ob_route, ('%s%s/delete' % (self.ob_name, pkey_tpl)), controller=self, action='delete')


    def _pkey(self, ob):
        return dict([(name, field.get(ob)) for name, field in self.pkey_fields])


    def _pkey_from_params(self, params):
        pkey = {}
        for name, field in self.pkey_fields:
            pkey[name] = field.fromUnicode(params.get(name))
        return pkey

    def _form_to_ob(self, form, ob, action='edit'):
        for name, field in self.iface_fields:
            if name in form.fields and not field_in_pkey(field):
                if name in self.ws_key_fields and action == 'edit':
                    # Если поле является ключом в afl_ws,
                    # то его значение не должно изменяться
                    continue
                field.set(ob, form.cleaned_data.get(name))

    def _populate_initial(self, ob, action='edit'):
        initial = {}
        readonly = []
        for name, field in self.iface_fields:
            try:
                if ob is not None:
                    initial[name] = field.get(ob)
                else:
                    initial[name] = field.default
            except RequiredMissing:
                initial[name] = None
            else:
                if (ob is not None and field_in_pkey(field)) or \
                        field.readonly or \
                        (name in self.ws_key_fields and action == 'edit'):
                    readonly.append(name)

        return initial, readonly


    def _notify(self, ob, action):
        if action == 'new':
            notify.on_object_added(ob)
        elif action == 'edit':
            notify.on_object_changed(ob)
        elif action == 'delete':
            notify.on_object_deleted(ob)

    def _compare_and_log_objects(self, old_obj, new_obj, id_field=None, vocab_name=None):
        if not id_field:
            id_field = self.pkey_fields[0][0] if self.pkey_fields else 'id'

        vocab_name = vocab_name or self.vocab_name
        if old_obj:
            old_obj_change_field = []
            new_obj_change_field = []
            for name, field in enumerate_fields(new_obj):
                if getattr(old_obj, name) != getattr(new_obj, name):
                    old_obj_change_field.append(u'{0}: {1}'.format(name, getattr(old_obj, name)))
                    new_obj_change_field.append(u'{0}: {1}'.format(name, getattr(new_obj, name)))
            if new_obj_change_field:
                LOG(u'Обновлен объект {0} в словаре {1}, '
                    u'новые поля: {2}, '
                    u'старые поля {3}'.format(
                        getattr(new_obj, id_field),
                        vocab_name,
                        u' | '.join(new_obj_change_field),
                        u' | '.join(old_obj_change_field)
                ))
        else:
            self._logging_action(u'Добавлен', new_obj, vocab_name)

    def _logging_action(self, action, obj, vocab_name):
        template_log = u'{0} объект словаря {1}. Объект: {2}'
        ls = [x for x in enumerate_fields(obj)]
        descrs = []
        for name, field in ls:
            attr = getattr(obj, name)
            item = u'{0}: {1}'.format(name, attr)
            descrs.append(item)

        LOG(template_log.format(
            action,
            vocab_name,
            u' | '.join([u'{0}: {1}'.format(
                name,
                getattr(obj, name)) for name, field in enumerate_fields(obj)]))
        )

    @authorize
    def add(self, **params):
        return self._edit(None, params, action='new')

    @authorize
    def edit(self, **params):
        pkey = self._pkey_from_params(params)
        ob = getV(self.vocab_name)[pkey]
        return self._edit(ob, params)

    def _edit(self, ob, params, action='edit'):
        assert action in ('new', 'edit')
        form_has_error = False
        redirect_on_save = None
        old_obj = None
        if 'submit0' in params:
            form = self.edit_form_factory(params)

            if form.is_valid():
                pkey = {}

                if ob is None:
                    if len(self.pkey_fields) == 1 and self.pkey_fields[0][0] not in form.fields:  # объект имеет "синтетический" первичный ключ
                        identifier = self.ob_class.getNewId()
                        pkey[self.pkey_fields[0][0]] = identifier
                    else:
                        pkey = self._pkey_from_params(form.cleaned_data)
                    redirect_on_save = resolveRoute(self.edit_ob_route, **pkey)

                    ob = self.ob_class(**pkey)
                    getV(self.vocab_name).add(ob)
                else:
                    old_obj = ob.copy()

                self._form_to_ob(form, ob, action)

                ob.save()
                VocabDataVersion.increment_version(self.vocab_name)
                self._notify(ob, action)

                self._compare_and_log_objects(old_obj, ob)
                self._on_after_save(ob, action)

                if redirect_on_save:
                    return self.redirect(redirect_on_save)
                notice(u'Данные сохранены')
            else:
                logging.error(form.errors)
                form_has_error = True
        initial, readonly = self._populate_initial(ob, action)

        if not form_has_error:
            form = self.edit_form_factory(initial=initial)

        for name in readonly:
            if name in form.fields:
                form[name].field.widget.attrs['readonly'] = 'readonly'

        content = ui.template.renderTemplate(self.edit_tpl, form=form, page=self, ob=ob, action=action)
        return self.render(content)

    def _on_after_save(self, ob, action='edit'):
        pass


    @authorize
    def delete(self, **params):
        pkey = self._pkey_from_params(params)
        ob = getV(self.vocab_name)[pkey]
        ob.delete()
        self._logging_action(u'Удален', ob, self.vocab_name)
        del getV(self.vocab_name)[pkey]
        VocabDataVersion.increment_version(self.vocab_name)
        self._notify(ob, 'delete')
        self._on_after_delete(ob)

        return self.render(ui.common.info_msg(u'Объект удален') + self.return_link)

    def _on_after_delete(self, ob):
        pass


    def _fmt_cell(self, value):
        from pyramid.model.interfaces import ITitleCapable
        from zope.schema.interfaces import ITitledTokenizedTerm

        if ITitleCapable.providedBy(value) or ITitledTokenizedTerm.providedBy(value):
            try:
                title = value.title
            except ValueError, e:
                title = repr(e)
            return conditional_escape(title)
        elif isinstance(value, bool):
            return value and u'Да' or u'Нет'
        else:
            return conditional_escape(value) if value is not None else '&mdash;'


    def _load_ob_list(self):
        return getV(self.vocab_name).values()


    @authorize
    def index(self, **params):
        objects = self._load_ob_list()

        obfilter_kw = {'match_attrs': self.match_attrs} if self.match_attrs else {}
        obfilter = self.filter_class(objects, self.search_attrs, params, **obfilter_kw)
        objects = obfilter.get_objects()

        if self.sort_attrs:
            objects.sort(key=lambda ob: [getattr(ob, attr) for attr in self.sort_attrs])
        else:
            objects.sort(key=self._pkey)

        parameters_to_pass = [attr[0] for attr in self.match_attrs]
        if self.search_attrs:
            parameters_to_pass.append(obfilter.search_param)
        paginator = self.paginator_class(objects, params=params, qs=obfilter.get_qs(),
                                         parameters_to_pass=parameters_to_pass)
        objects = paginator.get_objects()

        form = self.list_edit_form_factory()

        content = ui.template.renderTemplate(
            self.list_tpl, page=self, objects=objects,
            form=form, obfilter=obfilter, paginator=paginator.render(),
            enable_import=config.ENABLE_CSV_IMPORT,
            enable_export=config.ENABLE_CSV_EXPORT)
        return self.render(content)


    @authorize
    def export_csv(self, **params):
        header_row = []
        for name, field in self.csv_fields:
            header_row.append(field.title or name)

        def sort_key_func(ob):
            return [(name, field.get(ob)) for name, field in self.pkey_fields]

        def get_iterator():
            for ob in sorted(getV(self.vocab_name).values(), key=sort_key_func):
                row = []
                for name, field in self.csv_fields:
                    bound_field = field.bind(ob)
                    value_converter = getAdapter(bound_field, ICSVValueConverter)
                    v = value_converter.to_csv(field.get(ob))
                    row.append(v)
                yield row

        cherrypy.response.headers['content-type'] = 'text/csv'
        cherrypy.response.headers['content-disposition'] = 'attachment; filename=%s.csv' % self.ob_name

        return ui.csv_io.export_csv(header_row, get_iterator())


    def _parse_csv_row(self, row):
        ob = self.ob_class()
        row_errors = []
        col_n = 0
        for csv_value, (name, field) in zip(row, self.csv_fields):
            field = field.bind(ob)
            col_n += 1
            try:
                value_converter = getAdapter(field, ICSVValueConverter)
                v = value_converter.from_csv(csv_value)
            except Exception, e:
                traceback.print_exc()
                row_errors.append(e)
                #raise KeyError(e)
            else:
                setattr(ob, name, v)

        if not row_errors:
            for e in get_validation_errors(self.ob_iface, ob):
                row_errors.append(e)

        if not row_errors:
            #print repr(ob)
            dbquery('savepoint try_saving')
            try:
                ob.save()  # проверяем на соответствие констрейнтам БД
            except dbop.dbapi.DatabaseError, e:
                row_errors.append(e)
            dbquery('rollback to savepoint try_saving')
            dbquery('release savepoint try_saving')

        return ob, row_errors


    def _import_csv(self, uf):
        imported_objects, parse_errors = ui.csv_io.import_csv(uf.file, uf.charset, self._parse_csv_row)

        if parse_errors:
            raise ui.csv_io.ImportCSVError(parse_errors)

        vocab = getV(self.vocab_name)
        added, changed, deleted, merge_errors = ui.csv_io.merge(vocab, imported_objects)

        if merge_errors:
            raise ui.csv_io.ImportCSVError(merge_errors)

        for ob in added + changed:
            vocab.add(ob)
            ob.save()
            self._logging_action(u'(импорт)Добавлен/Измененен', ob, self.vocab_name)

        for ob in deleted:
            del vocab[ITokenizedTerm(ob).token]
            ob.delete()
            self._logging_action(u'(импорт)Удален', ob, self.vocab_name)

        VocabDataVersion.increment_version(self.vocab_name)
        notify.post_events(('add', added),
                           ('change', changed),
                           ('delete', deleted))

        LOG('import %s' % self.ob_name)


    @authorize
    def import_csv(self, **params):
        if 'submit0' in params:

            files = {}
            for k, v in params.items():
                if not isinstance(v, cgi.FieldStorage): continue
                files[k] = UploadedFile.from_FieldStorage(v)
            form = ImportCSVForm({}, files)

            if form.is_valid():
                self._import_csv(form.cleaned_data['f'])
                return self.render(ui.common.info_msg(u'Данные импортированы') + self.return_link)
        else:
            form = ImportCSVForm()

        content = ui.template.renderTemplate('/object_import.html', form=form, page=self, action='import_csv')
        return self.render(content)
