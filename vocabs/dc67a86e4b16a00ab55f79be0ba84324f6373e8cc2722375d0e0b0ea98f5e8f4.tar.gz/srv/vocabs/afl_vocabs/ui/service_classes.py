# -*- coding: utf-8 -*-

"""
$Id: $
"""

from pyramid.vocabulary import getV

from django import forms
from django.forms import formsets
from django.utils.html import conditional_escape

import notify
import ui.edit
import ui.widgets
from models.indexer import getI
from models.interfaces import IAirline, ITariffGroup
from models.service_classes import SkyTeamServiceClass, AirlineServiceClass, Comment, ServiceClassesLimit


class SkyTeamServiceClassPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Классы обслуживания SkyTeam'
    ob_name = 'skyteam_service_classes'
    ob_class = SkyTeamServiceClass
    vocab_name = 'skyteam_service_classes'
    sort_attrs = ['weight', 'skyteam_sc_id']
    exclude_fields = ['skyteam_sc_id']


class AirlineServiceClassPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Классы обслуживания авиакомпаний'
    ob_name = 'airline_service_classes'
    ob_class = AirlineServiceClass
    vocab_name = 'airline_service_classes'
    search_attrs = ['airline', 'skyteam_sc']
    exclude_fields = ['airline_sc_id']

    list_col_attrs = dict(
        airline = {'width': '350'},
        skyteam_sc = {'width': '350'}
    )
    #fixed_list_layout = True

    def __init__(self, *args, **kwargs):
        super(AirlineServiceClassPage, self).__init__(*args, **kwargs)
        original_edit_form_factory = self.edit_form_factory

        def edit_form_factory(*args, **kwargs):
            form = original_edit_form_factory(*args, **kwargs)
            form.fields['airline'].widget.item_fnc = lambda a: (a.airline_id, u"%s, %s" % (a.iata, a.title))
            return form

        self.edit_form_factory = edit_form_factory

    def _fmt_cell(self, value):
        if IAirline.providedBy(value):
            return conditional_escape(u"%s, %s" % (value.iata, value.title))
        return super(AirlineServiceClassPage, self)._fmt_cell(value)


class CommentClassPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Комментарии'
    ob_name = 'comments'
    ob_class = Comment
    vocab_name = 'comments'
    sort_attrs = ['weight']
    exclude_fields = ['comment_id']


class ServiceClassesLimitPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Ограничения для классов обслуживания'
    ob_name = 'service_classes_limit'
    ob_class = ServiceClassesLimit
    vocab_name = 'service_classes_limits'
    exclude_fields = ['service_classes_limit_id']
