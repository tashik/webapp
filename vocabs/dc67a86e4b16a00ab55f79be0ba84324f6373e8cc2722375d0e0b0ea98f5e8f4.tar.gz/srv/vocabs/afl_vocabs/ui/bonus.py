# -*- coding: utf-8 -*-

"""
$Id: bonus.py 24145 2017-03-31 15:46:37Z yumerkulov $
"""


from pyramid.ui.utils import resolveRoute
from pyramid.vocabulary import getV

from django import forms
from django.forms import formsets

import ui.edit
import ui.widgets
from models.bonus import RedemptionZone, TierLevel, TariffGroup, \
    BonusRoute, Award, TierLevelFactor, \
    AirlineTariffGroup, BookingClass
from ui import notice


class RedemptionZonePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Премиальные зоны'
    ob_name = 'redemption_zone'
    ob_class = RedemptionZone
    vocab_name = 'redemption_zones'
    ws_key_fields = ['redemption_zone']


class TierLevelPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Статусы участников'
    ob_name = 'tier_level'
    ob_class = TierLevel
    vocab_name = 'tier_levels'
    sort_attrs = ['ordering', 'tier_level']
    ws_key_fields = ['tier_level']


class TierLevelFactorPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Коэффициенты статуса участника'
    ob_name = 'tier_level_factor'
    ob_class = TierLevelFactor
    vocab_name = 'tier_level_factors'
    exclude_fields = ['tier_level_factor_id']
    match_attrs = [('airline_id', u'Выберите авиакомпанию', lambda tlf: tlf.airline,
                    lambda al: (al.airline_id, u"%s, %s" % (al.iata, unicode(al.title))))]

    def __init__(self, *args, **kwargs):
        super(TierLevelFactorPage, self).__init__(*args, **kwargs)
        original_edit_form_factory = self.edit_form_factory

        def edit_form_factory(*args, **kwargs):
            form = original_edit_form_factory(*args, **kwargs)
            form.fields['airline'].widget.item_fnc = lambda a: (a.airline_id, u"%s, %s" % (a.iata, a.title))
            return form

        self.edit_form_factory = edit_form_factory


class BookingClassForm(forms.Form):
    booking_class_id = forms.IntegerField(required=False, widget=forms.HiddenInput)
    code = forms.CharField(label=u'Код класса бронирования', required=True, max_length=1,
                           widget=ui.widgets.UppercaseTextInput)


class BookingClassesFormset(formsets.BaseFormSet):
    form = BookingClassForm
    extra = 1
    can_order = False
    can_delete = True
    max_num = None


class TariffGroupForm(forms.Form):
    service_class = ui.widgets.VocabReferenceField(vocab_name='skyteam_service_classes', label=u'Класс обслуживания', required=True)
    tariff_group = forms.CharField(label=u'Код тарифной группы', required=True, max_length=50)
    names = ui.widgets.MLNamesField(label=u'Названия', required=True)
    weight = forms.IntegerField(label=u'Вес', required=False)

    def clean(self):
        cleaned_data = super(TariffGroupForm, self).clean()
        tariff_group = cleaned_data.get('tariff_group')
        service_class = cleaned_data.get('service_class')

        if tariff_group and service_class and not tariff_group.startswith(
                u'%s-' % service_class.code):
            self._errors['tariff_group'] = self.error_class(
                [
                    u'Неправильное название тарифной группы. '
                    u'Название должно начинаться с: "%s-"' %
                    service_class.code
                ]
            )

        return cleaned_data


class TariffGroupPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Тарифные группы'
    ob_name = 'tariff_group'
    ob_class = TariffGroup
    vocab_name = 'tariff_groups'
    sort_attrs = ['id_field', 'tariff_group']
    edit_form_factory = TariffGroupForm
    ws_key_fields = ['id_field']
    exclude_fields = ['id_field']
    match_attrs = [('service_class', u'Выберите класс обслуживания', lambda tg: tg.service_class, lambda sc: (sc.skyteam_sc_id, unicode(sc.title)))]

    def _edit(self, tariff_group, params, action='edit'):
        form_has_error = False
        redirect_on_save = None
        old_obj = None

        if 'submit0' in params:
            form = self.edit_form_factory(params)

            if form.is_valid():
                if not tariff_group:
                    tariff_group = TariffGroup(
                        id_field=TariffGroup.getNewId()
                    )
                    getV(self.vocab_name).add(tariff_group)
                    redirect_on_save = resolveRoute(
                        self.edit_ob_route,
                        id_field=tariff_group.id_field
                    )
                else:
                    old_obj = tariff_group.copy()
                self._form_to_ob(form, tariff_group, action)
                tariff_group.save()

                self._notify(tariff_group, action)
                self._compare_and_log_objects(old_obj, tariff_group, 'id_field')
                self._on_after_save(tariff_group, action)

                if redirect_on_save:
                    return self.redirect(redirect_on_save)
                notice(u'Данные сохранены')
            else:
                form_has_error = True

        initial, readonly = self._populate_initial(tariff_group, action)

        if not form_has_error:
            form = TariffGroupForm(initial=initial)

        for name in readonly:
            if name in form.fields:
                form[name].field.widget.attrs['readonly'] = 'readonly'

        content = ui.template.renderTemplate(
            self.edit_tpl,
            form=form,
            page=self,
            ob=tariff_group,
            action=action
        )
        return self.render(content)


class AirlineTariffGroupPage(ui.edit.ObjectEditPage):
    sectionTitle = u"Тарифные группы для авиакомпаний"
    ob_name = "airline_tariff_group"
    ob_class = AirlineTariffGroup
    vocab_name = "airline_tariff_groups"
    sort_attrs = ["idField"]
    ws_key_fields = ["idField"]
    exclude_fields = ['idField']
    match_attrs = [('airline_id', u'Выберите авиакомпанию', lambda atg: atg.serviceClass.airline, lambda al: (al.airline_id, u"%s, %s" % (al.iata, unicode(al.title))))]


class BookingClassPage(ui.edit.ObjectEditPage):
    sectionTitle = u"Классы бронирования"
    ob_name = "booking_class"
    ob_class = BookingClass
    vocab_name = "booking_classes"
    sort_attrs = ["idField"]
    ws_key_fields = ["idField"]
    exclude_fields = ['idField']
    match_attrs = [
        ('airline_id', u'Выберите авиакомпанию',
         lambda bcl: bcl.alTariffGroup.serviceClass.airline,
         lambda al: (al.airline_id, u"%s, %s" % (al.iata, unicode(al.title)))),
        ('tariff_group', u'Выберите тариф',
         lambda bcl: bcl.alTariffGroup,
         lambda tg: (tg.id, unicode(tg.title))
        )
    ]

class BonusRouteForm(forms.Form):
    code = forms.CharField(widget=forms.HiddenInput())
    zone_from = ui.widgets.VocabReferenceField(vocab_name='redemption_zones', label=u'Зона вылета', required=True)
    zone_via = ui.widgets.VocabReferenceField(vocab_name='redemption_zones', label=u'Зона пересадки', required=False)
    zone_to = ui.widgets.VocabReferenceField(vocab_name='redemption_zones', label=u'Зона прилёта', required=True)
    carrier = ui.widgets.VocabReferenceField(vocab_name='carriers', label=u'Перевозчик', required=True)

    def clean(self):
        cleaned_data = super(BonusRouteForm, self).clean()
        zone_from = cleaned_data.get('zone_from')
        zone_via = cleaned_data.get('zone_via')
        zone_to = cleaned_data.get('zone_to')
        carrier = cleaned_data.get('carrier')

        cur_bonus_route_id = int(self.data.get('bonus_route_id', 0))
        for ob in getV('bonus_routes').values():
            if cur_bonus_route_id != ob.bonus_route_id \
		and carrier == ob.carrier \
                and (zone_from == ob.zone_from and zone_to == ob.zone_to and zone_via == ob.zone_via or \
                zone_to == ob.zone_from and zone_from == ob.zone_to and zone_via == ob.zone_via):
                self._errors['zone_to'] = self.error_class([u'Премиальный маршрут уже существует.'])
                break

        cleaned_data['code'] = getattr(zone_from, 'redemption_zone', '') + getattr(zone_via, 'redemption_zone', '') + getattr(zone_to, 'redemption_zone', '')

        return cleaned_data


class BonusRoutePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Премиальные маршруты'
    ob_name = 'bonus_route'
    ob_class = BonusRoute
    edit_form_factory = BonusRouteForm
#    ws_key_fields = ['zone_from', 'zone_via', 'zone_to']
    ws_key_fields = ['bonus_route_id']
    vocab_name = 'bonus_routes'
    exclude_fields = ['bonus_route_id']
    sort_attrs = ['code']
    readonly = ['code']
    match_attrs = [('carrier', u'Выберите перевозчика', lambda br: br.carrier, lambda carrier: (carrier.token, unicode(carrier.title))),
                   ('zone_from', u'Выберите зону вылета', lambda br: br.zone_from, lambda zone: (zone.redemption_zone, u"%s - %s" % (zone.redemption_zone, zone.title))),
                   ('zone_to', u'Выберите зону прилёта', lambda br: br.zone_to, lambda zone:  (zone.redemption_zone, u"%s - %s" % (zone.redemption_zone, zone.title)))]

    def _edit(self, bonus_route, params, action='edit'):
        params['code'] = params.get('zone_from', '') + params.get('zone_via', '') + params.get('zone_to', '')
        return super(BonusRoutePage, self)._edit(bonus_route, params, action)


class AwardsPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Премии'
    ob_name = 'award'
    ob_class = Award
    vocab_name = 'awards'
    exclude_fields = ['award_id']
    match_attrs = [('bonus_route', u'Выберите премиальный маршрут', lambda aw: aw.route, lambda rt: (rt.bonus_route_id, rt.title))]
