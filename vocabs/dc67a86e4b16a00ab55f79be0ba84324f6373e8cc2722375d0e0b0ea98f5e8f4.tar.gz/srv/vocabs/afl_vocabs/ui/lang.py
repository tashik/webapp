# -*- coding: utf-8 -*-

"""
$Id: $
"""

import ui.edit

from models.lang import Language, Localization


class LanguagePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Языки'
    ob_name = 'language'
    ob_class = Language
    vocab_name = 'languages'
    sort_attrs = ['alpha2_code']


class LocalizationPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Локализации'
    ob_name = 'localization'
    ob_class = Localization
    vocab_name = 'localizations'
    sort_attrs = ['code']
