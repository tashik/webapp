# -*- coding: utf-8 -*-
"""
$Id$
"""
from models.meal import MealType, SpecialMeal, MealRule, MealTimelimit
import ui.edit


class MealTypePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Типы питания'
    ob_name = 'meal_type'
    ob_class = MealType
    vocab_name = 'meal_types'


class SpecialMealPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Спецпитание'
    ob_name = 'special_meal'
    ob_class = SpecialMeal
    vocab_name = 'special_meal'


class MealRulePage(ui.edit.ObjectEditPage):
    sectionTitle = u'Правила заказа питания'
    ob_name = 'meal_rule'
    ob_class = MealRule
    vocab_name = 'meal_rules'
    list_exclude_fields = ['special_meal']
    sort_attrs = ['meal_rule_id']
    edit_tpl = '/meal_rule/edit.html'


class MealTimelimitPage(ui.edit.ObjectEditPage):
    sectionTitle = u'Ограничение времени выбора питания'
    ob_name = 'meal_timelimit'
    ob_class = MealTimelimit
    vocab_name = 'meal_timelimits'
    sort_attrs = ['meal_timelimit_id']
    edit_tpl = '/meal_rule/edit.html'
