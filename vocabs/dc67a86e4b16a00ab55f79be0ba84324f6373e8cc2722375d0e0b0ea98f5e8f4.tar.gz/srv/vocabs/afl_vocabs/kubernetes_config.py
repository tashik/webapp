# -*- coding: utf-8 -*-

# если ЛК запущен под Kubernetes, подгружаем конфигурацию из его хранилища
import re

_CLUSTER_CONFIG = os.environ['INSTANCE_HOME'] + '/kube-config/cluster-config.py'
execfile(_CLUSTER_CONFIG)

_KUBERNETES_SECRETS_DIR = os.environ['INSTANCE_HOME'] + '/secrets'

# нужна для распарсивания многоуровневых ключей, типа SMS_SENDER_CONN.host
def __set_param(key, value):
    container = globals()
    keys = key.split('.')
    inner = keys.pop(-1)
    for k in keys:
        container = container[k]
    container[inner] = value

def __read_secret(secret_name):
    with open('%s/%s' % (_KUBERNETES_SECRETS_DIR, secret_name)) as f:
        return f.read()

def __load_secrets():
    for varname in os.listdir(_KUBERNETES_SECRETS_DIR):
        if re.match('[A-Z]+.*', varname):
            __set_param(varname, __read_secret(varname))
    
__load_secrets()
