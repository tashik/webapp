# -*- coding: utf-8 -*-

from config_defaults import *


SERVER_PORT = 9880          # Set real application server port

EXT_SERVER_URL = 'http://127.0.0.1:9880'

POSTGRES_DSN = "application_name=%s" % os.environ['HOSTNAME']

ADMIN_EMAIL = []

# Single Sign-On -------------------------------------------------------------
SSO_CLIENT_NAME = 'vocabs'
SSO_PASSWORD = '***'
SSO_SERVER = '127.0.0.1:7080'
SSO_LOGIN_URL = 'http://%s/personal/login' % SSO_SERVER
SSO_LOGOUT_URL = 'http://%s/personal/logout' % SSO_SERVER
SSO_VALIDATE_URL = 'http://%s/personal/services/sso/%s' % (SSO_SERVER, SSO_CLIENT_NAME)

PBUS_URL = 'http://127.0.0.1:8390'
PBUS_MY_NAME = 'vocabs'
PBUS_PASSWORD = '***'
PBUS_CALLBACK_HOST = '127.0.0.1'
PBUS_CALLBACK_PASSWORD = '***'
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_TOPICS = {
    'vocabs': 'vocabs',
}

# CSV import and export ------------------------------------------------------
ENABLE_CSV_IMPORT = True  # включить импорт из CSV
ENABLE_CSV_EXPORT = True   # включить экспорт в CSV

if 'KUBERNETES_PORT' in os.environ:
    execfile(APPDIR + '/kubernetes_config.py')

# проверяем, все ли обязательные параметры настроены и переопределены
for __n, __v in globals().items():
    if __v is NotImplemented:
        raise NameError(__n)
