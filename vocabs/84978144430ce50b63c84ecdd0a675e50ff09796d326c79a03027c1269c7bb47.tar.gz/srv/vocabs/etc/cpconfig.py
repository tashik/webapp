# -*- coding: utf-8 -*-

"""CherryPy Global Configuration."""

import urlparse
import config

# CherryPy Global Configuration ------------------------------------------------

global_cfg = {
    'engine.autoreload.on': not config.USING_PDB,  # отключаем авторелоад при использовании отладчика
    'tools.decode.on': True,
    'tools.encode.on': True,
    'tools.encode.encoding': config.ENCODING,
    'tools.decode.encoding': config.ENCODING,
    #'log.access_file': config['LOGDIR'] + '/access.log',
    #'log.error_file': config['LOGDIR'] + '/error.log',
    'log.screen': True, # Use 'False' for production mode
    'server.socket_port': config.SERVER_PORT,
    'server.socket_host': config.SERVER_HOST,
    'server.thread_pool': 8, # Use >0 for production mode
    'tools.sessions.name': 'vocabs_session_id',
    'tools.sessions.on': True,
#    'tools.sessions.secure': True,
    'tools.sessions.storage_type': 'file',
    'tools.sessions.storage_path': config.SESSDIR,
    #'tools.sessions.storage_type': 'memcached',
    #'tools.sessions.prefix': 'dev_aflcab-',
    'tools.sessions.timeout': 60, # In minutes
    'tools.sessions.domain': config.COOKIE_DOMAIN,
    'checker.check_static_paths': False,
    'tools.activate_django_translation.on': True,
    'tools.request_timer.on': True,
    'tools.clear_sess_cookie_expiry.on': True,
#    'request.throw_errors': True,
}
