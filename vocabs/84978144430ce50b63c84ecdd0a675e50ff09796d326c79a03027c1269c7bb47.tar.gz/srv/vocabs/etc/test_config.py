# -*- coding: utf-8 -*-

"""Application Test Configuration Template.
"""

import sys
import os
import os.path
import re
import imp

# Интерпретируем основной конфиг, затем переопределяем переменные для тестов
#__main_config = os.path.dirname(__file__) + '/../config.py'
#execfile(__main_config)

# Интерпретируем основной конфиг, затем переопределяем переменные для тестов
test_dir = os.path.dirname(os.path.abspath(__file__))
proj_path = os.sep.join(test_dir.split(os.sep)[:-1])
need_dirs = [test_dir, proj_path]

for i, dir in enumerate(need_dirs):
    if os.path.exists(dir) and dir not in sys.path:
        sys.path.insert(i, dir)

__main_config = os.path.join(proj_path, 'config.py')

imp.load_source('merge_config', __main_config)
from merge_config import *

SERVER_PORT = SERVER_PORT + 1

POSTGRES_DSN = re.sub(r"dbname='([^']+)'", r"dbname='\1_test'", POSTGRES_DSN)

from django.conf import settings
if not settings.configured:
    settings.configure()
