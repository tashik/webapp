export AFLCABDIR=$HOME/afl_cabinet
export LIBROOTDIR=$HOME/pyramid-lib
export APPLIBDIR=$HOME/afl_cabinet-lib
export PYRAMIDDIR=$HOME/pyramid
export PYTHONPATH=$AFLCABDIR:$APPLIBDIR:$LIBROOTDIR:$HOME/lib/python2.7/site-packages
export LD_LIBRARY_PATH=$HOME/lib
