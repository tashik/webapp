# -*- coding: utf-8 -*-

from config_defaults import *


SERVER_PORT = 6380
INSTANCE_ID = None

EXT_SERVER_URL = 'http://127.0.0.1:6380' + VIRTUAL_BASE  # URL для доступа к веб-серверу приложения, строка вида 'http://127.0.0.1:80'

LK_URL = 'http://afl-test.com.spb.ru/personal'  # URL для ссылок на ресурсы "Личного кабинета" (также используется для SSO)

POSTGRES_DSN = ''  # адрес БД берем из переменных окружения PGHOST, PGUSER, PGDATABASE

CO2_ADMIN_WS_DIGEST = {'co2_admin': '################################'}

ADMIN_EMAIL = [] #['admin@ramax.ru',]
SMTP_FROM = 'afl_partners@localhost'
SMTP_SERVER = 'mail.ramax.ru'
SMTP_PORT = 25

ENABLE_I18N = True
KNOWN_LANGUAGES = ('en', 'ru', 'de')
DEFAULT_SERVICE_LANG = 'en'

# Pbus -----------------------------------------------------------------------
PBUS_URL = None
PBUS_MY_NAME = os.environ.get('USER') or os.environ.get('USERNAME')
PBUS_PASSWORD = '123'
PBUS_CALLBACK_HOST = '127.0.0.1'
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_CALLBACK_PASSWORD = '123'
PBUS_TOPICS = {
    'vocabs': 'vocabs',
}
PBUS_VOCAB_RECIPIENTS = {
    'vocabs': 'vocabs'
}

PASSBOOK_SITE = 'https://stage.passbook.aeroflot.ru'
#PASSBOOK_SITE = 'https://passbook.aeroflot.ru'
WS_PASSBOOK_PASSWORD = '111'

ICER_SFTP_HOST = "sftp.aeroflot.ru"
ICER_SFTP_PORT = 22
ICER_SFTP_USERNAME = "***"
ICER_SFTP_PASSWORD = "***"
ICER_FILE_NAME_RE = re.compile(r'ICER_.*\.csv\.(\d{8}_\d{6}_\d{4})\.zip')

GEOIP_DB_PATH = os.path.abspath(os.path.join(APPDIR, '..', 'afl_cabinet-lib', 'GeoLite2-City.mmdb'))

# Сколько секунд кэшировать справочники в браузере
STATIC_DOCUMENT_CACHING_PERIOD = 0

CPCONFIG_GLOBAL.update({
    'server.thread_pool': 8,       # Число создаваемых тредов для обработки запросов
    'engine.autoreload.on': True,  # Автоматически перезагружать приложение при изменении *py файлов
    'log.screen': True,            # Use 'False' for production mode
})

# проверяем, все ли обязательные параметры настроены и переопределены
for __n, __v in globals().items():
    if __v is NotImplemented:
        raise NameError(__n)
