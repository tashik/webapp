#!/bin/bash -eu

if [[ -z "$@" ]]; then
    # default action
    mkdir -p "$INSTANCE_HOME/log/errors"
    # NOTE: используем exec для корректной обработки SIGINT контейнером
    exec python -u ws.py
else
    # cutsom cmd (example: /bin/bash)
    exec "$@"
fi
