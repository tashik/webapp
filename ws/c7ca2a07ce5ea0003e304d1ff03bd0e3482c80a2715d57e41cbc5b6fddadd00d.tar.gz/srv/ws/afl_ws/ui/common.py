# -*- coding: utf-8 -*-

"""
$Id: common.py 10039 2014-12-17 17:37:00Z ogambaryan $
"""


import cherrypy
import time
import re

from itertools import product, izip, tee

from zope.component import queryUtility, getUtility
from zope.i18n.interfaces import INegotiator, ILanguageAvailability

from django.utils.html import conditional_escape
from django import forms

from pyramid.app.page import AuthorizablePage
from pyramid.vocabulary import getV

import ui.template

from pyramid.ui.error import ErrorHandler
import rx.sso.error_handling
import rx.sso.url


def info_msg(msg):
    return u'<div class="information"><ul><li>%s</li></ul></div>' % conditional_escape(msg)


def error_msg(msg):
    return u'<div class="error message">%s</div>' % conditional_escape(msg)


def get_current_lang():
    return 'ru'


def _get_available_languages():
    result = []
    for elem in getUtility(ILanguageAvailability).getAvailableLanguages():
        if isinstance(elem, (list, tuple)):
            result.append(elem[0])
        else:
            result.append(elem)

    return result


def get_ws_languages():
    available = _get_available_languages()

    negotiator = queryUtility(INegotiator)
    if negotiator is not None:
        lang = negotiator.getLanguage(available, None)
        if lang:
            return [lang]

    return available


class AppPage(rx.sso.error_handling.ErrorHandling, AuthorizablePage):
    """ Веб-страница """

    def __init__(self, *args, **kw):
        super(AppPage, self).__init__(*args, **kw)
        self.errorHandler = ErrorHandler(self)
        self._cp_config['request.error_response'] = self.errorHandler.index

    _menus = 'main_menu'
    _template = '/full_page.html'
    _authObject = 'general'
    active_menu_item = None
    is_mobile_page = False

    # параметр _loginUrl используется в обработчике ошибок для редиректа на страницу логина
    # мы вынуждены динамически вычислять loginUrl из-за необходимости добавлять return_url

    _loginUrl = property(rx.sso.url.get_login_url, lambda self, v: None)

    def render(self, content, **params):
        menu = ui.template.renderTemplate('/app_menu.html')

        x_params = dict(
            page_title=u' | '.join([ unicode(s) for s in (self.title, self.sectionTitle) if s ]),
            section_title=self.sectionTitle is None and self.title or self.sectionTitle,
            user_display_name='',
            new_messages='',
            content=content,
            active_menu_item=self.active_menu_item,
            show_breadcrumbs=True,
            menus=[menu],
            current_year=time.localtime()[0],
        )
        x_params.update(params)

        return ui.template.renderTemplate(self._template, **x_params)
