# -*- coding: utf-8 -*-

"""
$Id: root.py 3147 2013-12-18 21:20:37Z ogambaryan $
"""

import urllib
import cherrypy
from pyramid.app.page import Page
import config
import ui.common
from auth import authorize

class LoginPage(Page):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('login', '/login', controller=self, action='login')
        dispatcher.connect('logout', '/logout', controller=self, action='logout', mode='full')

    def login(self, return_url=config.EXT_SERVER_URL+config.VIRTUAL_BASE):
        url = "%s?return_url=%s" % (config.SSO_LOGIN_URL, urllib.quote(return_url))
        self.redirect(url)

    def logout(self, mode, return_url=config.EXT_SERVER_URL+config.VIRTUAL_BASE):
        from pyramid.auth.authentication import revokeAuthentication
        revokeAuthentication()
        url = "%s?return_url=%s" % (config.SSO_LOGOUT_URL, return_url)
        self.redirect(url)


class RootPage(ui.common.AppPage):
    sectionTitle = config.SYSTEM_NAME

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('root', '/', controller=self, action='index')

    @authorize
    def index(self, **params):
        return self.render('')
#        email = cherrypy.session.get('user_email')
#        
#        content = 'Welcome %s' % email
#        return self.render(content)

