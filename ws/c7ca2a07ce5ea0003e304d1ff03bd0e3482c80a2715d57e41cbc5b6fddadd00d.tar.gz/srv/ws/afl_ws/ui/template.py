# -*- coding: utf-8 -*-

import cherrypy
from mako.lookup import TemplateLookup
from pyramid.ui.utils import resolveRoute
import config
tplLookup = TemplateLookup(directories=config.TEMPLATEDIR, input_encoding='utf-8')

from i18n_ws import _
__ = unicode

def renderTemplate(tpl_file_name, **kw):
    B = resolveRoute('root')
    if B == '/':
        B = ''
    tpl = tplLookup.get_template(tpl_file_name)
    
    from ui.common import get_current_lang
    x_params = dict(B=B, LK=config.LK_URL,
                    R=resolveRoute,
                    current_lang=get_current_lang(),
                    url=cherrypy.url())
    x_params.update(kw)

    return tpl.render(_=_, __=__, **x_params)
