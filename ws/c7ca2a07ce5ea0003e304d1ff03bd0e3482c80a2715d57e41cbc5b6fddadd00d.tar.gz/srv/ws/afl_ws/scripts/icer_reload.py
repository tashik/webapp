#!/usr/bin/env python
import json
import urllib2
import urllib
import logging
import logging.handlers
import sys
import traceback

from random import random
from pprint import pformat

import config


def create_icer_service_url():
    service_path = '/v.0.0.1/json/icer/RUB'
    params = urllib.urlencode({
        "prices": json.dumps(
            [{"currency": "EUR", "price": random() * 123456}]
        ),
        "reload": 1,
    })
    if len(sys.argv) > 1:
        return "".join([
            sys.argv[1],
            service_path, "?", params
        ])
    return "".join([
        "http://", config.SERVER_HOST, ":", str(config.SERVER_PORT),
        config.VIRTUAL_BASE,
        service_path, "?", params
    ])


def main():
    url = create_icer_service_url()
    logging.info("Trying to urlopen: %s" % url)
    try:
        result = json.loads(
            urllib2.urlopen(url).read()
        )
        logging.info("service response:\n" + pformat(result))
    except Exception as exc:
        logging.exception("error occured:\n" + traceback.format_exc(exc))


def init_logging():
    fmt = '[%(asctime)s] %(name)s %(message)s'
    datefmt = '%d/%b/%Y:%H:%M:%S'
    formatter = logging.Formatter(fmt, datefmt=datefmt)
    root = logging.root
    root.name = 'ICER update'
    root.setLevel(logging.INFO)
    console = logging.StreamHandler()
    console.setFormatter(formatter)
    console.setLevel(logging.INFO)
    root.addHandler(console)
    file_log = logging.handlers.RotatingFileHandler(
        config.LOGDIR + "/icer_update.log"
    )
    file_log.setFormatter(formatter)
    file_log.setLevel(logging.INFO)
    root.addHandler(file_log)


if __name__ == "__main__":
    init_logging()
    main()
