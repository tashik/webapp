# -*- coding: utf-8 -*-
import csv
from glob import glob
from pyramid.ormlite import dbquery
import requests
import config

import log as logging
import os
from pyramid.app.initializer import initDBConnection
from pyramid.vocabulary import getV
from transaction import commit
from initializer import init_vocabularies
from models.co2 import Emission, Coefficients

LOG = logging.log.scripts_logger.info
EMMISSION_HEADER = ('from', 'to', 'distance', 'aircraft_type' ,'co2_emission')
COEFS_HEADER = ('service_class', 'coefficient')


class CO2Exception(Exception):
    """Ошибка скрипта парсинга данных выбросов"""


def parse_csv(f, header):
    """Парсим строки csv и проверяем хедер на совпадение"""
    with open(f, 'rb') as csv_file:
        reader = csv.reader(csv_file, delimiter=',', quotechar='"')
        if tuple(reader.next()) != header:
            raise CO2Exception(u'Расположение полей не соответствует необходимым (%s)' % ', '.join(header))

        for i, row in enumerate(reader):
            yield i, row


def parse_emission(f):
    """Парсим файл выбросов и наполняем БД"""
    air_types = {type_item.ohd_code: type_item for type_item in getV('aircraft_types')}
    for i, row in parse_csv(f, EMMISSION_HEADER):
        Emission(emission_id=i,
                 airport_from=row[0],
                 airport_to=row[1],
                 distance=row[2],
                 aircraft_type=air_types[row[3]].aircraft_type_id,
                 emission=row[4]).save()


def parse_coefs(f):
    for i, row in parse_csv(f, COEFS_HEADER):
        Coefficients(service_class=row[0], coefficient=row[1]).save()


def main():
    os.chdir('data')
    emission_file = glob('CO2_emission*')
    coef_file = glob('CO2_coefficients*')
    LOG('Start emission parsing')
    LOG('emission_file: %s' % emission_file)
    LOG('coef_file: %s' % coef_file)
    url = "http://127.0.0.1:%s%s/v.0.0.1/json/co2/update" % (config.SERVER_PORT, config.VIRTUAL_BASE)

    if emission_file and coef_file:
        try:
            dbquery('delete from co2_coefficients')
            dbquery('delete from co2_emission')
            parse_emission(emission_file[0])
            parse_coefs(coef_file[0])
        except Exception as e:
            LOG('Failed\t' + e.__repr__())
            raise

        commit()
        LOG('Successful emission parsing')

        r = requests.get(url)
        if r.status_code != 200:
            msg = u'Вокабы не обновились, %s status -> %s' % (url, r.status_code)
            LOG(msg)
            raise CO2Exception(msg)
        else:
            LOG('Successful vocabs updating')

    else:
        LOG('No files in "/data" directory')

if __name__ == '__main__':
    initDBConnection()
    init_vocabularies()
    main()
