#!/usr/bin/env bash

#source setenv.sh || exit 1
pushd scripts || exit 1
python import_co2_data.py || exit 1
popd
echo "Done"
