# -*- coding: utf-8 -*-

"""
$Id: ssods.py 2858 2013-11-20 20:01:13Z anovgorodov $
"""
from datetime import datetime
import cherrypy
from lxml import etree
from zope.interface import implements
from zope.component import getUtility

from pyramid.auth.exc import NoCredentialsError
from pyramid.auth.interfaces import IAuthenticationDataSource,\
    ICredentialsDataSource, IAuthenticator, IPrincipal
import rx.sso.ssoclient
import config


class SSOUser(object):
    implements(IPrincipal)
    
    def __init__(self, user_id, email, first_name, last_name, role, display_name):
        self.identity = int(user_id)
        self.email = email
        self.first_name = first_name
        self.role = role
        self.last_name = last_name
        self.display_name = display_name

    @classmethod
    def from_sso(cls, e):
        user = cls(e.attrib['userId'], e.attrib.get('email'),
                   e.attrib.get('firstName'), e.attrib.get('lastName'), e.attrib.get('role'),
                   e.attrib.get('displayName'))
        return user

    @property
    def shortName(self):
        return self.display_name

    @property
    def realName(self):
        return '%s %s' % (self.first_name, self.last_name)


class SSOAuthenticationDS(object):
    implements(IAuthenticationDataSource)

    # Аргумент _sso_client нужен для тестирования
    def __init__(self, _sso_client=None):
        self._service_factory = _sso_client or rx.sso.ssoclient.SSOClient

    def authenticate(self, credentials):
        if not credentials:
            raise NoCredentialsError
        assert isinstance(credentials, str)
        sso = self._service_factory()
        text = sso.call(config.SSO_VALIDATE_URL, credentials)
        if not text:
            # delete cookie
            try:
                cherrypy.response.cookie['sso_session_id'].value = ''
                cherrypy.response.cookie['sso_session_id']['path'] = cherrypy.request.cookie['path']
                if 'domain' in cherrypy.request.cookie:
                    cherrypy.response.cookie['sso_session_id']['domain'] = cherrypy.request.cookie['domain']
                cherrypy.response.cookie['sso_session_id']['expires'] = 0
            except KeyError:
                pass
            raise NoCredentialsError
        return text


class SSOCredentialsDS(object):
    """CherryPy request params as Data source for credentials data"""
    implements(ICredentialsDataSource)

    # Аргумент _params используется при тестировании
    def getCredentials(self, _params=None):
        cookie = cherrypy.request.cookie
        try:
            sso_session_id = cookie['sso_session_id'].value
        except KeyError:
            return None  # не нашли нужную cookie
        return sso_session_id


class Authenticator(object):
    """Authentication service"""
    implements(IAuthenticator)

    def authenticate(self, force=False, include_personal_data=False):
        """Authenticates context. If 'force', clears current authentication
        status and forces authentication process.
        """
        cred_ds = getUtility(ICredentialsDataSource)
        auth_ds = getUtility(IAuthenticationDataSource)

        try:
            sso_session_id = cherrypy.request.cookie['sso_session_id'].value
        except KeyError:
            sso_session_id = None
        # кэширование результатов SSO
        sso_revalidate = cherrypy.session.get('sso_revalidate')

        do_call_sso = (force or
                       not sso_revalidate or
                       datetime.utcnow() >= sso_revalidate or
                       not sso_session_id or
                       sso_session_id != cherrypy.session.get('from_sso_session_id'))

        if not do_call_sso:
            sso_text = cherrypy.session['sso_text']
            user = SSOUser.from_sso(etree.fromstring(sso_text))
        else:
            sso_text = auth_ds.authenticate(cred_ds.getCredentials())
            e = etree.fromstring(sso_text)
            user = SSOUser.from_sso(e)
            cherrypy.session['sso_text'] = sso_text
            cherrypy.session['from_sso_session_id'] = sso_session_id
            cherrypy.session['sso_revalidate'] = datetime.strptime(e.attrib['revalidate'], '%Y-%m-%dT%H:%M:%S')
            cherrypy.session['user_display_name'] = user.display_name

        return user

    def reset(self):
        for k in 'sso_text', 'sso_revalidate', 'user_display_name':
            try:
                del cherrypy.session[k]
            except KeyError:
                pass
