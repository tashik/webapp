# -*- coding: utf-8 -*-
"""
$Id: __init__.py 3011 2013-12-10 20:12:16Z ogambaryan $
"""

from zope.component import getUtility
from pyramid.auth.interfaces import ICredentialsDataSource,\
    IAuthenticationDataSource, IAuthenticator
from pyramid.auth.exc import AuthorizationError

def authorizeFor(obj):
    """Упрощенная авторизация для afl_vocabs"""
    #cred_ds = getUtility(ICredentialsDataSource)
    #auth_ds = getUtility(IAuthenticationDataSource)
    #return auth_ds.authenticate(cred_ds.getCredentials())

    #authenticator = getUtility(IAuthenticator)
    #user = authenticator.authenticate()
    #if user.role != 'admin':
    #    raise AuthorizationError()

    return False

def authorize(method):
    """Authorization decorator for object methods.

    Usage:

    class Foo():

        @authorize()
        def some_method(self, params):
            pass

    Authorizes method access before calling.
    """
    def decorator(self, *args, **kwargs):
        authorizeFor(self)
        return method(self, *args, **kwargs)
    return decorator
