# -*- coding: utf-8 -*-

"""
$Id: ibeacons.py 35215 2018-07-21 11:29:36Z apinsky $
"""

import uuid

from pyramid.vocabulary import getV

from services.json_services import get_translate_dict
from services.base.json_base import CommonJSONService, SuccessServiceResponse


class BluetoothBeaconsService(CommonJSONService):
    """Сервис iBeacons (bluetooth маячки)"""
    
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_ibeacons_service', 'v.0.0.1/json/ibeacons',
                           action='v001', controller=self)
    
    def v001(self):
        vocab = getV('ibeacons')
        result = [self._encode_ibeacon(ibeacon) for ibeacon in vocab]
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())
    
    def _encode_ibeacon(self, ibeacon):
        item = {
            'id': ibeacon.unique_id,
            'device_id': ibeacon.device_id,
            'description': get_translate_dict(ibeacon.beacon_description),
            'message': get_translate_dict(ibeacon.message),
            'type': ibeacon.message_type,
            'major': ibeacon.device_major,
            'minor': ibeacon.device_minor,
            'uuid': str(uuid.UUID(ibeacon.manufacturer_guid))
        }
        if ibeacon.location_latitude is None or ibeacon.location_longitude is None:
            item['location'] = None
        else:
            item['location'] = {
                'lat': ibeacon.location_latitude,
                'lon': ibeacon.location_longitude
            }
        if ibeacon.scheme_android and ibeacon.scheme_ios and ibeacon.scheme_winphone:
            item['scheme'] = {
                'android': ibeacon.scheme_android,
                'ios': ibeacon.scheme_ios,
                'winphone': ibeacon.scheme_winphone
            }
        else:
            item['scheme'] = None

        return item
