# -*- coding: utf-8 -*-
"""
$Id$
"""

from collections import namedtuple

from pyramid.vocabulary import getV
from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse, json_required, BaseValidationError,\
    ParameterMissingError
from services.json_services import get_json_ml


POSITION_KEY = 'position'
SEGMENTS_KEY = 'segments'
CLEANED_REQUEST_KEY = 'request'
DEFAULT_POSITION = 'flight'


CleanedRequest = namedtuple('CleanedRequest', ['global_params', 'position', 'segments', 'raw'])


class SegmentsValidationError(BaseValidationError):
    u"""Ошибка валидации списка сегментов"""

    code = 207023


class AdditionalInfoJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_additional_info_service', 'v.0.0.1/json/additional_info', action='v001',
                           controller=self)
        dispatcher.connect('json_additional_info_service_v002', 'v.0.0.2/json/additional_info', action='v002',
                           controller=self)

    def _update_param(self, segment, old_prefix, new_prefix, vocab, field_name):
        u"""Проставляет код города по аэропорту, код страны по городу и т.д."""
        for key, value in segment.items():
            if key.startswith(old_prefix):
                new_key = new_prefix + key[len(old_prefix):]
                if new_key not in segment or not segment[new_key]:
                    try:
                        element = vocab[value]
                    except KeyError:
                        continue

                    new_value = getattr(element, field_name)
                    if new_value:
                        segment[new_key] = new_value
        return segment

    def _update_segment(self, segment):
        segment = self._update_param(segment, 'airport', 'city', getV('airports'), 'city')
        segment = self._update_param(segment, 'city', 'country', getV('cities'), 'country_code')
        segment = self._update_param(segment, 'country', 'world_region', getV('countries'), 'world_region_id')
        return segment

    @staticmethod
    def _clean_request(json_request):
        try:
            segments = json_request[SEGMENTS_KEY]
        except (KeyError, TypeError):
            raise SegmentsValidationError(json_request)

        if not isinstance(segments, list):
            raise SegmentsValidationError(json_request)

        global_params = dict(json_request)
        global_params.pop(SEGMENTS_KEY)
        position = global_params.pop(POSITION_KEY, None)

        return CleanedRequest(global_params=global_params, position=position, segments=segments, raw=json_request)

    def _index(self, message_lang, segments, position, global_params, raw_request):
        info_vocab = getV('additional_info')
        data = {}
        for segment in segments:
            if not isinstance(segment, dict):
                raise SegmentsValidationError(raw_request)

            segment = self._update_segment(segment)

            for info in info_vocab:
                if info.position == position and info.matches(**segment):
                    data[info.additional_info_id] = info

        data = sorted(data.itervalues(), key=lambda x: (x.weight, x.created), reverse=True)
        data = [get_json_ml(info.names, message_lang) for info in data]
        response = SuccessServiceResponse(data=data)
        return self.render(response.to_dict())

    @languageaware
    @json_required
    def v001(self, message_lang, error_lang, json_request, **params):
        u"""Сервис дополнительной информации"""
        request = self._clean_request(json_request)
        return self._index(message_lang, segments=request.segments, position=DEFAULT_POSITION,
                           global_params=request.global_params, raw_request=request.raw)

    @languageaware
    @json_required
    def v002(self, message_lang, error_lang, json_request, **params):
        u"""Сервис дополнительной информации версии 2"""
        request = self._clean_request(json_request)

        if not request.position:
            raise ParameterMissingError(POSITION_KEY)

        return self._index(message_lang, segments=request.segments, position=request.position,
                           global_params=request.global_params, raw_request=request.raw)
