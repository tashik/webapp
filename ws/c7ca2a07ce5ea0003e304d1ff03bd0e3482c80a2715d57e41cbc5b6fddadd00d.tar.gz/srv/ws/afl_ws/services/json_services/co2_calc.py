# -*- coding: utf-8 -*-
import cherrypy

from pyramid.vocabulary import getV

import access
from services.base.json_base import CommonJSONService, SuccessServiceResponse
from services.json_services import translate_ML


class CO2Calculate(CommonJSONService):
    """Сервис расчета выбросов со2"""
    default_lang = 'en'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_co2', 'v.0.0.1/json/co2/{param_from}/{param_to}',
                           action='index', controller=self)

    def index(self, param_from='', param_to='', aircraft_type='',  service_class='', **kwargs):
        ap_from, ap_to, ac_type, service_class, result = (
            param_from.upper(),
            param_to.upper(),
            aircraft_type,
            service_class.lower(),
            []
        )
        lang = kwargs.get('lang', self.default_lang)
        coeffs, air_types = getV('coefficients'), getV('aircraft_types')
        air_types_data = {key: air_types[key] for key in air_types.keys()}

        if not ap_from or not ap_to:
            return self.render()

        for item in getV('emission'):
            if ap_from == item.airport_from and ap_to == item.airport_to:
                if ac_type and ac_type != air_types_data[str(item.aircraft_type)].ohd_code:
                    continue
                for coeff_item in coeffs:
                    if service_class and service_class != coeff_item.service_class:
                        continue
                    aircraft_names = translate_ML(air_types_data[str(item.aircraft_type)].names)
                    result.append({
                        'from': item.airport_from,
                        'to': item.airport_to,
                        'aircraft_type': air_types_data[str(item.aircraft_type)].ohd_code,
                        'service_class': coeff_item.service_class,
                        'distance': item.distance,
                        'co2_emission': round(item.emission * coeff_item.coefficient, 3),
                        'aircraft_name': aircraft_names.get(lang, aircraft_names.get(self.default_lang))
                    })

        response = SuccessServiceResponse({'segment': result}).to_dict()
        return self.render(response)


class CO2VocabsUpdater(CommonJSONService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('co2_updater', 'v.0.0.1/json/co2/update', action='index', controller=self)

    def index(self, **kwargs):
        access.check_monitoring_access()
        coeffs = getV('coefficients')
        air_types = getV('emission')
        coeffs.vocab_reload()
        air_types.vocab_reload()
