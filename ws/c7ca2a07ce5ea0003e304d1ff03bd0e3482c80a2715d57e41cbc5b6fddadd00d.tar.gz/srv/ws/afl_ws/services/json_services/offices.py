# -*- coding: utf-8 -*-

from pyramid.vocabulary import getV
from services.json_services import translate_ML, get_json_ml

from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse
from services.base.static import StaticService, DocumentCatalog, StaticDocument
import config

def get_list(list_element):
    return filter(lambda x: x != '', list_element)

_ALL_LANGUAGES = list(config.KNOWN_LANGUAGES) + [None]


class OfficeJSONServiceV002(CommonJSONService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_offices_service_v2', 'v.0.0.2/json/offices', action='v002', controller=self)

    @languageaware
    def v002(self, message_lang, error_lang):
        u"""Сервис офисов, на основе towns, offices и countries"""
        offices = getV('offices')
        cities = getV('towns')
        countries = getV('countries')
        office_categories = getV('office_categories')

        data = []
        for office_item in offices:
            office = {}
            office_category = office_categories[office_item.office_category]
            city = cities[office_category.city]
            country_code = city.country_code
            country = countries[country_code]
            city_names = translate_ML(city.names)
            country_names = translate_ML(country.names)
            office_title = {}
            for lang in city_names.keys():
                if lang in country_names.keys():
                    office_title_var = "%s, %s" % (country_names[lang],city_names[lang])
                    office_title[lang] = office_title_var
            office['city'] = dict(title=city_names)
            office['country'] = dict(title=country_names)
            office['description'] = translate_ML(office_item.office_description)
            office['email'] = get_list(office_item.email)
            office['fax'] = get_list(office_item.fax)
            office['phone'] = get_list(office_item.phone)
            lat = office_item.lat
            lon = office_item.lon
            if (lat is not None) and (lon is not None):
                office['location'] = dict(lat=lat, lon=lon)
            else:
                office['location'] = None
            office['address'] = translate_ML(office_item.address)
            office['title'] = office_title
            office['worktime'] = dict(description=translate_ML(office_item.worktime))
            data.append(office)
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class OfficeJSONServiceV003(StaticService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_offices_service_v3', 'v.0.0.3/json/offices', action='v003', controller=self)

    def _make_office_category_dict(self, category, lang, offices, travel_options, cities, countries, airports):
        city = cities[category.city]
        country = countries[city.country_code]
        d = {
             'title': get_json_ml(category.names, lang),
             'description': get_json_ml(category.office_category_description, lang),
             'city': {'title': get_json_ml(city.names, lang)},
             'country': {'title': get_json_ml(country.names, lang)},
             'offices': [self._make_office_dict(office, lang, travel_options, airports) for office in category.get_offices(offices)]
             }
        return d

    def _make_office_dict(self, office, lang, travel_options, airports):
        airport = airports.get(office.airport, None)
        airport_name = None
        if airport:
            airport_name = get_json_ml(airports[office.airport].names, lang)

        location = None
        if (office.lat is not None) and (office.lon is not None):
            location = dict(lat=office.lat, lon=office.lon)

        d = {
             'title': get_json_ml(office.names, lang),
             'description': get_json_ml(office.office_description, lang),
             'address': get_json_ml(office.address, lang),
             'worktime': get_json_ml(office.worktime, lang),
             'airport': office.airport,
             'airport_name': airport_name,
             'in_airport': office.in_airport,
             'distance_to_airport': office.distance_to_airport,
             'insurance_policy': office.insurance_policy,
             'noncash_booking': office.noncash_booking,
             'new_office': office.new_office,
             'email': get_list(office.email),
             'fax': get_list(office.fax),
             'phone': get_list(office.phone),
             'location': location,
             'location_map': get_json_ml(office.location_map, lang),
             'transfer_time_public': office.transfer_time_public,
             'transfer_time_automobile': office.transfer_time_automobile,
             'transfer_time_foot': office.transfer_time_foot,
             'important_info': get_json_ml(office.important_info, lang),
             'office_weight': office.office_weight,
             'travels': [self._make_travel_options(office, lang) for office in office.get_travel_options(travel_options)]
        }
        return d

    def _make_travel_options(self, travel, lang):
        d = {
              'type': travel.travel_type,
              'description': get_json_ml(travel.office_travel_option_description, lang),
              'time': travel.travel_time
        }
        return d

    @languageaware
    def v003(self, message_lang, error_lang, **params):
        u"""Сервис доступных категорий партнёров"""
        return self.serve_document(self.documents[message_lang])

    def build_document(self, message_lang):
        categories = getV('office_categories')
        offices = getV('offices')
        travel_options = getV('office_travel_options')
        cities = getV('towns')
        countries = getV('countries')
        airports = getV('airports')
        data = [self._make_office_category_dict(category, message_lang, offices, travel_options, cities, countries, airports) \
                for category in categories if category.office_category_id > 0]
        response = SuccessServiceResponse(data)
        return StaticDocument(self.renderContent(response.to_dict()))


    def __init__(self):
        super(OfficeJSONServiceV003, self).__init__()
        self.documents = DocumentCatalog(dependencies={'offices', 'towns', 'countries', 'office_categories'},
                                         document_keys=_ALL_LANGUAGES,
                                         document_constructor=self.build_document)
