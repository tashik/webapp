# -*- coding: utf-8 -*-
"""
$Id$
"""
from datetime import datetime, timedelta

from django.core.validators import RegexValidator
from django.forms import Form, CharField, IntegerField, DateTimeField
from pyramid.vocabulary import getV
from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse, BaseValidationError, json_required
from services.json_services import get_json_ml
import config


class RuleBasedFilter(object):
    vocab = NotImplemented
    sort_by_field = NotImplemented
    match_fields = NotImplemented

    def field_matches(self, field, value):
        u"""Проверяет, что значение подходит под маску правила"""
        if field is None:
            return True
        if isinstance(field, (list, tuple)):
            if not field:
                return True
            return value in field
        if isinstance(field, basestring):
            if not field:
                return True
            try:
                number = int(value)
                for interval in field.split(','):
                    values = interval.split('-')
                    if len(values) == 2:
                        if int(values[0]) <= number <= int(values[1]):
                            return True
                    elif number == int(interval):
                        return True
            except (ValueError, TypeError):
                pass
        return value == field

    def matches(self, item, **kwargs):
        u"""Проверяет, что параметры подходят под правило"""
        for field in self.match_fields:
            if field.endswith('_from'):
                key = field[:-5]
                value = getattr(item, field)
                if value is not None and (key not in kwargs or value > kwargs[key]):
                    return False
            elif field.endswith('_to'):
                key = field[:-3]
                value = getattr(item, field)
                if value is not None and (key not in kwargs or value < kwargs[key]):
                    return False
            elif not self.field_matches(getattr(item, field), kwargs.get(field)):
                return False
        return True

    def find(self, **kwargs):
        u"""Возвращает все правила, под которые подходят параметры"""
        items = sorted(getV(self.vocab).values(), key=lambda x: getattr(x, self.sort_by_field))
        for item in items:
            if self.matches(item, **kwargs):
                yield item

    def get_first(self, **kwargs):
        u"""Возвращает первое правило, под которое подходят параметры"""
        try:
            return self.find(**kwargs).next()
        except StopIteration:
            return


class MealRuleFilter(RuleBasedFilter):
    vocab = 'meal_rules'
    sort_by_field = 'meal_rule_id'
    match_fields = ('date_from', 'date_to', 'number', 'airline', 'origin', 'destination', 'booking_class')


class MealTimelimitFilter(RuleBasedFilter):
    vocab = 'meal_timelimits'
    sort_by_field = 'meal_timelimit_id'
    match_fields = ('origin', 'special_meal')


class UppercaseCharField(CharField):
    u"""Приводит строку к верхнему регистру"""

    def clean(self, value):
        value = super(UppercaseCharField, self).clean(value)
        return value.upper()


class SegmentForm(Form):
    origin = UppercaseCharField(label=u'Код аэропорта вылета', required=True, validators=[RegexValidator(u'^[A-Za-z]{3}$')])
    destination = UppercaseCharField(label=u'Код аэропорта прилета', required=True, validators=[RegexValidator(u'^[A-Za-z]{3}$')])
    flight_datetime = DateTimeField(label=u'UTC Дата вылета', required=True, input_formats=[u'%Y-%m-%dT%H:%M'])
    booking_class = UppercaseCharField(label=u'Класс бронирования', required=True, validators=[RegexValidator(u'^[A-Za-z]$')])
    number = IntegerField(label=u'Номер рейса', required=True, min_value=0)
    airline = UppercaseCharField(label=u'Код авиакомпании', required=True, validators=[RegexValidator(u'^[A-Za-z]+$')])


class RequestFormatError(BaseValidationError):
    u"""Неправильный формат запроса"""
    code = 207030


class OriginValidationError(BaseValidationError):
    u"""Ошибка валидации кода аэропорта вылета"""
    code = 207031


class DestinationValidationError(BaseValidationError):
    u"""Ошибка валидации кода аэропорта прибытия"""
    code = 207032


class FlightDatetimeValidationError(BaseValidationError):
    u"""Ошибка валидации времени вылета"""
    code = 207033


class BookingClassValidationError(BaseValidationError):
    u"""Ошибка валидации класса бронирования"""
    code = 207034


class FlightValidationError(BaseValidationError):
    u"""Ошибка валидации номера рейса"""
    code = 207035


class AirlineValidationError(BaseValidationError):
    u"""Ошибка валидации кода авиакомпании"""
    code = 207036


ERRORS_MAPPING = {
    'origin': OriginValidationError,
    'destination': DestinationValidationError,
    'flight_datetime': FlightDatetimeValidationError,
    'booking_class': BookingClassValidationError,
    'number': FlightValidationError,
    'airline': AirlineValidationError,
}


class AvailableMealJSONService(CommonJSONService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_available_meal_service', 'v.0.0.1/json/meal', action='v001', controller=self)

    @languageaware
    @json_required
    def v001(self, message_lang, error_lang, json_request, **params):
        u"""Сервис доступного питания"""
        if not isinstance(json_request, dict):
            raise RequestFormatError(json_request)

        form = SegmentForm(data=json_request)
        if not form.is_valid():
            field = form.errors.iterkeys().next()
            raise ERRORS_MAPPING[field](json_request.get(field))

        meals = []
        flight_datetime = form.cleaned_data.pop('flight_datetime')
        meal_rule = MealRuleFilter().get_first(date=flight_datetime.date(), **form.cleaned_data)
        if meal_rule is not None:
            special_meal_vocab = getV('ssr_meal_codes')
            for code in meal_rule.special_meal:
                timelimit = MealTimelimitFilter().get_first(origin=form.cleaned_data['origin'], special_meal=code)
                if timelimit is None:
                    continue
                is_available_now = datetime.utcnow() + timedelta(hours=timelimit.timelimit) < flight_datetime
                try:
                    special_meal = special_meal_vocab[code]
                except KeyError:
                    continue
                name = get_json_ml(special_meal.names, message_lang)[message_lang or config.DEFAULT_SERVICE_LANG]
                meals.append({'code': code, 'timelimit': timelimit.timelimit, 'is_available_now': is_available_now, 'name': name})

        response = SuccessServiceResponse(data={'meals': meals})
        return self.render(response.to_dict())
