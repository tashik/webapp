# -*- coding: utf-8 -*-

from zope.interface.interfaces import ComponentLookupError

from pyramid.vocabulary import getV

from i18n_ws import _

from services.base.json_base import CommonJSONService, ServiceError, SuccessServiceResponse
from services.base.lang import languageaware
from services.json_services import get_json_ml


class ProfessionalAreasError(ServiceError):
    msg = _(u'Ошибка отображения списка родов деятельности')


class ProfessionalAreasJSONService(CommonJSONService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_professional_areas', 'v.0.0.1/json/professional_areas', controller=self, action='v001')

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        try:
            data = []
            prof_areas_codes = getV('professional_areas')
            for area in prof_areas_codes:
                key = str(area.professional_area_id)
                data.append({'code': key, 'title': get_json_ml(area.names, message_lang)})
        except (ComponentLookupError, TypeError):
            raise ProfessionalAreasError()

        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())