# -*- coding: utf-8 -*-

"""
$Id: geography.py 35221 2018-07-22 10:42:47Z apinsky $
"""

from pyramid.vocabulary import getV, getVI

import config
from services.base.json_base import (
    SuccessServiceResponse)
from services.base.lang import languageaware
from services.json_services import get_json_ml
from services.base.static import StaticService, DocumentCatalog, StaticDocument

_ALL_LANGUAGES = list(config.KNOWN_LANGUAGES) + [None]


class WorldRegionsJSONService(StaticService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_world_regions_service', 'v.0.0.1/json/world_regions', action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Справочник мировых регионов"""
        return self.serve_document(self.documents[message_lang])

    def build_document(self, message_lang):
        data = [{
            'title': get_json_ml(region.names, message_lang),
            'world_region_id': region.world_region_id,
        } for region in getV('world_regions')]
        response = SuccessServiceResponse(data)
        return StaticDocument(self.renderContent(response.to_dict()))

    def __init__(self):
        super(WorldRegionsJSONService, self).__init__()
        self.documents = DocumentCatalog(dependencies={'world_regions'},
                                         document_keys=_ALL_LANGUAGES,
                                         document_constructor=self.build_document)


class BaseCountriesJSONService(StaticService):
    def __init__(self):
        super(BaseCountriesJSONService, self).__init__()
        self.documents = DocumentCatalog(dependencies={'countries'},
                                         document_keys=_ALL_LANGUAGES,
                                         document_constructor=self.build_document)

    def build_document(self, message_lang):
        data = [self._encode_country(country, message_lang) for country in getV('countries')]
        response = SuccessServiceResponse(data)
        return StaticDocument(self.renderContent(response.to_dict()))

    def _encode_country(self, country, lang):
        raise NotImplementedError('_encode_country')


class CountriesJSONServiceV001(BaseCountriesJSONService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_countries_service_v001', 'v.0.0.1/json/countries', action='v001', controller=self)

    def _encode_country(self, country, lang):
        return {
            'code': country.country,
            'title': get_json_ml(country.names, lang),
            'world_region_id': country.world_region_id,
        }

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис стран"""
        return self.serve_document(self.documents[message_lang])


class CountriesJSONServiceV002(BaseCountriesJSONService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_countries_service_v002', 'v.0.0.2/json/countries', action='v002', controller=self)

    def _encode_country(self, country, lang):
        return {
            'code': country.country,
            'title': get_json_ml(country.names, lang),
            'world_region_id': country.world_region_id,
            'phone_code': country.phone_code
        }

    @languageaware
    def v002(self, message_lang, error_lang, **params):
        u"""Сервис стран"""
        return self.serve_document(self.documents[message_lang])


class POSCountriesJSONService(StaticService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_poscountries_service', 'v.0.0.1/json/poscountries', action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис стран, используемых в AFL_POS"""
        return self.serve_document(self.documents[message_lang])

    def build_document(self, message_lang):
        data = [{
            'code': country.country,
            'title': get_json_ml(country.names, message_lang),
        } for country in getVI('countries_by_use_in_pos_idx')(context=True)]
        if message_lang is None:
            data.sort(key=lambda country: country["code"])
        else:
            data.sort(
                key=lambda country: country["title"].get(
                    message_lang,
                    country["title"].get(
                        config.DEFAULT_SERVICE_LANG,
                        country["code"]
                    )
                )
            )
        response = SuccessServiceResponse(data)
        return StaticDocument(self.renderContent(response.to_dict()))

    def __init__(self):
        super(POSCountriesJSONService, self).__init__()
        self.documents = DocumentCatalog(dependencies={'countries'},
                                         document_keys=_ALL_LANGUAGES,
                                         document_constructor=self.build_document)


class CitiesJSONService(StaticService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_cities_service', 'v.0.0.1/json/cities', action='v001', controller=self)

    def _make_city_dict(self, city, lang):
        d = {
            'code': city.city,
            'country_code': city.country_code,
            'title': get_json_ml(city.names, lang),
            'location': None
        }
        if (city.lat is not None) and (city.lon is not None):
            d['location'] = dict(lat=city.lat, lon=city.lon)
        return d


    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис городов"""
        return self.serve_document(self.documents[message_lang])

    def build_document(self, message_lang):
        data = [self._make_city_dict(city, message_lang) for city in getV('cities')]
        response = SuccessServiceResponse(data)
        return StaticDocument(self.renderContent(response.to_dict()))

    def __init__(self):
        super(CitiesJSONService, self).__init__()
        self.documents = DocumentCatalog(dependencies={'cities'},
                                         document_keys=_ALL_LANGUAGES,
                                         document_constructor=self.build_document)


class AirportsJSONService(StaticService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_airports_service', 'v.0.0.1/json/airports', action='v001', controller=self)

    def _make_airport_dict(self, airport, lang):
        d = {
            'code': airport.airport,
            'city_code': airport.city,
            'title': get_json_ml(airport.names, lang),
            'location': None,
            'has_afl_flights': airport.has_afl_flights
        }
        if (airport.lat is not None) and (airport.lon is not None):
            d['location'] = dict(lat=airport.lat, lon=airport.lon)
        return d
    
    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис аэропортов"""
        return self.serve_document(self.documents[message_lang])

    def build_document(self, message_lang):
        data = [self._make_airport_dict(airport, message_lang) for airport in getV('airports')]
        response = SuccessServiceResponse(data)
        return StaticDocument(self.renderContent(response.to_dict()))

    def __init__(self):
        super(AirportsJSONService, self).__init__()
        self.documents = DocumentCatalog(dependencies={'airports'},
                                         document_keys=_ALL_LANGUAGES,
                                         document_constructor=self.build_document)

