# coding=utf-8
import config
from pyramid.exc import PyramidException
from pyramid.vocabulary import getV

from services.base.json_base import CommonJSONService, ServiceError, SuccessServiceResponse
from services.base.lang import languageaware
from services.json_services import get_json_ml
from i18n_ws import _


class MealCodesError(ServiceError):
    msg = _(u'Ошибка отображения списка кодов спецпитания')


class SSRMealCodes(CommonJSONService):
    """Сервис спецпитания"""

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_meals', 'v.0.0.1/json/special_meals', controller=self, action='index')

    @languageaware
    def index(self, message_lang, error_lang, **params):
        try:
            result = []
            for item in getV('ssr_meal_codes'):
                meals = get_json_ml(item.names, message_lang)
                result.append({'code': item.code, 'title': meals})
        except TypeError as e:
            raise MealCodesError(cause=e)
        except PyramidException as e:
            raise MealCodesError(cause=e)

        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())

