# -*- coding: utf-8 -*-

import os
import cherrypy
import demjson

from services.base.json_base import CommonJSONService, SuccessServiceResponse
from services.base.lang import languageaware

import config


class StaticDataJSONService(CommonJSONService):
    u"""Сервис являющийся 'прокси' для статических данных в файлах
        необходим для быстрого релиза/запуска сервисов, в статичном виде
        данные читаются из файла и пробрасываются сервисом
    """
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_static_data_service', 'v.0.0.1/json/static/:service_name', action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang, service_name):
        # заглушка пока нет справочника
        service_file_path = os.path.join(config.DATADIR, '%s.json' % service_name)

        if not os.path.exists(service_file_path):
            # если файла нет, логично 404 бросать
            raise cherrypy.NotFound()

        f = open(service_file_path)
        data = f.read()
        f.close()

        #создадим необходимую структуру json_services, заодно проверим валидность данных в файле
        json_data = demjson.decode(data)
        response = SuccessServiceResponse(json_data)
        return self.render(response.to_dict())