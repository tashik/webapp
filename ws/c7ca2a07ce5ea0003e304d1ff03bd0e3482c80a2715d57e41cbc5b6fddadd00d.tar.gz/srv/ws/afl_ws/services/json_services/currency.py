# -*- coding: utf-8 -*-
import cherrypy
import datetime
import json
from PyDecNumber import DecNumber

from pyramid.vocabulary import getV, getVI

from services.base.json_base import CommonJSONService, SuccessServiceResponse, BaseValidationError, \
    InvalidJSONFormatException
from services.base.lang import languageaware
from services.json_services import get_json_ml


class CurrencyNamesJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_currency_names_service', 'v.0.0.1/json/curnames/:currency_code', action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang, currency_code):
        u"""Сервис определения названия валюты по коду и языку"""
        try:
            currency = getV("currencies")[currency_code]
        except KeyError:
            raise cherrypy.NotFound()
        data = get_json_ml(currency.names, message_lang)
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class CurrencyJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_currency_service', 'v.0.0.1/json/currency/:country_code', action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang, country_code):
        u"""Сервис валют по странам"""
        try:
            data = {
                'currency': getV('countries')[country_code].currency_code
            }
        except KeyError:
            raise cherrypy.NotFound()
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class InvalidCurrencyException(BaseValidationError):
    u"""Некорректный код валюты"""
    code = 207023


class InvalidCurrencyPairException(BaseValidationError):
    u"""Некорректная пара валют"""
    code = 207023

    def __init__(self, cur1, cur2):
        self.cur1 = cur1
        self.cur2 = cur2
        super(InvalidCurrencyPairException, self).__init__(
            u"%s %s" % (cur1, cur2)
        )


class ICERJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_icer_service', 'v.0.0.1/json/icer/:currency', action='v001', controller=self)
        dispatcher.connect(
            'json_icer_reload_from_db', 'reload_icer_vocab_from_db',
            action='reload_icer_vocab_from_db', controller=self
        )

    @languageaware
    def v001(self, message_lang, error_lang, currency, prices="", **kwargs):
        if not prices:
            raise InvalidJSONFormatException("no prices")
        try:
            prices = json.loads(prices)
        except:
            raise InvalidJSONFormatException(prices)
        icer_voc = getV("icer")
        if kwargs.get("reload"):
            icer_voc.reloadICER()
        cur_voc = getV("currencies")
        if currency not in cur_voc:
            raise InvalidCurrencyException(currency)
        for rec in prices:
            try:
                cur, price = rec["currency"], rec["price"]
            except KeyError:
                return InvalidJSONFormatException(rec)
            if(cur == currency):
                minor_unit = cur_voc[currency].minor_unit
                price = DecNumber(price, minor_unit)
                rec["price"] = str(price)
                continue
            if cur not in cur_voc:
                raise InvalidCurrencyException(cur)
            try:
                icer = icer_voc[(cur, currency)]
            except KeyError:
                raise InvalidCurrencyPairException(
                    cur, currency
                )
            if icer.updated < datetime.datetime.now().date():
                raise InvalidCurrencyPairException(
                    cur, currency
                )
            price *= icer.rate
            minor_unit = cur_voc[currency].minor_unit
            price = DecNumber(price, minor_unit)
            rounding_unit = cur_voc[currency].rounding_unit
            # По требованию IATA, выбирается ближайшее целое
            # число по возрастанию, кратное rounding_unit
            # В формуле ниже не возникнет деления на нуль
            # в силу ограничения, прописанного в интерфейсе
            # ICurrency
            price = price + rounding_unit - (price % rounding_unit or rounding_unit)
            rec["currency"] = currency
            rec["price"] = str(price)
        response = SuccessServiceResponse({"currency": currency, "prices": prices})
        return self.render(response.to_dict())

    def reload_icer_vocab_from_db(self):
        """
        Обновляет справочник icer из базы данных
        """
        getV('icer').preload()
        return self.render("SUCCESS")


class CalcurrJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_calcurr_service', 'v.0.0.1/json/calcurr', action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang):
        u"""Сервис валют, используемых в калькуляторе валют по ICER"""
        data = sorted(
            cur.code
            for cur in getVI(
                "currencies_by_used_in_calc_idx"
            )(
                context=True
            )
        )
        # заглушка: рубль, евро и доллар должны идти первыми
        if "USD" in data:
            data.remove("USD")
            data.insert(0, "USD")
        if "EUR" in data:
            data.remove("EUR")
            data.insert(0, "EUR")
        if "RUB" in data:
            data.remove("RUB")
            data.insert(0, "RUB")
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())