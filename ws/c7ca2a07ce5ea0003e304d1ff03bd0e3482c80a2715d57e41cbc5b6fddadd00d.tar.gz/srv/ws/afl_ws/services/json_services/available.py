# -*- coding: utf-8 -*-

"""
$Id: available.py 10966 2015-02-12 01:15:52Z ogambaryan $
"""


from pyramid.vocabulary import getV

from services.base.json_base import CommonJSONService, SuccessServiceResponse
from services.base.lang import languageaware


class AvailableCitiesJSONService(CommonJSONService):
    
    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_available_cities_service', 'v.0.0.1/json/booking/available_cities', action='v001', controller=self)
    
    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис городов"""
        cities = getV('cities')
        data = []
        for city in cities:
            if city.can_book:
                data.append(city.city)
        
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())


class HasFlightAirportsJSONService(CommonJSONService):

    _cacheable = True

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_has_flight_airports_service', 'v.0.0.1/json/has_flight_airports', action='v001', controller=self)

    def v001(self, **params):
        u"""Сервис кодов аэропортов, куда летает Аэрофлот"""
        airports = getV('airports')
        data = [airport.airport for airport in airports if airport.has_afl_flights]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())
