# -*- coding: utf-8 -*-


from pyramid.vocabulary import getV

from services.base.lang import languageaware
from services.base.json_base import CommonJSONService,SuccessServiceResponse


def get_airlines_info_lp():
    airlines = getV('airlines')
    airlines_info_lp = {}
    for a in airlines:
        if a.loyalty_program_id:
            lp_id = a.loyalty_program_id
            lp_airlines = airlines_info_lp.setdefault(lp_id, [])
            lp_airlines.append({
                "airline_code": a.iata,
                "aliance": a.alliance,
                "airline_name": a.name_en
            })
    return airlines_info_lp


class LoyaltyProgramsJSONService(CommonJSONService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_loyalty_programs', 'v.0.0.1/json/loyalty_programs',  action='v001', controller=self)

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        airlines_info_lp = get_airlines_info_lp()
        loyalty_programs = getV('loyalty_programs')
        data = []
        for lp in loyalty_programs:
            lp_id = lp.loyalty_program_id
            result = {
                'id': lp_id, 'name': lp.title, 
                'airline_name': None,
                'airline_code': None,
                'aliance': None,
                'siebel_code': lp.siebel_id
            }
            airlines_info = airlines_info_lp.get(lp_id)
            if airlines_info:
                for airline_info in airlines_info:
                    res = result.copy()
                    res.update(airline_info)
                    data.append(res)
            else:
                data.append(result)
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())
