# -*- coding: utf-8 -*-

from pyramid.i18n import translate
from pyramid.i18n.message import Message
import config

from ui.common import get_ws_languages

from services.base.json_base import SuccessServiceResponse

def append_lang_dic(msg, languages=None):
    u"""на основе Messages, List и текущих языков создает словарь язык:перевод"""
    result = {}
    if languages is None:
        languages = get_ws_languages()
    for lang in languages:
        text = translate(msg, domain='self_translate', target_language=lang)
        result[lang] = text
    return result


def translate_ML(ml):
    u"""на основе MLField и текущих языков создает словарь язык:перевод"""
    d = get_translate_dict(ml)
    msg = Message(d, domain='self_translate')
    result = append_lang_dic(msg)
    return result


def get_translate_dict(ml_element):
    u"""преобразует MLField в словарь язык:перевод"""
    result = {}
    for translation in ml_element:
        parts = translation.split(':', 1)
        if len(parts) == 2:
            result[parts[0]] = parts[1]
    return result


def get_json_ml(ml, lang):
    translates = get_translate_dict(ml)
    langs = [lang] if lang else config.KNOWN_LANGUAGES
    res = {}

    for t_lang in langs:
        msg = translate(translates, domain='self_translate', target_language=t_lang)
        res[t_lang] = msg
    return res

