# -*- coding: utf-8 -*-
"""
$Id$
"""

from pyramid.vocabulary import getV
from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse, json_required, BaseValidationError
from services.json_services import get_json_ml, get_translate_dict


class FundsJSONService(CommonJSONService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_funds_service', 'v.0.0.1/json/funds', action='v001', controller=self)

    @staticmethod
    def _make_charity_fund_dict_v001(charity_fund, lang):

        d = {
              'names': get_json_ml(charity_fund.names, lang) if lang else get_translate_dict(charity_fund.names),
              'charity_id': charity_fund.charity_id,
              'logo_url': get_json_ml(charity_fund.logo_url, lang) if lang else get_translate_dict(charity_fund.logo_url),
              'image_url': get_json_ml(charity_fund.image_url, lang) if lang else get_translate_dict(charity_fund.image_url),
              'charity_short_description': get_json_ml(charity_fund.charity_short_description, lang) if lang else get_translate_dict(charity_fund.charity_short_description),
              'charity_description': get_json_ml(charity_fund.charity_description, lang) if lang else get_translate_dict(charity_fund.charity_description),
              'url': get_json_ml(charity_fund.url, lang) if lang else get_translate_dict(charity_fund.url),
              'transfer_conditions': get_json_ml(charity_fund.transfer_conditions, lang) if lang else get_translate_dict(charity_fund.transfer_conditions),
              'rss_url': charity_fund.rss_url,
              'stats_charity_funds_url': charity_fund.stats_charity_funds_url,
              'donate_miles_url': charity_fund.donate_miles_url,
              'donate_miles_mv_url': charity_fund.donate_miles_mv_url,
              'weight': charity_fund.weight,
              'contacts': get_json_ml(charity_fund.contacts, lang) if lang else get_translate_dict(charity_fund.contacts),
              'news_url': get_json_ml(charity_fund.news_url, lang) if lang else get_translate_dict(charity_fund.news_url),
              'news_mv_url': get_json_ml(charity_fund.news_mv_url, lang) if lang else get_translate_dict(charity_fund.news_mv_url)
        }

        return d

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        charity_funds_vocab = getV('charity_funds')
        loyalty_id = params.get('charity_id', None)
        data = []
        if not loyalty_id:
            data = [self._make_charity_fund_dict_v001(charity_fund, message_lang) for charity_fund in charity_funds_vocab if charity_fund.status == 'P']
        else:
            for charity_fund in charity_funds_vocab:
                if charity_fund.charity_id == loyalty_id and charity_fund.status == 'P':
                    data.append(self._make_charity_fund_dict_v001(charity_fund, message_lang))
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())