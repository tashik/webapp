# -*- coding: utf-8 -*-

from pyramid.vocabulary import getV
from services.json_services import translate_ML, get_json_ml

from services.base.lang import languageaware
from services.base.json_base import CommonJSONService, SuccessServiceResponse


class AircraftTypeJSONService(CommonJSONService):

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('json_aircraft_type_service', 'v.0.0.1/json/aircraft_type', action='v001', controller=self)

    def _null_str(self, s):
        if len(s) > 0:
            return s
        else:
            return None

    def _make_aircraft_types_dict_v001(self, aircraft_type, lang):
        d = {
              'title': get_json_ml(aircraft_type.names, lang),
              'code': aircraft_type.ohd_code,
              'iata': self._null_str(aircraft_type.iata),
              'icao': self._null_str(aircraft_type.icao),
              'pax_capacity': aircraft_type.pax_capacity,
              'cargo_capacity': aircraft_type.cargo_capacity,
              'f': aircraft_type.f,
              'c': aircraft_type.c,
              'y': aircraft_type.y
        }
        return d

    @languageaware
    def v001(self, message_lang, error_lang, **params):
        u"""Сервис типов судов"""
        aircraft_types = getV('aircraft_types')
        data = [self._make_aircraft_types_dict_v001(aircraft_type, message_lang) for aircraft_type in aircraft_types]
        response = SuccessServiceResponse(data)
        return self.render(response.to_dict())
