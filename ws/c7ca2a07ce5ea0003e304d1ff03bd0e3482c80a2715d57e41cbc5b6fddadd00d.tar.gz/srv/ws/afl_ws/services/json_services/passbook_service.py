# -*- coding: utf-8 -*-

"""Passbook integration.
$Id:
"""
from services.base.json_base import CommonJSONService, json_required, SuccessServiceResponse
from passbook import store_pnr_card, store_bonus_card, store_bpass_card

from log import log


class PassbookJSONService(CommonJSONService):
    _cacheable = False

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('passbook_pnr_service', 'v.0.0.1/json/passbook/pnr/:pnr_locator/:created', action='pnr_001', controller=self)
        dispatcher.connect('passbook_pnr_service_fast', 'v.0.0.1/json/passbook/pnr_update/:pnr_locator/:created', action='pnr_update_001', controller=self)

        dispatcher.connect('passbook_bonus_service', 'v.0.0.1/json/passbook/bonus/:sabre_id/:tier_level', action='bonus_001', controller=self)
        dispatcher.connect('passbook_bonus_service_fast', 'v.0.0.1/json/passbook/bonus_update/:sabre_id/:tier_level', action='bonus_update_001', controller=self)

        dispatcher.connect('passbook_bpass_service', 'v.0.0.1/json/passbook/bpass/:pnr/:passenger_id', action='bpass_001', controller=self)
        dispatcher.connect('passbook_bpass_service_fast', 'v.0.0.1/json/passbook/bpass_update/:pnr/:passenger_id', action='bpass_update_001', controller=self)

    @json_required
    def pnr_001(self, pnr_locator, created, json_string=None, name=None, **params):
        card_url = store_pnr_card(pnr_locator, created, json_string, log.passbook_logger, name=name)

        result = {'card_url': card_url}
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())

    @json_required
    def pnr_update_001(self, pnr_locator, created, json_string=None, name=None, **params):
        store_pnr_card(pnr_locator, created, json_string, log.passbook_logger, quiet_update=True, name=name)
        result = {}
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())

    @json_required
    def bonus_001(self, sabre_id, tier_level, json_string=None, **params):
        card_url = store_bonus_card(sabre_id, tier_level, json_string, log.passbook_logger)
        result = {'card_url': card_url}
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())

    @json_required
    def bonus_update_001(self, sabre_id, tier_level, json_string=None, **params):
        store_bonus_card(sabre_id, tier_level, json_string, log.passbook_logger, quiet_update=True)
        result = {}
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())

    @json_required
    def bpass_001(self, pnr, passenger_id, json_string=None, **params):
        card_url = store_bpass_card(pnr, passenger_id, json_string, log.passbook_logger)

        result = {'card_url': card_url}
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())

    @json_required
    def bpass_update_001(self, pnr, passenger_id, json_string=None, **params):
        store_bpass_card(pnr, passenger_id, json_string, log.passbook_logger, quiet_update=True)
        result = {}
        response = SuccessServiceResponse(result)
        return self.render(response.to_dict())
