# -*- coding: utf-8 -*-
from pyramid.vocabulary import getV
from services.base.json_base import CommonJSONService, SuccessServiceResponse
from services.json_services import translate_ML


class CO2Airports(CommonJSONService):
    """Сервис пар городов для данных о выбросах"""
    default_lang = 'en'

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('co2_airports', 'v.0.0.1/json/co2_airports', action='index', controller=self)

    def index(self, lang='en', **kwargs):
        co2_data, airports, cities = getV('emission'), getV('airports'), getV('cities')
        result, result_set = [], set()

        airports_data = {key: airports[key] for key in airports.keys()}
        cities_data = {key: cities[key] for key in cities.keys()}
        for item in co2_data:
            from_names = translate_ML(airports_data[item.airport_from].names)
            to_names = translate_ML(airports_data[item.airport_to].names)
            city_to_names = translate_ML(cities_data[airports_data[item.airport_to].city].names)
            city_from_names = translate_ML(cities_data[airports_data[item.airport_from].city].names)
            pair = item.airport_from + item.airport_to
            if pair not in result_set:
                result.append(dict((
                    ('from', item.airport_from),
                    ('to', item.airport_to),
                    ('from_name', from_names.get(lang, from_names.get(self.default_lang))),
                    ('to_name', to_names.get(lang, to_names.get(self.default_lang))),
                    ('from_city', airports_data[item.airport_from].city),
                    ('from_city_name', city_from_names.get(lang, city_from_names.get(self.default_lang))),
                    ('to_city', airports_data[item.airport_to].city),
                    ('to_city_name', city_to_names.get(lang, city_to_names.get(self.default_lang)))
                )))
            result_set.add(pair)

        response = SuccessServiceResponse({'airports': result}).to_dict()
        return self.render(response)