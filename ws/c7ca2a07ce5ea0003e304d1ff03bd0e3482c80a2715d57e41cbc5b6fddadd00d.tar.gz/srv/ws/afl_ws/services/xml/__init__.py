# -*- coding: utf-8 -*-

"""
$Id: $
"""


import sys
import cherrypy

from lxml import etree

from zope.interface.interface import Interface
from zope.interface.declarations import implements

from pyramid.exc import PyramidException
from pyramid.i18n import translate
from pyramid.ui.page import CPService, Service
from pyramid.ui.error.report import StdErrorReporter

from services.base import ErrorHandling


def set_lang_attr(el, languages):
    try:
        languages[1]
    except IndexError:
        try:
            el.attrib['lang'] = languages[0]
        except IndexError:
            pass


def append_lang_nodes(msg, parent, languages, tag_name='name'):
    for lang in languages:
        el = etree.SubElement(parent, tag_name)
        el.attrib['{http://www.w3.org/XML/1998/namespace}lang'] = lang
        el.text = translate(msg, domain='self_translate', target_language=lang)


class BadParamsException(PyramidException):
    pass


class InvalidRouteException(PyramidException):
    pass


class IXMLService(Interface):
    pass


class XMLErrorReporter(StdErrorReporter):
    def for_webpage(self, exc, tb):
        t, error, tb = sys.exc_info()
        error_code = 0
        if getattr(error, 'error_code', None):
            error_code = error.code

        cherrypy.response.headers['Content-Type'] = 'text/xml'

        if exc.__class__.__name__ in ('AwardsCalculatorException', 'BadParamsException',
                                      'InvalidRouteException', 'MilesCalculatorException'):
            cherrypy.response.status = 404
        else:
            cherrypy.response.status = 500

        root = etree.Element('errors')
        error_el = etree.Element('error')
        error_el.attrib['code'] = unicode(error_code)
        error_el.attrib['type'] = str(error.__class__.__name__)
        error_el.text = unicode(str(error), 'utf-8')
        root.append(error_el)

        return etree.tostring(root, xml_declaration=True, encoding='utf-8', pretty_print=True)


class XMLService(Service):
    u"""Сервис, поддерживающий формат данных XML"""

    _content_type = 'text/xml'

    def _renderContent(self, content, **kwargs):
        return etree.tostring(content, xml_declaration=True, encoding='utf-8', pretty_print=True)

class CPXMLService(XMLService, CPService):
    u"""Сервис, поддерживающий формат данных XML и использующий CherryPy"""


class BaseXMLService(ErrorHandling, CPXMLService):
    implements(IXMLService)
