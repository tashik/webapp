# -*- coding: utf-8 -*-
from lxml import etree

from pyramid.i18n import translate
from pyramid.ui.page import CPService
from pyramid.vocabulary import getV

from services.xml import BaseXMLService, set_lang_attr, append_lang_nodes
from ui.common import get_ws_languages


class AircraftTypeXMLService(BaseXMLService):
    u"""Сервис типов судов"""

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('xml_aircraft_type_service', 'v.0.0.1/xml/aircraft_type', action='v001', controller=self)

    def v001(self, **params):
        languages = get_ws_languages()
        aircraft_types = getV('aircraft_types')
        root = etree.Element('aircraft_types')
        set_lang_attr(root, languages)
        for aircraft_type in aircraft_types:
             aircraft_type_el = etree.SubElement(root, 'aircraft_type')
             aircraft_type_el.attrib['code'] = aircraft_type.ohd_code
             if len(aircraft_type.iata) > 0:
                aircraft_type_el.attrib['iata'] = aircraft_type.iata
             if len(aircraft_type.icao) > 0:
                aircraft_type_el.attrib['icao'] = aircraft_type.icao
             if aircraft_type.pax_capacity is not None:
                aircraft_type_el.attrib['pax_capacity'] = unicode(aircraft_type.pax_capacity)
             if aircraft_type.cargo_capacity is not None:
                aircraft_type_el.attrib['cargo_capacity'] = unicode(aircraft_type.cargo_capacity)
             if aircraft_type.f is not None:
                aircraft_type_el.attrib['f'] = unicode(aircraft_type.f)
             if aircraft_type.c is not None:
                aircraft_type_el.attrib['c'] = unicode(aircraft_type.c)
             if aircraft_type.y is not None:
                aircraft_type_el.attrib['y'] = unicode(aircraft_type.y)
             append_lang_nodes(aircraft_types[aircraft_type.aircraft_type_id].title, aircraft_type_el, languages)

        return self.render(root)