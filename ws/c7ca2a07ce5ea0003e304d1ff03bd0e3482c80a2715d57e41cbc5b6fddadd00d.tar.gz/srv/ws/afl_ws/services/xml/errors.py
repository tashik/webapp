# -*- coding: utf-8 -*-

"""
$Id: errors.py 10966 2015-02-12 01:15:52Z ogambaryan $
"""
import cherrypy
import os
import re
from lxml import etree
from pyramid.ui.utils import xmlQuote as xml_quote
from services.xml import BaseXMLService

import config


DATE_RE = re.compile(r'^\d{4}-\d{2}-\d{2}$')
EVENT_ID_RE = re.compile(r'^[0-9a-zA-Z-]+[0-9a-zA-Z.-]*$')

class ErrorsXMLService(BaseXMLService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('svc_errors', 'services/errors', controller=self, action='index')
        dispatcher.connect('svc_errors_day', 'services/errors/{d}', controller=self, action='day')
        dispatcher.connect('svc_errors_details', 'services/errors/{d}/{event_id}', controller=self, action='details')

    def index(self, *args, **kwargs):
        base = config.VIRTUAL_BASE + '/services/errors'
        root = etree.Element('days')
        for d in sorted(os.listdir(config.ERRORDIR)):
            if DATE_RE.match(d):
                root.append(etree.Element('day', date=d, href='/'.join((base, d))))
        return self.render(root)

    def day(self, d):
        if not DATE_RE.match(d):
            raise cherrypy.HTTPError(404, 'Invalid Date')
        index_path = '/'.join((config.ERRORDIR, d, 'index.tsv'))
        if not os.path.exists(index_path):
            raise cherrypy.NotFound()

        root = etree.Element('errors', date=d)
        with open(index_path, 'r') as f:
            for error_kwargs in self._day(f):
                root.append(etree.Element('error', error_kwargs))
        return self.render(root)

    def _day(self, f):
        header = f.readline()
        columns = header.rstrip().split('\t')
        for line in f.xreadlines():
            elements = line.rstrip().split('\t')
            hms, exc_type = elements[0].split('-')
            exc_type = exc_type.split('.')[0]
            parts = {'time': hms, 'exc_type': exc_type}
            parts.update(dict(zip(columns, elements)))
            for key_value in elements[len(columns):]:
                key, value = key_value.split('=', 1)
                parts[key] = xml_quote(value)
            yield parts

    def details(self, *args, **kw):
        if cherrypy.request.login not in config.ERROR_DETAILS_ACCESS:
            raise cherrypy.HTTPError(403, 'Forbidden')
        return self._details(*args, **kw)

    def _details(self, d, event_id):
        if not DATE_RE.match(d):
            raise cherrypy.HTTPError(404, 'Invalid Date')
        if not EVENT_ID_RE.match(event_id):
            raise cherrypy.HTTPError(404, 'Invalid Event Id')

        details_path = '/'.join((config.ERRORDIR, d, event_id))
        if not os.path.exists(details_path):
            raise cherrypy.NotFound()

        cherrypy.response.headers['Content-Type'] = 'application/xml; charset=UTF-8'
        return open(details_path).read()
