# -*- coding: utf-8 -*-

# Многие сервисы возвращают данные, которые базируются на внешних источниках (например, vocabs)
# и относительно редко изменяются, при этом имеют ограниченное пространство ключей (количество возможных комбинаций).
# В этом случае мы можем заранее заготовить все возможные варианты ответов сервиса и сохранить их в памяти.
# При изменении исходных данных (при приходе обновления справочников из vocabs) - производить перерасчет.

import cherrypy
import hashlib
import json
import logging

from pyramid.ui.page import CPService
from services.base.json_base import ICommonJSONService
from zope.interface.declarations import implements

from services.base import ErrorHandling
import config

CATALOG_REGISTRY = []

class StaticDocument(object):
    def __init__(self, serialized_document):
        self.body = serialized_document
        self.etag = '"%s"' % hashlib.md5(serialized_document).hexdigest()


# TODO: хранить кэш в транзакционном хранилище (MVCCVocabulary)
# TODO: сравнивать старую и новую версии документов, если не совпадают - добавлять к etag время изменения

class DocumentCatalog(object):
    def __init__(self, dependencies, document_keys, document_constructor):
        assert isinstance(dependencies, set)
        self.dependencies = dependencies
        self.document_keys = document_keys
        self.document_constructor = document_constructor
        self.rebuild_documents()
        CATALOG_REGISTRY.append(self)

    def __getitem__(self, key):
        if not isinstance(key, tuple):
            key = (key,)
        return self.serialized_documents[key]

    def rebuild_documents(self):
        logging.info('Rebuilding static documents for %s' % ' '.join(self.dependencies))
        serialized_documents = {}
        for key in self.document_keys:  # None - сообщения на всех языках
            if not isinstance(key, tuple):
                key = (key,)
            serialized_documents[key] = self.document_constructor(*key)
        self.serialized_documents = serialized_documents  # атомарно заменяем


class StaticService(ErrorHandling, CPService):
    implements(ICommonJSONService)

    documents = NotImplemented

    # в производных классах в конструкторе переопределяем атрибут documents:
    #   self.documents = DocumentCatalog(dependencies={'airports'},
    #                                    document_keys=ALL_LANGUAGES,
    #                                    document_constructor=build_document)

    def _json_to_str(self, d):
        # Переводим строку в str, иначе UnicodeEncodeError: 'latin-1' codec can't encode characters
        # в cherrypy/_cpwsgi.py
        return json.dumps(d, ensure_ascii=False).encode('utf-8')
    
    def renderErrors(self, errors):
        errors = super(CPService, self).renderErrors(errors)
        return self._json_to_str({'errors': errors})

    def renderContent(self, content):
        return self._json_to_str(content)

    @classmethod
    def serve_document(cls, document):
        # См. https://ru.wikipedia.org/wiki/HTTP_ETag
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            if key in cherrypy.response.headers:
                del cherrypy.response.headers[key]
        cherrypy.response.headers['Cache-Control'] = 'max-age=%s' % config.STATIC_DOCUMENT_CACHING_PERIOD
        cherrypy.response.headers['ETag'] = document.etag
        cherrypy.response.headers['Content-Type'] = 'application/json; charset=utf-8'
        request = cherrypy.request

        conditions = request.headers.elements('If-None-Match') or []
        conditions = [str(x) for x in conditions]
        if conditions == ['*'] or document.etag in conditions or ('W/%s' % document.etag) in conditions:
            raise cherrypy.HTTPRedirect([], 304)

        return document.body


def on_server_init():
    for catalog in CATALOG_REGISTRY:
        catalog.rebuild_documents()

def on_vocab_change(changed_vocabs, catalogs=CATALOG_REGISTRY):
    for catalog in catalogs:
        if catalog.dependencies & changed_vocabs:
            catalog.rebuild_documents()

