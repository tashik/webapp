# -*- coding: utf-8 -*-

"""
$Id: __init__.py 4009 2014-04-07 18:03:54Z apinsky $
"""
