# -*- coding: utf-8 -*-

"""
$Id: test_base_json.py 10966 2015-02-12 01:15:52Z ogambaryan $
"""


import sys
import testoob
import time
import unittest
import cherrypy
import json

from StringIO import StringIO

from pyramid.tests import testlib

from services.base.json_base import (
    ServiceErrorDescription,
    ServiceResponse,
    SuccessServiceResponse,
    FailureServiceResponse,
    ParamsValidationError,
    MalformedRequestError,
    JSONServiceErrorReporter,
    CommonJSONService,
    BaseValidationError,
    ContentTypeJSONRequiredException,
    InvalidJSONFormatException,
    json_required,
)


class ServiceMock(CommonJSONService):
    pass


class TestServiceError(unittest.TestCase):
    u"""Тест класса ошибки сервисов"""

    def test_create(self):
        error = ServiceErrorDescription(1234, u"xyz")
        self.assertEqual(1234, error.code)
        self.assertEqual(u"xyz", error.message)
        self.assertEqual(None, error.value)
        self.assertEqual(None, error.dbg)

        error = ServiceErrorDescription(code=1234, message=u"xyz", value=u"abcd", dbg=u"5678")
        self.assertEqual(1234, error.code)
        self.assertEqual(u"xyz", error.message)
        self.assertEqual(u"abcd", error.value)
        self.assertEqual(u"5678", error.dbg)

    def test_create_error(self):
        self.assertRaises(AssertionError, ServiceErrorDescription, code="1234", message=u"xyz")
        self.assertRaises(AssertionError, ServiceErrorDescription, code=1234, message=None)
        self.assertRaises(AssertionError, ServiceErrorDescription, code=-1234, message=u"1234")
        self.assertRaises(AssertionError, ServiceErrorDescription, code=1234, message=u"")


class TestServiceResponse(unittest.TestCase):
    u"""Тест класса ошибки сервисов"""

    def test_create(self):
        response = ServiceResponse(True, data=u"1234")
        self.assertTrue(response.success)
        self.assertEqual(0, len(response.errors))
        self.assertEqual(u"1234", response.data)

        response = ServiceResponse(False, errors=[ServiceErrorDescription(10, u"1234")])
        self.assertFalse(response.success)
        self.assertEqual(1, len(response.errors))
        self.assertEqual(10, response.errors[0].code)
        self.assertTrue(response.data is None)

    def test_create_error(self):
        self.assertRaises(AssertionError, ServiceResponse, success=1234, data=u"1234")
        self.assertRaises(AssertionError, ServiceResponse, success=True, errors=u"1234")

        self.assertRaises(ValueError, ServiceResponse, success=True, errors=[1, 2, 3], data=u"1234")
        self.assertRaises(ValueError, ServiceResponse, success=True, errors=[], data=None)

        self.assertRaises(ValueError, ServiceResponse, success=False, errors=[], data=None)
        self.assertRaises(ValueError, ServiceResponse, success=False, errors=[1, 2, 3], data="1234")

    def test_to_dict(self):
        response = ServiceResponse(True, data=u"1234")
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(True, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))
        self.assertEqual(0, len(data['errors']))
        self.assertEqual(u"1234", data['data'])

        response = ServiceResponse(False, errors=[ServiceErrorDescription(10, u"1234", u"xyz", "1234567890")])
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(False, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))

        self.assertEqual(1, len(data['errors']))
        error = data['errors'][0]
        self.assertTrue(isinstance(error, dict))
        self.assertEqual(4, len(error))
        self.assertEqual(10, error['code'])
        self.assertEqual(u"1234", error['message'])
        self.assertEqual(u"xyz", error['value'])
        self.assertEqual("1234567890", error['dbg'])

        self.assertTrue(data['data'] is None)


class TestSuccessServiceResponse(unittest.TestCase):
    def test_create(self):
        response = SuccessServiceResponse(u"1234")
        self.assertTrue(response.success)
        self.assertEqual(0, len(response.errors))
        self.assertEqual(u"1234", response.data)

    def test_to_dict(self):
        response = SuccessServiceResponse(u"1234")
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(True, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))
        self.assertEqual(0, len(data['errors']))
        self.assertEqual(u"1234", data['data'])


class TestFailureServiceResponse(unittest.TestCase):
    def test_create(self):
        response = FailureServiceResponse([ServiceErrorDescription(10, u"1234")])
        self.assertFalse(response.success)
        self.assertEqual(1, len(response.errors))
        self.assertEqual(10, response.errors[0].code)
        self.assertTrue(response.data is None)

    def test_to_dict(self):
        response = FailureServiceResponse([ServiceErrorDescription(10, u"1234", u"xyz", "1234567890")])
        data = response.to_dict()
        self.assertEqual(3, len(data))
        self.assertEqual(False, data['isSuccess'])
        self.assertTrue(isinstance(data['errors'], list))

        self.assertEqual(1, len(data['errors']))
        error = data['errors'][0]
        self.assertTrue(isinstance(error, dict))
        self.assertEqual(4, len(error))
        self.assertEqual(10, error['code'])
        self.assertEqual(u"1234", error['message'])
        self.assertEqual(u"xyz", error['value'])
        self.assertEqual("1234567890", error['dbg'])

        self.assertTrue(data['data'] is None)


class TestJSONServiceErrorReporter(testlib.TestCaseWithCP):
    u"""Тест обработчика ошибок сервисов"""

    def setUp(self):
        super(TestJSONServiceErrorReporter, self).setUp()
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            cherrypy.response.headers[key] = 'Test-%s' % key
        cherrypy.response.headers['Content-Type'] = 'text/plain'
        cherrypy.response.status = 100

    def test_param_error(self):
        errs = [
            ServiceErrorDescription(100, u"Error 1", u"param1"),
            ServiceErrorDescription(101, u"Error 2", u"param2")
        ]
        exception = ParamsValidationError(errs)

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(2, len(response['errors']))

        self.assertEqual(100, response['errors'][0]['code'])
        self.assertEqual("Error 1", response['errors'][0]['message'])
        self.assertEqual("param1", response['errors'][0]['value'])
        self.assertTrue(response['errors'][0]['dbg'] is None)
        self.assertEqual(101, response['errors'][1]['code'])
        self.assertEqual("Error 2", response['errors'][1]['message'])
        self.assertEqual("param2", response['errors'][1]['value'])
        self.assertTrue(response['errors'][1]['dbg'] is None)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_request_error(self):
        err = ServiceErrorDescription(200, u"Error 3")
        exception = MalformedRequestError(err)

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(200, response['errors'][0]['code'])
        self.assertEqual("Error 3", response['errors'][0]['message'])
        self.assertTrue(response['errors'][0]['value'] is None)
        self.assertTrue(response['errors'][0]['dbg'] is None)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_service_error(self):
        err = ServiceErrorDescription(300, u"Error 4")
        exception = MalformedRequestError(err)

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exception, None)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(300, response['errors'][0]['code'])
        self.assertEqual("Error 4", response['errors'][0]['message'])
        self.assertTrue(response['errors'][0]['value'] is None)
        self.assertTrue(response['errors'][0]['dbg'] is None)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json', cherrypy.response.headers['Content-Type'])

        self.assertEqual(200, cherrypy.response.status)

    def test_unexpected_error(self):
        try:
            raise ValueError("DB access error")
        except ValueError:
            tmp = sys.exc_info()
            exc = tmp[1]
            tb = tmp[2]

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exc, tb)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(300000, response['errors'][0]['code'])
        self.assertEqual("DB access error", response['errors'][0]['message'])
        self.assertTrue(response['errors'][0]['value'] is None)
        self.assertFalse(response['errors'][0]['dbg'] is None)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json', cherrypy.response.headers['Content-Type'])

        self.assertEqual(500, cherrypy.response.status)

    def test_unexpected_error_message(self):
        try:
            raise ValueError
        except ValueError:
            tmp = sys.exc_info()
            exc = tmp[1]
            tb = tmp[2]

        reporter = JSONServiceErrorReporter(ServiceMock())
        raw_response = reporter.for_webpage(exc, tb)
        response = json.loads(raw_response)

        self.assertEqual(3, len(response))
        self.assertTrue('isSuccess' in response)
        self.assertTrue('errors' in response)
        self.assertTrue('data' in response)

        self.assertEqual(False, response['isSuccess'])
        self.assertTrue(response['data'] is None)
        self.assertEqual(1, len(response['errors']))

        self.assertEqual(300000, response['errors'][0]['code'])
        self.assertEqual("Unhandled error", response['errors'][0]['message'])
        self.assertTrue(response['errors'][0]['value'] is None)
        self.assertFalse(response['errors'][0]['dbg'] is None)

        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])

        self.assertEqual('application/json', cherrypy.response.headers['Content-Type'])

        self.assertEqual(500, cherrypy.response.status)


class TestCommonJSONService(testlib.TestCaseWithCP):
    u"""Тест обработчика ошибок сервисов"""

    def setUp(self):
        super(TestCommonJSONService, self).setUp()
        for key in ('Cache-Control', 'Expires', 'Last-Modified', 'X-Cacheable'):
            cherrypy.response.headers[key] = 'Test-%s' % key
        cherrypy.response.headers['Content-Type'] = 'text/plain'

    def test_render_cachable(self):
        resp = SuccessServiceResponse("1234")
        svc = ServiceMock()
        svc._cacheable = True
        svc.render(resp.to_dict())
        self.assertFalse('Cache-Control' in cherrypy.response.headers)
        self.assertFalse('Expires' in cherrypy.response.headers)
        self.assertTrue('Last-Modified' in cherrypy.response.headers)
        self.assertTrue('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual(time.strftime('%a, %d %b %Y %H:%M:%S GMT', time.gmtime()), cherrypy.response.headers['Last-Modified'])
        self.assertEqual('yes', cherrypy.response.headers['X-Cacheable'])

    def test_render_notcachable(self):
        resp = SuccessServiceResponse("1234")
        svc = ServiceMock()
        svc._cacheable = False
        svc.render(resp.to_dict())
        self.assertTrue('Cache-Control' in cherrypy.response.headers)
        self.assertTrue('Expires' in cherrypy.response.headers)
        self.assertFalse('Last-Modified' in cherrypy.response.headers)
        self.assertFalse('X-Cacheable' in cherrypy.response.headers)
        self.assertEqual('No-Cache', cherrypy.response.headers['Cache-Control'])
        self.assertEqual('Thu, 01 Jan 1970 00:00:00 GMT', cherrypy.response.headers['Expires'])


class TestBaseValidationError(unittest.TestCase):

    def test_create(self):
        class CertainValidationError(BaseValidationError):
            u"""Certain error"""
            code = 100500

        c = CertainValidationError('error value')
        self.assertEqual(len(c.error_descs), 1)

        error = c.error_descs[0]
        self.assertEqual(error.message, u'Certain error')
        self.assertEqual(error.code, 100500)
        self.assertEqual(error.dbg, 'CertainValidationError')
        self.assertEqual(error.value, 'error value')


class TestJSONRequired(unittest.TestCase):

    @json_required
    def method(self, json_request, *args, **kwargs):
        return json_request

    def test_json_required(self):
        with self.assertRaises(ContentTypeJSONRequiredException) as e:
            self.method()
        error = e.exception.error_descs[0]
        self.assertEqual(error.code, 207021)
        self.assertIsNone(error.value)
        self.assertEqual(error.dbg, 'ContentTypeJSONRequiredException')

        cherrypy.request.headers['content-type'] = 'application/x-www-form-urlencoded'
        with self.assertRaises(ContentTypeJSONRequiredException) as e:
            self.method()
        error = e.exception.error_descs[0]
        self.assertEqual(error.code, 207021)
        self.assertEqual(error.value, 'application/x-www-form-urlencoded')
        self.assertEqual(error.dbg, 'ContentTypeJSONRequiredException')

        cherrypy.request.headers['content-type'] = 'application/JSON'
        cherrypy.request.body = StringIO('{}')
        self.assertEqual(self.method(), {})

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO('{}')
        self.assertEqual(self.method(), {})

        cherrypy.request.headers['content-type'] = 'text/plain'
        cherrypy.request.body = StringIO('{}')
        self.assertEqual(self.method(), {})

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO('')
        with self.assertRaises(InvalidJSONFormatException) as e:
            self.method()
        error = e.exception.error_descs[0]
        self.assertEqual(error.code, 207022)
        self.assertEqual(error.value, '')
        self.assertEqual(error.dbg, 'InvalidJSONFormatException')

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO('{')
        with self.assertRaises(InvalidJSONFormatException) as e:
            self.method()
        error = e.exception.error_descs[0]
        self.assertEqual(error.code, 207022)
        self.assertEqual(error.value, '{')
        self.assertEqual(error.dbg, 'InvalidJSONFormatException')


if __name__ == "__main__":
    testoob.main()
