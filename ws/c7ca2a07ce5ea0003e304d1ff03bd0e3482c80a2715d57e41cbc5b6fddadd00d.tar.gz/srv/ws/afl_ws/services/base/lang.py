# -*- coding: utf-8 -*-

"""
$Id: lang.py 22647 2017-01-31 12:05:45Z oeremeeva $
"""


import config


def languageaware(method):
    u"""
        Декортатор проверяет наличие в запросе параметра lang:
        * если он есть, то устанавливает язык результата и язык ошибок в соответствие с ним
        * если его нет, то устанавливает язык ошибок в соответствие с текущим окружением, а язык сообщений оставляет неопределенным
        У метода, на котором применяется данный декаратор, в первые два аргумента передаются коды языков:
        * message_lang - запрашиваемый язык текстовых данных, предназначенных для отображения пользователям,
                         может быть None
        * error_lang - запрашиваемый язык сообщений об ошибках,
                       гарантированно имеет значение, отличное от None
    """
    def decorator(self, *args, **kwargs):
        lang = kwargs.pop('lang', None)
        if not lang:
            message_lang = None
            error_lang = config.DEFAULT_SERVICE_LANG
        else:
            lang = lang.lower()
            error_lang = config.DEFAULT_SERVICE_LANG if lang in config.KNOWN_LANGUAGES else None
            message_lang = lang if lang in config.KNOWN_LANGUAGES else None
        return method(self, message_lang, error_lang, *args, **kwargs)
    return decorator

