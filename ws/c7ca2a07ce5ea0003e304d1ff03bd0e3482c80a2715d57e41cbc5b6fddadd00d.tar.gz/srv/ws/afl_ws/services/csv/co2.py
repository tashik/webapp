# -*- coding: utf-8 -*-
import csv
import StringIO

from pyramid.ui.page import CPService
from pyramid.vocabulary import getV
from services.json_services import translate_ML

SERVICE_FILE_HEADER = ['from', 'to', 'distance', 'aircraft_type', 'aircraft_name', 'service_class', 'co2_emission']


class CO2AllData(CPService):
    _content_type = 'text/csv; charset=utf-8'
    delimiter = ','

    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('csv_co2', 'v.0.0.1/csv/co2.csv', action='index', controller=self)

    def index(self, lang='ru', **kwargs):
        coeffs, air_types = getV('coefficients'), getV('aircraft_types')
        air_types_data = {key: value for key, value in air_types.items()}
        sio = StringIO.StringIO()
        spamwriter = csv.writer(sio, delimiter=self.delimiter, quoting=csv.QUOTE_MINIMAL)
        spamwriter.writerow(SERVICE_FILE_HEADER)
        for item in getV('emission'):
            aircraft_names = translate_ML(air_types_data[str(item.aircraft_type)].names)
            for coeff_item in coeffs:
                spamwriter.writerow([
                    item.airport_from, item.airport_to, item.distance,
                    air_types_data[str(item.aircraft_type)].ohd_code,
                    aircraft_names.get(lang, aircraft_names.get('ru')), coeff_item.service_class,
                    round(item.emission * coeff_item.coefficient, 3)
                ])

        sio.seek(0)
        return self.render([line for line in sio.readlines()])