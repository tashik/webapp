# -*- coding: utf-8 -*-

"""
$Id: i18n_ws.py 22633 2017-01-30 13:09:52Z oeremeeva $
Функциональность i18n отключена
"""


import cherrypy

from zope.component import queryUtility
from zope.i18n.interfaces import IUserPreferredLanguages, ILanguageAvailability
from zope.interface import implements

from pyramid.utils import Singleton

import config

_ = unicode


PREFERRED_LANG_KEY = 'lang'


class CPParamsUserPreferredLanguages(object):
    u"""Предпочтительный язык для пользователя на основе параметров запроса.
    
    Извлекает данные о языке из параметров запроса.
    """

    __metaclass__ = Singleton
    implements(IUserPreferredLanguages)
    
    def getPreferredLanguages(self):
        cp_params = cherrypy.request.params
        lang = cp_params.get(PREFERRED_LANG_KEY)
        if lang:
            return [lang]
        return []
