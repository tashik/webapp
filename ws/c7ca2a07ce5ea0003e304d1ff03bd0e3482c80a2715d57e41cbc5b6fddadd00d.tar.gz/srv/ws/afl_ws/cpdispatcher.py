# -*- coding: utf-8 -*-

"""
$Id: cpdispatcher.py 37 2012-05-30 11:45:43Z achunaev $
"""

import cherrypy
from pyramid.utils import Config as config

def _createMountConfig(dispatcher_factory, path):
    u"""Создает конфигурацию для монтирования"""

    mount_cfg = dict()

    import cpconfig
    cfg = cpconfig.app_cfg.copy()
    cfg['request.dispatch'] = dispatcher_factory(prefix=path)

    mount_cfg.update({
        path: cfg
    })

    mount_cfg.update({
        '/favicon.ico': {
            'tools.staticfile.on': True,
            'tools.staticfile.filename': config.STATICDIR + '/favicon.ico',
            'tools.sessions.on': False,
            'request.dispatch': cherrypy.dispatch.Dispatcher(),
        }
    })

    return mount_cfg


def _getMainDispatcher(prefix=None):
    u"""Создает диспетчер и регистрирует маршруты и соответствующие
    им контроллеры.
    """

    dispatcher = cherrypy.dispatch.RoutesDispatcher()
    dispatcher.mapper.prefix = prefix

    from ui.root import RootPage, LoginPage
    # Login/Logout - должны идти первыми
    LoginPage()._connectToDispatcher(dispatcher)
    RootPage()._connectToDispatcher(dispatcher)

    from ui.debug import SetDebugPage
    SetDebugPage()._connectToDispatcher(dispatcher)

    from services.heartbeat import HeartbeatService
    HeartbeatService()._connectToDispatcher(dispatcher)

    ####################################################################################################################
    # SERVICES
    ####################################################################################################################

    ####################################################################################################################
    # XML Services
    ####################################################################################################################

    from services.xml.air import AircraftTypeXMLService
    AircraftTypeXMLService()._connectToDispatcher(dispatcher)

    from services.xml.errors import ErrorsXMLService
    ErrorsXMLService()._connectToDispatcher(dispatcher)

    ####################################################################################################################
    # JSON Services
    ####################################################################################################################

    from services.json_services.passbook_service import PassbookJSONService
    PassbookJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.offices import OfficeJSONServiceV002, OfficeJSONServiceV003
    OfficeJSONServiceV002()._connectToDispatcher(dispatcher)
    OfficeJSONServiceV003()._connectToDispatcher(dispatcher)

    from services.json_services import currency, geography
    geography.WorldRegionsJSONService()._connectToDispatcher(dispatcher)
    geography.CountriesJSONServiceV001()._connectToDispatcher(dispatcher)
    geography.CountriesJSONServiceV002()._connectToDispatcher(dispatcher)
    geography.CitiesJSONService()._connectToDispatcher(dispatcher)
    geography.AirportsJSONService()._connectToDispatcher(dispatcher)
    geography.POSCountriesJSONService()._connectToDispatcher(dispatcher)
    currency.CurrencyJSONService()._connectToDispatcher(dispatcher)
    currency.CurrencyNamesJSONService()._connectToDispatcher(dispatcher)
    currency.ICERJSONService()._connectToDispatcher(dispatcher)
    currency.CalcurrJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.ssr_meal_codes import SSRMealCodes
    SSRMealCodes()._connectToDispatcher(dispatcher)
    
    from services.json_services.available import AvailableCitiesJSONService, HasFlightAirportsJSONService
    AvailableCitiesJSONService()._connectToDispatcher(dispatcher)
    HasFlightAirportsJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.static_data import StaticDataJSONService
    StaticDataJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.air import AircraftTypeJSONService
    AircraftTypeJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.loyalty_programs import LoyaltyProgramsJSONService
    LoyaltyProgramsJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.professional_areas import ProfessionalAreasJSONService
    ProfessionalAreasJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.co2_calc import CO2Calculate, CO2VocabsUpdater
    CO2Calculate()._connectToDispatcher(dispatcher)
    CO2VocabsUpdater()._connectToDispatcher(dispatcher)

    from services.json_services.co2_airports import CO2Airports
    CO2Airports()._connectToDispatcher(dispatcher)

    from services.csv.co2 import CO2AllData
    CO2AllData()._connectToDispatcher(dispatcher)

    from services.json_services.additional_info import AdditionalInfoJSONService
    AdditionalInfoJSONService()._connectToDispatcher(dispatcher)

    from services.json_services.meal import AvailableMealJSONService
    AvailableMealJSONService()._connectToDispatcher(dispatcher)

    from notify import NotifyService
    NotifyService()._connectToDispatcher(dispatcher)

    from services.json_services.funds import FundsJSONService
    FundsJSONService()._connectToDispatcher(dispatcher)
    
    from services.json_services.ibeacons import BluetoothBeaconsService
    BluetoothBeaconsService()._connectToDispatcher(dispatcher)

    return dispatcher


# Конфигурация диспетчеров и локальные параметры CherryPy ----------------------

mount_cfg = _createMountConfig(_getMainDispatcher, config.VIRTUAL_BASE)
mount_cfg.update({(config.VIRTUAL_BASE + '/verify/run'): {
    'response.stream': True,
}})

from access import auth_paths
mount_cfg.update(auth_paths())
