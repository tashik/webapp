# -*- coding: utf-8 -*-

"""Passbook integration.
$Id:
"""

import json
import StringIO
import urlparse
import threading
import socket

from httplib import HTTPSConnection, HTTPConnection


from passbook.exc import PassbookConnectionException, PassbookHTTPStatusException, PassbookConnectionReadException
from passbook.exc import PassbookJSONResponseException, PassbookTimeoutConnectionException


class PassbookServiceConnection(object):
    u"""Физическое соединение с сервисами Passbook"""

    def __init__(self, url, method, authkey, user_agent, logger=None):
        o = urlparse.urlparse(url)
        self.host = o.hostname
        self.path = o.path
        self.lock = threading.Lock()
        if o.scheme == 'https': self._con = HTTPSConnection(o.hostname, o.port or 443)
        elif o.scheme == 'http': self._con = HTTPConnection(o.hostname, o.port or 80)
        else: assert 0

        self.method = method
        self.user_agent = user_agent
        self.authkey = authkey
        self.logger = logger

    def log(self, s):
        if self.logger: self.logger.debug(s)
        else: print s

    def call(self, data):
        assert isinstance(data, basestring)

        headers = {"Host": self.host,
                   "Content-Type": 'application/json; charset=utf-8',
                   "User-Agent": self.user_agent,
                   "AuthKey": self.authkey
                   }

        self.log(">>>>>>%s %s%s\n%s\n%s" % (self.method, self.host, self.path, headers, data))
        with self.lock:
            try:
                self._con.request(self.method, self.path, data, headers)
                http_resp = self._con.getresponse()
            except socket.timeout, e:
                self.log("<<<<<<\n ERROR - PassbookTimeoutConnectionException\n%s" % e)
                raise PassbookTimeoutConnectionException(exc=e)
            except socket.error, e:
                self.log("<<<<<<\n ERROR - PassbookConnectionException\n%s" % e)
                raise PassbookConnectionException(exc=e)
            except Exception, e:
                self.log("<<<<<<\n ERROR - PassbookConnectionException\n%s" % e)
                raise PassbookConnectionException(exc=e)

            try:
                http_resp_data = http_resp.read()# if http_resp.status == 200 else ''
            except Exception, e:
                self.log("<<<<<<\n ERROR - PassbookConnectionReadException\n%s" % e)
                raise PassbookConnectionReadException(exc=e)

        if http_resp.status not in (200, 201):
            self.log("<<<<<<\n ERROR - PassbookHTTPStatusException %s\n%s" % (http_resp.status, http_resp_data))
            raise PassbookHTTPStatusException(status=http_resp.status, data=http_resp_data)

        if http_resp_data:
            try:
                response = json.loads(http_resp_data)
            except Exception, e:
                self.log("<<<<<<\n ERROR - PassbookJSONResponseException\n%s" % http_resp_data)
                raise PassbookJSONResponseException(json_data=http_resp_data, exc=e)
        else:
            self.log("<<<<<< %s\n No data" % http_resp.status)
            return None

        location = http_resp.getheader('Location', None)
        if location:
            response['response_location'] = location

        self.log("<<<<<< %s\n%s" % (http_resp.status, response))

        return response

    def close(self):
        try:
            self._con.close()
        except:
            pass

    def __del__(self):
        self.close()
