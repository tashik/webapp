# -*- coding: utf-8 -*-

"""Passbook integration.
$Id:
"""

import hashlib
from zope.schema.interfaces import Interface
from zope.interface import implements

from pyramid.ormlite.schema import TextLine
from pyramid.ormlite.cache import MutableElement

import re

BARCODE_ALTERNATE_TEXT_RE = re.compile(r'("barcode_alternate_text":\s*")(.*?)("\s*,)')


def get_data_hash(data):
    data = BARCODE_ALTERNATE_TEXT_RE.sub(r'\1\3', data)
    return hashlib.md5(data).hexdigest()


class IPassbookCard(Interface):
    u"""Статус участника"""

    card_key = TextLine(db_column='card_key', primary_key=True, required=True, min_length=1, max_length=256, title=u'составной код карты')
    external_card_id = TextLine(db_column='external_card_id', title=u'Идентификатор карты в системе passbook', required=True)
    card_type = TextLine(db_column='card_type', required=True, title=u'Коэффициент для начисления миль')
    data_hash = TextLine(db_column='data_hash', title=u'Контрольная сумма')


class PassbookCardType:
    BONUS = 'BONUS'
    PNR = 'PNR'
    BPASS = 'BPASS'

    @classmethod
    def assert_card_type(cls, card_type):
        assert card_type in (cls.BOOKING, cls.PNR)


class PassbookCard(MutableElement):
    implements(IPassbookCard)
    p_table_name = 'passbook_cards'

    def is_new(self):
        return self.external_card_id is None


class PassbookPNRCard(PassbookCard):
    def __init__(self, pnr_locator=None, created=None, name=None, *args, **kwargs):
        key = '%s%s' % (pnr_locator, created.upper())
        if name:
            key = '%s%s' % (key, name.upper())
        super(PassbookPNRCard, self).__init__(card_key=key, card_type=PassbookCardType.PNR, *args, **kwargs)


class PassbookBONUSCard(PassbookCard):
    def __init__(self, sabre_id=None, tier_level=None, *args, **kwargs):
        key = '%s%s' % (sabre_id, tier_level.upper())
        super(PassbookBONUSCard, self).__init__(card_key=key, card_type=PassbookCardType.BONUS, *args, **kwargs)


class PassbookBPASSCard(PassbookCard):
    def __init__(self, pnr=None, passenger_id=None, *args, **kwargs):
        key = '%s%s' % (pnr.upper(), passenger_id.upper())
        super(PassbookBPASSCard, self).__init__(card_key=key, card_type=PassbookCardType.BPASS, *args, **kwargs)
