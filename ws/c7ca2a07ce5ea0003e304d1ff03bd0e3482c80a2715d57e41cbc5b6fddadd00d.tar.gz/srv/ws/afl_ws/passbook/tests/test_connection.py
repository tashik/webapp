# -*- coding: utf-8 -*-

"""
$Id: test_connection.py 9027 2014-12-04 19:32:10Z mbirin $
"""

import mock
import testoob
import unittest
import httplib
import socket


from passbook.exc import PassbookHTTPStatusException, PassbookConnectionException, PassbookTimeoutConnectionException, \
    PassbookConnectionReadException, PassbookJSONResponseException
from passbook.connection import PassbookServiceConnection

SERVICE_RESPONSE = '{"serial-number": "123456"}'


class TestPassbookServiceConnection(unittest.TestCase):
    url = 'https://127.0.0.4:12321/service-api'
    user_agent = 'Test-Agent'
    authkey = 'test-auth-key'

    def test___init__(self):
        con = PassbookServiceConnection(self.url, 'PUT', self.authkey, self.user_agent)
        self.assertEquals("127.0.0.4", con.host)
        self.assertEquals("/service-api", con.path)
        self.assertEquals(self.authkey, con.authkey)
        self.assertEquals('PUT', con.method)
        self.assertTrue(isinstance(con._con, httplib.HTTPSConnection))
        self.assertTrue(con.lock)


    @mock.patch('passbook.connection.HTTPSConnection.request')
    def test_call_con_errors(self, mock_https_connection):
        con = PassbookServiceConnection(self.url, 'PUT', self.authkey, self.user_agent)

        mock_https_connection.side_effect = socket.timeout
        self.assertRaises(PassbookTimeoutConnectionException, con.call, '')

        mock_https_connection.side_effect = socket.error
        self.assertRaises(PassbookConnectionException, con.call, '')

        mock_https_connection.side_effect = Exception
        self.assertRaises(PassbookConnectionException, con.call, '')

    @mock.patch('passbook.connection.HTTPSConnection.getresponse')
    @mock.patch('passbook.connection.HTTPSConnection.request')
    def test_call_response_read_errors(self, mock_https_connection, mock_response):
        con = PassbookServiceConnection(self.url, 'PUT', self.authkey, self.user_agent)

        resp = mock.MagicMock()
        resp.read.side_effect = Exception
        mock_response.return_value = resp
        self.assertRaises(PassbookConnectionReadException, con.call, '')

    @mock.patch('passbook.connection.HTTPSConnection.getresponse')
    @mock.patch('passbook.connection.HTTPSConnection.request')
    def test_call_response_http_status_errors(self, mock_https_connection, mock_response):
        con = PassbookServiceConnection(self.url, 'PUT', self.authkey, self.user_agent)

        resp = mock.MagicMock()
        resp.status = 422
        mock_response.return_value = resp
        self.assertRaises(PassbookHTTPStatusException, con.call, '')

    @mock.patch('passbook.connection.HTTPSConnection.getresponse')
    @mock.patch('passbook.connection.HTTPSConnection.request')
    def test_call_response_json_errors(self, mock_https_connection, mock_response):
        con = PassbookServiceConnection(self.url, 'PUT', self.authkey, self.user_agent)

        resp = mock.MagicMock()
        resp.status = 201
        resp.read.return_value = '<bad json_services'
        mock_response.return_value = resp
        self.assertRaises(PassbookJSONResponseException, con.call, '')

    @mock.patch('passbook.connection.HTTPSConnection.getresponse')
    @mock.patch('passbook.connection.HTTPSConnection.request')
    def test_call_response_json_errors(self, mock_https_connection, mock_response):
        con = PassbookServiceConnection(self.url, 'PUT', self.authkey, self.user_agent)

        resp = mock.MagicMock()
        resp.status = 201
        resp.read.return_value = SERVICE_RESPONSE
        resp.getheader.side_effect = lambda key, default: default
        mock_response.return_value = resp
        result = con.call('')

        headers = mock_https_connection.call_args[0][3]
        self.assertEqual(self.authkey, headers['AuthKey'])
        self.assertEqual('application/json; charset=utf-8', headers['Content-Type'])
        self.assertEqual(self.user_agent, headers['User-Agent'])

        self.assertEqual('123456', result['serial-number'])
        self.assertFalse(result.get('response_location', None))

        resp.getheader.side_effect = lambda key, default: 'https://some.url/card' if key == 'Location' else default
        result = con.call('')
        self.assertEqual('123456', result['serial-number'])
        self.assertEqual('https://some.url/card', result['response_location'])


if __name__ == "__main__":
    testoob.main()
