# -*- coding: utf-8 -*-

"""
$Id: test_model.py 18513 2016-04-19 15:09:47Z sbolxzhatov $
"""
from pyramid.ormlite.dbop import dbquery
from pyramid.ormlite.exc import PersistenceError

import testoob
from pyramid.tests.testlib import ModelTest, TestCaseWithPgDBAndVocabs

from passbook.model import PassbookCard, PassbookPNRCard


class TestPassbookCard(ModelTest, TestCaseWithPgDBAndVocabs):

    def setUp(self):
        super(TestPassbookCard, self).setUp()
        self.model = PassbookCard

    def test_interfaces(self):
        super(TestPassbookCard, self).test_interfaces()

    def test_load(self):
        dbquery("insert into passbook_cards values ('xxxx', '123456', 'PNR')")
        card = PassbookCard.load(card_key='xxxx')
        card.delete()
        self.assertRaises(PersistenceError, PassbookCard.load, card_key='xxxx')

    def test_PassbookPNRCard(self):
        card = PassbookPNRCard(pnr_locator='ABCDEF', created='2016-04-01')
        self.assertEqual(card.card_key, 'ABCDEF2016-04-01')
        card = PassbookPNRCard(pnr_locator='ABCDEF', created='2016-04-01', name='TESTOV/TEST')
        self.assertEqual(card.card_key, 'ABCDEF2016-04-01TESTOV/TEST')

if __name__ == "__main__":
    testoob.main()