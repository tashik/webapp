# -*- coding: utf-8 -*-

"""
$Id: test_passbook.py 21802 2016-12-01 13:41:24Z oeremeeva $
"""

import json
import mock
from pyramid.ormlite.exc import PersistenceError
import testoob
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs

from passbook import store_pnr_card, get_http_params, call_passbook_method, store_bonus_card, drop_card

import config
from passbook.model import PassbookCard, PassbookCardType, PassbookBONUSCard, get_data_hash


class TestPassbook(TestCaseWithPgDBAndVocabs):

    def test_get_data_hash(self):
        data_1 = """
            "barcode_alternate_text": "Обновлено/Updated 01.04.2015 13:36",
            "expiration_date":"2015-04-17T07:55:00.0Z",
        """
        data_2 = """
            "barcode_alternate_text": "Обновлено/Updated 01.04.2020 13:36",
            "expiration_date":"2015-04-17T07:55:00.0Z",
        """
        self.assertEqual(get_data_hash(data_1), get_data_hash(data_2))

        data_1 = """
            "barcode_alternate_text": "Обновлено/Updated 01.04.2015 13:36", "expiration_date":"2015-04-17T07:55:00.0Z",
        """
        data_2 = """
            "barcode_alternate_text": "Обновлено/Updated 01.04.2020 13:36", "expiration_date":"2016-01-01T00:00:00.0Z",
        """
        self.assertNotEqual(get_data_hash(data_1), get_data_hash(data_2))

    def test_get_http_params_delete(self):
        card = PassbookCard(card_key='XXXXXX', external_card_id='1234567', card_type=PassbookCardType.PNR)
        url, method, authkey = get_http_params(card, is_delete=True)
        self.assertEqual(config.PASSBOOK_ACTION_URL % '1234567', url)
        self.assertEqual('DELETE', method)
        self.assertEqual(config.PASSBOOK_URL['PNR']['AuthKey'], authkey)

        card.card_type = PassbookCardType.BONUS
        url, method, authkey = get_http_params(card, is_delete=True)
        self.assertEqual(config.PASSBOOK_ACTION_URL % '1234567', url)
        self.assertEqual('DELETE', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

    def test_get_http_params_post(self):
        card = PassbookCard(card_key='XXXXXX', external_card_id='1234567', card_type=PassbookCardType.PNR)
        url, method, authkey = get_http_params(card)
        self.assertEqual(config.PASSBOOK_ACTION_URL % '1234567', url)
        self.assertEqual('POST', method)
        self.assertEqual(config.PASSBOOK_URL['PNR']['AuthKey'], authkey)

        card.card_type = PassbookCardType.BONUS
        url, method, authkey = get_http_params(card)
        self.assertEqual(config.PASSBOOK_ACTION_URL % '1234567', url)
        self.assertEqual('POST', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

        card.card_type = PassbookCardType.BONUS
        url, method, authkey = get_http_params(card, card_name='GOLD')
        self.assertEqual(config.PASSBOOK_ACTION_URL % '1234567', url)
        self.assertEqual('POST', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

    def test_get_http_params_put(self):
        card = PassbookCard(card_key='XXXXXX', card_type=PassbookCardType.PNR)
        url, method, authkey = get_http_params(card)
        self.assertEqual(config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL['PNR']['BASIC'], url)
        self.assertEqual('PUT', method)
        self.assertEqual(config.PASSBOOK_URL['PNR']['AuthKey'], authkey)

        card.card_type = PassbookCardType.BONUS
        url, method, authkey = get_http_params(card)
        self.assertEqual(config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL['BONUS']['BASIC'], url)
        self.assertEqual('PUT', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

        card.card_type = PassbookCardType.BONUS
        url, method, authkey = get_http_params(card, card_name='BASIC')
        self.assertEqual(config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL['BONUS']['BASIC'], url)
        self.assertEqual('PUT', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

        url, method, authkey = get_http_params(card, card_name='SILVER')
        self.assertEqual(config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL['BONUS']['SILVER'], url)
        self.assertEqual('PUT', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

        url, method, authkey = get_http_params(card, card_name='GOLD')
        self.assertEqual(config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL['BONUS']['GOLD'], url)
        self.assertEqual('PUT', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)

        url, method, authkey = get_http_params(card, card_name='PLATINUM')
        self.assertEqual(config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL['BONUS']['PLATINUM'], url)
        self.assertEqual('PUT', method)
        self.assertEqual(config.PASSBOOK_URL['BONUS']['AuthKey'], authkey)


    @mock.patch('passbook.PassbookServiceConnection')
    def test_call_passbook_method_with_new_card(self, mock_con):
        card = PassbookCard(card_key='XXXXXX', card_type=PassbookCardType.PNR)
        card.data = "{'data': 1}"

        #пока что нет записи о карте
        self.assertRaises(PersistenceError, PassbookCard.load, card_key='XXXXXX')

        _con_call = mock.MagicMock()
        _con_call.call.return_value = {'serial_number': '123456'}
        mock_con.return_value = _con_call
        result = call_passbook_method(card)
        self.assertEqual(config.PASSBOOK_CARD_URL % '123456', result)

        #записали в БД
        card = PassbookCard.load(card_key='XXXXXX')
        self.assertEqual('123456', card.external_card_id)

    @mock.patch('passbook.threading.Thread')
    @mock.patch('passbook.PassbookServiceConnection')
    def test_call_passbook_method_with_thread(self, mock_con, mock_thread):
        card = PassbookCard(card_key='XXXXXX', card_type=PassbookCardType.PNR)
        card.data = "{'data': 1}"

        self.assertRaises(AssertionError, call_passbook_method, card, with_thread=True)

        card.external_card_id = '123456'
        result = call_passbook_method(card, with_thread=True)
        self.assertEqual(config.PASSBOOK_CARD_URL % '123456', result)
        self.assertEqual(1, mock_thread.call_count)

    @mock.patch('passbook.call_passbook_method')
    def test_store_pnr_card(self, mock_call):
        pnr_locator = 'XXXXXXX'
        created = '2014-10-12'

        key = '%s%s' % (pnr_locator, created)

        result = store_pnr_card(pnr_locator, created, "{'data': 1}")
        self.assertEqual(1, mock_call.call_count)

        mock_call.reset_mock()

        result = store_pnr_card(pnr_locator, created, "{'data': 1}", quiet_update=True)
        #карты не существует ничего не произошло тк "втихую" новую запись не обновляем
        self.assertEqual(0, mock_call.call_count)
        self.assertFalse(result)

        mock_call.reset_mock()

        card = PassbookCard(card_key=key, external_card_id='123456', card_type=PassbookCardType.PNR)
        card.save()

        result = store_pnr_card(pnr_locator, created, "{'data': 1}", quiet_update=True)
        #карта существует - обновляем втихую
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(result)

        mock_call.reset_mock()

        card.data_hash = get_data_hash("{'data': 1}")
        card.save()

        result = store_pnr_card(pnr_locator, created, "{'data': 1}", quiet_update=True)
        #хэш совпал - не обновляем
        self.assertEqual(0, mock_call.call_count)
        self.assertTrue(result)

        mock_call.reset_mock()

        result = store_pnr_card(pnr_locator, created, "{'data': 1}", quiet_update=False, name='TESTOV/TEST')
        # Из-за name создается другая карта
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(result)

        mock_call.reset_mock()

        result = store_pnr_card(pnr_locator, created, "{'data': 2}", quiet_update=True)
        #хэш не совпал - обновляем
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(result)

        mock_call.reset_mock()

        result = store_pnr_card(pnr_locator, created, "{'data': 2}")
        #хэш не совпал - обновляем
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(result)




    @mock.patch('passbook.drop_card')
    @mock.patch('passbook.call_passbook_method')
    def test_store_bonus_card(self, mock_call, mock_drop):
        sabre_id = '88822333'
        tier_level = 'BASIC'

        card_key = '%s%s' % (sabre_id, tier_level.upper())

        result = store_bonus_card(sabre_id, tier_level, "{'data': 1}")
        self.assertEqual(1, mock_call.call_count)

        mock_call.reset_mock()

        result = store_bonus_card(sabre_id, tier_level, "{'data': 1}", quiet_update=True)
        #ничего не произошло тк "втихую" новую запись не обновляем
        self.assertEqual(0, mock_call.call_count)
        self.assertFalse(result)

        mock_call.reset_mock()

        card = PassbookBONUSCard(sabre_id=sabre_id, tier_level=tier_level, external_card_id='123456')
        card.save()

        result = store_bonus_card(sabre_id, tier_level, "{'data': 1}", quiet_update=True)
        #карта существует - обновляем втихую
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(mock_call.mock_calls[0][2]['with_thread'])
        self.assertTrue(result)

        mock_call.reset_mock()

        card.data_hash = get_data_hash("{'data': 1}")
        card.save()

        result = store_bonus_card(sabre_id, tier_level, "{'data': 2}", quiet_update=True)
        #карта существует - хэш не совпал - обновили
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(mock_call.mock_calls[0][2]['with_thread'])
        self.assertTrue(result)

        mock_call.reset_mock()

        result = store_bonus_card(sabre_id, tier_level, "{'data': 1}", quiet_update=True)
        #карта существует - хэш совпал - не обновили
        self.assertEqual(0, mock_call.call_count)
        self.assertTrue(result)

        mock_call.reset_mock()

        result = store_bonus_card(sabre_id, 'GOLD', "{'data': 1}", quiet_update=True)
        self.assertEqual(1, mock_drop.call_count)
        #новую карту не можем втихую обновить счетчики не изменились
        self.assertEqual(0, mock_call.call_count)
        self.assertFalse(result)

        mock_call.reset_mock()
        mock_drop.reset_mock()

        result = store_bonus_card(sabre_id, 'GOLD', "{'data': 1}")
        self.assertEqual(0, mock_drop.call_count)
        self.assertEqual(1, mock_call.call_count)
        self.assertTrue(result)

        #убедимся что старая карта удалилась
        self.assertRaises(PersistenceError, card.reload)

    @mock.patch('passbook.call_passbook_method')
    def test_drop_card(self, mock_c):
        sabre_id = '88822333'
        tier_level = 'BASIC'

        card_key = '%s%s' % (sabre_id, tier_level.upper())
        card = PassbookBONUSCard(sabre_id=sabre_id, tier_level=tier_level, external_card_id='123456')

        drop_card(card, sabre_id, tier_level)

        sended_card = mock_c.call_args[0][0]
        json_data = json.loads(sended_card.data)
        self.assertDictEqual(json_data, {
            "voided": True,
            "header_fields": [{"key": "LoyaltyNumber", "value": "88822333"}],
            "back_fields": [{"key": "PasswordRecovery", "value": "https://www.aeroflot.ru/personal/pda/forgot_password"}],
            "localization": [
                {"lang": "ru", "values": [
                    {"key": "CardHolder", "value": "СРОК ДЕЙСТВИЯ КАРТЫ ИСТЕК", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "Действующая карта Apple Wallet участника программы 'Аэрофлот Бонус' доступна для загрузки по ссылке https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "СРОК ДЕЙСТВИЯ КАРТЫ ИСТЕК"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "en","values": [
                    {"key": "CardHolder", "value": "THE CARD IS EXPIRED", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "Active Aeroflot Bonus Apple Wallet card is available to download at this link https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "THE CARD IS EXPIRED"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "de", "values": [
                    {"key": "CardHolder", "value": "DIE KARTE IST ABGELAUFEN", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "Die aktive Apple Wallet-Karte von Aeroflot-Bonus kann in Ihrem persönlichen Konto heruntergeladen werden — https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "DIE KARTE IST ABGELAUFEN"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "es", "values": [
                    {"key": "CardHolder", "value": "LA TARJETA HA CADUCADO", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "La tarjeta activa de Aeroflot Bonus Apple Wallet está disponible para su descarga en su cuenta personal: https://www.aeroflot.ru/persona/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "LA TARJETA HA CADUCADO"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "fr", "values": [
                    {"key": "CardHolder", "value": "LA CARTE A EXPIRÉ", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "Une carte Aeroflot Bonus Apple Wallet active peut être téléchargée dans votre compte personnel — https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "LA CARTE A EXPIRÉ"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "it", "values": [
                    {"key": "CardHolder", "value": "LA CARTA È SCADUTA", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "La carta Apple Wallet Aeroflot Bonus attiva è disponibile per il download accedendo all'account personale: https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "LA CARTA È SCADUTA"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "ja", "values": [
                    {"key": "CardHolder", "value": "カードは失効しています。", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "Aeroflot Apple Wallet ボーナスカードは、下記の個人アカウントでダウンロードできます — https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "カードは失効しています。"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "ko", "values": [
                    {"key": "CardHolder", "value": "만료된 카드입니다", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "활성화된 Aeroflot 보너스 Apple Wallet 카드는 https://www.aeroflot.ru/personal/pda/profile/info에서 귀하 계정으로 다운로드받을 수 있습니다."},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "만료된 카드입니다"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]},
                {"lang": "zh", "values": [
                    {"key": "CardHolder", "value": "该卡已过期", "change_message": "%@"},
                    {"key": "CardHolderBack", "value": "您可以在您的个人帐户中下载有效的 Aeroflot Bonus Apple Wallet 卡 — https://www.aeroflot.ru/personal/pda/profile/info"},
                    {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                    {"key": "LoyaltyMiles", "value": ""},
                    {"key": "CustLoyaltyMembershipLevel", "value": ""},
                    {"key": "ExpirationDate", "value": "该卡已过期"},
                    {"key": "Callcenter", "value": "+7 (495) 780-50-50"},
                    {"key": "Expired_date", "value": ""}
                ]}
            ],
            "search_fields": [
                {"key": "CustLoyaltyMembershipID", "value": "88822333"},
                {"key": "FirstName", "value": ""},
                {"key": "LastName", "value": ""},
                {"key": "CustLoyaltyMembershipLevel", "value": "BASIC"}
            ]
        })


if __name__ == "__main__":
    testoob.main()