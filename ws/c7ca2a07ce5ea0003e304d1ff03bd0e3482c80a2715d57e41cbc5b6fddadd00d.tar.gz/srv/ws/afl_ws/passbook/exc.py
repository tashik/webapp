# -*- coding: utf-8 -*-

"""Passbook integration.
$Id:
"""

import traceback

from pyramid.exc import PyramidException


class PassbookException(PyramidException):
    msg = "Passbook Service Exception"
    code = 500000

    def __str__(self):
        # TODO: разобраться, почему lazy-трансляция здесь не работает, и нужно явно вызывать unicode(self.msg)
        #return getattr(self, 'msg', None) or self.__doc__ or self.__class__.__name__
        args = list([repr(a) for a in self.args])
        try:
            args.extend(['%s=%s' % (k, repr(v)) for k, v in self.kw.items()])
        except Exception, e:
            traceback.print_exc()
            return '{INTERNAL EXCEPTION %s, see error.log}' % e.__class__.__name__

        if hasattr(self, 'msg'):
            return u'%s: %s' % (unicode(self.msg), u', '.join(args))

        return self.__doc__ or self.__class__.__name__

    __unicode__ = lambda self: str(self)

    def __repr__(self):
        args = list([repr(a) for a in self.args])
        try:
            args.extend(['%s=%s' % (k, repr(v)) for k, v in self.kw.items()])
        except Exception, e:
            traceback.print_exc()
            return '{INTERNAL EXCEPTION %s, see error.log}' % e.__class__.__name__

        return u'%s:%s(%s)' % (self.__class__.__name__, self.code, u', '.join(args))

    def __call__(self):
        return str(self)


class PassbookTimeoutConnectionException(PassbookException): pass

class PassbookConnectionReadException(PassbookException): pass

class PassbookConnectionException(PassbookException): pass

class PassbookHTTPStatusException(PassbookException): pass

class PassbookJSONResponseException(PassbookException): pass