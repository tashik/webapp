# -*- coding: utf-8 -*-

"""Passbook integration.
$Id:
"""

import threading

from pyramid.ormlite.exc import PersistenceError

from passbook.connection import PassbookServiceConnection
from passbook.model import (PassbookCardType, PassbookPNRCard, PassbookBONUSCard, PassbookCard, get_data_hash,
    PassbookBPASSCard)

from mako.lookup import TemplateLookup
import config


def renderTemplate(tpl_file_name, **kw):
    tpl = TemplateLookup(directories=config.APPDIR, input_encoding='utf-8', output_encoding='utf-8').get_template(tpl_file_name)
    return tpl.render(**kw)


def get_http_params(card, card_name='BASIC', is_delete=False):
    if is_delete:
        url = config.PASSBOOK_ACTION_URL % card.external_card_id
        method = 'DELETE'
    elif card.is_new():
        url = config.PASSBOOK_ACTION_URL % config.PASSBOOK_URL[card.card_type][card_name]
        method = 'PUT'
    else:
        url = config.PASSBOOK_ACTION_URL % card.external_card_id
        method = 'POST'

    authkey = config.PASSBOOK_URL[card.card_type]['AuthKey']

    return url, method, authkey


def call_passbook_method(card, card_name='BASIC', logger=None, with_thread=False):

    url, method, authkey = get_http_params(card, card_name=card_name)

    con = PassbookServiceConnection(url, method, authkey, 'Aeroflot passbook client', logger=logger)

    def _call_con():
        try:
            return con.call(card.data)
        finally:
            con.close()

    if with_thread:
        assert card.external_card_id
        threading.Thread(target=_call_con).start()
        response = None
    else:
        response = _call_con()

    if response:
        card.external_card_id = response['serial_number']
        result = response.get('response_location', config.PASSBOOK_CARD_URL % card.external_card_id)
    else:
        result = config.PASSBOOK_CARD_URL % card.external_card_id

    card.save()

    return result


def store_pnr_card(pnr_locator, created, data, logger=None, quiet_update=False, name=None):

    card = PassbookPNRCard(pnr_locator, created, name=name)
    data_hash = get_data_hash(data)

    try:
        card.reload()
    except PersistenceError:
        if quiet_update:
            return

    if card.data_hash == data_hash:
        assert card.external_card_id
        return config.PASSBOOK_CARD_URL % card.external_card_id
    card.data = data
    card.data_hash = data_hash

    return call_passbook_method(card, logger=logger, with_thread=quiet_update)


TIER_LEVELS = ('BASIC', 'SILVER', 'GOLD', 'PLATINUM')


def store_bonus_card(sabre_id, tier_level, data, logger=None, quiet_update=False):
    tier_level = tier_level.upper()
    assert tier_level in TIER_LEVELS

    card = PassbookBONUSCard(sabre_id, tier_level)
    data_hash = get_data_hash(data)

    try:
        card.reload()
    except PersistenceError:
        _tier_levels = list(TIER_LEVELS)
        _tier_levels.remove(tier_level)
        for t in _tier_levels:
            old_card = PassbookBONUSCard(sabre_id, t)
            try:
                old_card.reload()
            except PersistenceError:
                continue
            if old_card.external_card_id:
                drop_card(old_card, sabre_id, t, logger)
            old_card.delete()

        if quiet_update:
            return

    if card.data_hash == data_hash:
        assert card.external_card_id
        return config.PASSBOOK_CARD_URL % card.external_card_id

    card.data = data
    card.data_hash = data_hash

    return call_passbook_method(card, tier_level, logger=logger, with_thread=quiet_update)


def drop_card(card, sabre_id, tier_level, logger=None):
    card.data = renderTemplate('/passbook/templates/deleted_card.json', sabre_id=sabre_id, tier_level=tier_level)
    card.data_hash = get_data_hash(card.data)
    call_passbook_method(card, tier_level, logger=logger)


def store_bpass_card(pnr, passenger_id, data, logger=None, quiet_update=False):

    card = PassbookBPASSCard(pnr, passenger_id)
    data_hash = get_data_hash(data)

    try:
        card.reload()
    except PersistenceError:
        if quiet_update:
            return

    if card.data_hash == data_hash:
        assert card.external_card_id
        return config.PASSBOOK_CARD_URL % card.external_card_id

    card.data = data
    card.data_hash = data_hash

    return call_passbook_method(card, logger=logger, with_thread=quiet_update)