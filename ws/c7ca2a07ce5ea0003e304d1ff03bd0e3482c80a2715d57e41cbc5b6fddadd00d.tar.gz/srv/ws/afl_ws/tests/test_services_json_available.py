# -*- coding: utf-8 -*-

"""
$Id: test_services_json_available.py 10966 2015-02-12 01:15:52Z ogambaryan $
"""

import testoob
import demjson

from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from rx.i18n.translation import SelfTranslationDomain

from services.json_services.available import AvailableCitiesJSONService, HasFlightAirportsJSONService

import models.airport
import models.geo
import _test_data
from _test_data import setup_vocabulary


class TestAvailableCitiesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)
    
    def setUp(self):
        super(TestAvailableCitiesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
    
    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAvailableCitiesService, self).tearDown()
    
    def registerVocabularies(self):
        super(TestAvailableCitiesService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)
    
    def test_service(self):
        svc = AvailableCitiesJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(6, len(items))
        
        for item in items:
            self.assertTrue(isinstance(item, basestring))
        self.assertTrue('UUX' in items)
        self.assertTrue('UUY' in items)
        self.assertTrue('UUZ' in items)
        self.assertTrue('UUU' in items)
        self.assertTrue('UUW' in items)
    
    def test_service_lang(self):
        svc = AvailableCitiesJSONService()
        response = svc.v001(lang='en')
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(6, len(items))
        
        self.assertTrue('UUX' in items)
        self.assertTrue('UUY' in items)
        self.assertTrue('UUZ' in items)
        self.assertTrue('UUU' in items)
        self.assertTrue('UUW' in items)
    
    def test_service_excessiveParams(self):
        svc = AvailableCitiesJSONService()
        response = svc.v001(param1='a', some_other='1234')
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(6, len(items))
        
        self.assertTrue('UUX' in items)
        self.assertTrue('UUY' in items)
        self.assertTrue('UUZ' in items)
        self.assertTrue('UUU' in items)
        self.assertTrue('UUW' in items)


class TestHasFlightAirportsJSONService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestHasFlightAirportsJSONService, self).setUp()
        self.s = HasFlightAirportsJSONService()

    def registerVocabularies(self):
        super(TestHasFlightAirportsJSONService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.airport.AirportsVocabulary)

    def test_service(self):
        response = self.s.v001()
        body = demjson.decode(response)
        self.assertEqual(body, {'data': ['XXZ', 'XXX'], 'errors': [], 'isSuccess': True})

    def test_excessive_params(self):
        response = self.s.v001(param1='a', some_other='1234')
        body = demjson.decode(response)
        self.assertEqual(body, {'data': ['XXZ', 'XXX'], 'errors': [], 'isSuccess': True})


if __name__ == '__main__':
    testoob.main()
