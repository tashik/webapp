# -*- coding: utf-8 -*-

"""
$Id: test_services_json_geography.py 3988 2014-04-04 15:17:18Z anovgorodov $
"""


from zope.component import globalSiteManager as gsm
from zope.i18n.interfaces import INegotiator, ILanguageAvailability

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from rx.i18n.translation import SelfTranslationDomain

from services.json_services.air import AircraftTypeJSONService

import testoob
import unittest
import demjson
import _test_data
from _test_data import setup_vocabulary
import config
import models.air


class TestAircraftTypeService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)
    
    def setUp(self):
        super(TestAircraftTypeService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
    
    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAircraftTypeService, self).tearDown()
    
    def registerVocabularies(self):
        super(TestAircraftTypeService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AircraftTypesVocabulary)
    
    def test_service(self):
        svc = AircraftTypeJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(1, len(items))
        
        aircraft_type = items[0]
        self.assertTrue(isinstance(aircraft_type, dict), aircraft_type.__class__)
        self.assertEqual(9, len(aircraft_type))
        self.assertTrue('code' in aircraft_type)
        self.assertEqual('OoOo', aircraft_type['code'])

        self.assertTrue('title' in aircraft_type)
        self.assertTrue(isinstance(aircraft_type['title'], dict), aircraft_type['title'].__class__)
        self.assertEqual(2, len(aircraft_type['title']))
        self.assertTrue('en' in aircraft_type['title'])
        self.assertTrue('ru' in aircraft_type['title'])
        self.assertEqual(u'Боинг 797', aircraft_type['title']['ru'])
        self.assertEqual(u'Boeing 797', aircraft_type['title']['en'])

        self.assertTrue('iata' in aircraft_type)
        self.assertEqual('XXX', aircraft_type['iata'])

        self.assertTrue('icao' in aircraft_type)
        self.assertEqual('XYZ0', aircraft_type['icao'])

        self.assertTrue('f' in aircraft_type)
        self.assertEqual(70, aircraft_type['f'])

        self.assertTrue('c' in aircraft_type)
        self.assertEqual(20, aircraft_type['c'])

        self.assertTrue('y' in aircraft_type)
        self.assertEqual(10, aircraft_type['y'])

        self.assertTrue('pax_capacity' in aircraft_type)
        self.assertEqual(100, aircraft_type['pax_capacity'])

        self.assertTrue('cargo_capacity' in aircraft_type)
        self.assertEqual(100, aircraft_type['pax_capacity'])

    def test_service_lang(self):
        svc = AircraftTypeJSONService()
        response = svc.v001(lang='en')
        
        json = demjson.decode(response)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(1, len(items))
        
        aircraft_type = items[0]
        self.assertEqual(9, len(aircraft_type))
        self.assertEqual('OoOo', aircraft_type['code'])
        self.assertEqual(1, len(aircraft_type['title']))
        self.assertTrue('en' in aircraft_type['title'])
        self.assertEqual('Boeing 797', aircraft_type['title']['en'])
    
    def test_service_langWrong(self):
        svc = AircraftTypeJSONService()
        response = svc.v001(lang='fr')
        
        json = demjson.decode(response)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(1, len(items))
        
        aircraft_type = items[0]

        self.assertEqual(9, len(aircraft_type))
        self.assertEqual('OoOo', aircraft_type['code'])
        self.assertEqual(2, len(aircraft_type['title']))
        self.assertFalse('fr' in aircraft_type['title'])
        self.assertIn('ru', aircraft_type['title'])
        self.assertIn('en', aircraft_type['title'])
    
    def test_service_excessiveParams(self):
        svc = AircraftTypeJSONService()
        response = svc.v001(param1='a', some_other='1234')

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)

        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(1, len(items))


if __name__ == "__main__":
    testoob.main()
