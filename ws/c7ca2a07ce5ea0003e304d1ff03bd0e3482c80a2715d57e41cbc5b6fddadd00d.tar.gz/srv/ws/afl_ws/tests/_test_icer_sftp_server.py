from paramiko import (
    ServerInterface, SFTPServerInterface, SFTPServer,
    SFTPAttributes, SFTPHandle, SFTP_OK, AUTH_SUCCESSFUL,
    OPEN_SUCCEEDED
)
from StringIO import StringIO
import time
import socket
import paramiko
import multiprocessing
import os


class StubSFTPHandle(SFTPHandle):
    def stat(self):
        attr = SFTPAttributes()
        attr.st_size = self.size
        attr.filename = self.filenaname
        return attr


class StubServer(ServerInterface):
    def check_auth_password(self, username, password):
        return AUTH_SUCCESSFUL

    def check_channel_request(self, kind, chanid):
        return OPEN_SUCCEEDED


class StubSFTPServer(SFTPServerInterface):
    def __init__(self, *args, **kwargs):
        self.files = kwargs.pop("files")
        super(StubSFTPServer, self).__init__(*args, **kwargs)

    def list_folder(self, path):
        d = self.files
        for name in path.split("/"):
            if not name:
                continue
            if name==".":
                d = d
            else:
                d = d[name]
        ret = []
        for name in d:
            attr = SFTPAttributes()
            attr.filename = name
            ret.append(attr)
        return ret

    def open(self, path, flags, attr):
        d = self.files
        for name in path.split("/"):
            if not name:
                continue
            d = d[name]
        f = StringIO(d)
        fobj = StubSFTPHandle()
        fobj.filename = path
        fobj.readfile = f
        fobj.writefile = f 
        fobj.size = len(d)
        return fobj

    def stat(self, path):
        d = self.files
        for name in path.split("/"):
            if not name:
                continue
            d = d[name]
        attr = SFTPAttributes()
        attr.st_size = len(d)
        attr.filename = path
        return attr


BACKLOG = 10


class ICERSFTPServer(multiprocessing.Process):
    def __init__(self, host, port, files):
        super(ICERSFTPServer, self).__init__()
        self.host = host
        self.port = port
        self.files = files
        self.server_socket = server_socket = socket.socket(
            socket.AF_INET, socket.SOCK_STREAM
        )
        server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, True)
        server_socket.bind((self.host, self.port))
        server_socket.listen(BACKLOG)

    def run(self):
        while True:
            conn, addr = self.server_socket.accept()

            host_key = paramiko.ECDSAKey.generate()
            transport = paramiko.Transport(conn)
            transport.add_server_key(host_key)
            transport.set_subsystem_handler(
                'sftp', paramiko.SFTPServer, StubSFTPServer,
                files=self.files
            )
            server = StubServer()
            transport.start_server(server=server)

            channel = transport.accept()
            while transport.is_active():
                time.sleep(1)

    def terminate(self):
        super(ICERSFTPServer, self).terminate()


# paramiko_level = paramiko.common.DEBUG
# paramiko.common.logging.basicConfig(level=paramiko_level)
