# -*- coding: utf-8 -*-


from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

from rx.i18n.translation import SelfTranslationDomain

from services.json_services.professional_areas import ProfessionalAreasJSONService

import testoob
import demjson
import _test_data
from _test_data import setup_vocabulary

from models.professional_area import ProfessionalAreaVocabulary


class TestProfessionalAreasService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestProfessionalAreasService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestProfessionalAreasService, self).tearDown()

    def registerVocabularies(self):
        super(TestProfessionalAreasService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(ProfessionalAreaVocabulary)

    def test_service(self):
        svc = ProfessionalAreasJSONService()
        response = svc.v001()

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)

        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        area = items[0]
        self.assertTrue(isinstance(area, dict), area.__class__)
        self.assertEqual(2, len(area))
        self.assertTrue('code' in area)
        self.assertTrue('title' in area)
        self.assertEqual('-1', area['code'])
        self.assertEqual(2, len(area['title']))
        self.assertTrue('en' in area['title'])
        self.assertTrue('ru' in area['title'])
        self.assertEqual('XXX1', area['title']['ru'])
        self.assertEqual('YYY1', area['title']['en'])

        area = items[1]
        self.assertTrue(isinstance(area, dict), area.__class__)
        self.assertEqual(2, len(area))
        self.assertTrue('code' in area)
        self.assertTrue('title' in area)
        self.assertEqual('-2', area['code'])
        self.assertEqual(2, len(area['title']))
        self.assertTrue('en' in area['title'])
        self.assertTrue('ru' in area['title'])
        self.assertEqual('XXX2', area['title']['ru'])
        self.assertEqual('YYY2', area['title']['en'])

    def test_service_lang(self):
        svc = ProfessionalAreasJSONService()

        for lang in ['ru', 'en']:
            response = svc.v001(lang=lang)
            json = demjson.decode(response)

            items = json['data']
            self.assertTrue(isinstance(items, list), items.__class__)
            self.assertEqual(2, len(items))

            for area in items:
                self.assertTrue(isinstance(area, dict), area.__class__)
                self.assertEqual(2, len(area))
                self.assertTrue('code' in area)
                self.assertTrue('title' in area)
                self.assertEqual(1, len(area['title']))
                self.assertTrue(lang in area['title'])

    def test_excessive_params(self):
        svc = ProfessionalAreasJSONService()
        response = svc.v001(param1='111', some_param='qwerty')

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)

        items = json['data']
        self.assertEqual(2, len(items))

        for area in items:
            self.assertTrue(isinstance(area, dict), area.__class__)
            self.assertEqual(2, len(area))
            self.assertTrue('code' in area)
            self.assertTrue('title' in area)
            self.assertEqual(2, len(area['title']))


if __name__ == "__main__":
    testoob.main()
