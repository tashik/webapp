# coding=utf-8

import demjson
import mock
import pyramid
import testoob
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.tests.testlib import TestCaseWithI18N
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from pyramid.vocabulary import getV
from rx.i18n.translation import SelfTranslationDomain
from zope.component import globalSiteManager as gsm

from models.ssr_meal import SpecialMealVocabulary, SpecialMeal
from services.json_services.ssr_meal_codes import SSRMealCodes, MealCodesError


class TestSpecialMealService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    def setUp(self):
        super(TestSpecialMealService, self).setUp()
        self.service = SSRMealCodes()
        IRegisterableVocabulary(SpecialMealVocabulary).register()
        pyramid.vocabulary.mvcc.register()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        self.test_meals = {
            'ONE1': {'code': 'ONE1', 'names': [u'en:ONE1', u'ru:ОДИН1']},
            'TWO2': {'code': 'TWO2', 'names': [u'en:TWO1', u'ru:ДВА2']}
        }
        self._insert_test_data()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestSpecialMealService, self).tearDown()

    def test_all_lang(self):
        with mock.patch('services.json_services.ssr_meal_codes.config.KNOWN_LANGUAGES', ['en', 'ru']):
            response = self.service.index()
            json = demjson.decode(response)
            data = json['data']
            for entry in data:
                code = entry[u'code']
                self.assertEqual(len(entry['title']), 2)
                self.assertEqual(entry['title']['en'], self.test_meals[code]['names'][0].split(':', 1)[-1])
                self.assertEqual(entry['title']['ru'], self.test_meals[code]['names'][1].split(':', 1)[-1])

    def test_with_unknown_lang(self):
        with mock.patch('services.json_services.ssr_meal_codes.config.KNOWN_LANGUAGES', ['en', 'ru']):
            response = self.service.index(lang='asdasd')
            json = demjson.decode(response)
            data = json['data']
            for entry in data:
                code = entry[u'code']
                self.assertEqual(len(entry['title']), 2)
                self.assertEqual(entry['title']['en'], self.test_meals[code]['names'][0].split(':', 1)[-1])
                self.assertEqual(entry['title']['ru'], self.test_meals[code]['names'][1].split(':', 1)[-1])

    def test_with_known_lang(self):
        with mock.patch('services.json_services.ssr_meal_codes.config.KNOWN_LANGUAGES', ['en', 'ru']):
            response = self.service.index(lang='ru')
            json = demjson.decode(response)
            data = json['data']
            for entry in data:
                code = entry[u'code']
                self.assertEqual(len(entry['title']), 1)
                self.assertEqual(entry['title']['ru'], self.test_meals[code]['names'][1].split(':', 1)[-1])

    def test_with_exception(self):
        with mock.patch('services.json_services.ssr_meal_codes.getV', side_effect=TypeError):
            with self.assertRaises(MealCodesError) as e:
                self.service.index()

    def _insert_test_data(self):
        vocab = getV('ssr_meal_codes')
        for i in self.test_meals.values():
            vocab.add(SpecialMeal(**i))
        vocab.on_commit()

if __name__ == "__main__":
    testoob.main()
