# -*- coding: utf-8 -*-

"""
$Id: test_services_json_geography.py 3988 2014-04-04 15:17:18Z anovgorodov $
"""
import cherrypy

from zope.component import globalSiteManager as gsm, provideUtility
from zope.i18n.interfaces import INegotiator, ILanguageAvailability

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from rx.i18n.translation import SelfTranslationDomain
import services

from services.json_services.funds import FundsJSONService

import testoob
import unittest
import demjson
import _test_data
from _test_data import setup_vocabulary
import config
import models.charity_funds


class TestCharityFundsService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)
    
    def setUp(self):
        super(TestCharityFundsService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.charity_funds.CharityFundVocabulary)
        self.s = FundsJSONService()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCharityFundsService, self).tearDown()

    def test_service(self):
        svc = FundsJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(2, len(items))

        charity_fund = items[0]
        self.assertTrue(isinstance(charity_fund, dict), charity_fund.__class__)
        self.assertEqual(16, len(charity_fund))
        self.assertTrue('charity_id' in charity_fund)
        self.assertEqual(u'12345156', charity_fund['charity_id'])

        self.assertTrue('names' in charity_fund)
        self.assertTrue(isinstance(charity_fund['names'], dict), charity_fund['names'].__class__)
        self.assertEqual(2, len(charity_fund['names']))
        self.assertTrue('en' in charity_fund['names'])
        self.assertTrue('ru' in charity_fund['names'])
        self.assertEqual(u'Первый фонд', charity_fund['names']['ru'])
        self.assertEqual(u'First charity funds', charity_fund['names']['en'])

        self.assertTrue('charity_description' in charity_fund)
        self.assertTrue(isinstance(charity_fund['charity_description'], dict), charity_fund['charity_description'].__class__)
        self.assertEqual(2, len(charity_fund['charity_description']))
        self.assertTrue('en' in charity_fund['charity_description'])
        self.assertTrue('ru' in charity_fund['charity_description'])
        self.assertEqual(u'Это описание', charity_fund['charity_description']['ru'])
        self.assertEqual(u'This is description', charity_fund['charity_description']['en'])

        self.assertTrue('charity_short_description' in charity_fund)
        self.assertTrue(isinstance(charity_fund['charity_short_description'], dict), charity_fund['charity_short_description'].__class__)
        self.assertEqual(2, len(charity_fund['charity_short_description']))
        self.assertTrue('en' in charity_fund['charity_short_description'])
        self.assertTrue('ru' in charity_fund['charity_short_description'])
        self.assertEqual(u'Это короткое описание', charity_fund['charity_short_description']['ru'])
        self.assertEqual(u'This is short description', charity_fund['charity_short_description']['en'])

        self.assertTrue('contacts' in charity_fund)
        self.assertTrue(isinstance(charity_fund['contacts'], dict), charity_fund['contacts'].__class__)
        self.assertEqual(1, len(charity_fund['contacts']))
        self.assertTrue('ru' in charity_fund['contacts'])
        self.assertEqual(u'Москва', charity_fund['contacts']['ru'])

        self.assertTrue('donate_miles_mv_url' in charity_fund)
        self.assertEqual(u'http://aeroflot.ru/donate_miles_mv', charity_fund['donate_miles_mv_url'])

        self.assertTrue('donate_miles_url' in charity_fund)
        self.assertEqual(u'http://aeroflot.ru/donate_miles', charity_fund['donate_miles_url'])

        self.assertTrue('image_url' in charity_fund)
        self.assertTrue(isinstance(charity_fund['image_url'], dict), charity_fund['image_url'].__class__)
        self.assertEqual(2, len(charity_fund['image_url']))
        self.assertTrue('en' in charity_fund['image_url'])
        self.assertTrue('ru' in charity_fund['image_url'])
        self.assertEqual(u'http://aeroflot.ru/image.png', charity_fund['image_url']['ru'])
        self.assertEqual(u'http://aeroflot.ru/image.png', charity_fund['image_url']['en'])

        self.assertTrue('logo_url' in charity_fund)
        self.assertTrue(isinstance(charity_fund['logo_url'], dict), charity_fund['logo_url'].__class__)
        self.assertEqual(2, len(charity_fund['logo_url']))
        self.assertTrue('en' in charity_fund['logo_url'])
        self.assertTrue('ru' in charity_fund['logo_url'])
        self.assertEqual(u'http://aeroflot.ru/logo.png', charity_fund['logo_url']['ru'])
        self.assertEqual(u'http://aeroflot.ru/logo.png', charity_fund['logo_url']['en'])

        self.assertTrue('news_mv_url' in charity_fund)
        self.assertTrue(isinstance(charity_fund['news_mv_url'], dict), charity_fund['news_mv_url'].__class__)
        self.assertEqual(2, len(charity_fund['news_mv_url']))
        self.assertTrue('en' in charity_fund['news_mv_url'])
        self.assertTrue('ru' in charity_fund['news_mv_url'])
        self.assertEqual(u'http://aeroflot.ru/pda/news', charity_fund['news_mv_url']['ru'])
        self.assertEqual(u'http://aeroflot.ru/pda/news', charity_fund['news_mv_url']['en'])

        self.assertTrue('news_url' in charity_fund)
        self.assertTrue(isinstance(charity_fund['news_url'], dict), charity_fund['news_url'].__class__)
        self.assertEqual(2, len(charity_fund['news_url']))
        self.assertTrue('en' in charity_fund['news_url'])
        self.assertTrue('ru' in charity_fund['news_url'])
        self.assertEqual(u'http://aeroflot.ru/news', charity_fund['news_url']['ru'])
        self.assertEqual(u'http://aeroflot.ru/news', charity_fund['news_url']['en'])

        self.assertTrue(u'stats_charity_funds_url' in charity_fund)
        self.assertEqual(u'http://aeroflot.ru/stats', charity_fund['stats_charity_funds_url'])

        self.assertTrue('rss_url' in charity_fund)
        self.assertEqual(u'', charity_fund['rss_url'])

        self.assertTrue('transfer_conditions' in charity_fund)
        self.assertTrue(isinstance(charity_fund['transfer_conditions'], dict), charity_fund['transfer_conditions'].__class__)
        self.assertEqual(2, len(charity_fund['transfer_conditions']))
        self.assertTrue('en' in charity_fund['transfer_conditions'])
        self.assertTrue('ru' in charity_fund['transfer_conditions'])
        self.assertEqual(u'http://aeroflot.ru/', charity_fund['transfer_conditions']['ru'])
        self.assertEqual(u'http://aeroflot.ru/', charity_fund['transfer_conditions']['en'])

        self.assertTrue('weight' in charity_fund)
        self.assertEqual(u'10', charity_fund['weight'])


    def test_service_lang(self):
        svc = FundsJSONService()
        response = svc.v001(lang='en')
        
        json = demjson.decode(response)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(2, len(items))
        
        aircraft_type = items[0]
        self.assertEqual(16, len(aircraft_type))
        self.assertEqual('12345156', aircraft_type['charity_id'])
        self.assertEqual(1, len(aircraft_type['names']))
        self.assertTrue('en' in aircraft_type['names'])
        self.assertEqual('First charity funds', aircraft_type['names']['en'])
    
    def test_service_langWrong(self):
        svc = FundsJSONService()
        response = svc.v001(lang='fr')
        
        json = demjson.decode(response)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(2, len(items))
        
        aircraft_type = items[0]

        self.assertEqual(16, len(aircraft_type))
        self.assertEqual('12345156', aircraft_type['charity_id'])
        self.assertEqual(2, len(aircraft_type['names']))
        self.assertFalse('fr' in aircraft_type['names'])
        self.assertIn('ru', aircraft_type['names'])
        self.assertIn('en', aircraft_type['names'])
    
    def test_service_charity_id(self):
        svc = FundsJSONService()
        response = svc.v001(lang='ru', charity_id='223')

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)

        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(1, len(items))

    def test_service_wrong_charity_id(self):
        svc = FundsJSONService()
        response = svc.v001(lang='ru', charity_id='222')

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse([], json['data'])


if __name__ == "__main__":
    testoob.main()
