# -*- coding: utf-8 -*-

"""
$Id: $
"""


import testoob

import pyramid.vocabulary.mvcc
from pyramid.i18n.message import Message
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.vocabulary import getV
from pyramid.vocabulary.interfaces import IVocabulary

from rx.i18n.translation import SelfTranslationDomain, self_translated

import _test_data
from _test_data import setup_vocabulary
import models.air


class TestAir(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAir, self).setUp()
        self.model = models.air.AircraftType

    def test_model(self):
        ob = self.model.load(aircraft_type_id=-1)

        self.assertEqual(u'OoOo', ob.ohd_code)
        self.assertEqual([u'en:Boeing 797', u'ru:Боинг 797'], ob.names)
        self.assertEqual(u'XXX', ob.iata)
        self.assertEqual(u'XYZ0', ob.icao)
        self.assertEqual(100, ob.pax_capacity)
        self.assertEqual(30, ob.cargo_capacity)
        self.assertEqual(70, ob.f)
        self.assertEqual(20, ob.c)
        self.assertEqual(10, ob.y)

        self.assertTrue(isinstance(ob.title, Message))


class TestAirI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def testModelTitles(self):
        ob = models.air.AircraftType.load(aircraft_type_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'Boeing 797', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'Боинг 797', SelfTranslationDomain().translate(ob.title.msgid))


class TestAirVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAirVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AircraftTypesVocabulary)

    def testVocabulary(self):
        v = getV('aircraft_types')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(-2 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.air.AircraftType))
        self.assertEqual(ob.names, [u'en:Boeing 797', u'ru:Боинг 797'])

    def testVocabularyRegistration(self):
        v = getV('aircraft_types')
        self.assertTrue(-1 in v)
        self.assertFalse(-2 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.air.AircraftType))
        self.assertEqual(ob.names, [u'en:Boeing 797', u'ru:Боинг 797'])



if __name__ == "__main__":
    testoob.main()
