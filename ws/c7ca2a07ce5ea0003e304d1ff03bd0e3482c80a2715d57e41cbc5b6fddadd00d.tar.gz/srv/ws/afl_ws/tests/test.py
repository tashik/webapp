# -*- coding: utf-8 -*-

"""Test Runner.

$Id: test.py 1043 2011-08-16 19:29:39Z anovgorodov $
"""

import os
import unittest
import testoob
#import testlib


if __name__ == "__main__":

    testdir = os.path.split(__file__)[0] or '.'
    testfiles = [ f[:-3] for f in os.listdir(testdir) \
                 if f.startswith('test_') and f.endswith('.py') ]
    modules = [ __import__(file) for file in testfiles ]
    test_loader = unittest.TestLoader()
    tests = [ test_loader.loadTestsFromModule(module) for module in modules ]
    testoob.main(unittest.TestSuite(tests))
