# -*- coding: utf-8 -*-

"""
$Id: $
"""


import testoob
import unittest

from lxml import etree

from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.ui.utils import xmlTree
from rx.i18n.translation import SelfTranslationDomain

from _test_data import setup_vocabulary
import _test_data
import models.air

from services.xml.air import AircraftTypeXMLService


class TestAircraftTypeXMLService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAircraftTypeXMLService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAircraftTypeXMLService, self).tearDown()

    def registerVocabularies(self):
        super(TestAircraftTypeXMLService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.air.AircraftTypesVocabulary)

    def test_aircraft_type_v001(self):
        svc = AircraftTypeXMLService()
        data = svc.v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/aircraft_types'))
        self.assertTrue(xml.xpath('/aircraft_types[@lang="en"]'))
        self.assertTrue(xml.xpath('/aircraft_types/aircraft_type'))
        aircraft_types = xml.xpath('/aircraft_types/aircraft_type')
        self.assertEqual(len(aircraft_types), 1)
        aircraft_type = aircraft_types[0]
        attrib = aircraft_type.attrib
        self.assertTrue(attrib['code'], u'OoOo')
        self.assertTrue(attrib['iata'], u'XXX')
        self.assertTrue(attrib['icao'], u'XYZ0')
        self.assertTrue(attrib['cargo_capacity'], '30')
        self.assertTrue(attrib['pax_capacity'], '100')
        self.assertTrue(attrib['f'], '70')
        self.assertTrue(attrib['c'], '20')
        self.assertTrue(attrib['y'], '10')

    def test_tier_levels_langauages(self):
        self.negotiator.lang = 'ru'
        svc = AircraftTypeXMLService()
        data = svc.v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/aircraft_types[@lang="ru"]'))
        self.assertTrue(xml.xpath('/aircraft_types/aircraft_type[@code="OoOo"]'))
        self.assertFalse(xml.xpath('/aircraft_types/aircraft_type[@code="OoOo"]/name[@xml:lang="en"]'))
        self.assertEqual(xml.xpath('/aircraft_types/aircraft_type[@code="OoOo"]/name[@xml:lang="ru"]/text()')[0], u'Боинг 797')

        self.negotiator.lang = None

        svc = AircraftTypeXMLService()
        data = svc.v001()
        xml = etree.fromstring(data)

        self.assertTrue(xml.xpath('/aircraft_types/aircraft_type[@code="OoOo"]'))
        self.assertEqual(xml.xpath('/aircraft_types/aircraft_type[@code="OoOo"]/name[@xml:lang="en"]/text()')[0], u'Boeing 797')
        self.assertEqual(xml.xpath('/aircraft_types/aircraft_type[@code="OoOo"]/name[@xml:lang="ru"]/text()')[0], u'Боинг 797')

if __name__ == "__main__":
    testoob.main()
