# -*- coding: utf-8 -*-


from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary.indexer import VocabularyIndexerFactory

from rx.i18n.translation import SelfTranslationDomain

from services.json_services.loyalty_programs import LoyaltyProgramsJSONService

from mock import patch
import testoob
import demjson
import _test_data
from _test_data import setup_vocabulary

from models.loyalty_program import LoyaltyProgramVocabulary
from models.airline import AirlinesVocabulary


class TestLoyaltyProgramsService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestLoyaltyProgramsService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestLoyaltyProgramsService, self).tearDown()

    def registerVocabularies(self):
        super(TestLoyaltyProgramsService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(LoyaltyProgramVocabulary)
        setup_vocabulary(AirlinesVocabulary)

    @patch(
        'services.json_services.loyalty_programs.get_airlines_info_lp',
        lambda: {
            -1: [
                {
                    'airline_name': 'Test1',
                    'airline_code': 'T1',
                    'aliance': 'SkyTeam'
                },
                {
                    'airline_name': 'Test1.2',
                    'airline_code': 'T2',
                    'aliance': 'SkyTeam'
                }
            ],
            -2: [
                {
                    'airline_name': 'Test2',
                    'airline_code': 'T3',
                    'aliance': 'SkyTeam'
                }
            ]
        }
    )
    def test_service(self):
        svc = LoyaltyProgramsJSONService()
        response = svc.v001()

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)

        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(3, len(items))

        program = items[0]
        self.assertTrue(isinstance(program, dict), program.__class__)
        self.assertEqual(6, len(program))
        self.assertTrue('id' in program)
        self.assertTrue('name' in program)
        self.assertEqual(-1, program['id'])
        self.assertEqual('TEST1', program['name']),
        self.assertEqual('Test1', program['airline_name'])
        self.assertEqual('T1', program['airline_code'])
        self.assertEqual('SkyTeam', program['aliance'])
        self.assertEqual(None, program['siebel_code'])

        program = items[1]
        self.assertTrue(isinstance(program, dict), program.__class__)
        self.assertEqual(6, len(program))
        self.assertTrue('id' in program)
        self.assertTrue('name' in program)
        self.assertEqual(-1, program['id'])
        self.assertEqual('TEST1', program['name'])
        self.assertEqual('Test1.2', program['airline_name'])
        self.assertEqual('T2', program['airline_code'])
        self.assertEqual('SkyTeam', program['aliance'])
        self.assertEqual(None, program['siebel_code'])

        program = items[2]
        self.assertTrue(isinstance(program, dict), program.__class__)
        self.assertEqual(6, len(program))
        self.assertTrue('id' in program)
        self.assertTrue('name' in program)
        self.assertEqual(-2, program['id'])
        self.assertEqual('TEST2', program['name'])
        self.assertEqual('Test2', program['airline_name'])
        self.assertEqual('T3', program['airline_code'])
        self.assertEqual('SkyTeam', program['aliance'])
        self.assertEqual(None, program['siebel_code'])

    def test_excessive_params(self):
        svc = LoyaltyProgramsJSONService()
        response = svc.v001(param1='111', some_param='qwerty')

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)

        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)

        items = json['data']
        self.assertEqual(2, len(items))

        for area in items:
            self.assertTrue(isinstance(area, dict), area.__class__)
            self.assertEqual(6, len(area))
            self.assertTrue('id' in area)
            self.assertTrue('name' in area)
            self.assertTrue('airline_name' in area)
            self.assertTrue('airline_code' in area)
            self.assertTrue('aliance' in area)
            self.assertTrue('siebel_code' in area)


if __name__ == "__main__":
    testoob.main()
