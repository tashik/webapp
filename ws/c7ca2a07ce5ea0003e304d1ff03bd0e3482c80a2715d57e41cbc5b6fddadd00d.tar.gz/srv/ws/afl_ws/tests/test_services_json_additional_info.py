# -*- coding: utf-8 -*-
"""
$Id$
"""
import json
import mock
from StringIO import StringIO
import cherrypy
import testoob
from zope.component.globalregistry import provideUtility
import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from rx.i18n.translation import SelfTranslationDomain
from services.base.json_base import ContentTypeJSONRequiredException
from services.json_services.additional_info import AdditionalInfoJSONService, SegmentsValidationError, \
    ParameterMissingError
import models.additional_info
import models.airport
import models.geo
import _test_data


class TestAdditionalInfoService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAdditionalInfoService, self).setUp()
        cherrypy.request.headers = type(cherrypy.request.headers)()
        provideUtility(SelfTranslationDomain(), name='self_translate')
        self.service = AdditionalInfoJSONService()

    def registerVocabularies(self):
        super(TestAdditionalInfoService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.additional_info.AdditionalInfoVocabulary)
        _test_data.setup_vocabulary(models.airport.AirportsVocabulary)
        _test_data.setup_vocabulary(models.geo.CitiesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByVocabIDIndexer), 'cities_by_vocab_id_idx')
        _test_data.setup_vocabulary(models.geo.CountriesVocabulary)
        _test_data.setup_vocabulary(models.geo.WorldRegionsVocabulary)

    def tearDown(self):
        self._unregisterTranslationDomains('self_translate')
        super(TestAdditionalInfoService, self).tearDown()

    def test_service(self):
        cherrypy.request.body = StringIO(json.dumps([]))
        with self.assertRaises(ContentTypeJSONRequiredException):
            self.service.v001()

        cherrypy.request.headers['content-type'] = 'application/json'
        with self.assertRaises(SegmentsValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'abc': 1}))
        with self.assertRaises(SegmentsValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'segments': 1}))
        with self.assertRaises(SegmentsValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'segments': [{}, 1, '', None]}))
        with self.assertRaises(SegmentsValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'airport_from': 'XXA', 'airport_to': 'XXB', 'airline': 'SU'},
            {'country_from': 'XX', 'country_to': 'XX', 'airline': 'SU'},
            {'world_region_from': 1, 'world_region_to': 1, 'airline': 'SU'},
        ]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'В UUZ', u'en': u'To UUZ'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        # передана позиция search

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'airport_from': 'XXA', 'airport_to': 'XXB', 'airline': 'SU'},
            {'country_from': 'XX', 'country_to': 'XX', 'airline': 'SU'},
            {'world_region_from': 1, 'world_region_to': 1, 'airline': 'SU'},
        ], 'position': 'search'}))
        response = self.service.v001()
        result_with_search_position = json.loads(response)
        self.assertEqual(result_with_search_position, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'В UUZ', u'en': u'To UUZ'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        # передана позиция flight

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'airport_from': 'XXA', 'airport_to': 'XXB', 'airline': 'SU'},
            {'country_from': 'XX', 'country_to': 'XX', 'airline': 'SU'},
            {'world_region_from': 1, 'world_region_to': 1, 'airline': 'SU'},
        ], 'position': 'flight'}))
        response = self.service.v001()
        result_with_flight_position = json.loads(response)
        self.assertEqual(result_with_search_position, result_with_flight_position)

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'airport_from': 'XXA', 'airport_to': 'XXB', 'airline': 'SU'},
        ]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'В UUZ', u'en': u'To UUZ'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'country_from': 'XX', 'country_to': 'XX', 'airline': 'SU'},
        ]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'world_region_from': 1, 'world_region_to': 1, 'airline': 'SU'},
        ]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
        ]})

        # TODO: Тест отключен до выяснения вопроса включения geoip в релиз
        # cherrypy.request.body = StringIO(json.dumps({'segments': [
        #     {'airport_from': 'SVO', 'airport_to': 'JFK', 'airline': 'SU'}
        # ], 'booking_ip': '128.101.101.101'}))
        # response = self.service.v001()
        # result = json.loads(response)
        # self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
        #     {u'ru': u'Забронировано в США', u'en': u'Booked in USA'},
        # ]})

        # сегмент с позицией search
        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'world_region_from': 2, 'world_region_to': 2, 'airline': 'SU'},
        ]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'airport_from': 'SVO', 'airport_to': 'JFK', 'airline': 'SU'}
        ], 'booking_ip': '58.211.208.38'}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

        # TODO: Тест отключен до выяснения вопроса включения geoip в релиз
        # cherrypy.request.body = StringIO(json.dumps({'segments': [{
        #     'airport_from': 'SVO', 'airport_to': 'JFK', 'airline': 'SU', 'booking_ip': '128.101.101.101'
        # }], 'booking_ip': '58.211.208.38'}))
        # response = self.service.v001()
        # result = json.loads(response)
        # self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
        #     {u'ru': u'Забронировано в США', u'en': u'Booked in USA'},
        # ]})

        cherrypy.request.body = StringIO(json.dumps({'segments': [{
            'airport_from': 'SVO', 'airport_to': 'JFK', 'airline': 'SU', 'booking_ip': '128.101.101.101',
            'booking_country': 'CN'
        }]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

        cherrypy.request.body = StringIO(json.dumps({'segments': [
            {'airport_from': 'SVO', 'airport_to': 'JFK', 'airline': 'SU'}
        ]}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

    @mock.patch('config.KNOWN_LANGUAGES', ('en', 'ru'))
    def test_service_v002(self):
        cherrypy.request.body = StringIO(json.dumps([]))
        with self.assertRaises(ContentTypeJSONRequiredException):
            self.service.v002()

        cherrypy.request.headers['content-type'] = 'application/json'
        with self.assertRaises(SegmentsValidationError):
            self.service.v002()

        cherrypy.request.body = StringIO(json.dumps({'abc': 1}))
        with self.assertRaises(SegmentsValidationError):
            self.service.v002()

        cherrypy.request.body = StringIO(json.dumps({'segments': 1}))
        with self.assertRaises(SegmentsValidationError):
            self.service.v002()

        cherrypy.request.body = StringIO(json.dumps({'segments': [{}, 1, '', None]}))
        with self.assertRaises(ParameterMissingError):
            self.service.v002()

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'airport_from': 'XXA',
                        'airport_to': 'XXB',
                        'airline': 'SU'
                    },
                    {
                        'country_from': 'XX',
                        'country_to': 'XX',
                        'airline': 'SU'
                    },
                    {
                        'world_region_from': 1,
                        'world_region_to': 1,
                        'airline': 'SU'
                    }
                ],
                'position': 'flight',
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'В UUZ', u'en': u'To UUZ'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'airport_from': 'XXA',
                        'airport_to': 'XXB',
                        'airline': 'SU'
                    }
                ],
                'position': 'flight',
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'В UUZ', u'en': u'To UUZ'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'country_from': 'XX',
                        'country_to': 'XX',
                        'airline': 'SU'
                    }
                ],
                'position': 'flight',
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
            {u'ru': u'Из XX', u'en': u'From XX'},
        ]})

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'world_region_from': 1,
                        'world_region_to': 1,
                        'airline': 'SU'
                    }
                ],
                'position': 'flight',
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'},
        ]})

        # TODO: Тест отключен до выяснения вопроса включения geoip в релиз
        # cherrypy.request.body = StringIO(json.dumps(
        #     {
        #         'segments': [
        #             {
        #                 'airport_from': 'SVO',
        #                 'airport_to': 'JFK',
        #                 'airline': 'SU'
        #             }
        #         ],
        #         'booking_ip': '128.101.101.101',
        #         'position': 'flight',
        #     }
        # ))
        # response = self.service.v002()
        # result = json.loads(response)
        # self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
        #     {u'ru': u'Забронировано в США', u'en': u'Booked in USA'},
        # ]})

        # сегмент с позицией search
        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'world_region_from': 2,
                        'world_region_to': 2,
                        'airline': 'SU'
                    },
                ],
                'position': 'search',
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
            {u'ru': u'Из Европы', u'en': u'From Europe'}
        ]})

        # некорректная позиция
        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'world_region_from': 2,
                        'world_region_to': 2,
                        'airline': 'SU'
                    },
                ],
                'position': 'test',
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'airport_from': 'SVO',
                        'airport_to': 'JFK',
                        'airline': 'SU'
                    }
                ],
                'booking_ip': '58.211.208.38',
                'position': 'flight'
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

        # TODO: Тест отключен до выяснения вопроса включения geoip в релиз
        # cherrypy.request.body = StringIO(json.dumps(
        #     {
        #         'segments': [
        #             {
        #                 'airport_from': 'SVO',
        #                 'airport_to': 'JFK',
        #                 'airline': 'SU',
        #                 'booking_ip': '128.101.101.101'
        #             }
        #         ],
        #         'booking_ip': '58.211.208.38',
        #         'position': 'flight'
        #     }
        # ))
        # response = self.service.v002()
        # result = json.loads(response)
        # self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': [
        #     {u'ru': u'Забронировано в США', u'en': u'Booked in USA'},
        # ]})

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'airport_from': 'SVO',
                        'airport_to': 'JFK',
                        'airline': 'SU',
                        'booking_ip': '128.101.101.101',
                        'booking_country': 'CN'
                    }
                ],
                'position': 'flight'
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})

        cherrypy.request.body = StringIO(json.dumps(
            {
                'segments': [
                    {
                        'airport_from': 'SVO', 'airport_to': 'JFK', 'airline': 'SU'
                    }
                ],
                'position': 'flight'
            }
        ))
        response = self.service.v002()
        result = json.loads(response)
        self.assertEqual(result, {u'isSuccess': True, u'errors': [], u'data': []})


if __name__ == '__main__':
    testoob.main()
