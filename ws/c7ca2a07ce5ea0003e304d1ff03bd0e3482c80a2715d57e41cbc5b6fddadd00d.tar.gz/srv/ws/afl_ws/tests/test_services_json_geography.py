# -*- coding: utf-8 -*-

"""
$Id: test_services_json_geography.py 35221 2018-07-22 10:42:47Z apinsky $
"""

from zope.component import globalSiteManager as gsm

import pyramid.vocabulary.mvcc
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from rx.i18n.translation import SelfTranslationDomain

from services.json_services.geography import (
    WorldRegionsJSONService, CountriesJSONServiceV001, CountriesJSONServiceV002,
    CitiesJSONService, AirportsJSONService, POSCountriesJSONService)
from services.json_services.currency import CurrencyNamesJSONService, CurrencyJSONService, InvalidCurrencyException, \
    ICERJSONService, CalcurrJSONService

import mock
import testoob
import datetime
import demjson
import _test_data
from _test_data import setup_vocabulary
import models.airport
import models.geo


class TestWorldRegionsService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestWorldRegionsService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestWorldRegionsService, self).tearDown()

    def registerVocabularies(self):
        super(TestWorldRegionsService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.WorldRegionsVocabulary)

    def test_service(self):
        svc = WorldRegionsJSONService()
        response = svc.v001()
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [{u'world_region_id': 1, u'title': {u'ru': u'Европа', u'en': u'Europe'}}],
        })

    def test_service_lang(self):
        svc = WorldRegionsJSONService()
        response = svc.v001(lang='en')
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [{u'world_region_id': 1, u'title': {u'en': u'Europe'}}],
        })

    def test_service_langWrong(self):
        svc = WorldRegionsJSONService()
        response = svc.v001(lang='fr')
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [{u'world_region_id': 1, u'title': {u'ru': u'Европа', u'en': u'Europe'}}],
        })

    def test_service_excessiveParams(self):
        svc = WorldRegionsJSONService()
        response = svc.v001(param1='a', some_other='1234')
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [{u'world_region_id': 1, u'title': {u'ru': u'Европа', u'en': u'Europe'}}],
        })


class TestCountriesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCountriesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCountriesService, self).tearDown()

    def registerVocabularies(self):
        super(TestCountriesService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)
    
    def test_service_v001(self):
        svc = CountriesJSONServiceV001()
        response = svc.v001()
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [
                {u'world_region_id': 1, u'code': u'RU', u'title': {u'ru': u'Россия', u'en': u'Russia'}},
                {u'world_region_id': 1, u'code': u'XX', u'title': {u'ru': u'XXX', u'en': u'YYY'}},
                {u'world_region_id': 1, u'code': u'CN', u'title': {u'ru': u'Китай', u'en': u'China'}},
                {u'world_region_id': 1, u'code': u'US', u'title': {u'ru': u'США', u'en': u'USA'}},
            ],
        })

    @mock.patch('config.KNOWN_LANGUAGES', ('en', 'ru'))
    def test_service_v002(self):
        svc = CountriesJSONServiceV002()
        response = svc.v002()
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [
                {u'world_region_id': 1, u'code': u'RU', u'title': {u'ru': u'Россия', u'en': u'Russia'},
                 u'phone_code': u'+7'},
                {u'world_region_id': 1, u'code': u'XX', u'title': {u'ru': u'XXX', u'en': u'YYY'},
                 u'phone_code': u'+X'},
                {u'world_region_id': 1, u'code': u'CN', u'title': {u'ru': u'Китай', u'en': u'China'},
                 u'phone_code': u'+86'},
                {u'world_region_id': 1, u'code': u'US', u'title': {u'ru': u'США', u'en': u'USA'},
                 u'phone_code': u'+1'},
            ],
        })

    def test_service_lang(self):
        svc = CountriesJSONServiceV001()
        response = svc.v001(lang='en')
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [
                {u'world_region_id': 1, u'code': u'RU', u'title': {u'en': u'Russia'}},
                {u'world_region_id': 1, u'code': u'XX', u'title': {u'en': u'YYY'}},
                {u'world_region_id': 1, u'code': u'CN', u'title': {u'en': u'China'}},
                {u'world_region_id': 1, u'code': u'US', u'title': {u'en': u'USA'}},
            ],
        })

    def test_service_langWrong(self):
        svc = CountriesJSONServiceV001()
        response = svc.v001(lang='fr')
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [
                {u'world_region_id': 1, u'code': u'RU', u'title': {u'ru': u'Россия', u'en': u'Russia'}},
                {u'world_region_id': 1, u'code': u'XX', u'title': {u'ru': u'XXX', u'en': u'YYY'}},
                {u'world_region_id': 1, u'code': u'CN', u'title': {u'ru': u'Китай', u'en': u'China'}},
                {u'world_region_id': 1, u'code': u'US', u'title': {u'ru': u'США', u'en': u'USA'}},
            ],
        })

    def test_service_excessiveParams(self):
        svc = CountriesJSONServiceV001()
        response = svc.v001(param1='a', some_other='1234')
        json = demjson.decode(response)
        self.assertEqual(json, {
            u'isSuccess': True,
            u'errors': [],
            u'data': [
                {u'world_region_id': 1, u'code': u'RU', u'title': {u'ru': u'Россия', u'en': u'Russia'}},
                {u'world_region_id': 1, u'code': u'XX', u'title': {u'ru': u'XXX', u'en': u'YYY'}},
                {u'world_region_id': 1, u'code': u'CN', u'title': {u'ru': u'Китай', u'en': u'China'}},
                {u'world_region_id': 1, u'code': u'US', u'title': {u'ru': u'США', u'en': u'USA'}},
            ],
        })


class TestCitiesService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)
    
    def setUp(self):
        super(TestCitiesService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
    
    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCitiesService, self).tearDown()
    
    def registerVocabularies(self):
        super(TestCitiesService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)
    
    def test_service(self):
        svc = CitiesJSONService()
        response = svc.v001()

        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(7, len(items))
        
        city = items[0]
        self.assertTrue(isinstance(city, dict), city.__class__)
        self.assertEqual(4, len(city))
        self.assertTrue('code' in city)
        self.assertTrue('country_code' in city)
        self.assertTrue('title' in city)
        self.assertTrue('location' in city)
        
        city = [item for item in items if 'UUX' == item['code']]
        self.assertEqual(1, len(city))
        city = city[0]
        self.assertEqual('UUX', city['code'])
        self.assertEqual('XX', city['country_code'])
        self.assertTrue(isinstance(city['title'], dict), city['title'].__class__)
        self.assertEqual(2, len(city['title']))
        self.assertTrue('en' in city['title'])
        self.assertTrue('ru' in city['title'])
        self.assertEqual('XXX', city['title']['ru'])
        self.assertEqual('YYY', city['title']['en'])
        self.assertTrue(isinstance(city['location'], dict), city['location'].__class__)
        self.assertEqual(2, len(city['location']))
        self.assertTrue('lat' in city['location'])
        self.assertTrue('lon' in city['location'])
        self.assertEqual(99.9, city['location']['lat'])
        self.assertEqual(99.9, city['location']['lon'])
        
        city = [item for item in items if 'UUY' == item['code']]
        self.assertEqual(1, len(city))
        city = city[0]
        self.assertEqual('UUY', city['code'])
        self.assertEqual('XX', city['country_code'])
        self.assertEqual('AAA', city['title']['ru'])
        self.assertEqual('BBB', city['title']['en'])
        self.assertEqual(11.1, city['location']['lat'])
        self.assertEqual(22.0, city['location']['lon'])
    
    def test_service_lang(self):
        svc = CitiesJSONService()
        response = svc.v001(lang='en')
        
        json = demjson.decode(response)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(7, len(items))
        
        city = items[0]
        self.assertEqual(4, len(city))
        self.assertTrue('code' in city)
        self.assertTrue('country_code' in city)
        self.assertTrue('title' in city)
        self.assertTrue('location' in city)
        
        city = [item for item in items if 'UUX' == item['code']]
        self.assertEqual(1, len(city))
        city = city[0]
        self.assertEqual('UUX', city['code'])
        self.assertEqual('XX', city['country_code'])
        self.assertEqual(1, len(city['title']))
        self.assertEqual('YYY', city['title']['en'])
        self.assertEqual(2, len(city['location']))
        self.assertEqual(99.9, city['location']['lat'])
        self.assertEqual(99.9, city['location']['lon'])
        
        city = [item for item in items if 'UUY' == item['code']]
        self.assertEqual(1, len(city))
        city = city[0]
        self.assertEqual('UUY', city['code'])
        self.assertEqual('XX', city['country_code'])
        self.assertEqual(1, len(city['title']))
        self.assertEqual('BBB', city['title']['en'])
        self.assertEqual(11.1, city['location']['lat'])
        self.assertEqual(22.0, city['location']['lon'])
    
    def test_service_excessiveParams(self):
        svc = CitiesJSONService()
        response = svc.v001(param1='a', some_other='1234')
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(7, len(items))
        
    def test_service_incompleteLocation(self):
        svc = CitiesJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(7, len(items))
        
        city = [item for item in items if 'UUT' == item['code']]
        self.assertEqual(1, len(city))
        city = city[0]
        self.assertEqual('UUT', city['code'])
        self.assertEqual('XX', city['country_code'])
        self.assertEqual('OOO', city['title']['ru'])
        self.assertEqual('PPP', city['title']['en'])
        self.assertTrue(city['location'] is None)


class TestAirportsService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)
    
    def setUp(self):
        super(TestAirportsService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
    
    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestAirportsService, self).tearDown()
    
    def registerVocabularies(self):
        super(TestAirportsService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.airport.AirportsVocabulary)
        setup_vocabulary(models.geo.CitiesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByVocabIDIndexer), 'cities_by_vocab_id_idx')
    
    def test_service(self):
        svc = AirportsJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(9, len(items))
        
        airport = items[0]
        self.assertTrue(isinstance(airport, dict), airport.__class__)
        self.assertEqual(5, len(airport))
        self.assertTrue('code' in airport)
        self.assertTrue('city_code' in airport)
        self.assertTrue('title' in airport)
        self.assertTrue('location' in airport)
        self.assertIn('has_afl_flights', airport)
        
        airport = [item for item in items if 'XXX' == item['code']]
        self.assertEqual(1, len(airport))
        airport = airport[0]
        self.assertEqual('XXX', airport['code'])
        self.assertEqual('UUY', airport['city_code'])
        self.assertTrue(isinstance(airport['title'], dict), airport['title'].__class__)
        self.assertEqual(2, len(airport['title']))
        self.assertTrue('en' in airport['title'])
        self.assertTrue('ru' in airport['title'])
        self.assertEqual('XXX', airport['title']['ru'])
        self.assertEqual('YYY', airport['title']['en'])
        self.assertTrue(isinstance(airport['location'], dict), airport['location'].__class__)
        self.assertEqual(2, len(airport['location']))
        self.assertTrue('lat' in airport['location'])
        self.assertTrue('lon' in airport['location'])
        self.assertEqual(99.9, airport['location']['lat'])
        self.assertEqual(99.9, airport['location']['lon'])
        self.assertEqual(True, airport['has_afl_flights'])
        
        airport = [item for item in items if 'XXB' == item['code']]
        self.assertEqual(1, len(airport))
        airport = airport[0]
        self.assertEqual('XXB', airport['code'])
        self.assertEqual('UUZ', airport['city_code'])
        self.assertEqual(2, len(airport['title']))
        self.assertEqual('EEE', airport['title']['ru'])
        self.assertEqual('FFF', airport['title']['en'])
        self.assertEqual(10.0, airport['location']['lat'])
        self.assertEqual(20.0, airport['location']['lon'])
        self.assertEqual(False, airport['has_afl_flights'])
    
    def test_service_lang(self):
        svc = AirportsJSONService()
        response = svc.v001(lang='en')
        
        json = demjson.decode(response)
        
        self.assertEqual(3, len(json))
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertEqual(9, len(items))
        
        airport = items[0]
        self.assertTrue(isinstance(airport, dict), airport.__class__)
        self.assertEqual(5, len(airport))
        self.assertTrue('code' in airport)
        self.assertTrue('city_code' in airport)
        self.assertTrue('title' in airport)
        self.assertTrue('location' in airport)
        
        airport = [item for item in items if 'XXX' == item['code']]
        self.assertEqual(1, len(airport))
        airport = airport[0]
        self.assertEqual('XXX', airport['code'])
        self.assertEqual('UUY', airport['city_code'])
        self.assertEqual(1, len(airport['title']))
        self.assertEqual('YYY', airport['title']['en'])
        self.assertEqual(2, len(airport['location']))
        self.assertEqual(99.9, airport['location']['lat'])
        self.assertEqual(99.9, airport['location']['lon'])
        
        airport = [item for item in items if 'XXB' == item['code']]
        self.assertEqual(1, len(airport))
        airport = airport[0]
        self.assertEqual('XXB', airport['code'])
        self.assertEqual('UUZ', airport['city_code'])
        self.assertEqual(1, len(airport['title']))
        self.assertEqual('FFF', airport['title']['en'])
        self.assertEqual(10.0, airport['location']['lat'])
        self.assertEqual(20.0, airport['location']['lon'])
    
    def test_service_excessiveParams(self):
        svc = AirportsJSONService()
        response = svc.v001(param1='a', some_other='1234')
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(9, len(items))
    
    def test_service_incompleteLocation(self):
        svc = AirportsJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertTrue(isinstance(json, dict), json.__class__)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        items = json['data']
        self.assertTrue(isinstance(items, list), items.__class__)
        self.assertEqual(9, len(items))
        
        airport = [item for item in items if 'XXF' == item['code']]
        self.assertEqual(1, len(airport))
        airport = airport[0]
        self.assertEqual('XXF', airport['code'])
        self.assertEqual('UUX', airport['city_code'])
        self.assertEqual(2, len(airport['title']))
        self.assertEqual('QQQ', airport['title']['ru'])
        self.assertEqual('RRR', airport['title']['en'])
        self.assertTrue(airport['location'] is None)
        
        airport = [item for item in items if 'XXG' == item['code']]
        self.assertEqual(1, len(airport))
        airport = airport[0]
        self.assertEqual('XXG', airport['code'])
        self.assertEqual('UUZ', airport['city_code'])
        self.assertEqual(2, len(airport['title']))
        self.assertEqual('SSS', airport['title']['ru'])
        self.assertEqual('TTT', airport['title']['en'])
        self.assertTrue(airport['location'] is None)


class TestCurrencyServices(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)
    
    def setUp(self):
        super(TestCurrencyServices, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
    
    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestCurrencyServices, self).tearDown()
    
    def registerVocabularies(self):
        super(TestCurrencyServices, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.geo.CurrencyVocabulary)
        setup_vocabulary(models.geo.ICERVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CurrencyByUsedInCalcIndexer), 'currencies_by_used_in_calc_idx')
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CountriesByUseInPOSIndexer), 'countries_by_use_in_pos_idx')
    
    def test_currency_service(self):
        svc = CurrencyJSONService()
        response = svc.v001('XX')
        
        json = demjson.decode(response)
        self.assertIsInstance(json, dict)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        data = json['data']
        self.assertIsInstance(data, dict)
        self.assertIn("currency", data)
        self.assertEqual(data["currency"], "XXX")

    def test_icer_service(self):
        _icer = models.geo.ICER(
            currency1_code="YYY",
            currency2_code="XXX",
            rate=0.123456789,
            updated=datetime.date.today()
        )
        _icer.save()
        getV('icer').add(_icer)
        svc = ICERJSONService()
        response = svc.v001(
            'XXX', demjson.encode(
                [{'currency': 'YYY', 'price': 83.3333333}]
            )
        )
        
        json = demjson.decode(response)
        self.assertIsInstance(json, dict)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
       
        data = json['data']

        self.assertEqual(
            data, {
                u'prices': [
                    {
                        u'currency': u'XXX',
                        u'price': u"11.00"
                    }
                ],
                u'currency': u'XXX'
            }
        )

        with self.assertRaises(InvalidCurrencyException) as exc:
            svc.v001(
                'ZZZ', demjson.encode(
                    [{'currency': 'YYY', 'price': 83.3333333}]
                )
            )
            self.assertEqual(u"ZZZ", exc.value)
        with self.assertRaises(InvalidCurrencyException) as exc:
            svc.v001(
                'YYY', demjson.encode(
                    [{'currency': 'ZZZ', 'price': 83.3333333}]
                )
            )
            self.assertEqual(u"ZZZ", exc.value)

    def test_calcurr_service(self):
        svc = CalcurrJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertIsInstance(json, dict)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        self.assertEqual(json['data'], ['XXX', 'YYY'])

    def test_poscountries_service(self):
        svc = POSCountriesJSONService()
        response = svc.v001()
        
        json = demjson.decode(response)
        self.assertIsInstance(json, dict)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        self.assertEqual(json['data'], [])

    def test_curnames_service(self):
        svc = CurrencyNamesJSONService()
        response = svc.v001("XXX")
        
        json = demjson.decode(response)
        self.assertIsInstance(json, dict)
        
        self.assertEqual(3, len(json))
        self.assertTrue('isSuccess' in json)
        self.assertTrue('data' in json)
        self.assertTrue('errors' in json)
        self.assertEqual(True, json['isSuccess'])
        self.assertEqual([], json['errors'])
        self.assertFalse(json['data'] is None)
        
        self.assertEqual(json['data'], {"ru": "ruXXX", "en": "enXXX"})


if __name__ == "__main__":
    testoob.main()
