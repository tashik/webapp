# -*- coding: utf-8 -*-
"""
$Id: test_services_json_passbook.py 21770 2016-11-30 11:01:31Z oeremeeva $
"""

import mock
import json
import cherrypy
import testoob
from StringIO import StringIO

from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs
from initializer import init_django
from services.json_services.passbook_service import PassbookJSONService

import config

class TestPassbookJSONService(TestCaseWithPgDBAndVocabs):

    def setUp(self):
        super(TestPassbookJSONService, self).setUp()
        self.s = PassbookJSONService()
        init_django()

    @mock.patch('services.json_services.passbook_service.store_pnr_card')
    def test_pnr_001(self, mock_store_pnr_card):
        f = open(config.APPDIR + '/passbook/tests/data/passbook_pnr_data.json')
        data = f.read()
        f.close()
        pnr_locator = 'JCKQCS'
        created = '2014-10-12'

        mock_store_pnr_card.return_value = 'test-url'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(data)

        response = self.s.pnr_001(pnr_locator, created)
        j = json.loads(response)
        self.assertEqual('test-url', j['data']['card_url'])
        self.assertEqual(mock_store_pnr_card.call_args[0][:2], (pnr_locator, created))
        self.assertEqual(mock_store_pnr_card.call_args[1], {'name': None})

        cherrypy.request.body = StringIO(data)
        self.s.pnr_001(pnr_locator, created, name='LAST/FIRST')
        self.assertEqual(mock_store_pnr_card.call_args[0][:2], (pnr_locator, created))
        self.assertEqual(mock_store_pnr_card.call_args[1], {'name': 'LAST/FIRST'})

    @mock.patch('services.json_services.passbook_service.store_pnr_card')
    def test_pnr_update_001(self, mock_store_pnr_card):
        f = open(config.APPDIR + '/passbook/tests/data/passbook_pnr_data.json')
        data = f.read()
        f.close()
        pnr_locator = 'JCKQCS'
        created = '2014-10-12'

        mock_store_pnr_card.return_value = 'test-url'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(data)

        response = self.s.pnr_update_001(pnr_locator, created)
        j = json.loads(response)
        self.assertFalse(j['data'])
        self.assertEqual(mock_store_pnr_card.call_args[0][:2], (pnr_locator, created))
        self.assertEqual(mock_store_pnr_card.call_args[1], {'quiet_update': True, 'name': None})

        cherrypy.request.body = StringIO(data)
        self.s.pnr_update_001(pnr_locator, created, name='LAST/FIRST')
        self.assertEqual(mock_store_pnr_card.call_args[0][:2], (pnr_locator, created))
        self.assertEqual(mock_store_pnr_card.call_args[1], {'quiet_update': True, 'name': 'LAST/FIRST'})

    @mock.patch('services.json_services.passbook_service.store_bonus_card')
    def test_bonus_001(self, mock_store_pnr_card):
        f = open(config.APPDIR + '/passbook/tests/data/passbook_pnr_data.json')
        data = f.read()
        f.close()
        sabre_id = '88822333'
        tier_level = 'BASIC'

        mock_store_pnr_card.return_value = 'test-url'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(data)

        response = self.s.bonus_001(sabre_id, tier_level)
        j = json.loads(response)
        self.assertEqual('test-url', j['data']['card_url'])

    @mock.patch('services.json_services.passbook_service.store_bonus_card')
    def test_bonus_update_001(self, mock_store_pnr_card):
        f = open(config.APPDIR + '/passbook/tests/data/passbook_pnr_data.json')
        data = f.read()
        f.close()
        sabre_id = '88822333'
        tier_level = 'BASIC'

        mock_store_pnr_card.return_value = 'test-url'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(data)

        response = self.s.bonus_update_001(sabre_id, tier_level)
        j = json.loads(response)
        self.assertFalse(j['data'])

    @mock.patch('services.json_services.passbook_service.store_bpass_card')
    def test_bpass_001(self, mock_store_pnr_card):
        f = open(config.APPDIR + '/passbook/tests/data/passbook_pnr_data.json')
        data = f.read()
        f.close()
        prn = 'CCCCCC'
        passenger_id = '1232123'

        mock_store_pnr_card.return_value = 'test-url'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(data)

        response = self.s.bpass_001(prn, passenger_id)
        j = json.loads(response)
        self.assertEqual('test-url', j['data']['card_url'])

    @mock.patch('services.json_services.passbook_service.store_bpass_card')
    def test_bpass_update_001(self, mock_store_pnr_card):
        f = open(config.APPDIR + '/passbook/tests/data/passbook_pnr_data.json')
        data = f.read()
        f.close()
        prn = 'CCCCCC'
        passenger_id = '1232123'

        mock_store_pnr_card.return_value = 'test-url'

        cherrypy.request.headers['content-type'] = 'application/json'
        cherrypy.request.body = StringIO(data)

        response = self.s.bpass_update_001(prn, passenger_id)
        j = json.loads(response)
        self.assertFalse(j['data'])

if __name__ == '__main__':
    testoob.main()
