# -*- coding: utf-8 -*-

"""
$Id: $
"""


import testoob

import pyramid.vocabulary.mvcc
from pyramid.i18n.message import Message
from pyramid.ormlite import dbquery
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.vocabulary import getV
from pyramid.vocabulary.interfaces import IVocabulary

from rx.i18n.translation import SelfTranslationDomain, self_translated

import _test_data
from _test_data import setup_vocabulary
import models.airport


class TestAirport(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAirport, self).setUp()
        self.model = models.airport.Airport

    def test_model(self):
        ob = self.model.load(airport='XXX')

        self.assertEqual('XXX', ob.airport)
        self.assertEqual('XXXX', ob.icao)
        self.assertEqual(-2, ob.vocab_city_id)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertEqual(True, ob.has_afl_flights)

        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestAirportI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def testModelTitles(self):
        ob = models.airport.Airport.load(airport='XXX')
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestAirportVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAirportVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.airport.AirportsVocabulary)

    def testVocabulary(self):
        v = getV('airports')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue('XXX' in v)
        self.assertFalse('XXY' in v)
        ob = v['XXX']
        self.assertTrue(isinstance(ob, models.airport.Airport))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])

    def testVocabularyRegistration(self):
        v = getV('airports')
        self.assertTrue('XXX' in v)
        self.assertFalse('XXY' in v)
        ob = v['XXX']
        self.assertTrue(isinstance(ob, models.airport.Airport))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update airports SET names = 'ru:AAA|en:BBB' where airport = 'XXX'")
        v = getV('airports')
        ob = v['XXX']
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        v.preload()
        v = getV('airports')
        ob = v['XXX']
        self.assertEqual(ob.names, [u'ru:AAA', u'en:BBB'])


if __name__ == "__main__":
    testoob.main()
