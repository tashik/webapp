# -*- coding: utf-8 -*-
"""
$Id$
"""
import json
import mock
from StringIO import StringIO
from datetime import datetime, date
import cherrypy
import testoob
from zope.component.globalregistry import provideUtility
import pyramid.vocabulary.mvcc
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary import getV
from rx.i18n.translation import SelfTranslationDomain
from services.base.json_base import ContentTypeJSONRequiredException
from services.json_services.meal import AvailableMealJSONService, MealRuleFilter
from services.json_services.meal import RequestFormatError, OriginValidationError, DestinationValidationError, BookingClassValidationError
from services.json_services.meal import AirlineValidationError, FlightDatetimeValidationError, FlightValidationError
from initializer import init_django
import models.meal
import models.ssr_meal
import _test_data


class NewDate(datetime):

    @classmethod
    def utcnow(cls):
        return cls(2015, 12, 1)


class TestAvailableMealService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAvailableMealService, self).setUp()
        cherrypy.request.headers = type(cherrypy.request.headers)()
        provideUtility(SelfTranslationDomain(), name='self_translate')
        self.service = AvailableMealJSONService()
        init_django()

    def registerVocabularies(self):
        super(TestAvailableMealService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.meal.MealRulesVocabulary)
        _test_data.setup_vocabulary(models.meal.MealTimelimitsVocabulary)
        _test_data.setup_vocabulary(models.ssr_meal.SpecialMealVocabulary)

    def tearDown(self):
        self._unregisterTranslationDomains('self_translate')
        super(TestAvailableMealService, self).tearDown()

    @mock.patch('services.json_services.meal.datetime', NewDate)
    def test_service(self):
        cherrypy.request.body = StringIO(json.dumps([]))
        with self.assertRaises(ContentTypeJSONRequiredException):
            self.service.v001()

        cherrypy.request.headers['content-type'] = 'application/json'
        with self.assertRaises(RequestFormatError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({}))
        with self.assertRaises(OriginValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO'}))
        with self.assertRaises(BookingClassValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I'}))
        with self.assertRaises(DestinationValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED'}))
        with self.assertRaises(AirlineValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU'}))
        with self.assertRaises(FlightDatetimeValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-02T00:05'}))
        with self.assertRaises(FlightValidationError):
            self.service.v001()

        valid = json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-02T00:05', 'number': '8'})
        cherrypy.request.body = StringIO(valid)
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {'isSuccess': True, 'errors': [], 'data': {u'meals': [{
            'code': 'VJML',
            'is_available_now': True,
            'name': 'Eastern Orthodoxal Lenten meal',
            'timelimit': 24,
        }]}})

        cherrypy.request.body = StringIO(valid)
        response = self.service.v001(lang='ru')
        result = json.loads(response)
        self.assertEqual(result, {'isSuccess': True, 'errors': [], 'data': {'meals': [{
            'code': 'VJML',
            'is_available_now': True,
            'name': 'Постное меню',
            'timelimit': 24,
        }]}})

        valid = json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-01T23:55', 'number': '8'})
        cherrypy.request.body = StringIO(valid)
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {'isSuccess': True, 'errors': [], 'data': {u'meals': [{
            'code': 'VJML',
            'is_available_now': False,
            'name': 'Eastern Orthodoxal Lenten meal',
            'timelimit': 24,
        }]}})

        cherrypy.request.body = StringIO(json.dumps({'origin': 'svo', 'booking_class': 'i', 'destination': 'led', 'airline': 'su', 'flight_datetime': '2015-12-01t23:55', 'number': 8}))
        response = self.service.v001()
        result = json.loads(response)
        self.assertEqual(result, {'isSuccess': True, 'errors': [], 'data': {u'meals': [{
            'code': 'VJML',
            'is_available_now': False,
            'name': 'Eastern Orthodoxal Lenten meal',
            'timelimit': 24,
        }]}})

        cherrypy.request.body = StringIO(json.dumps({'origin': 'сво', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-01T23:55', 'number': '8'}))
        with self.assertRaises(OriginValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'и', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-01T23:55', 'number': '8'}))
        with self.assertRaises(BookingClassValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'лед', 'airline': 'SU', 'flight_datetime': '2015-12-01T23:55', 'number': '8'}))
        with self.assertRaises(DestinationValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'авиа', 'flight_datetime': '2015-12-01T23:55', 'number': '8'}))
        with self.assertRaises(AirlineValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-01', 'number': '8'}))
        with self.assertRaises(FlightDatetimeValidationError):
            self.service.v001()

        cherrypy.request.body = StringIO(json.dumps({'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'flight_datetime': '2015-12-01T23:55', 'number': '-1'}))
        with self.assertRaises(FlightValidationError):
            self.service.v001()


class TestMealRuleFilter(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestMealRuleFilter, self).setUp()
        self.filter = MealRuleFilter()

    def registerVocabularies(self):
        super(TestMealRuleFilter, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.meal.MealRulesVocabulary)

    def test_find(self):
        result = list(self.filter.find(**{'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'date': date(2015, 12, 10), 'number': 8}))
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0].meal_rule_id, 1)
        self.assertEqual(result[1].meal_rule_id, 9)
        self.assertEqual(list(self.filter.find(airline='NOPE')), [])

    def test_get_first(self):
        result = self.filter.get_first(**{'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'date': date(2015, 12, 10), 'number': 8})
        self.assertEqual(result.meal_rule_id, 1)

        result = self.filter.get_first(airline='NOPE')
        self.assertIsNone(result)

    def test_matches(self):
        vocab = getV('meal_rules')
        self.assertTrue(self.filter.matches(vocab[1], **{'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'date': date(2015, 12, 10), 'number': 8}))
        self.assertFalse(self.filter.matches(vocab[1], **{'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'number': 8}))
        self.assertFalse(self.filter.matches(vocab[2], **{'origin': 'SVO', 'booking_class': 'I', 'destination': 'LED', 'airline': 'SU', 'date': date(2015, 12, 10), 'number': 8}))
        self.assertTrue(self.filter.matches(vocab[9], airline='SU'))

    def test_field_matches(self):
        self.assertTrue(self.filter.field_matches(None, 'anything'))
        self.assertTrue(self.filter.field_matches([], 'anything'))
        self.assertTrue(self.filter.field_matches((), 'anything'))
        self.assertTrue(self.filter.field_matches(('something', 'anything'), 'anything'))
        self.assertFalse(self.filter.field_matches(('something', 'nothing'), 'anything'))
        self.assertFalse(self.filter.field_matches('something', 'anything'))
        self.assertTrue(self.filter.field_matches('anything', 'anything'))
        self.assertFalse(self.filter.field_matches('1,3,5,7-9', 'anything'))
        self.assertFalse(self.filter.field_matches('1,3,5,a-c', 'anything'))
        self.assertTrue(self.filter.field_matches('1,3,5,7-9', '8'))
        self.assertTrue(self.filter.field_matches('1,3,5,7-9', '007'))
        self.assertTrue(self.filter.field_matches('1,3,5,7-9', 5))
        self.assertFalse(self.filter.field_matches('1,3,5,7-9', 6))
        self.assertFalse(self.filter.field_matches('1,a,5,7-9', 5))
        self.assertTrue(self.filter.field_matches('1,3,5,7-9', '1,3,5,7-9'))

if __name__ == '__main__':
    testoob.main()
