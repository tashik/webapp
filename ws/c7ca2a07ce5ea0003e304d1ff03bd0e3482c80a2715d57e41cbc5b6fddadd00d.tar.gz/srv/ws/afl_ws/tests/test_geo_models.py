# -*- coding: utf-8 -*-

"""
$Id$
"""

import testoob

from zope.schema.interfaces import ITokenizedTerm

import pyramid.vocabulary.mvcc
from pyramid.i18n.message import Message
from pyramid.ormlite import dbquery
from pyramid.registry import registerVocabularyIndexer
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs,
                                   TestCaseWithI18N)
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.interfaces import IVocabulary

from rx.i18n.translation import SelfTranslationDomain

import _test_data
from _test_data import setup_vocabulary
import models.geo


class TestWorldRegion(ModelTest, TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestWorldRegion, self).setUp()
        self.model = models.geo.WorldRegion

    def test_model(self):
        ob = self.model.load(world_region_id=1)
        self.assertEqual([u'ru:Европа', 'en:Europe'], ob.names)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)
        self.assertEqual(u'Europe', SelfTranslationDomain().translate(ob.title.msgid))
        self.negotiator.lang = 'ru'
        self.assertEqual(u'Европа', SelfTranslationDomain().translate(ob.title.msgid))


class TestWorldRegionsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestWorldRegionsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.WorldRegionsVocabulary)

    def testVocabularyRegistration(self):
        factory = models.geo.WorldRegionsVocabulary
        self.assertTrue(IRegisterableVocabulary.providedBy(factory))
        factory.register()
        v = getV('world_regions')
        self.assertTrue(1 in v)
        self.assertFalse(2 in v)
        ob = v[1]
        self.assertTrue(isinstance(ob, models.geo.WorldRegion))
        self.assertEqual(ob.names, [u'ru:Европа', 'en:Europe'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update world_regions SET names = 'ru:AAA|en:BBB' where world_region_id = 1")
        v = getV('world_regions')
        ob = v[1]
        self.assertEqual(ob.names, [u'ru:Европа', 'en:Europe'])
        v.preload()
        v = getV('world_regions')
        ob = v[1]
        self.assertEqual(ob.names, [u'ru:AAA', u'en:BBB'])


class TestCountry(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCountry, self).setUp()
        self.model = models.geo.Country

    def test_model(self):
        ob = self.model.load(country='XX')

        self.assertEqual('XXX', ob.iso_code3)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertEqual(1, ob.world_region_id)

        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestCountryI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def testModelTitles(self):
        ob = models.geo.Country.load(country='XX')
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestCountryVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCountryVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CountriesVocabulary)

    def testVocabulary(self):
        v = getV('countries')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue('XX' in v)
        self.assertFalse('XY' in v)
        ob = v['XX']
        self.assertTrue(isinstance(ob, models.geo.Country))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])

    def testVocabularyRegistration(self):
        factory = models.geo.CountriesVocabulary
        self.assertTrue(IRegisterableVocabulary.providedBy(factory))
        factory.register()
        v = getV('countries')
        self.assertTrue('XX' in v)
        self.assertFalse('XY' in v)
        ob = v['XX']
        self.assertTrue(isinstance(ob, models.geo.Country))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update countries SET names = 'ru:AAA|en:BBB' where country = 'XX'")
        v = getV('countries')
        ob = v['XX']
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        v.preload()
        v = getV('countries')
        ob = v['XX']
        self.assertEqual(ob.names, [u'ru:AAA', u'en:BBB'])


class TestCity(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCity, self).setUp()
        self.model = models.geo.City

    def test_model(self):
        ob = self.model.load(city='UUX')

        self.assertEqual('XX', ob.country_code)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertEqual(99.9, ob.lat)
        self.assertEqual(99.9, ob.lon)
        self.assertEqual(True, ob.can_book)
        self.assertEqual('UTC+5', ob.tz)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestCityI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def testModelTitles(self):
        ob = models.geo.City.load(city='UUX')
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestCityVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCityVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)

    def testVocabulary(self):
        v = getV('cities')
        self.assertTrue('UUX' in v)
        self.assertFalse('XXY' in v)
        ob = v['UUX']
        self.assertTrue(isinstance(ob, models.geo.City))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.country_code, u'XX')
        self.assertEqual(ob.lon, 99.9)
        self.assertEqual(ob.lat, 99.9)
        self.assertEqual(ob.can_book, True)

    def testVocabularyRegistration(self):
        v = getV('cities')
        self.assertTrue('UUX' in v)
        self.assertFalse('XXY' in v)
        ob = v['UUX']
        self.assertTrue(isinstance(ob, models.geo.City))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update cities SET names = 'ru:AAA|en:BBB' where city = 'UUX'")
        v = getV('cities')
        ob = v['UUX']
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        v.preload()
        v = getV('cities')
        ob = v['UUX']
        self.assertEqual(ob.names, [u'ru:AAA', u'en:BBB'])


class TestCitiesByVocabIDIndexer(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCitiesByVocabIDIndexer, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.CitiesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(models.geo.CitiesByVocabIDIndexer), 'cities_by_vocab_id_idx')

    def test_add(self):
        vocab = getV('cities')
        idx = getVI('cities_by_vocab_id_idx')

        self.assertEqual(len(idx(context=-1)), 1)
        self.assertTrue(isinstance(idx(context=-1)[0], models.geo.City))
        self.assertEqual(idx(context=-1)[0].city, u'UUX')

        self.assertEqual(len(idx(context=-100)), 0)

        ob = models.geo.City(
            city='AAA',
            country_code='RU',
            lat=10.0,
            lon=-10.10,
            can_book=True,
            names=[u'ru:AAAAAA', u'en:BBBBBB'],
            tz=u'UTC-7',
            vocab_id=-100
        )

        vocab.update_many([ob])

        self.assertIn('AAA', vocab)
        self.assertEqual(len(idx(context=-100)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=-100)), 1)
        self.assertTrue(isinstance(idx(context=-100)[0], models.geo.City))
        self.assertEqual(idx(context=-100)[0].city, u'AAA')

    def test_change(self):
        vocab = getV('cities')
        idx = getVI('cities_by_vocab_id_idx')

        self.assertEqual(len(idx(context=-1)), 1)
        self.assertEqual(len(idx(context=-100)), 0)

        ob = models.geo.City(
            city='UUX',
            country_code='XX',
            lat=99.9,
            lon=99.9,
            can_book=True,
            names=[u'ru:XXX', u'en:YYY'],
            tz=u'UTC+5',
            vocab_id=-100
        )

        vocab.update_many([ob])

        self.assertIn('UUX', vocab)
        self.assertEqual(len(idx(context=-1)), 1)
        self.assertEqual(len(idx(context=-100)), 0)

        idx._reindex()

        self.assertEqual(len(idx(context=-1)), 0)
        self.assertEqual(len(idx(context=-100)), 1)
        self.assertEqual(idx(context=-100)[0].city, u'UUX')

    def test_delete(self):
        vocab = getV('cities')
        idx = getVI('cities_by_vocab_id_idx')

        self.assertEqual(len(idx(context=-1)), 1)

        ob = idx(context=-1)[0]
        ob.delete()
        vocab.delete_many([ITokenizedTerm(ob).token])

        self.assertNotIn('UUX', vocab)
        self.assertEqual(len(idx(context=-1)), 1)

        idx._reindex()

        self.assertEqual(len(idx(context=-1)), 0)


class TestTown(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestTown, self).setUp()
        self.model = models.geo.Town

    def test_model(self):
        ob = self.model.load(town_id=-1)

        self.assertEqual('XX', ob.country_code)
        self.assertEqual([u'ru:XXX', u'en:YYY'], ob.names)
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)


class TestTownI18NSupport(TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def testModelTitles(self):
        ob = models.geo.Town.load(town_id=-1)
        self.assertTrue(isinstance(ob.title, Message))

        self.assertEqual(u'YYY', SelfTranslationDomain().translate(ob.title.msgid))

        self.negotiator.lang = 'ru'
        self.assertEqual(u'XXX', SelfTranslationDomain().translate(ob.title.msgid))


class TestTownVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestTownVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.geo.TownsVocabulary)

    def testVocabulary(self):
        v = getV('towns')
        self.assertTrue(-1 in v)
        self.assertFalse(-2 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.geo.Town))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        self.assertEqual(ob.country_code, u'XX')

    def testVocabularyRegistration(self):
        v = getV('towns')
        self.assertTrue(-1 in v)
        self.assertFalse(-2 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.geo.Town))
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update towns SET names = 'ru:AAA|en:BBB' where town_id = -1")
        v = getV('towns')
        ob = v[-1]
        self.assertEqual(ob.names, [u'ru:XXX', u'en:YYY'])
        v.preload()
        v = getV('towns')
        ob = v[-1]
        self.assertEqual(ob.names, [u'ru:AAA', u'en:BBB'])


if __name__ == "__main__":
    testoob.main()
