# -*- coding: utf-8 -*-
import json
from pyramid.registry import registerVocabularyIndexer
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs, TestCaseWithI18N
from pyramid.vocabulary import getV
from pyramid.vocabulary.indexer import VocabularyIndexerFactory
import pyramid.vocabulary.mvcc
import testoob

import _test_data
from models.air import AircraftTypesVocabulary
from models.airport import AirportsVocabulary
from models.co2 import EmissionVocabulary, CoefficientsVocabulary
from models.geo import CitiesVocabulary, CitiesByVocabIDIndexer
from services.csv.co2 import CO2AllData
from services.json_services.co2_airports import CO2Airports
from services.json_services.co2_calc import CO2Calculate


class TestCO2Services(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCO2Services, self).setUp()

    def tearDown(self):
        super(TestCO2Services, self).tearDown()

    def registerVocabularies(self):
        super(TestCO2Services, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(EmissionVocabulary)
        _test_data.setup_vocabulary(CoefficientsVocabulary)
        _test_data.setup_vocabulary(CitiesVocabulary)
        _test_data.setup_vocabulary(AirportsVocabulary)
        _test_data.setup_vocabulary(AircraftTypesVocabulary)
        registerVocabularyIndexer(VocabularyIndexerFactory(CitiesByVocabIDIndexer), 'cities_by_vocab_id_idx')

    def test_airpots_service(self):
        svc = CO2Airports()
        response = svc.index()

        json_data = json.loads(response)
        self.assertIsInstance(json_data, dict)
        self.assertEqual(3, len(json_data))
        self.assertIn('isSuccess', json_data)
        self.assertIn('data', json_data)
        self.assertIn('errors', json_data)
        self.assertEqual(True, json_data['isSuccess'])
        self.assertEqual([], json_data['errors'])
        self.assertFalse(json_data['data'] is None)

        items = json_data['data']
        self.assertIsInstance(items, dict)
        self.assertEqual(1, len(items))
        self.assertIn('airports', items)
        self.assertEqual(1, len(items['airports']))

        airports = items['airports'][0]
        self.assertIsInstance(airports, dict)
        self.assertEqual(8, len(airports))

        self.assertIn('from', airports)
        self.assertEqual(airports['from'], 'XXX')

        self.assertIn('from_city', airports)
        self.assertEqual(airports['from_city'], 'UUY')

        for key in ['from_city_name', 'to_city_name', 'to_name']:
            self.assertIn(key, airports)
            # self.assertTrue(isinstance(airports[key], dict), airports[key].__class__)
            # self.assertTrue(all(['ru' in airports[key], 'en' in airports[key]]))
            # self.assertEqual(airports[key]['ru'], 'AAA')
            # self.assertEqual(airports[key]['en'], 'BBB')

        self.assertIn('from_name', airports)
        # self.assertTrue(isinstance(airports['from_name'], dict), airports['from_name'].__class__)
        # self.assertTrue(all(['ru' in airports['from_name'], 'en' in airports['from_name']]))
        # self.assertEqual(airports['from_name']['ru'], 'XXX')
        # self.assertEqual(airports['from_name']['en'], 'YYY')

        self.assertIn('to', airports)
        self.assertEqual(airports['to'], 'XXZ')

        self.assertIn('to_city', airports)
        self.assertEqual(airports['to_city'], 'UUY')

    def test_calc_service(self):
        svc = CO2Calculate()
        coeffs_vocab = getV('coefficients')
        coeffs_data = {key:coeffs_vocab[key] for key in coeffs_vocab.keys()}
        response = svc.index(
            param_from='XXX',
            param_to='XXZ'
        )

        json_data = json.loads(response)
        self.assertIsInstance(json_data, dict)
        self.assertEqual(3, len(json_data))
        self.assertIn('isSuccess', json_data)
        self.assertIn('data', json_data)
        self.assertIn('errors', json_data)
        self.assertEqual(True, json_data['isSuccess'])
        self.assertEqual([], json_data['errors'])
        self.assertFalse(json_data['data'] is None)

        items = json_data['data']
        self.assertIsInstance(items, dict)
        self.assertEqual(1, len(items))
        self.assertIn('segment', items)
        self.assertEqual(2, len(items['segment']))

        for em_item in items['segment']:
            self.assertIsInstance(em_item, dict)
            self.assertEqual(7, len(em_item))

            self.assertIn('aircraft_name', em_item)

            self.assertIn('aircraft_type', em_item)
            self.assertEqual(em_item['aircraft_type'], 'OoOo')

            self.assertIn('service_class', em_item)
            self.assertIn(em_item['service_class'], ['business', 'economy'])

            self.assertIn('co2_emission', em_item)
            self.assertEqual(em_item['co2_emission'], 123.456 * coeffs_data[em_item['service_class']].coefficient)

            self.assertIn('distance', em_item)
            self.assertEqual(em_item['distance'], 1234.567)

            self.assertIn('from', em_item)
            self.assertEqual(em_item['from'], 'XXX')

            self.assertIn('to', em_item)
            self.assertEqual(em_item['to'], 'XXZ')

        response = svc.index(
            param_from='XXX',
            param_to='XXZ',
            service_class='business'
        )

        json_data = json.loads(response)
        self.assertIsInstance(json_data, dict)
        self.assertEqual(3, len(json_data))
        self.assertIn('isSuccess', json_data)
        self.assertIn('data', json_data)
        self.assertIn('errors', json_data)
        self.assertEqual(True, json_data['isSuccess'])
        self.assertEqual([], json_data['errors'])
        self.assertFalse(json_data['data'] is None)

        items = json_data['data']
        self.assertIsInstance(items, dict)
        self.assertEqual(1, len(items))
        self.assertIn('segment', items)
        self.assertEqual(1, len(items['segment']))

    def test_co2_csv_service(self):
        svc = CO2AllData()
        response = svc.index()

        self.assertIsInstance(response, list)
        self.assertEqual(3, len(response))

        response_header = ','.join(
            ['from', 'to', 'distance', 'aircraft_type', 'aircraft_name', 'service_class', 'co2_emission']
        ) + '\r\n'
        self.assertTrue(response[0] == response_header)

        self.assertTrue(response[1] == 'XXX,XXZ,1234.567,OoOo,,business,246.912\r\n')
        self.assertTrue(response[2] == 'XXX,XXZ,1234.567,OoOo,,economy,123.456\r\n')


if __name__ == "__main__":
    testoob.main()


