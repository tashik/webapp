#!/usr/bin/env python
# -*- coding: utf-8

"""
$Id: $
"""
import cherrypy
import mock
import testoob

from pyramid.tests import testlib
from pyramid.ui.utils import htmlTree

import access
import services.heartbeat

import config


class TestHeartbeatService(testlib.TestCaseWithCP, testlib.TestCaseWithPgDB,
                           testlib.TestCaseWithLenientRoutes, ):
    def setUp(self):
        super(TestHeartbeatService, self).setUp()
        self.svc = services.heartbeat.HeartbeatService()

    def test_status(self):
        services.heartbeat.StatusMonitor()
        with mock.patch('cherrypy.tools') as mock_tools:
            mock_tools.status.seen_threads = {}
            res = self.svc.server_status()
        html = htmlTree(res)
        for title in ("Current time", "Start time", "Uptime", "Requests served"):
            self.assertTrue(html.xpath("/html/body/p/text()[starts-with(., '%s:')]" % title))

            
class TestAccess(testlib.TestCaseWithCP):
    @mock.patch('services.heartbeat.config.MONITORING_ACCESS_IP', ['1.2.3.4'])
    def test_monitoring_access(self):
        with mock.patch('access.cherrypy.request.remote.ip', '1.2.3.4'):
            access.check_monitoring_access()
        with mock.patch('access.cherrypy.request.remote.ip', '1.2.3.5'):
            self.assertRaises(cherrypy.HTTPError, access.check_monitoring_access)
        with mock.patch('access.cherrypy.request.remote.ip', '1.2.3.4'):
            with mock.patch('access.cherrypy.request.headers', {'X-Forwarded-For': '1.2.3.6'}):
                self.assertRaises(cherrypy.HTTPError, access.check_monitoring_access)
            

if __name__ == "__main__":
    testoob.main(**config.TESTOOB_CONFIG)
