# -*- coding: utf-8 -*-

"""
$Id: test_services_json_offices.py 35220 2018-07-22 10:33:38Z apinsky $
"""

import testoob
import unittest

import pyramid.vocabulary.mvcc
from zope.component import globalSiteManager as gsm
from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs,TestCaseWithI18N
from rx.i18n.translation import SelfTranslationDomain
import demjson
import models.office
import models.geo
import models.airport
import _test_data
import services.json_services.offices
from _test_data import setup_vocabulary

class TestOfficeJSONService(TestCaseWithPgDBAndVocabs, TestCaseWithI18N):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOfficeJSONService, self).setUp()
        self.td = SelfTranslationDomain()
        gsm.registerUtility(self.td, name='self_translate')
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.office.OfficeVocabulary)
        setup_vocabulary(models.geo.CountriesVocabulary)
        setup_vocabulary(models.geo.TownsVocabulary)
        setup_vocabulary(models.airport.AirportsVocabulary)
        setup_vocabulary(models.office.OfficeCategoryVocabulary)
        setup_vocabulary(models.office.OfficeTravelOptionVocabulary)
        self.s002 = services.json_services.offices.OfficeJSONServiceV002()
        self.s003 = services.json_services.offices.OfficeJSONServiceV003()

    def tearDown(self):
        gsm.unregisterUtility(self.td)
        super(TestOfficeJSONService, self).tearDown()

    def test_v002(self):
        u"""Проверка структура данных"""
        data = self.s002.v002()
        offices = demjson.decode(data)
        self.assertEqual(3, len(offices))
        self.assertTrue('data' in offices)
        self.assertTrue('isSuccess' in offices)
        self.assertTrue('errors' in offices)
        self.assertEqual(True, offices['isSuccess'])
        self.assertEqual([], offices['errors'])

        self.assertEqual(5, len(offices['data']))                # проверка корневого элемента data
        item = offices['data'][1]
        self.assertEqual([u'812-111-11-11'], item['phone'])               # проверка элемента простого типа данных
        self.assertEqual([u'812-111-11-11'], item['fax'])
        self.assertEqual(1, len(item['title']))                  # проверка переводимого элемента данных
        self.assertEqual([u'en'] , item['title'].keys())
        self.assertEqual(u'YYY, YYY', item['title'][u'en'])
        self.assertTrue(isinstance(item['location'], dict))
        self.assertEqual(99.99, item['location']['lat'])
        self.assertEqual(99.99, item['location']['lon'])
        
        item = offices['data'][2]
        self.assertTrue(item['location'] is None)

    def test_language(self):
        u"""Проверка перевода"""
        def get_city(lang):
            self.negotiator.lang = lang
            data = self.s002.v002()
            offices = demjson.decode(data)
            city = offices['data'][0]['city']['title']
            return city
        self.assertEqual({u'en':u'YYY'},get_city('en'))
        self.assertIn(get_city('de'),[{u'de':u'YYY'},{u'de':u'XXX'}])
        self.assertEqual({u'ru':u'XXX'},get_city('ru'))

    def test_get_json_ml(self):
        u"""Проверка функции, преобразующая ML в словарь для JSON с учетом lang"""
        ml = [u'en:Eng', u'ru:Рус']
        d = services.json_services.get_json_ml(ml,None)
        self.assertIsInstance(d, dict)
        self.assertIn('en', d.keys())
        self.assertIn('ru', d.keys())
        self.assertEqual(d['en'], u'Eng')
        self.assertEqual(d['ru'], u'Рус')
        d = services.json_services.get_json_ml(ml,'en')
        self.assertIn('en', d.keys())
        self.assertEqual(d.keys(), ['en'])
        self.assertEqual(d['en'], 'Eng')

    def test_v003(self):
        data = self.s003.v003()
        answer = demjson.decode(data)
        self.assertEqual(3, len(answer))
        self.assertTrue('data' in answer)
        self.assertTrue('isSuccess' in answer)
        self.assertTrue('errors' in answer)
        self.assertEqual(True, answer['isSuccess'])
        self.assertEqual([], answer['errors'])
        self.assertEqual(1, len(answer['data']))
        category = answer['data'][0]
        self.assertEqual(5, len(category))
        self.assertIn('city', category.keys())
        self.assertIn('title', category['city'].keys())
        self.assertEqual(u'XXX', category['city']['title']['ru'])
        self.assertEqual(u'YYY', category['city']['title']['en'])
        self.assertIn('country', category.keys())
        self.assertIn('title', category['country'].keys())
        self.assertEqual(u'XXX', category['country']['title']['ru'])
        self.assertEqual(u'YYY', category['country']['title']['en'])
        self.assertEqual(u'Рус', category['description']['ru'])
        self.assertEqual(u'Eng', category['description']['en'])
        self.assertEqual(u'Рус', category['title']['ru'])
        self.assertEqual(u'Eng', category['title']['en'])
        self.assertIn('offices', category.keys())
        self.assertEqual(3, len(category['offices']))

        office = category['offices'][0]
        self.assertEqual(22, len(office))
        self.assertEqual(u'Рус', office['address']['ru'])
        self.assertEqual(u'Eng', office['address']['en'])
        self.assertEqual(u'Рус', office['worktime']['ru'])
        self.assertEqual(u'Eng', office['worktime']['en'])
        self.assertEqual(u'Рус', office['description']['ru'])
        self.assertEqual(u'Eng', office['description']['en'])
        self.assertEqual(u'XXX', office['airport_name']['ru'])
        self.assertEqual(u'YYY', office['airport_name']['en'])
        self.assertEqual(u'XXX', office['airport'])
        self.assertEqual(123, office['distance_to_airport'])
        self.assertEqual(123, office['transfer_time_public'])
        self.assertEqual(123, office['transfer_time_automobile'])
        self.assertEqual(123, office['transfer_time_foot'])
        self.assertEqual([u'some@some.ru'], office['email'])
        self.assertEqual([u'812-111-11-11'], office['fax'])
        self.assertEqual([u'812-111-11-11'], office['phone'])
        self.assertEqual(True, office['in_airport'])
        self.assertEqual(True, office['insurance_policy'])
        self.assertEqual(True, office['new_office'])
        self.assertEqual(True, office['noncash_booking'])
        self.assertEqual(99.99, office['location']['lat'])
        self.assertEqual(99.99, office['location']['lon'])
        self.assertEqual(u'http://some.ru/ru.jpg', office['location_map']['ru'])
        self.assertEqual(u'http://some.ru/en.jpg', office['location_map']['en'])
        self.assertEqual(u'Рус', office['title']['ru'])
        self.assertEqual(u'Eng', office['title']['en'])
        self.assertEqual(u'', office['important_info']['ru'])
        self.assertIn('travels', office.keys())
        self.assertEqual(len(office['travels']), 1)
        travel = office['travels'][0]
        self.assertEqual(len(travel), 3)
        self.assertEqual(u'F', travel['type'])
        self.assertEqual(123, travel['time'])
        self.assertEqual(u'Рус', office['description']['ru'])
        self.assertEqual(u'Eng', office['description']['en'])


        office = category['offices'][2]
        self.assertIsNone(office['airport_name'])

if __name__ == "__main__":
    testoob.main()
