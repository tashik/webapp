# -*- coding: utf-8 -*-

"""
$Id: $
"""


from pyramid.ormlite.utils import runSQL
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.vocabulary import getV


def createTestData():
    sql_text = u'''
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXX','XXXX','ru:XXX|en:YYY',99.9,99.9,-2,TRUE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXZ','XXYY','ru:AAA|en:BBB',11.1,22.0,-2,TRUE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXA','XXAA','ru:CCC|en:DDD',1.0,12.12,-1,FALSE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXB','XXBB','ru:EEE|en:FFF',10.0,20.0,-3,FALSE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXC','XXCC','ru:KKK|en:LLL',20.0,30.0,-4,FALSE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXD','XXDD','ru:MMM|en:NNN',25.0,35.0,-4,FALSE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXE','XXEE','ru:OOO|en:PPP',15.0,25.0,-1,FALSE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXF','XXFF','ru:QQQ|en:RRR',null,25.0,-1,FALSE);
insert into airports (airport,icao,names,lat,lon,vocab_city_id,has_afl_flights) values ('XXG','XXGG','ru:SSS|en:TTT',20.0,null,-3,FALSE);
insert into world_regions (world_region_id, names) values (1, 'ru:Европа|en:Europe');
insert into countries (country,iso_code3,names,world_region_id,currency_code,phone_code) values ('XX','XXX','ru:XXX|en:YYY',1,'XXX','+X');
insert into countries (country,iso_code3,names,world_region_id,currency_code,phone_code) values ('RU','RUS','ru:Россия|en:Russia',1,'XXX','+7');
insert into countries (country,iso_code3,names,world_region_id,currency_code,phone_code) values ('US','USA','ru:США|en:USA',1,'XXX','+1');
insert into countries (country,iso_code3,names,world_region_id,currency_code,phone_code) values ('CN','CIN','ru:Китай|en:China',1,'XXX','+86');
insert into currencies (code, names, used_in_calc, minor_unit) VALUES ('XXX', 'ru:ruXXX|en:enXXX', TRUE, 2);
insert into currencies (code, names, used_in_calc, minor_unit) VALUES ('YYY', 'ru:ruYYY|en:enYYY', TRUE, 2);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUX','XX','ru:XXX|en:YYY',99.9,99.9,TRUE,'UTC+5',-1);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUY','XX','ru:AAA|en:BBB',11.1,22.0,TRUE,'UTC+0',-2);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUZ','XX','ru:CCC|en:DDD',1.0,12.12,TRUE,'UTC-7',-3);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUU','XX','ru:EEE|en:FFF',10.0,20.0,TRUE,'UTC+2',-4);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUW','XX','ru:KKK|en:LLL',20.0,30.0,TRUE,'UTC+4',-5);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUV','XX','ru:MMM|en:NNN',25.0,35.0,FALSE,'UTC+4',-6);
insert into cities (city,country,names,lat,lon,can_book,tz,vocab_id) values ('UUT','XX','ru:OOO|en:PPP',null,30.0,TRUE,'UTC-5',-7);
insert into towns (town_id,country,names) values (-1,'XX','ru:XXX|en:YYY');
insert into office_categories (office_category_id,office_category_description, names, city) values (1, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', -1 );
insert into office_categories (office_category_id,office_category_description, names, city) values (-1, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', -1 );
insert into offices (office_id, names,office_description, email,fax, phone, lat, lon, address, worktime, in_airport, insurance_policy, noncash_booking, new_office, airport, distance_to_airport, office_category, location_map, transfer_time_public, transfer_time_automobile, transfer_time_foot)
             values (-1, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 99.99, 99.99, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, 'XXX', 123, -1,'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123);
insert into offices (office_id, names, office_description, email,fax, phone,  address, worktime, in_airport, insurance_policy, noncash_booking, new_office, airport, distance_to_airport, office_category, location_map, transfer_time_public, transfer_time_automobile, transfer_time_foot)
             values (-2, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, 'XXX', 123, -1,'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123);
insert into offices (office_id, names,office_description, email,fax, phone, lat, lon, address, worktime, in_airport, insurance_policy, noncash_booking, new_office, airport, distance_to_airport, office_category, location_map, transfer_time_public, transfer_time_automobile, transfer_time_foot)
             values (-4, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 99.99, 99.99, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, 'XXX', 123, 1,'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123);
insert into offices (office_id, names, office_description, email,fax, phone, lat, lon, address, worktime, in_airport, insurance_policy, noncash_booking, new_office, airport, distance_to_airport, office_category, location_map, transfer_time_public, transfer_time_automobile, transfer_time_foot)
             values (-5, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 99.99, 99.99, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, 'XXX', 123, 1,'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123);
insert into offices (office_id, names, office_description, email,fax, phone,  address, worktime, in_airport, insurance_policy, noncash_booking, new_office, airport, distance_to_airport, office_category, location_map, transfer_time_public, transfer_time_automobile, transfer_time_foot)
             values (-6, 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', 'some@some.ru', '812-111-11-11', '812-111-11-11', 'en:Eng|ru:Рус', 'en:Eng|ru:Рус', True, True, True, True, 'ZZZ', 123, 1, 'ru:http://some.ru/ru.jpg|en:http://some.ru/en.jpg', 123, 123, 123);
insert into office_travel_options (office_travel_option_id, office_id,travel_type, office_travel_option_description,travel_time) values (-2, -5, 'F', 'en:Eng|ru:Рус', 123);
insert into office_travel_options (office_travel_option_id, office_id,travel_type, office_travel_option_description,travel_time) values (-1, -1, 'F', 'en:Eng|ru:Рус', 123);
insert into aircraft_types  (aircraft_type_id,ohd_code,iata,icao,pax_capacity,cargo_capacity,f,c,y,names) values (-1, 'OoOo', 'XXX', 'XYZ0', 100, 30, 70, 20, 10, 'en:Boeing 797|ru:Боинг 797');
insert into loyalty_programs (loyalty_program_id, name, sabre_id) values (-1, 'test1', 'XX');
insert into loyalty_programs (loyalty_program_id, name, sabre_id) values (-2, 'test2', 'YY');
insert into professional_areas (professional_area_id, names) values (-1, 'ru:XXX1|en:YYY1');
insert into professional_areas (professional_area_id, names) values (-2, 'ru:XXX2|en:YYY2');

insert into co2_emission (emission_id, airport_from, airport_to, distance, aircraft_type, emission) values (1, 'XXX', 'XXZ', 1234.567, -1, 123.456);
insert into co2_coefficients (service_class, coefficient) values ('economy', 1.00);
insert into co2_coefficients (service_class, coefficient) values ('business', 2.00);
insert into additional_info (additional_info_id, weight, created, names, condition, position) values (1, 10, '2015-10-28', 'ru:Из XX|en:From XX', '[{"country_from": "XX"}]', 'flight');
insert into additional_info (additional_info_id, weight, created, names, condition, position) values (2, 20, '2015-10-28', 'ru:В UUZ|en:To UUZ', '[{"city_to": "UUZ"}]', 'flight');
insert into additional_info (additional_info_id, weight, created, names, condition, position) values (3, 20, '2015-10-29', 'ru:Из Европы|en:From Europe', '[{"world_region_from": 1}]', 'flight');
insert into additional_info (additional_info_id, weight, created, names, condition, position) values (4, 20, '2015-10-29', 'ru:Не Аэрофлот|en:Not Aeroflot', '[{"country_from": "XX", "airline": "not SU"}]', 'flight');
insert into additional_info (additional_info_id, weight, created, names, condition, position) values (5, 20, '2015-10-29', 'ru:Забронировано в США|en:Booked in USA', ' [{"booking_country":"US","country_from":"US"},{"booking_country":"US","country_to":"US"}]', 'flight');
insert into additional_info (additional_info_id, weight, created, names, condition, position) values (6, 20, '2015-10-29', 'ru:Из Европы|en:From Europe', '[{"world_region_from": 2}]', 'search');

insert into charity_funds (charity_funds_id, names, logo_url, image_url, charity_short_description, charity_description, url, transfer_conditions, news_url, news_mv_url, donate_miles_url, donate_miles_mv_url, stats_charity_funds_url, rss_url, status, weight, create_date, modify_date, charity_id, contacts) values
(-1, 'en:First charity funds|ru:Первый фонд', 'en:http://aeroflot.ru/logo.png|ru:http://aeroflot.ru/logo.png',
'en:http://aeroflot.ru/image.png|ru:http://aeroflot.ru/image.png', 'ru:Это короткое описание|en:This is short description',
'ru:Это описание|en:This is description', 'en:http://aeroflot.ru/|ru:http://aeroflot.ru/',
'en:http://aeroflot.ru/|ru:http://aeroflot.ru/', 'en:http://aeroflot.ru/news|ru:http://aeroflot.ru/news',
'en:http://aeroflot.ru/pda/news|ru:http://aeroflot.ru/pda/news', 'http://aeroflot.ru/donate_miles',
'http://aeroflot.ru/donate_miles_mv',
'http://aeroflot.ru/stats', '', 'P', 10, '2015-10-29', '2016-10-30', '12345156', 'ru:Москва'),
(-2, 'en:Second charity funds|ru:Второй фонд', 'en:http://aeroflot.ru/logo2.png|ru:http://aeroflot.ru/logo2.png',
'en:http://aeroflot.ru/image2.png|ru:http://aeroflot.ru/image2.png', 'ru:Это второе короткое описание|en:This is second short description',
'ru:Это второе описание|en:This is second description', 'en:http://aeroflot.ru/2fund|ru:http://aeroflot.ru/2fund',
'en:http://aeroflot.ru/2fund|ru:http://aeroflot.ru/2fund', 'en:http://aeroflot.ru/2fund/news|ru:http://aeroflot.ru/2fund/news',
'en:http://aeroflot.ru/pda/2fund/news|ru:http://aeroflot.ru/pda/2fund/news', 'http://aeroflot.ru/2fund/donate_miles',
'http://aeroflot.ru/2fund/donate_miles_mv',
'http://aeroflot.ru/2fund/stats', 'http://aeroflot.ru/2fund/rss', 'P', 10, '2015-10-29', '2016-10-30', '223', 'ru:Москва2'),
(-3, 'en:Deactivate charity funds|ru:Деактивированный фонд', 'en:http://aeroflot.ru/logo_d.png|ru:http://aeroflot.ru/logo_d.png',
'en:http://aeroflot.ru/image_d.png|ru:http://aeroflot.ru/image_d.png', 'ru:Это деактивированное короткое описание|en:This is deactivate short description',
'ru:Это деактивированное описание|en:This is deactivate description', 'en:http://aeroflot.ru/2fund|ru:http://aeroflot.ru/Dfund',
'en:http://aeroflot.ru/2fund|ru:http://aeroflot.ru/2fund', 'en:http://aeroflot.ru/2fund/news|ru:http://aeroflot.ru/2fund/news',
'en:http://aeroflot.ru/pda/2fund/news|ru:http://aeroflot.ru/pda/2fund/news', 'http://aeroflot.ru/2fund/donate_miles',
'http://aeroflot.ru/2fund/donate_miles_mv',
'http://aeroflot.ru/2fund/stats', 'http://aeroflot.ru/2fund/rss', 'S', 10, '2015-10-29', '2016-10-30', '221', 'ru:Москва2');;

insert into meal_rules (meal_rule_id, date_from, date_to, numbers, airlines, origins, destinations, booking_classes, special_meal) values
(1, '2015-12-01', '2016-01-01', '1,3,5,7-9', 'SU,FV', 'GOJ,SVO', 'LED,JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(2, '2015-12-11', '2016-01-01', '1,3,5,7-9', 'SU,FV', 'GOJ,SVO', 'LED,JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(3, '2015-12-01', '2015-12-09', '1,3,5,7-9', 'SU,FV', 'GOJ,SVO', 'LED,JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(4, '2015-12-01', '2016-01-01', '1,3,5,7', 'SU,FV', 'GOJ,SVO', 'LED,JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(5, '2015-12-01', '2016-01-01', '1,3,5,7-9', 'FV', 'GOJ,SVO', 'LED,JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(6, '2015-12-01', '2016-01-01', '1,3,5,7-9', 'SU,FV', 'GOJ', 'LED,JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(7, '2015-12-01', '2016-01-01', '1,3,5,7-9', 'SU,FV', 'GOJ,SVO', 'JFK', 'C,D,J,I', 'BBML,CHML,VJML'),
(8, '2015-12-01', '2016-01-01', '1,3,5,7-9', 'SU,FV', 'GOJ,SVO', 'LED,JFK', 'C,D,J', 'BBML,CHML,VJML'),
(9, NULL, NULL, NULL, 'SU', NULL, NULL, NULL, 'BBML,CHML,VJML');
insert into meal_timelimits (meal_timelimit_id, origin, special_meal, timelimit) values (1, 'SVO,LED', 'VJML,VGML', 24);
insert into vocab_special_meal (code, names) values ('VJML', 'ru:Постное меню|en:Eastern Orthodoxal Lenten meal');

insert into ibeacons(unique_id, device_id, description, message, message_type, location_lat, location_lon, device_major, device_minor, manufacturer_guid, scheme_android, scheme_ios, scheme_winphone)
    values
    (-1, 'ABC', 'en:Description 1|ru:Описание 1', 'en:Message 1|ru:Сообщение 1', 'special_offers', 55.751432, 37.596561, 4660, 5590, 'f7826da64fa24e988024bc5b71e0893e', 'afl://menu/special-offers1', 'afl://menu/special-offers2', 'afl://menu/special-offers3'),
    (-2, 'DEF', 'en:Description 2|ru:Описание 2', 'en:Message 2|ru:Сообщение 2', 'other_offers', 50.751432, 30.596561, 4661, 5591, 'f7826da64fa24e988024bc5b71e0893f', null, null, null),
    (-3, 'GHI', 'en:Description 3|ru:Описание 3', 'en:Message 3|ru:Сообщение 3', 'something', null, null, 4662, 5592, 'f7826da64fa24e988024bc5b71e0893a', 'afl://menu/something1', 'afl://menu/something2', 'afl://menu/something3');

'''
    runSQL(sql_text)


def setup_vocabulary(vocab_class):
    IRegisterableVocabulary(vocab_class).register()
    vocab = getV(vocab_class.regName)
    if hasattr(vocab, 'preload'):
        vocab.preload()
    return vocab
