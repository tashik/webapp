# -*- coding: utf-8 -*-

"""
$Id: test_models.py 35222 2018-07-22 15:36:50Z apinsky $
"""

from datetime import date
from StringIO import StringIO
from zipfile import ZipFile
import csv
import datetime
import testoob
from zope.component.globalregistry import provideUtility
import pyramid.vocabulary.mvcc
from pyramid.ormlite import dbquery
from pyramid.i18n import translate
from pyramid.i18n.message import Message
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.tests.testlib import ModelTest, TestCaseWithPgDBAndVocabs, TestCaseWithI18N 
from pyramid.vocabulary import getV
from rx.i18n.translation import SelfTranslationDomain
import models.additional_info
import models.charity_funds
import models.geo
import models.meal
import models.ssr_meal
import models.ibeacon
import _test_data
from _test_icer_sftp_server import ICERSFTPServer
import config


class TestAdditionalInfo(ModelTest, TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAdditionalInfo, self).setUp()
        self.model = models.additional_info.AdditionalInfo
        provideUtility(SelfTranslationDomain(), name='self_translate')

    def tearDown(self):
        super(TestAdditionalInfo, self).tearDown()
        self._unregisterTranslationDomains('self_translate')

    def test_model(self):
        ob = self.model.load(additional_info_id=1)
        self.assertEqual(ob.weight, 10)
        self.assertEqual(ob.created, date(2015, 10, 28))
        self.assertEqual(ob.condition, [{'country_from': 'XX'}])
        self.assertEqual(ob.names, [u'ru:Из XX', 'en:From XX'])
        self.assertTrue(isinstance(ob.title, Message))
        self.assertEqual('', ob.description)
        self.assertEqual(u'From XX', translate(ob.title, domain='self_translate'))
        self.negotiator.lang = 'ru'
        self.assertEqual(u'Из XX', translate(ob.title, domain='self_translate'))

    def test_matches(self):
        ob = self.model(condition=[
            {'first': 1, 'second': 2},
            {'one': 1, 'two': 2},
        ], position='flight')
        self.assertTrue(ob.matches(first=1, second=2, third=3))
        self.assertTrue(ob.matches(first=1, second=2))
        self.assertFalse(ob.matches(first=1, second='invalid'))
        self.assertFalse(ob.matches(first=1))
        self.assertTrue(ob.matches(one=1, two=2))
        self.assertFalse(ob.matches(first=1, two=2))


class TestAdditionalInfoVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestAdditionalInfoVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.additional_info.AdditionalInfoVocabulary)

    def test_vocabulary_registration(self):
        factory = models.additional_info.AdditionalInfoVocabulary
        self.assertTrue(IRegisterableVocabulary.providedBy(factory))
        factory.register()
        v = getV('additional_info')
        self.assertTrue(1 in v)
        self.assertFalse(0 in v)
        ob = v[1]
        self.assertTrue(isinstance(ob, models.additional_info.AdditionalInfo))
        self.assertEqual(ob.names, [u'ru:Из XX', 'en:From XX'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update additional_info SET names='ru:AAA|en:BBB' where additional_info_id = 1")
        ob = v[1]
        self.assertEqual(ob.names, [u'ru:Из XX', 'en:From XX'])
        v.preload()
        ob = v[1]
        self.assertEqual(ob.names, [u'ru:AAA', u'en:BBB'])


class TestICERVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestICERVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(
            models.geo.ICERVocabulary
        )
        io = StringIO()
        archive = ZipFile(io, mode="w")
        csv_handle = StringIO()
        writer = csv.writer(csv_handle)
        writer.writerow(["cur1", "cur2", "dt", "rt"])
        self.date = datetime.date.today()
        dts = self.date.strftime("%d/%m/%Y")
        writer.writerow(["EUR", "RUB", dts, "100"])
        writer.writerow(["USD", "RUB", dts, "90"])
        csv_handle.flush()
        archive.writestr("ICER_20160831_041710_2343.csv", csv_handle.getvalue())
        csv_handle.close()
        archive.close()
        io.flush()
        icer_files = {
            "ICER_20160829_041710_2343.csv.20160829_041710_2343.zip": "aaa",
            "ICER_20160830_041710_2343.csv.20160830_041710_2343.zip": "bbb",
            "ICER_20160831_041710_2343.csv.20160831_041710_2343.zip": io.getvalue(),
        }
        io.close()
        self.server = ICERSFTPServer(
            config.ICER_SFTP_HOST,
            config.ICER_SFTP_PORT,
            icer_files
        )
        self.server.start()

    def tearDown(self):
        self.server.terminate()

    def test_reloadICER(self):
        voc = getV("icer")
        voc.reloadICER()
        eurrub = voc[("EUR", "RUB")]
        self.assertEqual(
            eurrub.rate, 100
        )
        self.assertEqual(
            eurrub.updated, self.date
        )
        usdrub = voc[("USD", "RUB")]
        self.assertEqual(
            usdrub.rate, 90
        )
        self.assertEqual(
            usdrub.updated, self.date
        )

class TestCharityFunds(ModelTest, TestCaseWithI18N, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestCharityFunds, self).setUp()
        self.model = models.charity_funds.CharityFund

    def test_model(self):
        ob = self.model.load(charity_fund_id=-1)
        self.assertEqual(ob.weight, '10')
        self.assertEqual(ob.create_date, date(2015, 10, 29))
        self.assertEqual(ob.logo_url, [u'en:http://aeroflot.ru/logo.png', u'ru:http://aeroflot.ru/logo.png'])
        self.assertEqual(ob.image_url, [u'en:http://aeroflot.ru/image.png', u'ru:http://aeroflot.ru/image.png'])
        self.assertEqual(ob.charity_description, [u'ru:Это описание', u'en:This is description'])

class TestMealRule(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)
    model = models.meal.MealRule

    def test_model(self):
        ob = self.model.load(meal_rule_id=1)
        self.assertEqual(ob.meal_rule_id, 1)
        self.assertEqual(ob.date_from, date(2015, 12, 1))
        self.assertEqual(ob.date_to, date(2016, 1, 1))
        self.assertEqual(ob.number, u'1,3,5,7-9')
        self.assertEqual(ob.airline, [u'SU', u'FV'])
        self.assertEqual(ob.origin, [u'GOJ', u'SVO'])
        self.assertEqual(ob.destination, [u'LED', u'JFK'])
        self.assertEqual(ob.booking_class, [u'C', u'D', u'J', u'I'])
        self.assertEqual(ob.special_meal, [u'BBML', u'CHML', u'VJML'])


class TestMealRulesVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestMealRulesVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.meal.MealRulesVocabulary)

    def test_vocabulary_registration(self):
        self.assertTrue(IRegisterableVocabulary.providedBy(models.meal.MealRulesVocabulary))
        v = getV('meal_rules')
        self.assertTrue(1 in v)
        self.assertFalse(0 in v)
        ob = v[1]
        self.assertTrue(isinstance(ob, models.meal.MealRule))
        self.assertEqual(ob.special_meal, [u'BBML', u'CHML', u'VJML'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update meal_rules SET special_meal='AAAA,BBBB' where meal_rule_id = 1")
        ob = v[1]
        self.assertEqual(ob.special_meal, [u'BBML', u'CHML', u'VJML'])
        v.preload()
        ob = v[1]
        self.assertEqual(ob.special_meal, [u'AAAA', u'BBBB'])


class TestMealTimelimit(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)
    model = models.meal.MealTimelimit

    def test_model(self):
        ob = self.model.load(meal_timelimit_id=1)
        self.assertEqual(ob.meal_timelimit_id, 1)
        self.assertEqual(ob.origin, [u'SVO', u'LED'])
        self.assertEqual(ob.special_meal, [u'VJML', u'VGML'])
        self.assertEqual(ob.timelimit, 24)


class TestMealTimelimitsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestMealTimelimitsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.meal.MealTimelimitsVocabulary)

    def test_vocabulary_registration(self):
        self.assertTrue(IRegisterableVocabulary.providedBy(models.meal.MealTimelimitsVocabulary))
        v = getV('meal_timelimits')
        self.assertTrue(1 in v)
        self.assertFalse(0 in v)
        ob = v[1]
        self.assertTrue(isinstance(ob, models.meal.MealTimelimit))
        self.assertEqual(ob.timelimit, 24)

        # Test that vocabulary factory is cacheable
        dbquery(u"update meal_timelimits SET timelimit=100 where meal_timelimit_id = 1")
        ob = v[1]
        self.assertEqual(ob.timelimit, 24)
        v.preload()
        ob = v[1]
        self.assertEqual(ob.timelimit, 100)


class TestSpecialMeal(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)
    model = models.ssr_meal.SpecialMeal

    def test_model(self):
        ob = self.model.load(code=u'VJML')
        self.assertEqual(ob.code, u'VJML')
        self.assertEqual(ob.names, [u'ru:Постное меню', u'en:Eastern Orthodoxal Lenten meal'])


class TestSpecialMealVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestSpecialMealVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.ssr_meal.SpecialMealVocabulary)

    def test_vocabulary_registration(self):
        self.assertTrue(IRegisterableVocabulary.providedBy(models.ssr_meal.SpecialMealVocabulary))
        v = getV('ssr_meal_codes')
        self.assertTrue(u'VJML' in v)
        self.assertFalse(u'XXXX' in v)
        ob = v[u'VJML']
        self.assertTrue(isinstance(ob, models.ssr_meal.SpecialMeal))
        self.assertEqual(ob.names, [u'ru:Постное меню', u'en:Eastern Orthodoxal Lenten meal'])

        # Test that vocabulary factory is cacheable
        dbquery(u"update vocab_special_meal SET names='ru:Питание|en:Meal' where code = 'VJML'")
        ob = v[u'VJML']
        self.assertEqual(ob.names, [u'ru:Постное меню', u'en:Eastern Orthodoxal Lenten meal'])
        v.preload()
        ob = v[u'VJML']
        self.assertEqual(ob.names, [u'ru:Питание', u'en:Meal'])


class TestBluetoothBeacons(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)
    model = models.ibeacon.BluetoothBeacon

    def test_model(self):
        ob = self.model.load(unique_id=-1)
        
        self.assertEqual(ob.unique_id, -1)
        self.assertEqual(ob.device_id, 'ABC')
        self.assertIsInstance(ob.beacon_description, list)
        self.assertEqual(ob.beacon_description, [u"en:Description 1", u"ru:Описание 1"])
        self.assertIsInstance(ob.message, list)
        self.assertEqual(ob.message, [u"en:Message 1", u"ru:Сообщение 1"])
        self.assertEqual(ob.message_type, 'special_offers')
        self.assertEqual(ob.location_latitude, 55.751432)
        self.assertEqual(ob.location_longitude, 37.596561)
        self.assertEqual(ob.device_major, 4660)
        self.assertEqual(ob.device_minor, 5590)
        self.assertEqual(ob.manufacturer_guid, 'f7826da64fa24e988024bc5b71e0893e')
        self.assertEqual(ob.scheme_android, 'afl://menu/special-offers1')
        self.assertEqual(ob.scheme_ios, 'afl://menu/special-offers2')
        self.assertEqual(ob.scheme_winphone, 'afl://menu/special-offers3')


class TestBluetoothBeaconsVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestBluetoothBeaconsVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.ibeacon.BluetoothBeaconsVocabulary)

    def test_vocabulary(self):
        self.assertTrue(IRegisterableVocabulary.providedBy(models.ibeacon.BluetoothBeaconsVocabulary))
        v = getV('ibeacons')
        self.assertTrue(-1 in v)
        self.assertTrue(-2 in v)
        self.assertTrue(-3 in v)
        self.assertFalse(-4 in v)
        
        ob = v[-1]
        self.assertIsInstance(ob, models.ibeacon.BluetoothBeacon)
        self.assertEqual(ob.device_id, 'ABC')
        ob = v[-2]
        self.assertIsInstance(ob, models.ibeacon.BluetoothBeacon)
        self.assertEqual(ob.device_id, 'DEF')
        ob = v[-3]
        self.assertIsInstance(ob, models.ibeacon.BluetoothBeacon)
        self.assertEqual(ob.device_id, 'GHI')
        with self.assertRaises(KeyError):
            ob = v[-4]
        ob = v.get(-4)
        self.assertIsNone(ob)
    
    def test_vocabulary_cacheability(self):
        v = getV('ibeacons')
        
        ob = v[-1]
        self.assertEqual(ob.device_id, 'ABC')
        
        dbquery(u"update ibeacons SET device_id='XYZ' where unique_id = -1")
        ob = v[-1]
        self.assertEqual(ob.device_id, 'ABC')
        
        v.preload()
        ob = v[-1]
        self.assertEqual(ob.device_id, 'XYZ')


if __name__ == '__main__':
    testoob.main()
