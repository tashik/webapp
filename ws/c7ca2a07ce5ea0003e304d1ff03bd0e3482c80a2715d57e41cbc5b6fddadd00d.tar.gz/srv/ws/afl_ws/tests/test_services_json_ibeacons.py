# -*- coding: utf-8 -*-

"""
$Id: test_services_json_ibeacons.py 35215 2018-07-21 11:29:36Z apinsky $
"""

import json

import testoob
import pyramid.vocabulary.mvcc

import models.ibeacon
import _test_data

from pyramid.tests.testlib import TestCaseWithPgDBAndVocabs

from services.json_services.ibeacons import BluetoothBeaconsService


class TesBluetoothBeaconsService(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def registerVocabularies(self):
        super(TesBluetoothBeaconsService, self).registerVocabularies()
        pyramid.vocabulary.mvcc.register()
        _test_data.setup_vocabulary(models.ibeacon.BluetoothBeaconsVocabulary)
    
    def test__encode_ibeacon_all_fields(self):
        svc = BluetoothBeaconsService()
        
        ob = models.ibeacon.BluetoothBeacon.load(unique_id=-1)
        ob.beacon_description.append(u'es:Descripción')
        ob.message.append(u'de:Nachricht')
        d = svc._encode_ibeacon(ob)
        self.assertIsInstance(d, dict)
        self.assertEqual(set(d.keys()),
            {'id', 'device_id', 'description', 'message', 'type', 'location', 'major', 'minor', 'uuid', 'scheme'})
        self.assertEqual(d['id'], -1)
        self.assertEqual(d['device_id'], 'ABC')
        self.assertIsInstance(d['description'], dict)
        self.assertEqual(d['description'], {'en': u"Description 1", 'ru': u"Описание 1", 'es': u"Descripción"})
        self.assertIsInstance(d['message'], dict)
        self.assertEqual(d['message'], {'en': u"Message 1", 'ru': u"Сообщение 1", 'de': u"Nachricht"})
        self.assertEqual(d['type'], 'special_offers')
        self.assertIsInstance(d['location'], dict)
        self.assertEqual(d['location'], {'lat': 55.751432, 'lon': 37.596561})
        self.assertEqual(d['major'], 4660)
        self.assertEqual(d['minor'], 5590)
        self.assertEqual(d['uuid'], 'f7826da6-4fa2-4e98-8024-bc5b71e0893e')
        self.assertIsInstance(d['scheme'], dict)
        self.assertEqual(d['scheme'], {'android': 'afl://menu/special-offers1', 'ios': 'afl://menu/special-offers2', 'winphone': 'afl://menu/special-offers3'})
    
    def test__encode_ibeacon_no_scheme(self):
        svc = BluetoothBeaconsService()
        
        ob = models.ibeacon.BluetoothBeacon.load(unique_id=-2)
        ob.beacon_description.append(u'es:Descripción')
        ob.message.append(u'de:Nachricht')
        d = svc._encode_ibeacon(ob)
        self.assertIsInstance(d, dict)
        self.assertEqual(set(d.keys()),
            {'id', 'device_id', 'description', 'message', 'type', 'location', 'major', 'minor', 'uuid', 'scheme'})
        self.assertEqual(d['id'], -2)
        self.assertEqual(d['device_id'], 'DEF')
        self.assertIsInstance(d['description'], dict)
        self.assertEqual(d['description'], {'en': u"Description 2", 'ru': u"Описание 2", 'es': u"Descripción"})
        self.assertIsInstance(d['message'], dict)
        self.assertEqual(d['message'], {'en': u"Message 2", 'ru': u"Сообщение 2", 'de': u"Nachricht"})
        self.assertEqual(d['type'], 'other_offers')
        self.assertIsInstance(d['location'], dict)
        self.assertEqual(d['location'], {'lat': 50.751432, 'lon': 30.596561})
        self.assertEqual(d['major'], 4661)
        self.assertEqual(d['minor'], 5591)
        self.assertEqual(d['uuid'], 'f7826da6-4fa2-4e98-8024-bc5b71e0893f')
        self.assertIsNone(d['scheme'])
    
    def test__encode_ibeacon_no_scheme_partial(self):
        svc = BluetoothBeaconsService()
        
        ob = models.ibeacon.BluetoothBeacon.load(unique_id=-1)
        ob.beacon_description.append(u'es:Descripción')
        ob.message.append(u'de:Nachricht')
        ob.scheme_android = ''
        d = svc._encode_ibeacon(ob)
        self.assertIsInstance(d, dict)
        self.assertEqual(set(d.keys()),
            {'id', 'device_id', 'description', 'message', 'type', 'location', 'major', 'minor', 'uuid', 'scheme'})
        self.assertEqual(d['id'], -1)
        self.assertEqual(d['device_id'], 'ABC')
        self.assertIsInstance(d['description'], dict)
        self.assertEqual(d['description'], {'en': u"Description 1", 'ru': u"Описание 1", 'es': u"Descripción"})
        self.assertIsInstance(d['message'], dict)
        self.assertEqual(d['message'], {'en': u"Message 1", 'ru': u"Сообщение 1", 'de': u"Nachricht"})
        self.assertEqual(d['type'], 'special_offers')
        self.assertIsInstance(d['location'], dict)
        self.assertEqual(d['location'], {'lat': 55.751432, 'lon': 37.596561})
        self.assertEqual(d['major'], 4660)
        self.assertEqual(d['minor'], 5590)
        self.assertEqual(d['uuid'], 'f7826da6-4fa2-4e98-8024-bc5b71e0893e')
        self.assertIsNone(d['scheme'])
    
    def test__encode_ibeacon_no_location(self):
        svc = BluetoothBeaconsService()
        
        ob = models.ibeacon.BluetoothBeacon.load(unique_id=-3)
        ob.beacon_description.append(u'es:Descripción')
        ob.message.append(u'de:Nachricht')
        d = svc._encode_ibeacon(ob)
        self.assertIsInstance(d, dict)
        self.assertEqual(set(d.keys()),
            {'id', 'device_id', 'description', 'message', 'type', 'location', 'major', 'minor', 'uuid', 'scheme'})
        self.assertEqual(d['id'], -3)
        self.assertEqual(d['device_id'], 'GHI')
        self.assertIsInstance(d['description'], dict)
        self.assertEqual(d['description'], {'en': u"Description 3", 'ru': u"Описание 3", 'es': u"Descripción"})
        self.assertIsInstance(d['message'], dict)
        self.assertEqual(d['message'], {'en': u"Message 3", 'ru': u"Сообщение 3", 'de': u"Nachricht"})
        self.assertEqual(d['type'], 'something')
        self.assertIsNone(d['location'])
        self.assertEqual(d['major'], 4662)
        self.assertEqual(d['minor'], 5592)
        self.assertEqual(d['uuid'], 'f7826da6-4fa2-4e98-8024-bc5b71e0893a')
        self.assertIsInstance(d['scheme'], dict)
        self.assertEqual(d['scheme'], {'android': 'afl://menu/something1', 'ios': 'afl://menu/something2', 'winphone': 'afl://menu/something3'})
    
    def test__encode_ibeacon_uuid_format(self):
        svc = BluetoothBeaconsService()
        
        ob = models.ibeacon.BluetoothBeacon.load(unique_id=-1)
        ob.manufacturer_guid = 'F7826DA64FA24E988024BC5B71E0893E'
        d = svc._encode_ibeacon(ob)
        self.assertEqual(d['uuid'], 'f7826da6-4fa2-4e98-8024-bc5b71e0893e')

    def test_service_v001(self):
        svc = BluetoothBeaconsService()
        
        response = svc.v001()
        obj = json.loads(response)
        self.assertIsInstance(obj, dict)
        self.assertEqual(set(obj.keys()), {'data', 'errors', 'isSuccess'})
        self.assertEqual(obj['isSuccess'], True)
        self.assertEqual(obj['errors'], [])
        data = obj['data']
        self.assertIsInstance(data, list)
        self.assertEqual(len(data), 3)
        for item in data:
            self.assertIsInstance(item, dict)
            self.assertEqual(set(item.keys()),
                {'id', 'device_id', 'description', 'message', 'type', 'location', 'major', 'minor', 'uuid', 'scheme'})
        self.assertEqual({-1, -2, -3}, {item['id'] for item in data})


if __name__ == "__main__":
    testoob.main()
