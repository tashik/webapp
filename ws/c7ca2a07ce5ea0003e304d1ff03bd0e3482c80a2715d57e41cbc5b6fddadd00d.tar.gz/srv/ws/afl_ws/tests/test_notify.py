# -*- coding: utf-8 -*-

"""
$Id: test_notify.py 35222 2018-07-22 15:36:50Z apinsky $
"""
from datetime import date
import mock
import testoob

from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.vocabulary import getV
from pyramid.tests import testlib
import pyramid.vocabulary.mvcc
import pyramid.i18n
from rx.i18n.translation import init_i18n
import models.geo
import models.office
import models.airport
import models.air
import models.additional_info
import models.ibeacon
import models.meal
import notify.decode
import models.ssr_meal
import models.charity_funds
from models.ssr_meal import SpecialMeal
from services.base.static import on_vocab_change, DocumentCatalog


def t2l(msg, lang):
    return pyramid.i18n.translate(msg, target_language=lang)


class TestDecode(testlib.TestCaseWithI18N, testlib.TestCaseWithPgDBAndVocabs):
    DEFAULT_NEGOTIATOR_LANG = 'en'

    def setUp(self):
        super(TestDecode, self).setUp()
        init_i18n()
        pyramid.vocabulary.mvcc.register()

    def test_aircraft_type(self):
        d = {
            'aircraft_type_id': -1,
            'ohd_code': u'OoOo',
            'names': [u'en:ABC', u'ru:АБВ'],
            'iata': u'XXX',
            'icao': u'YYYY',
            'pax_capacity': 123,
            'cargo_capacity': 123,
            'f': 123,
            'y': 123,
            'c': 123,
            }

        term = notify.decode.decode_aircraft_type(d)
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(term.aircraft_type_id, -1)
        self.assertEqual(term.ohd_code, u'OoOo')
        self.assertEqual(term.iata, u'XXX')
        self.assertEqual(term.icao, u'YYYY')
        self.assertEqual(term.pax_capacity, 123)
        self.assertEqual(term.cargo_capacity, 123)
        self.assertEqual(term.f, 123)
        self.assertEqual(term.y, 123)
        self.assertEqual(term.c, 123)

    def test_office_category(self):
        d = {
            'office_category_id': -1,
            'names': [u'en:Eng', u'ru:Рус'],
            'office_category_description': [u'en:Eng', u'ru:Рус'],
            'city': -1
        }

        term = notify.decode.decode_office_category(d)
        self.assertEqual(t2l(term.title, 'ru'), u'Рус')
        self.assertEqual(t2l(term.title, 'en'), u'Eng')
        self.assertEqual(term.office_category_id, -1)
        self.assertEqual(term.office_category_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(term.city, -1)

    def test_decode_office(self):
        d = {
            'office_id': 101,
            'names': [u'en:ABC', u'ru:АБВ'],
            'office_description': [u'en:ABC', u'ru:АБВ'],
            'email': [u'a@a.com', u'b@b.com'],
            'fax': [u'123', u'456'],
            'phone': [u'777', u'888'],
            'lat': 5.0,
            'lon': 6.0,
            'address': [u'en:SPb', u'ru:СПб'],
            'worktime': [u'en:24 hours', u'ru:24 часа'],
            'in_airport': True,
            'airport': u'XXX',
            'distance_to_airport': 123,
            'insurance_policy': True,
            'noncash_booking': True,
            'new_office': True,
            'office_category': -1,
            'location_map':[u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'],
            'transfer_time_public': 123,
            'transfer_time_automobile': 123,
            'important_info': [u'ru:'],
            'office_weight': 50,
            'transfer_time_foot': 123

        }
        term = notify.decode.decode_office(d)
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(t2l(term.title, 'en'), u'ABC')  # Office is not MLTitleCapable
        self.assertEqual(term.office_id, 101)
        self.assertEqual(term.office_description, [u'en:ABC', u'ru:АБВ'])
        self.assertEqual(term.email, [u'a@a.com', u'b@b.com'])
        self.assertEqual(term.fax, [u'123', u'456'])
        self.assertEqual(term.phone, [u'777', u'888'])
        self.assertEqual(term.lat, 5.0)
        self.assertEqual(term.lon, 6.0)
        self.assertEqual(term.address, [u'en:SPb', u'ru:СПб'])
        self.assertEqual(term.worktime, [u'en:24 hours', u'ru:24 часа'])
        self.assertEqual(term.in_airport, True)
        self.assertEqual(term.airport, u'XXX')
        self.assertEqual(term.distance_to_airport, 123)
        self.assertEqual(term.insurance_policy, True)
        self.assertEqual(term.noncash_booking, True)
        self.assertEqual(term.new_office, True)
        self.assertEqual(term.office_category, -1)
        self.assertEqual(term.location_map, [u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'])
        self.assertEqual(term.transfer_time_public, 123)
        self.assertEqual(term.transfer_time_automobile, 123)
        self.assertEqual(term.transfer_time_foot, 123)

    def test_decode_office_travel_options(self):
        d = {
            'office_travel_option_id': -1,
            'office_id': -1,
            'travel_type': u'F',
            'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
            'travel_time': 123
        }
        term = notify.decode.decode_office_travel_option(d)
        self.assertEqual(term.office_travel_option_id, -1)
        self.assertEqual(term.office_id, -1)
        self.assertEqual(term.travel_type, u'F')
        self.assertEqual(term.office_travel_option_description,[u'en:Eng', u'ru:Рус'])
        self.assertEqual(term.travel_time, 123)

    def test_decode_airport(self):
        d = {
            'city': -1,
            'iata': 'ABC',
            'icao': 'ABCD',
            'names': [u'en:Abc', u'ru:Абв'],
            'has_afl_flights': False,
            'lat': 5.0,
            'lon': 6.0
        }
        term = notify.decode.decode_airport(d)
        self.assertEqual(t2l(term.title, 'en'), u'Abc')
        self.assertEqual(t2l(term.title, 'ru'), u'Абв')
        self.assertEqual(term.airport, 'ABC')
        self.assertEqual(term.icao, 'ABCD')
        self.assertEqual(term.names, [u'en:Abc', u'ru:Абв'])
        self.assertEqual(term.has_afl_flights, False)
        self.assertEqual(term.lat, 5.0)
        self.assertEqual(term.lon, 6.0)
        self.assertEqual(term.vocab_city_id, -1)

        d = {
            'city': -1,
            'iata': 'ABC',
            'icao': 'ABCD',
            'names': [u'en:Abc'],
            'has_afl_flights': True,
            'lat': 5.0,
            'lon': 6.0
        }
        term = notify.decode.decode_airport(d)
        self.assertEqual(t2l(term.title, 'en'), u'Abc')
        self.assertEqual(t2l(term.title, 'ru'), u'Abc')
        self.assertEqual(term.has_afl_flights, True)

    def test_decode_world_region(self):
        d = {
            'world_region_id': 1,
            'names': [u'en:Europe'],
        }
        term = notify.decode.decode_world_region(d)
        self.assertEqual(t2l(term.title, 'en'), u'Europe')
        self.assertEqual(t2l(term.title, 'ru'), u'Europe')
        self.assertEqual(term.world_region_id, 1)

        d['names'].append(u'ru:Европа')
        term = notify.decode.decode_world_region(d)
        self.assertEqual(t2l(term.title, 'en'), u'Europe')
        self.assertEqual(t2l(term.title, 'ru'), u'Европа')

    def test_decode_country(self):
        d = {
            'iso_code2': 'RU',
            'iso_code3': 'RUS',
            'names': [u'en:Russia'],
            'world_region': 1,
            'currency': 'RUB',
            'use_in_pos': 1,
            'telephone_code': '+7',
        }
        term = notify.decode.decode_country(d)
        self.assertEqual(t2l(term.title, 'en'), u'Russia')
        self.assertEqual(t2l(term.title, 'ru'), u'Russia')
        self.assertEqual(term.country, 'RU')
        self.assertEqual(term.iso_code3, 'RUS')
        self.assertEqual(term.world_region_id, 1)
        self.assertEqual(term.phone_code, '+7')

        d['names'].append(u'ru:Россия')
        term = notify.decode.decode_country(d)
        self.assertEqual(t2l(term.title, 'en'), u'Russia')
        self.assertEqual(t2l(term.title, 'ru'), u'Россия')

    def test_decode_currency(self):
        d = {
            'alpha3_code': 'RUB',
            "names": [u"en:Ruble", u"ru:Рубль"],
            'used_in_calc': 1,
            'minor_unit': 2,
            'rounding_unit': 5,
        }
        term = notify.decode.decode_currency(d)
        self.assertEqual(term.code, 'RUB')
        self.assertTrue(term.used_in_calc)
        self.assertEqual(term.minor_unit, 2)
        self.assertEqual(term.rounding_unit, 5)

    def test_decode_city(self):
        d = {
            'city_id': -1,
            'iata': 'LED',
            'country_code': 'RU',
            'lat': 5.0,
            'lon': 6.0,
            'can_book': True,
            'names': [u'en:Saint Petersburg', u'ru:Санкт-Петербург'],
            'tz': 'Europe\Moscow'
        }
        term = notify.decode.decode_city(d)
        self.assertEqual(t2l(term.title, 'en'), u'Saint Petersburg')
        self.assertEqual(t2l(term.title, 'ru'), u'Санкт-Петербург')
        self.assertEqual(term.city, 'LED')
        self.assertEqual(term.country_code, 'RU')
        self.assertEqual(term.lat, 5.0)
        self.assertEqual(term.lon, 6.0)
        self.assertEqual(term.can_book, True)
        self.assertEqual(term.names,
                         [u'en:Saint Petersburg', u'ru:Санкт-Петербург'])
        self.assertEqual(term.tz, 'Europe\Moscow')
        self.assertEqual(term.vocab_id, -1)

        d = {
            'city_id': -1,
            'iata': 'LED',
            'country_code': 'RU',
            'lat': 5.0,
            'lon': 6.0,
            'can_book': True,
            'names': [u'en:Saint Petersburg'],
            'tz': 'Europe\Moscow'
        }
        term = notify.decode.decode_city(d)
        self.assertEqual(t2l(term.title, 'en'), u'Saint Petersburg')
        self.assertEqual(t2l(term.title, 'ru'), u'Saint Petersburg')

    def test_decode_town(self):
        d = {
            'city_id': 101,
            'country_code': 'RU',
            'names': [u'en:ABC', u'ru:АБВ']
        }
        term = notify.decode.decode_town(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'АБВ')
        self.assertEqual(term.town_id, 101)
        self.assertEqual(term.country_code, 'RU')
        self.assertEqual(term.names, [u'en:ABC', u'ru:АБВ'])

        d = {
            'city_id': 101,
            'country_code': 'RU',
            'names': [u'en:ABC']
        }
        term = notify.decode.decode_town(d)
        self.assertEqual(t2l(term.title, 'en'), u'ABC')
        self.assertEqual(t2l(term.title, 'ru'), u'ABC')

    def test_decode_additional_info(self):
        d = {
            'additional_info_id': 1,
            'weight': 10,
            'created': '2015-10-28',
            'names': [u'en:Message'],
            'condition': [{'country_from': 'US'}],
            'position': 'flight',
        }
        term = notify.decode.decode_additional_info(d)
        self.assertEqual(t2l(term.title, 'en'), u'Message')
        self.assertEqual(t2l(term.title, 'ru'), u'Message')
        self.assertEqual(term.additional_info_id, 1)
        self.assertEqual(term.weight, 10)
        self.assertEqual(term.created, date(2015, 10, 28))
        self.assertEqual(term.names, [u'en:Message'])
        self.assertEqual(term.condition, [{'country_from': 'US'}])
        self.assertEqual(term.position, 'flight')

        d['names'].append(u'ru:Сообщение')
        term = notify.decode.decode_additional_info(d)
        self.assertEqual(term.names, [u'en:Message', u'ru:Сообщение'])
        self.assertEqual(t2l(term.title, 'en'), u'Message')
        self.assertEqual(t2l(term.title, 'ru'), u'Сообщение')

        # позиция search

        d = {
            'additional_info_id': 1,
            'weight': 10,
            'created': '2015-10-28',
            'names': [u'en:Message'],
            'condition': [{'country_from': 'US'}],
            'position': 'search',
        }
        term = notify.decode.decode_additional_info(d)
        self.assertEqual(t2l(term.title, 'en'), u'Message')
        self.assertEqual(t2l(term.title, 'ru'), u'Message')
        self.assertEqual(term.additional_info_id, 1)
        self.assertEqual(term.weight, 10)
        self.assertEqual(term.created, date(2015, 10, 28))
        self.assertEqual(term.names, [u'en:Message'])
        self.assertEqual(term.condition, [{'country_from': 'US'}])
        self.assertEqual(term.position, 'search')

        d['names'].append(u'ru:Сообщение')
        term = notify.decode.decode_additional_info(d)
        self.assertEqual(term.names, [u'en:Message', u'ru:Сообщение'])
        self.assertEqual(t2l(term.title, 'en'), u'Message')
        self.assertEqual(t2l(term.title, 'ru'), u'Сообщение')

    def test_decode_meal_rule(self):
        d = {
            u'class': u'MealRule',
            u'meal_rule_id': 1100,
            u'date_from': u'2015-12-01',
            u'date_to': u'2016-01-01',
            u'number': u'1,3,5,7-9',
            u'airline': [u'SU', u'FV'],
            u'origin': [u'OVB', u'KJA'],
            u'destination': [u'KHV'],
            u'booking_class': [u'Z', u'X'],
            u'special_meal': [u'AVML', u'BBML', u'CHML', u'DBML'],
        }
        term = notify.decode.decode_meal_rule(d)
        self.assertIsInstance(term, models.meal.MealRule)
        self.assertEqual(term.origin, [u'OVB', u'KJA'])
        self.assertEqual(term.special_meal, [u'AVML', u'BBML', u'CHML', u'DBML'])
        self.assertEqual(term.date_from, date(2015, 12, 1))
        self.assertEqual(term.destination, [u'KHV'])
        self.assertEqual(term.number, u'1,3,5,7-9')
        self.assertEqual(term.booking_class, [u'Z', u'X'])
        self.assertEqual(term.meal_rule_id, 1100)
        self.assertEqual(term.airline, [u'SU', u'FV'])
        self.assertEqual(term.date_to, date(2016, 1, 1))

        d['date_from'] = None
        d['date_to'] = None
        term = notify.decode.decode_meal_rule(d)
        self.assertIsNone(term.date_from)
        self.assertIsNone(term.date_to)

    def test_decode_meal_timelimit(self):
        d = {u'class': u'MealTimelimit', u'meal_timelimit_id': 1, u'origin': [u'SVO', u'LED'], u'special_meal': [u'VJML', u'VGML'], u'timelimit': 36}
        term = notify.decode.decode_meal_timelimit(d)
        self.assertIsInstance(term, models.meal.MealTimelimit)
        self.assertEqual(term.meal_timelimit_id, 1)
        self.assertEqual(term.origin, [u'SVO', u'LED'])
        self.assertEqual(term.special_meal, [u'VJML', u'VGML'])
        self.assertEqual(term.timelimit, 36)

    def test_decode_special_meal(self):
        d = {u'code': u'KSML', u'class': u'SpecialMeal', u'names': [u'ru:Кошерное', u'en:Kosher meal']}
        term = notify.decode.decode_special_meal(d)
        self.assertIsInstance(term, models.ssr_meal.SpecialMeal)
        self.assertEqual(term.code, u'KSML')
        self.assertEqual(term.names, [u'ru:Кошерное', u'en:Kosher meal'])
    
    def test_decode_ibeacon(self):
        d = {
            'beacon_id': 123,
            'unique_id': -1,
            'device_id': 'ABC',
            'beacon_description': [
                u"en:Description 1",
                u"ru:Описание 1"
            ],
            'message': [
                u"en:Message 1",
                u"ru:Сообщение 1"
            ],
            'message_type': 'special_offers',
            'location_latitude': 55.751432,
            'location_longitude': 37.596561,
            'device_major': 4660,
            'device_minor': 5590,
            'manufacturer_id': 'f7826da64fa24e988024bc5b71e0893e',
            'scheme_android': 'afl://menu/special-offers1',
            'scheme_ios': 'afl://menu/special-offers2',
            'scheme_winphone': 'afl://menu/special-offers3',
            'class': 'BluetoothBeacon'
        }
        obj = notify.decode.decode_ibeacon(d)
        self.assertIsInstance(obj, models.ibeacon.BluetoothBeacon)
        self.assertEqual(obj.unique_id, -1)
        self.assertEqual(obj.device_id, 'ABC')
        self.assertEqual(obj.beacon_description, [u"en:Description 1", u"ru:Описание 1"])
        self.assertEqual(obj.message, [u"en:Message 1", u"ru:Сообщение 1"])
        self.assertEqual(obj.message_type, 'special_offers')
        self.assertEqual(obj.location_latitude, 55.751432)
        self.assertEqual(obj.location_longitude, 37.596561)
        self.assertEqual(obj.device_major, 4660)
        self.assertEqual(obj.device_minor, 5590)
        self.assertEqual(obj.manufacturer_guid, 'f7826da64fa24e988024bc5b71e0893e')
        self.assertEqual(obj.scheme_android, 'afl://menu/special-offers1')
        self.assertEqual(obj.scheme_ios, 'afl://menu/special-offers2')
        self.assertEqual(obj.scheme_winphone, 'afl://menu/special-offers3')        


class TestNotifyService(testlib.TestCaseWithI18N, testlib.TestCaseWithPgDBAndVocabs):
    DEFAULT_NEGOTIATOR_LANG = 'ru'

    def setUp(self):
        super(TestNotifyService, self).setUp()
        init_i18n()
        pyramid.vocabulary.mvcc.register()

        IRegisterableVocabulary(models.geo.WorldRegionsVocabulary).register()
        IRegisterableVocabulary(models.geo.CountriesVocabulary).register()
        IRegisterableVocabulary(models.office.OfficeVocabulary).register()
        IRegisterableVocabulary(models.office.OfficeCategoryVocabulary).register()
        IRegisterableVocabulary(models.office.OfficeTravelOptionVocabulary).register()
        IRegisterableVocabulary(models.airport.AirportsVocabulary).register()
        IRegisterableVocabulary(models.geo.CitiesVocabulary).register()
        IRegisterableVocabulary(models.geo.TownsVocabulary).register()
        IRegisterableVocabulary(models.air.AircraftTypesVocabulary).register()
        IRegisterableVocabulary(models.additional_info.AdditionalInfoVocabulary).register()
        IRegisterableVocabulary(models.geo.CurrencyVocabulary).register()
        IRegisterableVocabulary(models.meal.MealRulesVocabulary).register()
        IRegisterableVocabulary(models.meal.MealTimelimitsVocabulary).register()
        IRegisterableVocabulary(models.ssr_meal.SpecialMealVocabulary).register()
        IRegisterableVocabulary(models.charity_funds.CharityFundVocabulary).register()
        IRegisterableVocabulary(models.ibeacon.BluetoothBeaconsVocabulary).register()

    def test_process_aircraft_type(self):
        # change, add
        objects = [
            {
                'aircraft_type_id': 101,
                'ohd_code': u'OoOo',
                'names': [u'en:ABC', u'ru:АБВ'],
                'iata': u'XXX',
                'icao': u'YYYY',
                'pax_capacity': 123,
                'cargo_capacity': 123,
                'f': 123,
                'y': 123,
                'c': 123,
                'class': 'AircraftType',
            },
            {
                'aircraft_type_id': 102,
                'ohd_code': u'OoOo',
                'names': [u'en:ABC', u'ru:ГДЕ'],
                'iata': u'XXX',
                'icao': u'YYYY',
                'pax_capacity': 123,
                'cargo_capacity': 123,
                'f': 123,
                'y': 123,
                'c': 123,
                'class': 'AircraftType',
            }
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('aircraft_types')
        self.assertEqual(t2l(vocab['101'].title, 'ru'), u'АБВ')
        self.assertEqual(t2l(vocab['102'].title, 'ru'), u'ГДЕ')

        # replace_all
        objects = [
            {
                'aircraft_type_id': 103,
                'ohd_code': u'OoOo',
                'names': [u'en:ABC', u'ru:ЖЗИ'],
                'iata': u'XXX',
                'icao': u'YYYY',
                'pax_capacity': 123,
                'cargo_capacity': 123,
                'f': 123,
                'y': 123,
                'c': 123,
                'class': 'AircraftType',
            },
            {
                'aircraft_type_id': 104,
                'ohd_code': u'OoOo',
                'names': [u'en:ABC', u'ru:КЛМ'],
                'iata': u'XXX',
                'icao': u'YYYY',
                'pax_capacity': 123,
                'cargo_capacity': 123,
                'f': 123,
                'y': 123,
                'c': 123,
                'class': 'AircraftType',
            }
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('aircraft_types')
        self.assertNotIn('101', vocab)
        self.assertNotIn('102', vocab)
        self.assertEqual(t2l(vocab['103'].title, 'ru'), u'ЖЗИ')
        self.assertEqual(t2l(vocab['104'].title, 'ru'), u'КЛМ')

        # delete
        objects = [
            {
                'aircraft_type_id': 103,
                'ohd_code': u'OoOo',
                'names': [u'en:ABC', u'ru:ЖЗИ'],
                'iata': u'XXX',
                'icao': u'YYYY',
                'pax_capacity': 123,
                'cargo_capacity': 123,
                'f': 123,
                'y': 123,
                'c': 123,
                'class': 'AircraftType',
            }
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('aircraft_types')
        self.assertNotIn('103', vocab)
        self.assertIn('104', vocab)

    def test_process_office_category(self):
        # change, add
        objects = [
            {
                'office_category_id': -1,
                'names': [u'en:Eng1', u'ru:Рус1'],
                'office_category_description': [u'en:Eng1', u'ru:Рус1'],
                'city': -1,
                'class': 'OfficeCategory',
            },
            {
                'office_category_id': -2,
                'names': [u'en:Eng2', u'ru:Рус2'],
                'office_category_description': [u'en:Eng2', u'ru:Рус2'],
                'city': -2,
                'class': 'OfficeCategory',
            }
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('office_categories')
        self.assertEqual(t2l(vocab['-1'].title, 'ru'), u'Рус1')
        self.assertEqual(t2l(vocab['-2'].title, 'ru'), u'Рус2')

        # replace_all
        objects = [
            {
                'office_category_id': -3,
                'names': [u'en:Eng3', u'ru:Рус3'],
                'office_category_description': [u'en:Eng3', u'ru:Рус3'],
                'city': -1,
                'class': 'OfficeCategory',
            },
            {
                'office_category_id': -4,
                'names': [u'en:Eng4', u'ru:Рус4'],
                'office_category_description': [u'en:Eng4', u'ru:Рус4'],
                'city': -2,
                'class': 'OfficeCategory',
            }
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('office_categories')
        self.assertNotIn('-1', vocab)
        self.assertNotIn('-2', vocab)
        self.assertEqual(t2l(vocab['-3'].title, 'ru'), u'Рус3')
        self.assertEqual(t2l(vocab['-4'].title, 'ru'), u'Рус4')

        # delete
        objects = [
            {
                'office_category_id': -3,
                'names': [u'en:Eng3', u'ru:Рус3'],
                'office_category_description': [u'en:Eng3', u'ru:Рус3'],
                'city': -1,
                'class': 'OfficeCategory',
            }
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('office_categories')
        self.assertNotIn('-3', vocab)
        self.assertIn('-4', vocab)

    def test_process_office(self):
        # change, add
        objects = [
            {
                'office_id': 101,
                'office_description': [u'en:ABC', u'ru:АБВ'],
                'names': [u'en:ABC1', u'ru:АБВ1'],
                'email': [u'a@a.com', u'b@b.com'],
                'fax': [u'123', u'456'],
                'phone': [u'777', u'888'],
                'lat': 5.0,
                'lon': 6.0,
                'address': [u'en:SPb', u'ru:СПб'],
                'worktime': [u'en:24 hours', u'ru:24 часа'],
                'in_airport': True,
                'airport': u'XXX',
                'distance_to_airport': 123,
                'insurance_policy': True,
                'noncash_booking': True,
                'new_office': True,
                'office_category': -1,
                'location_map':[u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'],
                'transfer_time_public': 123,
                'transfer_time_automobile': 123,
                'transfer_time_foot': 123,
                'important_info': [u'ru:'],
                'office_weight': 50,
                'travel_options':[
                    {'office_travel_option_id': -1,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 123},
                    {'office_travel_option_id': -2,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 124},
                ],
                'class': 'Office',
            },
            {
                'office_id': 102,
                'names': [u'en:ABC2', u'ru:АБВ2'],
                'office_description': [u'en:DEF', u'ru:ГДЕ'],
                'email': [u'a@a.com', u'b@b.com'],
                'fax': [u'123', u'456'],
                'phone': [u'777', u'888'],
                'lat': 5.0,
                'lon': 6.0,
                'address': [u'en:SPb', u'ru:СПб'],
                'worktime': [u'en:24 hours', u'ru:24 часа'],
                'in_airport': True,
                'airport': u'XXX',
                'distance_to_airport': 123,
                'insurance_policy': True,
                'noncash_booking': True,
                'new_office': True,
                'office_category': -1,
                'location_map':[u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'],
                'transfer_time_public': 123,
                'transfer_time_automobile': 123,
                'transfer_time_foot': 123,
                'important_info': [u'ru:'],
                'office_weight': 50,
                'travel_options':[
                    {'office_travel_option_id': -3,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 125
                    },
                    {'office_travel_option_id': -4,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 126
                    },
                ],
                'class': 'Office',
            }
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('offices')
        vocab.on_commit()
        self.assertEqual(vocab[101].title, u'АБВ1')
        self.assertEqual(vocab[102].title, u'АБВ2')

        travel = getV('office_travel_options')
        travel.on_commit()
        self.assertEqual(travel['-1'].travel_type, u'F')
        self.assertEqual(travel['-1'].office_travel_option_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(travel['-1'].travel_time, 123)
        self.assertEqual(travel['-2'].travel_time, 124)
        self.assertEqual(travel['-3'].travel_time, 125)
        self.assertEqual(travel['-4'].travel_time, 126)

        # replace_all
        objects = [
            {
                'office_id': 103,
                'names': [u'en:ABC3', u'ru:АБВ3'],
                'city': 201,
                'office_description': [u'en:GHI', u'ru:ЖЗИ'],
                'email': [u'a@a.com', u'b@b.com'],
                'fax': [u'123', u'456'],
                'phone': [u'777', u'888'],
                'lat': 5.0,
                'lon': 6.0,
                'address': [u'en:SPb', u'ru:СПб'],
                'worktime': [u'en:24 hours', u'ru:24 часа'],
                'in_airport': True,
                'airport': u'XXX',
                'distance_to_airport': 123,
                'insurance_policy': True,
                'noncash_booking': True,
                'new_office': True,
                'office_category': -1,
                'location_map':[u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'],
                'transfer_time_public': 123,
                'transfer_time_automobile': 123,
                'transfer_time_foot': 123,
                'important_info': [u'ru:'],
                'office_weight': 50,
                'travel_options':[
                    {'office_travel_option_id': -5,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 127},
                    {'office_travel_option_id': -6,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 128},
                ],
                'class': 'Office',
            },
            {
                'office_id': 104,
                'names': [u'en:ABC4', u'ru:АБВ4'],
                'city': 201,
                'office_description': [u'en:JKL', u'ru:КЛМ'],
                'email': [u'a@a.com', u'b@b.com'],
                'fax': [u'123', u'456'],
                'phone': [u'777', u'888'],
                'lat': 5.0,
                'lon': 6.0,
                'address': [u'en:SPb', u'ru:СПб'],
                'worktime': [u'en:24 hours', u'ru:24 часа'],
                'in_airport': True,
                'airport': u'XXX',
                'distance_to_airport': 123,
                'insurance_policy': True,
                'noncash_booking': True,
                'new_office': True,
                'office_category': -1,
                'location_map':[u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'],
                'transfer_time_public': 123,
                'transfer_time_automobile': 123,
                'important_info': [u'ru:'],
                'office_weight': 50,
                'transfer_time_foot': 123,
                'travel_options':[
                    {'office_travel_option_id': -7,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 129},
                    {'office_travel_option_id': -8,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 130},
                ],
                'class': 'Office',
            }
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('offices')
        vocab.on_commit()
        self.assertNotIn(101, vocab)
        self.assertNotIn(102, vocab)
        self.assertEqual(vocab[103].title, u'АБВ3')
        self.assertEqual(vocab[104].title, u'АБВ4')

        travel = getV('office_travel_options')
        travel.on_commit()
        self.assertNotIn(-1, travel)
        self.assertNotIn(-2, travel)
        self.assertNotIn(-3, travel)
        self.assertNotIn(-4, travel)
        self.assertEqual(travel['-5'].travel_time, 127)
        self.assertEqual(travel['-6'].travel_time, 128)
        self.assertEqual(travel['-7'].travel_time, 129)
        self.assertEqual(travel['-8'].travel_time, 130)

        # delete
        objects = [
            {
                'office_id': 103,
                'names': [u'en:ABC3', u'ru:АБВ3'],
                'city': 201,
                'office_description': [u'en:GHI', u'ru:ЖЗИ'],
                'email': [u'a@a.com', u'b@b.com'],
                'fax': [u'123', u'456'],
                'phone': [u'777', u'888'],
                'lat': 5.0,
                'lon': 6.0,
                'address': [u'en:SPb', u'ru:СПб'],
                'worktime': [u'en:24 hours', u'ru:24 часа'],
                'in_airport': True,
                'airport': u'XXX',
                'distance_to_airport': 123,
                'insurance_policy': True,
                'noncash_booking': True,
                'new_office': True,
                'office_category': -1,
                'location_map':[u'en:http://some.ru/en.jpg', u'ru:http://some.ru/en.jpg'],
                'transfer_time_public': 123,
                'transfer_time_automobile': 123,
                'transfer_time_foot': 123,
                'important_info': [u'ru:'],
                'office_weight': 50,
                'travel_options':[
                    {'office_travel_option_id': -5,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 127},
                    {'office_travel_option_id': -6,
                     'travel_type': u'F',
                     'office_travel_option_description': [u'en:Eng', u'ru:Рус'],
                     'travel_time': 128},
                ],
                'class': 'Office',
            }
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('offices')
        vocab.on_commit()
        self.assertNotIn(103, vocab)
        self.assertIn(104, vocab)

        travel = getV('office_travel_options')
        travel.on_commit()
        self.assertNotIn(-5, travel)
        self.assertNotIn(-6, travel)
        self.assertIn(-7, travel)
        self.assertIn(-8, travel)

    def test_process_airport(self):
        # change, add
        objects = [
            {
                'city': -1,
                'iata': 'ABC',
                'icao': 'ABCD',
                'names': [u'en:Abc', u'ru:Абв'],
                'has_afl_flights': '0',
                'lat': 5.0,
                'lon': 6.0,
                'class': 'Airport'
            },
            {
                'city': -1,
                'iata': 'DEF',
                'icao': 'DEFG',
                'names': [u'en:Def', u'ru:Где'],
                'has_afl_flights': '1',
                'lat': 5.0,
                'lon': 6.0,
                'class': 'Airport'
            }
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('airports')
        vocab.on_commit()
        self.assertEqual(t2l(vocab['ABC'].title, 'ru'), u'Абв')
        self.assertEqual(t2l(vocab['DEF'].title, 'ru'), u'Где')

        # replace_all
        objects = [
            {
                'city': -1,
                'iata': 'GHI',
                'icao': 'GHIJ',
                'names': [u'en:Ghi', u'ru:Жзи'],
                'has_afl_flights': '0',
                'lat': 5.0,
                'lon': 6.0,
                'class': 'Airport'
            },
            {
                'city': -1,
                'iata': 'JKL',
                'icao': 'JKLM',
                'names': [u'en:Jkl', u'ru:Клм'],
                'has_afl_flights': '1',
                'lat': 5.0,
                'lon': 6.0,
                'class': 'Airport'
            }
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('airports')
        vocab.on_commit()
        self.assertNotIn('ABC', vocab)
        self.assertNotIn('DEF', vocab)
        self.assertEqual(t2l(vocab['GHI'].title, 'ru'), u'Жзи')
        self.assertEqual(t2l(vocab['JKL'].title, 'ru'), u'Клм')

        # delete
        objects = [
            {
                'city': -1,
                'iata': 'GHI',
                'icao': 'GHIJ',
                'names': [u'en:Ghi', u'ru:Жзи'],
                'has_afl_flights': '0',
                'lat': 5.0,
                'lon': 6.0,
                'class': 'Airport'
            }
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('airports')
        vocab.on_commit()
        self.assertNotIn('GHI', vocab)
        self.assertIn('JKL', vocab)

    def test_process_world_regions(self):
        # change, add
        objects = [
            {
                'class': 'WorldRegion',
                'world_region_id': 1,
                'names': [u'en:Europe', u'ru:Европа'],
            },
            {
                'class': 'WorldRegion',
                'world_region_id': 2,
                'names': [u'en:America', u'ru:Америка'],
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('world_regions')
        vocab.on_commit()
        self.assertEqual(t2l(vocab[1].title, 'ru'), u'Европа')
        self.assertEqual(t2l(vocab[2].title, 'ru'), u'Америка')

        # replace_all
        objects = [
            {
                'class': 'WorldRegion',
                'world_region_id': 3,
                'names': [u'en:Africa', u'ru:Африка'],
            },
            {
                'class': 'WorldRegion',
                'world_region_id': 4,
                'names': [u'en:Asia', u'ru:Азия'],
            },
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('world_regions')
        vocab.on_commit()
        self.assertNotIn(1, vocab)
        self.assertNotIn(2, vocab)
        self.assertEqual(t2l(vocab[3].title, 'ru'), u'Африка')
        self.assertEqual(t2l(vocab[4].title, 'ru'), u'Азия')

        # delete
        objects = [{
            'class': 'WorldRegion',
            'world_region_id': 4,
            'names': [u'en:Asia', u'ru:Азия'],
        }]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('world_regions')
        vocab.on_commit()
        self.assertNotIn(4, vocab)
        self.assertIn(3, vocab)

    def test_process_countries(self):
        # change, add
        objects = [
            {
                'class': 'Country',
                'iso_code2': 'RU',
                'iso_code3': 'RUS',
                'names': [u'ru:Российская Федерация', u'en:Russian Federation'],
                'world_region': 1,
                'currency': 'RUB',
                'use_in_pos': 1,
                'telephone_code': '+7',
            },
            {
                'class': 'Country',
                'iso_code2': 'DE',
                'iso_code3': 'DEU',
                'names': [u'ru:Германия', u'en:Germany'],
                'world_region': 1,
                'currency': 'EUR',
                'use_in_pos': 1,
                'telephone_code': '+49',
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('countries')
        vocab.on_commit()
        self.assertEqual(t2l(vocab['RU'].title, 'ru'), u'Российская Федерация')
        self.assertEqual(t2l(vocab['DE'].title, 'ru'), u'Германия')

        # replace_all
        objects = [
            {
                'class': 'Country',
                'iso_code2': 'FR',
                'iso_code3': 'FRA',
                'names': [u'ru:Франция', u'en:France'],
                'world_region': 1,
                'currency': 'EUR',
                'use_in_pos': 1,
                'telephone_code': '+33',
            },
            {
                'class': 'Country',
                'iso_code2': 'IT',
                'iso_code3': 'ITA',
                'names': [u'ru:Италия', u'en:Italy'],
                'world_region': 1,
                'currency': 'EUR',
                'use_in_pos': 1,
                'telephone_code': '+39',
            }
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('countries')
        vocab.on_commit()
        self.assertNotIn('RU', vocab)
        self.assertNotIn('DE', vocab)
        self.assertEqual(t2l(vocab['FR'].title, 'ru'), u'Франция')
        self.assertEqual(t2l(vocab['IT'].title, 'ru'), u'Италия')

        # delete
        objects = [
            {
                'class': 'Country',
                'iso_code2': 'FR',
                'iso_code3': 'FRA',
                'names': [u'ru:Франция', u'en:France'],
                'world_region': 1,
                'currency': 'EUR',
                'use_in_pos': 1,
                'telephone_code': '+33',
            }
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('countries')
        vocab.on_commit()
        self.assertNotIn('FR', vocab)
        self.assertIn('IT', vocab)

    def test_process_currencies(self):
        # change, add
        objects = [
            {
                'class': 'Currency',
                'alpha3_code': 'RUB',
                "names": [u"en:Ruble", u"ru:Рубль"],
                'used_in_calc': 1,
                'minor_unit': 2,
                'rounding_unit': 5,
            },
            {
                'class': 'Currency',
                'alpha3_code': 'EUR',
                "names": [u"en:Euro", u"ru:Евро"],
                'used_in_calc': 1,
                'minor_unit': 2,
                'rounding_unit': 1,
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('currencies')
        vocab.on_commit()
        self.assertEqual(vocab['RUB'].code, u'RUB')
        self.assertEqual(vocab['EUR'].code, u'EUR')

        # replace_all
        objects = [
            {
                'class': 'Currency',
                'alpha3_code': 'DKK',
                "names": [u"en:Crone", u"ru:Крона"],
                'used_in_calc': 1,
                'minor_unit': 3,
                'rounding_unit': 1,
            },
            {
                'class': 'Currency',
                'alpha3_code': 'CZK',
                "names": [u"en:Crone", u"ru:Крона"],
                'used_in_calc': 1,
                'minor_unit': 2,
                'rounding_unit': 1,
            },
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('currencies')
        vocab.on_commit()
        self.assertNotIn('RUB', vocab)
        self.assertNotIn('EUR', vocab)
        self.assertEqual(vocab['DKK'].code, u'DKK')
        self.assertEqual(vocab['CZK'].code, u'CZK')

        # delete
        objects = [
            {
                'class': 'Currency',
                'alpha3_code': 'CZK',
                "names": [u"en:Crone", u"ru:Крона"],
                'used_in_calc': 1,
                'minor_unit': 2,
                'rounding_unit': 1,
            },
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('currencies')
        vocab.on_commit()
        self.assertNotIn('CZK', vocab)
        self.assertIn('DKK', vocab)

    def test_process_city(self):
        # change, add
        objects = [
            {
                'city_id': 101,
                'iata': 'LED',
                'country_code': 'RU',
                'lat': 5.0,
                'lon': 6.0,
                'can_book': True,
                'names': [u'en:Saint Petersburg', u'ru:Санкт-Петербург'],
                'tz': 'Europe\Moscow',
                'class': 'City'
            },
            {
                'city_id': 102,
                'iata': 'MOW',
                'country_code': 'RU',
                'lat': 5.0,
                'lon': 6.0,
                'can_book': True,
                'names': [u'en:Moscow', u'ru:Москва'],
                'tz': 'Europe\Moscow',
                'class': 'City'
            }
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('cities')
        vocab.on_commit()
        self.assertEqual(t2l(vocab['LED'].title, 'ru'), u'Санкт-Петербург')
        self.assertEqual(t2l(vocab['MOW'].title, 'ru'), u'Москва')
        vocab = getV('towns')
        vocab.on_commit()
        self.assertEqual(t2l(vocab[101].title, 'ru'), u'Санкт-Петербург')
        self.assertEqual(t2l(vocab[102].title, 'ru'), u'Москва')

        # replace_all
        objects = [
            {
                'city_id': 103,
                'iata': 'OMS',
                'country_code': 'RU',
                'lat': 5.0,
                'lon': 6.0,
                'can_book': True,
                'names': [u'en:Omsk', u'ru:Омск'],
                'tz': 'Europe\Moscow',
                'class': 'City'
            },
            {
                'city_id': 104,
                'iata': 'VVO',
                'country_code': 'RU',
                'lat': 5.0,
                'lon': 6.0,
                'can_book': True,
                'names': [u'en:Vladivostok', u'ru:Владивосток'],
                'tz': 'Europe\Moscow',
                'class': 'City'
            }
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('cities')
        vocab.on_commit()
        self.assertNotIn('LED', vocab)
        self.assertNotIn('MOW', vocab)
        self.assertEqual(t2l(vocab['OMS'].title, 'ru'), u'Омск')
        self.assertEqual(t2l(vocab['VVO'].title, 'ru'), u'Владивосток')
        vocab = getV('towns')
        vocab.on_commit()
        self.assertNotIn(101, vocab)
        self.assertNotIn(102, vocab)
        self.assertEqual(t2l(vocab[103].title, 'ru'), u'Омск')
        self.assertEqual(t2l(vocab[104].title, 'ru'), u'Владивосток')

        # delete
        objects = [
            {
                'city_id': 103,
                'iata': 'OMS',
                'country_code': 'RU',
                'lat': 5.0,
                'lon': 6.0,
                'can_book': True,
                'names': [u'en:Omsk', u'ru:Омск'],
                'tz': 'Europe\Moscow',
                'class': 'City'
            }
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('cities')
        vocab.on_commit()
        self.assertNotIn('OMS', vocab)
        self.assertIn('VVO', vocab)
        vocab = getV('towns')
        vocab.on_commit()
        self.assertNotIn(103, vocab)
        self.assertIn(104, vocab)

    def test_process_additional_info(self):
        # change, add
        objects = [
            {
                u'additional_info_id': 1,
                u'weight': 10,
                u'created': u'2015-10-28',
                u'names': [u'ru:Эстонские', u'en:Estonian'],
                u'class': u'AdditionalInfo',
                u'condition': [{u'airport_to': u'TLL', u'airline': u'OV'}, {u'airport_from': u'TLL', u'airline': u'OV'}],
                u'position': u'flight',
            },
            {
                u'additional_info_id': 2,
                u'weight': 10,
                u'created': u'2015-10-28',
                u'names': [u'ru:Латвийские', u'en:Latvian'],
                u'class': u'AdditionalInfo',
                u'condition': [{u'airport_to': u'RIX', u'airline': u'BT'}, {u'airport_from': u'RIX', u'airline': u'BT'}],
                u'position': u'flight',
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('additional_info')
        vocab.on_commit()
        self.assertEqual(t2l(vocab[1].title, 'ru'), u'Эстонские')
        self.assertEqual(t2l(vocab[2].title, 'ru'), u'Латвийские')

        # replace_all
        objects = [
            {
                u'additional_info_id': 3,
                u'weight': 10,
                u'created': u'2015-10-28',
                u'names': [u'ru:Эстонские', u'en:Estonian'],
                u'class': u'AdditionalInfo',
                u'condition': [{u'airport_to': u'CPH', u'airline': u'OV'}, {u'airport_from': u'CPH', u'airline': u'OV'}],
                u'position': u'flight',
            },
            {
                u'additional_info_id': 4,
                u'weight': 10,
                u'created': u'2015-10-28',
                u'names': [u'ru:Женевские', u'en:Genevian'],
                u'class': u'AdditionalInfo',
                u'condition': [{u'airport_to': u'GVA', u'airline': u'BT'}],
                u'position': u'flight',
            },
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('additional_info')
        vocab.on_commit()
        self.assertNotIn(1, vocab)
        self.assertNotIn(2, vocab)
        self.assertEqual(t2l(vocab[3].title, 'ru'), u'Эстонские')
        self.assertEqual(t2l(vocab[4].title, 'ru'), u'Женевские')

        # delete
        objects = [{
            u'additional_info_id': 4,
            u'weight': 10,
            u'created': u'2015-10-28',
            u'names': [u'ru:Женевские', u'en:Genevian'],
            u'class': u'AdditionalInfo',
            u'condition': [{u'airport_to': u'GVA', u'airline': u'BT'}],
            u'position': u'flight',
        }]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('additional_info')
        vocab.on_commit()
        self.assertNotIn(4, vocab)
        self.assertIn(3, vocab)


    def test_process_meal_rule(self):
        # change, add
        objects = [
            {
                u'class': u'MealRule',
                u'meal_rule_id': 1,
                u'special_meal': [u'CHML'],
                u'origin': [u'EVN'],
                u'date_from': None,
                u'destination': [u'SVO'],
                u'number': None,
                u'booking_class': [],
                u'airline': [],
                u'date_to': None,
            },
            {
                u'class': u'MealRule',
                u'meal_rule_id': 2,
                u'special_meal': [u'CHML', u'BBML', u'RVML', u'SFML'],
                u'origin': [u'BQS'],
                u'date_from': None,
                u'destination': [],
                u'number': u'46,699',
                u'booking_class': [],
                u'airline': [],
                u'date_to': None,
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('meal_rules')
        vocab.on_commit()
        self.assertEqual(vocab[1].special_meal, [u'CHML'])
        self.assertEqual(vocab[2].special_meal, [u'CHML', u'BBML', u'RVML', u'SFML'])

    def test_add_special_meals(self):
        vocab = getV('ssr_meal_codes')
        vocab.add(SpecialMeal(code='ONE1', names=[]))
        vocab.on_commit()
        objects = [
            {
                'code': 'ONE1',
                'names': [u'en:first', u'ru:первый'],
                'class': 'SpecialMeal'
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'change', 'objects': objects})
        vocab = getV('ssr_meal_codes')
        vocab.on_commit()
        self.assertEqual(vocab['ONE1'], SpecialMeal(code=objects[0]['code'], names=objects[0]['names']))

    def test_replace_all_special_meals(self):
        vocab = getV('ssr_meal_codes')
        vocab.add(SpecialMeal(code='ONE1', names=[]))
        vocab.on_commit()
        objects = [
            {
                'code': 'ONE2',
                'names': [u'en:first', u'ru:первый'],
                'class': 'SpecialMeal'
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('ssr_meal_codes')
        vocab.on_commit()
        self.assertEqual(vocab['ONE2'], SpecialMeal(code=objects[0]['code'], names=objects[0]['names']))
        self.assertNotIn('ONE1', vocab)

    def test_delete_special_meals(self):
        vocab = getV('ssr_meal_codes')
        vocab.add(SpecialMeal(code='ONE1', names=[]))
        vocab.on_commit()
        objects = [
            {
                'code': 'ONE1',
                'names': [u'en:first', u'ru:первый'],
                'class': 'SpecialMeal'
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('ssr_meal_codes')
        vocab.on_commit()
        self.assertNotIn('ONE1', vocab)

    def test_process_meal_timelimit(self):
        # change, add
        objects = [
            {u'class': u'MealTimelimit', u'meal_timelimit_id': 1, u'origin': [], u'special_meal': [], u'timelimit': 36},
            {u'class': u'MealTimelimit', u'meal_timelimit_id': 2, u'origin': [], u'special_meal': [u'VJML'], u'timelimit': 63},
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('meal_timelimits')
        vocab.on_commit()
        self.assertEqual(vocab[1].timelimit, 36)
        self.assertEqual(vocab[2].timelimit, 63)

        # replace_all
        objects = [
            {u'class': u'MealTimelimit', u'meal_timelimit_id': 3, u'origin': [u'SVO'], u'special_meal': [u'VGML'], u'timelimit': 12},
            {u'class': u'MealTimelimit', u'meal_timelimit_id': 4, u'origin': [u'LED'], u'special_meal': [u'VJML'], u'timelimit': 24},
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab.on_commit()
        self.assertNotIn(1, vocab)
        self.assertNotIn(2, vocab)
        self.assertEqual(vocab[3].timelimit, 12)
        self.assertEqual(vocab[4].timelimit, 24)

                # delete
        objects = [{u'class': u'MealTimelimit', u'meal_timelimit_id': 4, u'origin': [u'LED'], u'special_meal': [u'VJML'], u'timelimit': 24}]
        svc.process({'event': 'delete', 'objects': objects})
        vocab.on_commit()
        self.assertNotIn(4, vocab)
        self.assertIn(3, vocab)

    def test_process_special_meal(self):
        # change, add
        objects = [
            {u'code': u'VJML', u'class': u'SpecialMeal', u'names': [u'ru:Постное', u'en:Eastern Orthodoxal Lenten meal']},
            {u'code': u'DBML', u'class': u'SpecialMeal', u'names': [u'ru:Диабетическое', u'en:Diabetic meal']},
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('ssr_meal_codes')
        vocab.on_commit()
        self.assertEqual(vocab[u'VJML'].names, [u'ru:Постное', u'en:Eastern Orthodoxal Lenten meal'])
        self.assertEqual(vocab[u'DBML'].names, [u'ru:Диабетическое', u'en:Diabetic meal'])

        # replace_all
        objects = [
            {u'code': u'KSML', u'class': u'SpecialMeal', u'names': [u'ru:Кошерное', u'en:Kosher meal']},
            {u'code': u'FPML', u'class': u'SpecialMeal', u'names': [u'ru:Фруктовое', u'en:Fruit platter']},
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab.on_commit()
        self.assertNotIn(u'VJML', vocab)
        self.assertNotIn(u'DBML', vocab)
        self.assertEqual(vocab[u'KSML'].names, [u'ru:Кошерное', u'en:Kosher meal'])
        self.assertEqual(vocab[u'FPML'].names, [u'ru:Фруктовое', u'en:Fruit platter'])

        # delete
        objects = [{u'code': u'FPML', u'class': u'SpecialMeal', u'names': [u'ru:Фруктовое', u'en:Fruit platter']}]
        svc.process({'event': 'delete', 'objects': objects})
        vocab.on_commit()
        self.assertNotIn(u'FPML', vocab)
        self.assertIn(u'KSML', vocab)

    def test_process_charity_funds(self):
        # change, add
        objects = [
            {
                u'charity_fund_id': 1,
                u'names': [u'en:First charity funds', u'ru:Первый фонд'],
                u'logo_url': [u'en:http://aeroflot.ru/logo.png', u'ru:http://aeroflot.ru/logo.png'],
                u'image_url': [u'en:http://aeroflot.ru/image.png', u'ru:http://aeroflot.ru/image.png'],
                u'charity_short_description': [u'ru:Это короткое описание', u'en:This is short description'],
                u'charity_description':[u'ru:Это описание', u'en:This is description'],
                u'url': [u'en:http://aeroflot.ru/', u'ru:http://aeroflot.ru/'],
                u'transfer_conditions': [u'en:http://aeroflot.ru/', u'ru:http://aeroflot.ru/'],
                u'news_url': [u'en:http://aeroflot.ru/news', u'ru:http://aeroflot.ru/news'],
                u'news_mv_url': [u'en:http://aeroflot.ru/pda/news', u'ru:http://aeroflot.ru/pda/news'],
                u'donate_miles_url': u'http://aeroflot.ru/donate_miles_url',
                u'donate_miles_mv_url': u'http://aeroflot.ru/donate_miles_mv',
                u'stats_charity_funds_url': u'http://aeroflot.ru/stats',
                u'rss_url': u'',
                u'status': u'P',
                u'weight': 10,
                u'create_date': u'2015-10-29',
                u'modify_date': u'2016-10-30',
                u'charity_id': u'123456',
                u'class': u'CharityFund',
                u'contacts': u'contacts'
            },
            {
                u'charity_fund_id': 2,
                u'names': [u'en:Second charity funds', u'ru:Второй фонд'],
                u'logo_url': [u'en:http://aeroflot.ru/logo2.png', u'ru:http://aeroflot.ru/logo2.png'],
                u'image_url': [u'en:http://aeroflot.ru/image2.png', u'ru:http://aeroflot.ru/image2.png'],
                u'charity_short_description': [u'ru:Это короткое описание 2', u'en:This is short description 2'],
                u'charity_description': [u'ru:Это описание 2', u'en:This is description 2'],
                u'url': [u'en:http://aeroflot.ru/2', u'ru:http://aeroflot.ru/2'],
                u'transfer_conditions': [u'en:http://aeroflot.ru/2', u'ru:http://aeroflot.ru/2'],
                u'news_url': [u'en:http://aeroflot.ru/news2', u'ru:http://aeroflot.ru/news2'],
                u'news_mv_url': [u'en:http://aeroflot.ru/pda/news2', u'ru:http://aeroflot.ru/pda/news2'],
                u'donate_miles_url': u'http://aeroflot.ru/donate_miles2',
                u'donate_miles_mv_url': u'http://aeroflot.ru/donate_miles_mv2',
                u'stats_charity_funds_url': u'http://aeroflot.ru/stats2',
                u'rss_url': u'',
                u'status': u'P',
                u'weight': 100,
                u'create_date': u'2015-10-29',
                u'modify_date': u'2016-10-30',
                u'charity_id': '123457',
                u'class': u'CharityFund',
                u'contacts': u'contacts'
            }
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})

        vocab = getV('charity_funds')
        vocab.on_commit()
        self.assertEqual(t2l(vocab[1].title, 'ru'), u'Первый фонд')
        self.assertEqual(t2l(vocab[2].title, 'ru'), u'Второй фонд')

        # replace_all
        objects = [
            {
                u'charity_fund_id': 4,
                u'names': [u'en:fourth charity funds', u'ru:Четвертый фонд'],
                u'logo_url': [u'en:http://aeroflot.ru/logo4.png', u'ru:http://aeroflot.ru/logo4.png'],
                u'image_url': [u'en:http://aeroflot.ru/image4.png', u'ru:http://aeroflot.ru/image4.png'],
                u'charity_short_description': [u'ru:Это короткое описание 4', u'en:This is short description 4'],
                u'charity_description':[u'ru:Это описание 4', u'en:This is description 4'],
                u'url': [u'en:http://aeroflot.ru/4', u'ru:http://aeroflot.ru/4'],
                u'transfer_conditions': [u'en:http://aeroflot.ru/4', u'ru:http://aeroflot.ru/4'],
                u'news_url': [u'en:http://aeroflot.ru/news4', u'ru:http://aeroflot.ru/news4'],
                u'news_mv_url': [u'en:http://aeroflot.ru/pda/news4', u'ru:http://aeroflot.ru/pda/news4'],
                u'donate_miles_url': u'http://aeroflot.ru/donate_miles4',
                u'donate_miles_mv_url': u'http://aeroflot.ru/donate_miles_mv4',
                u'stats_charity_funds_url': u'http://aeroflot.ru/stats4',
                u'rss_url': u'',
                u'status': u'P',
                u'weight': 20,
                u'create_date': u'2015-10-29',
                u'modify_date': u'2016-10-30',
                u'charity_id': u'123459',
                u'class': u'CharityFund',
                u'contacts': u'contacts'
            },
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab = getV('charity_funds')
        vocab.on_commit()
        self.assertNotIn(1, vocab)
        self.assertNotIn(2, vocab)
        self.assertEqual(t2l(vocab[4].title, 'ru'), u'Четвертый фонд')

        # delete
        objects = [{
                u'charity_fund_id': 2,
                u'names': [u'en:Second charity funds', u'ru:Второй фонд'],
                u'logo_url': [u'en:http://aeroflot.ru/logo2.png', u'ru:http://aeroflot.ru/logo2.png'],
                u'image_url': [u'en:http://aeroflot.ru/image2.png', u'ru:http://aeroflot.ru/image2.png'],
                u'charity_short_description': [u'ru:Это короткое описание 2', u'en:This is short description 2'],
                u'charity_description': [u'ru:Это описание 2', u'en:This is description 2'],
                u'url': [u'en:http://aeroflot.ru/2', u'ru:http://aeroflot.ru/2'],
                u'transfer_conditions': [u'en:http://aeroflot.ru/2', u'ru:http://aeroflot.ru/2'],
                u'news_url': [u'en:http://aeroflot.ru/news2', u'ru:http://aeroflot.ru/news2'],
                u'news_mv_url': [u'en:http://aeroflot.ru/pda/news2', u'ru:http://aeroflot.ru/pda/news2'],
                u'donate_miles_url': u'http://aeroflot.ru/donate_miles2',
                u'donate_miles_mv_url': u'http://aeroflot.ru/donate_miles_mv2',
                u'stats_charity_funds_url': u'http://aeroflot.ru/stats2',
                u'rss_url': u'',
                u'status': u'P',
                u'weight': 100,
                u'create_date': u'2015-10-29',
                u'modify_date': u'2016-10-30',
                u'charity_id': '123457',
                u'class': u'CharityFund',
                u'contacts': u'contacts'
        }]
        svc.process({'event': 'delete', 'objects': objects})
        vocab = getV('charity_funds')
        vocab.on_commit()
        self.assertNotIn(2, vocab)
        self.assertIn(4, vocab)
   
    def test_process_ibeacon(self):
        # change, add
        objects = [
            {
                'beacon_id': 123,
                'unique_id': -1,
                'device_id': 'ABC',
                'beacon_description': [
                    u"en:Description 1",
                    u"ru:Описание 1"
                ],
                'message': [
                    u"en:Message 1",
                    u"ru:Сообщение 1"
                ],
                'message_type': 'special_offers',
                'location_latitude': 55.751432,
                'location_longitude': 37.596561,
                'device_major': 4660,
                'device_minor': 5590,
                'manufacturer_id': 'f7826da64fa24e988024bc5b71e0893e',
                'scheme_android': 'afl://menu/special-offers1',
                'scheme_ios': 'afl://menu/special-offers2',
                'scheme_winphone': 'afl://menu/special-offers3',
                'class': 'BluetoothBeacon'
            },
            {
                'beacon_id': 456,
                'unique_id': -2,
                'device_id': 'DEF',
                'beacon_description': [
                    u"en:Description 2",
                    u"ru:Описание 2"
                ],
                'message': [
                    u"en:Message 2",
                    u"ru:Сообщение 2"
                ],
                'message_type': 'other_offers',
                'location_latitude': 50.751432,
                'location_longitude': 30.596561,
                'device_major': 4661,
                'device_minor': 5591,
                'manufacturer_id': 'f7826da64fa24e988024bc5b71e0893f',
                'scheme_android': 'afl://menu/special-offers4',
                'scheme_ios': 'afl://menu/special-offers5',
                'scheme_winphone': 'afl://menu/special-offers6',
                'class': 'BluetoothBeacon'
            },
        ]
        svc = notify.NotifyService()
        svc.process({'event': 'add', 'objects': objects})
        vocab = getV('ibeacons')
        vocab.on_commit()
        self.assertEqual(vocab[-1].message, [u"en:Message 1", u"ru:Сообщение 1"])
        self.assertEqual(vocab[-2].message, [u"en:Message 2", u"ru:Сообщение 2"])
        
        # replace_all
        objects = [
            {
                'beacon_id': 456,
                'unique_id': -2,
                'device_id': 'DEF',
                'beacon_description': [
                    u"en:Description 2",
                    u"ru:Описание 2"
                ],
                'message': [
                    u"en:Message 2",
                    u"ru:Сообщение 2"
                ],
                'message_type': 'other_offers',
                'location_latitude': 50.751432,
                'location_longitude': 30.596561,
                'device_major': 4661,
                'device_minor': 5591,
                'manufacturer_id': 'f7826da64fa24e988024bc5b71e0893f',
                'scheme_android': 'afl://menu/special-offers4',
                'scheme_ios': 'afl://menu/special-offers5',
                'scheme_winphone': 'afl://menu/special-offers6',
                'class': 'BluetoothBeacon'
            },
            {
                'beacon_id': 789,
                'unique_id': -3,
                'device_id': 'GHI',
                'beacon_description': [
                    u"en:Description 3",
                    u"ru:Описание 3"
                ],
                'message': [
                    u"en:Message 3",
                    u"ru:Сообщение 3"
                ],
                'message_type': 'something',
                'location_latitude': 65.751432,
                'location_longitude': 47.596561,
                'device_major': 4662,
                'device_minor': 5592,
                'manufacturer_id': 'f7826da64fa24e988024bc5b71e0893a',
                'scheme_android': 'afl://menu/special-offers7',
                'scheme_ios': 'afl://menu/special-offers8',
                'scheme_winphone': 'afl://menu/special-offers9',
                'class': 'BluetoothBeacon'
            },
        ]
        svc.process({'event': 'replace_all', 'objects': objects})
        vocab.on_commit()
        self.assertNotIn(-1, vocab)
        self.assertEqual(vocab[-2].message, [u"en:Message 2", u"ru:Сообщение 2"])
        self.assertEqual(vocab[-3].message, [u"en:Message 3", u"ru:Сообщение 3"])

        # delete
        objects = [
            {
                'beacon_id': 789,
                'unique_id': -3,
                'device_id': 'GHI',
                'beacon_description': [
                    u"en:Description 3",
                    u"ru:Описание 3"
                ],
                'message': [
                    u"en:Message 3",
                    u"ru:Сообщение 3"
                ],
                'message_type': 'something',
                'location_latitude': 65.751432,
                'location_longitude': 47.596561,
                'device_major': 4662,
                'device_minor': 5592,
                'manufacturer_id': 'f7826da64fa24e988024bc5b71e0893a',
                'scheme_android': 'afl://menu/special-offers7',
                'scheme_ios': 'afl://menu/special-offers8',
                'scheme_winphone': 'afl://menu/special-offers9',
                'class': 'BluetoothBeacon'
            },
        ]
        svc.process({'event': 'delete', 'objects': objects})
        vocab.on_commit()
        self.assertNotIn(-3, vocab)
        self.assertIn(-2, vocab)

    @mock.patch('services.base.static.CATALOG_REGISTRY', [])
    def test_update_service_cache(self):

        class _TestService(object):
            def build_document(self):
                return None

            def __init__(self):
                self.documents = DocumentCatalog(dependencies={'cities'},
                                                 document_keys=[],
                                                 document_constructor=self.build_document)

        svc = _TestService()

        with mock.patch('services.base.static.DocumentCatalog.rebuild_documents') as rebuild_documents:
            on_vocab_change({'regions'}, catalogs={svc.documents})
            self.assertFalse(rebuild_documents.called)
            on_vocab_change({'cities'}, catalogs={svc.documents})
            self.assertTrue(rebuild_documents.called)

    @mock.patch('services.base.static.CATALOG_REGISTRY', [])
    def test_update_offices_static(self):
        from services.json_services.offices import OfficeJSONServiceV003
        svc = OfficeJSONServiceV003()

        with mock.patch('services.base.static.DocumentCatalog.rebuild_documents') as rebuild_documents:
            on_vocab_change({'regions'}, catalogs={svc.documents})
            self.assertFalse(rebuild_documents.called)
            on_vocab_change({'offices'}, catalogs={svc.documents})
            self.assertTrue(rebuild_documents.called)

        with mock.patch('services.base.static.DocumentCatalog.rebuild_documents') as rebuild_documents:
            on_vocab_change({'office_categories'}, catalogs={svc.documents})
            self.assertTrue(rebuild_documents.called)

        with mock.patch('services.base.static.DocumentCatalog.rebuild_documents') as rebuild_documents:
            on_vocab_change({'towns'}, catalogs={svc.documents})
            self.assertTrue(rebuild_documents.called)

        with mock.patch('services.base.static.DocumentCatalog.rebuild_documents') as rebuild_documents:
            on_vocab_change({'countries'}, catalogs={svc.documents})
            self.assertTrue(rebuild_documents.called)


if __name__ == "__main__":
    testoob.main()
