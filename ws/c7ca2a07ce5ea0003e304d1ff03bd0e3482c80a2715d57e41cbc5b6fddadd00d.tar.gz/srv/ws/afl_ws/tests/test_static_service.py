# -*- coding: utf-8 -*-

"""
$Id: test_static_service.py 35220 2018-07-22 10:33:38Z apinsky $
"""

import cherrypy
import testoob
from pyramid.tests.testlib import ModelTest, TestCaseWithPgDBAndVocabs, TestCaseWithI18N, TestCaseWithCP


from services.base.static import StaticService, StaticDocument

class TestStaticService(TestCaseWithPgDBAndVocabs, TestCaseWithCP):

    def test_serialize(self):
        svc = StaticService()
        text = svc.renderContent({1: u'фыва'})
        self.assertEqual(text, '{"1": "фыва"}')

    def test_serve_document(self):
        doc = StaticDocument('"aaabbb"')
        svc = StaticService()
        svc.serve_document(doc)
        self.assertEqual(cherrypy.response.headers['etag'], doc.etag)

        cherrypy.request.headers['If-None-Match'] = doc.etag
        self.assertRaises(cherrypy.HTTPRedirect, svc.serve_document, doc)

if __name__ == '__main__':
    testoob.main()
