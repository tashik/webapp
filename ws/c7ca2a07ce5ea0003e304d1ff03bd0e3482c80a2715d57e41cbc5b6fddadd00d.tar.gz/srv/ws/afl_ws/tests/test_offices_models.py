# -*- coding: utf-8 -*-

"""
$Id: $
"""


import testoob

import pyramid.vocabulary.mvcc
from pyramid.ormlite import dbquery
from pyramid.registry.interfaces import IRegisterableVocabulary
from pyramid.tests.testlib import (ModelTest, TestCaseWithPgDBAndVocabs )
from pyramid.vocabulary import getV
from pyramid.vocabulary.interfaces import IVocabulary

import _test_data
from _test_data import setup_vocabulary
import models.office


class TestOffices(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOffices, self).setUp()
        self.model = models.office.Office
        setup_vocabulary(models.office.OfficeTravelOptionVocabulary)

    def test_model(self):
        ob = models.office.Office.load(office_id=-1)
        self.assertEqual(ob.office_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.names, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.email, ['some@some.ru'])
        self.assertEqual(ob.fax, ['812-111-11-11'])
        self.assertEqual(ob.phone, ['812-111-11-11'])
        self.assertEqual(ob.lat, 99.99)
        self.assertEqual(ob.lon, 99.99)
        self.assertEqual(ob.address, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.worktime, [u'en:Eng', u'ru:Рус'])
        self.assertTrue(ob.in_airport)
        self.assertTrue(ob.insurance_policy)
        self.assertTrue(ob.noncash_booking)
        self.assertTrue(ob.new_office)
        self.assertEqual(ob.airport, u'XXX')
        self.assertEqual(ob.distance_to_airport, 123)
        self.assertEqual(ob.office_category, -1)
        self.assertEqual(ob.location_map, [u'ru:http://some.ru/ru.jpg', u'en:http://some.ru/en.jpg'])
        self.assertEqual(ob.transfer_time_public, 123)
        self.assertEqual(ob.transfer_time_automobile, 123)
        self.assertEqual(ob.transfer_time_foot, 123)

    def test_get_travel_options(self):
        ob = models.office.Office.load(office_id=-1)
        travels = ob.get_travel_options()
        self.assertEqual(len(travels), 1)
        self.assertIsInstance(travels[0], models.office.OfficeTravelOption)
        self.assertEqual(travels[0].travel_time, 123)


class TestOfficeVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOfficeVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.office.OfficeVocabulary)

    def testVocabulary(self):
        v = getV('offices')
        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(2 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.office.Office))
        self.assertEqual(ob.office_description, [u'en:Eng', u'ru:Рус'])

    def testVocabularyRegistration(self):
        v = getV('offices')
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.office.Office))
        self.assertEqual(ob.transfer_time_foot, 123)

        # Test that vocabulary factory is cacheable
        dbquery(u"update offices SET transfer_time_foot = 456 where office_id = -1")
        v = getV('offices')
        ob = v[-1]
        self.assertEqual(ob.transfer_time_foot, 123)
        v.preload()
        v = getV('offices')
        ob = v[-1]
        self.assertEqual(ob.transfer_time_foot, 456)


class TestOfficesCategory(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOfficesCategory, self).setUp()
        self.model = models.office.OfficeCategory
        setup_vocabulary(models.office.OfficeVocabulary)

    def test_model(self):
        ob = self.model.load(office_category_id=-1)

        self.assertEqual(-1, ob.city)
        self.assertEqual(ob.office_category_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.names, [u'en:Eng', u'ru:Рус'])

    def test_get_offices(self):
        ob = self.model.load(office_category_id=-1)
        offices = ob.get_offices()
        self.assertEqual(len(offices), 2)
        self.assertIsInstance(offices[0], models.office.Office)
        self.assertEqual(offices[0].transfer_time_public, 123)

class TestOfficeCategoryVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOfficeCategoryVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.office.OfficeCategoryVocabulary)

    def testVocabulary(self):
        v = getV('office_categories')

        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(2 in v)

        ob = v[-1]

        self.assertTrue(isinstance(ob, models.office.OfficeCategory))
        self.assertEqual(ob.city,-1)
        self.assertEqual(ob.office_category_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.names, [u'en:Eng', u'ru:Рус'])

    def testVocabularyRegistration(self):
        v = getV('office_categories')
        self.assertTrue(-1 in v)
        self.assertFalse(2 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.office.OfficeCategory))
        self.assertEqual(ob.city, -1)

        dbquery(u"update office_categories SET city = -2 where office_category_id = -1")
        v = getV('office_categories')
        ob = v[-1]
        self.assertEqual(ob.city, -1)
        v.preload()
        v = getV('office_categories')
        ob = v[-1]
        self.assertEqual(ob.city, -2)


class TestOfficesTravelOption(ModelTest, TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOfficesTravelOption, self).setUp()
        self.model = models.office.OfficeTravelOption

    def test_model(self):
        ob = self.model.load(office_travel_option_id=-1)

        self.assertEqual(ob.office_id, -1)
        self.assertEqual(ob.office_travel_option_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.travel_type, u'F')
        self.assertEqual(ob.travel_time, 123)


class TestOfficeTravelOptionVocabulary(TestCaseWithPgDBAndVocabs):
    _test_data_initializers = (_test_data.createTestData,)

    def setUp(self):
        super(TestOfficeTravelOptionVocabulary, self).setUp()
        pyramid.vocabulary.mvcc.register()
        setup_vocabulary(models.office.OfficeTravelOptionVocabulary)

    def testVocabulary(self):
        v = getV('office_travel_options')

        self.assertTrue(IVocabulary.providedBy(v))
        self.assertTrue(-1 in v)
        self.assertFalse(2 in v)

        ob = v[-1]

        self.assertTrue(isinstance(ob, models.office.OfficeTravelOption))

        self.assertEqual(ob.office_id, -1)
        self.assertEqual(ob.office_travel_option_description, [u'en:Eng', u'ru:Рус'])
        self.assertEqual(ob.travel_type, u'F')
        self.assertEqual(ob.travel_time, 123)

    def testVocabularyRegistration(self):
        v = getV('office_travel_options')
        self.assertTrue(-1 in v)
        self.assertFalse(1 in v)
        ob = v[-1]
        self.assertTrue(isinstance(ob, models.office.OfficeTravelOption))
        self.assertEqual(ob.travel_time, 123)

        dbquery(u"update office_travel_options SET travel_time = 456 where office_travel_option_id = -1")
        v = getV('office_travel_options')
        ob = v[-1]
        self.assertEqual(ob.travel_time, 123)
        v.preload()
        v = getV('office_travel_options')
        ob = v[-1]
        self.assertEqual(ob.travel_time, 456)


if __name__ == "__main__":
    testoob.main()
