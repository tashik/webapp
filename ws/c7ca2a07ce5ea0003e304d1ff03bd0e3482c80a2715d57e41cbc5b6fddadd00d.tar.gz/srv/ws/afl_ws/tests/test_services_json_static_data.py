# -*- coding: utf-8 -*-

"""
$Id: test_services_json_static_data.py 10039 2014-12-17 17:37:00Z ogambaryan $
"""

import os
import testoob
import unittest
import cherrypy

import demjson
from services.json_services.static_data import StaticDataJSONService

import config

test_json_data = """
{'object_one':{'name': 'Object', 'value': '123' },
 'object_two':{'name': 'Two', 'value': 'test value' }
}
"""


class TestStaticDataJSONService(unittest.TestCase):

    def setUp(self):
        super(TestStaticDataJSONService, self).setUp()
        self.s = StaticDataJSONService()
        self.service_name = '_test_json_static_data'
        self.service_file_path = os.path.join(config.DATADIR, '%s.json' % self.service_name)
        f = open(self.service_file_path, 'w')
        f.write(test_json_data)
        f.close()


    def tearDown(self):
        if os.path.exists(self.service_file_path):
            os.remove(self.service_file_path)
        super(TestStaticDataJSONService, self).tearDown()

    def test_v001(self):
        u"""Проверка общего принципа"""
        data = self.s.v001(self.service_name)
        json_data = demjson.decode(data)
        self.assertEqual('Object', json_data['data']['object_one']['name'])
        self.assertEqual('123', json_data['data']['object_one']['value'])
        self.assertEqual('Two', json_data['data']['object_two']['name'])
        self.assertEqual('test value', json_data['data']['object_two']['value'])

    def test_v001_NotFound(self):
        u"""Что будет если файла под сервис не существует"""
        self.assertRaises(cherrypy.NotFound, self.s.v001, '__bad_service_name')

    def test_v001_all(self):
        u"""Проверим все текущие данные для статических сервисов"""
        for file_name in os.listdir(config.DATADIR):
            if not file_name.endswith('json'):
                continue
            file_name = file_name.replace('.json', '')
            data = self.s.v001(file_name)
            json_data = demjson.decode(data)
            self.assertTrue(json_data['data'])
            self.assertTrue(json_data['isSuccess'])
            self.assertFalse(json_data['errors'])






if __name__ == "__main__":
    testoob.main()
