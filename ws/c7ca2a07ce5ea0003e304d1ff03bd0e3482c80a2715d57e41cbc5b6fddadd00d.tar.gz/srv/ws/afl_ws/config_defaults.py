# -*- coding: utf-8 -*-

"""
$Id: config_defaults.py 35220 2018-07-22 10:33:38Z apinsky $
"""

import os
import os.path
import logging
import pyramid
import re

import socket
socket.setdefaulttimeout(60)

SERVER_PORT = NotImplemented
SERVER_HOST = '127.0.0.1'
INSTANCE_ID = None
PROXY_IP = ['127.0.0.1']    # see initializer.trusted_proxy

COOKIE_DOMAIN = None

VIRTUAL_BASE = '/ws'  # путь до корня приложения

EXT_SERVER_URL = NotImplemented  # URL для доступа к веб-серверу приложения, строка вида 'http://127.0.0.1:80'
VIRTUAL_STATIC_BASE = VIRTUAL_BASE

LK_URL = 'http://127.0.0.1:7080/personal'  # URL для ссылок на ресурсы "Личного кабинета" (также используется для SSO)

APPDIR = os.path.dirname(__file__)
PYRAMIDDIR = os.path.dirname(pyramid.__file__)
TEMPLATEDIR = [APPDIR + '/templates', PYRAMIDDIR + '/ui/templates']
LOG_LEVEL = logging.DEBUG

LOGDIR = APPDIR + '/log'
ERRORDIR = APPDIR + '/log/errors'
SESSDIR = APPDIR + '/session'
STATICDIR = APPDIR + '/static'
PIDDIR = APPDIR + '/pid'
DATADIR = APPDIR + '/data'

CSS_BASE_PATH = '/static/style'
JS_BASE_PATH = '/static/js'

CSS_MAIN_FILE = 'style.css'

COMPANY_NAME = u'Аэрофлот – Российские авиалинии'  # Set real company name
SYSTEM_NAME = u'Веб-сервисы'  # Set real application name
COPYRIGHT_STRING = '&copy; 2013'
COPYRIGHT_NAME = 'Аэрофлот'
FAVICONFILE = STATICDIR + '/favicon.ico'

ENCODING = 'utf-8'

DEFAULT_DB_CON = 'psycopgcon'
DEFAULT_DB_TYPE = 'pg'

POSTGRES_DSN = NotImplemented

ADMIN_EMAIL = []
SMTP_FROM = 'skel@localhost'
SMTP_SERVER = 'klaus-s.com.spb.ru'
SMTP_PORT = 25

APP_COOKIE = 'AF'
DEBUG_COOKIE = '_DEBUG'

ENABLE_I18N = True
KNOWN_LANGUAGES = ('ru', 'en')
FALLBACK_LANGUAGES = ['en']
DEFAULT_SERVICE_LANG = 'en'

# Хэши для доступа к веб-сервисам мониторинга - ошибки и т.д.
# Для вычисления хэша используем команду: print hashlib.md5('mon-ws-client:aeroflot-digest:PASSWORD').hexdigest()
MONITORING_WS_DIGEST = {'mon-ws-client': '################################'}
CO2_ADMIN_WS_DIGEST = NotImplemented
# Кто имеет доступ к расширенному отчету об ошибке
ERROR_DETAILS_ACCESS = ['mon-ws-client']
# IP системы сетевого мониторинга
MONITORING_ACCESS_IP = ['127.0.0.1']

# Компоненты Pyramid ---------------------------------------------------------

INCLUDE_CONTRACTORS = False
INCLUDE_FILES       = False
INCLUDE_PERSONS     = False
INCLUDE_EMPLOYEES   = False
INCLUDE_LOCATIONS   = False
INCLUDE_EMPLOYEES = INCLUDE_CONTRACTORS and INCLUDE_PERSONS

# Google Analytics -----------------------------------------------------------
GA_ACCOUNT = None

PBUS_URL = None #'http://127.0.0.1:8390'
PBUS_MY_NAME = os.environ.get('USER') or os.environ.get('USERNAME')
PBUS_PASSWORD = '#######'
PBUS_CALLBACK_HOST = '127.0.0.1'
PBUS_CALLBACK_PORT = SERVER_PORT
PBUS_CALLBACK_PASSWORD = '#######'
PBUS_TOPICS = {
    'vocabs': 'vocabs',
}
PBUS_VOCAB_RECIPIENTS = {
    'vocabs': 'vocabs'
}


PASSBOOK_SITE = 'https://stage.passbook.aeroflot.ru'

#PASSBOOK_SITE = 'https://passbook.aeroflot.ru'

PASSBOOK_TEMPLATE_URL = '%s/api/provider/templates' % PASSBOOK_SITE
PASSBOOK_ACTION_URL = '%s/api/provider/pass/%%s' % PASSBOOK_SITE
PASSBOOK_CARD_URL = '%s/api/client/pass/%%s' % PASSBOOK_SITE

PASSBOOK_URL = {
    'PNR':{
        'AuthKey': 'FE0551AE8BFDE9834C9883627EEDFFD7DFC444AD722876215736AD1340883FDA',
        'BASIC': '828251ad54a3476e84a499ffcc1d2207'
    },

    'BONUS':{
        'AuthKey': 'B014AF72C73D4BEB2C0E7174771C8B0ACB02B646CF6BEB9EA6C1E483CA1E7930',
        'BASIC': 'af8f7f6e65c640ccb36666fe6b5a380f',
        'SILVER': '2dcae17a69cd4a71baf8d05263d39fc3',
        'GOLD': 'ca3cebec886f4b2599326b2cd9c4a8c5',
        'PLATINUM': 'e391689869dd46e197adb2169121a442',
    },

    'BPASS': {
        'AuthKey': '###########################',
        'BASIC'  : '###########################'
    }
}

WS_PASSBOOK_PASSWORD = NotImplemented
ICER_SFTP_HOST = NotImplemented
ICER_SFTP_PORT = 22
ICER_SFTP_USERNAME = NotImplemented
ICER_SFTP_PASSWORD = NotImplemented
ICER_FILE_NAME_RE = re.compile(r'ICER_.*\.csv\.(\d{8}_\d{6}_\d{4})\.zip')

GEOIP_DB_PATH = os.path.abspath(os.path.join(APPDIR, '..', 'afl_cabinet-lib', 'GeoLite2-City.mmdb'))

# Сколько секунд кэшировать справочники в браузере
STATIC_DOCUMENT_CACHING_PERIOD = 300

# CherryPy Global Configuration -------------------------------------
CPCONFIG_GLOBAL = {}

# Конфигурация для страниц веб-приложения ---------------------------
# подключается в cpdispatcher.py
CPCONFIG_APP = {}

# Конфигурация для диспетчера статических файлов --------------------
CPCONFIG_STATIC = {}
