var currency = "RUB";
var currencies = [];

/* Determining path to THIS script */
var scripts = document.getElementsByTagName('script');
var path = scripts[scripts.length-1].src.split('?')[0];      // remove any ?query
var mydir = path.split('/').slice(0, -3).join('/')+'/';  // remove last filename part of path

if(path.indexOf("hide.me") >= 0){
    /* for proxy tests */
    mydir = "//";
}

var VIRTUAL_BASE = mydir;

function collect_prices()
{
    var prices;
    var price;

    prices = Array();
    $("span[data-price]").each(function(i, sp){
        price = {};
        price.currency = $(sp).attr("data-currency");
        if(!price.currency){
            price.currency = "RUB";
        }
        price.price = parseFloat($(sp).attr("data-price"));
        prices.push(price);
    })

    return prices;
}

function draw_prices(prices)
{
    var sel_html, cur, i;

    sel_html = "<select>";
    for(i in currencies){
        cur = currencies[i];
        sel_html += '<option value="' + cur + '"';
        if(cur == currency){
            sel_html += ' selected="selected">';
        } else {
            sel_html += '>';
        }
        sel_html += cur + "</option>"
    }
    sel_html += "</select>"
    $("span[data-price]").each(function(i, sp){
        price = prices[i];
        $(sp).html("<b>" + price.price + "</b>&nbsp;" + sel_html);
        $(sp).find("select").change(function(e){
            currency = this.value;
            init_cur_calc_main();
        })
    })
}

function drawOriginalPrices()
{
    var sel_html, cur, i, price;

    $("span[data-price]").each(function(i, sp){
        price = {};
        price.currency = $(sp).attr("data-currency");
        if(!price.currency){
            price.currency = "RUB";
        }
        price.price = parseFloat($(sp).attr("data-price"));
        sel_html = '<span>' + price.currency + '</span>';
        $(sp).html("<b>" + price.price + "</b>&nbsp;" + sel_html);
    });
}

function calculate_prices()
{
    $.ajax({
        url: VIRTUAL_BASE + "v.0.0.1/json/icer/" + currency + "/",
        type: "GET",
        dataType: "JSON",
        data: {
            prices: JSON.stringify(collect_prices())
        },
        crossDomain: true,
        success: function(data){
            var prices;
            prices = data.data.prices;
            draw_prices(prices);
        },
        error: drawOriginalPrices
    })
}

function init_cur_calc_main(){
    $.ajax({
        url: VIRTUAL_BASE + "v.0.0.1/json/calcurr/",
        type: "POST",
        dataType: "JSON",
        data: "",
        crossDomain: true,
        success: function(data){
            currencies = data.data;
            if($.inArray(currency, currencies) == -1){
                currency = 'RUB';
            }
            $.cookie("CURRENCY_ICER", currency, {expires: 7, path: '/'});
            calculate_prices();
        },
        error: drawOriginalPrices
    })
}

function init_from_geoip(data){
    currency = data.data.currency;
    init_cur_calc_main();
}

function init_cur_calc(){
    var cookie;
    cookie = null;
    cookie = $.cookie("CURRENCY_ICER");
    if(cookie){
        currency = cookie;
        init_cur_calc_main();
        return;
    }
    if(typeof geoip_country === undefined){
        drawOriginalPrices();
        return;
    }
    $.ajax({
        url: VIRTUAL_BASE + "v.0.0.1/json/currency/" + geoip_country,
        type: "POST",
        dataType: "JSON",
        data: "",
        crossDomain: true,
        success: init_from_geoip,
        error: drawOriginalPrices
    })
}

$(document).ready(function(){
    drawOriginalPrices();
    $.ajax({
        url: VIRTUAL_BASE + "/static/js/jquery.cookie.js", 
        async:false,
        cache:false,
        type: "POST",
        crossDomain: true,
        dataType: 'script',
        data: "",
        success: init_cur_calc,
        error: drawOriginalPrices
    });
    $(document).ajaxError(drawOriginalPrices);
});
