# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements
from pyramid.ormlite.record import ActiveRecord
from pyramid.ormlite.models import TitleCapable
from pyramid.registry import makeVocabularyRegisterable
from models.interfaces import IOffice, IOfficeCategory, IOfficeTravelOption
from models.base import WSVocabularyBase
from models.ml import MLTitleCapable
from pyramid.vocabulary import getV
from zope.schema.interfaces import ITokenizedTerm

class OfficeCategory(ActiveRecord, MLTitleCapable):
    u"""Категория офисов продаж"""

    implements(IOfficeCategory)
    p_table_name = 'office_categories'

    def get_offices(self, vocab=None):
        u"""Получить список всех офисов данной категории"""

        if vocab is None:
            vocab = getV('offices')
        token = ITokenizedTerm(self).token
        res = []
        for office in vocab:
            if str(office.office_category) == token:
                res.append(office)
        return res

class OfficeCategoryVocabulary(WSVocabularyBase):
    objectC = OfficeCategory
    makeVocabularyRegisterable('office_categories')


class Office(ActiveRecord, MLTitleCapable):
    u"""Офис"""

    implements(IOffice)
    p_table_name = 'offices'

    def get_travel_options(self, vocab=None):
        u"""Получить список возможных марштуртов для офиса"""

        if vocab is None:
            vocab = getV('office_travel_options')
        token = ITokenizedTerm(self).token
        res = []
        for travel in vocab:
            if str(travel.office_id) == token:
                res.append(travel)
        return res



class OfficeVocabulary(WSVocabularyBase):
    objectC = Office
    makeVocabularyRegisterable('offices')


class OfficeTravelOption(ActiveRecord, TitleCapable):
    u"""Дорога до офиса"""

    implements(IOfficeTravelOption)
    p_table_name = 'office_travel_options'


class OfficeTravelOptionVocabulary(WSVocabularyBase):
    u"""Vocab "Дорога до офиса" """

    objectC = OfficeTravelOption
    makeVocabularyRegisterable('office_travel_options')
