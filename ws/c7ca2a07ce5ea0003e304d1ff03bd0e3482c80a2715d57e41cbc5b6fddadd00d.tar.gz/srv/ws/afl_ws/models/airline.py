#!/usr/bin/env python
# -*- coding: utf-8 -*-
from pyramid.ormlite.record import ActiveRecord

from zope.interface import implements

from pyramid.ormlite.models import TitleCapable
from pyramid.registry import makeVocabularyRegisterable

from models.interfaces import IAirline
from models.base import WSVocabularyBase


class Airline(ActiveRecord, TitleCapable):
    p_table_name = 'vocab_airlines'

    u"""Авиакомпании"""
    implements(IAirline)

    @property
    def name_en(self):
        try:
            d = dict([s.split(':', 1) for s in self.names])
        except ValueError:
            return ''
        return d.get('en', '')


class AirlinesVocabulary(WSVocabularyBase):
    objectC = Airline
    makeVocabularyRegisterable('airlines')