# -*- coding: utf-8 -*-

"""
$Id: $
"""

import json
import re
from pyramid.ormlite import dbquery
from pyramid.ormlite.schema.interfaces import IORMField
from pyramid.vocabulary.mvcc import MvccVocabulary
from pyramid.ormlite.schema.schema import ORMField, TextLine
from zope.interface import implements
from zope.schema.interfaces import IList, ITextLine
from zope.schema import List

LOYALTY_ID_REGEXP = re.compile(r'^\s*[0-9]+[0-9 ]*$')

class WSVocabularyBase(MvccVocabulary):
    objectC = NotImplemented

    @staticmethod
    def coerce_token(token):
        u"""Приводит токен к общему формату"""
        if isinstance(token, (list, tuple,)):
            return '-'.join([ str(p) for p in token ])
        return str(token)

    def preload(self):
        table_name = self.objectC.p_table_name
        objects = self.objectC.bulkLoadList(dbquery('select * from %s' % table_name))
        self.add_many(objects)


class IConditionField(IORMField, IList):
    pass


class ConditionField(ORMField, List):
    implements(IConditionField)

    def _toType(self, value):
        if isinstance(value, basestring):
            return json.loads(value)
        return super(ConditionField, self)._toType(value)

    def toDbType(self, value):
        value = super(ConditionField, self).toDbType(value)
        return json.dumps(value, ensure_ascii=False).encode('utf8')

    def null(self):
        return []

class ILoyaltyIdField(ITextLine):
    pass

class LoyaltyIdField(TextLine):
    u"""Номер в системе лояльности"""
    implements(ILoyaltyIdField)

    def constraint(self, value):
        return super(LoyaltyIdField, self).constraint(value) and bool(LOYALTY_ID_REGEXP.match(value))

