# -*- coding: utf-8 -*-

"""
$Id: interfaces.py 35222 2018-07-22 15:36:50Z apinsky $
"""

from datetime import date
from zope.interface import Interface
from zope.schema import Dict
from pyramid.ormlite.schema import *
from models.ml import MLNames, TextLineList, MLText
from models.uppercase import UppercaseTextLine
from models.base import ConditionField, LoyaltyIdField

from DecNumber import DecNumber

class IAirport(Interface):
    u"""Аэропорт"""

    airport = UppercaseTextLine(db_column='airport', title=u'IATA-код аэропорта', min_length=3, max_length=3, primary_key=True)
    icao = UppercaseTextLine(db_column='icao', title=u'ICAO-код аэропорта', min_length=4, max_length=4, required=False)
    names = MLNames(db_column='names', title=u'Название аэропорта', required=True)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    vocab_city_id = Int(db_column='vocab_city_id', title=u'ID Города в справочниках', required=True)
    has_afl_flights = Bool(db_column='has_afl_flights', title=u'Сюда летает Аэрофлот', required=False)


class IWorldRegion(Interface):
    u"""Регион мира"""
    world_region_id = Int(db_column='world_region_id', primary_key=True, required=True, readonly=True)
    names = MLNames(db_column='names', title=u'Название региона', required=True)


class ICountry(Interface):
    u"""Страна"""

    country = UppercaseTextLine(db_column='country', title=u'2-значный код ISO',
                                primary_key=True, required=True, min_length=2, max_length=2)
    iso_code3 = UppercaseTextLine(db_column='iso_code3', title=u'3-значный код ISO', required=False, min_length=3, max_length=3)
    names = MLNames(db_column='names', title=u'Название страны', required=True)
    world_region_id = Int(db_column='world_region_id', title=u'Регион мира', required=False)
    currency_code = UppercaseTextLine(db_column='currency_code', title=u'3-значный код валюты ISO', required=False, min_length=3, max_length=3)
    use_in_pos = Bool(db_column='use_in_pos', required=False, title=u'используется в AFL_POS')
    phone_code = TextLine(db_column='phone_code', title=u'Телефонный код страны')


class ICity(Interface):
    u"""Город"""

    city = UppercaseTextLine(db_column='city', title=u'Код города по IATA', min_length=3, max_length=3, required=True, primary_key=True)
    country_code = UppercaseTextLine(db_column='country', title=u'2-значный код страны', min_length=2,
                                     max_length=2, required=False)
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    can_book = Bool(db_column='can_book', title=u'Допускается бронирование', default=True, required=False)
    names = MLNames(db_column='names', title=u'Название города', required=True)
    tz = TextLine(db_column='tz', title=u'Часовой пояс', required=True, min_length=0, max_length=32)
    vocab_id = Int(db_column='vocab_id', title=u'ID Города в справочниках', required=True)


class ITown(Interface):
    u"""Населённый пункт"""

    town_id = Int(db_column='town_id', required=True, readonly=True, primary_key=True)
    country_code = UppercaseTextLine(db_column='country', title=u'2-значный код страны', min_length=2,
                                     max_length=2, required=False)
    names = MLNames(db_column='names', title=u'Название города', required=True)


class IOfficeCategory(Interface):
    u"""Категория офисов продаж"""

    office_category_id = Int(db_column='office_category_id', title=u'Id', primary_key=True, required=True)
    names = MLNames(db_column='names', title=u'Наименование категории офисов продаж', required=True)
    office_category_description = MLNames(db_column='office_category_description', title=u'Описание', required=True)
    city = Int(db_column='city', title=u'Город', required=True)


class IOfficeTravelOption(Interface):
    u"""Дорога до офиса"""

    office_travel_option_id = Int(db_column='office_travel_option_id', title=u'Id', primary_key=True, required=True)
    office_id = Int(db_column='office_id', title=u'Офис Id', required=True)
    travel_type = TextLine(db_column='travel_type', title=u'Тип офиса', min_length=0, max_length=1, required=True)
    office_travel_option_description = MLNames(db_column='office_travel_option_description', title=u'Описание', required=True)
    travel_time = Int(db_column='travel_time', title=u'Время в пути (мин)', required=False)


class IOffice(Interface):
    u"""Офисы"""
    office_id = Int(db_column='office_id', title=u'Id', primary_key=True, required=True)
    office_weight = Int(db_column='office_weight', title=u'Вес для сортировки', required=True)
    names = MLNames(db_column='names', title=u'Наименование офиса продаж', required=False)
    office_description = MLNames(db_column='office_description', title=u'Описание', required=False)
    email = TextLineList(db_column='email', title=u'E-mail', required=False, separator='|')
    fax = TextLineList(db_column='fax', title=u'Fax', required=False, separator='|')
    phone = TextLineList(db_column='phone', title=u'Телефоны', required=False, separator='|')
    lat = Float(db_column='lat', title=u'Широта', required=False)
    lon = Float(db_column='lon', title=u'Долгота', required=False)
    address = MLNames(db_column='address', title=u'Адреса', required=False)
    worktime = MLNames(db_column='worktime', title=u'Время работы', required=False)
    in_airport = Bool(db_column='in_airport', title=u'Находится в аэропорту', default=False, required=False)
    airport = UppercaseTextLine(db_column='airport', title=u'IATA-код аэропорта', min_length=3, max_length=3, required=False)
    distance_to_airport = Int(db_column='distance_to_airport', title=u'Расстояние до аэропорта', required=False)
    insurance_policy = Bool(db_column='insurance_policy', title=u'Признак продажи страховых полисов', required=False)
    noncash_booking = Bool(db_column='noncash_booking', title=u'Признак заказа счёта для безналичной оплаты бронирования', required=False)
    new_office = Bool(db_column='new_office', title=u'Признак того, что офис новый', required=False)
    office_category = Int(db_column='office_category', title=u'Категория офисов продаж', required=True)
    location_map = MLNames(db_column='location_map', title=u'Схема проезда', required=True)
    transfer_time_public = Int(db_column='transfer_time_public', title=u'Время в пути до аэропорта на общественном транспорте (мин.)', required=False)
    transfer_time_automobile = Int(db_column='transfer_time_automobile', title=u'Время в пути до аэропорта на автомобиле (мин.)', required=False)
    transfer_time_foot = Int(db_column='transfer_time_foot', title=u'Время в пути до аэропорта пешком (мин.)', required=False)
    important_info = MLNames(db_column='important_info', title=u'Важная информация', required=True)


class IAircraftType(Interface):
    aircraft_type_id = Int(db_column='aircraft_type_id', primary_key=True, required=True, readonly=True)
    ohd_code = TextLine(db_column='ohd_code', title=u'Код ОХД', required=False)
    names = MLNames(db_column='names', title=u'Название модели', required=True)
    iata = UppercaseTextLine(db_column='iata', title=u'IATA-код', min_length=2, max_length=3, required=False)
    icao = UppercaseTextLine(db_column='icao', title=u'ICAO-код', min_length=3, max_length=4, required=False)
    pax_capacity = Int(db_column='pax_capacity', title=u'Число мест', required=False)
    cargo_capacity = Int(db_column='cargo_capacity', title=u'Грузоподъемность', required=False)
    f = Int(db_column='f', title=u'Мест первого класса', required=False)
    c = Int(db_column='c', title=u'Мест бизнес-класса', required=False)
    y = Int(db_column='y', title=u'Мест эконом-класса', required=False)


class ILoyaltyProgram(Interface):
    """Программы лояльности"""
    loyalty_program_id = Int(db_column='loyalty_program_id', primary_key=True, required=True, readonly=True)
    name = TextLine(db_column='name', title=u'Программы лояльности', required=True, min_length=1, max_length=128)
    sabre_id = TextLine(db_column='sabre_id', title=u'код Sabre', min_length=2, max_length=2, required=False)
    siebel_id = TextLine(db_column='siebel_id', title=u'Идентификатор в системе Siebel', min_length=1, max_length=4, required=False)


class IProfessionalArea(Interface):
    """Род деятельности"""
    professional_area_id = Int(db_column='professional_area_id', primary_key=True, required=True, readonly=True)
    names = MLNames(db_column='names', title=u'Род деятельность')


class IEmission(Interface):
    """Выбросы CO2"""
    emission_id = Int(db_column='emission_id', primary_key=True, required=True, readonly=True)
    airport_from = UppercaseTextLine(db_column='airport_from', title=u'IATA-код аэропорта', min_length=3, max_length=3)
    airport_to = UppercaseTextLine(db_column='airport_to', title=u'IATA-код аэропорта', min_length=3, max_length=3)
    distance = Float(db_column='distance', title=u'Дистанция')
    aircraft_type = Int(db_column='aircraft_type', title=u'Тип судна')
    emission = Float(db_column='emission', title=u'Выбросы')


class ICoefficients(Interface):
    """Коэффициенты для классов обслуживания"""
    service_class = TextLine(db_column='service_class', title=u'Класс обслуживания', primary_key=True)
    coefficient = Float(db_column='coefficient', title=u'Коэффициент')


class IAdditionalInfo(Interface):
    u"""Дополнительная информация"""

    additional_info_id = Int(db_column='additional_info_id', primary_key=True, required=True, readonly=True)
    weight = Int(db_column='weight', title=u'Вес', required=True)
    created = Date(db_column='created', title=u'Дата создания', required=False, defaultFactory=date.today, format='%Y-%m-%d')
    names = MLNames(db_column='names', title=u'Сообщение', required=True)
    condition = ConditionField(db_column='condition', title=u'Условия отображения', required=True, defaultFactory=list, value_type = Dict())
    position = TextLine(db_column='position', title=u'Позиция', required=True)


class IICER(Interface):
    u"""Курсы валют по IATA, IATA Currency Exchange Rate"""
    currency1_code = UppercaseTextLine(db_column='currency1_code', title=u'ISO-код валюты 1', min_length=3, max_length=3, required=True, primary_key=True)
    currency2_code = UppercaseTextLine(db_column='currency2_code', title=u'ISO-код валюты 2', min_length=3, max_length=3, required=True, primary_key=True)
    rate = Float(db_column='rate', required=True)
    updated = Date(db_column='updated', title=u'Дата последнего обновления', required=True)


class ICurrency(Interface):
    u"""Валюты"""
    code = UppercaseTextLine(db_column='code', title=u'ISO-код валюты', min_length=3, max_length=3, required=True, primary_key=True)
    names = MLNames(db_column='names', title=u'Название валюты', required=True)
    used_in_calc = Bool(db_column='used_in_calc', required=False, title=u'используется в калькуляторе валют')
    minor_unit = Int(db_column='minor_unit', required=True, title=u'Число знаков разменной единицы')
    rounding_unit = FixedPoint(db_column='rounding_unit', required=True, title=u'Единица округления', precision=2, min=DecNumber(0.01, 2))

class ISpecialMeal(Interface):
    code = TextLine(db_column='code', primary_key=True, required=True, min_length=4, max_length=4,
                    title=u'Код специального питания')
    names = MLNames(db_column='names', title=u'Наименование специального питания', required=True)


class IAirline(Interface):
    iata = TextLine(db_column='iata', primary_key=True, required=True, min_length=2, max_length=3,
                    title=u'IATA-код')
    loyalty_program_id = Int(db_column='loyalty_program_id', title=u'Программа лояльности', required=False)
    names = MLNames(db_column='names', title=u'Название авиакомпании', required=True)
    alliance = TextLine(db_column='alliance', title=u'Альянс', required=False)


class IMealRule(Interface):
    u"""Правила выбора питания"""

    meal_rule_id = Int(db_column='meal_rule_id', title=u'ID', primary_key=True, required=True)
    date_from = Date(db_column='date_from', title=u'Дата вылета от', required=False, format='%Y-%m-%d')
    date_to = Date(db_column='date_to', title=u'Дата вылета до', required=False, format='%Y-%m-%d')
    number = TextLine(db_column='numbers', title=u'Номера рейсов', required=False)
    airline = List(db_column='airlines', title=u'Авиалинии', required=False)
    origin = List(db_column='origins', title=u'Аэропорты вылета', required=False)
    destination = List(db_column='destinations', title=u'Аэропорты прибытия', required=False)
    booking_class = List(db_column='booking_classes', title=u'Классы бронирования', required=False)
    special_meal = List(db_column='special_meal', title=u'Спецпитание', required=False)


class IMealTimelimit(Interface):
    u"""Ограничение времени выбора питания"""

    meal_timelimit_id = Int(db_column='meal_timelimit_id', primary_key=True, required=True, readonly=True)
    origin = List(db_column='origin', title=u'Аэропорты вылета', required=False)
    special_meal = List(db_column='special_meal', title=u'Спецпитание', required=False)
    timelimit = Int(db_column='timelimit', title=u'Часы до вылета', required=True, min=0)

class ICharityFund(Interface):
    u"""Благотворительные фонды"""

    charity_fund_id = Int(db_column='charity_funds_id', title=u'ID', primary_key=True, required=True)
    charity_id = LoyaltyIdField(db_column='charity_id', title=u'Номер в системе лояльности', required=True)
    names = MLNames(db_column='names', title=u'Название фонда', required=True)
    logo_url = MLNames(db_column='logo_url', title=u'Ссылка на логотип', required=True)
    image_url = MLNames(db_column='image_url', title=u'Ссылка на изображение', required=False)
    charity_short_description = MLNames(db_column='charity_short_description', title=u'Краткое описание фонда', required=True)
    charity_description = MLText(db_column='charity_description', title=u'Описание фонда', required=True)
    url = MLNames(db_column='url', title=u'Ссылка на сайт фонда', required=True)
    transfer_conditions = MLText(db_column='transfer_conditions', title=u'Условия перевода', required=True)
    contacts = MLText(db_column='contacts', title=u'Контакты', required=False)
    news_url = MLNames(db_column='news_url', title=u'Ссылка «Новости фонда» на ОС', required=False)
    news_mv_url = MLNames(db_column='news_mv_url', title=u'Ссылка «Новости фонда» на МС', required=False)
    donate_miles_url = TextLine(db_column='donate_miles_url', title=u'Ссылка «Пожертвовать мили» на ОС', required=True)
    donate_miles_mv_url = TextLine(db_column='donate_miles_mv_url', title=u'Ссылка «Пожертвовать мили» на МС', required=True)
    stats_charity_funds_url = TextLine(db_column='stats_charity_funds_url', title=u'Ссылка на файл «Статистика фонда»', required=True)
    rss_url = TextLine(db_column='rss_url', title=u'RSS-сервис новостей фонда', required=False)
    status = TextLine(db_column='status', title=u'Статус партнёра', min_length=0, max_length=1, required=True)
    weight = TextLine(db_column='weight', title=u'Вес', required=True)
    create_date = Date(db_column='create_date', title=u'Дата создания', required=False, defaultFactory=date.today, format='%Y-%m-%d')
    modify_date = Date(db_column='modify_date', title=u'Дата изменения', required=False, defaultFactory=date.today, format='%Y-%m-%d')

class IBluetoothBeacon(Interface):
    u"""iBeacon (bluetooth маячок)"""
    unique_id = Int(db_column='unique_id', title=u'Числовой ID маячка', primary_key=True, required=True, readonly=True)
    device_id = TextLine(db_column='device_id', title=u'Стоковый ID маячка', required=False, max_length=20)
    beacon_description = MLNames(db_column='description', title=u'Описание маячка', required=True)
    message = MLNames(db_column='message', title=u'Сообщение, связанное с маячком', required=True)
    message_type = TextLine(db_column='message_type', title=u'Тип сообщения', required=True, max_length=100)
    location_latitude = Float(db_column='location_lat', title=u'Широта местоположения', required=False)
    location_longitude = Float(db_column='location_lon', title=u'Долгота местоположения', required=False)
    device_major = Int(db_column='device_major', title=u'Старшая часть номера устройства', required=True)
    device_minor = Int(db_column='device_minor', title=u'Младшая часть номера устройства', required=True)
    manufacturer_guid = TextLine(db_column='manufacturer_guid', title=u'Идентификатор производителя устройства', required=True, min_length=32, max_length=32)
    scheme_android = TextLine(db_column='scheme_android', title=u'Deeplink для приложения Android', required=False, max_length=200)
    scheme_ios = TextLine(db_column='scheme_ios', title=u'Deeplink для приложения iOS', required=False, max_length=200)
    scheme_winphone = TextLine(db_column='scheme_winphone', title=u'Deeplink для приложения WinPhone', required=False, max_length=200)
