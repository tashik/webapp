# -*- coding: utf-8 -*-

"""
$Id: $
"""


from zope.interface.declarations import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable

from models.interfaces import IAircraftType
from models.ml import MLTitleCapable
from models.base import WSVocabularyBase

class AircraftType(ActiveRecord, MLTitleCapable):
    u"""Тип воздушного судна"""

    implements(IAircraftType)
    p_table_name = 'aircraft_types'

class AircraftTypesVocabulary(WSVocabularyBase):
    objectC = AircraftType
    makeVocabularyRegisterable('aircraft_types')
