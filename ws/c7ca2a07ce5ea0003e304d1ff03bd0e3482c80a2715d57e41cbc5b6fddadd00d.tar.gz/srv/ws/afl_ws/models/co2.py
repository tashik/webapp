# -*- coding: utf-8 -*-
from pyramid.ormlite import ActiveRecord, dbquery
from pyramid.registry import makeVocabularyRegisterable
from zope.interface import implements
from models.base import WSVocabularyBase
from models.interfaces import IEmission, ICoefficients
from models.ml import MLTitleCapable


class Emission(ActiveRecord, MLTitleCapable):
    """Выбросы"""
    implements(IEmission)
    p_table_name = 'co2_emission'


class Coefficients(ActiveRecord, MLTitleCapable):
    """Коэффициенты классов обслуживания"""
    implements(ICoefficients)
    p_table_name = 'co2_coefficients'


class EmissionVocabulary(WSVocabularyBase):
    objectC = Emission
    makeVocabularyRegisterable('emission')

    def vocab_reload(self):
        objects = self.objectC.bulkLoadList(dbquery('select * from %s' % self.objectC.p_table_name))
        self.replace_all(objects)
    _reload = vocab_reload


class CoefficientsVocabulary(WSVocabularyBase):
    objectC = Coefficients
    makeVocabularyRegisterable('coefficients')

    def vocab_reload(self):
        objects = self.objectC.bulkLoadList(dbquery('select * from %s' % self.objectC.p_table_name))
        self.replace_all(objects)
    _reload = vocab_reload


