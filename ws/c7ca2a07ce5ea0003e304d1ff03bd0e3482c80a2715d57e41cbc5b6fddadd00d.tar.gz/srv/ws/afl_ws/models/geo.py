# -*- coding: utf-8 -*-

"""
$Id: $
"""
from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable, makeIndexerRegisterable
from pyramid.vocabulary.indexer import VocabularyIndexer

from models.interfaces import (
    IWorldRegion, ICountry, ICity, ITown, IICER, ICurrency
)
from models.ml import MLTitleCapable
from models.base import WSVocabularyBase

from StringIO import StringIO
import config
import csv
import datetime
import urllib2
import psycopg2
import pysftp
import zipfile

class WorldRegion(ActiveRecord, MLTitleCapable):
    u"""Регион мира"""

    implements(IWorldRegion)
    p_table_name = 'world_regions'


class WorldRegionsVocabulary(WSVocabularyBase):
    objectC = WorldRegion
    makeVocabularyRegisterable('world_regions')


class Country(ActiveRecord, MLTitleCapable):
    u"""Страна"""

    implements(ICountry)
    p_table_name = 'countries'


class CountriesVocabulary(WSVocabularyBase):
    objectC = Country
    makeVocabularyRegisterable('countries')


class CountriesByUseInPOSIndexer(VocabularyIndexer):
    vocabulary = 'countries'

    def objectIndex(self, ob):
        return ob.use_in_pos

    def contextIndex(self, use_in_pos):
        return use_in_pos

    makeIndexerRegisterable('countries_by_use_in_pos_idx')


class City(ActiveRecord, MLTitleCapable):
    u"""Город"""

    implements(ICity)
    p_table_name = 'cities'


class CitiesVocabulary(WSVocabularyBase):
    objectC = City
    makeVocabularyRegisterable('cities')


class CitiesByVocabIDIndexer(VocabularyIndexer):
    vocabulary = 'cities'

    def objectIndex(self, ob):
        return ob.vocab_id

    def contextIndex(self, vocab_id):
        return vocab_id

    makeIndexerRegisterable('cities_by_vocab_id_idx')


class Town(ActiveRecord, MLTitleCapable):
    u"""Населённый пункт"""

    implements(ITown)
    p_table_name = 'towns'


class TownsVocabulary(WSVocabularyBase):
    objectC = Town
    makeVocabularyRegisterable('towns')


class ICER(ActiveRecord):
    u"""Курсы валют по IATA, IATA Currency Exchange Rate"""

    implements(IICER)
    p_table_name = 'icer'


class ICERVocabulary(WSVocabularyBase):
    objectC = ICER
    makeVocabularyRegisterable('icer')

    def open_icer_file(self):
        cnopts = pysftp.CnOpts()
        cnopts.hostkeys = None
        c = pysftp.Connection(
            config.ICER_SFTP_HOST,
            port=config.ICER_SFTP_PORT,
            username=config.ICER_SFTP_USERNAME,
            password=config.ICER_SFTP_PASSWORD,
            cnopts=cnopts
        )
        max_dt = None
        last_fname = None
        for name in c.listdir():
            m = config.ICER_FILE_NAME_RE.match(name)
            if not m:
                continue
            dts = m.group(1)
            # 20160831_041710_2343
            dt = datetime.datetime.strptime(dts.rsplit("_", 1)[0], "%Y%m%d_%H%M%S")
            if max_dt is None or max_dt < dt:
                max_dt = dt
                last_fname = name
        zipfile_handle = c.open(last_fname)
        s = zipfile_handle.read()
        io = StringIO(s)
        contents = zipfile.ZipFile(io)
        name = next(n for n in contents.namelist() if n.endswith(".csv"))
        return c, zipfile_handle, contents.open(name)

    def reloadICER(self):
        c, zipfile_handle, icer_csv = self.open_icer_file()
        reader = csv.reader(icer_csv)
        header = reader.next()
        obs = [] 
        for cur1, cur2, dt, rt in reader:
            dt = datetime.datetime.strptime(
                dt, '%d/%m/%Y'
            ).date()
            rt = float(rt)
            ob = ICER(
                currency1_code=cur1,
                currency2_code=cur2,
                rate=rt,
                updated=datetime.datetime.now().date()
            )
            if((cur1, cur2) in self):
                self.update([ob])
            else:
                self.add(ob)
            obs.append(ob)
        con = psycopg2.connect(config.POSTGRES_DSN)
        c = con.cursor()
        c.execute("DELETE FROM icer")
        c.copy_from(
            StringIO(
                "\n".join(
                    "%s\t%s\t%s\t%s" % (
                        ob.currency1_code,
                        ob.currency2_code,
                        ob.rate,
                        ob.updated.isoformat()
                    ) for ob in obs
                )
            ), "icer"
        )
        con.commit()


class Currency(ActiveRecord):
    u"""Валюты"""

    implements(ICurrency)
    p_table_name = 'currencies'


class CurrencyVocabulary(WSVocabularyBase):
    objectC = Currency
    makeVocabularyRegisterable('currencies')


class CurrencyByUsedInCalcIndexer(VocabularyIndexer):
    vocabulary = 'currencies'

    def objectIndex(self, ob):
        return ob.used_in_calc

    def contextIndex(self, used_in_calc):
        return used_in_calc

    makeIndexerRegisterable('currencies_by_used_in_calc_idx')
