# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements
from pyramid.ormlite.record import ActiveRecord
from models.interfaces import ICharityFund
from models.ml import MLTitleCapable
from models.base import WSVocabularyBase


from pyramid.registry import makeVocabularyRegisterable


class CharityFund(ActiveRecord, MLTitleCapable):
    u"""Партнёр Благотворительный фонд"""

    implements(ICharityFund)
    p_table_name = 'charity_funds'


class CharityFundVocabulary(WSVocabularyBase):
    objectC = CharityFund
    makeVocabularyRegisterable('charity_funds')