# -*- coding: utf-8 -*-

"""
$Id: ibeacon.py 35215 2018-07-21 11:29:36Z apinsky $
"""

from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable

from models.base import WSVocabularyBase
from models.interfaces import IBluetoothBeacon


class BluetoothBeacon(ActiveRecord):
    u"""iBeacon (bluetooth маячок)"""

    implements(IBluetoothBeacon)
    p_table_name = 'ibeacons'


class BluetoothBeaconsVocabulary(WSVocabularyBase):
    objectC = BluetoothBeacon
    makeVocabularyRegisterable('ibeacons')
