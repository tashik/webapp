# -*- coding: utf-8 -*-

import logging
import os
import subprocess
import time

import config


def get_svnversion():
    try:
        return subprocess.check_output(['svnversion', config.APPDIR]).strip()
    except Exception as e:
        logging.exception('Error invoking svnversion command: %r' % e)
        return 'unknown'


def fake_app_version():
    svn_rev = get_svnversion()
    return '%s-%s' % (svn_rev, time.strftime('%Y%m%d%H%M%S'))


# переменная окружения app_version передается при сборке в образ docker
# если она отсутствует (при запуске разработчиком локально), составляем версию из svnversion+timestamp
APP_VERSION = os.environ.get('app_version') or fake_app_version()
APP_START_TIME = time.time()
