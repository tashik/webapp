# -*- coding: utf-8 -*-
"""
$Id$
"""
from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable
from models.interfaces import IMealRule, IMealTimelimit, ISpecialMeal
from models.base import WSVocabularyBase


class MealRule(ActiveRecord):
    u"""Правила выбора питания"""
    implements(IMealRule)
    p_table_name = 'meal_rules'


class MealRulesVocabulary(WSVocabularyBase):
    objectC = MealRule
    makeVocabularyRegisterable('meal_rules')


class MealTimelimit(ActiveRecord):
    u"""Ограничение времени выбора питания"""
    implements(IMealTimelimit)
    p_table_name = 'meal_timelimits'


class MealTimelimitsVocabulary(WSVocabularyBase):
    objectC = MealTimelimit
    makeVocabularyRegisterable('meal_timelimits')

