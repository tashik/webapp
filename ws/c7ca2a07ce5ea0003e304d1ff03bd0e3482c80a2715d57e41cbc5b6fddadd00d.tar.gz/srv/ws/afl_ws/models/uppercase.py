# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements
from zope.schema.interfaces import ITextLine
from pyramid.ormlite.schema import TextLine

class IUppercaseTextLine(ITextLine):
    pass

class UppercaseTextLine(TextLine):
    implements(IUppercaseTextLine)
    def _toType(self, value):
        if value is not None and value is not self.missing_value:
            return unicode(value).upper()
        return value
