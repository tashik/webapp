# -*- coding: utf-8 -*-

"""
$Id: $
"""
from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable
from pyramid.ormlite.vocabulary.mutable import PersistentVocabulary
from pyramid.ormlite.vocabulary.rdb import RDBVocabulary
from pyramid.vocabulary import getV, getVI
from pyramid.vocabulary.base import ContextVocabulary
from pyramid.vocabulary.factory import VocabularyFactory

from models.interfaces import IAirport
from models.ml import MLTitleCapable
from models.base import WSVocabularyBase


class Airport(ActiveRecord, MLTitleCapable):
    u"""Аэропорт"""

    implements(IAirport)
    p_table_name = 'airports'

    @property
    def city(self):
        try:
            ob = getVI('cities_by_vocab_id_idx')(self.vocab_city_id)[0]
        except IndexError:
            return ''

        return ob.city

class AirportsVocabulary(WSVocabularyBase):
    objectC = Airport
    makeVocabularyRegisterable('airports')
