# coding=utf-8
from pyramid.registry import makeVocabularyRegisterable

from models.base import WSVocabularyBase
from models.interfaces import ISpecialMeal
from zope.interface import implements

from pyramid.ormlite import ActiveRecord

from models.ml import MLTitleCapable


class SpecialMeal(ActiveRecord, MLTitleCapable):
    u"""Специальное питание"""
    implements(ISpecialMeal)
    p_table_name = 'vocab_special_meal'


class SpecialMealVocabulary(WSVocabularyBase):
    objectC = SpecialMeal
    makeVocabularyRegisterable('ssr_meal_codes')
