# -*- coding: utf-8 -*-

"""
$Id: $
"""

from zope.interface import implements
from zope.interface import Interface
from zope.component import provideUtility, getUtility
from zope.schema.interfaces import ITokenizedTerm
from persistent import Persistent
from persistent.mapping import PersistentMapping
from persistent.list import PersistentList
from BTrees.OOBTree import OOTreeSet

from pyramid.ormlite.vocabulary.mutable import _getCacheRoot
from pyramid.ormlite.cache import ELEM_ADDED, ELEM_DELETED, ATTR_MODIFIED
from pyramid.vocabulary import getV


class IIndexer(Interface):
    pass

def getI(name):
    factory = getUtility(IIndexer, name)
    return factory()

class Indexer(Persistent):
    implements(IIndexer)
    name = NotImplemented
    parent_vocab = None

    @classmethod
    def new(cls):
        cacheRoot = _getCacheRoot()
        cacheKey = cls.name
        try:
            indexer = cacheRoot[cacheKey]
            return indexer
        except KeyError:
            indexer = cacheRoot[cacheKey] = cls()
            if cls.parent_vocab:
                indexer._reindex()
                getV(cls.parent_vocab).p_subscribe(indexer)
            return indexer

    @classmethod
    def key(cls, ob):
        raise NotImplementedError

    def __init__(self):
        self.map = PersistentMapping()
        self.revmap = PersistentMapping()
        self.p_afterChange = PersistentList()

    def _reindex(self):
        self.map.clear()
        self.revmap.clear()
        for ob in getV(self.parent_vocab):
            token = ITokenizedTerm(ob).token
            idx = self.key(ob)
            self.map.setdefault(idx, OOTreeSet()).add(token)
            self.revmap[token] = idx

    def add(self, ob):
        token = ITokenizedTerm(ob).token
        idx = self.key(ob)
        old_idx = self.revmap.get(token)
        if old_idx is not None:
            self.map[old_idx].remove(token)
        self.map.setdefault(idx, OOTreeSet()).add(token)
        self.revmap[token] = idx

    def remove(self, ob):
        token = ITokenizedTerm(ob).token
        del self.revmap[token]
        idx = self.key(ob)
        bucket = self.map.get(idx)
        if bucket:
            bucket.remove(token)
            if not bucket:
                del self.map[idx]

    def _fmt_idx(self, token):
        return str(token)

    def __call__(self, idx):
        return self.map.get(self._fmt_idx(idx), set())

    @classmethod
    def register(cls):
        provideUtility(cls.new, IIndexer, name=cls.name)

    def p_onChange(self, event, obs, attr, value):
#        print 'p_onChange', event

        def propagateEvent(event, obs, attr=None, value=None):
            for ob in self.p_afterChange:
                ob.p_onChange(event, obs, attr, value)

        if event == ELEM_ADDED:
            for ob in obs:
                self.add(ob)
            propagateEvent(ELEM_ADDED, obs)
        elif event == ELEM_DELETED:
            for ob in obs:
                self.remove(ob)
            propagateEvent(ELEM_DELETED, obs)
        elif event == ATTR_MODIFIED:
            for ob in obs:
                self.add(ob)
            propagateEvent(ATTR_MODIFIED, obs, attr, value)
        else:
            propagateEvent(event, obs, attr, value)


    def p_subscribe(self, ob):
        self.p_afterChange.append(ob)

    def p_unsubscribe(self, ob):
        self.p_afterChange.remove(ob)
