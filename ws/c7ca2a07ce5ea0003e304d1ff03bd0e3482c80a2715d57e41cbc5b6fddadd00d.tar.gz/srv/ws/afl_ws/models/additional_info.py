# -*- coding: utf-8 -*-
"""
$Id$
"""
from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable
from models.interfaces import IAdditionalInfo
from models.ml import MLTitleCapable
from models.base import WSVocabularyBase


class AdditionalInfo(ActiveRecord, MLTitleCapable):
    u"""Дополнительная информация"""
    implements(IAdditionalInfo)
    p_table_name = 'additional_info'

    def matches(self, **kwargs):
        u"""Возвращает, подходят ли входящие параметры под условия отображения доп. информации"""
        # Перебираем возможные условия отображения
        for condition in self.condition:
            for key, value in condition.iteritems():
                if key not in kwargs or kwargs[key] != value:
                    # Параметры не подходят под это условие
                    break
            else:
                # Если параметры подходят хоть под одно условие - отображаем инфу
                return True
        # Параметры не подходят ни под одно условие
        return False


class AdditionalInfoVocabulary(WSVocabularyBase):
    objectC = AdditionalInfo
    makeVocabularyRegisterable('additional_info')
