# -*- coding: utf-8 -*-

from zope.interface import implements

from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable

from models.base import WSVocabularyBase
from models.interfaces import IProfessionalArea
from models.ml import MLTitleCapable


class ProfessionalArea(ActiveRecord, MLTitleCapable):
    u"""Род деятельности"""

    implements(IProfessionalArea)
    p_table_name = 'professional_areas'


class ProfessionalAreaVocabulary(WSVocabularyBase):
    objectC = ProfessionalArea
    makeVocabularyRegisterable('professional_areas')
