# -*- coding: utf-8 -*-


from zope.interface import implements

from pyramid.ormlite.models import TitleCapable
from pyramid.ormlite.record import ActiveRecord
from pyramid.registry import makeVocabularyRegisterable

from models.interfaces import ILoyaltyProgram
from models.base import WSVocabularyBase


class LoyaltyProgram(ActiveRecord, TitleCapable):
    u"""Программы лояльности"""

    implements(ILoyaltyProgram)
    p_table_name = 'loyalty_programs'

    @property
    def title(self):
        return u'%s' % self.name.upper()


class LoyaltyProgramVocabulary(WSVocabularyBase):
    objectC = LoyaltyProgram
    makeVocabularyRegisterable('loyalty_programs')