# -*- coding: utf-8 -*-

"""Aeroflot B2B Application registrations and initialization.

$Id: initializer.py 35220 2018-07-22 10:33:38Z apinsky $
"""
import json

import cherrypy
from zope.component import provideUtility

import pyramid.ormlite
import pyramid.model
from pyramid.app import initializer as _initializer
from pyramid.ui.page import HandlerWrapperTool, CPPageTransactionWrapper,\
    BeforeHandlerTool, CPSavedSessionHandler, CPNoCacheHandler
from pyramid.vocabulary import getV
from pyramid.registry.interfaces import IRegisterable, IRegisterableVocabulary
import pyramid.vocabulary.mvcc
import pyramid.ui.auto.adapters


import log
import services.base.static
import config



def setup_module_vocabularies(module):
    """ Регистрируем вокабы и загружаем в них данные, если требуется """
    for elem in module.__dict__.values():
        if IRegisterableVocabulary.providedBy(elem):
            elem.register()
            if hasattr(elem, 'preload'):
                getV(elem.regName).preload()
        elif IRegisterable.providedBy(elem):
            elem.register()


def init_vocabularies():
    u"""Регистрирует словари и адаптеры моделей"""
    from pyramid.registry import registerFromModule
    import transaction
    transaction.begin()

    # пирамидовские вокабы
    import pyramid.ui.auto.adapters
    registerFromModule(pyramid.ui.auto.adapters)
    import pyramid.ormlite
    registerFromModule(pyramid.ormlite)
    import pyramid.model
    registerFromModule(pyramid.model)

    # наши вокабы
    import pyramid.vocabulary.mvcc
    pyramid.vocabulary.mvcc.register()

    import models.geo
    setup_module_vocabularies(models.geo)

    import models.airport
    setup_module_vocabularies(models.airport)

    import models.ssr_meal
    setup_module_vocabularies(models.ssr_meal)

    import models.office
    setup_module_vocabularies(models.office)

    import models.air
    setup_module_vocabularies(models.air)

    import models.loyalty_program
    setup_module_vocabularies(models.loyalty_program)

    import models.professional_area
    setup_module_vocabularies(models.professional_area)

    import models.co2
    setup_module_vocabularies(models.co2)

    import models.meal
    setup_module_vocabularies(models.meal)

    import models.additional_info
    setup_module_vocabularies(models.additional_info)

    import models.airline
    setup_module_vocabularies(models.airline)

    import models.charity_funds
    setup_module_vocabularies(models.charity_funds)
    
    import models.ibeacon
    setup_module_vocabularies(models.ibeacon)

    transaction.commit()


def init_auth():
    import auth.ssods
    provideUtility(auth.ssods.SSOAuthenticationDS())
    provideUtility(auth.ssods.SSOCredentialsDS())
    provideUtility(auth.ssods.Authenticator())

def init_django():
    # Configure Django settings once, and only once.
    from django.conf import settings
    if not settings.configured:
        settings.configure()

    #from ui.common import get_current_lang
    #from django.utils.translation import activate
    #def activate_lang():
    #    activate(get_current_lang())
    #cherrypy.tools.activate_django_translation = cherrypy.Tool('on_start_resource', activate_lang,
    #                                                           priority=60)  # после tools.session (50)


def trusted_proxy(base=None, local='X-Forwarded-Host', remote='X-Forwarded-For',
                  scheme='X-Forwarded-Proto'):
    if cherrypy.request.remote.ip not in config.PROXY_IP:
        cherrypy.log('Remote address (%s) is not in config.PROXY_IP' % cherrypy.request.remote.ip)
        raise cherrypy.HTTPError(403, 'Remote address is not in PROXY_IP')

    # Удаляем из X-Forwarded-For IP-адреса, входящие в PROXY_IP
    xff = cherrypy.request.headers.get(remote)
    if xff and remote == 'X-Forwarded-For':
        xff_parts = [ip for ip in xff.split(',') if ip.strip() not in config.PROXY_IP]
        cherrypy.request.headers[remote] = ','.join(xff_parts)

    return cherrypy.lib.cptools.proxy(base=base, local=local, remote=remote, scheme=scheme)


def fix_session_cookie():
    cookie = cherrypy.response.cookie
    name = cherrypy.config.get('tools.sessions.name', 'session_id')
    if name in cookie:
        del cookie[name]['expires']
        #cookie[name]['HttpOnly'] = 1

def start_request_timer():
    import time
    cherrypy.request.start_time = time.time()


def init_cherrypy_tools():
    # pyramid tools
    cherrypy.tools.transactionwrapper = \
        HandlerWrapperTool(CPPageTransactionWrapper, priority=0)
    cherrypy.tools.savedsesstool = BeforeHandlerTool(CPSavedSessionHandler, priority=60)
    cherrypy.tools.nocachetool = BeforeHandlerTool(CPNoCacheHandler)

    # aflcab tools
    cherrypy.tools.clear_sess_cookie_expiry = \
        cherrypy.Tool('before_finalize', fix_session_cookie, priority=99)
    cherrypy.tools.request_timer = cherrypy.Tool('on_start_resource', start_request_timer, priority=0)

    from services.heartbeat import StatusMonitor
    cherrypy.tools.status = StatusMonitor()
    cherrypy.tools.trusted_proxy = cherrypy.Tool('before_request_body', trusted_proxy, priority=30)
    from ui.csrf import check_submit
    cherrypy.tools.csrf_submit_reject = cherrypy.Tool('before_request_body', check_submit, priority=90)


def init_i18n_support():
    from rx.i18n.translation import SelfTranslationDomain
    from pyramid.i18n.negotiator import LanguageAvailability, Negotiator
    from i18n_ws import CPParamsUserPreferredLanguages

    provideUtility(SelfTranslationDomain(), name='self_translate')
    provideUtility(LanguageAvailability(config.KNOWN_LANGUAGES))
    provideUtility(Negotiator())
    provideUtility(CPParamsUserPreferredLanguages())


def init_pbus():
    from rx.pbus.client import subscribe, post

    subscribe(config.PBUS_TOPICS['vocabs'])
    post(config.PBUS_TOPICS['vocabs'], json.dumps({
        "command": "get_all",
        "vocabularies": [
            "world_regions",
            "countries",
            "cities",
            "airports",
            "office_categories",
            "offices",
            "aircraft_types",
            "loyalty_programs",
            "airlines",
            "professional_areas",
            "additional_info",
            "currencies",
            "special_meal",
            "charity_funds",
            "meal_rules",
            "meal_timelimits",
            "ibeacons"
        ]
    }), recipient=config.PBUS_VOCAB_RECIPIENTS['vocabs'])


def init_error_reporting():
    from pyramid.ui.error.interfaces import IBoringError
#    zope.interface.classImplements(traverse.exc.SabreHTTPStatusError, IBoringError)
#    zope.interface.classImplements(traverse.exc.SabreInvalidAccountNumber, IBoringError)
#    zope.interface.classImplements(traverse.exc.SabreTransientConnectionError, IBoringError)

#    from ui.callcenter import ICallcenterPage, CallcenterErrorReport
#    provideAdapter(CallcenterErrorReport, [ICallcenterPage])

    from zope.interface import Interface
    from zope.component import provideAdapter
    #from services.errors import CustomLogData
    #provideAdapter(CustomLogData, [Interface])

    # обертка под ошибки XML сервисов
    from services.xml import IXMLService, XMLErrorReporter
    provideAdapter(XMLErrorReporter, [IXMLService,])

    # обертка под ошибки JSON сервисов   
    from services.base.json_base import ICommonJSONService, JSONServiceErrorReporter
    provideAdapter(JSONServiceErrorReporter, [ICommonJSONService,])


# Инициализация ----------------------------------------------------------------

def initialize():
    log.init_cherrypy_loggers()

    _initializer.initMimetypesExtensions()
    _initializer.initAuthServices()

    _initializer.initDBConnection()
    _initializer.initCache()

    init_vocabularies()

    init_i18n_support()

    services.base.static.on_server_init()

    # pyramid tools
    cherrypy.tools.transactionwrapper = \
        HandlerWrapperTool(CPPageTransactionWrapper, priority=0)
    cherrypy.tools.savedsesstool = BeforeHandlerTool(CPSavedSessionHandler, priority=60)
    cherrypy.tools.nocachetool = BeforeHandlerTool(CPNoCacheHandler)


    # В конце делаем пред-загрузку всех persistent-словарей, т.к. их
    # необходимо загружать ДО старта cherrypy-сервера, пока приложение
    # работает в единственном треде.
    _initializer.preloadVocabularies()

    init_cherrypy_tools()
    init_error_reporting()


    #init_auth()
    init_django()
    init_pbus()
