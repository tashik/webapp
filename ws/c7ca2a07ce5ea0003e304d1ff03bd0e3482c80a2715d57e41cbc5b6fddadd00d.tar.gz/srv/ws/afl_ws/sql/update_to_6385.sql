insert into _schema_revisions (revision) values (6385);

alter table offices add  in_airport boolean;
alter table offices add  insurance_policy boolean;
alter table offices add  noncash_booking boolean;
alter table offices add  new_office boolean;
alter table offices add  airport varchar(3);
alter table offices add  distance_to_airport integer;
alter table offices add  office_category integer;
alter table offices add  location_map  varchar(4096) not null;
alter table offices add  transfer_time_public  integer;
alter table offices add  transfer_time_automobile  integer;
alter table offices add  transfer_time_foot  integer;
alter table offices drop column city;