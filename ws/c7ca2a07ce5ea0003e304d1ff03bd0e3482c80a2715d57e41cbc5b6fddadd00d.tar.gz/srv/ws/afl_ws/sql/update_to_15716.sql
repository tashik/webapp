begin;

-- выбросы СО2
drop table if exists co2_emission;
drop table if exists co2_coefficients;

create table co2_emission (
  emission_id int not null PRIMARY KEY,
  airport_from varchar(3) REFERENCES airports(airport),      -- iata код аэропорта
  airport_to varchar(3) REFERENCES airports(airport),        -- iata код аэропорта
  distance decimal(8,3),
  aircraft_type int REFERENCES aircraft_types(aircraft_type_id),
  emission decimal(8,3)
);

create table co2_coefficients (
  service_class varchar PRIMARY KEY,
  coefficient decimal(3,2)
);

insert into _schema_revisions (revision) values (15716);

commit;