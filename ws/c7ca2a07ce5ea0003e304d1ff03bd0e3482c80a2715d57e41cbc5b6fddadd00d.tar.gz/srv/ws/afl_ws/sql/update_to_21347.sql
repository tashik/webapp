insert into _schema_revisions (revision) values (21347);

ALTER TABLE charity_funds RENAME COLUMN donate_miles TO donate_miles_url;
ALTER TABLE charity_funds RENAME COLUMN donate_miles_mv TO donate_miles_mv_url;
ALTER TABLE charity_funds RENAME COLUMN stats_charity_funds TO stats_charity_funds_url;