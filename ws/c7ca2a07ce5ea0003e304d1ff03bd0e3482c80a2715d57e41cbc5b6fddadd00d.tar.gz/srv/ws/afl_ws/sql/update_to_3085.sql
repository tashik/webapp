insert into _schema_revisions (revision) values (3085);
ALTER TABLE public.cities ADD tz varchar (32) NOT NULL;