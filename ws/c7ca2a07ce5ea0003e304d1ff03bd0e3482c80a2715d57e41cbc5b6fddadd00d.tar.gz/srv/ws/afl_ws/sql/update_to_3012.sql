insert into _schema_revisions (revision) values (3012);

create table tier_levels(
  tier_level varchar(16) not null primary key,
  names varchar (4096) not null
);