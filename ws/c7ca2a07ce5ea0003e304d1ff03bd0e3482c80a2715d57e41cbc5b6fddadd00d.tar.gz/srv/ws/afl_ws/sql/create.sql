-- $Id: create.sql 35222 2018-07-22 15:36:50Z apinsky $

create sequence global_seq;

create table _schema_revisions (
  revision integer not null primary key,
  applied timestamp not null default NOW()
);

INSERT INTO _schema_revisions (revision) VALUES (TO_NUMBER(REPLACE(SUBSTR('$Rev: 15424 $', 7), '$', ''), '9999999999'));

-- Аэропорт
create table airports (
  airport varchar(3) not null primary key,        -- iata код аэропорта
  icao varchar(4) unique,                         -- icao код аэропорта
  names varchar(4096) not null,                   -- наименование аэропорта
  has_afl_flights boolean not null default false, -- летает ли сюда Аэрофлот
  lat decimal(7,4),                               -- широта
  lon decimal(7,4),                               -- долгота
  vocab_city_id integer not null                  -- id города, где расположен аэропорт
);

-- Регионы мира
create table world_regions (
  world_region_id integer not null primary key,
  names varchar(4096) not null   -- языковые варианты названия объекта в формате [language1[_territory1]:name1|[language2[_territory2]:name2
);

-- Страны
create table countries (
  country char(2) not null primary key,       -- Двухзначный код страны
  iso_code3 varchar(3),                       -- см. http:--en.wikipedia.org/wiki/ISO_3166-1_alpha-3
  world_region_id integer,                    -- ID региона (части света)
  names varchar(4096) not null,               -- Наименование страны
  currency_code varchar(3),                   -- Код валюты страны
  use_in_pos boolean not null default false,  -- Используется в AFL_POS
  phone_code varchar(5)                       -- Телефонный код
);

comment on table countries is 'Страны';
comment on column countries.country is 'Двухзначный код страны';
comment on column countries.iso_code3 is 'ISO-код страны';
comment on column countries.world_region_id is 'ID региона (части света)';
comment on column countries.names is 'Название страны';
comment on column countries.currency_code is 'Код валюты';
comment on column countries.use_in_pos is 'Признак: используется в AFL_POS';
comment on column countries.phone_code is 'Телефонный код';

-- Город
create table cities (
  city varchar(3) primary key,      -- iata данные города
  country char(2) not null,         -- iso_code2 данные страны
  names varchar(4096) not null,     -- наименование города
  lat decimal(7,4),                 -- широта
  lon decimal(7,4),                 -- долгота
  can_book boolean default true,    -- разрешенно бронирование
  tz varchar(32) not null,          -- часовой пояс
  vocab_id integer not null         -- id города
);

-- Населённый пункт
create table towns(
  town_id integer not null primary key, -- первичный ключ
  country char(2) not null,             -- iso_code2 данные страны
  names varchar(4096) not null          -- наименование населённого пункта
);

--Офисы
CREATE TABLE offices(
  office_id integer not null primary key,
  names varchar(4096),
  office_description varchar(4096) not null,
  email varchar(4096) not null,
  fax varchar(4096) not null,
  phone varchar(4096) not null,
  lat decimal(7,4),
  lon decimal(7,4),
  address varchar(4096) not null,
  worktime varchar(4096) not null,
  in_airport boolean,
  insurance_policy boolean,
  noncash_booking boolean,
  new_office boolean,
  airport varchar(3),
  distance_to_airport integer,
  office_category integer not null,
  location_map  varchar(4096) not null,
  transfer_time_public  integer,
  transfer_time_automobile  integer,
  transfer_time_foot  integer,
  important_info varchar (4096) default 'ru:',
  office_weight integer not null default 50
);

-- Категории офисов продаж
create table office_categories(
  office_category_id int not null primary key,
  office_category_description text not null,
  names varchar(4096) not null,
  city integer not null
);

-- Дорога до офиса
CREATE TABLE office_travel_options(
  office_travel_option_id integer not null primary key,
  office_id integer not null,
  travel_type varchar(1) not null,
  office_travel_option_description varchar(4096) not null,
  travel_time integer
 );

-- типы судов
create table aircraft_types(
  aircraft_type_id integer not null primary key,
  ohd_code varchar(20),
  iata varchar(3),
  icao varchar(4),
  pax_capacity integer,
  cargo_capacity integer,
  f integer,
  c integer,
  y integer,
  names varchar(4096) not null
);

-- Passbook интеграция
create table passbook_cards(
  card_key varchar(256) not null primary key,
  external_card_id varchar(256),
  card_type varchar(10) CHECK (card_type in ('BONUS', 'PNR', 'BPASS')),
  data_hash varchar(256)
);

-- Программы лояльности
create table loyalty_programs (
  loyalty_program_id integer not null primary key,
  name varchar(128) not null,
  sabre_id varchar(2),
  siebel_id varchar(4)
);

-- Профессиональные области
create table professional_areas (
  professional_area_id integer not null primary key,
  names varchar(4096) not null
);

create table co2_emission (
  emission_id int not null PRIMARY KEY,
  airport_from varchar(3) REFERENCES airports(airport) ON UPDATE CASCADE ON DELETE CASCADE,      -- iata код аэропорта
  airport_to varchar(3) REFERENCES airports(airport) ON UPDATE CASCADE ON DELETE CASCADE,        -- iata код аэропорта
  distance decimal(8,3),
  aircraft_type int REFERENCES aircraft_types(aircraft_type_id) ON UPDATE CASCADE ON DELETE CASCADE,
  emission decimal(8,3)
);

create table co2_coefficients (
  service_class varchar PRIMARY KEY,
  coefficient decimal(3,2)
);

-- Дополнительная информация
create table additional_info (
  additional_info_id integer not null primary key,
  weight integer not null,                          -- вес
  created date not null,                            -- дата создания
  names text not null,                              -- названия на разных языках
  condition json not null default '[]',             -- условия отображения
  position varchar(50) not null                     -- позиция
);

-- Курсы валют по IATA, IATA Currency Exchange Rate
create table icer(
  currency1_code VARCHAR(3) NOT NULL,
  currency2_code VARCHAR(3) NOT NULL,
  rate FLOAT NOT NULL,
  updated DATE NOT NULL,
  PRIMARY KEY(currency1_code, currency2_code)
);

-- Валюты
create table currencies(
  code VARCHAR(3) NOT NULL PRIMARY KEY,
  names text not null default 'ru:',       -- названия на разных языках
  used_in_calc BOOLEAN NOT NULL,
  minor_unit INTEGER NOT NULL DEFAULT 2,
  rounding_unit DECIMAL NOT NULL DEFAULT 1
);

create table vocab_special_meal(
  code character(4) NOT NULL,
  names text NOT NULL,
  CONSTRAINT special_meal_pkey PRIMARY KEY (code)
);

create table vocab_airlines (
  iata varchar(3) primary key,
  loyalty_program_id integer,
  names varchar(200),
  alliance text
);

-- Правила заказа питания
create table meal_rules (
  meal_rule_id integer not null primary key,
  date_from date,
  date_to date,
  numbers text,
  airlines text,
  origins text,
  destinations text,
  booking_classes text,
  special_meal text
);

-- Ограничение времени выбора питания
create table meal_timelimits (
  meal_timelimit_id integer not null primary key,
  origin text,
  special_meal text,
  timelimit integer not null
);

-- создание таблицы справочника "Благотворительные фонды" (#2817)
CREATE TABLE charity_funds(
  charity_funds_id integer not null primary key,
  charity_id varchar(16) NOT NULL, -- Номер фонда в системе лояльности (charity_id)	Обязательно
  names varchar(4096) not null, -- Название фонда	Многоязычное однострочное текстовое поле	Обязательно
  logo_url text not null, -- Ссылка на логотип	Многоязычное однострочное текстовое поле	Обязательно
  image_url text default '', -- Ссылка на изображение	Многоязычное однострочное текстовое поле	Не обязательно
  charity_short_description text not null, -- Краткое описание фонда	Многоязычное однострочное текстовое поле	Обязательно
  charity_description text not null, -- Описание фонда	Многоязычное многострочное текстовое поле	Обязательно
  url text not null, --  Ссылка на сайт фонда	Многоязычное однострочное текстовое поле	Обязательно
  transfer_conditions text not null, -- Условия перевода	Многоязычное многострочное текстовое поле	Обязательно
  news_url text default '', -- Ссылка «Новости фонда» на ОС	Многоязычное однострочное текстовое поле	Нет
  news_mv_url text default '', -- Ссылка «Новости фонда» на МС	Многоязычное однострочное текстовое поле	Нет
  donate_miles_url varchar (1024) not null, -- Ссылка «Пожертвовать мили» на ОС	Однострочное поле	Да
  donate_miles_mv_url varchar (1024) not null, -- Ссылка «Пожертвовать мили» на МС	Однострочное поле	Да
  contacts text default '',
  stats_charity_funds_url varchar (1024) not null, -- Ссылка на файл «Статистика фонда»	Однострочное поле	Да
  rss_url varchar (1024) default '', -- RSS-сервис новостей фонда	Однострочное поле	Нет
  status varchar (1), -- Статус	Выбор из списка: Опубликовано/ Не опубликовано	Да	Значение по умолчанию – Не опубликовано
  weight integer not null default 0, -- Вес	Числовое	Да	Значение по умолчанию – 0
  create_date date not null, -- create	Дата и время	Да	Системное поле. Указывается дата и время создания записи фонда
  modify_date date not null -- modify	Дата и время	Да	Системное поле. Указывается дата и время изменений записи фонда
);

-- Bluetooth маячки
create table ibeacons
(
    unique_id         integer not null,
    device_id         varchar(20),
    description       text not null,
    message           text not null,
    message_type      varchar(100) not null,
    location_lat      decimal(9,6),
    location_lon      decimal(9,6),
    device_major      integer not null,
    device_minor      integer not null,
    manufacturer_guid char(32) not null,
    scheme_android    varchar(200),
    scheme_ios        varchar(200),
    scheme_winphone   varchar(200),
    constraint pk_ibeacons primary key (unique_id)
);

comment on table ibeacons is 'Данные справочника ibeacons (Bluetooth маячки)';
comment on column ibeacons.unique_id is 'Числовой ID маячка';
comment on column ibeacons.device_id is 'Стоковый ID маячка';
comment on column ibeacons.description is 'Описание маячка';
comment on column ibeacons.message is 'Сообщение, связанное с маячком';
comment on column ibeacons.message_type is 'Тип сообщения';
comment on column ibeacons.location_lat is 'Широта местоположения';
comment on column ibeacons.location_lon is 'Долгота местоположения';
comment on column ibeacons.device_major is 'Старшая часть номера устройства';
comment on column ibeacons.device_minor is 'Младшая часть номера устройства';
comment on column ibeacons.manufacturer_guid is 'Идентификатор производителя устройства';
comment on column ibeacons.scheme_android is 'Deeplink для приложения Android';
comment on column ibeacons.scheme_ios is 'Deeplink для приложения iOS';
comment on column ibeacons.scheme_winphone is 'Deeplink для приложения WinPhone';
