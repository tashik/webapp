insert into _schema_revisions (revision) values (7591);

alter table offices add  important_info  varchar(4096) default '';
