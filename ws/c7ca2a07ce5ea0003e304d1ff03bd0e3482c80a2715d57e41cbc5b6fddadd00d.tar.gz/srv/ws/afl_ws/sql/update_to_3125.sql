insert into _schema_revisions (revision) values (3125);

alter table award_miles add column vocab_id integer;
alter table combined_routes add column vocab_id integer;
alter table routes add column vocab_id integer;

update award_miles set vocab_id = 0;
update combined_routes set vocab_id = 0;
update routes set vocab_id = 0;

alter table award_miles alter column vocab_id set not null;
alter table combined_routes alter column vocab_id set not null;
alter table routes alter column vocab_id set not null;