-- $Id: drop.sql 35215 2018-07-21 11:29:36Z apinsky $

drop table _schema_revisions;
drop sequence global_seq;

drop table currencies cascade;
drop table co2_emission cascade;
drop table co2_coefficients cascade;
drop table airports;
drop table world_regions;
drop table countries;
drop table cities;
drop table towns;
drop table offices;
drop table office_categories;
drop table office_travel_options;
drop table aircraft_types;
drop table passbook_cards;
drop table professional_areas;
drop table loyalty_programs;
drop table additional_info;
drop table icer;
drop table meal_rules;
drop table meal_timelimits;
drop table vocab_special_meal;
drop table vocab_airlines;
drop table charity_funds;
drop table ibeacons;
