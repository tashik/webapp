begin;

insert into _schema_revisions (revision) values (16610);

ALTER TABLE countries ADD COLUMN currency_code varchar(3);

commit;
