insert into _schema_revisions (revision) values (3066);
-- Город
create table cities (
  city varchar(3) primary key , -- iata данные города
  country char(2) not null,     -- iso_code2 данные страны
  names varchar(4096) not null, -- наименование города
  lat decimal(7,4),             -- широта
  lon decimal(7,4),             -- долгота
  can_book boolean default true -- разрешенно бронирование
);
