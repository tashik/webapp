BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (19974);

-- Колонка "используется в AFL_POS"
ALTER TABLE countries ADD COLUMN use_in_pos boolean not null default FALSE;

COMMIT;
