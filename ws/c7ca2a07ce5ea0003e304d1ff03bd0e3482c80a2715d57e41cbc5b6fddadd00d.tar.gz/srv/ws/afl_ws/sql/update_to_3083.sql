insert into _schema_revisions (revision) values (3083);

create table combined_routes (
  airport_from varchar(3) not null, -- аэропорт вылета
  airport_via varchar(3) not null,  -- аэропорт пересадки
  airport_to varchar(3) not null,   -- аэропорт прилёта
  primary key(airport_from, airport_via, airport_to)
);