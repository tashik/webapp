-- типы судов
create table aircraft_types (
  aircraft_type_id integer not null primary key,
  ohd_code varchar(20),
  iata varchar(3),
  icao varchar(4),
  pax_capacity integer,
  cargo_capacity integer,
  f integer,
  c integer,
  y integer,
  names varchar(4096) not null
);