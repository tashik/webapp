insert into _schema_revisions (revision) values (3062);
ALTER TABLE airports ALTER COLUMN redemption_zone TYPE VARCHAR (2) USING redemption_zone::VARCHAR (2);