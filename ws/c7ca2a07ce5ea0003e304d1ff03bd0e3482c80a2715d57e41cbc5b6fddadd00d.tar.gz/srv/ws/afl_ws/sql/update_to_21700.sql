begin;
insert into _schema_revisions (revision) values (21700);

alter table currencies add column rounding_unit INTEGER NOT NULL DEFAULT 1; 

commit;
