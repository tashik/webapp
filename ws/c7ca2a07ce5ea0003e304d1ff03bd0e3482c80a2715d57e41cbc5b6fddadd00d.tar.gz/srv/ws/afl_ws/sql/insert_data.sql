-- $Id: insert_data.sql 2551 2013-09-06 09:57:40Z anovgorodov $

