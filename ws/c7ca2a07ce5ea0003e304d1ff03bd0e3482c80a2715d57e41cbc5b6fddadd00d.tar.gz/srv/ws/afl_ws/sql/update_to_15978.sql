begin;

ALTER TABLE co2_emission DROP CONSTRAINT co2_emission_airport_to_fkey;
ALTER TABLE co2_emission DROP CONSTRAINT co2_emission_airport_from_fkey;
ALTER TABLE co2_emission DROP CONSTRAINT co2_emission_aircraft_type_fkey;

ALTER TABLE co2_emission ADD CONSTRAINT co2_emission_airport_from_fkey FOREIGN KEY (airport_from) REFERENCES airports(airport) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE co2_emission ADD CONSTRAINT co2_emission_airport_to_fkey FOREIGN KEY (airport_to) REFERENCES airports(airport) ON UPDATE CASCADE ON DELETE CASCADE;
ALTER TABLE co2_emission ADD CONSTRAINT co2_emission_aircraft_type_fkey FOREIGN KEY (aircraft_type) REFERENCES aircraft_types(aircraft_type_id) ON UPDATE CASCADE ON DELETE CASCADE;

insert into _schema_revisions (revision) values (15978);

commit;