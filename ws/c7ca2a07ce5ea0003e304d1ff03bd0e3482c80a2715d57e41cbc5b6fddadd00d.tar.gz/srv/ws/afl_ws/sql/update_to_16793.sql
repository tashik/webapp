begin;

insert into _schema_revisions (revision) values (16793);

-- Правила заказа питания
create table meal_rules (
  meal_rule_id integer not null primary key,
  date_from date,
  date_to date,
  number text,
  airline text,
  origin text,
  destination text,
  booking_class text,
  special_meal text
);

commit;
