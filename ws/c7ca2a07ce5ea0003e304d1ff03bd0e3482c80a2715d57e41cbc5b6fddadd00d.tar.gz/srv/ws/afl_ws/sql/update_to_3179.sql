insert into _schema_revisions (revision) values (3179);

alter table award_miles rename to awards;