insert into _schema_revisions (revision) values (3193);

alter table tariff_group_booking_classes drop constraint tariff_group_booking_classes_tariff_group_fkey;