begin;

-- Регионы мира
create table world_regions (
  world_region_id integer not null primary key,
  names varchar(4096) not null   -- языковые варианты названия объекта в формате [language1[_territory1]:name1|[language2[_territory2]:name2
);

alter table countries add column world_region_id integer;

insert into _schema_revisions (revision) values (11940);

commit;