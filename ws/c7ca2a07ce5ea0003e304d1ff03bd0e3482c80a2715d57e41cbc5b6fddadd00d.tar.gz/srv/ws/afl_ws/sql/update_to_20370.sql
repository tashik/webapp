insert into _schema_revisions (revision) values (20370);

-- создание таблицы справочника "Благотворительные фонды" (#2817)
CREATE TABLE charity_funds(
  charity_funds_id integer not null primary key,
  charity_id varchar(16) NOT NULL, -- Номер фонда в системе лояльности (charity_id)	Обязательно
  names varchar(4096) not null, -- Название фонда	Многоязычное однострочное текстовое поле	Обязательно
  url_logo text not null, -- Ссылка на логотип	Многоязычное однострочное текстовое поле	Обязательно
  url_image text default '', -- Ссылка на изображение	Многоязычное однострочное текстовое поле	Не обязательно
  charity_short_description text not null, -- Краткое описание фонда	Многоязычное однострочное текстовое поле	Обязательно
  charity_description text not null, -- Описание фонда	Многоязычное многострочное текстовое поле	Обязательно
  url text not null, --  Ссылка на сайт фонда	Многоязычное однострочное текстовое поле	Обязательно
  transfer_conditions text not null, -- Условия перевода	Многоязычное многострочное текстовое поле	Обязательно
  url_to_news text default '', -- Ссылка «Новости фонда» на ОС	Многоязычное однострочное текстовое поле	Нет
  url_to_news_mv text default '', -- Ссылка «Новости фонда» на МС	Многоязычное однострочное текстовое поле	Нет
  donate_miles varchar (1024) not null, -- Ссылка «Пожертвовать мили» на ОС	Однострочное поле	Да
  donate_miles_mv varchar (1024) not null, -- Ссылка «Пожертвовать мили» на МС	Однострочное поле	Да
  stats_charity_funds varchar (1024) not null, -- Ссылка на файл «Статистика фонда»	Однострочное поле	Да
  rss_url varchar (1024) default '', -- RSS-сервис новостей фонда	Однострочное поле	Нет
  status varchar (1), -- Статус	Выбор из списка: Опубликовано/ Не опубликовано	Да	Значение по умолчанию – Не опубликовано
  weight integer not null default 0, -- Вес	Числовое	Да	Значение по умолчанию – 0
  create_date date not null, -- create	Дата и время	Да	Системное поле. Указывается дата и время создания записи фонда
  modify_date date not null -- modify	Дата и время	Да	Системное поле. Указывается дата и время изменений записи фонда
);