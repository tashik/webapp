begin;

insert into _schema_revisions (revision) values (35037);

ALTER TABLE countries
   ADD COLUMN phone_code varchar(5);

commit;
