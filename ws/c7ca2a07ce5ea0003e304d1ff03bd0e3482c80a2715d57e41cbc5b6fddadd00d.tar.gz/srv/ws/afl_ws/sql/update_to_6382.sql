insert into _schema_revisions (revision) values (6382);

-- Дорога до офиса
CREATE TABLE office_travel_options
(
  office_travel_option_id integer not null primary key,
  office_id integer not null,
  travel_type varchar(1) not null,
  office_travel_option_description varchar(4096) not null,
  travel_time integer
 );
