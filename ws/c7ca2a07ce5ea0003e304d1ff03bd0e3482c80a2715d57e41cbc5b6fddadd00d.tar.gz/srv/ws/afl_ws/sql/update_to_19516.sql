BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (19516);

-- Колонка количество знаков после запятой в валюте
ALTER TABLE currencies ADD COLUMN minor_unit INTEGER NOT NULL DEFAULT 2;

COMMIT;
