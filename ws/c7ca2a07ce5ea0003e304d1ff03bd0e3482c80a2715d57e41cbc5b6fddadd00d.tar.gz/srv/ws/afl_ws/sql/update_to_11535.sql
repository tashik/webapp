begin;

-- Программы лояльности
create table loyalty_programs (
  loyalty_program_id integer not null primary key,
  name varchar(128) not null
);

-- Профессиональные области
create table professional_areas (
  professional_area_id integer not null primary key,
  names varchar(4096) not null
);

commit;