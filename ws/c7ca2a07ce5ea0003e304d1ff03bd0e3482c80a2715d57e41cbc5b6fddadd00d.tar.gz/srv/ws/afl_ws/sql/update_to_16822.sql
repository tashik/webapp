begin;

insert into _schema_revisions (revision) values (16822);

-- Валюты
create table currencies(
  code VARCHAR(3) NOT NULL PRIMARY KEY,
  used_in_calc BOOLEAN NOT NULL
);

commit;
