insert into _schema_revisions (revision) values (3035);
-- Аэропорты
create table airports (
  airport_id integer not null primary key,
  iata varchar(3) unique,                        -- iata данные аэропорта
  icao varchar(4) unique,                        -- icao данные аэропорта
  city_id integer not null,                      -- id города, где расположен аэропорт
  names varchar(4096) not null,                  -- наименование аэропорта
  has_afl_flights boolean not null default false, -- летают ли самолеты аэрофлота или партнеров в данный аэропорт
  redemption_zone integer                        -- преимальная зона аэропорта
);