insert into _schema_revisions (revision) values (3124);

create table award_miles (
  zone_from varchar(2),
  zone_via varchar(2),
  zone_to varchar(2),
  alias varchar(32) not null,  
  economy_ow integer,
  economy_rt integer,
  comfort_ow integer,
  comfort_rt integer,
  business_ow integer,
  business_rt integer,
  upgrade_xo integer,
  upgrade_xf integer,
  upgrade_fo integer,
  upgrade_checkin_ow integer,
  primary key(zone_from, zone_via, zone_to)
);