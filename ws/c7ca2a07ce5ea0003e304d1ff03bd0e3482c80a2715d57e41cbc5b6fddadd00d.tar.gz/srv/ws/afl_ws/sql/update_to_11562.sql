begin;

insert into _schema_revisions (revision) values (11562);
alter table passbook_cards add column data_hash varchar(256);

commit;