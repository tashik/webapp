﻿BEGIN;

ALTER TABLE loyalty_programs ADD COLUMN sabre_id character varying(2);

CREATE TABLE vocab_airlines (
  iata varchar(3) primary key,
  loyalty_program_id integer,
  names varchar(200),
  );

INSERT INTO _schema_revisions (revision) VALUES (20365);

END;