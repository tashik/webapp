insert into _schema_revisions (revision) values (9029);

-- Passbook интеграция
create table passbook_cards(
  card_key varchar(256) not null primary key,
  external_card_id varchar(256),
  card_type varchar(10) CHECK (card_type in ('BONUS', 'PNR'))
);