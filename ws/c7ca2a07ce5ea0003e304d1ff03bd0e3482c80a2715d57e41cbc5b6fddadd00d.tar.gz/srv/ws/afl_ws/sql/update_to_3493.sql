insert into _schema_revisions (revision) values (3493);

create table towns(
  town_id integer not null primary key,
  country char(2) not null,
  names varchar(4096) not null
);