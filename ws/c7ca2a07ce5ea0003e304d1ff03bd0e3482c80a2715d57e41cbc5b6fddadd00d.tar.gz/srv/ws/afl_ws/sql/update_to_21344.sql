begin;
insert into _schema_revisions (revision) values (21343);

alter table vocab_airlines add column alliance text; 
alter table loyalty_programs add column siebel_id varchar(4); 

commit;
