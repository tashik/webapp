begin;

insert into _schema_revisions (revision) values (10031);

drop table awards;
drop table wrong_routes;
drop table pairs;
drop table redemption_zones;
drop table tariff_group_booking_classes;
drop table tariff_groups;
drop table service_classes;
drop table tier_levels;

alter table airports drop column redemption_zone;
alter table airports drop column city;

alter table airports add column vocab_city_id integer;
update airports set vocab_city_id = 0;
alter table airports alter column vocab_city_id set not null;

alter table cities add column vocab_id integer;
update cities set vocab_id = 0;
alter table cities alter column vocab_id set not null;

commit;