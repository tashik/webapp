insert into _schema_revisions (revision) values (21355);

ALTER TABLE charity_funds ADD COLUMN contacts text default '';

