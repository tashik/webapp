insert into _schema_revisions (revision) values (3690);

drop table if exists combined_routes;

-- Запрещённый маршрут
create table wrong_routes (
  city_from varchar(3) not null,    -- город вылета
  city_via varchar(3) not null,     -- город пересадки
  city_to varchar(3) not null,      -- город прилёта
  vocab_id integer not null,        -- первичный ключ в afl_vocabs
  primary key(city_from, city_via, city_to)
);