insert into _schema_revisions (revision) values (3025);

alter table tariff_groups drop constraint tariff_groups_service_class_fkey;
alter table tariff_groups alter service_class set not null;