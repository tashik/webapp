begin;

insert into _schema_revisions (revision) values (35135);

alter table additional_info add column position varchar(50);
update additional_info set position = 'flight';
alter table additional_info alter column position set not null;

commit;
