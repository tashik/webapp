insert into _schema_revisions (revision) values (3032);
-- Премиальные зоны
create table redemption_zones (
  redemption_zone varchar (2) not null primary key,  -- код премиальной зоны
  names varchar (4096) not null  -- наименование премиальной зоны
);