BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (20169);

-- названия валют на разных языках
ALTER TABLE currencies ADD COLUMN names text not null default 'ru:';

COMMIT;
