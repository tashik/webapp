insert into _schema_revisions (revision) values (7997);

alter table offices add  important_info  varchar(4096) default 'ru:';
