insert into _schema_revisions (revision) values (3063);
-- Страна
create table countries (
  country char(2) not null primary key,  -- Двухзначный код страны
  iso_code3 varchar(3),                  -- см. http:--en.wikipedia.org/wiki/ISO_3166-1_alpha-3
  names varchar(4096) not null           -- Наименование страны
);