begin;

insert into _schema_revisions (revision) values (10394);

alter table airports add column has_afl_flights boolean not null default false;

commit;
