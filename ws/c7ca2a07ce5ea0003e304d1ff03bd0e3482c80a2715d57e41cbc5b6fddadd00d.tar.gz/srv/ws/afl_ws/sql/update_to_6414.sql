﻿insert into _schema_revisions (revision) values (6414);

ALTER TABLE offices ALTER COLUMN office_category SET NOT NULL;