begin;
insert into _schema_revisions (revision) values (22346);

alter table currencies alter column rounding_unit type decimal; 

commit;
