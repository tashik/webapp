insert into _schema_revisions (revision) values (21350);

ALTER TABLE passbook_cards DROP constraint passbook_cards_card_type_check;
ALTER TABLE passbook_cards ADD constraint passbook_cards_card_type_check CHECK(card_type in ('BONUS', 'PNR', 'BPASS'));