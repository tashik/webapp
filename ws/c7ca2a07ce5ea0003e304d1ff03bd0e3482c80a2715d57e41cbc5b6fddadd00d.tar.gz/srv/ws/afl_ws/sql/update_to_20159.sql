BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (20159);

CREATE TABLE vocab_special_meal
(
  code character(4) NOT NULL,
  names text NOT NULL,
  CONSTRAINT special_meal_pkey PRIMARY KEY (code)
);

COMMIT;