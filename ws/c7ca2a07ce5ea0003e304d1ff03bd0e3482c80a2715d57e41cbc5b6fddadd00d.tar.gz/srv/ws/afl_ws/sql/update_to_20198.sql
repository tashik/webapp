BEGIN;

INSERT INTO _schema_revisions (revision) VALUES (20198);

-- Снятие ограничения длины поля описания категорий офисов
ALTER TABLE office_categories ALTER COLUMN office_category_description TYPE text;

COMMIT;
