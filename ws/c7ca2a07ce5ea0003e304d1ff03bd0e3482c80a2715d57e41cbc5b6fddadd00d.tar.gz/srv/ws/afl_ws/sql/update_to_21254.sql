begin;
insert into _schema_revisions (revision) values (21254);

alter table meal_rules rename column number to numbers; 
alter table meal_rules rename column airline to airlines; 
alter table meal_rules rename column origin to origins; 
alter table meal_rules rename column destination to destinations; 
alter table meal_rules rename column booking_class to booking_classes; 

commit;
