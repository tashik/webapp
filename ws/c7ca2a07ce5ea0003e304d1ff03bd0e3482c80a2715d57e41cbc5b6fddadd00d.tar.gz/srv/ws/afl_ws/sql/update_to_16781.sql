begin;

insert into _schema_revisions (revision) values (16781);

-- Курсы валют по IATA, IATA Currency Exchange Rate
create table icer(
  currency1_code VARCHAR(3) NOT NULL,
  currency2_code VARCHAR(3) NOT NULL,
  rate FLOAT NOT NULL,
  updated DATE NOT NULL,
  PRIMARY KEY(currency1_code, currency2_code)
);

commit;
