insert into _schema_revisions (revision) values (3056);
ALTER TABLE airports DROP airport_id;
ALTER TABLE airports ADD PRIMARY KEY ( airport );
ALTER TABLE airports RENAME COLUMN iata TO airport;
ALTER TABLE airports DROP city_id;
ALTER TABLE airports ADD city VARCHAR (3) NOT NULL;