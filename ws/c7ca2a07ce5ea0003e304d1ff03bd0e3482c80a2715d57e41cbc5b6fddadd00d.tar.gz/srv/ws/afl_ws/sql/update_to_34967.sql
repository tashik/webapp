begin;

insert into _schema_revisions (revision) values (34967);

-- Bluetooth маячки
create table if not exists ibeacons
(
    unique_id         integer not null,
    device_id         varchar(20),
    description       text not null,
    message           text not null,
    message_type      varchar(100) not null,
    location_lat      decimal(9,6),
    location_lon      decimal(9,6),
    device_major      integer not null,
    device_minor      integer not null,
    manufacturer_guid char(32) not null,
    scheme_android    varchar(200),
    scheme_ios        varchar(200),
    scheme_winphone   varchar(200),
    constraint pk_ibeacons primary key (unique_id)
);

commit;
