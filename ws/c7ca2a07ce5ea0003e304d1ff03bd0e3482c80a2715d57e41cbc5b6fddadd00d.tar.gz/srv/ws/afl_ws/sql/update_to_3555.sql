insert into _schema_revisions (revision) values (3555);

drop table offices;

--Офисы
CREATE TABLE offices
(
  office_id integer not null primary key,
  city integer not null,
  office_description varchar(4096) not null,
  email varchar(4096) not null,
  fax varchar(4096) not null,
  phone varchar(4096) not null,
  lat decimal(7,4),
  lon decimal(7,4),
  address varchar(4096) not null,
  worktime varchar(4096) not null
);