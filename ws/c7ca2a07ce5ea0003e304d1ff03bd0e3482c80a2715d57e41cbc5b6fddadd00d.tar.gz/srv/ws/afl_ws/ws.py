# -*- coding: utf-8 -*-

"""AFL Public Application Starter.

$Id: ws.py 12454 2015-04-13 13:53:12Z ogambaryan $
"""

import sys
import signal
import cherrypy

def int_handler(signum, frame):
    raise KeyboardInterrupt

signal.signal(signal.SIGINT, int_handler)
signal.signal(signal.SIGTERM, int_handler)

# TODO: выпилить
class StaticRoot(object):
    pass

def main():
    if sys.platform != 'win32':
        from pyramid.utils.pidfile import PidFile
        pidfile = PidFile('ws')

    import initializer
    initializer.initialize()

    import config
    import cpconfig
    import cpdispatcher

    cpconfig.global_cfg.update({'tools.response_headers.on': True,
                                'tools.response_headers.headers': [('X-Debug', str(config.INSTANCE_ID))]})
    cherrypy.config.update(cpconfig.global_cfg)
    if '--no-autoreload' in sys.argv:
        cherrypy.config['engine.autoreload.on'] = False
    cherrypy.tree.mount(None, config=cpdispatcher.mount_cfg)
    cherrypy.tree.mount(StaticRoot(), config.VIRTUAL_BASE + '/static', config={'/': cpconfig.static_cfg})

    cherrypy.request.wsgi_environ = {}
    cherrypy.engine.start()
    cherrypy.engine.block()


if __name__ == "__main__":
    main()
