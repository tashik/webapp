# -*- coding: UTF-8 -*-
"""
$Id: __init__.py 5788 2014-08-13 16:28:31Z kmakarov $
"""

import copy
import logging

import cherrypy
import demjson
import rx.pbus.vocabulary
import transaction
from pyramid.ormlite.dbop import selectFrom
from pyramid.ui.page import CPJSONService
from pyramid.vocabulary import getV, getVI
from zope.schema.interfaces import ITokenizedTerm

import config
import decode
from models.base import WSVocabularyBase
from services.base.static import on_vocab_change


OBJECT_DECODERS = {
    'Airport': decode.decode_airport,
    'WorldRegion': decode.decode_world_region,
    'Country': decode.decode_country,
    'City': decode.decode_city,
    'Town': decode.decode_town,
    'Office': decode.decode_office,
    'OfficeCategory': decode.decode_office_category,
    'OfficeTravelOption': decode.decode_office_travel_option,
    'AircraftType': decode.decode_aircraft_type,
    'LoyaltyProgram': decode.decode_loyalty_program,
    'ProfessionalArea': decode.decode_professional_area,
    'AdditionalInfo': decode.decode_additional_info,
    'Currency': decode.decode_currency,
    'SpecialMeal': decode.decode_special_meal,
    'Airline': decode.decode_airline,
    'MealRule': decode.decode_meal_rule,
    'MealTimelimit': decode.decode_meal_timelimit,
    'CharityFund': decode.decode_charity_funds,
    'BluetoothBeacon': decode.decode_ibeacon
}

CONTAINERS = {
    'Airport': ('airports', 'airports'),
    'WorldRegion': ('world_regions', 'world_regions'),
    'Country': ('countries', 'countries'),
    'City': ('cities', 'cities'),
    'Town': ('towns', 'towns'),
    'Office': ('offices', 'offices'),
    'OfficeCategory': ('office_categories', 'office_categories'),
    'OfficeTravelOption': ('office_travel_options', 'office_travel_options'),
    'AircraftType': ('aircraft_types', 'aircraft_types'),
    'LoyaltyProgram': ('loyalty_programs', 'loyalty_programs'),
    'ProfessionalArea': ('professional_areas', 'professional_areas'),
    'AdditionalInfo': ('additional_info', 'additional_info'),
    'Currency': ('currencies', 'currencies'),
    'SpecialMeal': ('ssr_meal_codes', 'vocab_special_meal'),
    'Airline': ('airlines', 'vocab_airlines'),
    'MealRule': ('meal_rules', 'meal_rules'),
    'MealTimelimit': ('meal_timelimits', 'meal_timelimits'),
    'CharityFund': ('charity_funds', 'charity_funds'),
    'BluetoothBeacon': ('ibeacons', 'ibeacons'),
}

FLAG_TO_DELETE = -99999

INDEXERS = (
    (('City',), ('cities_by_vocab_id_idx',)),
    (('Currency',), ('currencies_by_used_in_calc_idx',)),
    (('Country',), ('countries_by_use_in_pos_idx',)),
)

def update_indexers(changes):

    for c_list, i_list in INDEXERS:
        if any([c in changes for c in c_list]):
            for i in i_list:
                getVI(i)._reindex()
                logging.debug('notify updating indexer "%s"' % i)


class NotifyService(CPJSONService):
    def _connectToDispatcher(self, dispatcher):
        dispatcher.connect('notify_vocabs', '/notify/%s' % config.PBUS_TOPICS['vocabs'], controller=self, action='index')

    def index(self, **params):
        body = cherrypy.request.body.read()
        msg_json = demjson.decode(body, encoding='utf-8')
        self.process(msg_json)
        return ''

    def copy_cities_to_towns(self, msg_json):
        # копируем данные City для обработки как Town
        for msg in msg_json:
            towns = []
            for ob in msg['objects']:
                if ob['class'] == 'City':
                    town_ob = copy.copy(ob)
                    town_ob['class'] = 'Town'
                    towns.append(town_ob)
            msg['objects'].extend(towns)
        return msg_json

    def prepare_office_travel_options(self, msg_json):
        for msg in msg_json:
            obs = []
            for ob in msg['objects']:
                if ob['class'] == 'Office':
                    if not len(ob['travel_options']):
                        obs.append({
                            'office_travel_option_id': FLAG_TO_DELETE,
                            'office_id': ob['office_id'],
                            'travel_type': u'F',
                            'office_travel_option_description': [u'ru:XXX'],
                            'travel_time': 1,
                            'class': 'OfficeTravelOption'
                        })
                    else:
                        for to_ob in ob['travel_options']:
                            c_to_ob = copy.copy(to_ob)
                            c_to_ob['office_id'] = ob['office_id']
                            c_to_ob['class'] = 'OfficeTravelOption'
                            obs.append(c_to_ob)
            msg['objects'].extend(obs)
        return msg_json

    def process(self, msg_json):
        if isinstance(msg_json, list):
            pass
        elif isinstance(msg_json, dict) and 'event' in msg_json:  # ответ на запрос (например, command get_all)
            msg_json = [msg_json, ]
        else:
            return

        msg_json = self.copy_cities_to_towns(msg_json)
        msg_json = self.prepare_office_travel_options(msg_json)

        changes = {}

        for event in rx.pbus.vocabulary.VocabularyEvent.from_json(msg_json):
            for cls_name, objects in event.decode(OBJECT_DECODERS):
                vocab_name, table_name = CONTAINERS[cls_name]
                vocab = getV(vocab_name)
                ob_cls = vocab.objectC

                ext_ids = []
                ext_tokens = []
                if 'vocab_id' in ob_cls.p_fields:
                    ext_ids = [ob.vocab_id for ob in objects]
                    if ext_ids:
                        ext_tokens = [
                            ITokenizedTerm(ob).token for ob in ob_cls.bulkLoadList(
                                selectFrom(table_name, {'vocab_id': ext_ids}))]

                if cls_name == 'OfficeTravelOption':
                    office_ids = set(ob.office_id for ob in objects)
                    ext_tokens = [ITokenizedTerm(ob).token for ob in ob_cls.bulkLoadList(
                        selectFrom(table_name, {'office_id': list(office_ids)}))]
                    ext_tokens.append(FLAG_TO_DELETE)

                if event.type == 'change':
                    # пропускаем изменение ключей, кроме случаев,
                    # когда объект содержит vocab_id присутствующий
                    # в измененых объектах
                    for i, ob in enumerate(objects):
                        if ITokenizedTerm(ob).token not in vocab and \
                                getattr(ob, 'vocab_id', None) not in ext_ids:

                            if cls_name == 'OfficeTravelOption':
                                continue

                            objects.pop(i)

                seen = set(ITokenizedTerm(ob).token for ob in objects)

                if isinstance(vocab, WSVocabularyBase):
                    vocab_changes = event.update_mvcc(
                        objects, vocab, table_name)

                else:
                    vocab_changes = event.update_vocabulary(objects, vocab)
                    for ob in objects:
                        ob.save()

                logging.debug('notify updating vocab %s - %s record(s)' % (
                    vocab_name, len(vocab_changes)))

                # удаляем объекты, имеющие vocab_id и получившие изменение ключа
                # (вместо них были созданы новые объекты)
                for t in ext_tokens:
                    if t not in seen and t in vocab:
                        vocab[t].delete()
                        del vocab[t]

                changes[cls_name] = vocab_changes

        changed_vocabs = set([CONTAINERS[ob_class][0] for ob_class in changes.keys()])
        on_vocab_change(changed_vocabs)

        current = transaction.get()
        current.addAfterCommitHook(lambda success: success and update_indexers(changes))
