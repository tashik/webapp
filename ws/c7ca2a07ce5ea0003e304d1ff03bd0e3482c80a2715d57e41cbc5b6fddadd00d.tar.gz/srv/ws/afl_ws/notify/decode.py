# -*- coding: utf-8 -*-

"""
$Id$
"""
from datetime import datetime

from pyramid.ormlite.utils import parseDate
from zope.schema import getFieldNames

from models.airport import Airport
from models.geo import Town, City, Country, WorldRegion, Currency
from models.office import Office, OfficeCategory, OfficeTravelOption
from models.air import AircraftType
from models.loyalty_program import LoyaltyProgram
from models.professional_area import ProfessionalArea
from models.additional_info import AdditionalInfo
from models.meal import MealRule, MealTimelimit
from models.interfaces import(
    IAirline
)
from models.ssr_meal import SpecialMeal
from models.airline import Airline
from models.charity_funds import CharityFund
from models.ibeacon import BluetoothBeacon
from models.meal import MealRule, MealTimelimit
from models.interfaces import(
    IAirline, ICharityFund, ICurrency
)

from DecNumber import DecNumber


def decode_aircraft_type(json_ob):
    return AircraftType(aircraft_type_id=json_ob['aircraft_type_id'],
                        ohd_code=json_ob['ohd_code'],
                        names=json_ob['names'],
                        iata=json_ob['iata'],
                        icao=json_ob['icao'],
                        pax_capacity=json_ob['pax_capacity'],
                        cargo_capacity=json_ob['cargo_capacity'],
                        f=json_ob['f'],
                        c=json_ob['c'],
                        y=json_ob['y'])


def decode_office(json_ob):
    # для полей airport и office_category преобразований не требуется:
    # в afl_vocabs для Office переопределён метод as_primitive, поэтому
    # json_ob['airport'] - это строка (не int)
    # json_ob['office_category'] - хоть и Choice(required=True), но явно
    # приводится к типу int

    return Office(office_id=json_ob['office_id'],
                  names=json_ob['names'],
                  office_description=json_ob['office_description'],
                  email=json_ob['email'],
                  fax=json_ob['fax'],
                  phone=json_ob['phone'],
                  lat=json_ob['lat'],
                  lon=json_ob['lon'],
                  address=json_ob['address'],
                  worktime=json_ob['worktime'],
                  in_airport=json_ob['in_airport'],
                  airport=json_ob['airport'],
                  distance_to_airport=json_ob['distance_to_airport'],
                  insurance_policy=json_ob['insurance_policy'],
                  noncash_booking=json_ob['noncash_booking'],
                  new_office=json_ob['new_office'],
                  office_category=json_ob['office_category'],
                  location_map=json_ob['location_map'],
                  transfer_time_public=json_ob['transfer_time_public'],
                  transfer_time_automobile=json_ob['transfer_time_automobile'],
                  transfer_time_foot=json_ob['transfer_time_foot'],
                  important_info=json_ob['important_info'],
                  office_weight=json_ob['office_weight'])


def decode_office_travel_option(json_ob):
    # для поля travel_type преобразований не требуется:
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - TextLine(required=True)

    return OfficeTravelOption(
        office_travel_option_id=json_ob['office_travel_option_id'],
        office_id=json_ob['office_id'],
        travel_type=json_ob['travel_type'],
        office_travel_option_description=json_ob['office_travel_option_description'],
        travel_time=json_ob['travel_time'])


def decode_office_category(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    city = int(json_ob['city'])

    return OfficeCategory(
        office_category_id=json_ob['office_category_id'],
        names=json_ob['names'],
        office_category_description=json_ob['office_category_description'],
        city=city)


def decode_airport(json_ob):
    # в afl_vocabs тип поля - Choice(required=True)
    # у нас - Int(required=True)
    vocab_city_id = int(json_ob['city'])

    if json_ob['iata']:
        return Airport(airport=json_ob['iata'],
                       icao=json_ob['icao'],
                       names=json_ob['names'],
                       has_afl_flights=json_ob['has_afl_flights'],
                       lat=json_ob['lat'],
                       lon=json_ob['lon'],
                       vocab_city_id=vocab_city_id)


def decode_world_region(json_ob):
    return WorldRegion(
        world_region_id=json_ob['world_region_id'],
        names=json_ob['names'],
    )


def decode_country(json_ob):
    # в afl_vocabs тип поля - Choice(required=False)
    # у нас - Int(required=False)
    try:
        world_region_id = int(json_ob['world_region'])
    except TypeError:
        world_region_id = None

    if json_ob['iso_code2']:
        return Country(
            country=json_ob['iso_code2'],
            iso_code3=json_ob['iso_code3'],
            names=json_ob['names'],
            world_region_id=world_region_id,
            currency_code=json_ob['currency'],
            use_in_pos=json_ob['use_in_pos'],
            phone_code=json_ob['telephone_code'],
        )


def decode_city(json_ob):
    if json_ob['iata']:
        return City(city=json_ob['iata'],
                    country_code=json_ob['country_code'],
                    lat=json_ob['lat'],
                    lon=json_ob['lon'],
                    can_book=json_ob['can_book'],
                    names=json_ob['names'],
                    tz=json_ob['tz'],
                    vocab_id=json_ob['city_id'])


def decode_town(json_ob):
    return Town(town_id=json_ob['city_id'],
                country_code=json_ob['country_code'],
                names=json_ob['names'])


def decode_professional_area(json_ob):
    return ProfessionalArea(
        professional_area_id=json_ob['professional_area_id'],
        names=json_ob['names'])


def decode_loyalty_program(json_ob):
    return LoyaltyProgram(loyalty_program_id=json_ob['loyalty_program_id'],
                          name=json_ob['name'],
                          sabre_id=json_ob['sabre_id'],
                          siebel_id=json_ob['siebel_id'])


def decode_additional_info(json_ob):
    return AdditionalInfo(
        additional_info_id=json_ob['additional_info_id'],
        weight=json_ob['weight'],
        created=parseDate(json_ob['created']),
        names=json_ob['names'],
        condition=json_ob['condition'],
        position=json_ob['position']
    )

def decode_charity_funds(json_ob):
    try:
        modify_date = datetime.strptime(json_ob['modify_date'], "%Y-%m-%d").date()
    except (TypeError, ValueError):
        modify_date = None
    try:
        create_date = datetime.strptime(json_ob['create_date'], "%Y-%m-%d").date()
    except (TypeError, ValueError):
        create_date = None

    return CharityFund(
        weight=json_ob['weight'],
        charity_fund_id=json_ob['charity_fund_id'],
        charity_id=json_ob['charity_id'],
        status=json_ob['status'],
        transfer_conditions=json_ob['transfer_conditions'],
        stats_charity_funds_url=json_ob['stats_charity_funds_url'],
        url=json_ob['url'],
        charity_short_description=json_ob['charity_short_description'],
        logo_url=json_ob['logo_url'],
        donate_miles_url=json_ob['donate_miles_url'],
        names=json_ob['names'],
        charity_description=json_ob['charity_description'],
        news_url=json_ob['news_url'],
        news_mv_url=json_ob['news_mv_url'],
        modify_date=modify_date,
        create_date=create_date,
        image_url=json_ob['image_url'],
        donate_miles_mv_url=json_ob['donate_miles_mv_url'],
        rss_url=json_ob['rss_url'],
        contacts=json_ob['contacts']
    )

def decode_currency(json_ob):
    return Currency(
        code=json_ob["alpha3_code"],
        used_in_calc=json_ob["used_in_calc"],
        names=json_ob['names'],
        minor_unit=json_ob["minor_unit"],
        rounding_unit=DecNumber(
            str(json_ob["rounding_unit"]),
            ICurrency._InterfaceClass__attrs["rounding_unit"].precision
        )  # rx.utils не кодирует DecNumber
    )


def decode_special_meal(d):
    code = d['code']
    return SpecialMeal(code=code, names=d['names'])


def decode_airline(d):
    if d['loyalty_program']:
        d['loyalty_program_id'] = int(d.pop('loyalty_program'))
    params = dict(
        (k, d.get(k)) for k in getFieldNames(IAirline)
    )
    return Airline(**params)


def decode_meal_rule(json_ob):
    try:
        date_from = parseDate(json_ob['date_from'])
    except (TypeError, ValueError):
        date_from = None
    try:
        date_to = parseDate(json_ob['date_to'])
    except (TypeError, ValueError):
        date_to = None
    return MealRule(
        meal_rule_id=json_ob['meal_rule_id'],
        date_from=date_from,
        date_to=date_to,
        number=json_ob['number'],
        airline=json_ob['airline'],
        origin=json_ob['origin'],
        destination=json_ob['destination'],
        booking_class=json_ob['booking_class'],
        special_meal=json_ob['special_meal'],
    )

def decode_meal_timelimit(json_ob):
    return MealTimelimit(
        meal_timelimit_id=json_ob['meal_timelimit_id'],
        origin=json_ob['origin'],
        special_meal=json_ob['special_meal'],
        timelimit=json_ob['timelimit'],
    )


def decode_ibeacon(json_ob):
    return BluetoothBeacon(
        unique_id=json_ob['unique_id'],
        device_id=json_ob['device_id'],
        beacon_description=json_ob['beacon_description'],
        message=json_ob['message'],
        message_type=json_ob['message_type'],
        location_latitude=json_ob['location_latitude'],
        location_longitude=json_ob['location_longitude'],
        device_major=json_ob['device_major'],
        device_minor=json_ob['device_minor'],
        manufacturer_guid=json_ob['manufacturer_id'],
        scheme_android=json_ob['scheme_android'],
        scheme_ios=json_ob['scheme_ios'],
        scheme_winphone=json_ob['scheme_winphone']
    )
