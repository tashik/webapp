# -*- coding: utf-8 -*-

"""Path auth"""

import string
import random

import cherrypy

import config

def digest_auth(digest_dict, realm):
    def get_ha1(req_realm, req_username):
        if req_realm == realm:
            ha1 = digest_dict.get(req_username)
            return ha1
    private_key = ''.join([random.choice(string.letters) for n in range(40)])
    digest_auth = {'tools.auth_digest.on': True,
                   'tools.auth_digest.realm': realm,
                   'tools.auth_digest.get_ha1': get_ha1,
                   'tools.auth_digest.key': private_key,
                   }
    return digest_auth

def basic_auth(username, password, realm):
    return {'tools.auth_basic.on': True,
            'tools.auth_basic.realm': realm,
            'tools.auth_basic.checkpassword': lambda r, u, p: u == username and p == password,
            }


def auth_paths():
    d = {(config.VIRTUAL_BASE + '/v.0.0.1/json/passbook'): basic_auth('ws-passbook', config.WS_PASSBOOK_PASSWORD, 'notify'),
         (config.VIRTUAL_BASE + '/services/errors'): digest_auth(config.MONITORING_WS_DIGEST, 'aeroflot-digest'),
         (config.VIRTUAL_BASE + '/v.0.0.1/csv/co2.csv'): digest_auth(config.CO2_ADMIN_WS_DIGEST, 'co2-digest'),
        }
    return d

def check_monitoring_access():
    if cherrypy.request.remote.ip not in config.MONITORING_ACCESS_IP or cherrypy.request.headers.get('X-Forwarded-For'):
        raise cherrypy.HTTPError(403, 'Forbidden')
    
