#!/bin/bash
set -eu
###############################################################################
. ./build-config.sh

echo "[..] APP_REPO = $APP_REPO"
echo "[..] APP_REV  = $APP_REV"
echo "[..] Building image $FULL_NAME"

###############################################################################
mkdir -p checkout

svn_checkout "$APP_REPO" checkout/afl_ws "$APP_REV"

# Параметры доступны при сборке в Jenkins
PIPELINE_TAG=${PIPELINE_TAG-}
BUILD_NUMBER=${BUILD_NUMBER-}

if [ -n "$PIPELINE_TAG" -a -n "$BUILD_NUMBER" ]
then
    app_version="$PIPELINE_TAG-$BUILD_NUMBER-$(date +'%Y%m%d%H%M%S')"
else
    app_version="$APP_REV-$(date +'%Y%m%d%H%M%S')"
fi

tar c --exclude .svn Dockerfile checkout files | \
    docker build -t "$FULL_NAME" -t "$APP_NAME" -t "$APP_NAME:$DOCKER_TAG" --force-rm \
        --build-arg app_version=$app_version \
        --label afl_ws_repo="$APP_REPO" \
        --label afl_ws_rev="$APP_REV" \
        --label org.label-schema.vcs-url="$APP_REPO" \
        --label org.label-schema.vcs-ref="$APP_REV-$(date +'%Y%m%d%H%M%S')" \
        -
