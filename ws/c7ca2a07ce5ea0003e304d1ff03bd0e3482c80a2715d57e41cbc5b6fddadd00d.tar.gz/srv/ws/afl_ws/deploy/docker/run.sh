#!/bin/sh

mkdir -p etc log/errors
chmod -R 777 log/

docker run --rm -ti --link ws-pg:ws-postgres -p 6380:6380 -v $PWD/etc:/srv/ws/etc -v $PWD/log:/srv/ws/log ws $@
