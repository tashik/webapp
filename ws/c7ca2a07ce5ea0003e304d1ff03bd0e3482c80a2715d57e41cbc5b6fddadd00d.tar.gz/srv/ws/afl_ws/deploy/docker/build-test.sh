#!/bin/bash
. ./build-config.sh

docker build -t $APP_NAME-test:$DOCKER_TAG -t $APP_NAME-test ws-test
