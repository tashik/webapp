#!/bin/bash

set -e

: ${PGHOST:=db}
: ${PGPORT:=5432}
: ${PGUSER:=ws}
: ${PGDATABASE:=$PGUSER}

export PGHOST PGPORT PGUSER PGDATABASE

# если конфиги отсутствуют, создаем их на основе шаблонов (файлы .tmpl)
if [ ! -e $INSTANCE_HOME/etc/config.py ]
then
  cp $INSTANCE_HOME/afl_ws/config.py.tmpl $INSTANCE_HOME/etc/config.py
  cp $INSTANCE_HOME/afl_ws/cpconfig.py.tmpl $INSTANCE_HOME/etc/cpconfig.py
  
  cat <<EOF >> $INSTANCE_HOME/etc/config.py

import os

SERVER_HOST = '0.0.0.0'

POSTGRES_DSN = """
    host=%(PGHOST)s
    port=%(PGPORT)s
    dbname=%(PGDATABASE)s
    user=%(PGUSER)s
    password=
""" % os.environ

GEOIP_DB_PATH = '/srv/ws/afl_cabinet-lib/GeoLite2-City.mmdb'

EOF

  sed -i -e "s/'tools.trusted_proxy.on'/#'tools.trusted_proxy.on'/" $INSTANCE_HOME/etc/cpconfig.py
fi


if [ ! -e $INSTANCE_HOME/etc/test_config.py ]
then
    cp $INSTANCE_HOME/afl_ws/tests/config.py.tmpl $INSTANCE_HOME/etc/test_config.py
    sed -i -e "s/POSTGRES_DSN/#POSTGRES_DSN/" $INSTANCE_HOME/etc/test_config.py
fi

mkdir -p $INSTANCE_HOME/log/errors

cd $INSTANCE_HOME/afl_ws

exec $@
