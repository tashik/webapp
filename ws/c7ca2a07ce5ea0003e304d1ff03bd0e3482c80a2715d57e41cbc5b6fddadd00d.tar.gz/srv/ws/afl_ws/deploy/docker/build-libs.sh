#!/bin/bash
set -eu
###############################################################################
. ./build-config.sh

echo "[..] WSLIB_REPO      = $WSLIB_REPO"
echo "[..] WSLIB_REV       = $WSLIB_REV"
echo "[..] AFLCABLIB_REPO  = $AFLCABLIB_REPO"
echo "[..] AFLCABLIB_REV   = $AFLCABLIB_REV"
echo "[..] PYRAMID_REPO    = $PYRAMID_REPO"
echo "[..] PYRAMID_REV     = $PYRAMID_REV"
echo "[..] PYRAMID_LIB_REPO     = $PYRAMID_LIB_REPO"
#echo "[..] PYRAMID_LIB_SRC_REPO = $PYRAMID_LIB_SRC_REPO"

###############################################################################

cd ws-libs
mkdir -p checkout
cd checkout

svn_checkout "$WSLIB_REPO" ws-lib "$WSLIB_REV"
svn_checkout "$AFLCABLIB_REPO"/lib afl_cabinet-lib "$AFLCABLIB_REV"
svn_checkout "$AFLCABLIB_REPO"/lib-src afl_cabinet-lib-src "$AFLCABLIB_REV"
svn_checkout "$PYRAMID_REPO" pyramid "$PYRAMID_REV"
svn_checkout "$PYRAMID_LIB_REPO" pyramid-lib "$PYRAMID_REV"
svn_checkout "$PYRAMID_LIB_SRC_REPO" pyramid-lib-src "$PYRAMID_REV"

cd ..

# -t ws-libs (имя без тега) нужно, так как нельзя параметризовать тег в операторе FROM в Dockerfile
tar c --exclude .svn Dockerfile checkout pydistutils.cfg | \
    docker build -t registry.com.spb.ru/ws-libs:"${WSLIB_REV}" -t ws-libs --force-rm \
                 --label ws_lib_rev="$WSLIB_REV" \
                 --label aflcab_lib_rev=$(svnversion checkout/afl_cabinet-lib) \
                 --label aflcab_lib_src_rev=$(svnversion checkout/afl_cabinet-lib-src) \
                 --label pyramid_rev="$PYRAMID_REV" \
                 --label pyramid_lib_rev=$(svnversion checkout/pyramid-lib) \
                 --label pyramid_lib_src_rev=$(svnversion checkout/pyramid-lib-src) \
                 -

#                 --label ws_lib_rev=$(svnversion checkout/ws-lib) \
#                 --label pyramid_rev=$(svnversion checkout/pyramid) \
