#!/bin/bash
### BEGIN INIT INFO
# Provides:       Postrges for AFL_WS
# Required-Start: docker
# Required-Stop:  docker app13_ws_1 app13_ws_2 app13_ws_3 app13_ws_4 app13_ws_5
# Default-Start:  2 3 4 5
# Default-Stop:   0 1 6
# Description:    Docker container Postgres for AFL_WS
### END INIT INFO

### Устанавливаемые переменные
DOCKER_IMAGE="postgres:9.3"
APP_NAME="ws"
APP_HOME="/srv/prod_${APP_NAME}"
PG_DATA="${APP_HOME}/postgres/data"
PG_PORT=25432
WAIT_STOPPING=60 # in sec
#
### Рассчитываемые переменные
CLUSTER=$(basename "$0" | grep -oE "^[0-9a-zA-Z]+")
if [[ -z $CLUSTER ]]; then
    echo "[EE] You need call executable script in format: <CLUSTER>_<APP_NAME>_postgres"
    exit 1
fi
INSTANCE_NAME="${CLUSTER}_${APP_NAME}_postgres"

# Привязка к ядру ЦП
INSTANCE_CPUS='' # default: ''
_TMP=`grep -E "^$INSTANCE_NAME=([0-9][0-9,-]*)$" /etc/docker/cpuset 2>/dev/null | head -n1 | awk -F'=' '{print $2}'`
if [ ! -z $_TMP ]; then
    INSTANCE_CPUS="--cpuset-cpus=${_TMP}"
fi

export RETVAL=0


start() {
    echo "[..] Starting: $INSTANCE_NAME --port=$PG_PORT --network=$APP_NAME $INSTANCE_CPUS ($DOCKER_IMAGE)"
    local start_time=$(date +"%Y-%m-%dT%H:%M:%S.%N")
    status
    rc=$?
    if [ $rc -eq 0 ]; then
        echo "[OK] $INSTANCE_NAME already started"
        return 0
    elif [ $rc -eq 1 ]; then
        docker run -d --name $INSTANCE_NAME \
            --ulimit nofile=65536:65536 $INSTANCE_CPUS \
            --volume="${PG_DATA}":/var/lib/postgresql/data \
            --network="${APP_NAME}" \
            -p $PG_PORT:5432 \
            --network-alias=pghost \
            --log-opt max-size=5m \
            $DOCKER_IMAGE >/dev/null
        RETVAL=$?
    else
        docker start $INSTANCE_NAME >/dev/null
        RETVAL=$?
    fi
    if [ $RETVAL -eq 0 ] && spinner 6 && status; then
        echo "[OK] $INSTANCE_NAME started"
        return $RETVAL
    else
        echo "[EE] $INSTANCE_NAME not started"
        docker logs --since=$start_time $INSTANCE_NAME
        RETVAL=1
        return $RETVAL
    fi
}


stop() {
    echo "[..] Stopping: $INSTANCE_NAME"
    docker stop "$INSTANCE_NAME" >/dev/null &
    cnt=0
    while [ $cnt -lt $WAIT_STOPPING ]; do
        if ! status; then
            echo "[OK] $INSTANCE_NAME stopped"
            #
            if [ "$1" == "-rm" ]; then
                docker rm "$INSTANCE_NAME" >/dev/null
                echo "[OK] $INSTANCE_NAME deleted"
            fi
            #
            return 0
        fi
        sleep 1
        cnt=$(( $cnt + 1 ))
        spinner
    done
    echo "[WW] $INSTANCE_NAME not stopped"
    RETVAL=1
    return $RETVAL
}


kill() {
    echo "[..] Killing: $INSTANCE_NAME"
    docker kill "$INSTANCE_NAME" >/dev/null
    RETVAL=$?
    return $RETVAL
}


status() {
    rd=`docker ps -a -f name="^/$INSTANCE_NAME\$"`
    if echo "$rd" | grep -q "Up "; then
        # running
        return 0
    elif echo "$rd" | grep -q "$INSTANCE_NAME"; then
        # other
        return 2
    else
        # does not exist
        return 1
    fi
}


entry() {
    docker exec -i -t "$INSTANCE_NAME" /bin/bash
}


info() {
    if status; then
        echo "[II] $INSTANCE_NAME started ($DOCKER_IMAGE)"
    else
        echo "[II] $INSTANCE_NAME stopped ($DOCKER_IMAGE)"
    fi
}


_SPINNER_CHR='/-\/'
_SPINNER_POS=0
spinner() {
    _SPINER_CNT=0
    _SPINER_MAX=${1:-1}
    while true; do
        _SPINNER_POS=$(( ($_SPINNER_POS + 1) %4 ))
        echo -ne "${_SPINNER_CHR:$_SPINNER_POS:1}" "\r"
        _SPINER_CNT=$(( $_SPINER_CNT + 1 ))
        [ $_SPINER_CNT -lt $_SPINER_MAX ] || break
        sleep 1
    done
    return 0
}


case "$1" in
    start)
        start
        ;;
    stop)
        stop "$2"
        ;;
    restart)
        stop "$2" && { sleep 1;  start; }
        ;;
    kill)
        kill
        ;;
    status)
        status && exit 0 || exit $?
        ;;
    entry)
        entry
        ;;
    info)
        info
        ;;
    *)
        echo "Usage: ${0##*/} {start|(stop|restart) [-rm]|kill|status|entry|info}"
        RETVAL=1
esac

exit $RETVAL
