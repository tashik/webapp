#!/bin/bash
set -eu
###############################################################################
# !!! Слешом директории не закрывать
CONFIG_REPO="https://svn.com.spb.ru/afl_site/afl_ws/docker/etc"
APP_NAME="ws"
APP_UID=2015
APP_HOME=${1:-$(cd `dirname "${BASH_SOURCE[0]}"`/../.. && pwd)}
INSTANCE_NUMBER=${2:-}
CLUSTER=${3:-}

###############################################################################
### APP HOME
while true; do
    if [ ! -d "$APP_HOME" ]; then
        if [ "$APP_HOME" != 'None' ]; then
            echo "[EE] Cannot access '$APP_HOME'"
        fi
        read -p "Enter APP HOME direcotry:" APP_HOME
    else
        APP_CONF="$APP_HOME/etc"
        echo "[..] APP_NAME=$APP_NAME"
        echo "[..] APP_HOME=$APP_HOME"
        echo "[..] APP_CONF=$APP_CONF"
        read -p "Confirm [Y=YES, any=NO]:" -n 1 CONFIRM
        echo
        if [ "$CONFIRM" == "Y" ]; then
            break
        else
            APP_HOME='None'
        fi
    fi
done

mkdir -p  "$APP_HOME/postgres/data"
chmod 750 "$APP_HOME"


### DOCKER
which docker >/dev/null || { echo "[EE] Docker not installed"; exit 1; }


### INSTANCE_UID
DOCKREMAP_UID=`cat /etc/subuid | grep dockremap | cut -d':' -f2`
if [ -z "$DOCKREMAP_UID" ] || ! echo "$DOCKREMAP_UID" | grep -iqE "^[0-9]+$"; then
    echo "[EE] Incorrect DOCKREMAP_UID"
    exit 1
fi
# Уникальный UID для проекта в докере
INSTANCE_UID=$(( $DOCKREMAP_UID + $APP_UID ))
echo "[..] INSTANCE_UID=$INSTANCE_UID"

DOCKREMAP_GID=`cat /etc/subgid | grep dockremap | cut -d':' -f2`
if [ -z "$DOCKREMAP_GID" ] || ! echo "$DOCKREMAP_GID" | grep -iqE "^[0-9]+$"; then
    echo "[EE] Incorrect DOCKREMAP_GID"
    exit 1
fi
# Уникальный GID для проекта в докере
INSTANCE_GID=$(( $DOCKREMAP_GID + $APP_UID ))
echo "[..] INSTANCE_GID=$INSTANCE_GID"

chown $INSTANCE_UID:$INSTANCE_GID "$APP_HOME"

### Postgres data
# WARNING: Postgres Docker при запуске сам установит права, но только если папка с UID > dockremap.
if [ "$(stat -c '%a' $APP_HOME/postgres/data)" != "700" ]; then
    chmod 777 "$APP_HOME/postgres/data"
    chown $INSTANCE_UID:$INSTANCE_GID "$APP_HOME/postgres/data"  # Что бы не закрыть доступ к уже работающему процессу, сперва выполняется chmod 777
fi

echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
### SVN
if [ -d "$APP_CONF" ]; then
    svn sw "$CONFIG_REPO" "$APP_CONF"
else
    svn co "$CONFIG_REPO" "$APP_CONF"
fi


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
### CLUSTER
CLUSTER_INF_FILE="$APP_HOME/.cluster"
if [ -f "$CLUSTER_INF_FILE" ]; then
    # auto detect
    CLUSTER=$(head -n1 "$CLUSTER_INF_FILE")
    echo "[..] DETECT CLUSTER=$CLUSTER"
else
    if [ -z "$CLUSTER" ]; then
        # set manually
        cd "$APP_CONF/cluster"
        ls -lh *py | awk '{print "*",$9}' | sed 's/\.py//g'
        read -p "Enter cluster name:" CLUSTER
    else
        # argument set
        echo "[..] CLUSTER=$CLUSTER"
    fi
fi

CONFIG_CLUSTER="cluster/$CLUSTER.py"
CONFIG_SYMLINK="config.py"
cd "$APP_CONF"
if [ ! -f "$CONFIG_CLUSTER" ]; then
    echo "[EE] Not found cluster config '$CONFIG_CLUSTER'"
    exit 1
elif [ ! -e "$CONFIG_SYMLINK" ]; then
    ln -s "$CONFIG_CLUSTER" "$CONFIG_SYMLINK"
    echo "[OK] Created CONFIG_SYMLINK='$CONFIG_SYMLINK'"
else
    echo "[WW] Already exist '$CONFIG_SYMLINK'"
fi


CONFIG_PASSWD="passwd.py"
cd "$APP_CONF"
if [ ! -f "$CONFIG_PASSWD" ]; then
    cp passwd.py.example "$CONFIG_PASSWD"
fi
chmod 600 "$CONFIG_PASSWD"
chown $INSTANCE_UID:$INSTANCE_GID "$CONFIG_PASSWD"



echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
### INSTANCE
if [ -z "$INSTANCE_NUMBER" ]; then
    cd "$APP_HOME"
    ls -lh | awk '/'"$APP_NAME"'[0-9]/ {print "*",$9}'
    read -p "Enter INSTANCE_NUMBER:" INSTANCE_NUMBER
else
    echo "[..] INSTANCE_NUMBER=$INSTANCE_NUMBER"
fi
if ! echo "$INSTANCE_NUMBER" | grep -iqE "^[0-9]+$"; then
    echo "[EE] Incorrect INSTANCE_NUMBER"
    exit 1
fi

INSTANCE_HOME="$APP_HOME/$APP_NAME$INSTANCE_NUMBER"
echo "[..] INSTANCE_HOME=$INSTANCE_HOME"

if [ -d "$INSTANCE_HOME" ]; then
    echo "[WW] Already exist $INSTANCE_HOME"
fi

mkdir -p "$INSTANCE_HOME/log"
chown -R $INSTANCE_UID:$INSTANCE_GID "$INSTANCE_HOME"


### INIT.D
INITD_SRC="$APP_CONF/scripts/init.$CLUSTER.sh"
INITD_TRG="/etc/init.d/${CLUSTER}_${APP_NAME}_${INSTANCE_NUMBER}"
if [ ! -f "$INITD_SRC" ]; then
    echo "[EE] INIT.D src not found '$INITD_SRC'"
    exit 1
elif [ ! -e "$INITD_TRG" ]; then
    cp "$INITD_SRC" "$INITD_TRG"
    echo "[OK] INIT.D created $INITD_TRG"
else
    echo "[WW] INIT.D already exist $INITD_TRG"
fi

### CLUSTER
if [ ! -f "$CLUSTER_INF_FILE" ]; then
    # save cluster info in end
    echo "$CLUSTER" > "$CLUSTER_INF_FILE"
    echo "[OK] CLUSTER INFO SAVED '$CLUSTER_INF_FILE'"
fi


### POSTGRE INIT.D
PG_INITD_SRC="$APP_CONF/scripts/init.${CLUSTER}_postgres.sh"
PG_INITD_TRG="/etc/init.d/${CLUSTER}_${APP_NAME}_postgres"
if [ ! -f "$PG_INITD_SRC" ]; then
    echo "[EE] Postgres INIT.D src not found '$PG_INITD_SRC'"
    exit 1
elif [ ! -e "$PG_INITD_TRG" ]; then
    cp "$PG_INITD_SRC" "$PG_INITD_TRG"
    echo "[OK] Postgres INIT.D created $PG_INITD_TRG"
else
    echo "[WW] Postgres INIT.D already exist $PG_INITD_TRG"
fi

### CLUSTER
if [ ! -f "$CLUSTER_INF_FILE" ]; then
    # save cluster info in end
    echo "$CLUSTER" > "$CLUSTER_INF_FILE"
    echo "[OK] CLUSTER INFO SAVED '$CLUSTER_INF_FILE'"
fi


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
### DOCKER IMAGE
DOCKER_IMAGE=`grep "DOCKER_IMAGE=" $INITD_SRC | head -n1 | cut -d'=' -f2 | tr -d "\"" | tr -d "'" | tr -d " "`
if [ -z "$DOCKER_IMAGE" ]; then
    echo "[EE] Not found DOCKER_IMAGE in INIT.D script '$INITD_SRC'"
    exit 1
fi
echo "[..] Update DOCKER_IMAGE=$DOCKER_IMAGE"

set +e
docker login  "$DOCKER_IMAGE"
docker pull   "$DOCKER_IMAGE"
docker logout "$DOCKER_IMAGE"
set -e


echo "-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"
### Done
echo "[OK] Done!"
