#!/bin/bash
set -u
###############################################################################
RUN_UNDER="docker_ws"

WS_1ST_PORT="6581"
WS_ETC_PORT="6582"

###############################################################################
export RETVAL=0

# Проверка пользователя
if [ "$LOGNAME" != "$RUN_UNDER" ]; then
  echo "Must be run under '$RUN_UNDER' user"
  exit 1
fi

# Скачиваем и обновляем данные в БД через первый инстанса
echo ''
echo "$(date '+%Y-%m-%d %H:%M:%S') [..] Updating ICER (1st PORT=$WS_1ST_PORT) ..."
URL="http://127.0.0.1:${WS_1ST_PORT}/ws2/v.0.0.1/json/icer/RUB?prices=%5B%7B%22currency%22%3A+%22EUR%22%2C+%22price%22%3A+8179.022839301929%7D%5D&reload=1"
echo "${URL}"
OUTPUT=$(curl -sS -i --max-time 600 --write-out "\n%{http_code}" "${URL}")
RC=$?
echo "${OUTPUT}" | head -n -1
if [[ $RC -ne 0 || $(echo "${OUTPUT}" | tail -n1) -ne 200 ]]; then
  echo "$(date '+%Y-%m-%d %H:%M:%S') [EE] Update failed"
  # NOTE: Прерываем дальнейшую работу
  exit $RC
fi
echo "$(date '+%Y-%m-%d %H:%M:%S') [OK] Updated"
sleep 3

for PORT in ${WS_ETC_PORT}; do
  echo ''
  echo "$(date '+%Y-%m-%d %H:%M:%S') [..] Reloading ICER (PORT=${PORT}) ..."
  URL="http://127.0.0.1:${PORT}/ws2/reload_icer_vocab_from_db"
  echo "${URL}"
  OUTPUT=$(curl -sS -i --max-time 600 --write-out "\n%{http_code}" "${URL}")
  RC=$?
  echo "${OUTPUT}" | head -n -1
  if [[ $RC -ne 0 || $(echo "${OUTPUT}" | tail -n1) -ne 200 ]]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') [EE] Reload failed"
    # NOTE: Не прерываем цикл
    RETVAL=$RC
  else
    echo "$(date '+%Y-%m-%d %H:%M:%S') [OK] Reloaded"
  fi
  sleep 3
done

exit $RETVAL
