# -*- coding: utf-8 -*-

"""CherryPy Global Configuration."""

import config


# CherryPy Global Configuration -------------------------------------
global_cfg = {
    'tools.decode.on': True,
    'tools.encode.on': True,
    'tools.encode.encoding': config.ENCODING,
    'tools.decode.encoding': config.ENCODING,
    'log.screen': True,  # Use 'False' for production mode
    'server.socket_port': config.SERVER_PORT,
    'server.socket_host': config.SERVER_HOST,
    'server.thread_pool': 8,  # Use >0 for production mode
    'checker.check_static_paths': False,

    # для того, чтобы можно было посмотреть /service/status с ip, отличного от 127.0.0.1
    'tools.trusted_proxy.on': True,
    # замерялка времени генерации response
    'tools.request_timer.on': True,
    # для страницы мониторинга /services/status
    'tools.status.on': True,

    #'server.socket_timeout': 20,

    # чтобы не редиректило на 127.0.0.1
    'tools.proxy.on': True,
    'tools.proxy.base': config.EXT_SERVER_URL,
    # Для продуктивного режима вывод трейса отключаем
    #request.show_tracebacks': False,

    'tools.savedsesstool.on': False,  # не нужен здесь, т.к. нет аутентификации
}
# Погружаем настройки кластера
global_cfg = dict(global_cfg, **config.CPCONFIG_GLOBAL)


# Конфигурация для страниц веб-приложения ---------------------------
# подключается в cpdispatcher.py
app_cfg = {
    'tools.transactionwrapper.on': True,
    'tools.nocachetool.on': True,
    'tools.sessions.on': False,
}


# Конфигурация для диспетчера статических файлов --------------------
static_cfg = {
    'tools.staticdir.on': True,
    'tools.staticdir.dir': config.STATICDIR,
    #'tools.caching.on': True,
    #'tools.savedsesstool.on': False,
}
