# -*- coding: utf-8 -*-

import os
import socket

from config_defaults import *
from passwd import *

INSTANCE_NUMBER = int(os.environ['INSTANCE_NUMBER']) # init.d
INSTANCE_PORT = int(os.environ['INSTANCE_PORT']) # init.d
INSTANCE_HOME = os.environ['INSTANCE_HOME'] # Dockerfile


# Настройка cpconfig ----------------------------------------------------------
CPCONFIG_GLOBAL = {
    'server.thread_pool': 8,        # Число создаваемых тредов для обработки запросов
    'engine.autoreload.on': False,  # Автоматически перезагружать приложение при изменении *py файлов
    'log.screen': False,  # Use 'False' for production mode
}

# Настройки веб-сервера и сервера приложений ----------------------------------
SERVER_HOST = '0.0.0.0'
SERVER_PORT = 6380
INSTANCE_ID = 'STAGING_WS2_{}'.format(INSTANCE_NUMBER)

# Список IP-адресов, запросы от которых считаются доверительными
PROXY_IP = ['127.0.0.1', socket.gethostbyname('dockerhost'), '185.69.82.30', '192.168.16.2','192.168.16.3','192.168.16.4','192.168.16.5','192.168.16.6','192.168.16.7'] 

ENABLE_I18N = True
KNOWN_LANGUAGES = ('en', 'ru', 'de', 'fr', 'it', 'es', 'ja', 'ko', 'zh')
FALLBACK_LANGUAGES = ['en']
# Язык ответа Web-сервисов в случае отсутствия параметра lang
DEFAULT_SERVICE_LANG = 'en'


# Настройки URL ---------------------------------------------------------------
VIRTUAL_BASE = '/ws2'
VIRTUAL_STATIC_BASE = VIRTUAL_BASE
EXT_SERVER_URL = 'https://afl-staging.test.aeroflot.ru' + VIRTUAL_BASE  # URL для доступа к веб-серверу приложения, строка вида 'http://127.0.0.1:80'
LK_URL = 'https://afl-staging.test.aeroflot.ru/personal'  # URL для ссылок на ресурсы "Личного кабинета" (также используется для SSO)


# Настройки почты MTA -------------------------------------
ADMIN_EMAIL = []
SMTP_FROM = 'staging_ws2@afl-site2.com.spb.ru'
SMTP_SERVER = 'dockerhost'
SMTP_PORT = 25


# Настройки подключения к БД --------------------------------------------------
POSTGRES_BASE = "staging_ws2"
POSTGRES_USER = "staging_ws2_{}".format(INSTANCE_NUMBER)
if POSTGRES_PW:
    POSTGRES_DSN = "host=pghost dbname={} user={} password='{}'".format(POSTGRES_BASE, POSTGRES_USER, POSTGRES_PW, INSTANCE_ID)
else:
    POSTGRES_DSN = "host=pghost dbname={} user={}".format(POSTGRES_BASE, POSTGRES_USER, INSTANCE_ID)


# Настройки взаимодействия с сервисом PBUS ------------------------------------
PBUS_URL = 'http://dockerhost:8390' # !!! Адрес сервера PBUS
PBUS_CALLBACK_HOST = 'localhost'  # Имя или IP-адрес сервера приложения для callback-запросов от PBUS
PBUS_CALLBACK_PORT = INSTANCE_PORT
PBUS_MY_NAME = 'staging_ws2_{}'.format(INSTANCE_NUMBER)
PBUS_TOPICS = {
    'vocabs': 'vocabs2',
}
PBUS_VOCAB_RECIPIENTS = {
    'vocabs': 'staging_vocabs2',
}

# Настройки взаимодействия с системой PASSBOOK --------------------------------
PASSBOOK_SITE = 'https://stage.passbook.aeroflot.ru/'
PASSBOOK_TEMPLATE_URL = '%s/api/provider/templates' % PASSBOOK_SITE
PASSBOOK_ACTION_URL = '%s/api/provider/pass/%%s' % PASSBOOK_SITE
PASSBOOK_CARD_URL = 'https://stage.passbook.aeroflot.ru/api/client/pass/%s'

# Настройки взаимодействия с системой ICER-------------------------------------
#ICER_CSV_URL = "http://127.0.0.1:6580/ws2/static/ICER_test.csv"
ICER_SFTP_HOST = "sftp.aeroflot.ru"



# Проверка конфига. Добавить в самом конце файла !!! --------------------------
__errors = []
for __n, __v in globals().items():
    if __v is NotImplemented:
        __errors.append('%s = %s' % (__n, __v))

# Проверям, что язык язык по умолчанию вход в список "известных" языков
if DEFAULT_SERVICE_LANG not in KNOWN_LANGUAGES:
    __errors.append('DEFAULT_SERVICE_LANG: %s not in %s ' % (DEFAULT_SERVICE_LANG, KNOWN_LANGUAGES))

if __errors:
    raise NameError(__errors)
