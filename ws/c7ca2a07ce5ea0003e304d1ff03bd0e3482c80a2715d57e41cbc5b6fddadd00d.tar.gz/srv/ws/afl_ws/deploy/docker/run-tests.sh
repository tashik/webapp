#!/bin/bash -eu

. build-config.sh

docker_tag=${1-latest}
app=$APP_NAME

DB_CONTAINER="${app}-test-${docker_tag}-db"
NETWORK="${app}-test-${docker_tag}"
IMAGE_NAME="${app}-test:${docker_tag}"
APP_CONTAINER="${app}-test-${docker_tag}"
DB_USER="${app}_test"
INIT_DB_SCRIPTS=sql/create.sql

PG_MIN_STABLE_SECONDS=3

wait_for_postgres() {
    local container=$1
    local user=$2
    local uptime=0
    while :
    do
	(set +e; docker exec $container psql -q -v ON_ERROR_STOP=1 -U $user -c 'select 1;') >/dev/null 2>&1
	local result=$?
	if [[ $result -eq 0 ]]; then
	    uptime=$[ $uptime + 1 ]
	    if [[ $uptime -gt $PG_MIN_STABLE_SECONDS ]]; then
		break
	    fi
	else
	    uptime=0
	fi
	echo "## Waiting for postgres container to start (uptime=$uptime)" >&2
        sleep 1
    done
}

start_postgres() {
    local container_id=$(docker run --name $DB_CONTAINER --network $NETWORK -e POSTGRES_PASSWORD='' -e POSTGRES_USER=$DB_USER -d postgres:9.3)
    wait_for_postgres $container_id $DB_USER
}

populate_db() {
    local RUN_SQL="docker run --rm -t --network $NETWORK -e PGHOST=$DB_CONTAINER -e PGUSER=$DB_USER $IMAGE_NAME"
    for sql_script in $@
    do
	$RUN_SQL psql -v ON_ERROR_STOP=1 -qf $sql_script || exit 3
    done
}

copy_reports() {
    local destdir=$1
    local appdir=$(docker inspect --format='{{.Config.WorkingDir}}' $APP_CONTAINER)
    docker cp $APP_CONTAINER:$appdir/log/coverage-report.xml $destdir
    docker cp $APP_CONTAINER:$appdir/log/test-report.xml $destdir
}

cleanup() {
    (
	set +e
	docker rm -vf $APP_CONTAINER 2>&1 | grep -v 'No such container:'
	docker stop $DB_CONTAINER 2>&1 | grep -v 'No such container:'
	docker rm -v $DB_CONTAINER 2>&1 | grep -v 'No such container:'
	docker network rm $NETWORK 2>&1 | grep -v 'network .* not found'
	true
    )
}


main() {
    rm -f ./coverage-report.xml ./test-report.xml
    cleanup
    docker network create $NETWORK >/dev/null

    trap true SIGINT SIGTERM
    (
	trap - SIGINT SIGTERM

	start_postgres
	populate_db $INIT_DB_SCRIPTS
	docker run --name $APP_CONTAINER --network $NETWORK -e PGHOST=$DB_CONTAINER -e PGUSER=$DB_USER $IMAGE_NAME coverage.sh
	copy_reports .

    ) || true

    trap - SIGINT SIGTERM
    cleanup
}

main
