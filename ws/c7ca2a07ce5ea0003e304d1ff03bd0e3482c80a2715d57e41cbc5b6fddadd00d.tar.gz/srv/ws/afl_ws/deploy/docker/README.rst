= Сборка образа =

::

    ./build-libs.sh
    ./build.sh


= Запуск СУБД =

::

    docker run --name ws-postgres --network docker_default -e TZ=Europe/Moscow -e POSTGRES_PASSWORD='' -e POSTGRES_USER=ws -d postgres:9.3



= Инициализация данных в БД =

::

    # если требуется, пересоздаем БД
    #docker run --rm -t --link ws-postgres:db -u ws ws dropdb ws
    #docker run --rm -t --link ws-postgres:db -u ws ws createdb ws

    PSQL_WS="docker run --rm -i --network docker_default ws psql"

    # если есть дамп БД, загружаем его.
    zcat ~/dumps/ws2-2017-02-12.sql.gz | $PSQL_WS

    # если дампа нет, создаем пустую БД, через create.sql
    $PSQL_WS -f sql/create.sql


= Запуск на консоли =

::

    ./run.sh

= Запуск тестов =

::

    # сборка образа
    ./build-test.sh

    # запускаем СУБД
    docker run --name ws-test-pg -e TZ=Europe/Moscow -e POSTGRES_PASSWORD='' -e POSTGRES_USER=ws-test -d postgres:9.3

    # если требуется, пересоздаем БД
    #docker run --rm -t --link ws-test-pg:db -u ws ws dropdb ws
    #docker run --rm -t --link ws-test-pg:db -u ws ws createdb ws

    PSQL_WS="docker run --rm -i --link ws-test-pg:db ws-test psql -h db"

    # создаем пустую БД
    $PSQL_WS -f sql/create.sql

    # запускаем тесты
    docker run -ti --rm -v $PWD/etc:/srv/ws/etc -v $PWD/log:/srv/ws/log --link ws-test-pg:ws-postgres --name ws-test ws-test
    docker run -ti --rm -v $PWD/etc:/srv/ws/etc -v $PWD/log:/srv/ws/log --link ws-test-pg:ws-postgres --name ws-test ws-test coverage.sh
