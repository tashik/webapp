#!/bin/bash -euo pipefail
# Запуск приложения с монтированием локальной копии исходников (из каталога checkout/)

. build-config.sh

find_checkout_dir() {
    cd checkout
    shopt -s nullglob
    local checkout_dir=(afl_$app* afl-$app* $app* afl_*)
    echo ${checkout_dir[0]}
}

docker_tag=latest
app=$APP_NAME
checkout_dir=$(find_checkout_dir)
mounts="-v $PWD/checkout/$checkout_dir:/srv/$app/$checkout_dir"

DB_CONTAINER=$app-postgres
NETWORK=docker_default
IMAGE_NAME="${app}-test:${docker_tag}"
APP_CONTAINER=$app-dev
DB_USER=$app

ports=$(docker inspect --type image \
               -f '{{ range $key,$value := .ContainerConfig.ExposedPorts }} -p {{ $key }}:{{ $key }} {{ end }}' \
               $IMAGE_NAME \
        | sed 's,/tcp,,g')


DOCKER_RUN="docker run -ti --network $NETWORK -e PGHOST=$DB_CONTAINER -e PGUSER=$DB_USER $ports $mounts"

$DOCKER_RUN --name $APP_CONTAINER --rm $IMAGE_NAME $@

