#!/bin/bash -exu

if [[ -z "$@" ]]; then
    # default action
    exec su-exec ws python /usr/bin/py.test
else
    # custom cmd (example: docker run -ti --rm ws-test /bin/bash)
    exec su-exec ws $@
fi
