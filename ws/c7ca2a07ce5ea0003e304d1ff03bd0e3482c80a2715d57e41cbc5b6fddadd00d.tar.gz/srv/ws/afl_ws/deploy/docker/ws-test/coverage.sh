#!/bin/sh

cd $INSTANCE_HOME
python-coverage run /usr/bin/py.test --junitxml afl_ws/log/test-report.xml afl_ws/
python-coverage xml --include="afl_ws/*" --omit="afl_ws/tests/*" \
    --omit="afl_ws/services/base/tests/*" --omit="afl_ws/passbook/tests/*" \
    -i -o $APPDIR/log/coverage-report.xml
