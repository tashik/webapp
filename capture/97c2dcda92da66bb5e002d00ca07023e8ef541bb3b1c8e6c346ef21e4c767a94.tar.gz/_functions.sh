function log {
    echo $@ >&2
}

function url_path_to_filename {
    echo $1 | sed -E -e 's,^http?://[\:a-z.0-9-]+[/]+,,' -e 's,[/?&:],+,g'
}

function ceil {
    python -c "import math; print '%i%%' % math.ceil($1 * 100)"
}
