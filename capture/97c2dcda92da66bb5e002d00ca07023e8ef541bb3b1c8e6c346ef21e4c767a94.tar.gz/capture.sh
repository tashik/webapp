#!/bin/bash

set -e

source ./_functions.sh

INPUT_FILE=/dev/stdin
CONTAINER="pjs-$$"

function process_path {
    local url=$1
    output_file="$(url_path_to_filename $url).png"

    if [ -n "$LOCAL_PHANTOMJS" ]
    then
	cp error.png /tmp/page.png  # на случай, если phantomjs упадет
	phantomjs /config/load.js $url
	mv /tmp/page.png $OUTPUT_DIR/$output_file
    else
        # Переменная DOCKER_OPTIONS передается извне
        docker run $DOCKER_OPTIONS --name $CONTAINER -i -u root -v $PWD:/config/ \
	    wernight/phantomjs phantomjs /config/load.js $url
        docker cp $CONTAINER:/tmp/page.png $OUTPUT_DIR/$output_file
	docker rm $CONTAINER
    fi
}


function process_input_lines {
    local input_file=$1
    local counter=1
    for url in $(< $1)
    do
	echo "### $counter $url"
	process_path $url
	counter=$((counter+1))
    done
}


function usage {
    echo "Usage: $0 {output-dir} [urls-file]" >&2
    exit 2
}

function main {
    OUTPUT_DIR=$1
    [ -z "$OUTPUT_DIR" ] && usage

    INPUT_FILE=$2

    process_input_lines ${INPUT_FILE:-/dev/stdin}
}


main $@
