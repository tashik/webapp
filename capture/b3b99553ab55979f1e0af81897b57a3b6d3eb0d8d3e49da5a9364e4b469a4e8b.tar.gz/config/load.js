var system = require('system');
var page = require('webpage').create();
var url = system.args[1];
var allowed = ['www.aeroflot.ru']; // домены, с которых разрешена загрузка ресурсов
var inject_css = ("div#bottom-banner { display: none; } " + 
		  "div.banner-container { display: none; } " +
		  "div.information-label { display: none; } " +
		  "");
page.settings.resourceTimeout = 30000;  // 30 seconds


// https://github.com/ariya/phantomjs/blob/master/examples/waitfor.js
function waitFor(testFx, onReady, timeOutMillis) {
    var maxtimeOutMillis = timeOutMillis ? timeOutMillis : 3000, //< Default Max Timout is 3s
        start = new Date().getTime(),
        condition = false,
        interval = setInterval(function() {
		if ( (new Date().getTime() - start < maxtimeOutMillis) && !condition ) {
		    // If not time-out yet and condition not yet fulfilled
		    condition = (typeof(testFx) === "string" ? eval(testFx) : testFx()); //< defensive code
		} else {
		    if(!condition) {
			// If condition still not fulfilled (timeout but condition is 'false')
			console.log("'waitFor()' timeout");
			phantom.exit(1);
		    } else {
			// Condition fulfilled (timeout and/or condition is 'true')
			console.log("'waitFor()' finished in " + (new Date().getTime() - start) + "ms.");
			typeof(onReady) === "string" ? eval(onReady) : onReady(); //< Do what it's supposed to do once the condition is fulfilled
			clearInterval(interval); //< Stop this interval
		    }
		}
	    }, 50); //< repeat check every 50ms
};


page.onResourceRequested = function(requestData, networkRequest) {
    var url = requestData.url;

    if (url.indexOf('data:') == 0) {
        console.log('Requested data URI');
    } else {
	var found = 0;
        for (var i = 0; i < allowed.length; i++) {
            var good = allowed[i];
            if (good == url || url.match(new RegExp(good))) {
                 found = 1;
		 break;
            }
        } 
	if (!found) {
	    console.log('Blocking resource: ' + url);
	    networkRequest.abort();
	}
        console.log('Requested: ' + url);
    }
};


page.doInject = function() {
    console.log('Injecting custom script');
    page.evaluate(function(style) {
	    var styleEl = document.createElement('style');
	    styleEl.type = 'text/css';
	    styleEl.innerHTML = style;
	    document.getElementsByTagName('head')[0].appendChild(styleEl);
	    if (window.jQuery) { 
		$('input.dateInput').val(''); // спрятать текущую дату, так как она не должна участвовать в сравнении
	    }
	}, inject_css);
};


page.onLoadFinished = function() {
    console.log('Load finished');
    page.doInject();
}


// Wait for booking_overlay to be hidden
page.waitForOverlay = function() {
    waitFor(function() {
	    var $is_visible = page.evaluate(function() { 
		return window.jQuery && $('.booking_overlay').is(":visible");
	    });
	    console.log("booking_overlay booking_overlay_visible=" + $is_visible);
	    return !$is_visible;
	}, function() {
	    page.render('/tmp/page.png');
	    console.log('saved');
	    phantom.exit();
	});
}


function onPageOpen(status) {
    // отбрасываем RSS и прочие неотображаемые объекты
    var $is_webpage = page.evaluate(function() { 
	return document.getElementsByTagName("TITLE").length != 0;
    });

    console.log("Status: " + status + "; Is webpage: " + $is_webpage);
    
    if (status === "success" && $is_webpage) {
	setTimeout(page.waitForOverlay, 200);
    } else {
	phantom.exit();
    }
}


page.open(url, function(status) {
    try {
	onPageOpen(status);
    } catch(ex) {
        var fullMessage = "\nJAVASCRIPT EXCEPTION";
        fullMessage += "\nMESSAGE: " + ex.toString();
        for (var p in ex) {
            fullMessage += "\n" + p.toUpperCase() + ": " + ex[p];
        }
        console.log(fullMessage);
	phantom.exit();
    }

});
