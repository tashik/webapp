#!/bin/bash -e

exec python3 -m celery -A main worker \
    -n aac_admin_worker -c 4 -Q $QUEUE_NAME \
    --workdir=$APPDIR \
    --pidfile=$APPDIR/pid/%n.pid \
    --logfile=$APPDIR/log/aac_admin_worker.log
