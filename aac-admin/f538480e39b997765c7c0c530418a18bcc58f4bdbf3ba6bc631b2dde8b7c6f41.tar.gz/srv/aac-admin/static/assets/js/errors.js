function set_error_messages(messages){
    $container = $('.form_errors_container');
    if(!$container.length) return;

    $container.empty();
    for (var i = 0; i < messages.length; ++i) {
        $container.append('<p class="h-fz--16">' + messages[i] + '</p>')
    }
}