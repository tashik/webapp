# -*- coding: utf-8 -*-
import hashlib

# При выводе конфига заменяет секреты (пароли, ключи) на хэш-коды,
# что позволяет хранить и работать с копиями конфигов без риска утечки
class Secret(str):
    def __repr__(self):
        return 'Secret(%s)' % hashlib.md5(self.encode()).hexdigest()[:8]

def yaml_secret_constructor(loader, node):
    value = loader.construct_scalar(node)
    return Secret(value)
