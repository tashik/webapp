# -*- coding: utf-8 -*-
import config

# CherryPy Global Configuration -------------------------------------
global_cfg = {
    'tools.decode.on': True,
    'tools.encode.on': True,
    'tools.encode.encoding': 'utf-8',
    'tools.decode.encoding': 'utf-8',
    'log.screen': True,  # Use 'False' for production mode
    'server.socket_port': config.SERVER_PORT,
    'server.socket_host': config.SERVER_HOST,
    'server.thread_pool': 8,  # Use >0 for production mode
    'checker.check_static_paths': False,

    # замерялка времени генерации response
    'tools.request_timer.on': True,

    'tools.status.on': True,  # для страницы мониторинга /services/status
    # для того, чтобы можно было посмотреть /service/status с ip, отличного от 127.0.0.1
    'tools.trusted_proxy.on': True,

    # чтобы не редиректило на 127.0.0.1
    'tools.proxy.on': True,
    'tools.proxy.base': config.EXT_SERVER_URL,
# Для продуктивного режима вывод трейса отключаем
#    'request.show_tracebacks': False,
}

global_cfg.update(config.CPCONFIG_GLOBAL)



# Конфигурация для страниц веб-приложения ---------------------------
app_cfg = {
    # ставим дефолтный язык для django - ru
    'tools.activate_django_translation.on': True,

    'tools.savedsesstool.on': True,
    'tools.transactionwrapper.on': True,
    'tools.nocachetool.on': True,

    'tools.sessions.domain': config.APP_COOKIE_DOMAIN,
    'tools.sessions.prefix': config.SESSION_COOKIE_PREFIX,
    'tools.sessions.name': 'banneradm_session_id',
    'tools.sessions.on': True,
    'tools.sessions.secure': True,
    #'tools.sessions.storage_type': 'file',
    'tools.sessions.storage_type': 'memcached',
    #'tools.sessions.storage_path': config.SESSDIR,
    #'tools.sessions.timeout': 60 * 8,  # In minutes
    'tools.sessions.timeout': 60, # In minutes
}

app_cfg.update(config.CPCONFIG_APP)

# Конфигурация для диспетчера статических файлов --------------------
static_cfg = {
    # для статики сессии не нужны
    'tools.savedsesstool.on': False,
    'tools.sessions.on': False,
    'tools.staticdir.on': True,
    'tools.staticdir.dir': config.STATICDIR,
}

static_cfg.update(config.CPCONFIG_STATIC)
