# -*- coding: utf-8 -*-
import re
import yaml

def expand_config_templates(d, template_vars):
    from config.secret import Secret
    for k, v in d.items():
        if isinstance(v, str) and not isinstance(v, Secret):
            d[k] = v = re.sub(r'{{([A-Z0-9_]+)}}', lambda m: template_vars[m.group(1)], v)


def load_yaml(path, template_vars):
    with open(path) as f:
        d = yaml.load(f)
    expand_config_templates(d, template_vars)
    return d
