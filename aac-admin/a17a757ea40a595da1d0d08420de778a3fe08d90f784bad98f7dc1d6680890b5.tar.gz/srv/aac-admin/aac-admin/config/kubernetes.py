# -*- coding: utf-8 -*-

# В каталог /secrets монтируются секреты при запуске под Kubernetes.
# Переопределения параметров конфига считваем через API Kubernetes.

from __future__ import print_function

import base64
import os
import sys
import yaml
from config.secret import Secret
from collections import OrderedDict


def _ensure_type(container, t):
    if not isinstance(container, (t, OrderedDict)):
        raise ValueError('%s must have type %s' % (container, t))

def _ensure_size(container, index):
    if len(container) < index + 1:
        if isinstance(container, OrderedDict):
            container.update({k: None for k in range(len(container), index + 1)})
        else:
            container += [None] * (index + 1 - len(container))


# Распарсивание многоуровневых ключей, типа SMS_SENDER_CONN.host.
# Если ключ похож на число, интерпретирует его как индекс в списке.
# Ограничение: если переменная не была инициализирована как list ранее в конфиге, то элементы списка будут добавляться
# в порядке их парсинга, без учета значения их числовых ключей (X.1 = '1'; X.0 = '0'; print(list(X)); ['1', '0'])
def set_config_param(container, key, value):
    segments = key.split('.')
    for n, k in enumerate(segments):
        if k.isdigit():
            k = int(k)
            _ensure_type(container, list)
            _ensure_size(container, k)
        else:
            _ensure_type(container, dict)
            if k not in container:
                container[k] = OrderedDict()

        if n < len(segments) - 1:
            container = container[k]
        else:  # last loop iteration
            container[k] = value


# При монтировании configmap в pod обновление данных в нем происходит с задержкой.
# Поэтому читаем configmap через Kubernetes API (HTTP GET).
def load_resource(name, resource_type):
    import requests

    with open('/var/run/secrets/kubernetes.io/serviceaccount/namespace') as f:
        namespace = f.read()
    with open('/var/run/secrets/kubernetes.io/serviceaccount/token') as f:
        headers = {'Authorization': 'Bearer ' + f.read()}
    r = requests.get('https://kubernetes.default.svc.cluster.local:%s/api/v1/namespaces/%s/%s/%s' % \
                     (os.environ['KUBERNETES_SERVICE_PORT'], namespace,
                      resource_type + 's', name),
                      headers=headers, verify='/var/run/secrets/kubernetes.io/serviceaccount/ca.crt')
    if r.status_code == 200:
        print('Loaded kubernetes resource %s/%s' % (resource_type, name), file=sys.stderr)
        return yaml.load(r.text)['data']
    else:
        print('Unable to load %s/%s: %s %s' % (resource_type, name, r.status_code, r.text),
              file=sys.stderr)
    return {}

def load_configmap(container, name='aac-admin-config'):
    configmap_data = load_resource(name, 'configmap')
    if 'config.yaml' in configmap_data:
        configmap_data = yaml.load(configmap_data['config.yaml'])
    container.update(configmap_data)

def load_secrets(container, name='aac-admin-secrets'):
    for varname, value in load_resource(name, 'secret').items():
        value = base64.decodebytes(value.encode()).decode()
        set_config_param(container, varname, Secret(value))

def load_cluster_config(container):
    if 'KUBERNETES_SERVICE_HOST' in os.environ:
        load_configmap(container)
        load_secrets(container)
    return container
