# -*- coding: utf-8 -*-

"""
Usage: python -m config [--pretty-print]

Выводит содержимое конфига в алфавитном порядке. Применяется для проверки и сравнения конфигов разных версии системы.
"""

import pprint
import re
import sys
import types
import config
# борьба с ошибкой django.core.exceptions.AppRegistryNotReady
config.USE_I18N = False

OBJECT_ADDR_RE = re.compile('object at 0x[0-9a-f]{1,}', re.MULTILINE)
SITE_DOMAIN_RE = re.compile('%s' % re.escape(config.DOMAIN), re.MULTILINE)

def dump_config():
    for k, v in sorted(config.__dict__.items()):
        if k == 'USE_I18N':
            continue

        if not k.startswith('_') and not isinstance(v, (types.ModuleType, types.CodeType, types.FunctionType, type)):
            if '--pretty-print' in sys.argv:
                v = pprint.pformat(v)
            else:
                v = repr(v)
            v = OBJECT_ADDR_RE.sub('object at {memory-addr}', v)
            v = SITE_DOMAIN_RE.sub('{{SITE_DOMAIN}}', v, re.MULTILINE)
            if '\n' in v:
                print('%s = \\\n %s' % (k, v))
            else:
                print('%s = %s' % (k, v))


if __name__ == '__main__':
    dump_config()
