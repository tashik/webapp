# -*- coding: utf-8 -*-

import os
import pathlib
from django.utils.translation import ugettext_lazy as _

DOMAIN = os.environ.get('DOMAIN', 'aac-test.test.aeroflot.ru')

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.11/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = NotImplemented

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# Application definition

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'aac_admin',
    'social_django',
    'rest_framework'
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.locale.LocaleMiddleware',

    'aac_admin.middleware.AACSocialAuthExceptionMiddleware',
]

ROOT_URLCONF = 'main.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'aac_admin', 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',

                'social_django.context_processors.backends',
                'social_django.context_processors.login_redirect',
            ],
        },
    },
]

WSGI_APPLICATION = 'main.wsgi.application'

# Password validation
# https://docs.djangoproject.com/en/1.11/ref/settings/#auth-password-validators

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Internationalization
# https://docs.djangoproject.com/en/1.11/topics/i18n/

LANGUAGE_CODE = 'ru'
TIME_ZONE = 'Europe/Moscow'
USE_I18N = True
USE_L10N = True
USE_TZ = True


STATICFILES_DIRS = [
    os.path.join(BASE_DIR, "static"),
]

STATIC_URL = '/admin/static/'
STATIC_ROOT = os.environ['INSTANCE_HOME'] + '/static'


AUTHENTICATION_BACKENDS = (
    'auth.social_backends.aac.AACOICAuth',
    'django.contrib.auth.backends.ModelBackend',
)

SOCIAL_AUTH_BACKENDS = {
    'social_core.backends.vk.VKOAuth2': {'id': 1, 'name': 'vk', 'siebel_id': 'VK',
                                         'css_class': 'social__item--vk social__link--vk'},
    'social_core.backends.twitter.TwitterOAuth': {'id': 2, 'name': 'twitter', 'siebel_id': 'Twitter',
                                                  'css_class': 'social__item--twitter social__link--tv'},
    'social_core.backends.facebook.FacebookOAuth2': {'id': 3, 'name': 'facebook', 'siebel_id': 'Facebook',
                                                     'css_class': 'social__item--fb social__link--fb'},
    'social_core.backends.instagram.InstagramOAuth2': {'id': 4, 'name': 'instagram', 'siebel_id': 'Instagram',
                                                       'css_class': 'social__item--instagram social__link--inst'},
    'social_core.backends.google.GooglePlusAuth': {'id': 5, 'name': 'google', 'siebel_id': 'Google+',
                                                   'css_class': 'social__item--g-plus'}
}

LOGIN_URL = 'login'
LOGOUT_URL = 'logout'
LOGIN_REDIRECT_URL = 'home'
SOCIAL_AUTH_INACTIVE_USER_URL = '/admin/error?error_code=999001002'

LANGUAGES = (
    # Customize this
    ('ru', _('Russian')),
)
TRANSLATION_TEXT_LANGUAGES = ['ru', 'en', 'de', 'fr', 'es', 'it', 'zh', 'ko', 'ja']

REST_FRAMEWORK = {
    'DEFAULT_PERMISSION_CLASSES': [
        'rest_framework.permissions.IsAuthenticated',
    ],
    'DEFAULT_PAGINATION_CLASS': [
        'rest_framework.pagination.PageNumberPagination'
    ],
    'PAGE_SIZE': 10
}

JWKS_CACHE_TTL = 3600


DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('PGDATABASE', 'aac-admin'),
        'HOST': os.environ.get('PGHOST', 'aac-postgres'),
        'USER': os.environ.get('PGUSER', 'aac-admin'),
    },
    'aac': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('AAC_PGDATABASE', 'aac'),
        'HOST': os.environ.get('AAC_PGHOST', 'aac-postgres'),
        'USER': os.environ.get('AAC_PGUSER', 'aac-admin'),
        'TEST': {
            'MIRROR': 'aac',
        }
    },
}

DATABASE_ROUTERS = ['main.db_routers.AACRouter']

LOGBASE = 'log'
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'root': {
        'level': 'DEBUG',
        'handlers': ['serverfile']
    },
    'filters': {
        'require_debug_false': {
            '()': 'django.utils.log.RequireDebugFalse'
        }
    },
    'handlers': {
        'mail_admins': {
            'level': 'ERROR',
            'filters': ['require_debug_false'],
            'class': 'django.utils.log.AdminEmailHandler'
        },
        'serverfile': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'server.log')),
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'django_db': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'django_db.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'access': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'access.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'request': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'request.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'aac_admin': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'aac_admin.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'aac_admin_actions': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'aac_admin_actions.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'aac_admin_errors': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'aac_admin_errors.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },

        'social': {
            'level': 'DEBUG',
            'class': 'logging.handlers.RotatingFileHandler',
            'filename': str(pathlib.PurePath(BASE_DIR, LOGBASE, 'social.log')),
            'formatter': 'defaultFormatter',
            'delay': True,
            'maxBytes': 10 * 1024 * 1024,
            'backupCount': 3,
            'encoding': 'UTF-8',
            'mode': 'a',
        },
        'console': {
            'level': 'DEBUG',
            'class': 'logging.StreamHandler',
            'formatter': 'defaultFormatter',
        },
    },
    'formatters': {
        'defaultFormatter': {
            'class': 'logging.Formatter',
            'format': '[%(asctime)s] %(name)s %(message)s',
            'datefmt': '%d/%b/%Y:%H:%M:%S'
        },
        'accessFormatter': {
            'class': 'logging.Formatter',
            'format': '[%(asctime)s] %(name)s %(message)s %(request)s',
            'datefmt': '%d/%b/%Y:%H:%M:%S'

        }
    },
    'loggers': {
        'django.request': {
            'handlers': ['console', 'request'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'django.db.backends': {
            'handlers': ['django_db'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'django': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False
        },
        'django.server': {
            'handlers': ['console', 'access'],
            'level': 'DEBUG',
            'propagate': False
        },
        'aac_admin': {
            'handlers': ['console', 'aac_admin'],
            'level': 'DEBUG',
            'propagate': False
        },
        'aac_admin_actions': {
            'handlers': ['console', 'aac_admin_actions'],
            'level': 'DEBUG',
            'propagate': False
        },
        'aac_admin_errors': {
            'handlers': ['console', 'aac_admin_errors'],
            'level': 'DEBUG',
            'propagate': False
        },
        'social': {
            'handlers': ['social', 'console'],
            'level': 'DEBUG',
            'propagate': False
        },
    }
}


SOCIAL_AUTH_REDIRECT_IS_HTTPS = True
SOCIAL_AUTH_AAC_KEY = '100'
SOCIAL_AUTH_AAC_SECRET = 'aac_admin_secret'
SOCIAL_AUTH_SESSION_EXPIRATION = True

AAC_URL = 'https://aac-' + DOMAIN

AAC_ID_TOKEN_ISSUER = AAC_URL + '/'
AAC_AUTHORIZATION_URL = AAC_URL + '/oauth2/v1/authorization'
AAC_ACCESS_TOKEN_URL = AAC_URL + '/oauth2/v1/token'
AAC_USERINFO_URL = AAC_URL + '/oidc/v1/userinfo'
AAC_ENDSESSION_URL = AAC_URL + '/oidc/v1/end_session'
AAC_JWKS_URI = AAC_URL + '/jwks'
ALLOWED_HOSTS = ['aac-' + DOMAIN, '127.0.0.1', 'localhost']
SECURE_PROXY_SSL_HEADER = ('TEST', 'TEST')

SOCIAL_AUTH_AAC_PIPELINE = (
    'social_core.pipeline.social_auth.social_details',
    'social_core.pipeline.social_auth.social_uid',
    'social_core.pipeline.social_auth.auth_allowed',
    'auth.pipeline.social_auth.get_aac_user',
    'social_core.pipeline.social_auth.social_user',
    'auth.pipeline.social_auth.get_aac_username',
    'social_core.pipeline.social_auth.associate_user',
    'social_core.pipeline.social_auth.load_extra_data',
    'social_core.pipeline.user.user_details',
    'auth.pipeline.social_auth.session_expiry',
)

INFINITE_SCROLL_ITEMS_COUNT = 20

WEB_DAV_STORAGE_URL = 'http://localhost:8085/data/'
#WEB_DAV_STORAGE_URL = f'file://{os.environ["APPDIR"]}/static/client_logo'
# в продакшене адрес проксирующего сервера
UPLOADED_DATA_BASE_URL = AAC_URL + '/data/'
#UPLOADED_DATA_BASE_URL = f'https://aac-{DOMAIN}/admin/static/client_logo/'

WEB_DAV_USER = 'dav'
WEB_DAV_PASSWORD = NotImplemented

REDIS_HOST = 'aac-redis'
REDIS_PORT = 6379
REDIS_DB = 0

CELERY_REDIS_DB = 1
CELERY_BROKER_URL = 'redis://%s:%s/%s' % (REDIS_HOST, REDIS_PORT, CELERY_REDIS_DB)
CELERY_TASK_DEFAULT_QUEUE = 'aac_admin'

# параметры не используются?
LOGIN_ERROR_URL = 'home'
