# -*- coding: utf-8 -*-

from __future__ import print_function
import sys
import yaml

from config import load_yaml, secret, kubernetes
yaml.add_constructor('!secret', secret.yaml_secret_constructor)

from config.defaults import *

_template_vars = dict(DOMAIN=DOMAIN)

_LOCAL_CONFIG_YAML = os.path.dirname(os.path.dirname(__file__)) + '/local-config.yaml'
if os.path.exists(_LOCAL_CONFIG_YAML):
    globals().update(load_yaml.load_yaml(_LOCAL_CONFIG_YAML, _template_vars))
    print('Loaded config overrides from %s' % _LOCAL_CONFIG_YAML, file=sys.stderr)

kubernetes.load_cluster_config(globals())


DEPRECATED = set()

def validate_config():
    errors = []
    for n, v in globals().items():
        # Некоторые переменные являются обязательными для переопределения.
        if v is NotImplemented:
            errors.append(n)
        if n in DEPRECATED:
            # logging здесь использовать не получается, так как он еще не сконфигурирован
            print('WARNING: config parameter %s is deprecated' % n, file=sys.stderr)

        if v in ('True', 'False'):
            print('WARNING: config parameter %s may have invalid value (use lowercase for true/false values)' % n,
                  file=sys.stderr)

    if errors:
        raise NameError(errors)
