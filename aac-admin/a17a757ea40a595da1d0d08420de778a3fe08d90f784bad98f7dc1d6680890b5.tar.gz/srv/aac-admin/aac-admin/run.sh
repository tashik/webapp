#!/usr/bin/env sh

# Запуск celery worker
python3 -m celery -A main worker --detach \
    -n aac_admin_worker -c 4 -Q $QUEUE_NAME \
    --workdir=$APPDIR \
    --pidfile=$APPDIR/pid/%n.pid \
    --logfile=$APPDIR/log/aac_admin_worker.log

# Запуск Django
python3 manage.py runserver 0.0.0.0:8080
