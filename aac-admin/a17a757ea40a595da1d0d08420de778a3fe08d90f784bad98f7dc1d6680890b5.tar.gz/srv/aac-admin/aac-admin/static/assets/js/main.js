var debounce, delay, interval;

debounce = function(delay, fn) {
  var timer;
  timer = null;
  return function() {
    var args, context;
    context = this;
    args = arguments;
    clearTimeout(timer);
    timer = setTimeout((function() {
      fn.apply(context, args);
    }), delay);
  };
};

delay = function(ms, func) {
  return setTimeout(func, ms);
};

interval = function(ms, func) {
  return setInterval(func, ms);
};

String.prototype.toHTML = function() {
  var div;
  div = document.createElement('div');
  div.innerHTML = this;
  return div.firstChild;
};

String.prototype.parseTime = function() {
  var hour, minute, time;
  time = this.match(/(\d+)(?:[:,-](\d\d))?\s*(p?)/);
  try {
    hour = parseInt(time[1]) + (time[3] ? 12 : 0);
    minute = parseInt(time[2]) || 0;
    return [hour <= 23 ? hour : hour === 24 ? 0 : 23, minute <= 59 ? minute : 59];
  } catch (error) {
    return null;
  }
};

Number.prototype.to10String = function() {
  if (this.toString().length === 1) {
    return '0' + this;
  } else {
    return this;
  }
};

Number.prototype.formatMoney = function(t, d, c) {
  var i, j, n, s;
  if (t == null) {
    t = ' ';
  }
  if (d == null) {
    d = '.';
  }
  if (c == null) {
    c = '';
  }
  n = this;
  s = n < 0 ? "-" + c : c;
  i = Math.abs(n).toFixed(0);
  j = ((j = i.length) > 3 ? j % 3 : 0);
  if (j) {
    s += i.substr(0, j) + t;
  }
  return s + i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + t);
};

Node.prototype.addClass = function(className) {
  if (this.classList) {
    return this.classList.add(className);
  } else {
    return this.className += ' ' + className;
  }
};

Node.prototype.hasClass = function(className) {
  return (this.classList ? this.classList.contains(className) : this.className.indexOf(className) !== -1);
};

Element.prototype.hasData = function(name, deniedEmpty) {
  if (!deniedEmpty) {
    return this.dataset[name] != null;
  } else {
    return this.dataset[name] && this.dataset[name].length > 0;
  }
};

Element.prototype.removeClass = Node.prototype.removeClass = function(className) {
  if (this.classList) {
    this.classList.remove(className);
  } else {
    this.className.replace(className, '');
  }
  return this;
};

NodeList.prototype.removeClass = HTMLCollection.prototype.removeClass = function(className) {
  var element, j, len, ref;
  ref = this;
  for (j = 0, len = ref.length; j < len; j++) {
    element = ref[j];
    element.removeClass(className);
  }
  return this;
};

Node.prototype.getRelativeClientRect = function(parent) {
  var parentRect, rect;
  rect = this.getBoundingClientRect();
  if (!parent) {
    parentRect = this.offsetParent.getBoundingClientRect();
  } else {
    parentRect = parent.getBoundingClientRect();
  }
  return {
    bottom: parentRect.bottom - rect.bottom,
    height: rect.height,
    left: rect.left - parentRect.left,
    right: parentRect.right - rect.right,
    top: rect.top - parentRect.top,
    width: rect.width
  };
};

Node.prototype.prependChild = function(child) {
  return this.insertBefore(child, this.firstChild);
};

Element.prototype.remove = function() {
  this.parentElement.removeChild(this);
};

NodeList.prototype.remove = HTMLCollection.prototype.remove = function() {
  var i;
  i = this.length - 1;
  while (i >= 0) {
    if (this[i] && this[i].parentElement) {
      this[i].parentElement.removeChild(this[i]);
    }
    i--;
  }
};

Element.prototype.closest = function(selector) {
  var el, matchesSelector;
  el = this;
  matchesSelector = el.matches || el.webkitMatchesSelector || el.mozMatchesSelector || el.msMatchesSelector;
  while (el) {
    if (matchesSelector.call(el, selector)) {
      break;
    }
    el = el.parentElement;
  }
  return el;
};

Element.prototype.next = function(selector) {
  var el;
  el = this;
  while (el) {
    el = el.nextElementSibling;
    if (el && el.hasClass(selector)) {
      break;
    }
  }
  return el;
};

Element.prototype.prev = function(selector) {
  var el;
  el = this;
  while (el) {
    el = el.previousElementSibling;
    if (el && el.hasClass(selector)) {
      break;
    }
  }
  return el;
};

var changeOptions, clearDate, clearInput, clickEvent, datePickers, disableReturnDate, getCertificate, isAndroidBrowser, isTouchDevice, login, maskerCard, milesPayment, removeListener, toggle, toggleCheckbox, unfocused, userAgent;

unfocused = {
  init: function() {
    var nextElem, prevElem, secondUnfocusedElem, unfocusedElem;
    unfocusedElem = document.getElementsByClassName('js-unfocused1')[0];
    secondUnfocusedElem = document.getElementsByClassName('js-unfocused2')[0];
    nextElem = document.querySelectorAll('.js-focused-next')[0];
    prevElem = document.querySelectorAll('.js-focused-prev')[0];
    if (unfocusedElem) {
      unfocusedElem.addEventListener('focus', function(e) {
        if (e.target.hasClass('js-unfocused1')) {
          e.preventDefault();
          return nextElem.focus();
        }
      });
    }
    if (secondUnfocusedElem) {
      return secondUnfocusedElem.addEventListener('focus', function(e) {
        if (e.target.hasClass('js-unfocused2')) {
          e.preventDefault();
          return prevElem.focus();
        }
      });
    }
  }
};

isTouchDevice = function() {
  var e;
  try {
    document.createEvent('TouchEvent');
    return true;
  } catch (error) {
    e = error;
    return false;
  }
};

clickEvent = isTouchDevice() ? 'touchstart' : 'click';

isAndroidBrowser = {};

userAgent = {
  init: function() {
    var appleWebKitVersion, body, chromeVersion, isAndroidMobile, regExAppleWebKit, regExChrome, resultAppleWebKitRegEx, resultChromeRegEx, ua;
    ua = navigator.userAgent;
    body = document.getElementsByTagName('body')[0];
    if (ua.indexOf("MSIE") !== -1 || ua.indexOf("Trident") !== -1 || ua.indexOf("Edge") !== -1) {
      body.addClass('ua-ie');
    }
    if (ua.indexOf("MSIE 9") !== -1) {
      body.addClass('ua-ie--9');
    }
    if (ua.indexOf("MSIE 10") !== -1) {
      body.addClass('ua-ie--10');
    }
    if (ua.indexOf("Edge") !== -1) {
      body.addClass('ua-ie--edge');
    }
    if (ua.indexOf("iPhone") !== -1 || ua.indexOf("iPad") !== -1 || ua.indexOf("iPod") !== -1) {
      body.addClass('ua-ios');
      body.addClass('ua-mobile');
      if (ua.indexOf("OS 9") !== -1) {
        body.addClass('ua-ios--9');
      }
    }
    if ((ua.indexOf("Windows Phone") !== -1 || ua.indexOf("IEMobile") !== -1) && !ua.indexOf("Android") !== -1) {
      body.addClass('ua-winmobile');
      body.addClass('ua-mobile');
    }
    if (!(ua.indexOf("Windows Phone") !== -1) && ua.indexOf("Android") !== -1) {
      body.addClass('ua-android');
      body.addClass('ua-mobile');
    }
    isAndroidMobile = ua.indexOf('Android') !== -1 && ua.indexOf('Mozilla/5.0') !== -1 && ua.indexOf('AppleWebKit') !== -1;
    regExAppleWebKit = new RegExp(/AppleWebKit\/([\d.]+)/);
    resultAppleWebKitRegEx = regExAppleWebKit.exec(ua);
    appleWebKitVersion = resultAppleWebKitRegEx === null ? null : parseFloat(regExAppleWebKit.exec(ua)[1]);
    regExChrome = new RegExp(/Chrome\/([\d.]+)/);
    resultChromeRegEx = regExChrome.exec(ua);
    chromeVersion = resultChromeRegEx === null ? null : parseFloat(regExChrome.exec(ua)[1]);
    isAndroidBrowser = isAndroidMobile && appleWebKitVersion !== null && appleWebKitVersion < 537 || chromeVersion !== null && chromeVersion < 37;
    if (isAndroidBrowser) {
      return body.addClass('ua-android-browser');
    }
  }
};

login = {
  init: function() {
    var button, i, icon, len, ref, results, subtitle, text;
    ref = document.getElementsByClassName('js-change-auth');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      text = ref[i];
      login = document.getElementsByClassName('modal--login')[0];
      subtitle = document.getElementsByClassName('js-subtitle')[0];
      button = document.querySelectorAll('.js-change-auth .button')[0];
      icon = document.querySelectorAll('.js-change-auth .icon')[0];
      results.push(text.addEventListener("click", function(e) {
        e.preventDefault();
        if (login.hasClass('modal--corporative')) {
          login.removeClass('modal--corporative');
          subtitle.innerHTML = 'Для частных лиц';
          button.innerHTML = 'Вход для юридических лиц';
          icon.removeClass('icon--man-blue');
          return icon.addClass('icon--case');
        } else {
          login.addClass('modal--corporative');
          subtitle.innerHTML = 'Для организаций';
          button.innerHTML = 'Вход для частных лиц';
          icon.removeClass('icon--case');
          return icon.addClass('icon--man-blue');
        }
      }));
    }
    return results;
  }
};

changeOptions = {
  init: function(elemToggle, elementsHidden) {
    var hiddenClass, hideContent, showCurrent;
    hiddenClass = 'h-display--none';
    hideContent = function() {
      var content, i, len, ref, results;
      ref = document.getElementsByClassName(elementsHidden);
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        content = ref[i];
        results.push(content.addClass(hiddenClass));
      }
      return results;
    };
    showCurrent = function(node) {
      var curContent, i, len, ref, results, selind, val;
      selind = node.options.selectedIndex;
      val = node.options[selind].value;
      ref = document.querySelectorAll('.' + elementsHidden + '.' + val);
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        curContent = ref[i];
        results.push(curContent.removeClass(hiddenClass));
      }
      return results;
    };
    return window.addEventListener("DOMContentLoaded", function() {
      var i, len, ref, results, selectChanger;
      ref = document.querySelectorAll(elemToggle + ' > select');
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        selectChanger = ref[i];
        selectChanger.addEventListener("change", function(e) {
          hideContent();
          return showCurrent(selectChanger);
        });
        hideContent();
        results.push(showCurrent(selectChanger));
      }
      return results;
    });
  }
};

getCertificate = {
  init: function() {
    var hidden, i, len, ref, results, stepNumberInput, stepOne, stepOneButton, stepTwo;
    hidden = 'h-display--none';
    ref = document.getElementsByClassName('js-certificate-step1');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      stepOne = ref[i];
      stepNumberInput = stepOne.querySelector('.js-certificate-input-number > input');
      stepOneButton = stepOne.querySelector('.button');
      stepOneButton.addEventListener('click', function(e) {
        var j, len1, number, ref1;
        e.preventDefault();
        ref1 = document.querySelectorAll('.js-certificate-number');
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          number = ref1[j];
          number.textContent = stepNumberInput.value;
        }
        stepOne.addClass(hidden);
        if (stepTwo.hasClass(hidden)) {
          return stepTwo.removeClass(hidden);
        }
      });
      results.push((function() {
        var j, len1, ref1, results1;
        ref1 = document.getElementsByClassName('js-certificate-step2');
        results1 = [];
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          stepTwo = ref1[j];
          results1.push(window.addEventListener("DOMContentLoaded", function() {
            return stepTwo.addClass(hidden);
          }));
        }
        return results1;
      })());
    }
    return results;
  }
};

toggle = {
  removeAttributes: function(element) {
    var i, len, ref, results, target;
    ref = element.querySelectorAll('.toggle-target');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      target = ref[i];
      results.push(target.removeAttribute('aria-expanded'));
    }
    return results;
  },
  addAttributes: function(element) {
    var i, len, ref, results, target;
    ref = element.querySelectorAll('.toggle-target');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      target = ref[i];
      if (element.classList.contains('toggle-target--active')) {
        results.push(target.setAttribute('aria-expanded', 'true'));
      } else {
        results.push(target.setAttribute('aria-expanded', 'false'));
      }
    }
    return results;
  },
  checkMobileAttributes: function() {
    var i, len, mobileToggle, ref, results;
    ref = document.querySelectorAll('[data-toggle-mobile]');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      mobileToggle = ref[i];
      if (window.innerWidth < 800) {
        results.push(toggle.addAttributes(mobileToggle));
      } else {
        results.push(toggle.removeAttributes(mobileToggle));
      }
    }
    return results;
  },
  changeAttributes: function(elements) {
    var elem, i, len, results;
    results = [];
    for (i = 0, len = elements.length; i < len; i++) {
      elem = elements[i];
      if (elem.hasAttribute('aria-expanded')) {
        if (elem.getAttribute('aria-expanded') === 'true') {
          results.push(elem.setAttribute('aria-expanded', 'false'));
        } else {
          results.push(elem.setAttribute('aria-expanded', 'true'));
        }
      } else {
        results.push(void 0);
      }
    }
    return results;
  },
  init: function(element) {
    var i, len, ref, results, toggler;
    ref = document.querySelectorAll('[data-toggle]');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      toggler = ref[i];
      results.push(toggler.addEventListener("click", function(e) {
        var j, len1, ref1, results1, target;
        e.preventDefault();
        ref1 = document.querySelectorAll('[data-toggle-id="' + this.dataset.toggleTarget + '"]');
        results1 = [];
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          target = ref1[j];
          if (target !== null) {
            if (target.hasClass('toggle-target--active')) {
              target.removeClass('toggle-target--active');
              this.removeClass('toggle--active');
            } else {
              target.addClass('toggle-target--active');
              this.addClass('toggle--active');
            }
            results1.push(toggle.changeAttributes(target.querySelectorAll('.toggle-target')));
          } else {
            results1.push(void 0);
          }
        }
        return results1;
      }));
    }
    return results;
  }
};

milesPayment = {
  init: function() {
    var button, hidden, i, input, len, ref, results, wrapper, wrapperCheck, wrapperConfirm;
    ref = document.querySelectorAll('.js-miles-button');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      button = ref[i];
      wrapper = document.querySelector('.js-miles-wrapper');
      input = document.querySelector('.js-miles-input > input');
      hidden = 'h-display--none';
      wrapperConfirm = document.querySelector('.js-wrapper-confirm');
      wrapperCheck = document.querySelector('.js-wrapper-hide');
      results.push(button.addEventListener("click", function() {
        wrapper.removeClass('wrapper--opacity');
        wrapperCheck.removeClass(hidden);
        return wrapperConfirm.addClass(hidden);
      }));
    }
    return results;
  }
};

clearDate = {
  init: function() {
    var i, len, ref, results, returnHide, returnHideThis, returnIcon, returnInput, returnVisible;
    ref = document.querySelectorAll('.js-return-input > input');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      returnInput = ref[i];
      returnIcon = returnInput.parentNode.querySelector('.icon');
      returnVisible = function() {
        var returnCross;
        returnIcon.removeClass('icon--calendar');
        returnIcon.addClass('icon--cross-mini-blue');
        returnIcon.addClass('input__close');
        returnIcon.setAttribute('tabindex', 0);
        returnCross = returnInput.parentNode.querySelector('.input__close');
        returnCross.addEventListener("click", function() {
          return returnHideThis(this);
        });
        return returnCross.addEventListener("keydown", function(e) {
          if (e.keyCode === 13) {
            return returnHideThis(this);
          }
        });
      };
      returnHideThis = function(elem) {
        elem.addClass('icon--calendar');
        elem.removeClass('icon--cross-mini-blue');
        elem.removeClass('input__close');
        elem.removeAttribute('tabindex');
        return elem.parentNode.querySelector('input').value = '';
      };
      returnHide = function() {
        returnIcon.addClass('icon--calendar');
        returnIcon.removeClass('icon--cross-mini-blue');
        returnIcon.removeClass('input__close');
        return returnIcon.removeAttribute('tabindex');
      };
      returnInput.addEventListener("input", function() {
        if (returnInput.value.length > 0) {
          return returnVisible();
        } else {
          return returnHide();
        }
      });
      if (returnInput.value.length > 0) {
        results.push(returnVisible());
      } else {
        results.push(returnHide());
      }
    }
    return results;
  }
};

disableReturnDate = {
  init: function() {
    var i, len, ref, results, returnInputShowed, returnLink;
    returnInputShowed = true;
    ref = document.querySelectorAll('.js-return-link');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      returnLink = ref[i];
      results.push(returnLink.addEventListener("click", function(e) {
        var returnIcon, returnInput;
        e.preventDefault();
        returnInput = this.closest('fieldset').querySelector('.js-return-input > input');
        returnIcon = this.closest('fieldset').querySelector('.js-return-input .icon');
        returnInputShowed = !returnInputShowed;
        if (returnInputShowed === false) {
          returnInput.setAttribute('disabled', '');
          returnIcon.addClass('h-pointer-events--none');
          returnIcon.addClass('h-opacity--half');
          return this.innerHTML = 'Туда и обратно';
        } else {
          returnInput.removeAttribute('disabled');
          this.innerHTML = 'В одну сторону';
          returnIcon.removeClass('h-pointer-events--none');
          return returnIcon.removeClass('h-opacity--half');
        }
      }));
    }
    return results;
  }
};

datePickers = {
  init: function() {
    var ariaLabelСhangeable, datepickerInputs, datepickerInputsAll, datepickers, firstDay, format, i, i18n, j, k, len, len1, len2, maxDate, now, picker, position, reposition, results, theme, themeTwice, yearRange;
    now = new Date();
    now.setHours(0, 0, 0, 0);
    theme = 'aero-theme';
    themeTwice = 'aero-theme aero-theme-twice';
    format = 'DD.MM.YYYY';
    yearRange = [moment().format('YYYY'), moment().add(1, 'years').format('YYYY')];
    maxDate = moment().add(330, 'days')._d;
    firstDay = 1;
    reposition = true;
    position = 'bottom';
    i18n = {
      previousMonth: 'Предыдущий месяц',
      nextMonth: 'следующий месяц',
      months: ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
      weekdays: ['Воскресенье', 'Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота'],
      weekdaysShort: ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'],
      caption: 'Выберите год и месяц'
    };
    ariaLabelСhangeable = false;
    datepickers = [];
    datepickerInputs = document.querySelectorAll('.js-datepicker > input');
    for (i = 0, len = datepickerInputs.length; i < len; i++) {
      picker = datepickerInputs[i];
      picker.setAttribute('readonly', 'readonly');
      datepickers.push(new Pikaday({
        field: picker,
        theme: themeTwice,
        format: format,
        yearRange: yearRange,
        minDate: now,
        maxDate: maxDate,
        firstDay: firstDay,
        reposition: reposition,
        numberOfMonths: 2,
        position: position,
        i18n: i18n,
        disableDayFn: function(day) {
          day.setHours(0, 0, 0, 0);
          return day < now;
        },
        onOpen: function(day) {
          var j, len1, prev, prevDate, prevPicker, prevPickerDate, prevRow, prevRows, row, that, thatDate;
          that = this._o.field;
          thatDate = void 0;
          row = that.closest('fieldset');
          if (that.value !== '') {
            thatDate = that.value.split('.');
            thatDate = new Date(thatDate[2], thatDate[1] - 1, thatDate[0]);
            this.setDate(thatDate);
          }
          thatDate = this.getDate();
          prevRows = [];
          while (row.previousElementSibling && row.previousElementSibling.matches('fieldset')) {
            prevRows.push(row = row.previousElementSibling);
          }
          for (j = 0, len1 = prevRows.length; j < len1; j++) {
            prevRow = prevRows[j];
            prevPicker = prevRow.querySelector('.js-datepicker input');
            if (prevPicker.value !== '') {
              prevPickerDate = prevPicker.value.split('.');
              prevPickerDate = new Date(prevPickerDate[2], prevPickerDate[1] - 1, prevPickerDate[0]);
              this.setMinDate(prevPickerDate);
              if (thatDate < prevPickerDate) {
                this.setDate(prevPickerDate);
              }
            }
          }
          if (that.dataset.searchDropdownDirection === 'to') {
            prev = row.querySelector('[data-search-dropdown-direction="from"]');
            if (prev.value !== '') {
              prevDate = prev.value.split('.');
              prevDate = new Date(prevDate[2], prevDate[1] - 1, prevDate[0]);
              this.setMinDate(prevDate);
              if (thatDate < prevDate) {
                return this.setDate(prevDate);
              }
            }
          }
        },
        onSelect: function(day) {
          var j, len1, next, nextDate, nextPicker, nextPickerDate, nextRow, nextRows, row, that, thatDate;
          if (this._o.field.parentNode.hasClass('js-return-input')) {
            clearDate.init();
          }
          that = this._o.field;
          thatDate = this.getDate();
          row = that.closest('fieldset');
          nextRows = [];
          while (row.nextElementSibling && row.nextElementSibling.matches('fieldset')) {
            nextRows.push(row = row.nextElementSibling);
          }
          for (j = 0, len1 = nextRows.length; j < len1; j++) {
            nextRow = nextRows[j];
            nextPicker = nextRow.querySelector('.js-datepicker input');
            if (nextPicker.value !== '') {
              nextPickerDate = nextPicker.value.split('.');
              nextPickerDate = new Date(nextPickerDate[2], nextPickerDate[1] - 1, nextPickerDate[0]);
              if (thatDate > nextPickerDate) {
                nextPicker.value = that.value;
              }
            }
          }
          if (that.dataset.searchDropdownDirection === 'from') {
            next = row.querySelector('[data-search-dropdown-direction="to"]');
            if (next.value !== '') {
              nextDate = next.value.split('.');
              nextDate = new Date(nextDate[2], nextDate[1] - 1, nextDate[0]);
              if (thatDate > nextDate) {
                next.value = that.value;
              }
            }
          }
        },
        ariaLabelСhangeable: ariaLabelСhangeable
      }));
    }
    datepickerInputsAll = document.querySelectorAll('.js-datepicker-one-month > input');
    for (j = 0, len1 = datepickerInputsAll.length; j < len1; j++) {
      picker = datepickerInputsAll[j];
      picker.setAttribute('readonly', 'readonly');
      datepickers.push(new Pikaday({
        field: picker,
        theme: theme,
        format: format,
        yearRange: yearRange,
        minDate: now,
        maxDate: maxDate,
        firstDay: firstDay,
        reposition: reposition,
        position: position,
        i18n: i18n,
        disableDayFn: function(day) {
          day.setHours(0, 0, 0, 0);
          return day < now;
        },
        onSelect: function(day) {},
        ariaLabelСhangeable: ariaLabelСhangeable
      }));
    }
    datepickerInputsAll = document.querySelectorAll('.js-datepicker-all-select > input');
    results = [];
    for (k = 0, len2 = datepickerInputsAll.length; k < len2; k++) {
      picker = datepickerInputsAll[k];
      picker.setAttribute('readonly', 'readonly');
      results.push(datepickers.push(new Pikaday({
        field: picker,
        theme: theme,
        format: format,
        firstDay: firstDay,
        reposition: reposition,
        position: position,
        i18n: i18n,
        onSelect: function(day) {},
        ariaLabelСhangeable: ariaLabelСhangeable
      })));
    }
    return results;
  }
};

clearInput = {
  init: function() {
    var close, i, inputText, len, ref, results;
    if (window.innerWidth <= 600) {
      ref = document.querySelectorAll('.input__text:not(.js-datepicker):not(.js-datepicker-all-select):not(.input--arrow):not(.js-no-clear-input) input:not([readonly])');
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        inputText = ref[i];
        close = "<div class='icon input__icon input__icon--right icon--cross-mini-blue input__close input__close--hidden'></div>".toHTML();
        inputText.addEventListener("focus", function(e) {
          e.target.parentNode.appendChild(close);
          if (e.target.value.length > 0) {
            return close.removeClass('input__close--hidden');
          } else {
            return close.addClass('input__close--hidden');
          }
        });
        inputText.addEventListener("blur", function(e) {
          if (e.target.parentNode.close) {
            return close.addClass('input__close--hidden');
          }
        });
        inputText.addEventListener("input", function(e) {
          if (!e.target.parentNode.close) {
            e.target.parentNode.appendChild(close);
          }
          if (e.target.value.length > 0) {
            return close.removeClass('input__close--hidden');
          } else {
            return close.addClass('input__close--hidden');
          }
        });
        results.push(close.addEventListener("click", function(e) {
          e.input = e.target.parentNode.querySelectorAll('input')[0];
          this.addClass('input__close--hidden');
          e.input.focus();
          e.input.value = '';
          return close.remove();
        }));
      }
      return results;
    }
  }
};

maskerCard = {
  init: function() {
    return VMasker(document.querySelectorAll('.js-cardinput input')).maskPattern('9999-9999-9999-9999');
  }
};

toggleCheckbox = {
  init: function() {
    var buttonDisabled, checkbox, i, len, ref, results;
    ref = document.querySelectorAll('[data-check-target]');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      checkbox = ref[i];
      buttonDisabled = 'button--disabled';
      results.push(checkbox.addEventListener("change", function(e) {
        var button, target;
        target = e.target.dataset['checkTarget'];
        button = document.querySelector('[data-check-id="' + target + '"]');
        if (e.target.checked) {
          button.removeClass(buttonDisabled);
          button.setAttribute('aria-disabled', true);
          return button.removeAttribute('disabled');
        } else {
          button.addClass(buttonDisabled);
          button.setAttribute('aria-disabled', false);
          return button.setAttribute('disabled', '');
        }
      }));
    }
    return results;
  }
};

removeListener = function(el) {
  var elClone;
  elClone = el.cloneNode(true);
  if (el.parentNode) {
    return el.parentNode.replaceChild(elClone, el);
  }
};

window.addEventListener("resize", function() {
  return toggle.checkMobileAttributes();
});

document.addEventListener("DOMContentLoaded", function() {
  var unfocusedPage;
  userAgent.init();
  datePickers.init();
  login.init();
  if (document.getElementsByClassName('js-pending-payment-select')[0]) {
    changeOptions.init('.js-pending-payment-select', 'js-pending-payment');
  }
  if (document.getElementsByClassName('js-electron-payment-select')[0]) {
    changeOptions.init('.js-electron-payment-select', 'js-electron-payment');
  }
  getCertificate.init();
  toggle.init(document);
  toggle.checkMobileAttributes();
  milesPayment.init();
  maskerCard.init();
  clearInput.init();
  clearDate.init();
  unfocusedPage = document.getElementsByClassName('js-unfocusedPage')[0];
  if (unfocusedPage) {
    unfocused.init();
  }
  objectFitImages();
  toggleCheckbox.init();
  return disableReturnDate.init();
});

document.addEventListener("DOMContentLoaded", function() {
  if (!Array.from) {
    return Array.from = (function() {
      var isCallable, maxSafeInteger, toInteger, toLength, toStr;
      toStr = Object.prototype.toString;
      isCallable = function(fn) {
        return typeof fn === 'function' || toStr.call(fn) === '[object Function]';
      };
      toInteger = function(value) {
        var number;
        number = Number(value);
        if (isNaN(number)) {
          return 0;
        }
        if (number === 0 || !isFinite(number)) {
          return number;
        }
        return (number > 0 ? 1 : -1) * Math.floor(Math.abs(number));
      };
      maxSafeInteger = Math.pow(2, 53) - 1;
      toLength = function(value) {
        var len;
        len = toInteger(value);
        return Math.min(Math.max(len, 0), maxSafeInteger);
      };
      return function(arrayLike) {
        var A, C, T, items, k, kValue, len, mapFn;
        C = this;
        items = Object(arrayLike);
        if (arrayLike === null) {
          throw new TypeError('Array.from requires an array-like object - not null or undefined');
        }
        mapFn = arguments.length > 1 ? arguments[1] : void 0;
        T = void 0;
        if (typeof mapFn !== 'undefined') {
          if (!isCallable(mapFn)) {
            throw new TypeError('Array.from: when provided, the second argument must be a function');
          }
          if (arguments.length > 2) {
            T = arguments[2];
          }
        }
        len = toLength(items.length);
        A = isCallable(C) ? Object(new C(len)) : new Array(len);
        k = 0;
        kValue = void 0;
        while (k < len) {
          kValue = items[k];
          if (mapFn) {
            A[k] = typeof T === 'undefined' ? mapFn(kValue, k) : mapFn.call(T, kValue, k);
          } else {
            A[k] = kValue;
          }
          k += 1;
        }
        A.length = len;
        return A;
      };
    })();
  }
});

document.addEventListener("DOMContentLoaded", function() {
  window.accordion = {
    init: function() {
      var accordion, closeAccordion, expandAccordion, i, j, len, len1, open, ref, ref1;
      open = 'accordion__item--open';
      ref = document.getElementsByClassName('accordion__heading');
      for (i = 0, len = ref.length; i < len; i++) {
        accordion = ref[i];
        accordion.addEventListener("click", function(e) {
          var parentAccordion;
          parentAccordion = this.parentNode;
          if (parentAccordion.hasClass(open)) {
            return closeAccordion(parentAccordion);
          } else {
            closeAccordion(parentAccordion);
            return expandAccordion(parentAccordion);
          }
        });
      }
      ref1 = document.getElementsByClassName('accordion__item');
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        accordion = ref1[j];
        accordion.addEventListener('keydown', function(e) {
          var next, prev;
          e.stopPropagation();
          if (e.keyCode === 40 || e.keyCode === 39) {
            next = document.activeElement.next('accordion__item');
            if (next) {
              e.preventDefault();
              document.activeElement.setAttribute('tabindex', -1);
              next.setAttribute('tabindex', 0);
              next.focus();
            }
          }
          if (e.keyCode === 38 || e.keyCode === 37) {
            prev = document.activeElement.prev('accordion__item');
            if (prev) {
              e.preventDefault();
              document.activeElement.setAttribute('tabindex', -1);
              prev.setAttribute('tabindex', 0);
              prev.focus();
            }
          }
          if (e.keyCode === 13 && document.activeElement.hasClass('accordion__item')) {
            e.preventDefault();
            if (this.hasClass(open)) {
              return closeAccordion(this);
            } else {
              closeAccordion(this);
              return expandAccordion(this);
            }
          }
        });
      }
      closeAccordion = function(el) {
        var hide_opened, item, k, len2, ref2, results;
        ref2 = document.getElementsByClassName('accordion__item');
        results = [];
        for (k = 0, len2 = ref2.length; k < len2; k++) {
          item = ref2[k];
          if (item.querySelector(".accordion__inner")) {
            item.querySelector(".accordion__inner").style.height = '';
          }
          item.setAttribute('aria-expanded', false);
          item.setAttribute('tabindex', -1);
          el.setAttribute('tabindex', 0);
          item.removeClass(open);
          hide_opened = item.querySelector("[data-hide-opened]");
          if (hide_opened) {
            results.push(hide_opened.removeClass('h-display--none'));
          } else {
            results.push(void 0);
          }
        }
        return results;
      };
      return expandAccordion = function(el) {
        var hide_opened, itemCurrent;
        itemCurrent = el;
        itemCurrent.setAttribute('aria-expanded', true);
        itemCurrent.setAttribute('tabindex', 0);
        itemCurrent.addClass(open);
        hide_opened = itemCurrent.querySelector("[data-hide-opened]");
        if (hide_opened) {
          return hide_opened.addClass('h-display--none');
        }
      };
    }
  };
  return window.accordion.init();
});





var checkAvailabilityCard;

checkAvailabilityCard = function() {
  var card, element, i, len, ref, results;
  card = document.querySelector('.bank-card');
  if (!card) {
    return;
  }
  if (card.hasClass('bank-card--not-available')) {
    ref = card.querySelectorAll('.input__text-input, .input__select-input');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      element = ref[i];
      results.push(element.setAttribute('tabindex', '-1'));
    }
    return results;
  }
};

document.addEventListener("DOMContentLoaded", function() {
  return checkAvailabilityCard();
});



var blockCarousel;

blockCarousel = {
  params: {
    currentIndex: 0
  },
  init: function() {
    var activate, carouselParams, clearStyles, j, k, l, leftArrow, len, len1, len2, ref, ref1, ref2, results, rightArrow, swipe, swipeArea;
    carouselParams = this.params;
    clearStyles = function() {
      var carousel, child, j, len, ref, results;
      ref = document.querySelectorAll('.block-carousel .block-carousel__list');
      results = [];
      for (j = 0, len = ref.length; j < len; j++) {
        carousel = ref[j];
        carousel.removeAttribute('style');
        results.push((function() {
          var k, len1, ref1, results1;
          ref1 = carousel.children;
          results1 = [];
          for (k = 0, len1 = ref1.length; k < len1; k++) {
            child = ref1[k];
            results1.push(child.removeAttribute('style'));
          }
          return results1;
        })());
      }
      return results;
    };
    activate = function() {
      var carouselInner, carouselRoot, dataset, itemsnum, j, len, ratio, ref, results;
      ref = document.querySelectorAll('.block-carousel');
      results = [];
      for (j = 0, len = ref.length; j < len; j++) {
        carouselRoot = ref[j];
        carouselInner = carouselRoot.querySelector('.block-carousel__list');
        dataset = carouselRoot.dataset;
        itemsnum = dataset && dataset.itemsnum || 3;
        if (dataset && dataset.disableloop) {
          carouselParams.loop = false;
        } else {
          carouselParams.loop = true;
        }
        carouselParams.itemsnum = parseInt(itemsnum);
        carouselParams.childnum = carouselInner.children.length;
        if (window.innerWidth >= 800) {
          ratio = itemsnum;
        } else {
          ratio = 1;
        }
        carouselRoot.removeClass('block-carousel--enabled');
        carouselRoot.removeClass('block-carousel--disabled');
        blockCarousel.clearing();
        if (carouselInner.children.length > ratio) {
          carouselRoot.addClass('block-carousel--enabled');
          blockCarousel.build(carouselInner, itemsnum);
        } else {
          carouselRoot.addClass('block-carousel--disabled');
        }
        if (ratio > 1) {
          results.push(clearStyles());
        } else {
          results.push(void 0);
        }
      }
      return results;
    };
    activate();
    window.addEventListener("resize", function() {
      return activate();
    });
    ref = document.querySelectorAll('.block-carousel__arrow--left');
    for (j = 0, len = ref.length; j < len; j++) {
      leftArrow = ref[j];
      if (!carouselParams.loop) {
        leftArrow.classList.add('block-carousel__arrow--disabled');
      }
      leftArrow.addEventListener("click", function() {
        return blockCarousel.change(this.parentNode.parentNode.querySelector('.block-carousel__list'), 'prev');
      });
      leftArrow.addEventListener("keydown", function(e) {
        if (e.keyCode === 13) {
          return blockCarousel.change(this.parentNode.parentNode.querySelector('.block-carousel__list'), 'prev');
        }
      });
    }
    ref1 = document.querySelectorAll('.block-carousel__arrow--right');
    for (k = 0, len1 = ref1.length; k < len1; k++) {
      rightArrow = ref1[k];
      rightArrow.addEventListener("click", function() {
        return blockCarousel.change(this.parentNode.parentNode.querySelector('.block-carousel__list'), 'next');
      });
      rightArrow.addEventListener("keydown", function(e) {
        if (e.keyCode === 13) {
          return blockCarousel.change(this.parentNode.parentNode.querySelector('.block-carousel__list'), 'next');
        }
      });
    }
    ref2 = document.querySelectorAll('.block-carousel__list');
    results = [];
    for (l = 0, len2 = ref2.length; l < len2; l++) {
      swipeArea = ref2[l];
      if (swipeArea.parentNode.parentNode.hasClass('block-carousel--enabled')) {
        swipe = new Hammer(swipeArea);
        swipe.on('swipeleft', function(e) {
          blockCarousel.change(e.target.closest('.block-carousel__list'), 'next');
        });
        results.push(swipe.on('swiperight', function(e) {
          blockCarousel.change(e.target.closest('.block-carousel__list'), 'prev');
        }));
      } else {
        results.push(void 0);
      }
    }
    return results;
  },
  clearing: function() {
    var carouselDisabled, child, j, len, ref, results;
    ref = document.querySelectorAll('.block-carousel--disabled .block-carousel__list');
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      carouselDisabled = ref[j];
      carouselDisabled.removeAttribute('style');
      results.push((function() {
        var k, len1, ref1, results1;
        ref1 = carouselDisabled.children;
        results1 = [];
        for (k = 0, len1 = ref1.length; k < len1; k++) {
          child = ref1[k];
          results1.push(child.removeAttribute('style'));
        }
        return results1;
      })());
    }
    return results;
  },
  build: function(wrapper, itemsnum) {
    var activeChilds, childs, elemHeight, height, i, isAutoHeight, maxHeight, nrOfElements, ratio, root, width;
    root = wrapper.closest('.block-carousel');
    isAutoHeight = root.dataset && root.dataset.autoheight;
    width = 0;
    height = 0;
    maxHeight = 0;
    if (window.innerWidth >= 800) {
      ratio = itemsnum;
    } else {
      ratio = 1;
    }
    childs = Array.from(wrapper.children);
    nrOfElements = childs.length;
    maxHeight = 0;
    elemHeight = childs[0].offsetHeight;
    if (nrOfElements > 1) {
      maxHeight = elemHeight;
      i = 0;
      while (i < nrOfElements) {
        maxHeight = Math.max(maxHeight, childs[i].offsetHeight);
        i++;
      }
    }
    childs.forEach(function(element, index) {
      element.removeAttribute('data-carousel-active');
      element.setAttribute('aria-hidden', true);
      if (isAutoHeight) {
        element.style.height = maxHeight + 'px';
      }
      element.style.width = Math.abs(wrapper.parentNode.offsetWidth / ratio - (parseFloat(window.getComputedStyle(element).getPropertyValue('margin-left'))) - (parseFloat(window.getComputedStyle(element).getPropertyValue('margin-right'))) + (parseFloat(window.getComputedStyle(childs[ratio - 1]).getPropertyValue('margin-right')) / ratio)) + 'px';
      element.style.left = ((parseFloat(window.getComputedStyle(element).getPropertyValue('width'))) + (parseFloat(window.getComputedStyle(element).getPropertyValue('margin-left'))) + (parseFloat(window.getComputedStyle(element).getPropertyValue('margin-right')))) * index + 'px';
      width += element.offsetWidth;
      width += parseFloat(window.getComputedStyle(element).getPropertyValue('margin-left'));
      return width += parseFloat(window.getComputedStyle(element).getPropertyValue('margin-right'));
    });
    wrapper.style.width = width + 'px';
    if (window.innerWidth >= 800) {
      activeChilds = childs.slice(0, +(itemsnum - 1) + 1 || 9e9);
      activeChilds.forEach(function(element, index) {
        activeChilds[index].setAttribute('data-carousel-active', '');
        return element.setAttribute('aria-hidden', false);
      });
    } else {
      childs[0].setAttribute('data-carousel-active', '');
      childs[0].setAttribute('aria-hidden', false);
    }
    return wrapper.style.height = maxHeight + 'px';
  },
  change: function(elem, direction) {
    var activated, activeChilds, firstChild, lastChild, movedChilds, nextChild, nextIndex, prevChild, removable;
    if (!this.params.loop) {
      nextIndex = null;
      if (direction === 'next') {
        nextIndex = this.params.currentIndex + 1;
        if (((nextIndex + 1) + this.params.itemsnum) > this.params.childnum) {
          elem.parentNode.parentNode.querySelector('.block-carousel__arrow--right').classList.add('block-carousel__arrow--disabled');
        } else {
          elem.parentNode.parentNode.querySelector('.block-carousel__arrow--right').classList.remove('block-carousel__arrow--disabled');
          elem.parentNode.parentNode.querySelector('.block-carousel__arrow--left').classList.remove('block-carousel__arrow--disabled');
        }
      } else if (direction === 'prev') {
        nextIndex = this.params.currentIndex - 1;
        if (nextIndex - 1 < 0) {
          elem.parentNode.parentNode.querySelector('.block-carousel__arrow--left').classList.add('block-carousel__arrow--disabled');
        } else {
          elem.parentNode.parentNode.querySelector('.block-carousel__arrow--right').classList.remove('block-carousel__arrow--disabled');
          elem.parentNode.parentNode.querySelector('.block-carousel__arrow--left').classList.remove('block-carousel__arrow--disabled');
        }
      }
      if (nextIndex < 0 || (nextIndex + this.params.itemsnum) > this.params.childnum) {
        return;
      }
    }
    firstChild = 0;
    lastChild = 0;
    activeChilds = Array.from(elem.querySelectorAll('[data-carousel-active]'));
    activeChilds.forEach(function(element, index) {
      firstChild = activeChilds[0];
      lastChild = activeChilds[activeChilds.length - 1];
      return element.style.transition = 'left .35s';
    });
    prevChild = 0;
    nextChild = 0;
    if (firstChild.previousElementSibling !== null) {
      prevChild = firstChild.previousElementSibling;
    } else {
      prevChild = elem.lastElementChild;
    }
    if (lastChild.nextElementSibling !== null) {
      nextChild = lastChild.nextElementSibling;
    } else {
      nextChild = elem.firstElementChild;
    }
    if (direction === 'next') {
      this.params.currentIndex++;
      activated = nextChild;
      removable = firstChild;
      elem.insertBefore(elem.firstElementChild, elem.lastElementChild.nextSibling);
      activated.style.transition = '';
      activated.style.left = (activated.getRelativeClientRect().width + lastChild.getRelativeClientRect(elem).left) + 'px';
      activated.offsetWidth;
    } else if (direction === 'prev') {
      this.params.currentIndex--;
      activated = prevChild;
      removable = lastChild;
      elem.insertBefore(elem.lastElementChild, elem.firstElementChild);
      activated.style.left = -(activated.getRelativeClientRect().width + (parseFloat(window.getComputedStyle(activated).getPropertyValue('margin-left'))) + (parseFloat(window.getComputedStyle(activated).getPropertyValue('margin-right')))) + 'px';
      activated.offsetWidth;
    }
    activated.setAttribute('data-carousel-active', '');
    activated.setAttribute('aria-hidden', false);
    if (removable) {
      removable.removeAttribute('data-carousel-active');
      activated.setAttribute('aria-hidden', true);
    }
    activated.style.transition = 'left .3s';
    movedChilds = Array.from(elem.children);
    movedChilds.forEach(function(element, index) {
      return element.style.left = (element.getRelativeClientRect().width + (parseFloat(window.getComputedStyle(element).getPropertyValue('margin-left'))) + (parseFloat(window.getComputedStyle(element).getPropertyValue('margin-right')))) * index + 'px';
    });
    if (direction === 'next') {
      removable.style.left = -(removable.getRelativeClientRect().width + (parseFloat(window.getComputedStyle(removable).getPropertyValue('margin-left'))) + (parseFloat(window.getComputedStyle(removable).getPropertyValue('margin-right')))) + 'px';
    }
    return delay(300, function() {
      return removable.style.transition = '';
    });
  }
};

document.addEventListener("DOMContentLoaded", function() {
  return blockCarousel.init();
});



var carousel, itemActive, itemAfter, itemBefore, listItem, listItemActive, listNavPreview;

carousel = {};

carousel.number = 0;

carousel.wrapClass = 'carousel';

carousel.inner = document.getElementsByClassName('carousel__inner');

carousel.slides = document.getElementsByClassName('carousel__item');

carousel.nav = document.getElementsByClassName('carousel__nav')[0];

carousel.nameClass = 'js-carousel-name';

carousel.navItem = [];

itemActive = 'carousel__item--active';

itemBefore = 'carousel__item--before';

itemAfter = 'carousel__item--after';

listItem = 'carousel__nav-item';

listNavPreview = 'carousel__nav--preview';

listItemActive = 'carousel__nav-item--active';

carousel.navigation = function(obj) {
  var children, i, index;
  children = this.parentNode.childNodes;
  index = 0;
  i = 0;
  while (i < children.length) {
    index = i;
    if (this === children[i]) {
      break;
    }
    i++;
  }
  carousel.nav = index;
  return carousel.change('manual');
};

carousel.change = function(value) {
  var el, j, len, name, nextItem, prevItem, ref;
  prevItem = function() {
    if (null === carousel.slides[carousel.number].previousElementSibling) {
      return carousel.slides[carousel.number].parentNode.lastElementChild;
    } else {
      return carousel.slides[carousel.number].previousElementSibling;
    }
  };
  nextItem = function() {
    if (null === carousel.slides[carousel.number].nextElementSibling) {
      return carousel.slides[carousel.number].parentNode.children[0];
    } else {
      return carousel.slides[carousel.number].nextElementSibling;
    }
  };
  prevItem().removeClass(itemBefore);
  nextItem().removeClass(itemAfter);
  carousel.slides[carousel.number].removeClass(itemActive);
  carousel.navItem[carousel.number].className = listItem;
  if (carousel.number + value > carousel.slides.length - 1) {
    carousel.number = 0;
  } else if (carousel.number + value < 0) {
    carousel.number = carousel.slides.length - 1;
  } else if (value === 'manual') {
    carousel.number = carousel.nav;
  } else {
    carousel.number += value;
  }
  carousel.slides[carousel.number].className += ' ' + itemActive;
  prevItem().className += ' ' + itemBefore;
  nextItem().className += ' ' + itemAfter;
  carousel.navItem[carousel.number].className += ' ' + listItemActive;
  name = carousel.slides[carousel.number].getAttribute('data-name');
  document.getElementsByClassName(carousel.nameClass)[0].innerHTML = name;
  ref = carousel.slides;
  for (j = 0, len = ref.length; j < len; j++) {
    el = ref[j];
    if (el.hasClass('carousel__item--active')) {
      el.setAttribute('aria-hidden', false);
    } else {
      el.setAttribute('aria-hidden', true);
    }
    if (el.hasClass('carousel__item--before') || el.hasClass('carousel__item--after')) {
      el.setAttribute('aria-live', 'polite');
      el.setAttribute('role', 'status');
    } else {
      el.removeAttribute('aria-live');
      el.removeAttribute('role');
    }
  }
};

carousel.init = function() {
  var carouselHeight, i, imgs, j, k, len, len1, navItem, ref, ref1, swipe;
  if (carousel.slides.length > 2) {
    i = 0;
    while (i < carousel.slides.length) {
      carousel.navItem[i] = document.getElementsByClassName('carousel__nav')[0].appendChild(document.createElement('li'));
      if (document.getElementsByClassName(carousel.wrapClass)[0].getAttribute('data-nav') === 'preview') {
        carousel.navItem[i].innerHTML = '<img src=' + carousel.slides[i].children[0].getAttribute('src') + ' class="carousel__nav-item-img" />';
        document.getElementsByClassName('carousel__nav')[0].className += ' ' + listNavPreview;
      }
      carousel.navItem[i].className = listItem;
      i++;
    }
    carousel.slides[0].className += ' ' + itemActive;
    carousel.slides[0].setAttribute('aria-hidden', false);
    carousel.slides[carousel.slides.length - 1].className += ' ' + itemBefore;
    carousel.slides[carousel.slides.length - 1].setAttribute('aria-live', 'polite');
    carousel.slides[carousel.slides.length - 1].setAttribute('role', 'status');
    carousel.slides[0].nextElementSibling.className += ' ' + itemAfter;
    carousel.slides[0].nextElementSibling.setAttribute('aria-live', 'polite');
    carousel.slides[0].nextElementSibling.setAttribute('role', 'status');
    carousel.navItem[0].className += ' ' + listItemActive;
    ref = carousel.slides;
    for (j = 0, len = ref.length; j < len; j++) {
      imgs = ref[j];
      carouselHeight = function() {
        var minHeight;
        minHeight = carousel.slides[carousel.number].children[0].offsetHeight;
        return carousel.inner[0].style.height = minHeight + 'px';
      };
      carouselHeight();
      window.addEventListener("resize", function() {
        return carouselHeight();
      });
    }
    ref1 = carousel.navItem;
    for (k = 0, len1 = ref1.length; k < len1; k++) {
      navItem = ref1[k];
      navItem.addEventListener("click", carousel.navigation);
    }
    carousel.left = document.getElementsByClassName('carousel__arrow--left');
    carousel.right = document.getElementsByClassName('carousel__arrow--right');
    swipe = new Hammer(carousel.inner[0]);
    carousel.left[0].addEventListener("click", function() {
      carousel.change(-1);
      return carouselHeight();
    });
    carousel.right[0].addEventListener("click", function() {
      carousel.change(1);
      return carouselHeight();
    });
    carousel.left[0].addEventListener("keydown", function(e) {
      if (e.keyCode === 13) {
        carousel.change(-1);
      }
      return carouselHeight();
    });
    carousel.right[0].addEventListener("keydown", function(e) {
      if (e.keyCode === 13) {
        carousel.change(1);
      }
      return carouselHeight();
    });
    swipe.on('swipeleft', function(ev) {
      carousel.change(1);
    });
    return swipe.on('swiperight', function(ev) {
      carousel.change(-1);
    });
  } else if (carousel.inner.length > 0) {
    return carousel.inner[0].parentNode.addClass('carousel--disabled');
  }
};

if (screen.width <= 768 && isTouchDevice()) {
  window.addEventListener("load", function() {
    return carousel.init();
  });
} else {
  document.addEventListener("DOMContentLoaded", function() {
    return carousel.init();
  });
}

var addСollapseCart, cartContainer, cartItemChoicePriceHighlited, cartItemCollapsed, cartItemHidden, cartItemOpen, changeAttributesElementCart, checkHeightCart, checkСollapseCart, closeElementCart, closeHighlightPrices, collapseCartElement, getPriceCLassByColor, highlightPrices, openElementCart, removeСollapseCart, seatHighlightedClass;

document.addEventListener("DOMContentLoaded", function() {
  var cart, isNoFloating, passengerCurrent, positionPassengerName, seatingName, seatingPassengerSelected;
  cart = document.querySelector('.cart');
  if (cart) {
    isNoFloating = cart.classList.contains('cart--nofloating');
  }
  passengerCurrent = document.querySelector('.cart__item-passenger--current');
  seatingName = document.querySelector('.seating__title');
  seatingPassengerSelected = document.querySelector('.seating__passenger--selected');
  if (!isNoFloating) {
    positionPassengerName = function() {
      if (!seatingName) {
        return;
      }
      if (seatingName.getBoundingClientRect().top < 0) {
        passengerCurrent.firstElementChild.classList.add('cart__item-passenger-inner--floating');
        if (seatingPassengerSelected) {
          return passengerCurrent.firstElementChild.classList.add('cart__item-passenger-inner--selected');
        }
      } else {
        passengerCurrent.firstElementChild.classList.remove('cart__item-passenger-inner--floating');
        return passengerCurrent.firstElementChild.classList.remove('cart__item-passenger-inner--selected');
      }
    };
    return window.addEventListener("scroll", function() {
      return positionPassengerName();
    });
  }
});

cartItemCollapsed = 'cart__item--collapsed';

cartItemOpen = 'cart__item--open';

cartContainer = 'cart__item-container';

cartItemHidden = 'cart__item-hidden';

seatHighlightedClass = 'seating__place--color-highlite';

cartItemChoicePriceHighlited = 'cart__item-choice-price--highlite';

checkHeightCart = function(cartContent) {
  var body, cartContentTop, heightCart, heightWindow;
  body = document.getElementsByTagName('body')[0];
  heightCart = cartContent.offsetHeight;
  cartContentTop = cartContent.getRelativeClientRect(body).top;
  heightWindow = document.documentElement.clientHeight - cartContentTop;
  return heightCart > heightWindow;
};

changeAttributesElementCart = function(element, classNameVisibleElement, classNameHiddenElement) {
  element.querySelector('.' + classNameVisibleElement).setAttribute('aria-hidden', 'false');
  return element.querySelector('.' + classNameHiddenElement).setAttribute('aria-hidden', 'true');
};

openElementCart = function(e) {
  e.target.classList.add(cartItemOpen);
  return changeAttributesElementCart(e.target, cartContainer, cartItemHidden);
};

closeElementCart = function(e) {
  e.target.classList.remove(cartItemOpen);
  return changeAttributesElementCart(e.target, cartItemHidden, cartContainer);
};

addСollapseCart = function(cartItem, cartItemCollapsed, cartContainer, cartItemHidden) {
  cartItem.classList.add(cartItemCollapsed);
  cartItem.addEventListener('mouseenter', openElementCart);
  cartItem.addEventListener('mouseleave', closeElementCart);
  cartItem.addEventListener('focus', openElementCart);
  cartItem.addEventListener('blur', closeElementCart);
  return changeAttributesElementCart(cartItem, cartItemHidden, cartContainer);
};

removeСollapseCart = function(cartItem, cartItemCollapsed, cartContainer, cartItemHidden) {
  cartItem.classList.remove(cartItemCollapsed);
  cartItem.removeEventListener('mouseenter', openElementCart);
  cartItem.removeEventListener('mouseleave', closeElementCart);
  cartItem.removeEventListener('focus', openElementCart);
  cartItem.removeEventListener('blur', closeElementCart);
  return changeAttributesElementCart(cartItem, cartContainer, cartItemHidden);
};

checkСollapseCart = function() {
  var cartCollapsed;
  cartCollapsed = document.getElementsByClassName(cartItemCollapsed)[0];
  return cartCollapsed;
};

collapseCartElement = function() {
  var cart, cartContent, cartItems, i, j, ref, results;
  cart = document.querySelector('.cart');
  if (!cart) {
    return;
  }
  cartContent = cart.querySelector('.cart__content');
  cartItems = cartContent.querySelectorAll('.js-cart-item');
  if (cartItems.length === 0) {
    return;
  }
  results = [];
  for (i = j = ref = cartItems.length - 1; ref <= 0 ? j <= 0 : j >= 0; i = ref <= 0 ? ++j : --j) {
    if (checkHeightCart(cartContent)) {
      results.push(addСollapseCart(cartItems[i], cartItemCollapsed, cartContainer, cartItemHidden));
    } else {
      removeСollapseCart(cartItems[i], cartItemCollapsed, cartContainer, cartItemHidden);
      if (checkHeightCart(cartContent)) {
        results.push(addСollapseCart(cartItems[i], cartItemCollapsed, cartContainer, cartItemHidden));
      } else {
        results.push(void 0);
      }
    }
  }
  return results;
};

getPriceCLassByColor = function(style) {
  var colorClass, colorNum, priceColor;
  priceColor = style.cssText;
  colorNum = priceColor.match(/\d+/g).join('');
  colorClass = ".seating__place--color-" + colorNum;
  return colorClass;
};

highlightPrices = function() {
  var colorClass, j, len, place, ref, results;
  if (this.style) {
    colorClass = getPriceCLassByColor(this.style);
    this.classList.add(cartItemChoicePriceHighlited);
    ref = document.querySelectorAll(colorClass);
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      place = ref[j];
      results.push(place.classList.add(seatHighlightedClass));
    }
    return results;
  }
};

closeHighlightPrices = function() {
  var colorClass, j, len, place, ref, results;
  if (this.style) {
    colorClass = getPriceCLassByColor(this.style);
    if (this.classList.contains(cartItemChoicePriceHighlited)) {
      this.classList.remove(cartItemChoicePriceHighlited);
    }
    ref = document.querySelectorAll(colorClass);
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      place = ref[j];
      if (place.classList.contains(seatHighlightedClass)) {
        results.push(place.classList.remove(seatHighlightedClass));
      } else {
        results.push(void 0);
      }
    }
    return results;
  }
};

document.addEventListener("DOMContentLoaded", function() {
  var item, j, len, ref, results;
  ref = document.querySelectorAll('.js-collapsed-items-cart');
  results = [];
  for (j = 0, len = ref.length; j < len; j++) {
    item = ref[j];
    results.push(item.addEventListener('click', function() {
      return collapseCartElement();
    }));
  }
  return results;
});

document.addEventListener("DOMContentLoaded", function() {
  return collapseCartElement();
});

document.addEventListener("DOMContentLoaded", function() {
  var body, choicePrice, counter, floatEl, floatElRect, floatElTop, footer, footerTop, item, j, len, ref, stickyCart;
  item = document.getElementsByClassName('cart__item--active')[0];
  ref = document.querySelectorAll('.cart__item-choice-price');
  for (j = 0, len = ref.length; j < len; j++) {
    choicePrice = ref[j];
    choicePrice.addEventListener('mouseenter', highlightPrices);
    choicePrice.addEventListener('mouseleave', closeHighlightPrices);
  }
  if (item) {
    item.addEventListener("click", function(e) {
      var cart;
      cart = e.currentTarget.parentNode.parentNode;
      if (cart.hasClass('cart--uncollapse')) {
        return cart.removeClass('cart--uncollapse');
      } else {
        return cart.addClass('cart--uncollapse');
      }
    });
  }
  floatEl = document.getElementsByClassName('js-float')[0];
  if (floatEl) {
    body = document.getElementsByTagName('body')[0];
    floatElRect = floatEl.getRelativeClientRect(body);
    floatElTop = floatEl.getRelativeClientRect(body).top;
    footer = document.getElementsByClassName('footer')[0];
    footerTop = footer.getRelativeClientRect(body).top;
    counter = floatEl.parentNode.getElementsByClassName('js-counter')[0];
    stickyCart = function() {
      footerTop = footer.getRelativeClientRect(body).top;
      var floatElHeight;
      floatElHeight = floatEl.offsetHeight;
      if (!checkСollapseCart()) {
        if (window.innerWidth > 1050) {
          floatEl.parentNode.style.minHeight = floatElHeight + 'px';
          floatEl.parentNode.style.position = 'relative';
          if ((window.scrollY || document.documentElement.scrollTop) > footerTop - floatElHeight - 32) {
            floatEl.style.position = 'absolute';
            return floatEl.style.top = (footerTop - floatElHeight - floatElTop - 32) + 'px';
          } else if ((window.scrollY || document.documentElement.scrollTop) > floatElTop + 15) {
            floatEl.style.position = 'absolute';
            floatEl.style.top = ((window.scrollY || document.documentElement.scrollTop) - floatElTop + 15) + 'px';
            if (floatEl.parentNode.parentNode.offsetHeight <= floatElHeight) {
              floatEl.style.position = 'relative';
              floatEl.style.top = 0;
            }
          } else {
            floatEl.style.position = 'relative';
            return floatEl.style.top = 0;
          }
        } else {
          floatEl.style.position = 'static';
          return floatEl.parentNode.style.minHeight = '';
        }
      }
    };
    stickyCart();
    window.addEventListener("scroll", function(e) {
      return stickyCart();
    });
    return window.addEventListener("resize", function(e) {
      return stickyCart();
    });
  }
});

document.addEventListener("DOMContentLoaded", function() {
  var button, buttonActive, checkCertificate, i, len, ref, results;
  ref = document.querySelectorAll('.certificate__check > input');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    checkCertificate = ref[i];
    button = document.querySelectorAll('.certificate__confirm-button')[0];
    buttonActive = 'certificate__confirm-button--active';
    results.push(checkCertificate.addEventListener("change", function(e) {
      var thisParent;
      thisParent = this.parentNode.parentNode;
      if (this.checked) {
        button.addClass(buttonActive);
        return button.setAttribute('aria-disabled', true);
      } else if (button.hasClass(buttonActive)) {
        button.removeClass(buttonActive);
        return button.setAttribute('aria-disabled', false);
      }
    }));
  }
  return results;
});





document.addEventListener("DOMContentLoaded", function() {
  var cartToggler, counter, counterInner, footer, positionCounter, prevElement;
  counter = document.getElementsByClassName('js-counter')[0];
  counterInner = document.querySelectorAll('.js-counter .counter__inner')[0];
  if (!counter) {
    return;
  }
  prevElement = counter.previousElementSibling;
  footer = document.getElementsByClassName('footer')[0];
  cartToggler = document.querySelectorAll('[data-toggle-target="cart-booking"]')[0];
  positionCounter = function() {
    var counterDocumentTop, footerDocumentTop, prevDocumentTop;
    if (window.innerWidth < 1050) {
      prevDocumentTop = prevElement.getRelativeClientRect(window.document.body).top + prevElement.offsetHeight;
      counterInner.style = '';
      if ((window.scrollY || document.documentElement.scrollTop) > counter.getRelativeClientRect(window.document.body).top) {
        counter.addClass('counter--fixed');
      }
      if ((window.scrollY || document.documentElement.scrollTop) < prevDocumentTop) {
        return counter.removeClass('counter--fixed');
      }
    } else {
      counterDocumentTop = counterInner.getRelativeClientRect(window.document.body).top;
      prevDocumentTop = prevElement.getRelativeClientRect(window.document.body).top + prevElement.offsetHeight;
      footerDocumentTop = footer.getRelativeClientRect(window.document.body).top;
      if (counterDocumentTop + 140 > footerDocumentTop && counterDocumentTop > prevDocumentTop + counterInner.offsetHeight) {
        counterInner.style.position = 'absolute';
        counterInner.style.top = footerDocumentTop - 240 + 'px';
      }
      if ((window.scrollY + window.innerHeight || document.documentElement.scrollTop + window.innerHeight) > prevDocumentTop + counterInner.offsetHeight + 32 && (window.scrollY + window.innerHeight || document.documentElement.scrollTop + window.innerHeight) < footerDocumentTop) {
        counterInner.style.position = 'fixed';
        return counterInner.style.top = 'auto';
      }
    }
  };
  if (!cartToggler) {
    positionCounter();
    window.addEventListener("scroll", function(e) {
      return positionCounter();
    });
    return window.addEventListener("resize", function(e) {
      return positionCounter();
    });
  }
});

window.initDirectionMap = function() {
  var activeTransfer, circle, circleBlue, city, cityInfo, cityLatLng, collapseMap, directionMap, directionMapCloseButton, flightPath, from, from_lat, i, index, len, map, map_lat, marker, to, to_lat, transfers;
  directionMap = document.getElementById('direction-map');
  if (directionMap && directionMap.dataset.from && directionMap.dataset.to && directionMap.dataset.transfers) {
    from = JSON.parse(directionMap.dataset.from);
    from_lat = new google.maps.LatLng(from[0], from[1]);
    to = JSON.parse(directionMap.dataset.to);
    to_lat = new google.maps.LatLng(to[0], to[1]);
    transfers = JSON.parse(directionMap.dataset.transfers);
    map_lat = new google.maps.LatLng((from[0] - to[0]) / 2 + to[0], (from[1] - to[1]) / 2 + to[1]);
    map = new google.maps.Map(directionMap, {
      zoom: 3,
      scrollwheel: false,
      disableDefaultUI: true
    });
    circle = {
      path: google.maps.SymbolPath.CIRCLE,
      fillColor: '#E87722',
      fillOpacity: 1,
      strokeWeight: 2,
      scale: 7,
      strokeColor: '#ffffff'
    };
    circleBlue = {
      path: google.maps.SymbolPath.CIRCLE,
      fillColor: '#4A90E2',
      fillOpacity: 1,
      strokeWeight: 2,
      scale: 7,
      strokeColor: '#ffffff'
    };
    activeTransfer = new google.maps.LatLng(transfers[0].latlng[0], transfers[0].latlng[1]);
    flightPath = new google.maps.Polyline({
      path: [from_lat, activeTransfer, to_lat],
      geodesic: true,
      strokeColor: '#4A90E2',
      strokeOpacity: 1,
      strokeWeight: 2
    });
    flightPath.setMap(map);
    for (index = i = 0, len = transfers.length; i < len; index = ++i) {
      city = transfers[index];
      cityInfo = city.latlng;
      cityLatLng = new google.maps.LatLng(cityInfo[0], cityInfo[1]);
      marker = new google.maps.Marker({
        position: cityLatLng,
        zIndex: 1,
        map: map,
        icon: circleBlue
      });
      marker.addListener("mouseover", function(e) {
        return this.setZIndex(2);
      });
      marker.addListener("mouseout", function(e) {
        return this.setZIndex(1);
      });
      marker.addListener("click", function(e) {
        var position;
        position = this.getPosition();
        return flightPath.setPath([from_lat, position, to_lat]);
      });
    }
    new google.maps.Marker({
      position: from_lat,
      map: map,
      icon: circle
    });
    new google.maps.Marker({
      position: to_lat,
      map: map,
      icon: circle
    });
    map.setCenter(map_lat);
    collapseMap = function() {
      var mapButton;
      map.setOptions({
        zoom: 2,
        mapTypeControl: false,
        zoomControl: false
      });
      mapButton = document.querySelector('.js-direction-map-button');
      if (mapButton) {
        return mapButton.addEventListener('click', function(e) {
          e.preventDefault();
          map.setOptions({
            zoom: 3,
            mapTypeControl: true,
            zoomControl: true,
            center: map_lat
          });
          document.querySelector('.js-direction-map-exprired').addClass('frame__expired--hidden');
          document.querySelector('.direction-map').removeClass('direction-map--minimize');
          return delay(360, function() {
            google.maps.event.trigger(map, 'resize');
            return map.setCenter(map_lat);
          });
        });
      }
    };
    directionMapCloseButton = document.getElementsByClassName('direction-map__close');
    if (directionMapCloseButton.length > 0) {
      directionMapCloseButton[0].addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector('.direction-map').addClass('direction-map--minimize');
        return document.querySelector('.js-direction-map-exprired').removeClass('frame__expired--hidden');
      });
    }
    if (directionMap.hasData('collapse')) {
      return collapseMap();
    }
  }
};

document.addEventListener("DOMContentLoaded", function(e) {
  return window.initDirectionMap();
});



var dropdownFullScreenBreakpoint;

dropdownFullScreenBreakpoint = 767;

document.addEventListener("DOMContentLoaded", function() {
  window.dropdown = {
    init: function() {
      var arrow, body, dropdown, el, i, len, ref, showDropdown;
      ref = document.querySelectorAll('[data-dropdown]');
      for (i = 0, len = ref.length; i < len; i++) {
        el = ref[i];
        el.setAttribute('aria-expanded', false);
        dropdown = document.querySelectorAll('[data-dropdown-id="' + el.dataset.dropdownTarget + '"]')[0];
        body = document.getElementsByTagName('body')[0];
        body.appendChild(dropdown);
        arrow = 'dropdown--arrow-' + (el.dataset.dropdownArrow ? el.dataset.dropdownArrow : 'right');
        dropdown.addClass(arrow);
        if (el.dataset.dropdownWidth) {
          dropdown.style.width = el.dataset.dropdownWidth + 'px';
        }
        showDropdown = function(e, handler, target) {
          var activeItemClass, changeFocus, dropdownItems, dropdownWrapper, elem, firstChildDropdown, itemClass, j, k, len1, len2, ref1, ref2, toggleActiveItem;
          if (target.hasClass('dropdown--show') && !(e.target.dataset.dropdownTarget = target.id) && (handler.dataset.showed = true)) {
            target.removeClass('dropdown--show');
            target.setAttribute('aria-expanded', false);
            handler.setAttribute('aria-expanded', false);
            target.setAttribute('tabindex', -1);
            this.dataset.showed = false;
          } else {
            window.dropdown.hideDropdowns(false);
            window.dropdown.positionDropdown(handler, target);
            target.querySelector('.dropdown__overlay').style.display = 'block';
            target.addClass('dropdown--show');
            target.setAttribute('aria-expanded', true);
            handler.setAttribute('aria-expanded', true);
            target.setAttribute('tabindex', 0);
            handler.dataset.showed = true;
            itemClass = 'dropdown__items-item';
            dropdownItems = target.querySelectorAll('.' + itemClass);
            firstChildDropdown = dropdownItems[0];
            changeFocus = function(next, current) {
              if (current) {
                current.removeAttribute('tabindex');
              }
              next.setAttribute('tabindex', 0);
              return next.focus();
            };
            handler.addEventListener('keydown', function(e) {
              if (e.keyCode === 40 || e.keyCode === 38) {
                e.preventDefault();
              }
              if ((e.keyCode === 40 || e.keyCode === 38 || e.keyCode === 9) && !(document.activeElement.closest('.dropdown')) && firstChildDropdown) {
                return changeFocus(firstChildDropdown);
              }
            });
            target.addEventListener('keydown', function(e) {
              if (document.activeElement.closest('.' + itemClass)) {
                if (e.keyCode === 40) {
                  e.preventDefault();
                  if (document.activeElement.next(itemClass)) {
                    return changeFocus(document.activeElement.next(itemClass), document.activeElement);
                  }
                } else if (e.keyCode === 38) {
                  e.preventDefault();
                  if (document.activeElement.prev(itemClass)) {
                    return changeFocus(document.activeElement.prev(itemClass), document.activeElement);
                  }
                }
              }
            });
          }
          if (handler.dataset.showed = true) {
            activeItemClass = 'dropdown__items-item--active';
            ref1 = document.querySelectorAll('.dropdown__items--clickable');
            for (j = 0, len1 = ref1.length; j < len1; j++) {
              dropdownWrapper = ref1[j];
              toggleActiveItem = function(item) {
                var k, len2, ref2, results, toggler;
                ref2 = item.parentNode.querySelectorAll('.dropdown__items-item');
                results = [];
                for (k = 0, len2 = ref2.length; k < len2; k++) {
                  toggler = ref2[k];
                  toggler.removeClass(activeItemClass);
                  toggler.setAttribute('aria-selected', false);
                  toggler.removeAttribute('tabindex');
                  item.addClass(activeItemClass);
                  item.setAttribute('aria-selected', true);
                  results.push(item.setAttribute('tabindex', 0));
                }
                return results;
              };
              ref2 = dropdownWrapper.querySelectorAll('.dropdown__items-item');
              for (k = 0, len2 = ref2.length; k < len2; k++) {
                elem = ref2[k];
                elem.addEventListener("click", function(e) {
                  return toggleActiveItem(this);
                });
                elem.addEventListener("keydown", function(e) {
                  if (e.keyCode === 13) {
                    return toggleActiveItem(this);
                  }
                });
              }
            }
          }
          return false;
        };
        el.addEventListener('click', function(e) {
          var isDropdownOpened, selfClosing, targetDropdown;
          targetDropdown = document.querySelectorAll('[data-dropdown-id="' + this.dataset.dropdownTarget + '"]')[0];
          e.preventDefault();
          selfClosing = this.dataset && this.dataset.selfclosing ? true : false;
          if (selfClosing) {
            isDropdownOpened = targetDropdown.classList.contains('dropdown--show');
            if (isDropdownOpened) {
              return window.dropdown.hideDropdowns(true);
            } else {
              return showDropdown(e, this, targetDropdown);
            }
          } else {
            return showDropdown(e, this, targetDropdown);
          }
        });
        el.addEventListener('keydown', function(e) {
          var targetDropdown;
          targetDropdown = document.querySelectorAll('[data-dropdown-id="' + this.dataset.dropdownTarget + '"]')[0];
          if (e.keyCode === 9) {
            if (this.dataset.showed === 'true') {
              e.preventDefault();
              return targetDropdown.focus();
            }
          } else if (e.keyCode === 27) {
            return window.dropdown.hideDropdowns();
          }
        });
        dropdown.addEventListener('keydown', function(e) {
          var active, dropdownParent;
          dropdownParent = document.querySelectorAll('[data-dropdown-target="' + this.dataset.dropdownId + '"]')[0];
          active = document.activeElement;
          if (window.dropdown.inDropdown(e.target) && ((e.keyCode === 27) || (e.target.hasClass('dropdown__close') && e.keyCode === 13) || (e.shiftKey && e.keyCode === 9 && active.hasClass('dropdown')))) {
            e.preventDefault();
            return dropdownParent.focus();
          }
        });
      }
      document.body.addEventListener("click", function(e) {
        if (e.target.hasClass('dropdown__close')) {
          e.preventDefault();
          window.dropdown.hideDropdowns(true);
        }
        if ((e.target != null) && !e.target.dataset.dropdown && !window.dropdown.inDropdown(e.target) || e.target.hasClass('dropdown__overlay')) {
          return window.dropdown.hideDropdowns(true);
        }
      });
      document.body.addEventListener("touchstart", function(e) {
        if ((e.target != null) && !e.target.dataset.dropdown && !window.dropdown.inDropdown(e.target) || e.target.hasClass('dropdown__overlay')) {
          return window.dropdown.hideDropdowns(true);
        } else {
          return true;
        }
      });
      return document.addEventListener('keydown', function(e) {
        if (e.keyCode === 27 || (e.target.hasClass('dropdown__close') && e.keyCode === 13)) {
          return window.dropdown.hideDropdowns(true);
        }
      });
    },
    positionDropdown: function(handler, target) {
      var algorhitmX, algorhitmY, arrowHeight, body, offsetX, rects, rightShift, topShift;
      arrowHeight = 10;
      body = document.getElementsByTagName('body')[0];
      topShift = handler.getRelativeClientRect(body).top + handler.offsetHeight + arrowHeight;
      algorhitmX = 0;
      algorhitmY = 0;
      if (screen.width <= dropdownFullScreenBreakpoint) {
        document.body.style.overflow = 'hidden';
      }
      switch (handler.dataset.dropdownArrow) {
        case 'right':
          offsetX = handler.dataset.dropdownOffsetx ? handler.dataset.dropdownOffsetx : 18;
          rightShift = handler.getRelativeClientRect(body).right - offsetX;
          break;
        case 'center':
          offsetX = handler.dataset.dropdownOffsetx ? handler.dataset.dropdownOffsetx : -5;
          rightShift = handler.getRelativeClientRect(body).right - target.offsetWidth / 2 - offsetX;
          break;
        case 'left':
          offsetX = handler.dataset.dropdownOffsetx ? handler.dataset.dropdownOffsetx : -18;
          rightShift = handler.getRelativeClientRect(body).right - target.offsetWidth - offsetX + 7;
          break;
        case 'none':
          rightShift = handler.getRelativeClientRect(body).right;
          topShift = topShift - 8;
          break;
      }
      target.style.top = topShift + 'px';
      target.style.right = rightShift + algorhitmX + 'px';
      if (handler.dataset.positionAlgorhitm) {
        rects = handler.getClientRects();
        target.style.right = '';
        return target.style.left = rects[rects.length - 1].left + 'px';
      }
    },
    hideDropdowns: function(remover) {
      var a, d, i, j, len, len1, ref, ref1, results;
      ref = document.querySelectorAll('[data-dropdown-id]');
      for (i = 0, len = ref.length; i < len; i++) {
        d = ref[i];
        d.querySelector('.dropdown__overlay').style.display = 'none';
        d.setAttribute('aria-expanded', false);
        d.setAttribute('tabindex', -1);
        if (remover === true && d.hasClass('dropdown--show')) {
          d.removeClass('dropdown--show');
          removeListener(d);
        } else {
          d.removeClass('dropdown--show');
        }
      }
      ref1 = document.querySelectorAll('[data-dropdown]');
      results = [];
      for (j = 0, len1 = ref1.length; j < len1; j++) {
        a = ref1[j];
        a.setAttribute('aria-expanded', false);
        if (a.dataset.showed === 'true' && screen.width <= dropdownFullScreenBreakpoint) {
          document.body.style.overflow = '';
        }
        results.push(a.dataset.showed = false);
      }
      return results;
    },
    inDropdown: function(target) {
      var parentIsDropdown;
      parentIsDropdown = function(node) {
        if (!node) {
          return;
        }
        if (node.hasClass('dropdown') || node.dataset.dropdown) {
          return true;
        } else if (node.tagName === 'BODY' || node.parentNode === void 0) {
          return false;
        } else {
          return parentIsDropdown(node.parentNode);
        }
      };
      return parentIsDropdown(target);
    }
  };
  return window.dropdown.init();
});











window.initFlightMap = function() {
  var circle, flightMap, flightPath, from, from_lat, map, map_lat, to, to_lat;
  flightMap = document.getElementById('map');
  if (flightMap && flightMap.dataset.from && flightMap.dataset.to) {
    from = JSON.parse(flightMap.dataset.from);
    from_lat = new google.maps.LatLng(from[0], from[1]);
    to = JSON.parse(flightMap.dataset.to);
    to_lat = new google.maps.LatLng(to[0], to[1]);
    map_lat = new google.maps.LatLng((from[0] - to[0]) / 2 + to[0], (from[1] - to[1]) / 2 + to[1]);
    map = new google.maps.Map(flightMap, {
      zoom: 3,
      scrollwheel: false,
      disableDefaultUI: true
    });
    circle = {
      path: google.maps.SymbolPath.CIRCLE,
      fillColor: '#E87722',
      fillOpacity: 1,
      scale: 4,
      strokeColor: '#E87722'
    };
    flightPath = new google.maps.Polyline({
      path: [from_lat, to_lat],
      geodesic: true,
      strokeColor: '#4A90E2',
      strokeOpacity: 1,
      strokeWeight: 2
    });
    flightPath.setMap(map);
    new google.maps.Marker({
      position: from_lat,
      map: map,
      icon: circle
    });
    new google.maps.Marker({
      position: to_lat,
      map: map,
      icon: circle
    });
    new google.maps.Marker({
      position: map_lat,
      map: map,
      icon: {
        url: "./assets/img/center-fly.png",
        anchor: new google.maps.Point(20, 20)
      }
    });
    return map.setCenter(map_lat);
  }
};

document.addEventListener("DOMContentLoaded", function(e) {
  return window.initFlightMap();
});



document.addEventListener('DOMContentLoaded', function() {
  var el, i, j, k, l, len, len1, len2, len3, ref, ref1, ref2, ref3, results;
  ref = document.querySelectorAll('[data-slider-id="total-time"]');
  for (i = 0, len = ref.length; i < len; i++) {
    el = ref[i];
    new RangeSlider(el);
    el.addEventListener('change', function(e) {
      var target;
      target = document.querySelector('[data-slider-target="total-time"]');
      return target.innerHTML = "" + (~~e.slider_value > 0 ? ~~e.slider_value + 'h ' : '') + (parseInt((e.slider_value.toFixed(2) + '').split('.')[1]) > 0 ? (e.slider_value.toFixed(2) + '').split('.')[1] + 'm' : '');
    });
  }
  ref1 = document.querySelectorAll('[data-slider-id="takeoff-time"]');
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    el = ref1[j];
    new RangeSlider(el);
    el.addEventListener('change', function(e) {
      var target;
      target = document.querySelector('[data-slider-target="takeoff-time-min"]');
      target.innerHTML = (~~e.slider_from) + ":" + ((e.slider_from.toFixed(2) + '').split('.')[1]);
      target = document.querySelector('[data-slider-target="takeoff-time-max"]');
      return target.innerHTML = (~~e.slider_to) + ":" + ((e.slider_to.toFixed(2) + '').split('.')[1]);
    });
  }
  ref2 = document.querySelectorAll('[data-slider-id="arrival-time"]');
  for (k = 0, len2 = ref2.length; k < len2; k++) {
    el = ref2[k];
    new RangeSlider(el);
    el.addEventListener('change', function(e) {
      var target;
      target = document.querySelector('[data-slider-target="arrival-time-min"]');
      target.innerHTML = (~~e.slider_from) + ":" + ((e.slider_from.toFixed(2) + '').split('.')[1]);
      target = document.querySelector('[data-slider-target="arrival-time-max"]');
      return target.innerHTML = (~~e.slider_to) + ":" + ((e.slider_to.toFixed(2) + '').split('.')[1]);
    });
  }
  ref3 = document.querySelectorAll('[data-slider-id="transfer-dur"]');
  results = [];
  for (l = 0, len3 = ref3.length; l < len3; l++) {
    el = ref3[l];
    new RangeSlider(el);
    results.push(el.addEventListener('change', function(e) {
      var target;
      target = document.querySelector('[data-slider-target="transfer-dur"]');
      return target.innerHTML = "" + (~~e.slider_value > 0 ? ~~e.slider_value + 'h ' : '') + (parseInt((e.slider_value.toFixed(2) + '').split('.')[1]) > 0 ? (e.slider_value.toFixed(2) + '').split('.')[1] + 'm' : '');
    }));
  }
  return results;
});

document.addEventListener("DOMContentLoaded", function(e) {
  var button, j, len, results, showButtons;
  showButtons = document.getElementsByClassName('js-show-nearby-on-map');
  results = [];
  for (j = 0, len = showButtons.length; j < len; j++) {
    button = showButtons[j];
    results.push(button.addEventListener("click", function(e) {
      var mainContainer;
      mainContainer = e.target.closest('.flight-to-nearby-cities');
      return window.initNearbyMap(mainContainer);
    }));
  }
  return results;
});

window.showRouteToNearbyCity = function(fromLatLng, toLatLng, toMarkerInfoContent) {
  var bounds, flightPath, fromMarker, toMarker;
  window.infowindow.close();
  bounds = new google.maps.LatLngBounds();
  fromMarker = new google.maps.Marker({
    position: fromLatLng,
    map: window.nearbyMap,
    icon: {
      url: "./assets/img/star.svg",
      anchor: new google.maps.Point(16, 16)
    }
  });
  window.allMarkers.push(fromMarker);
  toMarker = new google.maps.Marker({
    position: toLatLng,
    map: window.nearbyMap,
    icon: {
      url: "./assets/img/icon--plane-white-orange-circle.svg",
      anchor: new google.maps.Point(12, 12)
    }
  });
  window.allMarkers.push(toMarker);
  toMarker.addListener("mouseover", function(e) {
    window.infowindow.setPosition(this.getPosition());
    window.infowindow.setContent(toMarkerInfoContent);
    return window.infowindow.open();
  });
  toMarker.addListener("mouseout", function(e) {
    return window.infowindow.close();
  });
  bounds.extend(fromLatLng);
  bounds.extend(toLatLng);
  fromMarker.setMap(window.nearbyMap);
  toMarker.setMap(window.nearbyMap);
  flightPath = new google.maps.Polyline({
    path: [fromLatLng, toLatLng],
    geodesic: true,
    strokeColor: '#4A90E2',
    strokeOpacity: 1,
    strokeWeight: 2
  });
  window.allMarkers.push(flightPath);
  flightPath.setMap(window.nearbyMap);
  window.nearbyMap.fitBounds(bounds);
  return window.nearbyMap.panToBounds(bounds);
};

window.initNearbyMap = function(mainContainer) {
  var addListenersToCities, buildContent, city, cityLatLng, clearMarkers, closeButton, from, fromMarker, from_lat, i, iconUrl, index, j, len, mapElem, mapWrapper, marker, onCityMouseEnter, removeActiveClassFromCities, removeListenersFromCities, selected, selectedLatLng, to;
  if (mainContainer && mainContainer.dataset.from && mainContainer.dataset.to) {
    window.allMarkers = [];
    from = JSON.parse(mainContainer.dataset.from);
    from_lat = new google.maps.LatLng(from[0], from[1]);
    to = JSON.parse(mainContainer.dataset.to);
    mapElem = mainContainer.getElementsByClassName('flight-to-nearby-cities__map')[0];
    mapWrapper = mainContainer.getElementsByClassName('flight-to-nearby-cities__map-wrapper')[0];
    closeButton = mainContainer.getElementsByClassName('flight-to-nearby-cities__map-close')[0];
    clearMarkers = function() {
      var i, j, len, marker, ref, results;
      ref = window.allMarkers;
      results = [];
      for (i = j = 0, len = ref.length; j < len; i = ++j) {
        marker = ref[i];
        results.push(window.allMarkers[i].setMap(null));
      }
      return results;
    };
    onCityMouseEnter = function() {
      var toMarkerInfo, toMarkerInfoContent;
      clearMarkers();
      if (this.dataset.info) {
        toMarkerInfo = JSON.parse(this.dataset.info);
        toMarkerInfoContent = buildContent(toMarkerInfo);
        window.showRouteToNearbyCity(from_lat, new google.maps.LatLng(toMarkerInfo.latlng[0], toMarkerInfo.latlng[1]), toMarkerInfoContent);
      }
      return removeActiveClassFromCities();
    };
    addListenersToCities = function() {
      var elem, j, len, ref, results;
      if (document.getElementsByClassName('flight-to-nearby-cities__city').length > 0) {
        ref = document.getElementsByClassName('flight-to-nearby-cities__city');
        results = [];
        for (j = 0, len = ref.length; j < len; j++) {
          elem = ref[j];
          results.push(elem.addEventListener("mouseenter", onCityMouseEnter));
        }
        return results;
      }
    };
    removeListenersFromCities = function() {
      var elem, j, len, ref, results;
      if (document.getElementsByClassName('flight-to-nearby-cities__city').length > 0) {
        ref = document.getElementsByClassName('flight-to-nearby-cities__city');
        results = [];
        for (j = 0, len = ref.length; j < len; j++) {
          elem = ref[j];
          results.push(elem.removeEventListener("mouseenter", onCityMouseEnter));
        }
        return results;
      }
    };
    buildContent = function(city) {
      var cityInfo, contentString, distance;
      cityInfo = city.cityInfo;
      distance = cityInfo.distance;
      if (city.selected) {
        distance = 'Нет рейсов';
      }
      contentString = '<div class="flight-to-nearby-cities__map-info-window">' + '<span class="flight-to-nearby-cities__map-info-window-city">' + cityInfo.geo.city + ', ' + cityInfo.geo.country + '</span>' + '<span class="flight-to-nearby-cities__map-info-window-code">' + cityInfo.code + '</span>' + '<div class="flight-to-nearby-cities__map-info-window-distance">' + distance + '</div>' + '</div>';
      return contentString;
    };
    removeActiveClassFromCities = function() {
      var elem, j, len, ref, results;
      if (document.getElementsByClassName('flight-to-nearby-cities__city').length > 0) {
        ref = document.getElementsByClassName('flight-to-nearby-cities__city');
        results = [];
        for (j = 0, len = ref.length; j < len; j++) {
          elem = ref[j];
          results.push(elem.classList.remove('flight-to-nearby-cities__city--active'));
        }
        return results;
      }
    };
    mainContainer.getElementsByClassName('js-show-nearby-on-map')[0].style.display = 'none';
    mapWrapper.classList.add('flight-to-nearby-cities__map-wrapper_show_yes');
    setTimeout(function(e) {
      return addListenersToCities();
    }, 500);
    if (!mapElem) {
      return;
    }
    if (closeButton) {
      closeButton.addEventListener("click", function(e) {
        mapWrapper.classList.remove('flight-to-nearby-cities__map-wrapper_show_yes');
        mainContainer.getElementsByClassName('js-show-nearby-on-map')[0].style.display = 'inline-block';
        removeActiveClassFromCities();
        removeListenersFromCities();
        if (window.infowindow) {
          window.infowindow.destroy();
        }
        return clearMarkers();
      });
    }
    selected = ((function() {
      var j, len, results;
      results = [];
      for (j = 0, len = to.length; j < len; j++) {
        i = to[j];
        if (i.selected === true) {
          results.push(i);
        }
      }
      return results;
    })())[0];
    if (selected) {
      if (!window.nearbyMap) {
        window.nearbyMap = new google.maps.Map(mapElem, {
          zoom: 3,
          disableDefaultUI: true
        });
      } else {
        window.nearbyMap.setZoom(3);
      }
      fromMarker = new google.maps.Marker({
        position: from_lat,
        map: window.nearbyMap,
        icon: {
          url: "./assets/img/star.svg",
          anchor: new google.maps.Point(16, 16)
        }
      });
      window.allMarkers.push(fromMarker);
      window.infowindow = new SnazzyInfoWindow({
        map: window.nearbyMap,
        placement: 'right',
        maxWidth: 250,
        showCloseButton: false,
        panOnOpen: false,
        offset: {
          top: '0px'
        }
      });
      for (index = j = 0, len = to.length; j < len; index = ++j) {
        city = to[index];
        cityLatLng = new google.maps.LatLng(city.latlng[0], city.latlng[1]);
        iconUrl = "./assets/img/icon--plane-white-blue-circle.svg";
        city.index = index;
        if (city.selected) {
          iconUrl = "./assets/img/icon--plane-gray-disabled.svg";
        }
        marker = new google.maps.Marker({
          position: cityLatLng,
          map: window.nearbyMap,
          cityInfo: city,
          zIndex: 1,
          icon: {
            url: iconUrl,
            anchor: new google.maps.Point(12, 12)
          }
        });
        window.allMarkers.push(marker);
        marker.addListener("mouseover", function(e) {
          var cityItem, itemClassName;
          itemClassName = 'flight-to-nearby-cities__city_item_' + this.cityInfo.index;
          cityItem = document.getElementsByClassName(itemClassName)[0];
          this.setZIndex(2);
          this.setIcon({
            url: "./assets/img/icon--plane-white-orange-circle.svg",
            anchor: new google.maps.Point(12, 12)
          });
          if (cityItem) {
            removeActiveClassFromCities();
            cityItem.classList.add('flight-to-nearby-cities__city--active');
          }
          window.infowindow.setPosition(this.getPosition());
          window.infowindow.setContent(buildContent(this.cityInfo));
          return window.infowindow.open();
        });
        marker.addListener("mouseout", function(e) {
          this.setIcon({
            url: "./assets/img/icon--plane-white-blue-circle.svg",
            anchor: new google.maps.Point(12, 12)
          });
          this.setZIndex(1);
          return window.infowindow.close();
        });
        if (!city.selected) {
          marker.addListener("click", function(e) {
            var cityItem, itemClassName, toMarkerInfoContent;
            itemClassName = 'flight-to-nearby-cities__city_item_' + this.cityInfo.index;
            cityItem = document.getElementsByClassName(itemClassName)[0];
            if (cityItem) {
              removeActiveClassFromCities();
              cityItem.classList.add('flight-to-nearby-cities__city--active');
            }
            this.setIcon({
              url: "./assets/img/icon--plane-white-orange-circle.svg",
              anchor: new google.maps.Point(12, 12)
            });
            infowindow.close();
            clearMarkers();
            toMarkerInfoContent = buildContent(city);
            return window.showRouteToNearbyCity(fromMarker.getPosition(), this.getPosition(), toMarkerInfoContent);
          });
        }
      }
      selectedLatLng = new google.maps.LatLng(selected.latlng[0], selected.latlng[1]);
      return window.nearbyMap.setCenter(selectedLatLng);
    }
  }
};

var floatTab;

floatTab = function(e) {
  var activate, activeButton, activeItem, calculation, clear, i, item, len, ref, results;
  activeItem = 'float-tab__item--active';
  activeButton = 'button--white';
  calculation = function() {
    var baseRect, content, contentLeft, contentRect, i, len, ref, results;
    ref = document.querySelectorAll('.float-tab__content');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      content = ref[i];
      baseRect = content.parentNode.parentNode.getRelativeClientRect(document.body);
      contentRect = content.parentNode.getElementsByClassName('float-tab__button')[0].getRelativeClientRect(document.body);
      contentLeft = baseRect.left - contentRect.left;
      content.style.left = contentLeft + 'px';
      results.push(content.style.width = baseRect.width + 'px');
    }
    return results;
  };
  clear = function() {
    var content, i, item, j, len, len1, ref, ref1, results;
    ref = document.querySelectorAll('.float-tab__button');
    for (i = 0, len = ref.length; i < len; i++) {
      item = ref[i];
      item.addClass(activeButton);
      item.setAttribute('aria-selected', false);
      if (item.parentNode.hasClass(activeItem)) {
        item.parentNode.removeClass(activeItem);
      }
      item.parentNode.style.marginBottom = '1rem';
    }
    ref1 = document.querySelectorAll('.float-tab__content');
    results = [];
    for (j = 0, len1 = ref1.length; j < len1; j++) {
      content = ref1[j];
      content.style.transform = 'translateY(0)';
      results.push(content.setAttribute('aria-hidden', true));
    }
    return results;
  };
  activate = function(el) {
    var contentBlock, contentHeight, marginHeight, transformHeight;
    contentBlock = el.parentNode.getElementsByClassName('float-tab__content')[0];
    el.parentNode.addClass(activeItem);
    el.setAttribute('aria-selected', true);
    el.removeClass(activeButton);
    contentBlock.setAttribute('aria-hidden', false);
    contentHeight = contentBlock.offsetHeight;
    transformHeight = el.parentNode.getRelativeClientRect(el.parentNode.parentNode).top + el.offsetHeight;
    marginHeight = contentHeight + el.offsetHeight;
    el.parentNode.style.marginBottom = marginHeight + 'px';
    return el.parentNode.getElementsByClassName('float-tab__content')[0].style.transform = 'translateY(' + el.offsetHeight + 'px)';
  };
  clear();
  calculation();
  document.addEventListener("click", function(e) {
    if (e.target.hasClass('float-tab__button')) {
      e.preventDefault();
      if (!e.target.parentNode.hasClass(activeItem)) {
        clear();
        activate(e.target);
      } else {
        clear();
      }
    }
    if (e.target.hasClass('float-tab__close')) {
      e.preventDefault();
      return clear();
    }
  });
  window.addEventListener("resize", function() {
    clear();
    return calculation();
  });
  if (window.innerWidth < 800) {
    ref = document.querySelectorAll('.float-tab__item');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      item = ref[i];
      results.push(item.classList.add('float-tab__item--mobile'));
    }
    return results;
  }
};

document.addEventListener("DOMContentLoaded", function() {
  return floatTab();
});

document.addEventListener("DOMContentLoaded", function() {
  var i, len, ref, results, toggler;
  ref = document.getElementsByClassName('footer__header--toggler');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    toggler = ref[i];
    results.push(toggler.addEventListener("click", function(e) {
      var item;
      item = e.target;
      if (Boolean(parseInt(item.dataset.show))) {
        item.dataset.show = 0;
        item.nextElementSibling.removeClass('footer__submenu--toggler-active');
        item.removeClass('footer__header--toggler-active');
      } else {
        item.dataset.show = 1;
        item.nextElementSibling.addClass('footer__submenu--toggler-active');
        item.addClass('footer__header--toggler-active');
      }
      return false;
    }));
  }
  return results;
});

document.addEventListener("DOMContentLoaded", function() {
  var collapsed, container, i, len, ref, results, toggler;
  ref = document.getElementsByClassName('frame--collapsed');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    collapsed = ref[i];
    if (window.innerWidth <= 600) {
      collapsed.addEventListener("click", function(e) {
        var block;
        block = e.currentTarget;
        if (block.hasClass('frame--collapsed-active')) {
          block.removeClass('frame--collapsed-active');
          return block.setAttribute("aria-expanded", true);
        } else {
          block.addClass('frame--collapsed-active');
          return block.setAttribute("aria-expanded", false);
        }
      });
      results.push((function() {
        var j, len1, ref1, results1;
        ref1 = document.getElementsByClassName('frame__container');
        results1 = [];
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          container = ref1[j];
          results1.push(container.addEventListener("click", function(e) {
            return e.stopPropagation();
          }));
        }
        return results1;
      })());
    } else {
      results.push((function() {
        var j, len1, ref1, results1;
        ref1 = collapsed.getElementsByClassName('js-frame__collapsed');
        results1 = [];
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          toggler = ref1[j];
          results1.push(toggler.addEventListener("click", function(e) {
            var block;
            e.preventDefault();
            e.stopPropagation();
            block = this.parentElement;
            container = block.querySelector('.frame__container');
            if (block.hasClass('frame--collapsed-active')) {
              block.removeClass('frame--collapsed-active');
              return container.setAttribute("aria-expanded", true);
            } else {
              block.addClass('frame--collapsed-active');
              return container.setAttribute("aria-expanded", false);
            }
          }));
        }
        return results1;
      })());
    }
  }
  return results;
});

document.addEventListener('DOMContentLoaded', function() {
  var gallery, i, len, ref, results;
  ref = document.querySelectorAll('[data-gallery]');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    gallery = ref[i];
    results.push(gallery.addEventListener('click', function(e) {
      e.preventDefault();
      if (e.target.parentNode && e.target.parentNode.hasClass('gallery__list-item')) {
        gallery.querySelectorAll('.gallery__list-item img').removeClass('active');
        e.target.addClass('active');
        gallery.querySelector('.gallery__active .gallery__active-img').src = e.target.src;
        return gallery.querySelector('.gallery__active .gallery__active-img').alt = e.target.alt;
      }
    }));
  }
  return results;
});

var geocodeAddress,
  extend = function(child, parent) { for (var key in parent) { if (hasProp.call(parent, key)) child[key] = parent[key]; } function ctor() { this.constructor = child; } ctor.prototype = parent.prototype; child.prototype = new ctor(); child.__super__ = parent.prototype; return child; },
  hasProp = {}.hasOwnProperty;

geocodeAddress = function(geocoder, address) {
  return new Promise(function(resolve, reject) {
    return geocoder.geocode({
      'address': address
    }, function(results, status) {
      if (status === google.maps.GeocoderStatus.OK) {
        return resolve(results[0].geometry.location);
      } else {
        return reject(status);
      }
    });
  });
};

window.initMapCustom = function() {
  var CustomMarker, closeMap, collapseMap, coords_from, coords_from_lat, currencyMark, elMap, i, infoHTML, len, map, mapRoot, overlays, point, ref;
  overlays = [];
  elMap = document.getElementById('gmap');
  if (!elMap) {
    return;
  }
  infoHTML = document.querySelector('.gmap__infowindow_sample').innerHTML;
  document.querySelector('.gmap__infowindow_sample').remove();
  CustomMarker = (function(superClass) {
    extend(CustomMarker, superClass);

    function CustomMarker(from_, to_, map_, line_, text_, is_discount_) {
      this.from_ = from_;
      this.to_ = to_;
      this.map_ = map_;
      this.line_ = line_;
      this.text_ = text_;
      this.is_discount_ = is_discount_;
      this.discountIcon = "./assets/img/gmap__discont.svg";
      this.setMap(this.map_);
    }

    CustomMarker.prototype.draw = function() {
      var div, flightPath, info, overlayProjection, p, path;
      overlayProjection = this.getProjection();
      p = overlayProjection.fromLatLngToDivPixel(this.to_);
      div = this.div_;
      info = this.info_;
      div.style.left = p.x - div.offsetWidth / 2 + 'px';
      div.style.top = p.y - div.offsetHeight / 2 + 'px';
      if (this.line_ && !this.flightPath) {
        path = [this.from_, this.to_];
        flightPath = new google.maps.Polyline({
          path: path,
          geodesic: true,
          strokeColor: '#4A90E2',
          strokeOpacity: 1.0,
          strokeWeight: 1
        });
        this.flightPath = flightPath;
        return flightPath.setMap(this.map_);
      }
    };

    CustomMarker.prototype.onAdd = function() {
      var cross, div, infoWindow, styleFade, styleNormal;
      div = "<div class='gmap__marker' tabindex='0'></div>".toHTML();
      infoWindow = "<div class='gmap__infowindow' tabindex='0'></div>".toHTML();
      cross = "<i class='gmap__cross'></i>".toHTML();
      infoWindow.innerHTML = infoHTML;
      if (this.is_discount_) {
        div.appendChild(("<span class='gmap__marker--icon' style='background-image: url(" + this.discountIcon + ")'></span>").toHTML());
      }
      div.appendChild(("<span class='gmap__marker--text'>" + this.text_ + "</span>").toHTML());
      this.info_ = infoWindow;
      this.div_ = div;
      this.getPanes().overlayLayer.appendChild(div);
      this.getPanes().overlayMouseTarget.appendChild(div);
      styleFade = [
        {
          featureType: 'all',
          stylers: [
            {
              saturation: -100
            }, {
              lightness: 10
            }, {
              visibility: "simplified"
            }
          ]
        }
      ];
      styleNormal = [
        {
          featureType: 'all',
          stylers: [
            {
              saturation: 0
            }, {
              lightness: 0
            }, {
              visibility: "on"
            }
          ]
        }
      ];
      google.maps.event.addListener(this, 'click', (function(_this) {
        return function(e) {
          var crosses, i, infoWindows, len, offset, overlay, overlayProjection, p;
          infoWindows = document.querySelector('.gmap__infowindow');
          if (infoWindows) {
            infoWindows.remove();
          }
          crosses = document.querySelector('.gmap__cross');
          _this.getPanes().overlayLayer.appendChild(infoWindow);
          _this.getPanes().overlayMouseTarget.appendChild(infoWindow);
          overlayProjection = _this.getProjection();
          p = overlayProjection.fromLatLngToDivPixel(_this.to_);
          _this.map.panTo(_this.to_);
          offset = _this.is_discount_ ? 14 : 0;
          if (screen.width < 800) {
            infoWindow.style.left = (p.x - infoWindow.offsetWidth / 2) + 'px';
            infoWindow.style.top = (p.y - infoWindow.offsetHeight / 2) + 'px';
            map.setOptions({
              styles: styleFade
            });
            _this.getPanes().overlayMouseTarget.appendChild(cross);
            cross.style.left = (p.x + infoWindow.offsetWidth / 2 - 30) + 'px';
            cross.style.top = (p.y - infoWindow.offsetHeight / 2 - 30) + 'px';
            google.maps.event.addDomListener(cross, 'click', function(event) {
              if (infoWindows) {
                infoWindows.remove();
              }
              if (infoWindow) {
                infoWindow.remove();
              }
              cross.remove();
              return map.setOptions({
                styles: styleNormal
              });
            });
          } else {
            infoWindow.style.left = (p.x + div.offsetWidth - offset) + 'px';
            infoWindow.style.top = (p.y - infoWindow.offsetHeight + div.offsetHeight) + 'px';
          }
          window.accordion.init();
          for (i = 0, len = overlays.length; i < len; i++) {
            overlay = overlays[i];
            overlay.div_.removeClass('focus');
            if (overlay.flightPath) {
              overlay.flightPath.setOptions({
                strokeColor: "#4A90E2"
              });
            }
          }
          _this.div_.addClass('focus');
          if (_this.flightPath) {
            return _this.flightPath.setOptions({
              strokeColor: "#FF5100"
            });
          }
        };
      })(this));
      google.maps.event.addDomListener(div, 'click', (function(_this) {
        return function(event) {
          return google.maps.event.trigger(_this, 'click', event);
        };
      })(this));
      google.maps.event.addDomListener(div, 'blur', (function(_this) {
        return function(event) {
          if (!(event.relatedTarget && event.relatedTarget.hasClass('accordion__item'))) {
            return infoWindow.remove();
          }
        };
      })(this));
      return google.maps.event.addDomListener(div, 'keypress', (function(_this) {
        return function(event) {
          if (event.keyCode === 13) {
            return google.maps.event.trigger(_this, 'click');
          }
        };
      })(this));
    };

    return CustomMarker;

  })(google.maps.OverlayView);
  elMap = document.getElementById('gmap');
  mapRoot = document.getElementById('hitmap');
  map = new google.maps.Map(elMap, {
    center: {
      lat: 56.837653,
      lng: 60.607307
    },
    zoom: 4,
    minZoom: 2
  });
  coords_from = JSON.parse(elMap.dataset.from);
  coords_from_lat = new google.maps.LatLng(coords_from[0], coords_from[1]);
  new google.maps.Marker({
    position: coords_from_lat,
    map: map,
    icon: "./assets/img/gmap__from.png"
  });
  map.from_ = coords_from_lat;
  map.setCenter(coords_from_lat);
  currencyMark = "<span class='h-font--rouble'>a</span>";
  if (mapRoot.dataset.currency === 'miles') {
    currencyMark = "<span aria-hidden='true' class='h-font--aero'>¥</span>";
  }
  ref = JSON.parse(elMap.dataset.points);
  for (i = 0, len = ref.length; i < len; i++) {
    point = ref[i];
    overlays.push(new CustomMarker(coords_from_lat, new google.maps.LatLng(point.to[0], point.to[1]), map, point.line, point.price.formatMoney() + "&#8239;" + currencyMark, point.is_discount));
  }
  collapseMap = function() {
    var mapButton;
    map.setOptions({
      zoom: 3,
      mapTypeControl: false,
      zoomControl: false
    });
    mapButton = document.querySelector('.js-map-button');
    if (mapButton) {
      return mapButton.addEventListener('click', function(e) {
        e.preventDefault();
        map.setOptions({
          zoom: 4,
          mapTypeControl: true,
          zoomControl: true,
          center: coords_from_lat
        });
        document.querySelector('.js-map-exprired').addClass('frame__expired--hidden');
        document.querySelector('#hitmap').removeClass('gmap--minimize');
        return delay(360, function() {
          google.maps.event.trigger(map, 'resize');
          return map.setCenter(coords_from_lat);
        });
      });
    }
  };
  closeMap = function() {
    var gmapCloseButton;
    gmapCloseButton = document.getElementsByClassName('gmap__control-close');
    if (gmapCloseButton.length > 0) {
      return gmapCloseButton[0].addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector('#hitmap').addClass('gmap--minimize');
        return document.querySelector('.js-map-exprired').removeClass('frame__expired--hidden');
      });
    }
  };
  if (elMap.hasData('collapse')) {
    collapseMap();
  }
  return closeMap();
};





document.addEventListener("DOMContentLoaded", function() {
  var activeEl, activeItemClass, activeModifier, activeNode, ch, clearActiveClass, el, focusMain, getActiveNodeByItem, headerSelect, hideAllToggles, i, j, k, len, len1, len2, listItemsClass, openedClass, ref, ref1;
  headerSelect = document.getElementsByClassName('js-header__select');
  openedClass = 'header__select--opened';
  activeItemClass = 'header__select-active';
  listItemsClass = 'header__select-items';
  activeModifier = 'header__select-item--active';
  for (i = 0, len = headerSelect.length; i < len; i++) {
    el = headerSelect[i];
    activeEl = null;
    activeNode = el.getElementsByClassName(activeItemClass)[0];
    getActiveNodeByItem = function(itemObject) {
      return itemObject.parentNode.parentNode.getElementsByClassName(activeItemClass)[0];
    };
    clearActiveClass = function(dropObject) {
      var ch, j, len1, ref, results;
      ref = dropObject.getElementsByClassName(listItemsClass)[0].children;
      results = [];
      for (j = 0, len1 = ref.length; j < len1; j++) {
        ch = ref[j];
        results.push(ch.removeClass(activeModifier));
      }
      return results;
    };
    ref = el.getElementsByClassName(listItemsClass)[0].children;
    for (j = 0, len1 = ref.length; j < len1; j++) {
      ch = ref[j];
      ch.addEventListener('click', function(e) {
        clearActiveClass(this.parentNode.parentNode);
        getActiveNodeByItem(this).innerHTML = this.outerHTML;
        this.addClass(activeModifier);
        if (this.dataset.callback) {
          eval(this.dataset.callback);
        }
        if (this.dataset.url) {
          location.href = this.dataset.url;
        }
        this.parentNode.parentNode.removeClass(openedClass);
        this.parentNode.parentNode.setAttribute('aria-expanded', false);
        return false;
      });
      if (ch.hasClass(activeModifier)) {
        activeEl = ch;
      }
    }
    if (activeEl) {
      activeNode.innerHTML = activeEl.outerHTML;
      activeNode.getElementsByClassName(activeModifier)[0].removeClass(activeModifier);
    }
    el.getElementsByClassName(activeItemClass)[0].addEventListener('click', function(e) {
      var dropdown, k, len2;
      for (k = 0, len2 = headerSelect.length; k < len2; k++) {
        dropdown = headerSelect[k];
        dropdown.removeClass(openedClass);
        dropdown.setAttribute('aria-expanded', false);
      }
      if (this.parentNode.hasClass(openedClass)) {
        this.parentNode.removeClass(openedClass);
        this.parentNode.setAttribute('aria-expanded', false);
      } else {
        this.parentNode.addClass(openedClass);
        this.parentNode.setAttribute('aria-expanded', true);
      }
      return false;
    });
  }
  hideAllToggles = function() {
    var k, len2, ref1, results, target;
    ref1 = document.getElementsByClassName('js-header__toggle');
    results = [];
    for (k = 0, len2 = ref1.length; k < len2; k++) {
      el = ref1[k];
      target = document.querySelectorAll('[data-toggle-item=' + el.dataset.toggleTarget + ']')[0];
      target.removeClass('header__toggle-target--active');
      el.removeClass('header__toggle--active');
      results.push(el.dataset.show = 0);
    }
    return results;
  };
  ref1 = document.getElementsByClassName('js-header__toggle');
  for (k = 0, len2 = ref1.length; k < len2; k++) {
    el = ref1[k];
    el.addEventListener("click", function(e) {
      var item, target;
      item = e.target;
      target = document.querySelectorAll('[data-toggle-item=' + item.dataset.toggleTarget + ']')[0];
      if (!target) {
        return;
      }
      if (Boolean(parseInt(item.dataset.show))) {
        item.dataset.show = 0;
        target.removeClass('header__toggle-target--active');
        item.removeClass('header__toggle--active');
      } else {
        hideAllToggles();
        item.dataset.show = 1;
        target.addClass('header__toggle-target--active');
        item.addClass('header__toggle--active');
      }
      return false;
    });
  }
  focusMain = function(el) {
    var focusAction, l, len3, link, main, mainTop, ref2, results;
    ref2 = document.querySelectorAll('[role="main"]');
    results = [];
    for (l = 0, len3 = ref2.length; l < len3; l++) {
      main = ref2[l];
      mainTop = main.getBoundingClientRect().top;
      focusAction = function() {
        window.scroll(0, mainTop);
        main.setAttribute('tabindex', 0);
        return main.focus();
      };
      results.push((function() {
        var len4, m, results1;
        results1 = [];
        for (m = 0, len4 = el.length; m < len4; m++) {
          link = el[m];
          link.addEventListener("click", function(e) {
            return focusAction();
          });
          results1.push(link.addEventListener("keydown", function(e) {
            if (e.keyCode === 13) {
              return focusAction();
            }
          }));
        }
        return results1;
      })());
    }
    return results;
  };
  return focusMain(document.getElementsByClassName('js-skip-link'));
});



document.addEventListener("DOMContentLoaded", function() {
  var el, i, input_max, input_min, j, len, len1, ref, ref1, results, slider;
  ref = document.getElementsByClassName('js-hotel-filter__show-more');
  for (i = 0, len = ref.length; i < len; i++) {
    el = ref[i];
    el.addEventListener("click", function(e) {
      var item, target;
      e.preventDefault();
      item = e.target;
      target = document.getElementsByClassName('js-hotel-filter__morefilters')[0];
      if (!target) {
        return;
      }
      if (Boolean(parseInt(item.dataset.show))) {
        item.dataset.show = 0;
        target.removeClass('hotel-filter__morefilters--active');
        item.removeClass('hotel-filter__show-more--active');
      } else {
        item.dataset.show = 1;
        target.addClass('hotel-filter__morefilters--active');
        item.addClass('hotel-filter__show-more--active');
      }
      return false;
    });
  }
  ref1 = document.querySelectorAll('[data-slider-id="hotel-price"]');
  results = [];
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    el = ref1[j];
    slider = new RangeSlider(el);
    input_min = document.querySelector('[data-slider-target="hotel-price-min"]');
    input_max = document.querySelector('[data-slider-target="hotel-price-max"]');
    window.addEventListener('resize', function(e) {
      var max_value, min_value;
      slider.width100 = el.offsetWidth - slider.right_point.offsetWidth;
      max_value = parseFloat(input_max.value.replace(' ', ''));
      max_value = isNaN(max_value) || max_value > slider.max + slider.min || max_value < slider.min ? max_value = slider.max + slider.min : max_value;
      slider.right_point.style.left = (slider.width100 / 100 * (100 * (max_value - slider.min) / slider.max)) + "px";
      min_value = parseFloat(input_min.value.replace(' ', ''));
      min_value = isNaN(min_value) || min_value < slider.min || min_value > slider.max ? min_value = slider.min : min_value;
      slider.left_point.style.left = (slider.width100 / 100 * ((min_value - slider.min) / slider.max * 100)) + "px";
      return slider.getDistance();
    }, true);
    el.addEventListener('change', function(e) {
      input_min.value = e.slider_from.formatMoney();
      return input_max.value = e.slider_to.formatMoney();
    });
    input_min.addEventListener('change', function(e) {
      var min_value;
      slider.width100 = el.offsetWidth - slider.right_point.offsetWidth;
      min_value = parseFloat(input_min.value.replace(' ', ''));
      min_value = isNaN(min_value) || min_value < slider.min || min_value > slider.max ? min_value = slider.min : min_value;
      slider.left_point.style.left = (slider.width100 / 100 * ((min_value - slider.min) / slider.max * 100)) + "px";
      input_min.value = min_value.formatMoney();
      return slider.getDistance();
    });
    results.push(input_max.addEventListener('change', function(e) {
      var max_value;
      slider.width100 = el.offsetWidth - slider.right_point.offsetWidth;
      max_value = parseFloat(input_max.value.replace(' ', ''));
      max_value = isNaN(max_value) || max_value > slider.max + slider.min || max_value < slider.min ? max_value = slider.max + slider.min : max_value;
      slider.right_point.style.left = (slider.width100 / 100 * (100 * (max_value - slider.min) / slider.max)) + "px";
      input_max.value = max_value.formatMoney();
      return slider.getDistance();
    }));
  }
  return results;
});

document.addEventListener('DOMContentLoaded', function(e) {
  var hideHotelGalleryItem, hotelGalleryItem, hotelRoomGallery, showHotelGalleryItem, template;
  template = function(src, alt) {
    return ("<div class='hotel-room__fullscreen'><a href='#' class='modal__close'></a><img src='" + src + "' alt='" + alt + "'></div>").toHTML();
  };
  hotelRoomGallery = document.querySelector('.hotel-room__gallery');
  hotelGalleryItem = null;
  if (!hotelRoomGallery) {
    return;
  }
  showHotelGalleryItem = function(e) {
    hotelGalleryItem = template(e.target.getAttribute('src'), e.target.getAttribute('alt'));
    document.body.appendChild(hotelGalleryItem);
    return hotelGalleryItem.addEventListener('click', hideHotelGalleryItem);
  };
  hideHotelGalleryItem = function(e) {
    document.querySelector('.hotel-room__fullscreen').remove();
    return hotelGalleryItem.removeEventListener('click', hideHotelGalleryItem);
  };
  return hotelRoomGallery.addEventListener('click', showHotelGalleryItem);
});





document.addEventListener("DOMContentLoaded", function() {
  var activeClass, activeClassName, ariaHidden, getSlideProp, hideNameSlide, list, showNameSlide, slides, slidesControls, swipe, transformStyle;
  slides = document.querySelectorAll('.image-slider__container')[0];
  activeClass = 'image-slider__label--active';
  activeClassName = 'image-slider__name--visible';
  if (slides) {
    window.slideProp = 0;
    swipe = new Hammer(slides);
    list = document.querySelector('.image-slider__list');
    if (list.children.length <= 1) {
      list.parentNode.removeChild(list);
    } else {
      list.addEventListener('click', function(ev) {
        if (ev.target.hasClass('image-slider__select')) {
          return ev.target.focus();
        }
      });
      swipe.on('swipeleft', function(ev) {
        return getSlideProp(-1);
      });
      swipe.on('swiperight', function(ev) {
        return getSlideProp(1);
      });
    }
    ariaHidden = function(activeItem) {
      var i, item, len, ref, results;
      ref = document.querySelectorAll('.image-slider__slide');
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        item = ref[i];
        item.setAttribute('aria-hidden', true);
        results.push(activeItem.setAttribute('aria-hidden', false));
      }
      return results;
    };
    showNameSlide = function(index) {
      var activeName;
      activeName = document.querySelector("[data-slide-name=name-" + index + "]");
      return activeName.classList.add(activeClassName);
    };
    hideNameSlide = function() {
      var currentActiveName;
      currentActiveName = document.querySelector("." + activeClassName);
      if (currentActiveName) {
        return currentActiveName.classList.remove(activeClassName);
      }
    };
    transformStyle = function(elem, prop) {
      return elem.style.left = prop * -100 + '%';
    };
    ariaHidden(slides.children[window.slideProp]);
    slidesControls = Array.from(document.querySelectorAll('.image-slider__select'));
    slidesControls.forEach(function(element, index) {
      if (element.checked) {
        window.slideProp = index;
        transformStyle(slides, window.slideProp);
        ariaHidden(slides.children[window.slideProp]);
      } else {
        slidesControls[0].checked = true;
        slidesControls[0].parentNode.addClass(activeClass);
      }
      return element.addEventListener('change', function() {
        var i, len, slide;
        for (i = 0, len = slidesControls.length; i < len; i++) {
          slide = slidesControls[i];
          slide.parentNode.removeClass(activeClass);
        }
        window.slideProp = index;
        hideNameSlide();
        showNameSlide(index);
        transformStyle(slides, window.slideProp);
        ariaHidden(slides.children[window.slideProp]);
        return element.parentNode.addClass(activeClass);
      });
    });
    return getSlideProp = function(value) {
      var i, len, slide;
      if (window.slideProp - value >= slidesControls.length) {
        window.slideProp = 0;
      } else if (window.slideProp - value < 0) {
        window.slideProp = slidesControls.length - 1;
      } else {
        window.slideProp = window.slideProp - value;
      }
      transformStyle(slides, window.slideProp);
      slidesControls[window.slideProp].checked = true;
      for (i = 0, len = slidesControls.length; i < len; i++) {
        slide = slidesControls[i];
        slide.parentNode.removeClass(activeClass);
      }
      slidesControls[window.slideProp].parentNode.addClass(activeClass);
      return ariaHidden(slides.children[window.slideProp]);
    };
  }
});







document.addEventListener("DOMContentLoaded", function() {
  var changeCheck, check, checkCLass, checkPlaceholder, days, enadbledPhantom, i, j, k, len, len1, len2, maskerCertificates, maskerPhone, maskerPhoneBrackets, maskerPhoneNoRegion, maxDate, minDate, minDateFormat, months, phantom, phantomInput, ref, ref1, ref2, select;
  days = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
  months = ['Января', 'Февраля', 'Марта', 'Апреля', 'Мая', 'Июня', 'Июля', 'Августа', 'Сентября', 'Октября', 'Ноября', 'Декабря'];
  enadbledPhantom = function() {
    var i, len, ref, results, touchPhantom;
    ref = document.getElementsByClassName('input--phantom');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      touchPhantom = ref[i];
      if (screen.width <= 768 && isTouchDevice()) {
        results.push(touchPhantom.addClass('input--phantom-touch'));
      } else if (touchPhantom.hasClass('input--phantom-touch')) {
        results.push(touchPhantom.removeClass('input--phantom-touch'));
      } else {
        results.push(void 0);
      }
    }
    return results;
  };
  enadbledPhantom();
  window.addEventListener("resize", function(e) {
    return enadbledPhantom();
  });
  ref = document.getElementsByClassName('js-phantom');
  for (i = 0, len = ref.length; i < len; i++) {
    phantom = ref[i];
    phantomInput = phantom.getElementsByTagName('input')[0];
    minDate = moment(new Date()).format("YYYY-MM-DD");
    maxDate = moment(new Date()).add(330, 'days').format("YYYY-MM-DD");
    minDateFormat = moment(new Date()).format("DD.MM.YYYY").split('.');
    minDateFormat = new Date(minDateFormat[2], minDateFormat[1] - 1, minDateFormat[0]);
    if (phantomInput.parentNode.hasClass('js-direction-from') || phantomInput.parentNode.hasClass('js-direction-to') || phantomInput.parentNode.hasClass('js-direction-complex')) {
      phantomInput.setAttribute('min', minDate);
      phantomInput.setAttribute('max', maxDate);
    }
    phantomInput.addEventListener('focus', function() {
      this.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].addClass('focus');
      if (this.parentNode.hasClass('js-direction-from') || this.parentNode.hasClass('js-direction-to') || this.parentNode.hasClass('js-direction-complex')) {
        return this.value = '';
      }
    });
    phantomInput.addEventListener('blur', function() {
      return this.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].removeClass('focus');
    });
    phantomInput.addEventListener('change', function() {
      var fromDate, fromDateInput, j, k, len1, len2, minComplexDate, minFromDate, minPrevDate, nextDate, nextDateInput, nextRow, nextRows, prevDate, prevDateInput, prevRow, prevRows, results, rowNext, rowPrev, tempDate, tempTime, thatDate, toDate, toDateInput;
      switch (this.getAttribute('type')) {
        case 'date':
          thatDate = this.value;
          thatDate = moment(new Date(this.value)).format("DD.MM.YYYY").split('.');
          thatDate = new Date(thatDate[2], thatDate[1] - 1, thatDate[0]);
          if (thatDate < minDateFormat) {
            this.value = minDate;
          }
          tempDate = moment(new Date(this.value)).format("DD.MM.YYYY");
          if (tempDate === 'Invalid date') {
            tempDate = '';
          }
          this.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].value = tempDate;
          fromDateInput = document.querySelector('.js-direction-from input');
          toDateInput = document.querySelector('.js-direction-to input');
          if (fromDateInput) {
            fromDate = fromDateInput.value;
            toDate = toDateInput.value;
            fromDate = moment(new Date(fromDateInput.value)).format("DD.MM.YYYY").split('.');
            fromDate = new Date(fromDate[2], fromDate[1] - 1, fromDate[0]);
            minFromDate = moment(new Date(fromDate)).format("YYYY-MM-DD");
            if (toDateInput.value !== '' && this.parentNode.hasClass('js-direction-from')) {
              toDate = moment(new Date(toDateInput.value)).format("DD.MM.YYYY").split('.');
              toDate = new Date(toDate[2], toDate[1] - 1, toDate[0]);
              if (fromDate > toDate) {
                toDateInput.value = minFromDate;
                toDateInput.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].value = moment(new Date(fromDate)).format("DD.MM.YYYY");
              }
            }
            toDateInput.setAttribute('min', minFromDate);
            if (thatDate < fromDate) {
              this.value = minFromDate;
              this.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].value = moment(new Date(fromDate)).format("DD.MM.YYYY");
            }
          }
          if (this.parentNode.hasClass('js-direction-complex')) {
            rowNext = this.closest('fieldset');
            nextRows = [];
            while (rowNext.nextElementSibling && rowNext.nextElementSibling.closest('fieldset')) {
              nextRows.push(rowNext = rowNext.nextElementSibling);
            }
            for (j = 0, len1 = nextRows.length; j < len1; j++) {
              nextRow = nextRows[j];
              nextDateInput = nextRow.querySelector('.js-direction-complex input');
              if (nextDateInput) {
                nextDate = nextDateInput.value;
                nextDate = moment(new Date(nextDateInput.value)).format("DD.MM.YYYY").split('.');
                nextDate = new Date(nextDate[2], nextDate[1] - 1, nextDate[0]);
                minComplexDate = moment(new Date(thatDate)).format("YYYY-MM-DD");
                if (nextDateInput.value !== '' && thatDate > nextDate) {
                  nextDateInput.value = minComplexDate;
                  nextDateInput.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].value = moment(new Date(thatDate)).format("DD.MM.YYYY");
                }
                nextDateInput.setAttribute('min', minComplexDate);
              }
            }
            rowPrev = this.closest('fieldset');
            prevRows = [];
            while (rowPrev.previousElementSibling && rowPrev.previousElementSibling.closest('fieldset')) {
              prevRows.push(rowPrev = rowPrev.previousElementSibling);
            }
            results = [];
            for (k = 0, len2 = prevRows.length; k < len2; k++) {
              prevRow = prevRows[k];
              prevDateInput = prevRow.querySelector('.js-direction-complex input');
              if (prevDateInput) {
                prevDate = prevDateInput.value;
                prevDate = moment(new Date(prevDateInput.value)).format("DD.MM.YYYY").split('.');
                prevDate = new Date(prevDate[2], prevDate[1] - 1, prevDate[0]);
                minPrevDate = moment(new Date(prevDate)).format("YYYY-MM-DD");
                if (prevDateInput.value !== '' && thatDate < prevDate) {
                  this.value = minPrevDate;
                  results.push(this.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].value = moment(new Date(prevDate)).format("DD.MM.YYYY"));
                } else {
                  results.push(void 0);
                }
              } else {
                results.push(void 0);
              }
            }
            return results;
          }
          break;
        case 'time':
          tempTime = this.value.parseTime();
          return this.parentNode.parentNode.previousElementSibling.getElementsByTagName('input')[0].value = (tempTime[0].to10String()) + ":" + (tempTime[1].to10String());
      }
    });
    phantom.addEventListener("change", function() {
      return clearDate.init();
    });
  }
  ref1 = document.getElementsByClassName('input__select-input');
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    select = ref1[j];
    checkPlaceholder = function(obj) {
      var k, len2, option, setPlaceholderClass;
      setPlaceholderClass = false;
      for (k = 0, len2 = obj.length; k < len2; k++) {
        option = obj[k];
        if (option.selected && option.disabled) {
          setPlaceholderClass = true;
        }
      }
      if (setPlaceholderClass) {
        return obj.addClass('input__select-input--placeholder');
      } else {
        return obj.removeClass('input__select-input--placeholder');
      }
    };
    select.addEventListener("change", function(e) {
      return checkPlaceholder(this);
    });
    checkPlaceholder(select);
  }
  ref2 = document.querySelectorAll('.input--collapse > input');
  for (k = 0, len2 = ref2.length; k < len2; k++) {
    check = ref2[k];
    checkCLass = 'input--collapse-in';
    changeCheck = function() {
      var checkParent;
      checkParent = check.parentNode;
      if (check.checked) {
        return checkParent.addClass(checkCLass);
      } else if (checkParent.hasClass(checkCLass)) {
        return checkParent.removeClass(checkCLass);
      }
    };
    check.addEventListener("change", function(e) {
      var thisParent;
      thisParent = this.parentNode;
      if (this.checked) {
        return thisParent.addClass(checkCLass);
      } else if (thisParent.hasClass(checkCLass)) {
        return thisParent.removeClass(checkCLass);
      }
    });
    changeCheck();
  }
  maskerPhone = {
    init: function() {
      return VMasker(document.querySelectorAll('.js-phone input')).maskPattern('+9 999 999-99-99');
    }
  };
  maskerPhone.init();
  maskerPhoneNoRegion = {
    init: function() {
      return VMasker(document.querySelectorAll('.js-phone-no-region input')).maskPattern('999 999-99-99');
    }
  };
  maskerPhoneNoRegion.init();
  maskerPhoneBrackets = {
    init: function() {
      return VMasker(document.querySelectorAll('.js-phone-brackets input')).maskPattern('+9 (999) 999-99-99');
    }
  };
  maskerPhoneBrackets.init();
  maskerCertificates = {
    init: function() {
      return VMasker(document.querySelectorAll('.js-certificates input')).maskPattern('999 999 999');
    }
  };
  return maskerCertificates.init();
});

document.addEventListener("DOMContentLoaded", function() {
  var counter, i, len, minus, plus, ref, results;
  ref = document.getElementsByClassName('input-counter');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    counter = ref[i];
    minus = counter.querySelectorAll('.input-counter__minus')[0];
    plus = counter.querySelectorAll('.input-counter__plus')[0];
    counter.querySelectorAll('.input-counter__input-input')[0].value = 0;
    minus.addClass('input-counter__minus--passive');
    minus.addEventListener('click', function() {
      var input;
      input = this.parentNode.parentNode.querySelectorAll('.input-counter__input-input')[0];
      if (input.value > 0) {
        input.value -= 1;
      }
      if (parseInt(input.value) === 0) {
        return this.addClass('input-counter__minus--passive');
      }
    });
    results.push(plus.addEventListener('click', function() {
      var input;
      input = this.parentNode.parentNode.querySelectorAll('.input-counter__input-input')[0];
      input.value = parseInt(input.value) + 1;
      if (input.value > 0) {
        return this.previousElementSibling.previousElementSibling.removeClass('input-counter__minus--passive');
      }
    }));
  }
  return results;
});







document.addEventListener("DOMContentLoaded", function() {
  var boardingButton, i, len, ref, results;
  ref = document.querySelectorAll('.js-mobile-boarding-button');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    boardingButton = ref[i];
    results.push(boardingButton.addEventListener("click", function(e) {
      var boardingContent;
      e.preventDefault();
      boardingContent = e.target.parentNode.getElementsByClassName('mobile-boarding__info')[0];
      if (boardingContent.hasClass('mobile-boarding__info--visible')) {
        boardingContent.removeClass('mobile-boarding__info--visible');
        return e.target.innerHTML = 'ПОКАЗАТЬ ДЕТАЛИ МАРШРУТА';
      } else {
        boardingContent.addClass('mobile-boarding__info--visible');
        return e.target.innerHTML = 'СКРЫТЬ ДЕТАЛИ МАРШРУТА';
      }
    }));
  }
  return results;
});



document.addEventListener("DOMContentLoaded", function() {
  window.modal = {
    init: function() {
      var content, el, i, jsModalClass, len, ref, results;
      jsModalClass = 'js-modal';
      content = document.getElementsByClassName('js-wrapper')[0];
      ref = document.getElementsByClassName(jsModalClass);
      results = [];
      for (i = 0, len = ref.length; i < len; i++) {
        el = ref[i];
        document.getElementsByTagName('body')[0].prependChild(el);
        content.addClass('modal__blured');
        content.setAttribute('tabindex', '0');
        content.setAttribute('aria-hidden', 'true');
        results.push(content.addEventListener('focus', function() {
          return el.focus();
        }));
      }
      return results;
    }
  };
  return window.modal.init();
});

window.showModal = function(container, header_text, modifier, focus_elem, id) {
  var bodyWidth, content, header, iconClose, modal, modalContent, typeIcon, wrapper;
  if (header_text) {
    header = "<h2 class='modal-small__header'>" + header_text + "</h2>";
  } else {
    header = "";
  }
  if (modifier.indexOf('transparent') !== -1 || modifier.indexOf('close-outside') !== -1) {
    typeIcon = 'icon--cross-white';
  } else if (modifier.indexOf('landing') !== -1) {
    typeIcon = 'icon--cross-big-white';
  } else if (modifier.indexOf('back-lighten') !== -1) {
    typeIcon = 'icon--cross-black';
  } else {
    typeIcon = 'icon--cross';
  }
  if (modifier.indexOf('no-cross') !== -1) {
    iconClose = "";
  } else {
    iconClose = "<a class='modal-small__close icon " + typeIcon + " js-focused-next' href='javascript:void(0)' role='button' aria-label='Закрыть' data-modal-elem-id=" + (id != null ? id : {
      id: ''
    }) + "></a>";
  }
  wrapper = "<div class='modal-small' tabindex='-1' role='dialog'> <div class='modal-small__overlay'></div> <div class='modal-small__content " + (modifier != null ? modifier : {
    modifier: ''
  }) + "'> " + header + " <div class='modal-small__wrapper'></div> " + iconClose + " </div> </div>";
  modal = wrapper.toHTML();
  document.body.appendChild(modal);
  modal.querySelector('.modal-small__wrapper').insertBefore(container, modal.querySelector('.modal-small__wrapper').firstChild);
  content = document.querySelector('.js-wrapper');
  modalContent = document.querySelector('.modal-small__content');
  bodyWidth = window.document.body.offsetWidth;
  if (!isTouchDevice()) {
    modal.addEventListener('scroll', function() {
      return document.getElementsByClassName('popover').remove();
    });
  }
  return delay(100, function() {
    window.document.body.style.width = '100%';
    content.addClass('modal__blured');
    content.addClass('modal__blured--nofixed');
    content.setAttribute('tabindex', '0');
    content.setAttribute('aria-hidden', 'true');
    modal.addClass('modal-small--show');
    if (isAndroidBrowser) {
      window.document.body.style.position = 'fixed';
    } else {
      window.document.body.style.overflow = 'hidden';
    }
    if (focus_elem) {
      focus_elem.addClass('js-focused-next');
    }
    modal.focus();
    unfocused.init();
    return content.addEventListener('focus', function() {
      return modal.focus();
    });
  });
};

window.closeModal = function() {
  window.document.body.removeAttribute('style');
  document.querySelector('.js-focused-next').removeClass('js-focused-next');
  document.querySelector('.js-wrapper').removeClass('modal__blured');
  document.querySelector('.js-wrapper').removeClass('modal__blured--nofixed');
  document.querySelector('.js-wrapper').setAttribute('tabindex', '-1');
  document.querySelector('.js-wrapper').setAttribute('aria-hidden', 'false');
  document.querySelector('.modal-small').removeClass('modal-small--show');
  document.body.appendChild(document.querySelector('.modal-small .modal-small__wrapper').firstChild);
  document.querySelector('.modal-small').remove();
  return document.getElementsByClassName('popover').remove();
};

document.addEventListener('click', function(e) {
  if (e.target.hasClass('modal-small__close') || e.target.hasClass('modal-small__close-text') || e.target.hasClass('modal-small--show')) {
    return window.closeModal();
  }
});

document.addEventListener("keydown", function(e) {
  if (document.querySelector('.modal-small') && e.keyCode === 27) {
    window.closeModal();
  }
  if (e.target.hasClass('modal-small__close') && e.keyCode === 13) {
    return window.closeModal();
  }
});

document.addEventListener("DOMContentLoaded", function() {
  var button, checkConditions, conditions, disableClass, i, len, next, nextButton, ref, results;
  next = document.querySelectorAll('.js-conditions--button')[0];
  nextButton = document.querySelectorAll('.js-conditions--button a')[0];
  disableClass = 'next--disabled';
  button = {
    disabled: function() {
      next.addClass(disableClass);
      nextButton.setAttribute('aria-disabled', true);
      return nextButton.setAttribute('tabindex', '-1');
    },
    enabled: function() {
      next.removeClass(disableClass);
      nextButton.setAttribute('aria-disabled', false);
      return nextButton.setAttribute('tabindex', '0');
    }
  };
  conditions = {
    check: function() {
      if (checkConditions.checked) {
        return button.enabled();
      } else {
        return button.disabled();
      }
    }
  };
  ref = document.querySelectorAll('.js-conditions');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    checkConditions = ref[i];
    if (checkConditions) {
      checkConditions.addEventListener("change", function() {
        return conditions.check();
      });
      results.push(conditions.check());
    } else {
      results.push(void 0);
    }
  }
  return results;
});

document.addEventListener('DOMContentLoaded', function() {
  var el, i, j, len, len1, priceId, ref, ref1, results, sort, sortClass, sortReveseClass;
  ref = document.querySelectorAll('[data-slider]');
  for (i = 0, len = ref.length; i < len; i++) {
    el = ref[i];
    priceId = el.dataset.sliderId;
    new RangeSlider(el);
    el.addEventListener('change', function(e) {
      var target;
      target = document.querySelector('[data-slider-target=' + '"' + priceId + '-min"]');
      target.innerHTML = ("" + (~~e.slider_from)) + "&#8239;<span class='h-font--rouble'>a</span>";
      target = document.querySelector('[data-slider-target=' + '"' + priceId + '-max"]');
      return target.innerHTML = ("" + (~~e.slider_to)) + "&#8239;<span class='h-font--rouble'>a</span>";
    });
  }
  ref1 = document.querySelectorAll('.js-sortable');
  results = [];
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    sort = ref1[j];
    sortClass = 'offer__arrow--sort';
    sortReveseClass = 'offer__arrow--reverse';
    results.push(sort.addEventListener('click', function(e) {
      e.preventDefault();
      if (e.target.hasClass(sortClass)) {
        if (e.target.hasClass(sortReveseClass)) {
          return e.target.removeClass(sortReveseClass);
        } else {
          return e.target.addClass(sortReveseClass);
        }
      } else {
        return e.target.addClass(sortClass);
      }
    }));
  }
  return results;
});





var removePassengerPopup;

removePassengerPopup = {
  popupTemplate: "<div class=\"passenger-card__remove_popup-overlay\"></div> <div class=\"passenger-card__remove_popup\" tabindex=\"0\" role=\"dialog\"> <p class=\"passenger-card__remove_popup-title h-mb--24\"></p> <div class=\"row\"> <div class=\"col--1 hide--below-tablet-vertical\"></div> <div class=\"col--11\"><a href=\"javascript:void(0)\" class=\"button button--wide js-remove-passenger-close\" role=\"button\">Не удалять</a></div> <div class=\"col--11\"><a href=\"javascript:void(0)\" class=\"button button--wide button--alert js-remove-passenger-close\" role=\"button\">Удалить</a></div> <div class=\"col--1 hide--below-tablet-vertical\"></div> </div> </div>",
  popupHotelTemplate: "<div class=\"passenger-card__remove_popup-overlay\"></div> <div class=\"passenger-card__remove_popup h-pb--0\" tabindex=\"0\" role=\"dialog\"> <p class=\"passenger-card__remove_popup-title h-mb--24\"></p> <div class=\"row\"> <div class=\"col--1 hide--below-tablet-vertical\"></div> <div class=\"col--11\"><a href=\"javascript:void(0)\" class=\"button button--wide js-remove-passenger-close\" role=\"button\">Не удалять</a></div> <div class=\"col--11\"><a href=\"javascript:void(0)\" class=\"button button--wide button--alert js-remove-passenger-close\" role=\"button\">Удалить</a></div> <div class=\"col--1 hide--below-tablet-vertical\"></div> </div> <div class=\"wrapper wrapper--blue-wide h-pt--16 h-pb--24 h-mt--32 h-fz--12\"> <div class=\"text h-fw--700 h-mb--12\">Условия отмены</div> <div class=\"row\"> <div class=\"col--8 col--stack-below-tablet\">До 10 авг 2017 <div class=\"h-fz--16 h-mt--8 h-color--green\">Бесплатно</div></div> <div class=\"col--8 col--stack-below-tablet\">До 20 авг 2017 <div class=\"h-fz--16 h-mt--8\">3 500&#8239;<span class='h-font--rouble'>i</span></div></div> <div class=\"col--8 col--stack-below-tablet\">С 22 сен 2017 <div class=\"h-fz--16 h-mt--8\">15 102&#8239;<span class='h-font--rouble'>i</span></div></div> </div> </div> </div>",
  popupSimpleTemplate: "<div class=\"passenger-card__remove_popup-overlay\"></div> <div class=\"passenger-card__remove_popup\" tabindex=\"0\" role=\"dialog\"> <p class=\"passenger-card__remove_popup-title h-mb--24\"></p> <div class=\"wrapper h-align--center\" role=\"region\"> <a href=\"javascript:void(0)\" class=\"button js-remove-passenger-close\" role=\"button\">Хорошо</a> </div> </div>",
  currentParent: null,
  timeout: null,
  show: function(parent, text, type) {
    var currentParent, popup;
    currentParent = parent;
    popup = document.createElement('div');
    popup.className = 'passenger-card js-passenger-card-remove-popup';
    if (type === 'simple') {
      popup.innerHTML = this.popupSimpleTemplate;
    } else if (type === 'hotel') {
      popup.innerHTML = this.popupHotelTemplate;
    } else {
      popup.innerHTML = this.popupTemplate;
    }
    document.body.appendChild(popup);
    popup.getElementsByClassName('passenger-card__remove_popup-title')[0].innerHTML = text;
    clearTimeout(this.timeout);
    return this.timeout = delay(100, function() {
      popup.getElementsByClassName('passenger-card__remove_popup')[0].addClass('show');
      popup.getElementsByClassName('passenger-card__remove_popup-overlay')[0].addClass('show');
      return popup.getElementsByClassName('passenger-card__remove_popup')[0].focus();
    });
  },
  close: function(answer) {
    return document.getElementsByClassName('js-passenger-card-remove-popup').remove();
  },
  focusThis: function() {
    return document.getElementsByClassName('js-passenger-card-remove-popup').focus();
  }
};

document.addEventListener("DOMContentLoaded", function() {
  var checkbox, hideBonusBLock, inputUnlimitedMod, j, k, l, len, len1, len2, len3, link, m, pasportEndUnlimited, passangerCardSpecialTextarea, passangerGender, passangerGenderActive, passangerGenderError, passangerGenderNonActive, radio, ref, ref1, ref2, ref3, showBonusBLock;
  showBonusBLock = function(passengerCard) {
    var bonusInput, j, len, ref, results;
    ref = passengerCard.querySelectorAll('.js-passanger-card__bonus .input__text-input');
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      bonusInput = ref[j];
      results.push(bonusInput.removeAttribute('disabled'));
    }
    return results;
  };
  hideBonusBLock = function(passengerCard) {
    var bonusInput, j, len, ref, results;
    ref = passengerCard.querySelectorAll('.js-passanger-card__bonus .input__text-input');
    results = [];
    for (j = 0, len = ref.length; j < len; j++) {
      bonusInput = ref[j];
      results.push(bonusInput.setAttribute('disabled', true));
    }
    return results;
  };
  ref = document.getElementsByClassName('js-passanger-card__show-bonus');
  for (j = 0, len = ref.length; j < len; j++) {
    checkbox = ref[j];
    checkbox.addEventListener("change", function() {
      if (this.checked) {
        return showBonusBLock(this.parentNode.parentNode.parentNode.parentNode);
      } else {
        return hideBonusBLock(this.parentNode.parentNode.parentNode.parentNode);
      }
    });
    if (checkbox.checked) {
      showBonusBLock(checkbox.parentNode.parentNode.parentNode.parentNode);
    } else {
      hideBonusBLock(checkbox.parentNode.parentNode.parentNode.parentNode);
    }
  }
  passangerGender = 'js-passenger-card__gender-item';
  passangerGenderActive = 'passenger-card__gender-item--active';
  passangerGenderNonActive = 'passenger-card__gender-item--non-active';
  passangerGenderError = 'passenger-card__gender-item--error';
  ref1 = document.getElementsByClassName(passangerGender);
  for (k = 0, len1 = ref1.length; k < len1; k++) {
    radio = ref1[k];
    radio.addEventListener("click", function(e) {
      var group, i, l, len2, ref2;
      group = this.parentNode;
      if (!this.hasClass(passangerGenderActive)) {
        ref2 = group.getElementsByClassName(passangerGender);
        for (l = 0, len2 = ref2.length; l < len2; l++) {
          i = ref2[l];
          i.removeClass(passangerGenderActive);
          i.setAttribute('aria-pressed', false);
          i.addClass(passangerGenderNonActive);
          if (i.hasClass(passangerGenderError)) {
            i.removeClass(passangerGenderError);
            group.setAttribute('aria-invalid', false);
            group.removeAttribute("data-popover");
            group.removeAttribute("data-popover-description");
            group.removeAttribute("data-popover-id");
            group.removeAttribute("data-popover-type");
          }
        }
        this.removeClass(passangerGenderNonActive);
        this.addClass(passangerGenderActive);
        this.setAttribute('aria-pressed', true);
        group.dataset.gender = this.dataset.genderValue;
      }
      return e.preventDefault();
    });
  }
  passangerCardSpecialTextarea = 'js-passanger-card--show-textarea';
  ref2 = document.querySelectorAll('.' + passangerCardSpecialTextarea);
  for (l = 0, len2 = ref2.length; l < len2; l++) {
    checkbox = ref2[l];
    checkbox.addEventListener("change", function(e) {
      var area;
      area = this.parentNode.nextSibling.nextSibling.getElementsByClassName('input__textarea')[0];
      if (this.checked) {
        area.removeClass('h-display--none');
        return area.querySelector('textarea').focus();
      } else {
        return area.addClass('h-display--none');
      }
    });
  }
  pasportEndUnlimited = 'js-passenger-card__unlimited';
  inputUnlimitedMod = 'passenger-card__input--unlimited';
  ref3 = document.getElementsByClassName(pasportEndUnlimited);
  for (m = 0, len3 = ref3.length; m < len3; m++) {
    link = ref3[m];
    link.addEventListener("click", function(e) {
      var input, inputComponent;
      inputComponent = this.parentNode.previousElementSibling;
      input = inputComponent.getElementsByClassName('input__text-input')[0];
      if (inputComponent.hasClass(inputUnlimitedMod)) {
        inputComponent.removeClass(inputUnlimitedMod);
        input.disabled = false;
        this.text = 'Бессрочно';
      } else {
        inputComponent.addClass(inputUnlimitedMod);
        input.disabled = 'disabled';
        this.text = 'Указать срок';
      }
      return e.preventDefault();
    });
  }
  document.addEventListener('click', (function(_this) {
    return function(e) {
      var title;
      if (e.target && e.target.hasClass('js-remove-passenger-close')) {
        removePassengerPopup.close();
      }
      if ((e.target || e.target.parentNode) && (e.target.hasClass('js-remove-passenger') || e.target.parentNode && e.target.parentNode.hasClass('js-remove-passenger'))) {
        title = 'Вы точно хотите удалить этого пассажира?';
        return removePassengerPopup.show(e.target.closest('.passenger-card'), title);
      } else if ((e.target || e.target.parentNode) && (e.target.hasClass('js-booking-sending') || e.target.parentNode && e.target.parentNode.hasClass('js-booking-sending'))) {
        title = 'Ваша маршрутная квитанция отправлена на указанный адрес';
        return removePassengerPopup.show(e.target.closest('.passenger-card'), title, 'simple');
      } else if ((e.target || e.target.parentNode) && (e.target.hasClass('js-remove-hotel') || e.target.parentNode && e.target.parentNode.hasClass('js-remove-hotel'))) {
        title = 'Вы точно хотите отказаться от выбранного отеля?';
        return removePassengerPopup.show(e.target.closest('.passenger-card'), title, 'hotel');
      }
    };
  })(this));
  return document.addEventListener("keydown", function(e) {
    if (e.keyCode === 27) {
      return removePassengerPopup.close();
    }
  });
});







var __popover_process__, popopverFullScreenBreakpoint, popoverClose, popoverInit;

popopverFullScreenBreakpoint = 800;

__popover_process__ = function(e, popover_type, el, focus) {
  var delayTime, div, i, len, popover_rect, rect, ref, text, title, upperElem;
  if (e.target.popoverOpened || !e.target.hasData('popoverDescription', true) && !e.target.hasData('popoverTarget', true) || e.offsetParent && !e.target.offsetParent.hasClass('has-error')) {
    return true;
  }
  rect = e.target.getRelativeClientRect(document.body);
  if (popover_type === 'input_error') {
    text = e.target.dataset['popoverDescription'];
  } else {
    if (e.target.hasData('popoverTarget')) {
      text = document.querySelector("[data-popover-id='" + e.target.dataset['popoverTarget'] + "']").innerHTML;
    } else {
      text = e.target.dataset['popoverDescription'];
    }
  }
  document.querySelectorAll('.popover').remove();
  div = ("<div class='popover" + (popover_type === "input_error" || popover_type === "checkbox_error" || popover_type === "error" ? " popover--error" : popover_type === "notify" ? " popover--notify" : "") + "'>" + (e.target.hasData("popoverTitle") ? '<div class="popover__title"></div>' : '') + "<div class='popover__content'>" + text + "</div></div>").toHTML();
  div.fireParent = e.target;
  if (e.target.dataset['popoverId']) {
    div.id = e.target.dataset['popoverId'];
  }
  document.body.appendChild(div);
  if (e.target.hasData('popoverTitle')) {
    title = e.target.dataset['popoverTitle'];
    document.querySelector('.popover__title').innerHTML = title;
  }
  popover_rect = div.getRelativeClientRect(document.body);
  if (e.target.hasData('popoverFull')) {
    div.style.width = el.offsetWidth + "px";
  }
  if (e.target.dataset['popoverWidth']) {
    if (e.target.dataset.popoverWidth === 'auto') {
      div.style.width = 'auto';
      div.style.right = 'auto';
    } else if (window.innerWidth > 600) {
      div.style.width = e.target.dataset.popoverWidth + 'px';
    }
  }
  if (e.target.dataset['popoverPosition'] === 'bottom' || e.target.dataset['popoverTitle']) {
    div.addClass('popover--bottom');
    div.style.left = rect.left + "px";
    div.style.top = (rect.top + rect.height + 10) + "px";
  } else if (e.target.dataset['popoverPosition'] === 'top-center') {
    div.addClass('popover--top-center');
    div.style.left = (Math.ceil(rect.left - (div.offsetWidth - Math.ceil(rect.width)) / 2)) + "px";
    div.style.top = (rect.top - rect.height) + "px";
  } else if (e.target.dataset['popoverPosition'] === 'bottom-center') {
    div.addClass('popover--bottom-center');
    div.style.left = (rect.left - (div.offsetWidth - rect.width) / 2) + "px";
    div.style.top = (rect.top + rect.height + 10) + "px";
  } else if (e.target.dataset['popoverPosition'] === 'bottom-right') {
    div.style.right = (rect.right - 8) + "px";
    div.addClass('popover--bottom-right');
    div.style.left = 'auto';
  } else {
    if (rect.width < 30) {
      div.style.left = (rect.left + rect.width / 2 - (8 + 9)) + "px";
    } else {
      div.style.left = rect.left + "px";
    }
    div.style.top = (rect.top - div.offsetHeight - 11) + "px";
  }
  if (rect.left + popover_rect.width > document.body.offsetWidth && !div.hasClass('popover--bottom-center')) {
    div.style.right = rect.right + "px";
    div.addClass('popover--bottom-right');
    div.style.left = 'auto';
  }
  if (rect.right + popover_rect.width > document.body.offsetWidth && !div.hasClass('popover--bottom-center')) {
    div.style.left = rect.left + "px";
    div.addClass('popover--bottom-left');
    div.style.right = 'auto';
  }
  if (e.target.dataset['popoverTitle']) {
    div.addClass('popover--entitled');
  } else if (e.target.dataset['popoverTarget'] && !e.target.dataset['popoverTitle']) {
    div.addClass('h-width--240');
  }
  if (popover_type === 'price') {
    div.style.left = (rect.left + rect.width - 38 - 3 - 9) + "px";
    div.addClass('popover--price');
    div.addClass('popover--center-horizontal');
  }
  if (popover_type === 'noborder') {
    div.addClass('popover--noborder');
  }
  if (popover_type === 'checkbox_error') {
    div.style.left = (rect.left - 5) + "px";
  }
  if (div.getBoundingClientRect().bottom > document.documentElement.clientHeight && !e.target.dataset['popoverTitle'] && window.innerWidth < 1050) {
    if (div.hasClass('popover--bottom')) {
      div.classList.remove('popover--bottom');
      div.addClass('popover--top');
      if (div.hasClass('popover--bottom-center')) {
        div.classList.remove('popover--bottom-center');
        div.addClass('popover--top-center');
      }
    }
    if (div.hasClass('popover--bottom-right')) {
      div.classList.remove('popover--bottom-right');
      div.addClass('popover--top-right');
    }
    div.style.top = (rect.top - div.offsetHeight - 9) + "px";
  }
  if ((div.getBoundingClientRect().top - div.getBoundingClientRect().height) < 0) {
    if (div.hasClass('popover--top')) {
      div.classList.remove('popover--top');
    }
    if (div.hasClass('popover--top-center')) {
      div.addClass('popover--bottom-center');
    } else {
      div.addClass('popover--bottom');
    }
    if (popover_type === 'price') {
      div.style.top = (rect.top + rect.height - 20) + "px";
    } else {
      div.style.top = (rect.top + rect.height + 10) + "px";
    }
  }
  ref = document.querySelectorAll('.pika-lendar, .search-form__dropdown, .dropdown');
  for (i = 0, len = ref.length; i < len; i++) {
    upperElem = ref[i];
    if (upperElem && div) {
      upperElem.addEventListener('mouseenter', function(e) {
        e.target.popoverOpened = false;
        return document.querySelectorAll('.popover').remove();
      });
    }
  }
  e.target.popoverOpened = true;
  toggle.init(document.querySelector('.popover'));
  if (el.dataset['popoverBreakpoint'] === 'not-mobile' && screen.width <= popopverFullScreenBreakpoint) {
    return e.target.popoverOpened = false;
  } else {
    if (focus) {
      if (isTouchDevice()) {
        delayTime = 650;
      } else {
        delayTime = 10;
      }
      delay(delayTime, function() {
        div.style.transform = 'translate(0, 0)';
        return div.style.opacity = 1;
      });
      return e.target.addEventListener('blur', function(e) {
        e.target.popoverOpened = false;
        return document.querySelectorAll('.popover').remove();
      }, true);
    } else {
      return delay(100, function() {
        div.addEventListener('mouseleave', function(e) {
          if (!e.relatedTarget.hasData('popover') && !e.relatedTarget.offsetParent.hasData('popover')) {
            e.target.fireParent.popoverOpened = false;
            return document.getElementsByClassName('popover').remove();
          }
        });
        div.style.transform = 'translate(0, 0)';
        return div.style.opacity = 1;
      });
    }
  }
};

popoverClose = function(target) {
  if (!target.relatedTarget.hasClass('popover') && !target.relatedTarget.hasClass('popover__title') && !target.relatedTarget.offsetParent.hasClass('popover__content') && !target.relatedTarget.hasClass('popover__content')) {
    target.target.popoverOpened = false;
    return document.getElementsByClassName('popover').remove();
  }
};

popoverInit = function() {
  var el, i, len, ref;
  ref = document.querySelectorAll('[data-popover]');
  for (i = 0, len = ref.length; i < len; i++) {
    el = ref[i];
    if (el.plugins && el.plugins.indexOf('popover' > 0)) {
      return true;
    }
    if (el.dataset['popoverType'] === 'input_error' || el.dataset['popoverType'] === 'error') {
      el.setAttribute('aria-invalid', true);
    }
    if (el.dataset['popoverType'] === 'input_error') {
      el.addEventListener('focus', function(e) {
        return __popover_process__(e, 'input_error', e.target, true);
      });
    } else if (el.dataset['popoverType'] === 'input') {
      el.addEventListener('focus', function(e) {
        return __popover_process__(e, 'input', e.target, true);
      });
    } else {
      if (el.dataset['popoverType'] === 'error') {
        el.addEventListener('focus', function(e) {
          return __popover_process__(e, 'error', e.target, true);
        });
        if (window.innerWidth < 1050) {
          el.addEventListener('click', function(e) {
            return __popover_process__(e, 'error', e.target, false);
          });
        } else {
          el.addEventListener('mouseenter', function(e) {
            return __popover_process__(e, 'error', e.target, false);
          });
          el.addEventListener('focus', function(e) {
            return __popover_process__(e, 'default', e.target, true);
          });
        }
      } else if (el.dataset['popoverType'] === 'checkbox_error') {
        el.addEventListener('mouseenter', function(e) {
          return __popover_process__(e, 'checkbox_error', e.target, false);
        });
        el.addEventListener('focus', function(e) {
          return __popover_process__(e, 'default', e.target, true);
        });
      } else if (el.dataset['popoverType'] === 'price') {
        el.addEventListener('mouseenter', function(e) {
          return __popover_process__(e, 'price', e.target, false);
        });
        el.addEventListener('focus', function(e) {
          return __popover_process__(e, 'default', e.target, true);
        });
      } else if (el.dataset['popoverType'] === 'noborder') {
        el.addEventListener('mouseenter', function(e) {
          return __popover_process__(e, 'noborder', e.target, false);
        });
        el.addEventListener('focus', function(e) {
          return __popover_process__(e, 'default', e.target, true);
        });
      } else if (el.dataset['popoverType'] === 'notify') {
        el.addEventListener('mouseenter', function(e) {
          return __popover_process__(e, 'notify', e.target, false);
        });
        el.addEventListener('focus', function(e) {
          return __popover_process__(e, 'default', e.target, true);
        });
        if (window.innerWidth < 1050) {
          el.addEventListener('click', function(e) {
            return __popover_process__(e, 'notify', e.target, false);
          });
        }
      } else {
        if (screen.width <= popopverFullScreenBreakpoint && isTouchDevice()) {
          el.addEventListener('click', function(e) {
            return __popover_process__(e, 'default', e.target, false);
          });
        } else {
          el.addEventListener('mouseenter', function(e) {
            return __popover_process__(e, 'default', e.target, false);
          });
          el.addEventListener('focus', function(e) {
            return __popover_process__(e, 'default', e.target, true);
          });
        }
      }
      el.addEventListener('mouseleave', function(e) {
        return popoverClose(e);
      });
      if (el.dataset['popoverClick'] === 'close') {
        el.addEventListener('click', function(e) {
          e.target.popoverOpened = false;
          return document.getElementsByClassName('popover').remove();
        });
        el.addEventListener('keydown', function(e) {
          if (e.keyCode === 13) {
            e.target.popoverOpened = false;
            return document.getElementsByClassName('popover').remove();
          }
        });
      }
      if (isTouchDevice()) {
        document.addEventListener('touchstart', function(e) {
          if (!e.target.hasClass('popover') && !e.target.offsetParent.hasClass('popover__content') && !e.target.hasClass('popover__content') && !e.target.hasData('popover')) {
            e.target.popoverOpened = false;
            return document.getElementsByClassName('popover').remove();
          }
        });
      }
    }
    if (el.plugins) {
      el.plugins.push('popover');
    } else {
      el.plugins = ['popover'];
    }
  }
};

document.addEventListener("DOMContentLoaded", (function(_this) {
  return function() {
    return popoverInit();
  };
})(this));

window.addEventListener("resize", (function(_this) {
  return function() {
    return popoverInit();
  };
})(this));





var RangeSlider;

RangeSlider = (function() {
  function RangeSlider(element, min, max) {
    var endEvent, moveEvent, startEvent, touchSupport;
    this.element = element;
    this.min = min;
    this.max = max;
    if (this.element == null) {
      return;
    }
    this.touched = false;
    this.min = this.min || parseFloat(this.element.dataset.sliderMin || 0);
    this.max = this.max || parseFloat(this.element.dataset.sliderMax || 100) - this.min;
    this.changePoints = document.createEvent('Event');
    this.changePoints.initEvent('change', true, true);
    this.left_point = this.element.querySelector('.range-slider__point--left') || {
      "offsetLeft": 0,
      "style": Object,
      "isPhantom": true
    };
    this.right_point = this.element.querySelector('.range-slider__point--right');
    this.bar = this.element.querySelector('.range-slider__active');
    touchSupport = window.ontouchstart !== void 0;
    startEvent = touchSupport ? 'touchstart' : 'mousedown';
    moveEvent = touchSupport ? 'touchmove' : 'mousemove';
    endEvent = touchSupport ? 'touchend' : 'mouseup';
    document.addEventListener(moveEvent, this.updatePoints.bind(this));
    document.addEventListener(endEvent, (function(_this) {
      return function(e) {
        document.body.style.cursor = '';
        document.body.removeClass('noselect');
        return _this.touched = false;
      };
    })(this));
    this.element.addEventListener(startEvent, (function(_this) {
      return function(e) {
        document.body.style.cursor = 'pointer';
        document.body.addClass('noselect');
        _this.touched = true;
        return _this.updatePoints(e);
      };
    })(this));
    window.addEventListener('resize', (function(_this) {
      return function(e) {
        return _this.refreshOnResize(e);
      };
    })(this));
    window.addEventListener('orientationchange', (function(_this) {
      return function(e) {
        return _this.refreshOnResize(e);
      };
    })(this));
  }

  RangeSlider.prototype.refreshOnResize = function(e) {
    this.left_point.style.left = (this.left_point.offsetLeft / (this.element.offsetWidth - this.left_point.offsetWidth) * 100) + "%";
    this.right_point.style.left = (this.right_point.offsetLeft / (this.element.offsetWidth - this.right_point.offsetWidth) * 100) + "%";
    if (this.right_point.offsetLeft + this.right_point.offsetWidth > this.element.offsetWidth) {
      this.right_point.style.left = (this.element.offsetWidth - this.right_point.offsetWidth) + "px";
    }
    this.bar.style.width = (this.right_point.offsetLeft - this.left_point.offsetLeft) + "px";
    return this.bar.style.left = this.left_point.offsetLeft + "px";
  };

  RangeSlider.prototype.checkPageXY = function(e) {
    var body, html;
    if (e.pageX === null && e.clientX !== null) {
      html = document.documentElement;
      body = document.body;
      e.pageX = e.clientX + (html.scrollLeft || body && body.scrollLeft || 0);
      e.pageX -= html.clientLeft || 0;
      e.pageY = e.clientY + (html.scrollTop || body && body.scrollTop || 0);
      return e.pageY -= html.clientTop || 0;
    }
  };

  RangeSlider.prototype.updatePoints = function(e) {
    var active_point, cursor, inactive_point, left_percent, newPosition, right_percent;
    if (!this.touched) {
      return;
    }
    this.width100 = this.element.offsetWidth - this.right_point.offsetWidth;
    this.checkPageXY(e);
    cursor = (e.pageX || e.touches[0].pageX) - this.element.getBoundingClientRect().left;
    if (this.left_point.isPhantom) {
      active_point = this.right_point;
      inactive_point = this.left_point;
    } else if (Math.abs(this.left_point.offsetLeft - cursor) > Math.abs(this.right_point.offsetLeft - cursor)) {
      active_point = this.right_point;
      inactive_point = this.left_point;
    } else {
      active_point = this.left_point;
      inactive_point = this.right_point;
    }
    newPosition = cursor - active_point.offsetWidth / 2;
    if (Math.abs(newPosition - inactive_point.offsetLeft) > 20 || inactive_point.isPhantom) {
      active_point.style.left = newPosition + "px";
      if (this.left_point.offsetLeft < 1) {
        this.left_point.style.left = "0px";
      }
      if (this.right_point.offsetLeft + this.right_point.offsetWidth > this.element.offsetWidth) {
        this.right_point.style.left = (this.element.offsetWidth - this.right_point.offsetWidth) + "px";
      }
      if (this.right_point.offsetLeft < 1) {
        this.right_point.style.left = "0px";
      }
      left_percent = this.left_point.offsetLeft / this.width100 * 100;
      right_percent = this.right_point.offsetLeft / this.width100 * 100;
      this.changePoints.slider_from = this.max * left_percent / 100 + this.min;
      this.changePoints.slider_to = this.changePoints.slider_value = this.max * right_percent / 100 + this.min;
      this.element.dispatchEvent(this.changePoints);
      return this.getDistance();
    }
  };

  RangeSlider.prototype.getDistance = function() {
    this.bar.style.width = (this.right_point.offsetLeft - this.left_point.offsetLeft) + "px";
    return this.bar.style.left = this.left_point.offsetLeft + "px";
  };

  return RangeSlider;

})();





(function() {
  var controlVisibilityBreadcrumbsInRoute, findeRouteWithBreadcrumbs, heightBreadcrumbsInOneLine, listRouteWithBreadcrumbs;
  listRouteWithBreadcrumbs = null;
  heightBreadcrumbsInOneLine = 26;
  findeRouteWithBreadcrumbs = function() {
    return listRouteWithBreadcrumbs = document.querySelectorAll('.js-route-breadcrumbs');
  };
  controlVisibilityBreadcrumbsInRoute = function() {
    var breadсrumbsInСurrentRouteItem, heightBreadсrumbsInСurrentRouteItem, i, len, results, routeItem;
    results = [];
    for (i = 0, len = listRouteWithBreadcrumbs.length; i < len; i++) {
      routeItem = listRouteWithBreadcrumbs[i];
      breadсrumbsInСurrentRouteItem = routeItem.querySelector('.breadcrumb__wrap');
      heightBreadсrumbsInСurrentRouteItem = breadсrumbsInСurrentRouteItem.clientHeight;
      if (heightBreadсrumbsInСurrentRouteItem > heightBreadcrumbsInOneLine) {
        results.push(routeItem.classList.add('route--breadcrumb-hover'));
      } else {
        results.push(routeItem.classList.remove('route--breadcrumb-hover'));
      }
    }
    return results;
  };
  window.addEventListener("resize", function() {
    return controlVisibilityBreadcrumbsInRoute();
  });
  return document.addEventListener("DOMContentLoaded", function() {
    findeRouteWithBreadcrumbs();
    return controlVisibilityBreadcrumbsInRoute();
  });
})();

var searchDropdownFullScreenBreakpoint;

searchDropdownFullScreenBreakpoint = 800;

window.searchDropdown = {
  init: function() {
    var body, dropdown, el, i, len, ref, showDropdown;
    ref = document.querySelectorAll('[data-search-dropdown]');
    for (i = 0, len = ref.length; i < len; i++) {
      el = ref[i];
      dropdown = document.querySelectorAll('[data-search-dropdown-id="' + el.dataset.searchDropdownTarget + '"]')[0];
      body = document.getElementsByTagName('body')[0];
      body.appendChild(dropdown);
      showDropdown = function(e) {
        var activeItemClass, dropdownItems, firstChildDropdown, itemClass, j, len1, ref1, targetDropdown, toggleActiveItem, toggler;
        targetDropdown = document.querySelectorAll('[data-search-dropdown-id="' + this.dataset.searchDropdownTarget + '"]')[0];
        window.searchDropdown.positionDropdown(this, targetDropdown);
        itemClass = 'search-form__dropdown-item';
        dropdownItems = targetDropdown.querySelectorAll('.' + itemClass);
        firstChildDropdown = dropdownItems[0];
        if (e.keyCode === 40 || e.keyCode === 38 || e.keyCode === 13 || e.type === 'click') {
          e.preventDefault();
          if (this.dataset.showed !== 'true') {
            window.searchDropdown.hideDropdowns(false);
            targetDropdown.addClass('search-form__dropdown--show');
            targetDropdown.setAttribute('aria-expanded', true);
            targetDropdown.setAttribute('tabindex', 0);
            this.setAttribute('aria-expanded', true);
            this.dataset.showed = true;
            if (firstChildDropdown && !(e.type === 'click')) {
              window.searchDropdown.changeFocus(firstChildDropdown);
            }
            document.addEventListener('keydown', function(e) {
              if ((e.keyCode === 40 || e.keyCode === 38) && !(document.activeElement.closest('.search-form__dropdown')) && firstChildDropdown) {
                return window.searchDropdown.changeFocus(firstChildDropdown);
              }
            });
            window.searchDropdown.keyManage(targetDropdown, itemClass);
            activeItemClass = 'search-form__dropdown-item--active';
            ref1 = targetDropdown.querySelectorAll('.' + itemClass);
            for (j = 0, len1 = ref1.length; j < len1; j++) {
              toggler = ref1[j];
              toggleActiveItem = function(item) {
                var k, len2, ref2, results;
                ref2 = item.parentNode.querySelectorAll('.' + itemClass);
                results = [];
                for (k = 0, len2 = ref2.length; k < len2; k++) {
                  toggler = ref2[k];
                  toggler.removeClass(activeItemClass);
                  toggler.setAttribute('aria-selected', false);
                  toggler.removeAttribute('tabindex');
                  item.addClass(activeItemClass);
                  item.setAttribute('aria-selected', true);
                  results.push(item.setAttribute('tabindex', 0));
                }
                return results;
              };
              toggler.addEventListener("click", function(e) {
                return toggleActiveItem(this);
              });
              toggler.addEventListener("keydown", function(e) {
                if (e.keyCode === 13) {
                  return toggleActiveItem(this);
                }
              });
            }
          }
          e.preventDefault();
          return false;
        } else if (e.keyCode === 9) {
          if (this.dataset.showed === 'true') {
            e.preventDefault();
            return targetDropdown.focus();
          }
        }
      };
      el.addEventListener('click', showDropdown);
      if (!isTouchDevice()) {
        el.addEventListener('keydown', showDropdown);
      }
      dropdown.addEventListener('keydown', function(e) {
        var dropdownParent;
        dropdownParent = document.querySelectorAll('[data-search-dropdown-target="' + this.dataset.searchDropdownId + '"]')[0];
        if ((e.shiftKey && e.keyCode === 9 && e.target.hasClass('search-form__dropdown--show')) && window.searchDropdown.inDropdown(e.target) || (e.target.hasClass('js-dropdown-close') && e.keyCode === 13) || (e.keyCode === 27 && window.searchDropdown.inDropdown(e.target))) {
          e.preventDefault();
          return dropdownParent.focus();
        }
      });
    }
    document.body.addEventListener("click", function(e) {
      if ((e.target != null) && !window.searchDropdown.inDropdown(e.target) || e.target.hasClass('js-dropdown-close')) {
        if (e.target.hasClass('js-dropdown-close')) {
          e.preventDefault();
        }
        return window.searchDropdown.hideDropdowns(true);
      }
    });
    document.body.addEventListener("touchstart", function(e) {
      if ((e.target != null) && !window.searchDropdown.inDropdown(e.target) || e.target.hasClass('js-dropdown-close')) {
        if (e.target.hasClass('js-dropdown-close')) {
          e.preventDefault();
        }
        return window.searchDropdown.hideDropdowns(true);
      }
    });
    return document.addEventListener('keydown', function(e) {
      if (e.keyCode === 27 || e.keyCode === 13 && e.target.hasClass('js-dropdown-close')) {
        if (e.target.hasClass('js-dropdown-close')) {
          e.preventDefault();
        }
        return window.searchDropdown.hideDropdowns(true);
      }
    });
  },
  positionDropdown: function(handler, target) {
    var body, positionCalc;
    body = document.getElementsByTagName('body')[0];
    positionCalc = function() {
      var topShift;
      if (handler.dataset['searchDropdownFixed']) {
        topShift = handler.getBoundingClientRect(body).top + handler.clientHeight - 4;
        target.addClass('search-form__dropdown--fixed');
        if (handler.getBoundingClientRect(body).left + target.getBoundingClientRect(body).width > window.innerWidth) {
          target.style.right = handler.getBoundingClientRect(body).right + 'px';
        } else {
          target.style.left = handler.getBoundingClientRect(body).left + 'px';
        }
      } else {
        topShift = handler.getRelativeClientRect(body).top + handler.clientHeight - 4;
        if (handler.getRelativeClientRect(body).left + target.getRelativeClientRect(body).width > window.innerWidth || handler.dataset['searchDropdownPosition'] === 'right') {
          target.style.right = handler.getRelativeClientRect(body).right + 'px';
          target.style.left = 'auto';
        } else {
          target.style.left = handler.getRelativeClientRect(body).left + 'px';
          target.style.right = 'auto';
        }
      }
      if (handler.hasClass('input__text-input') || handler.hasClass('input__pseudo-select')) {
        target.style.top = topShift + 9 + 'px';
      } else {
        target.style.top = topShift + 'px';
      }
      if (handler.dataset['searchDropdownWidth']) {
        target.style.width = handler.dataset['searchDropdownWidth'] + 'px';
      } else {
        target.style.width = handler.offsetWidth + 'px';
      }
      if (screen.width <= searchDropdownFullScreenBreakpoint) {
        return target.style.maxWidth = handler.offsetWidth + 'px';
      } else {
        return target.style.maxWidth = '100%';
      }
    };
    positionCalc();
    return window.addEventListener("resize", function() {
      if (handler.dataset.showed === 'true') {
        return positionCalc();
      }
    });
  },
  hideDropdowns: function(remover) {
    var d, i, j, len, len1, ref, ref1, results, t;
    ref = document.querySelectorAll('[data-search-dropdown]');
    for (i = 0, len = ref.length; i < len; i++) {
      d = ref[i];
      d.dataset.showed = false;
      d.setAttribute('aria-expanded', false);
    }
    ref1 = document.querySelectorAll('[data-search-dropdown-id]');
    results = [];
    for (j = 0, len1 = ref1.length; j < len1; j++) {
      t = ref1[j];
      t.setAttribute('aria-expanded', false);
      t.setAttribute('tabindex', -1);
      if (remover === true && t.hasClass('search-form__dropdown--show')) {
        t.removeClass('search-form__dropdown--show');
        results.push(removeListener(t));
      } else {
        results.push(t.removeClass('search-form__dropdown--show'));
      }
    }
    return results;
  },
  inDropdown: function(target) {
    var parentIsDropdown;
    parentIsDropdown = function(node) {
      if (!node) {
        return;
      }
      if (node.hasClass('search-form__dropdown') || node.dataset.searchDropdown || node.dataset.searchDropdownTarget) {
        return true;
      } else if (node.tagName === 'BODY' || node.parentNode === void 0) {
        return false;
      } else {
        return parentIsDropdown(node.parentNode);
      }
    };
    return parentIsDropdown(target);
  },
  keyManage: function(target, item) {
    var changeActiveElement;
    changeActiveElement = function(e) {
      if (document.activeElement.closest('.' + item)) {
        if (e.keyCode === 40) {
          e.preventDefault();
          if (document.activeElement.next(item)) {
            return window.searchDropdown.changeFocus(document.activeElement.next(item), document.activeElement);
          }
        } else if (e.keyCode === 38) {
          e.preventDefault();
          if (document.activeElement.prev(item)) {
            return window.searchDropdown.changeFocus(document.activeElement.prev(item), document.activeElement);
          }
        }
      }
    };
    return target.addEventListener('keydown', changeActiveElement);
  },
  changeFocus: function(next, current) {
    if (current) {
      current.removeAttribute('tabindex');
    }
    next.setAttribute('tabindex', 0);
    return next.focus();
  }
};

document.addEventListener("DOMContentLoaded", function() {
  return window.searchDropdown.init();
});

document.addEventListener("DOMContentLoaded", (function(_this) {
  return function(event) {
    var el, i, len, ref, results;
    ref = document.querySelectorAll('.js-change-price');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      el = ref[i];
      results.push(el.addEventListener('click', function(e) {
        var month, week;
        week = this.parentNode.parentNode.parentNode.querySelectorAll('.js-price-chart__week')[0];
        month = this.parentNode.parentNode.parentNode.querySelectorAll('.js-price-chart__month')[0];
        if (this.dataset['isMonth'] === 'true') {
          week.removeClass('h-display--none');
          week.setAttribute('aria-expanded', true);
          month.addClass('h-display--none');
          month.setAttribute('aria-expanded', false);
          this.text = 'Цены на месяц';
          this.dataset['isMonth'] = false;
        } else {
          week.addClass('h-display--none');
          week.setAttribute('aria-expanded', false);
          month.removeClass('h-display--none');
          month.setAttribute('aria-expanded', true);
          this.text = 'Цены на неделю';
          this.dataset['isMonth'] = true;
        }
        e.preventDefault();
        return false;
      }));
    }
    return results;
  };
})(this));

var checkDirections, visible;

document.addEventListener("DOMContentLoaded", function(e) {
  var calendarDays, days, el, i, j, len, len1, ref, ref1, results, slider;
  window.initMapCustom();
  ref = document.querySelectorAll('[data-slider-id="days"]');
  for (i = 0, len = ref.length; i < len; i++) {
    el = ref[i];
    slider = new RangeSlider(el);
    days = document.querySelector('[data-slider-target="days_interval"]');
    el.addEventListener('change', function(e) {
      var interval;
      interval = (e.slider_from.formatMoney()) + ' – ' + (e.slider_to.formatMoney());
      switch (interval) {
        case 1:
          return days.innerHTML = interval + ' день';
        case 2:
        case 3:
          return days.innerHTML = interval + ' дня';
        default:
          return days.innerHTML = interval + ' дней';
      }
    });
  }
  window.addEventListener('scroll', function() {
    return checkDirections();
  });
  window.addEventListener("resize", function(e) {
    return checkDirections();
  });
  ref1 = document.querySelectorAll('[data-slider-id="calendar_days"]');
  results = [];
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    el = ref1[j];
    slider = new RangeSlider(el);
    calendarDays = document.querySelectorAll('[data-slider-target="calendar_days"]')[0];
    results.push(el.addEventListener('change', function(e) {
      var interval;
      interval = ~~e.slider_from + ' – ' + ~~e.slider_to;
      switch (~~e.slider_to) {
        case 2:
        case 3:
        case 4:
          return calendarDays.innerHTML = interval + ' дня';
        default:
          return calendarDays.innerHTML = interval + ' дней';
      }
    }));
  }
  return results;
});

visible = function(el) {
  if (!el) {
    return false;
  }
  return el.getBoundingClientRect().bottom < 0;
};

checkDirections = function() {
  var activeClass, body, floating, hoverClass;
  body = document.querySelector('.sexy-calendar__body');
  if (body) {
    floating = document.querySelector('.sexy-calendar__floating');
    activeClass = 'sexy-calendar__floating--active';
    hoverClass = 'sexy-calendar__floating--hover';
    if (!visible(body)) {
      if (floating.hasClass(activeClass)) {
        floating.removeClass(activeClass);
        window.searchDropdown.hideDropdowns();
      }
      if (floating.hasClass(hoverClass)) {
        floating.removeClass(hoverClass);
      }
    } else {
      floating.addClass(activeClass);
    }
    floating.addEventListener("mouseenter", function(e) {
      return e.target.addClass(hoverClass);
    });
    floating.addEventListener("mouseleave", function(e) {
      if (!document.activeElement.parentNode.hasClass('js-tracking-focus')) {
        return floating.removeClass(hoverClass);
      }
    });
    return document.addEventListener('click', function(e) {
      if (!e.target.closest('.sexy-calendar__floating--hover, .search-form__dropdown, .dropdown')) {
        return floating.removeClass(hoverClass);
      }
    });
  }
};





(function() {
  var activeClassForStickyHeader, activeClassTapInfo, activeHeaderClass, controlVisibilityInnerBlocksInStickyHeader, controlVisibilityStickyHeader, findeElementsInPage, floatingStickyHeader, hideBlockInStickyHeader, hideStickyHeader, hidingElementsInPage, showBlockInStickyHeader, showStickyHeader, stickyElementsInPage, tapInfo;
  floatingStickyHeader = null;
  stickyElementsInPage = null;
  tapInfo = null;
  activeClassTapInfo = 'seating__tap-info--show';
  hidingElementsInPage = null;
  activeClassForStickyHeader = 'sticky-header--active';
  activeHeaderClass = 'sticky-header__target--active';
  findeElementsInPage = function() {
    stickyElementsInPage = document.querySelectorAll('.js-sticky-header');
    floatingStickyHeader = document.querySelector('.sticky-header');
    tapInfo = document.querySelector('.seating__tap-info');
    return hidingElementsInPage = document.querySelectorAll('.js-sticky-hide-block');
  };
  showStickyHeader = function() {
    floatingStickyHeader.classList.add(activeClassForStickyHeader);
    if (!window.showTapInfo && tapInfo) {
      tapInfo.addClass(activeClassTapInfo);
      window.showTapInfo = true;
      window.clearTimeout(window.tapInfoTimeout);
      return window.tapInfoTimeout = setTimeout(function(e) {
        return tapInfo.removeClass(activeClassTapInfo);
      }, 5000);
    }
  };
  hideStickyHeader = function() {
    return floatingStickyHeader.classList.remove(activeClassForStickyHeader);
  };
  controlVisibilityStickyHeader = function() {
    if (!stickyElementsInPage || !stickyElementsInPage[0]) {
      return;
    }
    if (stickyElementsInPage[0].getBoundingClientRect().bottom < 0) {
      showStickyHeader();
    } else {
      hideStickyHeader();
    }
    return controlVisibilityInnerBlocksInStickyHeader();
  };
  showBlockInStickyHeader = function(dataAttr) {
    if (document.querySelector('.sticky-header__target--' + dataAttr)) {
      return document.querySelector('.sticky-header__target--' + dataAttr).addClass(activeHeaderClass);
    }
  };
  hideBlockInStickyHeader = function(dataAttr) {
    if (document.querySelector('.sticky-header__target--' + dataAttr).hasClass(activeHeaderClass)) {
      return document.querySelector('.sticky-header__target--' + dataAttr).removeClass(activeHeaderClass);
    }
  };
  controlVisibilityInnerBlocksInStickyHeader = function() {
    var currentDataAttr, currentDistanceToBottom, i, index, j, len, previousDataAttr, previousDistanceToBottom, results;
    results = [];
    for (index = j = 0, len = stickyElementsInPage.length; j < len; index = ++j) {
      i = stickyElementsInPage[index];
      currentDataAttr = stickyElementsInPage[index].getAttribute('data-sticky-header-mark');
      currentDistanceToBottom = stickyElementsInPage[index].getBoundingClientRect().bottom;
      if (stickyElementsInPage[index - 1]) {
        previousDistanceToBottom = stickyElementsInPage[index - 1].getBoundingClientRect().bottom;
        previousDataAttr = stickyElementsInPage[index - 1].getAttribute('data-sticky-header-mark');
      }
      if (currentDistanceToBottom < 0 && index === 0) {
        showBlockInStickyHeader(currentDataAttr);
        if (hidingElementsInPage[0].getBoundingClientRect().bottom < 190) {
          results.push(hideBlockInStickyHeader(currentDataAttr));
        } else {
          results.push(void 0);
        }
      } else if (currentDistanceToBottom < 0 && currentDistanceToBottom > previousDistanceToBottom) {
        hideBlockInStickyHeader(previousDataAttr);
        results.push(showBlockInStickyHeader(currentDataAttr));
      } else {
        results.push(hideBlockInStickyHeader(currentDataAttr));
      }
    }
    return results;
  };
  document.addEventListener('click', function(e) {
    var toggleButton;
    if (e.target.closest('.sticky-header__toggle')) {
      toggleButton = e.target.closest('.sticky-header__toggle');
      if (toggleButton.hasClass('sticky-header__toggle--active')) {
        toggleButton.removeClass('sticky-header__toggle--active');
        return document.querySelector('.toggle-target').removeClass('toggle-target--active');
      } else {
        toggleButton.addClass('sticky-header__toggle--active');
        return document.querySelector('.toggle-target').addClass('toggle-target--active');
      }
    }
  });
  document.addEventListener("DOMContentLoaded", function() {
    return findeElementsInPage();
  });
  return window.addEventListener('scroll', function() {
    return controlVisibilityStickyHeader();
  });
})();

document.addEventListener("DOMContentLoaded", function() {
  return document.addEventListener('click', function(e) {
    var i, j, k, len, len1, ref, ref1, tab;
    if (e.target.hasClass('tab__item')) {
      e.preventDefault();
      if (e.target.hasClass('tab__item--active')) {
        if (e.target.hasClass('tab__item--sorted')) {
          e.target.removeClass('tab__item--sorted');
        } else {
          e.target.addClass('tab__item--sorted');
        }
      }
      ref = e.target.parentNode.getElementsByClassName('tab__item');
      for (j = 0, len = ref.length; j < len; j++) {
        i = ref[j];
        i.removeClass('tab__item--active');
        i.setAttribute('aria-selected', false);
      }
      e.target.addClass('tab__item--active');
      e.target.setAttribute('aria-selected', true);
      if (e.target.hasData('targetTabId')) {
        tab = document.querySelector("[data-tab-id='" + e.target.dataset['targetTabId'] + "\']");
        ref1 = tab.parentNode.querySelectorAll('[data-tab-id]');
        for (k = 0, len1 = ref1.length; k < len1; k++) {
          i = ref1[k];
          i.addClass('wrapper--tab-hidden');
          i.setAttribute('aria-hidden', true);
        }
        tab.removeClass('wrapper--tab-hidden');
        tab.setAttribute('aria-hidden', false);
      }
      if (e.target.parentNode.hasClass('tab--clicked')) {
        return e.target.parentNode.removeClass('tab--clicked');
      } else {
        return e.target.parentNode.addClass('tab--clicked');
      }
    }
  });
});



var addAdviseTariff, manageTableShadow, setTableShadow;

manageTableShadow = function(parentTable, inner, table) {
  if (parentTable.hasClass('tariff-detail--shadow')) {
    if (table.getRelativeClientRect(inner).right === 0) {
      return parentTable.addClass('tariff-detail--shadow-hidden');
    } else {
      return parentTable.removeClass('tariff-detail--shadow-hidden');
    }
  }
};

setTableShadow = function() {
  var i, legend, legendHeight, len, ref, results, table;
  ref = document.querySelectorAll('.tariff-detail__table');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    table = ref[i];
    if (table.offsetWidth > table.parentNode.parentNode.offsetWidth) {
      table.parentNode.parentNode.addClass('tariff-detail--shadow');
      results.push((function() {
        var j, len1, ref1, results1;
        ref1 = document.querySelectorAll('.tariff-detail--shadow .tariff-detail__table-cell--legend');
        results1 = [];
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          legend = ref1[j];
          legendHeight = legend.parentNode.offsetHeight;
          results1.push(legend.style.height = legendHeight + 'px');
        }
        return results1;
      })());
    } else {
      results.push(table.parentNode.parentNode.removeClass('tariff-detail--shadow'));
    }
  }
  return results;
};

addAdviseTariff = function() {
  var tariffDetail, tariffDetailAdviseElem, tariffDetailAdviseTariff, tariffDetailTable, tariffDetailTableCellWrapper;
  tariffDetail = document.querySelector('.tariff-detail');
  if (!tariffDetail) {
    return;
  }
  tariffDetailTable = tariffDetail.querySelector('.tariff-detail__table');
  tariffDetailTableCellWrapper = tariffDetail.querySelector('.tariff-detail__table-cell-wrapper');
  tariffDetailAdviseTariff = tariffDetail.querySelector('.tariff-detail__advise-tariff');
  tariffDetailAdviseElem = tariffDetail.querySelector('.js-tariff-detail-advise');
  if (tariffDetailAdviseElem) {
    tariffDetailAdviseTariff.style.display = 'block';
    tariffDetailAdviseTariff.style.height = (tariffDetailTable.offsetHeight - 12) + 'px';
    tariffDetailAdviseTariff.style.width = tariffDetailAdviseElem.offsetWidth + 'px';
    return tariffDetailAdviseTariff.style.left = tariffDetailAdviseElem.getRelativeClientRect(tariffDetailTableCellWrapper).left + 'px';
  }
};

document.addEventListener("DOMContentLoaded", (function(_this) {
  return function(event) {
    var inner, parentTable, table;
    setTableShadow();
    window.addEventListener("resize", function(e) {
      return setTableShadow();
    });
    parentTable = document.querySelector('.tariff-detail');
    if (!parentTable) {
      return;
    }
    inner = parentTable.querySelector('.tariff-detail__inner');
    table = parentTable.querySelector('.tariff-detail__table');
    inner.addEventListener("scroll", function() {
      return manageTableShadow(parentTable, inner, table);
    });
    return addAdviseTariff();
  };
})(this));

var helperTop;

helperTop = function() {
  var body, handler, helper;
  body = document.getElementsByTagName('body')[0];
  handler = document.getElementsByClassName('js-tariff-helper')[0];
  helper = document.getElementsByClassName('tariff-helper')[0];
  if (handler) {
    if (window.innerWidth > 1050) {
      return helper.style.top = handler.getRelativeClientRect(body).top - helper.getRelativeClientRect(body).top + 'px';
    } else {
      return helper.style.top = 0;
    }
  }
};

document.addEventListener("DOMContentLoaded", function() {
  return helperTop();
});

window.addEventListener('resize', function() {
  return helperTop();
});







var TimePicker,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

TimePicker = (function() {
  TimePicker.prototype.hour = 0;

  TimePicker.prototype.minute = 0;

  TimePicker.prototype.template = "<div class='timepicker-popup'> <div class='timepicker-popup__wrapper'> <div class='timepicker-popup__hours'> <a href='javascript:void(0)' class='timepicker-popup__up'></a> <a href='javascript:void(0)' class='timepicker-popup__down'></a> </div> <div class='timepicker-popup__delimeter'>:</div> <div class='timepicker-popup__minutes'> <a href='javascript:void(0)' class='timepicker-popup__up'></a> <a href='javascript:void(0)' class='timepicker-popup__down'></a> </div> </div>";

  function TimePicker(element) {
    this.element = element;
    this.onChange = bind(this.onChange, this);
    this.removeDown = bind(this.removeDown, this);
    this.changeTime = bind(this.changeTime, this);
    if (this.element.getElementsByTagName('input')[0].value) {
      this.hour = this.element.getElementsByTagName('input')[0].value.parseTime()[0];
      this.minute = this.element.getElementsByTagName('input')[0].value.parseTime()[1];
    }
    this.element.getElementsByTagName('input')[0].addEventListener('focus', (function(_this) {
      return function() {
        var rect;
        _this.offsetHours = 0;
        _this.offsetMinutes = 0;
        _this.mouseDown = -1;
        _this.popup = _this.template.toHTML();
        document.body.prependChild(_this.popup);
        rect = _this.element.getRelativeClientRect(document.body);
        _this.popup.style.left = rect.left + "px";
        _this.popup.style.top = (rect.top + rect.height + 12) + "px";
        _this.popup.getElementsByClassName('timepicker-popup__wrapper')[0].addEventListener('mouseup', _this.removeDown);
        _this.popup.getElementsByClassName('timepicker-popup__wrapper')[0].addEventListener('mouseout', _this.removeDown);
        _this.popup.getElementsByClassName('timepicker-popup__wrapper')[0].addEventListener('mousedown', function(e) {
          return e.preventDefault();
        });
        _this.popup.getElementsByClassName('timepicker-popup__hours')[0].getElementsByClassName('timepicker-popup__up')[0].addEventListener('mousedown', function(e) {
          return _this.changeTime(e, 'up', 'hour');
        });
        _this.popup.getElementsByClassName('timepicker-popup__hours')[0].getElementsByClassName('timepicker-popup__down')[0].addEventListener('mousedown', function(e) {
          return _this.changeTime(e, 'down', 'hour');
        });
        _this.popup.getElementsByClassName('timepicker-popup__minutes')[0].getElementsByClassName('timepicker-popup__up')[0].addEventListener('mousedown', function(e) {
          return _this.changeTime(e, 'up', 'minute');
        });
        _this.popup.getElementsByClassName('timepicker-popup__minutes')[0].getElementsByClassName('timepicker-popup__down')[0].addEventListener('mousedown', function(e) {
          return _this.changeTime(e, 'down', 'minute');
        });
        _this.element.getElementsByTagName('input')[0].addEventListener('change', _this.onChange);
        return _this.update();
      };
    })(this));
    this.element.getElementsByTagName('input')[0].addEventListener('blur', (function(_this) {
      return function() {
        clearInterval(_this.mouseDown);
        return _this.popup.remove();
      };
    })(this));
  }

  TimePicker.prototype.changeTimeProcess = function(type, el) {
    if (el === 'hour') {
      if (type === 'up' && this.hour === 0) {
        this.hour = 23;
        this.offsetHours += 1158;
      } else if (type === 'up') {
        this.hour -= 1;
      } else if (type === 'down' && this.hour === 23) {
        this.hour = 0;
        this.offsetHours -= 1158;
      } else {
        this.hour += 1;
      }
    }
    if (el === 'minute') {
      if (type === 'up' && this.minute === 0) {
        this.minute = 59;
        this.offsetMinutes += 2890;
      } else if (type === 'up') {
        this.minute -= 1;
      } else if (type === 'down' && this.minute === 59) {
        this.minute = 0;
        this.offsetMinutes -= 2890;
      } else {
        this.minute += 1;
      }
    }
    return this.update();
  };

  TimePicker.prototype.changeTime = function(e, type, el) {
    e.preventDefault();
    this.changeTimeProcess(type, el);
    if (this.mouseDown === -1) {
      return this.mouseDown = interval(1000, (function(_this) {
        return function() {
          return _this.changeTimeProcess(type, el);
        };
      })(this));
    }
  };

  TimePicker.prototype.removeDown = function() {
    if (this.mouseDown !== -1) {
      clearInterval(this.mouseDown);
      return this.mouseDown = -1;
    }
  };

  TimePicker.prototype.update = function() {
    this.popup.getElementsByClassName('timepicker-popup__hours')[0].style.backgroundPosition = "50% " + (this.hour * -48 + this.offsetHours) + "px";
    this.popup.getElementsByClassName('timepicker-popup__minutes')[0].style.backgroundPosition = "50% " + (this.minute * -48 + this.offsetMinutes) + "px";
    return this.element.getElementsByTagName('input')[0].value = (this.hour.to10String()) + ":" + (this.minute.to10String());
  };

  TimePicker.prototype.onChange = function(e) {
    var time;
    time = e.target.value.parseTime();
    if (time) {
      this.hour = time[0];
      this.minute = time[1];
    }
    return this.update();
  };

  return TimePicker;

})();

document.addEventListener("DOMContentLoaded", (function(_this) {
  return function(event) {
    var el, i, len, ref, results;
    ref = document.getElementsByClassName('js-timepicker');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      el = ref[i];
      results.push(new TimePicker(el));
    }
    return results;
  };
})(this));



document.addEventListener("DOMContentLoaded", function() {
  var collapsed, i, len, ref, results;
  ref = document.getElementsByClassName('js-collapse');
  results = [];
  for (i = 0, len = ref.length; i < len; i++) {
    collapsed = ref[i];
    results.push(collapsed.addEventListener("click", function(e) {
      var block;
      block = e.currentTarget.parentNode;
      if (block.hasClass('vise--active')) {
        block.removeClass('vise--active');
        this.setAttribute('aria-expanded', false);
        return block.setAttribute('aria-expanded', false);
      } else {
        block.addClass('vise--active');
        this.setAttribute('aria-expanded', true);
        return block.setAttribute('aria-expanded', true);
      }
    }));
  }
  return results;
});

var childrenHighlight, positionWings, switchingPlaces, togglePosition;

togglePosition = function() {
  var body, seating, seatingTitle, toggle;
  toggle = document.querySelector('.seating__toggle');
  if (!toggle || toggle.classList.contains('h-display--none')) {
    return;
  }
  body = document.getElementsByTagName('body')[0];
  seating = document.querySelector('.seating');
  seatingTitle = seating.querySelector('.seating__title');
  if (seating.getBoundingClientRect().top - seatingTitle.clientHeight > 0) {
    toggle.style.position = 'absolute';
    toggle.style.top = (document.documentElement.clientHeight - toggle.clientHeight - seatingTitle.clientHeight) + 'px';
  } else {
    toggle.removeAttribute('style');
  }
  if (seating.getRelativeClientRect(body).top + seating.getRelativeClientRect(body).height - 100 > window.scrollY + document.documentElement.clientHeight - toggle.clientHeight) {
    return toggle.classList.add('seating__toggle--fixed');
  } else {
    return toggle.classList.remove('seating__toggle--fixed');
  }
};

switchingPlaces = function() {
  var checkPositionToggler, seating, seatingContainer, seatingContainerOverflow, seatingRow, seatingToggle, seatingToggleSlider, seatingWrapper, seatingWrapperBig;
  seating = document.querySelector('.seating');
  if (!seating) {
    return;
  }
  if (window.innerWidth > 600) {
    seating.querySelector('.seating__toggle').classList.add('h-display--none');
    return;
  }
  this.seatingOverflow = 'seating__container--overflow';
  this.wrapperBig = 'seating__wrapper--big';
  seatingContainer = document.querySelector('.seating__container');
  seatingWrapper = seating.querySelector('.seating__wrapper');
  seatingRow = seating.querySelector('.seating__row');
  if (seatingRow.children.length > 7) {
    seating.querySelector('.seating__toggle').classList.remove('h-display--none');
    seatingContainer.classList.add(this.seatingOverflow);
    seatingWrapper.classList.add(this.wrapperBig);
  }
  seatingContainerOverflow = document.querySelector('.' + this.seatingOverflow);
  if (!seatingContainerOverflow) {
    return;
  }
  seatingWrapperBig = document.querySelector('.' + this.wrapperBig);
  seatingToggleSlider = document.querySelector('.seating__toggle-slider');
  seatingToggle = document.querySelector('.seating__toggle');
  checkPositionToggler = function() {
    var seatingToggleSliderLeft, seatingToggleSliderRight;
    seatingToggleSliderLeft = seatingToggleSlider.getRelativeClientRect(seatingToggle).left;
    seatingToggleSliderRight = seatingToggleSlider.getRelativeClientRect(seatingToggle).right;
    if (seatingToggleSliderLeft < 0) {
      seatingToggleSlider.style.left = 0;
      return seatingToggleSlider.style.right = 'auto';
    } else if (seatingToggleSliderRight < 0) {
      seatingToggleSlider.style.right = 0;
      return seatingToggleSlider.style.left = 'auto';
    }
  };
  seatingContainerOverflow.addEventListener('scroll', function(evt) {
    var seatingContainerDistanceLeft, target;
    target = evt.target;
    seatingContainerDistanceLeft = target.scrollLeft / seatingWrapperBig.offsetWidth * 100;
    return seatingToggleSlider.style.left = seatingContainerDistanceLeft + '%';
  });
  return seatingToggleSlider.addEventListener('touchstart', function(evt) {
    var onMouseMove, onMouseUp, startCoords;
    startCoords = {
      x: evt.touches[0].clientX
    };
    onMouseMove = function(moveEvt) {
      var leftDistanseSeating, leftDistanseToggler, percentToggler, shift;
      shift = {
        x: startCoords.x - moveEvt.touches[0].clientX
      };
      startCoords = {
        x: moveEvt.touches[0].clientX
      };
      checkPositionToggler();
      leftDistanseToggler = seatingToggleSlider.getRelativeClientRect(seatingToggle).left - shift.x;
      seatingToggleSlider.style.left = leftDistanseToggler + 'px';
      percentToggler = leftDistanseToggler / seatingToggle.clientWidth * 100;
      leftDistanseSeating = seatingWrapper.clientWidth * percentToggler / 100;
      return seatingContainer.scrollLeft = leftDistanseSeating;
    };
    onMouseUp = function(upEvt) {
      checkPositionToggler();
      seatingToggleSlider.removeEventListener('touchmove', onMouseMove);
      return seatingToggleSlider.removeEventListener('touchend', onMouseUp);
    };
    seatingToggleSlider.addEventListener('touchmove', onMouseMove);
    return seatingToggleSlider.addEventListener('touchend', onMouseUp);
  });
};

positionWings = function() {
  var body, fade, i, len, range, ref, results, topRect, wingBottom, wingHeight, wingSide, wingTop, wingsBotHeight, wingsBotPos, wingsTopHeight, wingsTopPos, wrapper;
  if (window.innerWidth > 800) {
    range = 1392;
    wingHeight = 315;
    body = document.getElementsByTagName('body')[0];
    wrapper = document.getElementsByClassName('js-wrapper-fly')[0];
    fade = document.getElementsByClassName('wrapper__fade')[0];
    wingBottom = document.getElementsByClassName('js-wing-bottom')[0];
    ref = document.getElementsByClassName('js-wing-top');
    results = [];
    for (i = 0, len = ref.length; i < len; i++) {
      wingTop = ref[i];
      wingsTopPos = wingTop.getRelativeClientRect(body).top;
      wingsBotPos = wingBottom.getRelativeClientRect(body).top;
      wingsTopHeight = wingTop.getRelativeClientRect(body).height;
      wingsBotHeight = wingTop.getRelativeClientRect(body).height;
      topRect = -(range - wingsTopPos) + 'px';
      wrapper.style.backgroundPosition = '50%' + topRect;
      results.push((function() {
        var j, len1, ref1, results1;
        ref1 = document.getElementsByClassName('js-wings-side');
        results1 = [];
        for (j = 0, len1 = ref1.length; j < len1; j++) {
          wingSide = ref1[j];
          wingSide.style.top = wingsTopPos + wingHeight + 'px';
          results1.push(wingSide.style.height = wingsBotPos - wingsTopPos - wingHeight + wingsBotHeight + 5 + 'px');
        }
        return results1;
      })());
    }
    return results;
  }
};

childrenHighlight = function() {
  var adultPlace, childrenClass, epmty, i, icon, j, len, len1, next, nextClone, parent, parentNext, parentPrev, prev, prevClone, ref, ref1, results, srText;
  ref = document.querySelectorAll('[data-adult]');
  for (i = 0, len = ref.length; i < len; i++) {
    adultPlace = ref[i];
    if (adultPlace) {
      parent = adultPlace.parentNode.parentNode;
      epmty = 'seating__col--empty';
      childrenClass = 'seating__passenger--children';
      parentPrev = parent.previousElementSibling;
      if (parentPrev && !parentPrev.hasClass(epmty)) {
        prev = parentPrev.children[0].children[0];
        if (!prev.hasClass(childrenClass)) {
          prevClone = prev.cloneNode(true);
          prev.parentNode.appendChild(prevClone);
          prev.addClass(childrenClass);
        }
      }
      parentNext = parent.nextElementSibling;
      if (parentNext && !parentNext.hasClass(epmty)) {
        next = parentNext.children[0].children[0];
        if (!next.hasClass(childrenClass)) {
          nextClone = next.cloneNode(true);
          next.parentNode.appendChild(nextClone);
          next.addClass(childrenClass);
        }
      }
    }
  }
  ref1 = document.getElementsByClassName(childrenClass);
  results = [];
  for (j = 0, len1 = ref1.length; j < len1; j++) {
    icon = ref1[j];
    if (icon) {
      srText = document.createElement('div');
      srText.addClass('h-sr--only');
      srText.innerHTML = 'Это место вы можете выбрать для вашего ребенка';
      icon.parentNode.insertBefore(srText, icon);
      icon.insertBefore;
      if (icon.children[0] && icon.children[0].hasClass('icon--boy-blue')) {
        icon.children[0].removeClass('icon--boy-blue');
        icon.children[0].addClass('icon--boy-white');
      }
      if (icon.children[0] && icon.children[0].hasClass('icon--girl-blue')) {
        icon.children[0].removeClass('icon--girl-blue');
        results.push(icon.children[0].addClass('icon--girl-white'));
      } else {
        results.push(void 0);
      }
    } else {
      results.push(void 0);
    }
  }
  return results;
};

window.addEventListener("scroll", function() {
  return togglePosition();
});

window.addEventListener("resize", function() {
  switchingPlaces();
  return togglePosition();
});

document.addEventListener("DOMContentLoaded", function() {
  return switchingPlaces();
});

document.addEventListener("DOMContentLoaded", function() {
  positionWings();
  return childrenHighlight();
});

window.addEventListener("resize", function() {
  return positionWings();
});
