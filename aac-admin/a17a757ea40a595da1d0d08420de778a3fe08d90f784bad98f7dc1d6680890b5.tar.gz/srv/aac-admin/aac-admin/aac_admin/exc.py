class AACAdminError(Exception):
    code: str = ''
    msg: str = ''

    def __init__(self, msg: str=None, code: str=None) -> None:
        if msg is not None:
            self.msg = msg

        if code is not None:
            self.code = code

        super().__init__(msg)

    def __str__(self):
        return f'{self.__class__.__name__}({self.code}): {self.msg}'


class UnknownError(AACAdminError):
    code = '999001000'
    msg = 'Unknown error'
