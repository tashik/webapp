import base64
import json
import random
import string
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Tuple
from unittest.mock import patch

import fakeredis
from django.contrib import auth
from django.contrib.auth.models import AnonymousUser, Permission
from django.test import RequestFactory, TestCase

from django.contrib.auth.models import User
from django.urls import reverse

from aac_admin.exc import UnknownError
from aac_admin.utils.exc import AvailableExceptions
from aac_admin.views import root_view, login_view, logout_callback_view


class ViewTest(ABC):
    """
    Base class to check rights on view. Place it first in base classes list, like: class Test(ViewTest, TestCase):
    """
    expected_anonymous_status = 302
    expected_without_rights_status = 302
    expected_with_rights_status = 200

    @abstractmethod
    def get_testing_permission(self):
        pass

    @abstractmethod
    def get_request(self):
        pass

    @abstractmethod
    def get_response(self, request):
        pass

    def setUp(self):
        self.factory = RequestFactory()
        self.user_without_rights = User.objects.create(username='testing_user', password='top_secret')
        self.user_with_rights = User.objects.create(username='testing_user_client_rights', password='top_secret')
        testing_permissions = self.get_testing_permission()
        if isinstance(testing_permissions, list):
            for i in testing_permissions:
                self.user_with_rights.user_permissions.add(i)
        else:
            self.user_with_rights.user_permissions.add(testing_permissions)

    def tearDown(self):
        self.factory = None
        self.user_without_rights.delete()
        self.user_with_rights.delete()

    def test_anonymous(self):
        request = self.get_request()
        request.user = AnonymousUser()
        response = self.get_response(request)
        self.assertEqual(response.status_code, self.expected_anonymous_status)

    def test_without_rights(self):
        request = self.get_request()
        request.user = self.user_without_rights
        response = self.get_response(request)
        self.assertEqual(response.status_code, self.expected_without_rights_status)

    def test_with_rights(self):
        request = self.get_request()
        request.user = self.user_with_rights
        response = self.get_response(request)
        self.assertEqual(response.status_code, self.expected_with_rights_status)


class RedisMockTest:
    """
    Base class to test redis db. Place it first in base classes list, like: class Test(RedisMockTest, TestCase):
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.db = fakeredis.FakeStrictRedis()
        self.data = {}

    def setUp(self):
        redis_patcher = patch('aac_admin.utils.redis.REDIS_CLIENT', self.db)
        self.addCleanup(redis_patcher.stop)
        redis_patcher.start()
        self.flush_db()
        self.provide_test_data()

    def tearDown(self):
        self.flush_db()

    def flush_db(self):
        self.data.clear()
        self.db.flushdb()

    def provide_test_data(self):
        for aeroflot_id, client_id in self.default_aeroflot_id_client_id_tuples():
            self.add_session_to_user(aeroflot_id, client_id)

    @staticmethod
    def default_aeroflot_id_client_id_tuples():
        return ('user_1', 'client_id_1'), ('user_2', 'client_id_2')

    def add_session_to_user(self, aeroflot_id, client_id, iat: int = None, exp: int = None):
        session_id = self.generate_session_id()
        jti = self.generate_t_token_name()
        iat = iat if iat else self.generate_iat()
        exp = exp if exp else iat + 3600
        session, access_token = self.generate_session_value(aeroflot_id, client_id, jti, iat, exp)

        self.add_session_to_uid2sid(aeroflot_id, exp, session_id)
        self.set_jti(jti, session_id)
        self.set_session_info(session_id, session, exp - iat)

        self.data[jti] = {
            'aeroflot_id': aeroflot_id, 'sid': session_id, 'client_id': client_id,
            'access_token': access_token
        }

    def add_session_to_uid2sid(self, aeroflot_id, exp, session_id):
        self.db.zadd(aeroflot_id, exp, session_id)

    def set_jti(self, jti, session_id):
        self.db.set(jti, session_id)

    def set_session_info(self, session_id, session, ttl=3600):
        self.db.set(session_id, session, ttl)

    def generate_session_value(self, aeroflot_id, client_id, jti, iat, exp) -> Tuple[str, dict]:
        access_token_header = self.generate_default_access_token_header()
        access_token_payload = {
            'sub': aeroflot_id, 'jti': jti, 'aud': [client_id], 'azp': client_id,
            'iat': iat, 'exp': exp
        }
        data = {
            'client_id': client_id, 'sub': aeroflot_id,
            'access_token': self.generate_access_token_string(access_token_header, access_token_payload)
        }
        return json.dumps(data), access_token_payload

    @staticmethod
    def generate_access_token_string(header: dict, payload: dict) -> str:
        header_bytes = bytes(json.dumps(header), 'ascii')
        payload_bytes = bytes(json.dumps(payload), 'ascii')
        token = b''.join((base64.urlsafe_b64encode(header_bytes), b'.', base64.urlsafe_b64encode(payload_bytes)))
        return token.decode('ascii')

    @staticmethod
    def timestamp_to_date_str(timestamp, date_format: str = None):
        date_format = date_format if date_format else '%Y-%m-%dT%H:%M'
        return datetime.fromtimestamp(timestamp).strftime(date_format)

    @staticmethod
    def generate_default_access_token_header():
        return {'alg': 'HS256', 'typ': 'JWT'}

    @staticmethod
    def generate_iat() -> int:
        return int(datetime.now().timestamp())

    @staticmethod
    def generate_session_id():
        return ''.join(random.choices(string.ascii_lowercase + string.digits, k=56))

    @staticmethod
    def generate_t_token_name():
        return 'T-' + ''.join(random.choices(string.ascii_lowercase + string.digits, k=32))


class RootViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')

    def tearDown(self):
        self.user.delete()

    def test_anonymous(self):
        request = self.factory.get(reverse('home'))
        request.user = AnonymousUser()
        response = root_view(request)
        self.assertEqual(response.status_code, 302)

    def test_logged(self):
        request = self.factory.get(reverse('home'))
        request.user = self.user
        response = root_view(request)
        self.assertEqual(response.status_code, 200)


class LoginViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')

    def tearDown(self):
        self.user.delete()

    def test_anonymous(self):
        request = self.factory.get(reverse('login'))
        request.user = AnonymousUser()
        response = login_view(request)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('social:begin', args=['aac']))

    def test_logged(self):
        request = self.factory.get(reverse('home'))
        request.user = self.user
        response = login_view(request)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('home'))


class LogoutViewTest(TestCase):
    def setUp(self):
        self.password = 'top_secret'
        self.user = User.objects.create_user(username='testing_user', password=self.password)

    def tearDown(self):
        self.user.delete()

    def test_anonymous(self):
        response = self.client.get(reverse('logout'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('home'))
        self.assertEqual(auth.get_user(self.client), AnonymousUser())

    def test_logged(self):
        self.assertTrue(self.client.login(username=self.user.username, password=self.password))
        self.assertEqual(auth.get_user(self.client), self.user)
        response = self.client.get(reverse('logout'))
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('home'))
        self.assertEqual(auth.get_user(self.client), AnonymousUser())


class ErrorViewTest(TestCase):
    @patch('aac_admin.views.logging.getLogger')
    def test_empty(self, logging_mock):
        response = self.client.get(reverse('error'))
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.context['title'], 'Ошибка')
        self.assertEqual(response.context['error_code'], UnknownError.code)
        self.assertEqual(response.context['message'], UnknownError.msg)
        logging_mock.assert_called()
        logging_mock().error.assert_called()

    @patch('aac_admin.views.logging.getLogger')
    def test_with_code(self, logging_mock):
        exception = random.choice(list(AvailableExceptions)).value
        response = self.client.get(f'{reverse("error")}?error_code={exception.code}')
        self.assertEqual(response.status_code, 400)
        self.assertEqual(response.context['title'], 'Ошибка')
        self.assertEqual(response.context['error_code'], exception.code)
        self.assertEqual(response.context['message'], exception.msg)
        logging_mock.assert_called()
        logging_mock().error.assert_called()


class TestLogoutCallbackView(ViewTest, TestCase):
    expected_anonymous_status = 302
    expected_without_rights_status = 302
    expected_with_rights_status = 302

    def get_response(self, request):
        return logout_callback_view(request)

    def get_request(self):
        return self.factory.get(reverse('logout_callback'))

    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_user')
