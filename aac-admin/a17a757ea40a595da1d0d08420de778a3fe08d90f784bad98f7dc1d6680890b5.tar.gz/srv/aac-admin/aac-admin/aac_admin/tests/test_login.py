from django.test import TestCase
from django.contrib.auth.models import AnonymousUser
from django.test.client import RequestFactory
from django.urls import reverse

from aac_admin.views import login_view

# Create your tests here.


class LoginViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def tearDown(self):
        pass

    def test_login_view(self):
        request = self.factory.get(reverse('home'))
        request.user = AnonymousUser()
        response = login_view(request)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('social:begin', args=['aac']))
