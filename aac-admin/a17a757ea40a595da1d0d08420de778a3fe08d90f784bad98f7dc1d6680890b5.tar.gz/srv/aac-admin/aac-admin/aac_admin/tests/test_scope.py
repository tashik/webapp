import json

from django.contrib.auth.models import User, Permission
from django.test import TestCase, Client, RequestFactory
from django.urls import reverse

from aac_admin.forms import ScopeForm
from aac_admin.models import Scope
from aac_admin.views.scopes import ScopesView


class CreateScopeTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='add_aac_scope'))
        self.scope_value_name = 'create_scope_test_value'

    def tearDown(self):
        Scope.objects.filter(value=self.scope_value_name).delete()
        self.user.delete()

    def test_create(self):
        create_form = ScopeForm({'value': self.scope_value_name, 'description': {'ru': 'ru'}})
        self.assertTrue(create_form.is_valid())
        client = Client()
        client.force_login(self.user)
        response = client.post(reverse('scope-list'), json.dumps(create_form.cleaned_data), "application/json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(Scope.objects.filter(value='create_scope_test_value').exists())

    def test_create_duplicate(self):
        create_form = ScopeForm({'value': self.scope_value_name, 'description': {'ru': 'ru'}})
        self.assertTrue(create_form.is_valid())
        client = Client()
        client.force_login(self.user)
        response = client.post(reverse('scope-list'), json.dumps(create_form.cleaned_data), "application/json")
        self.assertEqual(response.status_code, 201)
        self.assertTrue(Scope.objects.filter(value='create_scope_test_value').exists())
        response = client.post(reverse('scope-list'), json.dumps(create_form.cleaned_data), "application/json")
        self.assertEqual(response.status_code, 400)


class UpdateScopeTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='add_aac_scope'))
        self.created_scope_value = 'created_scope_test_value'
        self.updated_scope_value = 'updated_scope_test_value'

    def tearDown(self):
        Scope.objects.filter(value=self.created_scope_value).delete()
        Scope.objects.filter(value=self.updated_scope_value).delete()
        self.user.delete()

    def test_update(self):
        create_form = ScopeForm({'value': self.created_scope_value, 'description': {'ru': 'ru'}})
        self.assertTrue(create_form.is_valid())
        created_scope = create_form.save()
        self.assertTrue(Scope.objects.filter(value=self.created_scope_value).exists())
        client = Client()
        client.force_login(self.user)
        url = reverse('scope-detail', kwargs={'pk': created_scope.id})
        update_form = ScopeForm({'value': self.updated_scope_value, 'description': {'ru': 'another_value'}})
        self.assertTrue(update_form.is_valid())
        response = client.put(url, json.dumps(update_form.cleaned_data), "application/json")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Scope.objects.filter(value=self.updated_scope_value).exists())
        self.assertEqual(created_scope.id, Scope.objects.get(value=self.updated_scope_value).id)

    def test_update_duplicate_value(self):
        first_form = ScopeForm({'value': self.created_scope_value, 'description': {'ru': 'ru'}})
        self.assertTrue(first_form.is_valid())
        first_form.save()
        self.assertTrue(Scope.objects.filter(value=self.created_scope_value).exists())

        second_form = ScopeForm({'value': self.updated_scope_value, 'description': {'ru': 'ru'}})
        self.assertTrue(second_form.is_valid())
        second_scope = second_form.save()
        self.assertTrue(Scope.objects.filter(value=self.updated_scope_value).exists())

        client = Client()
        client.force_login(self.user)
        url = reverse('scope-detail', kwargs={'pk': second_scope.id})
        response = client.put(url, json.dumps(first_form.cleaned_data), "application/json")
        self.assertEqual(response.status_code, 400)
        self.assertTrue(Scope.objects.filter(value=self.created_scope_value).exists())
        self.assertTrue(Scope.objects.filter(value=self.updated_scope_value).exists())


class DeleteScopeTest(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='delete_aac_scope'))
        self.created_scope_value = 'created_scope_test_value'

    def tearDown(self):
        Scope.objects.filter(value=self.created_scope_value).delete()
        self.user.delete()

    def test_delete(self):
        create_form = ScopeForm({'value': self.created_scope_value, 'description': {'ru': 'ru'}})
        self.assertTrue(create_form.is_valid())
        created_scope = create_form.save()
        self.assertTrue(Scope.objects.filter(value=self.created_scope_value).exists())
        client = Client()
        client.force_login(self.user)
        url = reverse('scope-detail', kwargs={'pk': created_scope.id})
        response = client.delete(url)
        self.assertEqual(response.status_code, 204)
        self.assertFalse(Scope.objects.filter(value=self.created_scope_value).exists())


class ScopesViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user_without_permissions = User.objects.create_user(username='bad_user', password='qwerty')
        self.user.user_permissions.add(Permission.objects.get(codename='view_aac_scope'))

    def tearDown(self):
        self.user.delete()
        self.factory = None

    def test_scopes_view_get_queryset(self):
        scopes_queryset = list(ScopesView().get_queryset())
        scopes_test_queryset = list(Scope.objects.all())
        for scope in scopes_test_queryset:
            self.assertIn(scope, scopes_queryset)

    def test_scopes_view_context_data(self):
        request = self.factory.get(reverse('scopes'))
        view = ScopesView()
        view.request = request
        view.object_list = view.get_queryset()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), 'Скоупы')

    def test_scopes_view_get(self):
        request = self.factory.get(reverse('scopes'))
        request.user = self.user_without_permissions
        response = ScopesView.as_view()(request)
        self.assertEqual(response.status_code, 302)
        request = self.factory.get(reverse('scopes'))
        request.user = self.user
        response = ScopesView.as_view()(request)
        self.assertEqual(response.status_code, 200)
