import os
from shutil import rmtree
from unittest.mock import patch, MagicMock

import requests
from django.conf import settings
from django.core.files import File
from django.test import TestCase

from aac_admin.api.v1.client_logo_saver import ClientLogoSaver, WebDavStorage, FileStorage

test_client_id = '123'


class NewLogoImageTest(TestCase):
    def setUp(self):
        self.test_client_id = test_client_id

    def test_webdav_new_url(self):
        urls = WebDavStorage._object_urls(self.test_client_id)
        self.assertEqual(len(urls), 2)
        self.assertTrue(urls[0].startswith(settings.WEB_DAV_STORAGE_URL))
        self.assertTrue(urls[1].startswith(settings.UPLOADED_DATA_BASE_URL))
        [self.assertTrue(url.endswith('.png')) for url in urls]

    @patch('django.conf.settings.WEB_DAV_STORAGE_URL', 'file:///tmp')
    def test_file_new_url(self):
        urls = FileStorage._object_urls(self.test_client_id)
        self.assertEqual(len(urls), 2)
        self.assertTrue(urls[0].startswith('/tmp'))
        self.assertTrue(urls[1].startswith(settings.UPLOADED_DATA_BASE_URL))
        [self.assertTrue(url.endswith('.png')) for url in urls]


@patch('aac_admin.api.v1.client_logo_saver.ClientLogoSaver.storage_driver', FileStorage)
class SaveLogoFileTest(TestCase):
    def setUp(self):
        self.test_client_id = test_client_id
        os.makedirs('/tmp/client_logo', exist_ok=True)

    def tearDown(self):
        rmtree('/tmp/client_logo')
        super().tearDown()

    @patch('django.conf.settings.WEB_DAV_STORAGE_URL', 'file:///tmp/client_logo')
    def test_save_logo_image_success(self):
        status, string_result = ClientLogoSaver.save_logo_image(MagicMock(spec=File, name='FileMock'),
                                                                self.test_client_id)
        self.assertTrue(status)
        filename = string_result.split('/')[-1]
        self.assertTrue(os.path.exists('/tmp/client_logo/' + filename))

    @patch('django.conf.settings.WEB_DAV_STORAGE_URL', 'file:///tmp/non-existing')
    def test_save_logo_image_failure(self):
        status, string_result = ClientLogoSaver.save_logo_image(MagicMock(spec=File, name='FileMock'),
                                                                self.test_client_id)
        self.assertFalse(status)


@patch('aac_admin.api.v1.client_logo_saver.ClientLogoSaver.storage_driver', FileStorage)
@patch('django.conf.settings.WEB_DAV_STORAGE_URL', 'file:///tmp/client_logo')
class DeleteLogoFileTest(TestCase):
    def setUp(self):
        os.makedirs('/tmp/client_logo', exist_ok=True)
        open('/tmp/client_logo/logo.png', 'w').write('data')

    def tearDown(self):
        rmtree('/tmp/client_logo')
        super().tearDown()

    def test_delete_logo_image_success(self):
        status, string_result = ClientLogoSaver.delete_logo_image('http://example.com/static/client_logo/logo.png')
        self.assertTrue(status)

    def test_delete_logo_image_failure(self):
        status, string_result = \
            ClientLogoSaver.delete_logo_image('http://example.com/static/client_logo/non-existing.png')
        self.assertFalse(status)


class SaveLogoTest(TestCase):
    def setUp(self):
        self.test_client_id = test_client_id

    @patch.object(requests, 'put')
    def test_save_logo_image_success(self, requests_mock):
        response = requests_mock.return_value
        response.status_code = 201
        self.assertTrue(requests.put is requests_mock)
        image_file_mock = MagicMock(spec=File, name='FileMock')
        result_tuple = ClientLogoSaver.save_logo_image(image_file_mock, self.test_client_id)
        requests_mock.assert_called()
        self.assertTrue(isinstance(result_tuple, tuple))
        status, string_result = result_tuple
        self.assertTrue(status)

    @patch.object(requests, 'put')
    def test_save_logo_image_failure(self, requests_mock):
        response = requests_mock.return_value
        response.status_code = 500
        self.assertTrue(requests.put is requests_mock)
        image_file_mock = MagicMock(spec=File, name='FileMock')
        result_tuple = ClientLogoSaver.save_logo_image(image_file_mock, self.test_client_id)
        requests_mock.assert_called()
        self.assertTrue(isinstance(result_tuple, tuple))
        status, string_result = result_tuple
        self.assertFalse(status)

    @patch.object(requests, 'put')
    def test_save_logo_image_exception(self, requests_mock):
        requests_mock.side_effect = requests.exceptions.RequestException()
        self.assertTrue(requests.put is requests_mock)
        image_file_mock = MagicMock(spec=File, name='FileMock')
        result_tuple = ClientLogoSaver.save_logo_image(image_file_mock, self.test_client_id)
        requests_mock.assert_called()
        self.assertTrue(isinstance(result_tuple, tuple))
        status, string_result = result_tuple
        self.assertFalse(status)


class DeleteLogoTest(TestCase):
    def setUp(self):
        self.logo_uri = 'http://example.com/test'

    @patch.object(requests, 'delete')
    def test_delete_logo_image_success(self, requests_mock):
        response = requests_mock.return_value
        response.status_code = 204
        self.assertTrue(requests.delete is requests_mock)
        result_tuple = ClientLogoSaver.delete_logo_image(self.logo_uri)
        requests_mock.assert_called()
        self.assertTrue(isinstance(result_tuple, tuple))
        status, string_result = result_tuple
        self.assertTrue(status)

    @patch.object(requests, 'delete')
    def test_delete_logo_image_failure(self, requests_mock):
        response = requests_mock.return_value
        response.status_code = 500
        self.assertTrue(requests.delete is requests_mock)
        result_tuple = ClientLogoSaver.delete_logo_image(self.logo_uri)
        requests_mock.assert_called()
        self.assertTrue(isinstance(result_tuple, tuple))
        status, string_result = result_tuple
        self.assertFalse(status)

    @patch.object(requests, 'delete')
    def test_delete_logo_image_exception(self, requests_mock):
        requests_mock.side_effect = requests.exceptions.RequestException()
        self.assertTrue(requests.delete is requests_mock)
        result_tuple = ClientLogoSaver.delete_logo_image(self.logo_uri)
        requests_mock.assert_called()
        self.assertTrue(isinstance(result_tuple, tuple))
        status, string_result = result_tuple
        self.assertFalse(status)
