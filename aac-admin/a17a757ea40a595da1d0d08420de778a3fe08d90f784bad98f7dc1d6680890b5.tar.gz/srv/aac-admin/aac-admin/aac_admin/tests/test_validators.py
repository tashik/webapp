import json
import random
import string

from PIL import Image
from django.core.exceptions import ValidationError
from django.test import TestCase
from io import BytesIO

from aac_admin.api.v1.custom_validators import JsonValueLengthValidator, ImageValidator
from aac_admin.utils import ValidationMixin


class TestImageValidator(TestCase):
    @staticmethod
    def create_test_image(image_type: str, width: int, height: int):
        file = BytesIO()
        image = Image.new('RGBA', size=(width, height), color=(0, 0, 0))
        image.save(file, image_type)
        file.seek(0)
        return file

    def test_valid(self):
        validator = ImageValidator(['png'], 50, 50)
        image_mock = self.create_test_image('png', 50, 50)
        try:
            validator.__call__(image_mock)
        except ValidationError:
            self.fail()

    def test_wrong_type(self):
        validator = ImageValidator(['jpg'], 50, 50)
        image_mock = self.create_test_image('png', 50, 50)
        self.assertRaises(ValidationError, validator.__call__, image_mock)

    def test_wrong_sizes(self):
        validator = ImageValidator(['png'], 50, 50)
        self.assertRaises(ValidationError, validator.__call__, self.create_test_image('png', 30, 50))
        self.assertRaises(ValidationError, validator.__call__, self.create_test_image('png', 50, 30))
        self.assertRaises(ValidationError, validator.__call__, self.create_test_image('png', 20, 20))

    def test_equals(self):
        self.assertTrue(ImageValidator().__eq__(ImageValidator()))
        self.assertTrue(ImageValidator(['png', 'jpg']).__eq__(ImageValidator(['png', 'jpg'])))
        self.assertTrue(ImageValidator(width=50).__eq__(ImageValidator(width=50)))
        self.assertTrue(ImageValidator(height=30).__eq__(ImageValidator(height=30)))
        self.assertTrue(ImageValidator(width=25, height=25).__eq__(ImageValidator(width=25, height=25)))

        self.assertFalse(ImageValidator(['png']).__eq__(ImageValidator()))
        self.assertFalse(ImageValidator(['png']).__eq__(ImageValidator(['jpg'])))
        self.assertFalse(ImageValidator(width=30, height=30).__eq__(ImageValidator()))
        self.assertFalse(ImageValidator(width=30, height=30).__eq__(ImageValidator(width=40, height=40)))


class TestJsonValueLengthValidator(TestCase):
    def test_valid(self):
        validator = JsonValueLengthValidator(10)
        json_ = {'1': '', '2': ''.join(random.choices(string.ascii_uppercase + string.digits, k=9))}
        try:
            validator.__call__(json_)
        except ValidationError:
            self.fail()

    def test_exceed_max_length(self):
        validator = JsonValueLengthValidator(10)
        json_ = {'test': ''.join(random.choices(string.ascii_uppercase + string.digits, k=13))}
        self.assertRaises(ValidationError, validator.__call__, json_)

    def test_equals(self):
        self.assertTrue(JsonValueLengthValidator(10).__eq__(JsonValueLengthValidator(10)))
        self.assertTrue(JsonValueLengthValidator(15).__eq__(JsonValueLengthValidator(15)))
        self.assertTrue(JsonValueLengthValidator(15, 'msg').__eq__(JsonValueLengthValidator(15, 'msg')))

        self.assertFalse(JsonValueLengthValidator(10).__eq__(JsonValueLengthValidator(15)))
        self.assertFalse(JsonValueLengthValidator(10).__eq__(JsonValueLengthValidator(10, 'msg')))
        self.assertFalse(JsonValueLengthValidator(10, 'str').__eq__(JsonValueLengthValidator(10, 'msg')))


class TestValidationMixin(TestCase):
    def setUp(self):
        self.validator = ValidationMixin()

    def test_is_int(self):
        for _ in range(5):
            self.assertTrue(self.validator._is_int(str(random.randint(-1000, 1000))))
        for _ in range(5):
            self.assertFalse(self.validator._is_int(''.join(random.choices(string.ascii_letters, k=10))))

    def test_is_float(self):
        for _ in range(5):
            self.assertTrue(self.validator._is_float(str(random.uniform(-1000, 1000))))
        for _ in range(5):
            self.assertFalse(self.validator._is_float(str(random.randint(-1000, 1000))))
        for _ in range(5):
            self.assertFalse(self.validator._is_float(''.join(random.choices(string.ascii_letters, k=10))))

    def test_is_string(self):
        self.assertTrue(self.validator._is_string(''.join(random.choices(string.ascii_letters, k=10))))
        for val in (int, float, dict, tuple, set, frozenset, list):
            self.assertFalse(self.validator._is_string(val()))

    def test_is_boolean(self):
        for val in (True, False):
            self.assertTrue(self.validator._is_boolean(str(val)))
            self.assertFalse(self.validator._is_boolean(val))

    def test_is_json(self):
        self.assertTrue(self.validator._is_json('{}'))
        test_dict = {
            '1': 1, 'empty_list': [], 'list': [1, 3, 'qwe', {'': ''}],
            'empty_dict': {}, 'dict': {'1': {'2': '3'}}
        }
        self.assertTrue(self.validator._is_json(json.dumps(test_dict)))
        self.assertFalse(self.validator._is_json([1, 2, 3, {'4': 5, '6': 7}]))

    def test_is_date(self):
        [self.assertTrue(self.validator._is_date(self.generate_random_date())) for _ in range(5)]
        [self.assertFalse(self.validator._is_date(self.generate_random_datetime())) for _ in range(5)]
        [self.assertFalse(self.validator._is_date(self.generate_random_time())) for _ in range(5)]

    def test_is_datetime(self):
        [self.assertTrue(self.validator._is_datetime(self.generate_random_datetime())) for _ in range(5)]
        [self.assertFalse(self.validator._is_datetime(self.generate_random_date())) for _ in range(5)]
        [self.assertFalse(self.validator._is_datetime(self.generate_random_time())) for _ in range(5)]

    def test_is_time(self):
        [self.assertTrue(self.validator._is_time(self.generate_random_time())) for _ in range(5)]
        [self.assertFalse(self.validator._is_time(self.generate_random_datetime())) for _ in range(5)]
        [self.assertFalse(self.validator._is_time(self.generate_random_date())) for _ in range(5)]

    @staticmethod
    def generate_random_date():
        day = random.randint(1, 28)
        month = random.randint(1, 12)
        year = random.randint(1950, 2000)
        return f'{day}.{month}.{year}'

    @staticmethod
    def generate_random_time():
        hour = random.randint(0, 23)
        minutes = random.randint(0, 59)
        return f'{hour}:{minutes}'

    def generate_random_datetime(self):
        return f'{self.generate_random_date()} {self.generate_random_time()}'
