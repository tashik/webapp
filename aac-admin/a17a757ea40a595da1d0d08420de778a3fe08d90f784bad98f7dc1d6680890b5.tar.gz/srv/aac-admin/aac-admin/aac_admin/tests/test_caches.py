from unittest import mock

from django.test import TestCase, override_settings
from django.contrib.messages.storage.fallback import FallbackStorage
from django.contrib.auth.models import AnonymousUser, Permission, User
from django.http import QueryDict
from django.test.client import RequestFactory
from django.urls import reverse
from requests.exceptions import RequestException

from aac_admin.views import caches


@override_settings(AAC_CACHE_PURGE={'some_cache':
    {
        'headers': {'Host': 'some_host'},
        'urls': ['http://1.1.1.1/some_resource'],
    },
})
class CachesViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.view = caches.CachesView.as_view()

    def tearDown(self):
        super().tearDown()
        self.user.delete()

    def test_get_view_anonymous(self):
        request = self.factory.get(reverse('caches'))
        request.user = AnonymousUser()
        response = self.view(request)
        self.assertEqual(response.status_code, 302)

    def test_get_view_with_view_permission(self):
        self.user.user_permissions.add(Permission.objects.get(codename='view_aac_cache'))
        request = self.factory.get(reverse('caches'))
        request.user = self.user
        response = self.view(request)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'http://1.1.1.1/some_resource', response.content)
        self.assertNotIn(b'clear_cache', response.content)

    def test_get_view_with_change_permission(self):
        self.user.user_permissions.add(Permission.objects.get(codename='view_aac_cache'))
        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_cache'))
        request = self.factory.get(reverse('caches'))
        request.user = self.user
        response = self.view(request)
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'clear_cache', response.content)

    @mock.patch('requests.request')
    def test_post_view(self, request_stub):
        request = self.factory.post(reverse('caches'))
        request.user = AnonymousUser()
        self.view(request)
        self.assertEqual(request_stub.called, False)

        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_cache'))
        request.user = self.user
        self.view(request)
        self.assertEqual(request_stub.called, False)

        request.POST = QueryDict('clear_cache=some_cache')
        setattr(request, 'session', 'session')
        _messages = FallbackStorage(request)
        setattr(request, '_messages', _messages)
        self.assertEqual(len(_messages._queued_messages), 0)

        request_stub.return_value = mock.MagicMock(status_code=200)
        self.view(request)
        self.assertEqual(request_stub.called, True)
        self.assertEqual(len(_messages._queued_messages), 1)
        self.assertEqual(_messages._queued_messages[0].message, 'Успешная очистка для cache: some_cache')

        request_stub.return_value = mock.MagicMock(status_code=404)
        self.view(request)
        self.assertEqual(request_stub.called, True)
        self.assertEqual(len(_messages._queued_messages), 2)
        self.assertEqual(_messages._queued_messages[1].message,
                         'Произошла ошибка при очистке cache: some_cache, url: http://1.1.1.1/some_resource')

        request_stub.side_effect = RequestException('test')
        self.view(request)
        self.assertEqual(request_stub.called, True)
        self.assertEqual(len(_messages._queued_messages), 3)
        self.assertEqual(_messages._queued_messages[2].message,
                         'Произошла ошибка при очистке cache: some_cache, url: http://1.1.1.1/some_resource')
