import base64
import json
import random
from datetime import datetime
import string
from unittest.mock import patch
import re
import itertools

from django.test import TestCase

from aac_admin.tests import RedisMockTest
from aac_admin.utils.redis import TokenList, delete_sessions_by_aeroflot_id, delete_client_sessions_for_users, \
    delete_user_tokens_by_client_ids, delete_all_client_sessions_for_users


class TokenListTest(TestCase):
    @patch('builtins.all')
    @patch('builtins.zip')
    @patch('aac_admin.utils.redis.REDIS_CLIENT.transaction')
    def test(self, retrieve_data_mock, zip_mock, all_mock):
        tokens = {
            b'T-t1': {'sid': b'sid1', 'sid_info': json.dumps({'access_token': ''})},
            b'T-t2': {'sid': b'sid2', 'sid_info': json.dumps({'access_token': ''})},
            b'T-t3': {'sid': b'sid3', 'sid_info': json.dumps({'access_token': ''})},
        }

        def zip_side_effect(*args):
            if len(args) == 3:
                for jti in tokens:
                    yield jti, tokens[jti]['sid'], tokens[jti]['sid_info']
                yield 'T-t', 'sid', None
            else:
                return True
        all_mock.return_value = True
        zip_mock.side_effect = zip_side_effect
        retrieve_data_mock.return_value = (tokens[key]['sid_info'] for key in tokens)
        result = TokenList.new_token_list(0, 20, {})
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0], 0)
        self.assertEqual(len(result[1]), len(tokens))
        result_tokens = result[1]
        self.assertEqual([token['jti'] for token in result_tokens], [key.decode('ascii') for key in tokens])
        self.assertEqual([token['session_id'] for token in result_tokens],
                         list(d['sid'].decode('ascii') for d in tokens.values()))
        zip_mock.assert_called()


def create_test_token(header: dict, payload: dict) -> str:
    header_bytes = bytes(json.dumps(header), 'ascii')
    payload_bytes = bytes(json.dumps(payload), 'ascii')
    token = b''.join((base64.urlsafe_b64encode(header_bytes), b'.', base64.urlsafe_b64encode(payload_bytes)))
    return token.decode('ascii')


class ParseTokenPayloadTest(TestCase):
    def test_empty(self):
        random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(1, 10)))
        [self.assertEqual(TokenList.parse_token_payload(value), {}) for value in (None, '', random_string)]

    def test_valid(self):
        header = {'alg': 'HS256', 'typ': 'JWT'}
        payload = {'sub': '1234567890', 'name': 'John Doe', 'admin': True}
        token = create_test_token(header, payload)
        self.assertEqual(TokenList.parse_token_payload(token), payload)


def date_str_to_timestamp(s: str, date_format: str = None) -> int:
    date_format = date_format if date_format else '%Y-%m-%dT%H:%M'
    return int(datetime.strptime(s, date_format).timestamp())


class TokenFiltersTest(TestCase):
    def test_create_filters_empty(self):
        filters = TokenList._create_filters({})
        self.assertEqual(len(filters), 4)

    def test_create_filters_with_values(self):
        params = {
            'client_id': '?123*\?123\*',
            'aeroflot_id': '1??77',
            'iat_range': 'before', 'iat1': '2016-01-01T00:00', 'iat2': '',
            'exp_range': 'between', 'exp1': '2017-03-01T05:00', 'exp2': '2017-03-01T07:00',
        }
        client_id, aeroflot_id, iat_range, exp_range = TokenList._create_filters(params)

        [self.assertIsNotNone(client_id(value)) for value in ('a123?123*', 'd123asd?123*', '.123.?123*')]
        [self.assertFalse(bool(client_id(value))) for value in ('', '123?123*', 'a123?123', '.123.?123')]

        [self.assertIsNotNone(aeroflot_id(value)) for value in ('1zx77', '1..77', '13377')]
        [self.assertFalse(bool(client_id(value))) for value in ('', '1', '7', '77', '17', '177', '1077', '1asd77')]

        [self.assertTrue(iat_range(date_str_to_timestamp(value)))
            for value in ('1999-01-01T00:00', '2015-01-01T00:00', '2015-12-31T11:59')]
        [self.assertFalse(iat_range(date_str_to_timestamp(value)))
            for value in ('2016-01-01T00:00', '2016-01-01T00:01', '2017-12-31T11:59')]

        [self.assertTrue(exp_range(date_str_to_timestamp(value)))
            for value in ('2017-03-01T05:00', '2017-03-01T05:01', '2017-03-01T06:59', '2017-03-01T07:00')]
        [self.assertFalse(exp_range(date_str_to_timestamp(value)))
            for value in ('2017-03-01T04:00', '2017-03-01T04:59', '2017-03-01T07:01', '2017-03-01T08:00')]

        params = {
            'client_id': '',
            'aeroflot_id': '',
            'iat_range': 'after', 'iat1': '2016-01-01T00:00', 'iat2': '',
            'exp_range': '', 'exp1': '', 'exp2': '',
        }
        client_id, aeroflot_id, iat_range, exp_range = TokenList._create_filters(params)
        [self.assertTrue(bool(client_id(value)))
            for value in ('', ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(1, 10))))]

        [self.assertTrue(bool(aeroflot_id(value)))
            for value in ('', ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(1, 10))))]

        [self.assertTrue(iat_range(date_str_to_timestamp(value)))
            for value in ('2016-01-01T00:01', '2016-01-01T01:00', '2017-02-01T00:00')]
        [self.assertFalse(iat_range(date_str_to_timestamp(value)))
            for value in ('2016-01-01T00:00', '2015-12-31T12:59', '2000-01-01T00:00')]

        [self.assertTrue(exp_range(value))
            for value in ('', ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(1, 10))))]

        params = {
            'iat_range': 'after', 'iat1': 'invalid_value', 'iat2': '',
            # first date after second
            'exp_range': 'between', 'exp1': '2017-01-01T00:00', 'exp2': '2000-01-01T00:00',
        }
        client_id, aeroflot_id, iat_range, exp_range = TokenList._create_filters(params)
        [self.assertTrue(iat_range(value))
            for value in ('', ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(1, 10))))]
        [self.assertTrue(exp_range(value))
            for value in ('', ''.join(random.choices(string.ascii_uppercase + string.digits, k=random.randint(1, 10))))]


class DeleteSessionsByAeroflotIdTest(TestCase):
    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test(self, redis_mock):
        sessions_ids = ['sid1', 'sid2', 'sid3']
        redis_mock.zrange.return_value = sessions_ids
        redis_mock.scan.return_value = (0, ['jti1', 'jti2', 'jti3'])
        redis_mock.pipeline().execute.return_value = sessions_ids
        from aac_admin.utils.redis import REDIS_CLIENT
        self.assertTrue(redis_mock is REDIS_CLIENT)
        delete_sessions_by_aeroflot_id('123')
        redis_mock.zrange.assert_called()
        redis_mock.delete.assert_called()
        redis_mock.scan.assert_called()
        redis_mock.pipeline.assert_called()
        redis_mock.pipeline().execute.assert_called()
        redis_mock.pipeline().delete.assert_called()


class TokenListEscapeCharsTest(TestCase):
    def test_escape(self):
        self.assertEqual(TokenList._escape_chars(''), '')
        self.assertEqual(TokenList._escape_chars('\\'), '\\\\')
        self.assertEqual(TokenList._escape_chars(r'\*'), r'\*')
        self.assertEqual(TokenList._escape_chars(r'\?'), r'\?')
        self.assertEqual(TokenList._escape_chars('*'), '.*')
        self.assertEqual(TokenList._escape_chars('?'), '.')
        self.assertEqual(TokenList._escape_chars('\**'), '\*.*')
        self.assertEqual(TokenList._escape_chars('\??'), '\?.')
        self.assertEqual(TokenList._escape_chars('[]{}|`~:;<=>!@#$%^&'), '\[\]\{\}\|\`\~\:\;\<\=\>\!\@\#\$\%\^\&')
        self.assertEqual(TokenList._escape_chars("\"()'_+.,/-"), "\\\"\(\)\\'_\+\.\,\/\-")
        self.assertEqual(TokenList._escape_chars(string.ascii_letters), string.ascii_letters)
        self.assertEqual(TokenList._escape_chars(string.digits), string.digits)


class DeleteClientSessionsForUsersTest(TestCase):
    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test_empty(self, redis_mock):
        delete_client_sessions_for_users('client_id', [])
        redis_mock.pipeline.assert_called()
        redis_mock.pipeline().execute.assert_not_called()

    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test(self, redis_mock):
        client_id = 'client_id'
        aeroflot_ids = ['1000', '1001', '1002']
        sessions = ['sid1', 'sid2', 'sid3']
        test_token_header = {'alg': 'HS256', 'typ': 'JWT'}
        sessions_info = [json.dumps({'client_id': client_id, 'access_token':
                                    create_test_token(test_token_header, {'jti': 'T-123'})}) for _ in sessions]
        redis_mock.zrange.return_value = sessions
        redis_mock.pipeline().execute.return_value = sessions_info
        delete_client_sessions_for_users(client_id, aeroflot_ids)
        redis_mock.pipeline.assert_called()
        redis_mock.pipeline().execute.assert_called()
        redis_mock.pipeline().delete.assert_called()


class DeleteUserTokensTest(TestCase):
    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test_empty(self, redis_mock):
        delete_user_tokens_by_client_ids('1000', [])
        redis_mock.pipeline.assert_not_called()

    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test(self, redis_mock):
        sessions = ['sid1', 'sid2', 'sid3']
        client_ids = [f'client_id_{i}' for i in range(len(sessions))]
        test_token_header = {'alg': 'HS256', 'typ': 'JWT'}
        redis_mock.zrange.return_value = sessions
        sessions_info = [json.dumps({'client_id': client_id, 'access_token': create_test_token(test_token_header,
                                    {'jti': 'T-123'})}) for client_id in client_ids]
        sessions_ttl = [3600 for _ in range(len(sessions))]
        redis_mock.pipeline().execute.side_effect = [sessions_info, sessions_ttl, None]
        delete_user_tokens_by_client_ids('1000', client_ids)
        redis_mock.pipeline.assert_called()
        redis_mock.pipeline().execute.assert_called()
        redis_mock.pipeline().delete.assert_called()


class TokensByAeroflotIdTest(TestCase):
    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test(self, redis_mock):
        aeroflot_id = '1000'
        client_id = 'client_id'
        sessions = [sid.encode('ascii') for sid in ['sid1', 'sid2', 'sid3']]
        test_token_header = {'alg': 'HS256', 'typ': 'JWT'}
        tokens = [{
            'jti': f'T-jti',
            'session_id': sid.decode('ascii'),
            'azp': client_id,
            'sub': aeroflot_id,
            'iat': 1_000_000,
            'exp': 1_000_001,
            'iat_int': 1_000_000
        } for sid in sessions]
        sessions_info = [json.dumps({'access_token': create_test_token(test_token_header, token)}) for token in tokens]
        redis_mock.zrange.return_value = sessions
        redis_mock.pipeline().execute.return_value = sessions_info
        result = TokenList.get_tokens_by_aeroflot_id(aeroflot_id)
        self.assertSequenceEqual([token['session_id'] for token in tokens], [token['session_id'] for token in result])
        self.assertSequenceEqual([token['azp'] for token in tokens], [token['client_id'] for token in result])
        self.assertSequenceEqual([token['sub'] for token in tokens], [token['aeroflot_id'] for token in result])


class DeleteAllClientSessionsForUsersTest(TestCase):
    @patch('aac_admin.utils.redis.REDIS_CLIENT')
    def test(self, redis_mock):
        client_id = 'test_client_id'
        tokens = {
            b'T-t1': {
                'sid': b'sid1',
                'sid_info': {'access_token': create_test_token({'alg': 'HS256'}, {'aud': [client_id], 'sub': '1'})}
            },
            b'T-t2': {
                'sid': b'sid2',
                'sid_info': {'access_token': create_test_token({'alg': 'HS256'}, {'aud': [client_id], 'sub': '2'})}
            },
            b'T-t3': {
                'sid': b'sid3',
                'sid_info': {'access_token': create_test_token({'alg': 'HS256'}, {'aud': [client_id], 'sub': '3'})}
            },
        }
        redis_mock.scan.return_value = 0, [jti for jti in tokens]
        redis_mock.pipeline().execute.side_effect = [
            [tokens[jti]['sid'] for jti in tokens],
            [json.dumps(tokens[jti]['sid_info']) for jti in tokens],
            None
        ]
        pipe = redis_mock.pipeline()
        pipe.delete.return_value = pipe
        pipe.zrem.return_value = pipe
        delete_all_client_sessions_for_users(client_id)
        redis_mock.pipeline.assert_called()
        redis_mock.scan.assert_called()
        for jti in tokens:
            pipe.delete.assert_any_call(jti)
            pipe.delete.assert_any_call(tokens[jti]['sid'])


class TokenListTestRedisMock(RedisMockTest, TestCase):
    def test_empty(self):
        self.flush_db()
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertEqual(cursor, 0)
        self.assertEqual(tokens, [])

    def test_with_default_data(self):
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertTrue(isinstance(cursor, int))
        for token in tokens:
            self.assertTrue(token['jti'] in self.data)
            test_data = self.data[token['jti']]
            self.assertEqual(token['session_id'], test_data['sid'])
            self.assertEqual(token['client_id'], test_data['client_id'])
            self.assertEqual(token['aeroflot_id'], test_data['aeroflot_id'])
            self.assertEqual(date_str_to_timestamp(token['exp'], '%d-%m-%Y %H:%M:%S'), test_data['access_token']['exp'])
            self.assertEqual(date_str_to_timestamp(token['iat'], '%d-%m-%Y %H:%M:%S'), test_data['access_token']['iat'])
            self.assertEqual(token['jti'], test_data['access_token']['jti'])
            self.assertEqual(token['client_id'], test_data['access_token']['azp'])
            self.assertEqual(token['aeroflot_id'], test_data['access_token']['sub'])

    def test_filter_client_id(self):
        self.flush_db()

        aeroflot_id = '12377'
        client_id = 'a123_123?*'
        self.add_session_to_user(aeroflot_id, client_id)

        test_data = (
            {'params': {}, 'expected': 1},
            {'params': {'client_id': ''}, 'expected': 1},
            {'params': {'client_id': 'a123_123\?\*'}, 'expected': 1},
            {'params': {'client_id': 'a123_12\?'}, 'expected': 0},
            {'params': {'client_id': 'a123_12\*'}, 'expected': 0},
            {'params': {'client_id': '123_123\?\*'}, 'expected': 0},
            {'params': {'client_id': '123_123'}, 'expected': 0},
            {'params': {'client_id': 'a123123'}, 'expected': 0},
            {'params': {'client_id': '123'}, 'expected': 0},

            {'params': {'client_id': '*'}, 'expected': 1},
            {'params': {'client_id': 'a*'}, 'expected': 1},
            {'params': {'client_id': 'a123*'}, 'expected': 1},
            {'params': {'client_id': '*\?\*'}, 'expected': 1},
            {'params': {'client_id': '*123\?\*'}, 'expected': 1},
            {'params': {'client_id': '*12'}, 'expected': 0},
            {'params': {'client_id': '*123*'}, 'expected': 1},
            {'params': {'client_id': '*_*'}, 'expected': 1},
            {'params': {'client_id': '*a*'}, 'expected': 1},
            {'params': {'client_id': '*\?*'}, 'expected': 1},
            {'params': {'client_id': '*\**'}, 'expected': 1},

            {'params': {'client_id': 'a123?123\?\*'}, 'expected': 1},
            {'params': {'client_id': '?123_123??'}, 'expected': 1},
            {'params': {'client_id': '?1?3_12?\??'}, 'expected': 1},
            {'params': {'client_id': '?1?3_12??\*'}, 'expected': 1},
            {'params': {'client_id': '?' * len(client_id)}, 'expected': 1},
            {'params': {'client_id': '?' * (len(client_id) - 1)}, 'expected': 0},
            {'params': {'client_id': '?' * (len(client_id) + 1)}, 'expected': 0},
            {'params': {'client_id': '?' * (len(client_id) - 3)}, 'expected': 0},

            {'params': {'client_id': '?123*'}, 'expected': 1},
            {'params': {'client_id': '?123_*'}, 'expected': 1},
            {'params': {'client_id': '?123?'}, 'expected': 0},
            {'params': {'client_id': '?123?*'}, 'expected': 1},
            {'params': {'client_id': '?*?'}, 'expected': 1},
            {'params': {'client_id': '?1*2?*'}, 'expected': 1},
            {'params': {'client_id': '*?*'}, 'expected': 1},
            {'params': {'client_id': '*a?*3\?\*'}, 'expected': 1},

            {'params': {'client_id': '\*'}, 'expected': 0},
            {'params': {'client_id': '?123\?*'}, 'expected': 0},
            {'params': {'client_id': '?123\**'}, 'expected': 0},
            {'params': {'client_id': '\?123*'}, 'expected': 0},
        )

        for test in test_data:
            cursor, tokens = TokenList.new_token_list(0, 20, test['params'])
            self.assertIsInstance(cursor, int)
            self.assertEqual(cursor, 0)
            self.assertEqual(len(tokens), test['expected'],
                             f'client_id {client_id} does not match regex {test["params"]}')

    def test_filter_aeroflot_id(self):
        self.flush_db()

        aeroflot_id = '12377'
        client_id = 'a123_123?*'
        self.add_session_to_user(aeroflot_id, client_id)

        test_data = (
            {'params': {}, 'expected': 1},
            {'params': {'aeroflot_id': ''}, 'expected': 1},
            {'params': {'aeroflot_id': '12377'}, 'expected': 1},
            {'params': {'aeroflot_id': '1237'}, 'expected': 0},
            {'params': {'aeroflot_id': '2377'}, 'expected': 0},

            {'params': {'aeroflot_id': '*'}, 'expected': 1},
            {'params': {'aeroflot_id': '1*'}, 'expected': 1},
            {'params': {'aeroflot_id': '*1*'}, 'expected': 1},
            {'params': {'aeroflot_id': '*1*'}, 'expected': 1},

            {'params': {'aeroflot_id': '?2377'}, 'expected': 1},
            {'params': {'aeroflot_id': '12?77'}, 'expected': 1},
            {'params': {'aeroflot_id': '1237?'}, 'expected': 1},
            {'params': {'aeroflot_id': '1?37?'}, 'expected': 1},
            {'params': {'aeroflot_id': '?12377'}, 'expected': 0},
            {'params': {'aeroflot_id': '12377?'}, 'expected': 0},
            {'params': {'aeroflot_id': '?12377?'}, 'expected': 0},
            {'params': {'aeroflot_id': '12??77'}, 'expected': 0},
            {'params': {'aeroflot_id': '?' * len(aeroflot_id)}, 'expected': 1},
            {'params': {'aeroflot_id': '?' * (len(aeroflot_id) + 1)}, 'expected': 0},
            {'params': {'aeroflot_id': '?' * (len(aeroflot_id) - 1)}, 'expected': 0},

            {'params': {'aeroflot_id': '1?*?'}, 'expected': 1},
            {'params': {'aeroflot_id': '?1*'}, 'expected': 0},
            {'params': {'aeroflot_id': '1*7?'}, 'expected': 1},
            {'params': {'aeroflot_id': '1*77?'}, 'expected': 0},
            {'params': {'aeroflot_id': '?*?'}, 'expected': 1},
            {'params': {'aeroflot_id': '*?*'}, 'expected': 1},
        )

        for test in test_data:
            cursor, tokens = TokenList.new_token_list(0, 20, test['params'])
            self.assertIsInstance(cursor, int)
            self.assertEqual(cursor, 0)
            self.assertEqual(len(tokens), test['expected'],
                             f'aeroflot_id {aeroflot_id} does not match regex {test["params"]}')

    def test_filter_iat_exp(self):
        self.flush_db()

        aeroflot_id = '123'
        client_id = 'test'
        iat = date_str_to_timestamp('2018-01-05T12:00:30', '%Y-%m-%dT%H:%M:%S')
        exp = iat
        self.add_session_to_user(aeroflot_id, client_id, iat, exp)

        _ = self.timestamp_to_date_str
        test_data = itertools.chain.from_iterable(
            [
                {'params': {}, 'expected': 1},
                {'params': {f'{t}_range': '', f'{t}1': '', f'{t}2': ''}, 'expected': 1},
                {'params': {f'{t}_range': 'test'}, 'expected': 1},
                {'params': {f'{t}_range': 'before'}, 'expected': 1},
                {'params': {f'{t}_range': 'after'}, 'expected': 1},
                {'params': {f'{t}_range': 'between'}, 'expected': 1},

                {'params': {f'{t}_range': 'before', f'{t}1': _(iat - 3600), f'{t}2': ''}, 'expected': 0},
                {'params': {f'{t}_range': 'before', f'{t}1': _(iat - 31), f'{t}2': ''}, 'expected': 0},
                {'params': {f'{t}_range': 'before', f'{t}1': _(iat), f'{t}2': ''}, 'expected': 0},
                {'params': {f'{t}_range': 'before', f'{t}1': _(iat + 30), f'{t}2': ''}, 'expected': 1},
                {'params': {f'{t}_range': 'before', f'{t}1': _(iat + 3600), f'{t}2': ''}, 'expected': 1},

                {'params': {f'{t}_range': 'after', f'{t}1': _(iat - 3600), f'{t}2': ''}, 'expected': 1},
                {'params': {f'{t}_range': 'after', f'{t}1': _(iat - 31), f'{t}2': ''}, 'expected': 1},
                {'params': {f'{t}_range': 'after', f'{t}1': _(iat), f'{t}2': ''}, 'expected': 1},
                {'params': {f'{t}_range': 'after', f'{t}1': _(iat + 30), f'{t}2': ''}, 'expected': 0},
                {'params': {f'{t}_range': 'after', f'{t}1': _(iat + 3600), f'{t}2': ''}, 'expected': 0},

                {'params': {f'{t}_range': 'between', f'{t}1': _(iat), f'{t}2': _(iat)}, 'expected': 0},
                {'params': {f'{t}_range': 'between', f'{t}1': _(iat), f'{t}2': _(iat + 30)}, 'expected': 1},
                {'params': {f'{t}_range': 'between', f'{t}1': _(iat + 30), f'{t}2': _(iat + 30)}, 'expected': 0},
                {'params': {f'{t}_range': 'between', f'{t}1': _(iat - 30), f'{t}2': _(iat - 30)}, 'expected': 0}
            ] for t in ('iat', 'exp')
        )

        for test in test_data:
            cursor, tokens = TokenList.new_token_list(0, 20, test['params'])
            self.assertIsInstance(cursor, int)
            self.assertEqual(cursor, 0)
            self.assertEqual(len(tokens), test['expected'],
                             f'time {_(iat, "%Y-%m-%dT%H:%M:%S")} does not match {test["params"]}')

    def test_parse_token_payload(self):
        payload = {'test': 'test'}
        token = self.generate_access_token_string(self.generate_default_access_token_header(), payload)
        self.assertTrue('=' in token)
        token = re.sub('=+', '', token)
        self.assertEqual(TokenList.parse_token_payload(token), payload)


class TokensByAeroflotId(RedisMockTest, TestCase):
    def test_not_existed(self):
        result = TokenList.get_tokens_by_aeroflot_id('some_aeroflot_id')
        self.assertEqual(len(result), 0)

    def test_get_tokens_by_aeroflot_id(self):
        self.flush_db()
        user_1, user_2 = 'user_1', 'user_2'
        client_id_1, client_id_2, client_id_3 = 'client_id_1', 'client_id_2', 'client_id_3'
        iterations = 3
        [self.add_session_to_user(user_1, client_id_1) for _ in range(iterations)]
        [self.add_session_to_user(user_1, client_id_2) for _ in range(iterations)]
        [self.add_session_to_user(user_2, client_id_3) for _ in range(iterations)]
        sid_without_sid_info = self.generate_session_id()
        self.add_session_to_uid2sid(user_1, 1, sid_without_sid_info)
        sid_without_access_token = self.generate_session_id()
        sid_info = {'client_id': client_id_1, 'sub': user_1}
        self.add_session_to_uid2sid(user_1, 1, sid_without_access_token)
        self.set_session_info(sid_without_access_token, json.dumps(sid_info))

        result = TokenList.get_tokens_by_aeroflot_id(user_1)
        self.assertEqual(len(result), iterations * 2)
        for token in result:
            self.assertIn(token['jti'], self.data)
            self.assertEqual(token['aeroflot_id'], user_1)
            self.assertIn(token['client_id'], [client_id_1, client_id_2])
            self.assertNotEqual(token['session_id'], sid_without_sid_info)
            self.assertNotEqual(token['session_id'], sid_without_access_token)


class DeleteSessionsByAeroflotIdRedisMock(RedisMockTest, TestCase):
    def test_not_existed(self):
        delete_sessions_by_aeroflot_id('some_aeroflot_id')
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertEqual(len(tokens), len(self.data))
        [self.assertIn(token['jti'], self.data) for token in tokens]

    def test(self):
        self.flush_db()
        user_1, user_2 = 'user_1', 'user_2'
        client_id_1, client_id_2, client_id_3 = 'client_id_1', 'client_id_2', 'client_id_3'
        pairs = [(user_1, client_id_1), (user_1, client_id_2), (user_1, client_id_3)]
        pairs += [(user_2, client_id_1), (user_2, client_id_2), (user_2, client_id_3)]
        [self.add_session_to_user(aeroflot_id, client_id) for aeroflot_id, client_id in pairs]
        delete_sessions_by_aeroflot_id(user_1)
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        [self.assertEqual(token['aeroflot_id'], user_2) for token in tokens]


class DeleteUserTokensByClientIdsTest(RedisMockTest, TestCase):
    def test_empty(self):
        pairs = self.default_aeroflot_id_client_id_tuples()
        user_id, client_id = pairs[0][0], pairs[0][1]
        delete_user_tokens_by_client_ids(user_id, [])
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertEqual(len(tokens), len(self.data))
        [self.assertIn(token['jti'], self.data) for token in tokens]

    def test_default_data(self):
        delete_user_tokens_by_client_ids('user_1', ['client_id_1'])
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        [self.assertEqual(token['aeroflot_id'], 'user_2') for token in tokens]
        delete_user_tokens_by_client_ids('user_2', ['client_id_2'])
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertEqual(len(tokens), 0)

    def test_custom_data(self):
        self.flush_db()
        user_1, user_2 = 'user_1', 'user_2'
        client_id_1, client_id_2, client_id_3 = 'client_id_1', 'client_id_2', 'client_id_3'
        iterations = 3
        [self.add_session_to_user(user_1, client_id_1) for _ in range(iterations)]
        [self.add_session_to_user(user_1, client_id_2) for _ in range(iterations)]
        [self.add_session_to_user(user_2, client_id_3) for _ in range(iterations)]

        delete_user_tokens_by_client_ids(user_1, [client_id_1])
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertEqual(len(tokens), iterations * 2)
        [self.assertNotEqual(token['client_id'], client_id_1) for token in tokens]
        self.assertEqual(self.db.zcard(user_1), iterations * 2)
        client_id_1_sids = [i['sid'] for i in self.data.values() if i['client_id'] == client_id_1]
        self.assertEqual(len(client_id_1_sids), iterations)
        [self.assertTrue(self.db.ttl(sid) > 0) for sid in client_id_1_sids]


class DeleteClientSessionsForUsers(RedisMockTest, TestCase):
    def test(self):
        self.flush_db()
        user_1, user_2 = 'user_1', 'user_2'
        client_id_1, client_id_2, client_id_3 = 'client_id_1', 'client_id_2', 'client_id_3'
        iterations = 3
        [self.add_session_to_user(user_1, client_id_1) for _ in range(iterations)]
        [self.add_session_to_user(user_1, client_id_2) for _ in range(iterations)]
        [self.add_session_to_user(user_2, client_id_1) for _ in range(iterations)]
        [self.add_session_to_user(user_2, client_id_3) for _ in range(iterations)]

        delete_all_client_sessions_for_users(client_id_1)
        cursor, tokens = TokenList.new_token_list(0, 20, {})
        self.assertEqual(len(tokens), iterations * 2)
        [self.assertNotEqual(token['client_id'], client_id_1) for token in tokens]
