from django.contrib.auth.models import User
from django.test import TestCase, RequestFactory

from aac_admin.admin import AdminLoginSite

import pytest
pytestmark = pytest.mark.django_db


class AdminLoginSiteTest(TestCase):
    """ Тест-кейс для Django-админки. """
    def setUp(self):
        self.user = User.objects.create_superuser(username='testing_user', password='top_secret', email='r@r.ru')
        self.site = AdminLoginSite()
        self.factory = RequestFactory()

    def tearDown(self):
        self.site = None
        self.user.delete()
        self.factory = None

    def test_each_context(self):
        request = self.factory.get('admin/admin/')
        request.user = self.user
        context = self.site.each_context(request)
        self.assertEqual(context.get('is_popup'), False)
