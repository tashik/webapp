from unittest.mock import patch, Mock

from django.contrib.auth.models import AnonymousUser, User, Permission
from django.test import TestCase, RequestFactory
from django.urls import reverse

from aac_admin.tests import ViewTest
from aac_admin.utils.redis import TokenList
from aac_admin.views.tokens import token_list_html, TokenDeleteView, tokens_view


class TestTokenListService(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user_with_rights = User.objects.create(username='testing_user_token_rights', password='top_secret')
        self.user_with_rights.user_permissions.add(Permission.objects.get(codename='view_aac_token'))

    def tearDown(self):
        self.factory = None
        self.user.delete()
        self.user_with_rights.delete()

    @patch.object(TokenList, 'new_token_list')
    def test_anonymous(self, token_list_mock):
        token_list_mock.return_value = (None, None)
        self.assertTrue(token_list_mock is TokenList.new_token_list)
        request = self.factory.get(reverse('token_list_html'))
        request.user = AnonymousUser()
        response = token_list_html(request)
        self.assertEqual(response.status_code, 401)
        token_list_mock.assert_not_called()

    @patch.object(TokenList, 'new_token_list')
    def test_without_rights(self, token_list_mock):
        token_list_mock.return_value = (None, None)
        self.assertTrue(token_list_mock is TokenList.new_token_list)
        request = self.factory.get(reverse('token_list_html'))
        request.user = self.user
        response = token_list_html(request)
        self.assertEqual(response.status_code, 403)
        token_list_mock.assert_not_called()

    @patch.object(TokenList, 'new_token_list')
    def test_with_rights(self, token_list_mock):
        token_list_mock.return_value = (None, None)
        self.assertTrue(token_list_mock is TokenList.new_token_list)
        request = self.factory.get(reverse('token_list_html'))
        request.user = self.user_with_rights
        response = token_list_html(request)
        self.assertEqual(response.status_code, 200)
        token_list_mock.assert_called()

    @patch.object(TokenList, 'new_token_list')
    def test_with_rights_and_bad_params(self, token_list_mock):
        token_list_mock.return_value = (None, None)
        self.assertTrue(token_list_mock is TokenList.new_token_list)
        request = self.factory.get(reverse('token_list_html'), {'cursor': 'bad', 'some': 'staff'})
        request.user = self.user_with_rights
        response = token_list_html(request)
        self.assertEqual(response.status_code, 200)
        token_list_mock.assert_called()


class TestTokenView(ViewTest, TestCase):
    def get_request(self):
        return self.factory.get(reverse('tokens'))

    def get_response(self, request):
        return tokens_view(request)

    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_token')


class TestTokenDeleteView(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        self.reverse_kwargs = {'session_id': 'sess', 'jti': 'T-jti', 'aeroflot_id': '123'}

    def get_request(self):
        return self.factory.get(reverse('token_delete', kwargs=self.reverse_kwargs))

    def get_response(self, request):
        return TokenDeleteView.as_view()(request, **self.reverse_kwargs)

    def get_testing_permission(self):
        return Permission.objects.get(codename='delete_aac_token')


class TestTokenDelete(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user_with_rights = User.objects.create(username='testing_user_token_rights', password='top_secret')
        self.user_with_rights.user_permissions.add(Permission.objects.get(codename='delete_aac_token'))

    def tearDown(self):
        self.factory = None
        self.user.delete()
        self.user_with_rights.delete()

    @patch('aac_admin.views.tokens.REDIS_CLIENT')
    def test_anonymous(self, redis_client_mock):
        del_mock, zrem_mock = Mock(), Mock()
        redis_client_mock.pipeline.return_value = del_mock
        del_mock.delete.return_value = zrem_mock
        reverse_kwargs = {'session_id': 'sess', 'jti': 'T-jti', 'aeroflot_id': '123'}
        request = self.factory.post(reverse('token_delete', kwargs=reverse_kwargs))
        request.user = AnonymousUser()
        response = TokenDeleteView.as_view()(request, **reverse_kwargs)
        self.assertEqual(response.status_code, 302)
        redis_client_mock.pipeline.assert_not_called()
        del_mock.delete.assert_not_called()
        zrem_mock.zrem.assert_not_called()

    @patch('aac_admin.views.tokens.REDIS_CLIENT')
    def test_without_rights(self, redis_client_mock):
        del_mock, zrem_mock = Mock(), Mock()
        redis_client_mock.pipeline.return_value = del_mock
        del_mock.delete.return_value = zrem_mock
        reverse_kwargs = {'session_id': 'sess', 'jti': 'T-jti', 'aeroflot_id': '123'}
        request = self.factory.post(reverse('token_delete', kwargs=reverse_kwargs))
        request.user = self.user
        response = TokenDeleteView.as_view()(request, **reverse_kwargs)
        self.assertEqual(response.status_code, 302)
        redis_client_mock.pipeline.assert_not_called()
        del_mock.delete.assert_not_called()
        zrem_mock.zrem.assert_not_called()

    @patch('aac_admin.views.tokens.REDIS_CLIENT')
    def test_with_rights(self, redis_client_mock):
        del_mock, zrem_mock = Mock(), Mock()
        redis_client_mock.pipeline.return_value = del_mock
        del_mock.delete.return_value = zrem_mock
        reverse_kwargs = {'session_id': 'sess', 'jti': 'T-jti', 'aeroflot_id': '123'}
        request = self.factory.post(reverse('token_delete', kwargs=reverse_kwargs))
        request.user = self.user_with_rights
        response = TokenDeleteView.as_view()(request, **reverse_kwargs)
        self.assertEqual(response.status_code, 302)
        redis_client_mock.pipeline.assert_called()
        del_mock.delete.assert_called()
        zrem_mock.zrem.assert_called()
