from unittest.mock import patch, MagicMock

from django.contrib.auth.models import User, Permission
from django.core.files import File
from django.test import TestCase, RequestFactory
from django.urls import reverse

from aac_admin import tasks
from aac_admin.api.v1.client_logo_saver import ClientLogoSaver
from aac_admin.api.v1.custom_validators import ImageValidator
from aac_admin.forms import ClientForm
from aac_admin.models import Client, UserIdProvider, LoginForm, User as AACUser
from aac_admin.tests import ViewTest
from aac_admin.views.clients import ClientAddView, ClientUpdateView, ClientDeleteView, ClientsView
from aac_admin.views import clients
from django.conf import settings


class ClientViewTest(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        self.client_id_test = 'client_id_test'
        create_form = ClientForm(get_client_data(self.client_id_test))
        self.assertTrue(create_form.is_valid())
        create_form.save()

    def tearDown(self):
        super().tearDown()
        Client.objects.filter(client_id=self.client_id_test).delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_client')

    def get_request(self):
        return self.factory.get(reverse('clients'))

    def get_response(self, request):
        return ClientsView.as_view()(request)

    def test_context_data(self):
        request = self.get_request()
        view = ClientsView()
        view.request = request
        view.object_list = view.get_queryset()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), 'Приложения-клиенты')

    def test_with_template_render(self):
        self.client.force_login(self.user_with_rights)
        response = self.client.get(reverse('clients'))
        self.assertEqual(response.status_code, 200)


class ClientAddViewTest(ViewTest, TestCase):
    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_client')

    def get_request(self):
        return self.factory.get(reverse('client_add'))

    def get_response(self, request):
        return ClientAddView.as_view()(request)


def get_client_data(client_id):
    provider = UserIdProvider.objects.first() if UserIdProvider.objects.first() \
        else UserIdProvider.objects.create(descr='test_user_id_provider')
    login_form = LoginForm.objects.first() if LoginForm.objects.first() \
        else LoginForm.objects.create(descr='test_login_form')
    image_file_mock = MagicMock(spec=File, name='FileMock')

    client_data = {f'{key}_{lang}': 'test'
                   for key in ('name', 'description') for lang in settings.TRANSLATION_TEXT_LANGUAGES}
    client_data.update({
        'redirect_uris': 'http://some_redirect.com',
        'response_types': 'qwe',
        'post_logout_redirect_uris': 'http://some_post_logout.com',
        'status': 'A',
        'client_id': client_id,
        'client_secret': 'some_secret',
        'client_type': 1,
        'user_id_provider': provider.id,
        'login_form': login_form.id,
        'logo_image': image_file_mock,
        'token_lifetime': 1800,
        'security_policy_id': 0,
        'available_login_forms': [f'{login_form.id}' for login_form in LoginForm.objects.all()]
    })
    return client_data


class CreateClientTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='add_aac_client'))
        self.client_id_test = 'client_id_test'
        log_patcher = patch.object(clients, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()

    def tearDown(self):
        Client.objects.filter(client_id=self.client_id_test).delete()
        self.factory = None
        self.user.delete()

    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_create(self, validate_image_mock, save_logo_mock):
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        self.assertTrue(clients.logger is self.logger_mock)
        self.assertTrue(ClientLogoSaver.save_logo_image is save_logo_mock)
        self.assertTrue(ImageValidator.__call__ is validate_image_mock)
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        # check initial recaptcha
        self.assertEqual(create_form.fields['security_policy_id'].initial(), 1)
        self.assertTrue(create_form.is_valid())
        request = self.factory.post(reverse('client_add'), data=client_data)
        request.user = self.user
        response = ClientAddView.as_view()(request)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        validate_image_mock.assert_called()
        save_logo_mock.assert_called()

    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_create_without_image(self, validate_image_mock, save_logo_mock):
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        client_data = get_client_data(self.client_id_test)
        client_data.pop('logo_image', None)
        create_form = ClientForm(client_data)
        # check initial recaptcha
        self.assertEqual(create_form.fields['security_policy_id'].initial(), 1)
        self.assertTrue(create_form.is_valid())
        request = self.factory.post(reverse('client_add'), data=client_data)
        request.user = self.user
        response = ClientAddView.as_view()(request)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Client.objects.filter(client_id=self.client_id_test).exists())
        validate_image_mock.assert_not_called()
        save_logo_mock.assert_not_called()

    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_create_logo_saver_failure(self, validate_image_mock, save_logo_mock):
        save_logo_mock.return_value = (False, 'some_error_message')
        validate_image_mock.return_value = True
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        # check initial recaptcha
        self.assertEqual(create_form.fields['security_policy_id'].initial(), 1)
        self.assertTrue(create_form.is_valid())
        request = self.factory.post(reverse('client_add'), data=client_data)
        request.user = self.user
        response = ClientAddView.as_view()(request)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Client.objects.filter(client_id=self.client_id_test).exists())
        validate_image_mock.assert_called()
        save_logo_mock.assert_called()

    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_create_no_data(self, validate_image_mock, save_logo_mock):
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        request = self.factory.post(reverse('client_add'))
        request.user = self.user
        response = ClientAddView.as_view()(request)
        self.assertEqual(response.status_code, 200)
        self.assertFalse(Client.objects.filter(client_id=self.client_id_test).exists())
        validate_image_mock.assert_not_called()
        save_logo_mock.assert_not_called()


class ClientUpdateViewTest(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        self.aac_client = Client.objects.create()

    def tearDown(self):
        super().tearDown()
        self.aac_client.delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_client')

    def get_request(self):
        return self.factory.get(reverse('client_update', kwargs={'pk': self.aac_client.pk}))

    def get_response(self, request):
        return ClientUpdateView.as_view()(request, pk=self.aac_client.pk)

    def test_with_template_render(self):
        self.client.force_login(self.user_with_rights)
        response = self.client.get(reverse('client_update', kwargs={'pk': self.aac_client.pk}))
        self.assertEqual(response.status_code, 200)


class UpdateClientTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_client'))
        self.client_id_test = 'client_id_test'
        log_patcher = patch.object(clients, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()
        delete_sessions_patcher = patch.object(clients, 'delete_sessions')
        self.addCleanup(delete_sessions_patcher.stop)
        delete_sessions_patcher.start()

    def tearDown(self):
        Client.objects.filter(client_id=self.client_id_test).delete()
        self.factory = None
        self.user.delete()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_update(self, validate_image_mock, save_logo_mock, delete_logo_mock):
        delete_logo_mock.return_value = (True, 'test_delete_log_message')
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        self.assertTrue(clients.logger is self.logger_mock)
        self.assertTrue(ClientLogoSaver.delete_logo_image is delete_logo_mock)
        self.assertTrue(ClientLogoSaver.save_logo_image is save_logo_mock)
        self.assertTrue(ImageValidator.__call__ is validate_image_mock)
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        client_data['status'] = 'B'
        client_data['token_lifetime'] = 600
        client_data['available_login_forms'] = ['0']
        request = self.factory.post(reverse('client_update', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientUpdateView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        updated_client = Client.objects.get(client_id=self.client_id_test)
        self.assertEqual(updated_client.pk, created_client.pk)
        self.assertEqual(updated_client.status, 'B')
        self.assertEqual(updated_client.token_lifetime, 600)
        self.assertEqual(updated_client.available_login_forms, [0])
        validate_image_mock.assert_called()
        save_logo_mock.assert_called()
        delete_logo_mock.assert_not_called()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_update_without_image(self, validate_image_mock, save_logo_mock, delete_logo_mock):
        delete_logo_mock.return_value = (True, 'test_delete_log_message')
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        client_data = get_client_data(self.client_id_test)
        client_data.pop('logo_image', None)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        client_data['status'] = 'B'
        client_data['token_lifetime'] = 600
        client_data['available_login_forms'] = ['0']
        request = self.factory.post(reverse('client_update', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientUpdateView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        updated_client = Client.objects.get(client_id=self.client_id_test)
        self.assertEqual(updated_client.pk, created_client.pk)
        self.assertEqual(updated_client.status, 'B')
        self.assertEqual(updated_client.token_lifetime, 600)
        self.assertEqual(updated_client.available_login_forms, [0])
        validate_image_mock.assert_not_called()
        save_logo_mock.assert_not_called()
        delete_logo_mock.assert_not_called()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_update_logo_saver_failure(self, validate_image_mock, save_logo_mock, delete_logo_mock):
        delete_logo_mock.return_value = (True, 'test_delete_log_message')
        save_logo_mock.return_value = (False, 'some_failure_message')
        validate_image_mock.return_value = True
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        client_data['status'] = 'B'
        client_data['token_lifetime'] = 600
        client_data['available_login_forms'] = ['0']
        request = self.factory.post(reverse('client_update', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientUpdateView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        updated_client = Client.objects.get(client_id=self.client_id_test)
        self.assertEqual(updated_client.pk, created_client.pk)
        self.assertEqual(updated_client.status, 'B')
        self.assertEqual(updated_client.token_lifetime, 600)
        self.assertEqual(updated_client.available_login_forms, [0])
        validate_image_mock.assert_called()
        save_logo_mock.assert_called()
        delete_logo_mock.assert_not_called()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_update_with_image_deletion_success(self, validate_image_mock, save_logo_mock, delete_logo_mock):
        delete_logo_mock.return_value = (True, 'test_delete_log_message')
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        created_client.logo_uri = 'some_logo_uri'
        created_client.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        client_data['status'] = 'B'
        client_data['token_lifetime'] = 600
        client_data['available_login_forms'] = ['0']
        request = self.factory.post(reverse('client_update', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientUpdateView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        updated_client = Client.objects.get(client_id=self.client_id_test)
        self.assertEqual(updated_client.pk, created_client.pk)
        self.assertEqual(updated_client.status, 'B')
        self.assertEqual(updated_client.token_lifetime, 600)
        self.assertEqual(updated_client.available_login_forms, [0])
        validate_image_mock.assert_called()
        save_logo_mock.assert_called()
        delete_logo_mock.assert_called()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    @patch.object(ClientLogoSaver, 'save_logo_image')
    @patch.object(ImageValidator, '__call__')
    def test_update_with_image_deletion_failure(self, validate_image_mock, save_logo_mock, delete_logo_mock):
        delete_logo_mock.return_value = (False, 'test_delete_log_error_message')
        save_logo_mock.return_value = (True, 'some_new_image_url')
        validate_image_mock.return_value = True
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        created_client.logo_uri = 'some_logo_uri'
        created_client.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        client_data['status'] = 'B'
        client_data['token_lifetime'] = 600
        client_data['available_login_forms'] = ['0']
        request = self.factory.post(reverse('client_update', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientUpdateView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        updated_client = Client.objects.get(client_id=self.client_id_test)
        self.assertEqual(updated_client.pk, created_client.pk)
        self.assertEqual(updated_client.status, 'B')
        self.assertEqual(updated_client.token_lifetime, 600)
        self.assertEqual(updated_client.available_login_forms, [0])
        validate_image_mock.assert_called()
        save_logo_mock.assert_called()
        delete_logo_mock.assert_called()


class DeleteSessionsTest(TestCase):
    def setUp(self):
        Client.objects.all().delete()
        AACUser.objects.all().delete()

    def tearDown(self):
        Client.objects.all().delete()
        AACUser.objects.all().delete()

    @patch.object(tasks, 'admin_actions_logger')
    @patch.object(tasks, 'admin_logger')
    @patch.object(tasks, 'delete_all_client_sessions_for_users')
    def test(self, delete_sessions_mock, *args):
        client_data = get_client_data(client_id=123)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        first_client = create_form.save()
        client_data = get_client_data(client_id=456)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        second_client = create_form.save()
        first, second = range(5), range(5, 10)
        for i in first:
            AACUser.objects.create(aeroflot_id=i, consents=[{'id': first_client.id}])
        for i in second:
            AACUser.objects.create(aeroflot_id=i, consents=[{'id': second_client.id}])
        tasks.delete_sessions(first_client.id, first_client.client_id, 'admin', 'test_action')
        delete_sessions_mock.assert_called_with(first_client.client_id)


class ClientDeleteViewTest(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        self.aac_client = Client.objects.create()

    def tearDown(self):
        super().tearDown()
        self.aac_client.delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='delete_aac_client')

    def get_request(self):
        return self.factory.get(reverse('client_delete', kwargs={'pk': self.aac_client.pk}))

    def get_response(self, request):
        return ClientDeleteView.as_view()(request, pk=self.aac_client.pk)

    def test_context_data(self):
        request = self.factory.get(reverse('client_delete', kwargs={'pk': self.aac_client.pk}))
        view = ClientDeleteView()
        view.request = request
        view.object = view.get_queryset()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), '')
        self.assertIsNotNone(context.get('object_to_delete'))
        self.assertIsNotNone(context.get('cancel_href'))


class ClientDeleteViewNotExistingClientTest(ViewTest, TestCase):
    expected_anonymous_status = 302
    expected_without_rights_status = 302
    expected_with_rights_status = 302

    def get_testing_permission(self):
        return Permission.objects.get(codename='delete_aac_client')

    def get_request(self):
        return self.factory.get(reverse('client_delete', kwargs={'pk': 1}))

    def get_response(self, request):
        return ClientDeleteView.as_view()(request, pk=1)


class DeleteClientTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='delete_aac_client'))
        self.client_id_test = 'client_id_test'
        log_patcher = patch.object(clients, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()
        delete_sessions_patcher = patch.object(clients, 'delete_sessions')
        self.addCleanup(delete_sessions_patcher.stop)
        self.delete_sessions_mock = delete_sessions_patcher.start()

    def tearDown(self):
        Client.objects.filter(client_id=self.client_id_test).delete()
        self.factory = None
        self.user.delete()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    def test_delete(self, delete_logo_mock):
        delete_logo_mock.return_value = (True, 'test_delete_log_message')
        self.assertTrue(clients.logger is self.logger_mock)
        self.assertTrue(ClientLogoSaver.delete_logo_image is delete_logo_mock)
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        created_client.logo_uri = 'test_logo_uri'
        created_client.save()
        request = self.factory.post(reverse('client_delete', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientDeleteView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Client.objects.filter(client_id=self.client_id_test).exists())
        delete_logo_mock.assert_called()
        self.delete_sessions_mock.delay.assert_called()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    def test_deletion_failure(self, delete_logo_mock):
        delete_logo_mock.return_value = (False, 'some_error_message')
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        created_client.logo_uri = 'test_logo_uri'
        created_client.save()
        request = self.factory.post(reverse('client_delete', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientDeleteView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Client.objects.filter(client_id=self.client_id_test).exists())
        delete_logo_mock.assert_called()
        self.delete_sessions_mock.delay.assert_called()

    @patch.object(ClientLogoSaver, 'delete_logo_image')
    def test_no_image_to_delete(self, delete_logo_mock):
        delete_logo_mock.return_value = (True, 'test_delete_log_message')
        client_data = get_client_data(self.client_id_test)
        create_form = ClientForm(client_data)
        self.assertTrue(create_form.is_valid())
        created_client = create_form.save()
        self.assertTrue(Client.objects.filter(client_id=self.client_id_test).exists())
        request = self.factory.post(reverse('client_delete', kwargs={'pk': created_client.pk}), data=client_data)
        request.user = self.user
        response = ClientDeleteView.as_view()(request, pk=created_client.pk)
        self.assertEqual(response.status_code, 302)
        self.assertFalse(Client.objects.filter(client_id=self.client_id_test).exists())
        delete_logo_mock.assert_not_called()
        self.delete_sessions_mock.delay.assert_called()
