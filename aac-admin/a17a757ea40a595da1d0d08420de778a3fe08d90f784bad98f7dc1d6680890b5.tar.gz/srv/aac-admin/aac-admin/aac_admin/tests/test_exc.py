from aac_admin.exc import AACAdminError

from django.test import TestCase


class AACAdminErrorTestCase(TestCase):
    def test_aac_admin_error(self):
        try:
            raise AACAdminError(msg='Test exception message', code='Test exception code')
        except AACAdminError as e:
            self.assertEqual(e.code, 'Test exception code')
            self.assertEqual(e.msg, 'Test exception message')
            self.assertIsInstance(e, AACAdminError)
            self.assertIsInstance(e, Exception)
            self.assertEqual(str(e), 'AACAdminError(Test exception code): Test exception message')
