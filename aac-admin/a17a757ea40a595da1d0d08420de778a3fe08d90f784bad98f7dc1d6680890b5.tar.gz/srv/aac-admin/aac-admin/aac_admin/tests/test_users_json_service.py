from django.test import TestCase
from django.contrib.auth import models

from aac_admin.api.v1 import users_json_service
from aac_admin.models import User


class UsersJsonServiceDictTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        for x in range(1, 10000):
            User.objects.get_or_create(lk_user_id=x, aeroflot_id=x)

    def setUp(self):
        user = models.User.objects.create_superuser("test_user", password="test_password", email="test_email")
        user.save()

    def test_users_json_service_all_none(self):
        result = users_json_service.get_users_list_dict()
        self.assertEqual(result['prev'], None)
        self.assertEqual(result['next'], {'offset': 100, 'items_count': 100})
        self.assertEqual(len(result['client_models']), 100)
        self.assertEqual(result['client_models'][1]['aeroflot_id'], 2)

    def test_users_json_service_offset_100(self):
        result = users_json_service.get_users_list_dict(offset=100)
        self.assertEqual(result['client_models'][0]['aeroflot_id'], 101)
        self.assertEqual(result['client_models'][99]['aeroflot_id'], 200)
        self.assertEqual(result['prev'], {'offset': 0, 'items_count': 100})
        self.assertEqual(result['next'], {'offset': 200, 'items_count': 100})

    def test_users_json_service_items_count_1000(self):
        result = users_json_service.get_users_list_dict(items_count=1000)
        self.assertEqual(len(result['client_models']), 1000)
        self.assertEqual(result['client_models'][0]['aeroflot_id'], 1)
        self.assertEqual(result['client_models'][999]['aeroflot_id'], 1000)
        self.assertEqual(result['prev'], None)
        self.assertEqual(result['next'], {'offset': 1000, 'items_count': 1000})

    def test_users_json_service_aeroflot_id(self):
        result = users_json_service.get_users_list_dict(aeroflot_id="1??1", items_count=1000)
        self.assertEqual(len(result['client_models']), 100)
        self.assertEqual(result['client_models'][0]['aeroflot_id'], 1001)
        self.assertEqual(result['client_models'][99]['aeroflot_id'], 1991)

        result = users_json_service.get_users_list_dict(aeroflot_id="12*4")
        self.assertEqual(len(result['client_models']), 11)
        self.assertEqual(result['client_models'][0]['aeroflot_id'], 124)
        self.assertEqual(result['client_models'][10]['aeroflot_id'], 1294)

    def test_users_json_service_lk_user_id(self):
        result = users_json_service.get_users_list_dict(lk_user_id="1??1", items_count=1000)
        self.assertEqual(len(result['client_models']), 100)
        self.assertEqual(result['client_models'][0]['lk_user_id'], 1001)
        self.assertEqual(result['client_models'][99]['lk_user_id'], 1991)

        result = users_json_service.get_users_list_dict(lk_user_id="12*4")
        self.assertEqual(len(result['client_models']), 11)
        self.assertEqual(result['client_models'][0]['lk_user_id'], 124)
        self.assertEqual(result['client_models'][10]['lk_user_id'], 1294)

    def test_users_json_service_aeroflot_lk_user_id(self):
        result = users_json_service.get_users_list_dict(lk_user_id="1????1", aeroflot_id="1*1")
        self.assertEqual(len(result['client_models']), 0)

    def test_users_json_service_all_empty_strings(self):
        result = users_json_service.get_users_list_dict(lk_user_id='', aeroflot_id='')
        self.assertEqual(result['prev'], None)
        self.assertEqual(result['next'], {'offset': 100, 'items_count': 100})
        self.assertEqual(len(result['client_models']), 100)
        self.assertEqual(result['client_models'][1]['aeroflot_id'], 2)

    def test_users_json_service_invalid_strings(self):
        try:
            users_json_service.get_users_list_dict(lk_user_id='', aeroflot_id='asdasd')
        except users_json_service.InvalidParamsException as e:
            self.assertIn('aeroflot_id', e.invalid_params)

        try:
            users_json_service.get_users_list_dict(lk_user_id='asdasd', aeroflot_id='')
        except users_json_service.InvalidParamsException as e:
            self.assertIn('lk_user_id', e.invalid_params)


class UsersJsonServiceWebTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        for x in range(1, 10000):
            User.objects.get_or_create(lk_user_id=x, aeroflot_id=x)

    def setUp(self):
        user = models.User.objects.create_superuser("test_user", password="test_password", email="test_email")
        user.save()

    def test_users_json_service_web_call_all(self):
        self.client.login(username="test_user", password="test_password")
        params = {'aeroflot_id': '1?1', 'offset': '15', 'items_count': '50', 'lk_user_id': '1111*'}
        response = self.client.get('/admin/users/get_users', params)
        self.assertEqual(response.status_code, 200)

    def test_users_json_service_web_call_all_none(self):
        self.client.login(username="test_user", password="test_password")
        params = {}
        response = self.client.get('/admin/users/get_users', params)
        self.assertEqual(response.status_code, 200)

    def test_users_json_service_web_call_bad(self):
        self.client.login(username="test_user", password="test_password")
        params = {'lk_user_id': 'bad_param_kaboom'}
        response = self.client.get('/admin/users/get_users', params)
        self.assertEqual(response.status_code, 400)


class UsersJsonServiceValidationTestCase(TestCase):
    def test_params_validation(self):
        try:
            users_json_service.validate_params(None, None, None, None)
        except users_json_service.InvalidParamsException as e:
            self.assertIn('items_count', e.invalid_params)
            self.assertIn('offset', e.invalid_params)
            self.assertIn('aeroflot_id', e.invalid_params)
            self.assertIn('lk_user_id', e.invalid_params)

        try:
            users_json_service.validate_params(aeroflot_id='', lk_user_id='', items_count=100, offset=0)
        except users_json_service.InvalidParamsException as e:
            self.assertIn('aeroflot_id', e.invalid_params)
            self.assertIn('lk_user_id', e.invalid_params)
            self.assertNotIn('offset', e.invalid_params)
            self.assertNotIn('items_count', e.invalid_params)

        try:
            users_json_service.validate_params(aeroflot_id='*1*', lk_user_id='*1*', offset='', items_count='')
        except users_json_service.InvalidParamsException as e:
            self.assertNotIn('aeroflot_id', e.invalid_params)
            self.assertNotIn('lk_user_id', e.invalid_params)
            self.assertIn('offset', e.invalid_params)
            self.assertIn('items_count', e.invalid_params)
