from django.test.client import RequestFactory
from django.test import TestCase
from django.urls import reverse

from aac_admin.views import monitoring
from aac_admin.templatetags.common_tags import get_app_revision


class StatusViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def tearDown(self):
        self.factory = None

    def test_get(self):
        request = self.factory.get(reverse('monitoring_status'))
        response = monitoring.StatusView().get(request)
        current_revision = get_app_revision()
        self.assertEqual(response.status_code, 200)
        self.assertJSONEqual(str(response.content, encoding='UTF-8'), {'version': current_revision})


class PingViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def tearDown(self):
        self.factory = None

    def test_get(self):
        request = self.factory.get(reverse('monitoring_ping'))
        response = monitoring.PingView().get(request)
        self.assertEqual(str(response.content, encoding='UTF-8'), 'PONG')
