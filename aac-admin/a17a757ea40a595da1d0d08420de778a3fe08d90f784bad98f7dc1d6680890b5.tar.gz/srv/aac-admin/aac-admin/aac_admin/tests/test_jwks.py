from unittest.mock import patch

from django.contrib.auth.models import Permission, User
from django.test import TestCase, RequestFactory
from django.urls import reverse

from Cryptodome.PublicKey import RSA

from aac_admin.models import JwkKey
from aac_admin.tests import ViewTest
from aac_admin.views import jwk_keys
from aac_admin.views.jwk_keys import JwkKeysView, jwk_key_add_view, JwkKeyUpdateView, JwkKeyDeleteView, RSA_KEY_SIZE


class JwkViewTest(ViewTest, TestCase):
    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_setting')

    def get_request(self):
        return self.factory.get(reverse('jwk_keys'))

    def get_response(self, request):
        return JwkKeysView.as_view()(request)


class JwkDeleteViewTest(ViewTest, TestCase):
    def setUp(self):
        key = RSA.generate(RSA_KEY_SIZE)
        private = key.exportKey('PEM').decode()
        public = key.publickey().exportKey('PEM').decode()
        super().setUp()
        self.jwk_key = JwkKey.objects.create(public=public, private=private)

    def tearDown(self):
        super().tearDown()
        self.jwk_key.delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='delete_aac_setting')

    def get_request(self):
        return self.factory.get(reverse('user_delete', kwargs={'pk': self.jwk_key.pk}))

    def get_response(self, request):
        return JwkKeyDeleteView.as_view()(request, pk=self.jwk_key.pk)


class JwkDeleteViewNotExistTest(ViewTest, TestCase):
    expected_anonymous_status = 302
    expected_without_rights_status = 302
    expected_with_rights_status = 302

    def setUp(self):
        super().setUp()
        JwkKey.objects.all().delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='delete_aac_setting')

    def get_request(self):
        return self.factory.get(reverse('jwk_key_delete', kwargs={'pk': 1}))

    def get_response(self, request):
        return JwkKeyDeleteView.as_view()(request, pk=1)


class AddJwkKeyTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='view_aac_setting'))
        self.user.user_permissions.add(Permission.objects.get(codename='add_aac_setting'))
        JwkKey.objects.all().delete()
        log_patcher = patch.object(jwk_keys, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()

    def tearDown(self):
        self.user.delete()

    def test_add(self):
        request = self.factory.post(reverse('jwk_key_add'))
        request.user = self.user
        response = jwk_key_add_view(request)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(JwkKey.objects.exists())
        self.assertEqual(JwkKey.objects.all().delete()[0], 1)


class UpdateJwkKeyTest(TestCase):
    def setUp(self):
        key = RSA.generate(RSA_KEY_SIZE)
        private = key.exportKey('PEM').decode()
        public = key.publickey().exportKey('PEM').decode()
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_setting'))
        self.create_params = dict(public=public, private=private, is_active=True)
        self.first_key = JwkKey.objects.create(**self.create_params)
        self.second_key = JwkKey.objects.create(**self.create_params)
        log_patcher = patch.object(jwk_keys, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()

    def tearDown(self):
        self.user.delete()
        self.first_key.delete()
        self.second_key.delete()

    def test_update(self):
        request = self.factory.get(reverse('jwk_key_update', kwargs={'pk': self.first_key.pk}))
        request.user = self.user
        response = JwkKeyUpdateView.as_view()(request, pk=self.first_key.pk)
        self.assertEqual(response.status_code, 200)
        first_updated = JwkKey.objects.get(id=self.first_key.id)
        self.assertEqual(first_updated.public, self.create_params['public'])
        self.assertEqual(first_updated.private, self.create_params['private'])
        self.assertEqual(first_updated.is_active, False)

        request = self.factory.get(reverse('jwk_key_update', kwargs={'pk': self.second_key.pk}))
        request.user = self.user
        response = JwkKeyUpdateView.as_view()(request, pk=self.second_key.pk)
        self.assertEqual(response.status_code, 400)
        second_updated = JwkKey.objects.get(id=self.second_key.id)
        self.assertEqual(second_updated.public, self.create_params['public'])
        self.assertEqual(second_updated.private, self.create_params['private'])
        self.assertEqual(second_updated.is_active, True)


class DeleteJwkKeyTest(TestCase):
    def setUp(self):
        key = RSA.generate(RSA_KEY_SIZE)
        private = key.exportKey('PEM').decode()
        public = key.publickey().exportKey('PEM').decode()
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='delete_aac_setting'))
        self.create_params = dict(public=public, private=private, is_active=True)
        self.first_key = JwkKey.objects.create(**self.create_params)
        self.second_key = JwkKey.objects.create(**self.create_params)
        log_patcher = patch.object(jwk_keys, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()

    def tearDown(self):
        self.user.delete()
        self.first_key.delete()
        self.second_key.delete()

    def test_delete(self):
        request = self.factory.post(reverse('jwk_key_delete', kwargs={'pk': self.first_key.pk}))
        request.user = self.user
        response = JwkKeyDeleteView.as_view()(request, pk=self.first_key.pk)
        self.assertEqual(response.status_code, 302)
        self.assertFalse(JwkKey.objects.filter(pk=self.first_key.id).exists())

        request = self.factory.post(reverse('jwk_key_delete', kwargs={'pk': self.second_key.pk}))
        request.user = self.user
        response = JwkKeyDeleteView.as_view()(request, pk=self.second_key.pk)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(JwkKey.objects.filter(pk=self.second_key.id).exists())
