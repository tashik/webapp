from unittest.mock import patch

from django.contrib.auth.models import User, AnonymousUser, Permission
from django.test import TestCase, override_settings

from aac_admin.templatetags.common_tags import get_item, can_view_aac_admin_model, get_revision_label, get_app_revision


class CanViewModelTest(TestCase):
    def setUp(self):
        self.models = ('aac_user', 'aac_client', 'aac_scope', 'aac_setting', 'aac_token', 'aac_social')
        self.anonymous = AnonymousUser()
        self.user_without_rights = User.objects.create(username='testing_user_without_rights', password='top_secret')
        self.user_has_view = User.objects.create(username='testing_user_has_view', password='top_secret')
        self.user_has_add = User.objects.create(username='testing_user_has_add', password='top_secret')
        self.user_has_change = User.objects.create(username='testing_user_has_change', password='top_secret')
        self.user_has_delete = User.objects.create(username='testing_user_has_delete', password='top_secret')
        for model in self.models:
            self.user_has_view.user_permissions.add(Permission.objects.get(codename=f'view_{model}'))
            self.user_has_add.user_permissions.add(Permission.objects.get(codename=f'add_{model}'))
            self.user_has_change.user_permissions.add(Permission.objects.get(codename=f'change_{model}'))
            self.user_has_delete.user_permissions.add(Permission.objects.get(codename=f'delete_{model}'))

    def tearDown(self):
        self.user_without_rights.delete()
        self.user_has_view.delete()
        self.user_has_add.delete()
        self.user_has_change.delete()
        self.user_has_delete.delete()

    def test_can_view(self):
        for model in self.models:
            self.assertFalse(can_view_aac_admin_model(self.anonymous, model))
            self.assertFalse(can_view_aac_admin_model(self.user_without_rights, model))
            self.assertTrue(can_view_aac_admin_model(self.user_has_view, model))
            self.assertTrue(can_view_aac_admin_model(self.user_has_add, model))
            self.assertTrue(can_view_aac_admin_model(self.user_has_change, model))
            self.assertTrue(can_view_aac_admin_model(self.user_has_delete, model))


class GetItemTest(TestCase):
    def test_get_from_not_dict(self):
        default = 'default'
        for _type in (int, float, list, tuple, set, frozenset):
            self.assertEqual(get_item(_type(), 'key', default), default)

    def test_get_from_dict(self):
        default = 'default'
        d = {'exists': 'value_exist'}
        self.assertEqual(get_item(d, 'exists', default), d['exists'])
        self.assertEqual(get_item(d, 'not_exists', default), default)


class AppRevisionTest(TestCase):
    def test(self):
        revision = get_app_revision()
        self.assertTrue(bool(revision))

    @patch('aac_admin.templatetags.common_tags.subprocess')
    @patch('aac_admin.templatetags.common_tags.logging')
    def test_exception(self, logging_mock, subprocess_mock):
        subprocess_mock.check_output.side_effect = Exception()
        get_app_revision()
        # subprocess_mock.check_output.assert_called()
        # logging_mock.exception.assert_called()


class RevisionLabelTest(TestCase):
    def test_without_debug(self):
        revision = get_revision_label({})
        self.assertFalse(bool(revision))

    @override_settings(DEBUG=True)
    def test_debug(self):
        revision = get_revision_label({})
        self.assertTrue(bool(revision))
