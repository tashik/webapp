import json
from unittest.mock import patch

from django.contrib.auth.models import User, Permission, AnonymousUser
from django.test import TestCase, RequestFactory
from django.urls import reverse

from aac_admin.api.v1.users_json_service import InvalidParamsException
from aac_admin.forms import UserForm
from aac_admin.tests import ViewTest
from aac_admin.views import users
from aac_admin.models import User as AACUser, Client
from aac_admin.views.users import user_list_html, users_view, UserAddView, UserUpdateView, UserDeleteView, user_tokens


class UserViewTest(ViewTest, TestCase):
    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_user')

    def get_request(self):
        return self.factory.get(reverse('users'))

    def get_response(self, request):
        return users_view(request)


class UserAddViewTest(ViewTest, TestCase):
    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_user')

    def get_request(self):
        return self.factory.get(reverse('user_add'))

    def get_response(self, request):
        return UserAddView.as_view()(request)


class CreateUserTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='add_aac_user'))
        log_patcher = patch.object(users, 'logger')
        self.addCleanup(log_patcher.stop)
        log_patcher.start()

    def tearDown(self):
        self.factory = None
        self.user.delete()
        AACUser.objects.all().delete()

    def test_create_active(self):
        form = UserForm(data={'lk_user_id': 0, 'status': 'A'})
        self.assertTrue(form.is_valid())
        request = self.factory.post(reverse('user_add'), data=form.cleaned_data)
        request.user = self.user
        response = users.UserAddView.as_view()(request)
        self.assertIn(response.status_code, (200, 302))
        self.assertTrue(AACUser.objects.filter(lk_user_id=None).exists())
        self.assertEqual(AACUser.objects.get(lk_user_id=None).status, 'A')

    def test_create_blocked(self):
        form = UserForm(data={'lk_user_id': 0, 'status': 'B'})
        self.assertTrue(form.is_valid())
        request = self.factory.post(reverse('user_add'), data=form.cleaned_data)
        request.user = self.user
        response = users.UserAddView.as_view()(request)
        self.assertIn(response.status_code, (200, 302))
        self.assertTrue(AACUser.objects.filter(lk_user_id=None).exists())
        self.assertEqual(AACUser.objects.get(lk_user_id=None).status, 'B')


class UserUpdateViewTest(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        self.aac_user = AACUser.objects.create(aeroflot_id=0)

    def tearDown(self):
        super().tearDown()
        self.aac_user.delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_user')

    def get_request(self):
        return self.factory.get(reverse('user_update', kwargs={'pk': self.aac_user.pk}))

    def get_response(self, request):
        return UserUpdateView.as_view()(request, pk=self.aac_user.pk)

    def test_context_data(self):
        request = self.factory.get(reverse('user_update', kwargs={'pk': self.aac_user.pk}))
        view = UserUpdateView(kwargs={'pk': self.aac_user.pk})
        view.request = request
        view.object = view.get_object()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), 'Пользователи')


class UpdateUserTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_user'))
        redis_patcher = patch.object(users, 'delete_sessions_by_aeroflot_id')
        self.addCleanup(redis_patcher.stop)
        self.delete_sessions_mock = redis_patcher.start()
        redis_patcher = patch.object(users, 'delete_user_tokens_by_client_ids')
        self.addCleanup(redis_patcher.stop)
        self.delete_tokens_mock = redis_patcher.start()
        log_patcher = patch.object(users, 'logger')
        self.addCleanup(log_patcher.stop)
        log_patcher.start()
        AACUser.objects.all().delete()

    def tearDown(self):
        AACUser.objects.all().delete()
        Client.objects.all().delete()
        self.factory = None
        self.user.delete()

    def test_update_active_to_blocked(self):
        self.assertTrue(users.delete_sessions_by_aeroflot_id is self.delete_sessions_mock)
        create_form = UserForm(data={'lk_user_id': 0, 'status': 'A'})
        self.assertTrue(create_form.is_valid())
        created_user = create_form.save()
        update_form = UserForm(data={'lk_user_id': 0, 'status': 'B'}, instance=created_user)
        self.assertTrue(update_form.is_valid())
        request = self.factory.post(reverse('user_update', kwargs={'pk': created_user.pk}),
                                    data=update_form.cleaned_data)
        request.user = self.user
        response = users.UserUpdateView.as_view()(request, pk=created_user.pk)
        self.assertIn(response.status_code, (200, 302))
        updated_user = AACUser.objects.get(lk_user_id=None)
        self.assertEqual(updated_user.status, 'B')
        self.assertNotEqual(updated_user.last_modified, created_user.last_modified)
        self.delete_sessions_mock.assert_called()

    def test_update_blocked_to_active(self):
        self.assertTrue(users.delete_sessions_by_aeroflot_id is self.delete_sessions_mock)
        create_form = UserForm(data={'lk_user_id': 0, 'status': 'B'})
        self.assertTrue(create_form.is_valid())
        created_user = create_form.save()
        update_form = UserForm(data={'lk_user_id': 0, 'status': 'A'}, instance=created_user)
        self.assertTrue(update_form.is_valid())
        request = self.factory.post(reverse('user_update', kwargs={'pk': created_user.pk}),
                                    data=update_form.cleaned_data)
        request.user = self.user
        response = users.UserUpdateView.as_view()(request, pk=created_user.pk)
        self.assertIn(response.status_code, (200, 302))
        updated_user = AACUser.objects.get(lk_user_id=None)
        self.assertEqual(updated_user.status, 'A')
        self.assertNotEqual(updated_user.last_modified, created_user.last_modified)
        self.delete_sessions_mock.assert_not_called()

    def test_update_consents(self):
        clients_list = [Client.objects.create(client_id=f'client_id_{i}') for i in range(3)]
        user = AACUser.objects.create(aeroflot_id=1, lk_user_id=1, status='A',
                                      consents=[{'id': client.id} for client in clients_list])
        update_form = UserForm(data={'aeroflot_id': user.aeroflot_id, 'lk_user_id': user.lk_user_id,
                                     'status': 'A', 'consents': []})
        self.assertTrue(update_form.is_valid())
        request = self.factory.post(reverse('user_update', kwargs={'pk': user.pk}), data=update_form.cleaned_data)
        request.user = self.user
        response = users.UserUpdateView.as_view()(request, pk=user.pk)
        self.assertEqual(response.status_code, 302)
        updated_user = AACUser.objects.get(lk_user_id=user.lk_user_id)
        self.assertEqual(updated_user.consents, [])
        self.delete_tokens_mock.assert_called()
        call_args = self.delete_tokens_mock.call_args[0]
        self.assertEqual(call_args[0], user.aeroflot_id)
        self.assertSequenceEqual(call_args[1], [client.client_id for client in clients_list])


class UserDeleteViewTest(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        self.aac_user = AACUser.objects.create(aeroflot_id=0)

    def tearDown(self):
        super().tearDown()
        self.aac_user.delete()

    def get_testing_permission(self):
        return Permission.objects.get(codename='delete_aac_user')

    def get_request(self):
        return self.factory.get(reverse('user_delete', kwargs={'pk': self.aac_user.pk}))

    def get_response(self, request):
        return UserDeleteView.as_view()(request, pk=self.aac_user.pk)

    def test_context_data(self):
        request = self.factory.get(reverse('user_delete', kwargs={'pk': self.aac_user.pk}))
        view = UserDeleteView(kwargs={'pk': self.aac_user.pk})
        view.request = request
        view.object = view.get_object()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), '')
        self.assertIsNotNone(context.get('object_to_delete'))
        self.assertIsNotNone(context.get('cancel_href'))


class DeleteUserTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='delete_aac_user'))
        log_patcher = patch.object(users, 'logger')
        self.addCleanup(log_patcher.stop)
        log_patcher.start()

    def tearDown(self):
        AACUser.objects.all().delete()
        self.factory = None
        self.user.delete()

    @patch('aac_admin.views.users.delete_sessions_by_aeroflot_id')
    def test_delete(self, delete_sessions_stub):
        create_form = UserForm(data={'lk_user_id': 0, 'status': 'A'})
        self.assertTrue(create_form.is_valid())
        created_user = create_form.save()
        self.assertTrue(AACUser.objects.filter(lk_user_id=None).exists())
        delete_form = UserForm(data={'lk_user_id': 0, 'status': 'A'}, instance=created_user)
        self.assertTrue(delete_form.is_valid())
        request = self.factory.post(reverse('user_update', kwargs={'pk': created_user.pk}),
                                    data=delete_form.cleaned_data)
        request.user = self.user
        response = users.UserDeleteView.as_view()(request, pk=created_user.pk)
        self.assertTrue(delete_sessions_stub.called)
        self.assertIn(response.status_code, (200, 302))
        self.assertFalse(AACUser.objects.filter(pk=created_user.pk).exists())


class TestUserListService(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user_with_rights = User.objects.create(username='testing_user_token_rights', password='top_secret')
        self.user_with_rights.user_permissions.add(Permission.objects.get(codename='view_aac_user'))

    def tearDown(self):
        self.factory = None
        self.user.delete()
        self.user_with_rights.delete()

    @patch('aac_admin.views.users.get_users_list_dict')
    def test_anonymous(self, users_service_mock):
        users_service_mock.get.return_value = []
        from aac_admin.views.users import get_users_list_dict
        self.assertTrue(users_service_mock is get_users_list_dict)
        request = self.factory.get(reverse('user_list_html'))
        request.user = AnonymousUser()
        response = user_list_html(request)
        self.assertEqual(response.status_code, 401)
        users_service_mock.assert_not_called()
        users_service_mock().get.assert_not_called()

    @patch('aac_admin.views.users.get_users_list_dict')
    def test_without_rights(self, users_service_mock):
        users_service_mock.get.return_value = []
        from aac_admin.views.users import get_users_list_dict
        self.assertTrue(users_service_mock is get_users_list_dict)
        request = self.factory.get(reverse('user_list_html'))
        request.user = self.user
        response = user_list_html(request)
        self.assertEqual(response.status_code, 403)
        users_service_mock.assert_not_called()
        users_service_mock().get.assert_not_called()

    @patch('aac_admin.views.users.get_users_list_dict')
    def test_with_rights(self, users_service_mock):
        users_service_mock.get.return_value = []
        from aac_admin.views.users import get_users_list_dict
        self.assertTrue(users_service_mock is get_users_list_dict)
        request = self.factory.get(reverse('user_list_html'))
        request.user = self.user_with_rights
        response = user_list_html(request)
        self.assertEqual(response.status_code, 200)
        users_service_mock.assert_called()
        users_service_mock().get.assert_called()

    @patch('aac_admin.views.users.get_users_list_dict')
    def test_with_rights_exception(self, users_service_mock):
        users_service_mock.side_effect = InvalidParamsException('message', [])
        from aac_admin.views.users import get_users_list_dict
        self.assertTrue(users_service_mock is get_users_list_dict)
        request = self.factory.get(reverse('user_list_html'))
        request.user = self.user_with_rights
        response = user_list_html(request)
        self.assertEqual(response.status_code, 200)
        users_service_mock.assert_called()

    @patch('aac_admin.views.users.get_users_list_dict')
    def test_with_rights_and_bad_params(self, users_service_mock):
        users_service_mock.get.return_value = []
        from aac_admin.views.users import get_users_list_dict
        self.assertTrue(users_service_mock is get_users_list_dict)
        request = self.factory.get(reverse('user_list_html'), {'offset': 'bad', 'some': 'staff'})
        request.user = self.user_with_rights
        response = user_list_html(request)
        self.assertEqual(response.status_code, 200)
        users_service_mock.assert_called()
        users_service_mock().get.assert_called()


class TestUserToken(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create(username='testing_user', password='top_secret')
        self.user_with_rights = User.objects.create(username='testing_user_token_rights', password='top_secret')
        self.user_with_rights.user_permissions.add(Permission.objects.get(codename='view_aac_user'))

    def tearDown(self):
        self.factory = None
        self.user.delete()
        self.user_with_rights.delete()

    def test_anonymous(self):
        request = self.factory.get(reverse('user_tokens'))
        request.user = AnonymousUser()
        response = user_tokens(request)
        self.assertEqual(response.status_code, 401)

    def test_without_rights(self):
        request = self.factory.get(reverse('user_tokens'))
        request.user = self.user
        response = user_tokens(request)
        self.assertEqual(response.status_code, 403)

    def test_with_rights_without_params(self):
        request = self.factory.get(reverse('user_tokens'))
        request.user = self.user_with_rights
        response = user_tokens(request)
        self.assertEqual(response.status_code, 400)

    @patch.object(users.TokenList, 'get_tokens_by_aeroflot_id')
    def test_with_rights(self, token_list_mock):
        aeroflot_id = 'test'
        tokens = []
        for i in range(3):
            tokens.append({
                'jti': f'T-jti{i}',
                'session_id': f'sid-{i}',
                'client_id': f'client_id-{i}',
                'aeroflot_id': aeroflot_id
            })
        token_list_mock.return_value = tokens
        request = self.factory.get(f"{reverse('user_tokens')}?aeroflot_id={aeroflot_id}&user_id=100")
        request.user = self.user_with_rights
        response = user_tokens(request)
        self.assertEqual(response.status_code, 200)
        token_list_mock.assert_called()
        content = json.loads(response.content)
        self.assertTrue('tokens' in content)
        self.assertEqual(len(content['tokens']), 3)
        self.assertTrue(all(token['aeroflot_id'] == aeroflot_id for token in content['tokens']))
        self.assertTrue(all('url' in token for token in content['tokens']))
