from django.contrib.auth.models import User, Permission
from django.test import TestCase, RequestFactory
from django.urls import reverse

from aac_admin.forms import SocialForm
from aac_admin.models import Social
from aac_admin.tests import ViewTest
from aac_admin.views.socials import SocialUpdateView, SocialsView


class UpdateSocialTest(TestCase):
    def setUp(self):
        self.social = Social.objects.create(id=10000,
                                            backend_class='test.backend',
                                            name={'ru': 'Тест', 'en': 'Test'},
                                            css_class='Test_css',
                                            params={'TEST_PARAM_1_NAME': 'TEST_PARAM1_VALUE',
                                                    'TEST_PARAM_2_NAME': 'TEST_PARAM_2_VALUE'},
                                            enabled=False
                                            )
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_social'))

    def tearDown(self):
        Social.objects.filter(pk=self.social.pk).delete()
        self.factory = None
        self.user.delete()

    def test_update(self):
        social_update_data = {
            'name_ru': 'Тест Изменён',
            'name_en': 'Test Changed',
            'css_class': 'css',
            'enabled': True
        }
        form = SocialForm(data=social_update_data)

        self.assertTrue(form.is_valid())

        request = self.factory.post(reverse('social_update', kwargs={'pk': self.social.pk}), data=form.data)
        request.user = self.user
        response = SocialUpdateView.as_view()(request, pk=self.social.pk)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(Social.objects.filter(pk=self.social.pk).exists())
        updated_social = Social.objects.get(pk=self.social.pk)
        self.assertTrue(updated_social.enabled)
        self.assertEqual(updated_social.css_class, 'css')
        self.assertEqual(updated_social.name['ru'], 'Тест Изменён')
        self.assertEqual(updated_social.name['en'], 'Test Changed')


class SocialsViewTest(ViewTest, TestCase):
    def get_testing_permission(self):
        return Permission.objects.get(codename='view_aac_social')

    def get_request(self):
        return self.factory.get(reverse('socials'))

    def get_response(self, request):
        return SocialsView.as_view()(request)

    def test_context_data(self):
        request = self.get_request()
        view = SocialsView()
        view.request = request
        view.object_list = view.get_queryset()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), 'Социальные сети')


class SocialsUpdateViewTest(ViewTest, TestCase):
    def setUp(self):
        super().setUp()
        if Social.objects.first():
            self.social = Social.objects.first()
        else:
            self.social = Social.objects.create(backend_class='social_core.backends.vk.VKOAuth2')

    def tearDown(self):
        super().tearDown()
        self.social.delete()

    def get_testing_permission(self):
        return [Permission.objects.get(codename='change_aac_social'), Permission.objects.get(codename='view_aac_social')]

    def get_request(self):
        return self.factory.get(reverse('social_update', kwargs={'pk': self.social.pk}))

    def get_response(self, request):
        return SocialUpdateView.as_view()(request, pk=self.social.pk)

    def test_context_data(self):
        request = self.get_request()
        view = SocialUpdateView(kwargs={'pk': self.social.pk})
        view.request = request
        view.object = view.get_object()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), self.social.get_name().upper())
