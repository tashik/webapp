from django.test import TestCase

from aac_admin.forms import ClientForm
from aac_admin.models import UserIdProvider, LoginForm, Scope
from aac_admin.utils import get_all_scopes_choices


class ClientTestCase(TestCase):
    def setUp(self):
        super().setUp()
        self.client_params = {'redirect_uris': "['http://test', 'local']", 'sector_id': 0,
                              'post_logout_redirect_uris': "['local']", 'security_policy_id': 1,
                              'name': "{'ru':'test'}"}

    def test_client_id(self):
        params = {'client_id': 'не валидный'}
        params.update(self.client_params)
        client_form = ClientForm(data=params)
        client_form.is_valid()
        self.assertIn('client_id', client_form.errors)

        params = {'client_id': 'test_id'}
        client_form = ClientForm(data=params)
        client_form.is_valid()
        self.assertNotIn('client_id', client_form.errors)

        # %x20-7E
        client_id = ''.join([chr(number) for number in range(32, 127)])
        params = {'client_id': client_id}
        client_form = ClientForm(data=params)
        client_form.is_valid()
        self.assertNotIn('client_id', client_form.errors)

    def test_user_id_provider(self):
        if UserIdProvider.objects.first():
            provider = UserIdProvider.objects.first()
        else:
            provider = UserIdProvider.objects.create(descr='test_user_id_provider')
        params = {'client_id': 'test_id', 'user_id_provider': provider.id}
        params.update(self.client_params)
        client_form = ClientForm(data=params)
        client_form.is_valid()
        self.assertNotIn('user_id_provider', client_form.errors)

    def test_login_form(self):
        if LoginForm.objects.first():
            login_form = LoginForm.objects.first()
        else:
            login_form = LoginForm.objects.create(descr='test_login_form')
        params = {'client_id': 'test_id', 'login_form': login_form.id}
        params.update(self.client_params)
        client_form = ClientForm(data=params)
        client_form.is_valid()
        self.assertNotIn('login_form', client_form.errors)

    def test_get_all_scopes_choices(self):
        all_scopes = get_all_scopes_choices()
        testing_scopes = [(scope.value, scope.value) for scope in Scope.objects.all()]
        for tuple_scope in testing_scopes:
            self.assertIn(tuple_scope, all_scopes)
