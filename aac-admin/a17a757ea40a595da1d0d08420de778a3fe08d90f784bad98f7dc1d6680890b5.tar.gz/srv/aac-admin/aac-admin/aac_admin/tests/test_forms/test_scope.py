from django.test import TestCase

from aac_admin.forms import ScopeForm


class ScopeTestCase(TestCase):
    def test_value(self):
        params = {'value': 'не валидный', 'description': {'ru': 'ru'}}
        scope_form = ScopeForm(data=params)
        scope_form.is_valid()
        self.assertIn('value', scope_form.errors)

        params = {'value': 'test_scope'}
        scope_form = ScopeForm(data=params)
        scope_form.is_valid()
        self.assertNotIn('value', scope_form.errors)

        # %x21|%x23-5b|%x5d-7e
        scope = ''.join([chr(number) for number in [33] + list(range(35, 92)) + list(range(93, 127))])
        params = {'value': scope}
        scope_form = ScopeForm(data=params)
        scope_form.is_valid()
        self.assertNotIn('value', scope_form.errors)
