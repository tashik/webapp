import json
from aac_admin.forms import AACCaptchaForm
from aac_admin.models import AACCaptcha
from django.test import TestCase


class CaptchaFormTestCase(TestCase):
    def setUp(self):
        temp_captcha = AACCaptcha.objects.get(id=1)
        for i in temp_captcha.settings.values():
            i['value'] = str(i['value'])
        self.assertTrue(temp_captcha.settings is not None)
        self.captcha = AACCaptcha.objects.create(id=1000,
                                                 description=temp_captcha.description,
                                                 settings=temp_captcha.settings)

    def tearDown(self):
        self.captcha.delete()

    def test_captcha_value_is_valid(self):
        captcha_data = {
            'description': str(self.captcha.description),
            'settings': json.dumps(self.captcha.settings)
        }
        captcha_form = AACCaptchaForm(captcha_data)
        captcha_form.initial['id'] = self.captcha.id
        captcha_form.initial['description'] = self.captcha.description
        self.assertTrue(captcha_form.is_valid())

        next(iter(self.captcha.settings.values()))['value'] = '123asdasd'

        captcha_data['settings'] = json.dumps(self.captcha.settings)
        captcha_form = AACCaptchaForm(captcha_data)
        captcha_form.initial['description'] = self.captcha.description
        self.assertFalse(captcha_form.is_valid())
