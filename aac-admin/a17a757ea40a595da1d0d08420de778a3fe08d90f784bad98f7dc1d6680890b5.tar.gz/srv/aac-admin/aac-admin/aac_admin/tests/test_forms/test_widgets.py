from django.test import TestCase

import pytest
pytestmark = pytest.mark.django_db

from aac_admin.forms import TranslationTextArea, ArrayFormatTextArea, ConsentsSelectMultiple, CaptchaJsonSettingsWidget


class TranslationTextAreaTestCase(TestCase):
    def test_format_value(self):
        text_area = TranslationTextArea()
        self.assertEqual(text_area.format_value(''), {})
        self.assertEqual(text_area.format_value('{"some_string": "some_string_2"}'), {'some_string': 'some_string_2'})
        self.assertEqual(text_area.format_value(123), {})


class ArrayFormatTextAreaTestCase(TestCase):
    def test_format_value(self):
        text_area = ArrayFormatTextArea()
        some_list = ('one', 'two', 'three')
        self.assertEqual(text_area.format_value(list(some_list)), 'one\r\ntwo\r\nthree')
        self.assertEqual(text_area.format_value('string'), '')


class ConsentsSelectMultipleTestCase(TestCase):
    def test_format_value(self):
        consents_area = ConsentsSelectMultiple()
        some_list = ('one', 'two', 'three')
        self.assertEqual(consents_area.format_value(list(some_list)), list(some_list))
        self.assertEqual(consents_area.format_value('{"string": "string_2"}'), {'string': 'string_2'})
        self.assertEqual(consents_area.format_value(123), {})


class CaptchaJsonSettingsWidgetTestCase(TestCase):
    def test_format_value(self):
        settings = CaptchaJsonSettingsWidget()
        self.assertEqual(settings.format_value(None), {})
        self.assertEqual(settings.format_value(''), {})
        self.assertEqual(settings.format_value(list()), list())
        self.assertEqual(settings.format_value(dict()), dict())
        self.assertEqual(settings.format_value('{"some_string": "some_string_2"}'), {'some_string': 'some_string_2'})
        self.assertEqual(settings.format_value(10), {})
