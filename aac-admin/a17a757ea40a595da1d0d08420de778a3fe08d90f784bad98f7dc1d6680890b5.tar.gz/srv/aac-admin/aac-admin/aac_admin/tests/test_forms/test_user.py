from django.test import TestCase

from aac_admin.forms import UserForm, get_afl_bonus_add


class UserTestCase(TestCase):
    def test_bonus_user_id(self):
        client_form = UserForm(data={'lk_user_id': -1, 'status': 'A'})
        self.assertEqual(client_form.is_valid(), True)

        client_form = UserForm(data={'lk_user_id': get_afl_bonus_add(), 'status': 'A'})
        self.assertEqual(client_form.is_valid(), True)

        client_form = UserForm(data={'lk_user_id': get_afl_bonus_add() - 1, 'status': 'A'})
        self.assertEqual(client_form.is_valid(), True)

        client_form = UserForm(data={'lk_user_id': get_afl_bonus_add() - 1})
        self.assertEqual(client_form.is_valid(), False)
