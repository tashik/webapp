from django.test import TestCase

from aac_admin.forms import AACSettingsForm
from aac_admin.models import AACSettings
from aac_admin.views.aac_settings import AACSettingsView

from django.contrib.auth.models import User, Permission
from django.test.client import RequestFactory
from django.urls import reverse


class AACSettingsTestCase(TestCase):
    def setUp(self):
        super(AACSettingsTestCase, self).setUp()

        self.aac_settings = AACSettings.objects.get_or_create(name='test0', value='500', descr='test_descr',
                                                              vtype='int')[0]

    def tearDown(self):
        self.aac_settings.delete()

    def test_valid_value(self):
        self.aac_settings.vtype = 'int'
        form = AACSettingsForm({'name': 'test0', 'value': '1000', 'descr': 'test_descr', 'vtype': 'int'},
                               instance=self.aac_settings)
        self.assertTrue(form.is_valid())

        self.aac_settings.vtype = 'float'
        form = AACSettingsForm({'name': 'test0', 'value': '100.05', 'descr': 'test_descr', 'vtype': 'float'},
                               instance=self.aac_settings)
        self.assertTrue(form.is_valid())

        self.aac_settings.vtype = 'bool'
        form = AACSettingsForm({'name': 'test0', 'value': 'True', 'descr': 'test_descr', 'vtype': 'bool'},
                               instance=self.aac_settings)
        self.assertTrue(form.is_valid())

        self.aac_settings.vtype = 'json'
        form = AACSettingsForm(
            {'name': 'test0', 'value': '{"foo": ["bar", "baz"]}', 'descr': 'test_descr', 'vtype': 'json'},
            instance=self.aac_settings)
        self.assertTrue(form.is_valid())

        self.aac_settings.vtype = 'url'
        form = AACSettingsForm(
            {'name': 'test0', 'value': 'http://test.com?1', 'descr': 'test_descr', 'vtype': 'url'},
            instance=self.aac_settings)
        self.assertTrue(form.is_valid())

    def test_missing_value(self):
        form = AACSettingsForm({'name': 'test0', 'value': '', 'descr': 'test_descr', 'vtype': 'int'},
                               instance=self.aac_settings)
        form.is_valid()
        errors = form['value'].errors.as_data()
        self.assertEqual(errors[0].code, 'required')

    def test_invalid_value(self):
        self.aac_settings.vtype = 'int'
        form = AACSettingsForm({'name': 'test0', 'value': 'test', 'descr': 'test_descr', 'vtype': 'int'},
                               instance=self.aac_settings)
        form.is_valid()
        self.assertIn('value', form.errors)

        self.aac_settings.vtype = 'float'
        form = AACSettingsForm({'name': 'test0', 'value': '123', 'descr': 'test_descr', 'vtype': 'float'},
                               instance=self.aac_settings)
        form.is_valid()
        self.assertIn('value', form.errors)

        self.aac_settings.vtype = 'bool'
        form = AACSettingsForm({'name': 'test0', 'value': '123', 'descr': 'test_descr', 'vtype': 'bool'},
                               instance=self.aac_settings)
        form.is_valid()
        self.assertIn('value', form.errors)

        self.aac_settings.vtype = 'json'
        form = AACSettingsForm({'name': 'test0', 'value': '{test : test}', 'descr': 'test_descr', 'vtype': 'json'},
                               instance=self.aac_settings)
        form.is_valid()
        self.assertIn('value', form.errors)

        self.aac_settings.vtype = 'url'
        form = AACSettingsForm({'name': 'test0', 'value': '123', 'descr': 'test_descr', 'vtype': 'url'},
                               instance=self.aac_settings)
        form.is_valid()
        self.assertIn('value', form.errors)


class AACSettingsViewTestCase(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='setting_test_user', password='top_secret')
        view_settings = Permission.objects.get(codename='view_aac_setting')
        self.user.user_permissions.add(view_settings)
        change_settings = Permission.objects.get(codename='change_aac_setting')
        self.user.user_permissions.add(change_settings)

        self.aac_settings = AACSettings.objects.get_or_create(name='test0', value='500', descr='test_descr',
                                                              vtype='int')[0]

    def tearDown(self):
        self.factory = None
        self.user.delete()
        self.aac_settings.delete()

    def test_get(self):
        request = self.factory.get(reverse('aac_settings'))
        request.user = self.user
        response = AACSettingsView.as_view()(request)
        self.assertEqual(response.status_code, 200)

    def test_post(self):
        data = {'form-TOTAL_FORMS': 1,
                'form-INITIAL_FORMS': 1,
                'form-0-name': 'test0',
                'form-0-value': '500',
                'form-0-descr': 'test_descr',
                'form-0-vtype': 'int'}
        request = self.factory.post(reverse('aac_settings'), data)
        request.user = self.user
        response = AACSettingsView.as_view()(request)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse('aac_settings'))

    def test_post_invalid_value(self):
        data = {'form-TOTAL_FORMS': 1,
                'form-INITIAL_FORMS': 1,
                'form-0-name': 'test0',
                'form-0-value': 'asd',
                'form-0-descr': 'test_descr',
                'form-0-vtype': 'int'}
        request = self.factory.post(reverse('aac_settings'), data)
        request.user = self.user
        response = AACSettingsView.as_view()(request)
        self.assertEqual(response.status_code, 200)
        self.assertTrue(len(response.context_data.get('formset').errors) > 0)
