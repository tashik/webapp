import json

from django.contrib.auth.models import User, Permission
from django.test import TestCase, RequestFactory
from unittest.mock import patch

from django.urls import reverse

from aac_admin.models import AACCaptcha

from aac_admin.views import aac_captcha as aac_captcha_view


class GetCaptchaTest(TestCase):
    def setUp(self):
        temp_captcha = AACCaptcha.objects.get(id=1)
        for i in temp_captcha.settings.values():
            i['value'] = str(i['value'])
        self.assertTrue(temp_captcha.settings is not None)
        self.captcha = AACCaptcha.objects.create(id=100,
                                                 description=temp_captcha.description,
                                                 settings=temp_captcha.settings)

    def tearDown(self):
        self.captcha.delete()

    def test_captcha_description_is_a_dictionary(self):
        self.assertTrue(isinstance(self.captcha.description, dict))
        self.assertTrue(self.captcha.description.get('ru', '') is not '')

    def test_captcha_settings_is_a_valid_dictionary(self):
        self.assertTrue(isinstance(self.captcha.settings, dict))
        for i in self.captcha.settings.values():
            self.assertTrue('value' in i.keys() and 'type' in i.keys() and 'description' in i.keys())


class CaptchaViewTest(TestCase):
    def setUp(self):
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user_without_permissions = User.objects.create_user(username='bad_user', password='qwerty')
        self.user.user_permissions.add(Permission.objects.get(codename='view_aac_setting'))
        log_patcher = patch.object(aac_captcha_view, 'logger')
        self.addCleanup(log_patcher.stop)
        self.logger_mock = log_patcher.start()

    def tearDown(self):
        self.factory = None
        self.user.delete()
        self.user_without_permissions.delete()

    def test_captcha_view_get_queryset(self):
        view = aac_captcha_view.AACCaptchaView()
        captcha_queryset = list(view.get_queryset())
        comparable_id = captcha_queryset[0].id
        for captcha in captcha_queryset:
            if captcha.id == comparable_id:
                continue
            self.assertTrue(captcha.id > comparable_id)
            comparable_id = captcha.id

    def test_captcha_view_get(self):
        request = self.factory.get(reverse('aac_captcha'))
        request.user = self.user_without_permissions
        response = aac_captcha_view.AACCaptchaView.as_view()(request)
        self.assertEqual(response.status_code, 302)
        request = self.factory.get(reverse('aac_captcha'))
        request.user = self.user
        response = aac_captcha_view.AACCaptchaView.as_view()(request)
        self.assertEqual(response.status_code, 200)

    def test_captcha_view_context_data(self):
        request = self.factory.get(reverse('aac_captcha'))
        view = aac_captcha_view.AACCaptchaView()
        view.request = request
        view.object_list = view.get_queryset()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), 'CAPTCHA')


class CaptchaSettingsViewTest(TestCase):
    def setUp(self):
        self.captcha_test = AACCaptcha.objects.create(id=100,
                                                      description={'ru': 'test_description'},
                                                      settings={'test_settings': 'test_settings'})
        self.factory = RequestFactory()
        self.user = User.objects.create_user(username='testing_user', password='top_secret')
        self.user_without_permissions = User.objects.create_user(username='bad_user', password='qwerty')
        self.user.user_permissions.add(Permission.objects.get(codename='view_aac_setting'))
        self.user.user_permissions.add(Permission.objects.get(codename='change_aac_setting'))

    def tearDown(self):
        self.captcha_test.delete()
        self.factory = None
        self.user.delete()
        self.user_without_permissions.delete()

    def test_captcha_settings_view_get(self):
        request = self.factory.get(reverse('aac_captcha_settings', kwargs={'pk': self.captcha_test.pk}))
        request.user = self.user_without_permissions
        response = aac_captcha_view.AACCaptchaSettingsView.as_view()(request, pk=self.captcha_test.pk)
        self.assertEqual(response.status_code, 302)
        request = self.factory.get(reverse('aac_captcha_settings', kwargs={'pk': self.captcha_test.pk}))
        request.user = self.user
        response = aac_captcha_view.AACCaptchaSettingsView.as_view()(request, pk=self.captcha_test.pk)
        self.assertEqual(response.status_code, 200)

    def test_captcha_settings_view_context_data(self):
        request = self.factory.get(reverse('aac_captcha_settings', kwargs={'pk': self.captcha_test.pk}))
        view = aac_captcha_view.AACCaptchaView()
        view.request = request
        view.object_list = view.get_queryset()
        context = view.get_context_data()
        self.assertEqual(context.get('title'), 'CAPTCHA')

    def test_captcha_settings_view_post(self):
        captcha_changed_data = {'settings': json.dumps(
            {"test_setting_1": {"type": "int", "value": "300", "description": "test"},
             "test_setting_2": {"type": "int", "value": "3", "description": "test_2"}}
        )}

        request = self.factory.post(reverse('aac_captcha_settings', kwargs={'pk': self.captcha_test.pk}),
                                    data=captcha_changed_data)
        request.user = self.user_without_permissions
        response = aac_captcha_view.AACCaptchaSettingsView.as_view()(request, pk=self.captcha_test.pk)
        self.assertEqual(response.status_code, 302)
        self.assertIn('/admin/login/', response.url)

        request = self.factory.post(reverse('aac_captcha_settings', kwargs={'pk': self.captcha_test.pk}),
                                    data=captcha_changed_data)
        request.user = self.user
        response = aac_captcha_view.AACCaptchaSettingsView.as_view()(request, pk=self.captcha_test.pk)
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, '/admin/captcha/')

        captcha_updated = AACCaptcha.objects.get(id=self.captcha_test.id)
        self.captcha_test = captcha_updated
        self.assertEqual(self.captcha_test.settings, json.loads(captcha_changed_data.get('settings')))
