import logging

from celery import shared_task

from aac_admin.utils.redis import delete_all_client_sessions_for_users


admin_logger = logging.getLogger('aac_admin')
admin_actions_logger = logging.getLogger('aac_admin_actions')


@shared_task
def delete_sessions(client_pk, client_id, admin, action):
    for sid, jti, aeroflot_id in delete_all_client_sessions_for_users(client_id):
        admin_actions_logger.info(f"aac_admin={admin} aeroflot_id={aeroflot_id} action='удаление сессии' "
                                  f"client_id={client_id} sid={sid} jti={jti} description='{action}'")
    admin_logger.info(f"удалены сессии пользователей Client({{'id': {client_pk}, 'client_id': {client_id}}})")
