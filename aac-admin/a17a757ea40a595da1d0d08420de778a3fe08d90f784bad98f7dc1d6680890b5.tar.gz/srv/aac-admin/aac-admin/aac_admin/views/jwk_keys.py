import logging

from Cryptodome.PublicKey import RSA
from django.contrib.auth.decorators import permission_required
from django.http import Http404, HttpResponseRedirect, HttpResponse, HttpResponseForbidden
from django.shortcuts import redirect, render
from django.urls import reverse_lazy, reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.generic import ListView, DeleteView
from django.views.generic.detail import SingleObjectMixin

from aac_admin.models import JwkKey
from aac_admin.views import EmptyTitleContextMixin

RSA_KEY_SIZE = 2048
logger = logging.getLogger('aac_admin_actions')
actions = {'added': 'JWK key added',
           'deleted': 'JWK key deleted',
           'activated': 'JWK key activated',
           'deactivated': 'JWK key deactivated'}


class JwkKeysView(ListView):
    model = JwkKey
    template_name = 'views/jwk_keys/jwk_keys_view.html'
    context_object_name = 'keys'

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'Jwk ключи'
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_setting'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


@permission_required('aac_admin.add_aac_setting')
def jwk_key_add_view(request, *args, **kwargs):
    key = RSA.generate(RSA_KEY_SIZE)
    private = key.exportKey('PEM').decode()
    public = key.publickey().exportKey('PEM').decode()
    jwk_key = JwkKey.objects.create(public=public, private=private)
    logger.info(f'action={actions.get("added")} jwk_pk={jwk_key.pk} jwk_kid={jwk_key.kid} '
                f'aac_admin={request.user.username} user_id={request.user.id}')
    return redirect(reverse('jwk_keys'))


class JwkKeyUpdateView(SingleObjectMixin, View):
    model = JwkKey

    def get(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return HttpResponse(status=401)
        if not request.user.has_perm('aac_admin.change_aac_setting'):
            return HttpResponseForbidden()
        jwk_key = self.get_object()
        if jwk_key.is_active is True and not JwkKey.active_remains(jwk_key.id):
            return HttpResponse('Ошибка: необходимо, чтобы был как минимум 1 активный ключ.', status=400)
        jwk_key.is_active = not jwk_key.is_active
        jwk_key.save()
        status_action = 'activated' if jwk_key.is_active else 'deactivated'
        logger.info(
            f'action={actions.get(status_action)} jwk_pk={jwk_key.pk} jwk_kid={jwk_key.kid} '
            f'aac_admin={request.user.username} user_id={request.user.id}')
        return HttpResponse()


class JwkKeyDeleteView(EmptyTitleContextMixin, DeleteView):
    model = JwkKey
    template_name = 'views/delete_object_view.html'
    success_url = reverse_lazy('jwk_keys')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['errors'] = None
        context['object_to_delete'] = self.object.get_verbose_name() \
            if hasattr(self.object, 'get_verbose_name') else self.object
        context['cancel_href'] = self.success_url
        context['return_url'] = None
        return context

    @method_decorator(permission_required('aac_admin.delete_aac_setting'))
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Http404:
            return HttpResponseRedirect(self.success_url)

    @method_decorator(permission_required('aac_admin.delete_aac_setting'))
    def delete(self, request, *args, **kwargs):
        self.object = self.get_object()
        kid = self.object.kid
        if not JwkKey.active_remains(self.object.id):
            context = self.get_context_data(**kwargs)
            context['errors'] = [{'label': 'Удаление невозможно',
                                  'errors': ['Необходимо, чтобы был как минимум 1 активный ключ']}]
            return render(request, 'views/delete_object_view.html', context)
        response = super().delete(request, *args, **kwargs)
        logger.info(f'action={actions.get("deleted")} jwk_pk={kwargs.get("pk")} jwk_kid={kid} '
                    f'aac_admin={request.user.username} user_id={request.user.id}')
        return response
