import logging

from django.contrib.auth.decorators import permission_required
from django.db.models.expressions import RawSQL, OrderBy
from django.http import Http404, HttpResponseRedirect
from django.views import generic
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.utils.translation import get_language


from aac_admin.api.v1.client_logo_saver import ClientLogoSaver
from aac_admin.tasks import delete_sessions
from aac_admin.views import LangsCodesContextMixin, EmptyTitleContextMixin, EmptyObjectContextMixin
from aac_admin.models import Client
from aac_admin.forms import ClientForm


logger = logging.getLogger('aac_admin_actions')


class ClientsView(LangsCodesContextMixin, generic.ListView):
    model = Client
    template_name = 'views/client/clients_view.html'

    def get_queryset(self):
        return Client.objects.all().order_by(OrderBy(RawSQL('LOWER(name->>%s)', [get_language()])))

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'Приложения-клиенты'
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_client'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


class ClientLogMixin(object):
    def prepare_request_data_to_log(self, data_dict):
        data_dict['client_secret'] = "********"


class ClientAddView(EmptyObjectContextMixin, EmptyTitleContextMixin, generic.CreateView, ClientLogMixin):
    form_class = ClientForm
    template_name = 'views/client/client_detail.html'
    success_url = reverse_lazy('clients')

    @method_decorator(permission_required('aac_admin.view_aac_client'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.add_aac_client'))
    def post(self, request, *args, **kwargs):
        self.object = None
        form = self.get_form()
        if not form.is_valid():
            return self.form_invalid(form)
        logo_image = form.cleaned_data.get('logo_image')
        if not logo_image:
            form.add_error('logo_image', 'Выберите файл для изображения.')
            return self.form_invalid(form)
        response = self.form_valid(form)
        success, data = ClientLogoSaver.save_logo_image(logo_image, self.object.client_id)
        if not success:
            self.object.delete()
            form.add_error('logo_image', data)
            return self.form_invalid(form)
        self.object.logo_uri = data
        self.object.save()
        request_data = request.POST.copy()
        self.prepare_request_data_to_log(request_data)
        logger.info(f"создание Client({{'pk': '{self.object.id}'}}) "
                    f"пользователем {request.user.username}: {request_data}")
        logger.info(f"создание logo_image Client({{'pk': '{self.object.id}'}})"
                    f" пользователем {request.user.username}: {data}")
        return response


class ClientUpdateView(EmptyTitleContextMixin, generic.UpdateView, ClientLogMixin):
    model = Client
    form_class = ClientForm
    template_name = 'views/client/client_detail.html'
    success_url = reverse_lazy('clients')

    @method_decorator(permission_required('aac_admin.view_aac_client'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.change_aac_client'))
    def post(self, request, *args, **kwargs):
        request_data = request.POST.copy()
        self.prepare_request_data_to_log(request_data)
        logger.info(f'изменение Client({kwargs}) пользователем {request.user.username}: {request_data}')
        old_status = self.get_object().status
        response = super().post(request, *args, **kwargs)
        form = self.get_form()
        if not form.is_valid():
            return response
        if old_status != self.object.status and self.object.status == 'B':
            delete_sessions.delay(self.object.id, self.object.client_id, request.user.username, 'клиент заблокирован')
        logo_image = form.cleaned_data.get('logo_image')
        if logo_image:
            if self.object.logo_uri:
                success, data = ClientLogoSaver.delete_logo_image(self.object.logo_uri)
                if success:
                    logger.info(data)
                else:
                    logger.error(data)
            success, data = ClientLogoSaver.save_logo_image(logo_image, self.object.client_id)
            if not success:
                form.add_error('logo_image', data)
                return self.form_invalid(form)
            self.object.logo_uri = data
            self.object.save()
            logger.info(f'изменение logo_image Client({kwargs}) пользователем {request.user.username}: {data}')
        elif not self.object.logo_uri:
            form.add_error('logo_image', 'Выберите файл для изображения.')
            return self.form_invalid(form)
        return response


class ClientDeleteView(EmptyTitleContextMixin, generic.DeleteView):
    model = Client
    template_name = 'views/delete_object_view.html'
    success_url = reverse_lazy('clients')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['errors'] = None
        context['object_to_delete'] = self.object.get_verbose_name() \
            if hasattr(self.object, 'get_verbose_name') else self.object
        context['cancel_href'] = self.success_url
        context['return_url'] = None
        return context

    @method_decorator(permission_required('aac_admin.delete_aac_client'))
    def get(self, request, *args, **kwargs):
        try:
            return super().get(request, *args, **kwargs)
        except Http404:
            return HttpResponseRedirect(self.success_url)

    @method_decorator(permission_required('aac_admin.delete_aac_client'))
    def delete(self, request, *args, **kwargs):
        logger.info(f'удаление Client({kwargs}) пользователем {request.user.username}')
        self.object = self.get_object()
        delete_sessions.delay(self.object.id, self.object.client_id, request.user.username, 'клиент удалён')
        if self.object.logo_uri:
            success, data = ClientLogoSaver.delete_logo_image(self.object.logo_uri)
            logger.info(data) if success else logger.error(data)
        return super().delete(request, *args, **kwargs)
