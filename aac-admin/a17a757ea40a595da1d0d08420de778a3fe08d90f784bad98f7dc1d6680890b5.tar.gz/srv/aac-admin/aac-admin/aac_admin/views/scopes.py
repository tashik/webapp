import logging

from django.contrib.auth.decorators import permission_required
from django.views import generic
from django.utils.decorators import method_decorator

from aac_admin.views import LangsCodesContextMixin
from aac_admin.models import Scope


logger = logging.getLogger('aac_admin_actions')


class ScopesView(LangsCodesContextMixin, generic.ListView):
    model = Scope
    template_name = 'views/scope/scopes_view.html'

    def get_queryset(self):
        return Scope.objects.all()

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'Скоупы'
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_scope'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)
