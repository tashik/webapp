import logging

from django.contrib.auth.decorators import permission_required
from django.http import HttpResponseForbidden, HttpResponse, JsonResponse
from django.shortcuts import render
from django.views import generic
from django.urls import reverse_lazy, reverse
from django.utils.decorators import method_decorator

from aac_admin.api.v1.users_json_service import get_users_list_dict, InvalidParamsException
from aac_admin.utils.redis import delete_sessions_by_aeroflot_id, TokenList, delete_user_tokens_by_client_ids
from aac_admin.views import EmptyTitleContextMixin, EmptyObjectContextMixin
from aac_admin.models import User, UserStatus, Client
from aac_admin.forms import UserForm
from main.settings import INFINITE_SCROLL_ITEMS_COUNT

logger = logging.getLogger('aac_admin_actions')


@permission_required('aac_admin.view_aac_user')
def users_view(request):
    context_data = {'title': 'Пользователи'}
    return render(request, 'views/user/users_view.html', context_data)


class UserAddView(EmptyObjectContextMixin, EmptyTitleContextMixin, generic.CreateView):
    form_class = UserForm
    template_name = 'views/user/user_detail.html'
    success_url = reverse_lazy('users')

    @method_decorator(permission_required('aac_admin.view_aac_user'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.add_aac_user'))
    def post(self, request, *args, **kwargs):
        logger.info(f'создание User({kwargs}) пользователем {request.user.username}')
        return super().post(request, *args, **kwargs)


def user_tokens(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.has_perm('aac_admin.view_aac_user'):
        return HttpResponseForbidden()
    aeroflot_id = request.GET.get('aeroflot_id')
    user_id = request.GET.get('user_id')
    if not aeroflot_id or not user_id:
        return HttpResponse('Ошибка: отсутствуют нобходимые параметры в запросе.', status=400)
    tokens = TokenList.get_tokens_by_aeroflot_id(aeroflot_id)
    for token in tokens:
        params = dict(session_id=token['session_id'], aeroflot_id=token['aeroflot_id'], jti=token['jti'])
        token['url'] = f"{reverse('token_delete', kwargs=params)}?return_url={reverse('user_update', args=(user_id,))}"
    return JsonResponse({'tokens': tokens})


class UserUpdateView(EmptyTitleContextMixin, generic.UpdateView):
    model = User
    form_class = UserForm
    template_name = 'views/user/user_detail.html'

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'Пользователи'
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_user'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.change_aac_user'))
    def post(self, request, *args, **kwargs):
        admin_username = request.user.username
        aeroflot_id = self.get_object().aeroflot_id
        logger.info(f"изменение User({{'aeroflot_id': '{aeroflot_id}'}}) пользователем {admin_username}")
        old_status = self.get_object().status
        old_consents = self.get_object().consents
        response = super().post(request, *args, **kwargs)
        new_status = self.object.status
        new_consents = self.object.consents
        if old_status != new_status:
            logger.info(f'action="Изменение статуса" from={old_status} to={new_status} '
                        f'aac_admin={admin_username} aeroflot_id={aeroflot_id}')
            if new_status == UserStatus.Blocked.value:
                for sid, jti in delete_sessions_by_aeroflot_id(aeroflot_id):
                    logger.info(f"aac_admin={admin_username} aeroflot_id={aeroflot_id} action='удаление сессии' "
                                f"sid={sid} jti={jti} description='пользователь заблокирован'")
        if old_consents != new_consents:
            logger.info(f'action="Изменение согласий" from={old_consents} to={new_consents} '
                        f'aac_admin={admin_username} aeroflot_id={aeroflot_id}')
            client_pks = set(c['id'] for c in old_consents) - set(c['id'] for c in new_consents)
            client_ids = Client.objects.filter(id__in=client_pks).values_list('client_id', flat=True)
            for sid, jti, client_id in delete_user_tokens_by_client_ids(aeroflot_id, client_ids):
                logger.info(f"aac_admin={admin_username} aeroflot_id={aeroflot_id} action='удаление сессии' "
                            f"client_id={client_id} sid={sid} jti={jti} description='согласие отозвано'")
        return response

    def get_success_url(self):
        user = self.object
        return reverse_lazy('user_update', kwargs={'pk': user.id})


class UserDeleteView(EmptyTitleContextMixin, generic.DeleteView):
    model = User
    template_name = 'views/delete_object_view.html'
    success_url = reverse_lazy('users')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['errors'] = None
        context['object_to_delete'] = self.object.get_verbose_name() if \
            self.object and hasattr(self.object, 'get_verbose_name') else self.object
        context['cancel_href'] = self.success_url
        context['return_url'] = None
        return context

    @method_decorator(permission_required('aac_admin.delete_aac_user'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.delete_aac_user'))
    def delete(self, request, *args, **kwargs):
        aeroflot_id = self.get_object().aeroflot_id
        logger.info(f"удаление User({{'aeroflot_id': '{aeroflot_id}'}}) пользователем {request.user.username}")
        for sid, jti in delete_sessions_by_aeroflot_id(aeroflot_id):
            logger.info(f"aac_admin={request.user.username} aeroflot_id={aeroflot_id} action='удаление сессии' "
                        f"sid={sid} jti={jti} description='пользователь удалён'")
        return super().delete(request, *args, **kwargs)


def user_list_html(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.has_perm('aac_admin.view_aac_user'):
        return HttpResponseForbidden()
    items_count = INFINITE_SCROLL_ITEMS_COUNT
    try:
        offset = int(request.GET.get('offset', 0))
    except ValueError:
        offset = 0
    aeroflot_id = request.GET.get('aeroflot_id', '')
    lk_user_id = request.GET.get('lk_user_id', '')
    try:
        users = get_users_list_dict(aeroflot_id, lk_user_id, str(items_count), str(offset)).get('client_models', [])
    except InvalidParamsException:
        users = []
    offset += items_count
    users_url = reverse('user_list_html')
    next_page = f'{users_url}?aeroflot_id={aeroflot_id}&lk_user_id={lk_user_id}&offset={offset}'
    response = {
        'user_list': users,
        'next_page': next_page if len(users) == items_count else None,
    }
    return render(request, 'views/user/users_html.html', context=response)
