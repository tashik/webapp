# -*- coding: utf-8 -*-
import logging

from django.shortcuts import render, redirect
from django.conf import settings
from django.urls import reverse
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from django.utils.http import urlencode
from django.views.generic import TemplateView

from aac_admin.utils import get_language_codes
from aac_admin.utils import exc


@login_required
def root_view(request):
    return render(request, 'root_page.html', context={'title': 'Администрирование ЕЦА'})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('home')

    aac_login_url = reverse('social:begin', args=['aac'])
    params = request.GET.urlencode()
    url = f'{aac_login_url}?{params}' if params else aac_login_url
    return redirect(url)


def logout_view(request):
    if request.user.is_anonymous:
        return redirect('home')

    social_auth = getattr(request.user, 'social_auth', None)
    logout(request)

    social_auth_query_set = social_auth.all()
    if not social_auth_query_set:
        return redirect(reverse('home'))

    social_auth = social_auth_query_set[0]
    logout_params = {
        'post_logout_redirect_uri': request.build_absolute_uri(reverse('logout_callback')),
        'id_token_hint': social_auth.extra_data.get('id_token', '')
    }

    return redirect('%s?%s' % (settings.AAC_ENDSESSION_URL, urlencode(logout_params)))


def logout_callback_view(request):
    return redirect(reverse('home'))


class LangsCodesContextMixin(object):
    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['langs'] = get_language_codes()
        return context_data


class EmptyTitleContextMixin(object):
    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = ''
        return context_data


class EmptyObjectContextMixin(object):
    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['object'] = None
        return context_data


class ErrorView(TemplateView):
    template_name = 'views/error_view.html'

    def get(self, request, *args, **kwargs):
        context = self.get_context_data(**kwargs)
        return self.render_to_response(context, status=400)

    def get_context_data(self, **kwargs):
        return self.get_error_context(self.request.GET.get('error_code', None))

    def get_error_context(self, error_code):
        error = self.get_error_by_code(error_code)
        logger = logging.getLogger('aac_admin_errors')
        logger.error(error)

        return {
            'title': 'Ошибка',
            'error_code': error.code,
            'message': error.msg,
        }

    def get_error_by_code(self, error_code):
        for enum_item in exc.AvailableExceptions:
            if enum_item.value.code == error_code:
                return enum_item.value

        return exc.AvailableExceptions.UnknownError.value
