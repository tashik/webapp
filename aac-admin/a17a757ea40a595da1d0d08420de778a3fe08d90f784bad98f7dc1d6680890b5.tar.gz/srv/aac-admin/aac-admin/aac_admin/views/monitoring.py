import os

from django.views.generic.base import View
from django.http import JsonResponse, HttpResponse

from aac_admin.templatetags.common_tags import get_app_revision


class StatusView(View):
    def get(self, request, *args, **kwargs):
        data = dict()
        data['version'] = get_app_revision()
        return JsonResponse(data, charset='UTF-8', content_type='application/json', json_dumps_params={'indent': 4})


class PingView(View):
    def get(self, request, *args, **kwargs):
        return HttpResponse('PONG')
