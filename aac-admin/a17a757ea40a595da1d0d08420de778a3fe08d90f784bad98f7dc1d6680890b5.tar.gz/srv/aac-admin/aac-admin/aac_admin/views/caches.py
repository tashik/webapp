import logging

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import permission_required
from django.shortcuts import render, redirect
from django.views import View
from django.utils.decorators import method_decorator
import requests
from requests.exceptions import RequestException


logger = logging.getLogger('aac_admin_actions')


class CachesView(View):
    @property
    def caches(self):
        return getattr(settings, 'AAC_CACHE_PURGE', {})

    @method_decorator(permission_required('aac_admin.view_aac_cache'))
    def get(self, request, *args, **kwargs):
        context = {
            'errors': None,
            'title': '',
            'caches': self.caches
        }

        return render(request, 'views/caches_view.html', context)

    @method_decorator(permission_required('aac_admin.change_aac_cache'))
    def post(self, request, *args, **kwargs):
        caches = self.caches
        if not caches:
            return redirect('caches')

        clear_cache = request.POST.get('clear_cache')
        cache_data = caches.get(clear_cache)
        if not cache_data:
            return redirect('caches')

        _messages = []
        for url in cache_data.get('urls'):
            try:
                result = requests.request('PURGE', url, headers=cache_data.get('headers', {}))
                logger.info(f'очистка cache={clear_cache}, url={url}, result={result}, '
                            f'пользователем={request.user.username}')

                if result.status_code != 200:
                    _messages.append((messages.ERROR, f'Произошла ошибка при очистке cache: {clear_cache}, url: {url}'))

            except RequestException as e:
                _messages.append((messages.ERROR, f'Произошла ошибка при очистке cache: {clear_cache}, url: {url}'))
                logger.exception(e)

        if not _messages:
            messages.add_message(request, messages.SUCCESS, f'Успешная очистка для cache: {clear_cache}')

        for msg_data in _messages:
            messages.add_message(request, msg_data[0], msg_data[1])

        return redirect('caches')
