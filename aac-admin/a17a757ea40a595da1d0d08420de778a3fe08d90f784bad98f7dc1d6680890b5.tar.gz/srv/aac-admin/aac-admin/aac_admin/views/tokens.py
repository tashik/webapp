import logging

from django.contrib.auth.decorators import permission_required
from django.http import HttpResponseForbidden, HttpResponse
from django.shortcuts import render, redirect
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.views import View
from django.conf import settings

from aac_admin.utils.redis import REDIS_CLIENT, TokenList


logger = logging.getLogger('aac_admin_actions')


@permission_required('aac_admin.view_aac_token')
def tokens_view(request):
    return render(request, 'views/token/tokens_view.html', {'title': 'Токены'})


def token_list_html(request):
    if not request.user.is_authenticated:
        return HttpResponse(status=401)
    if not request.user.has_perm('aac_admin.view_aac_token'):
        return HttpResponseForbidden()
    items_count = settings.INFINITE_SCROLL_ITEMS_COUNT
    try:
        cursor = int(request.GET.get('cursor', 0))
    except ValueError:
        cursor = 0
    next_cursor, tokens = TokenList.new_token_list(cursor, items_count, request.GET.dict())
    new_parameters = request.GET.copy()
    new_parameters['cursor'] = next_cursor
    response = {
        'token_list': tokens,
        'next_page': f'{reverse("token_list_html")}?{new_parameters.urlencode()}' if next_cursor else None,
    }
    return render(request, 'views/token/tokens_html.html', context=response)


class TokenDeleteView(View):
    @method_decorator(permission_required('aac_admin.delete_aac_token'))
    def get(self, request, *args, session_id, **kwargs):
        return_url = request.GET.get('return_url')
        context = {
            'errors': None,
            'title': '',
            'object_to_delete': session_id,
            'cancel_href': return_url if return_url else reverse('tokens'),
            'return_url': return_url
        }
        return render(request, 'views/delete_object_view.html', context)

    @method_decorator(permission_required('aac_admin.delete_aac_token'))
    def post(self, request, *args, session_id, jti, aeroflot_id):
        REDIS_CLIENT.pipeline().delete(session_id).zrem(aeroflot_id, session_id).delete(jti).execute()
        logger.info(f'action = "delete token" oic_sid = {session_id} aac_admin = {request.user.username} '
                    f'aeroflot_id = {aeroflot_id}')
        if request.GET.get('return_url'):
            return redirect(request.GET.get('return_url'))
        return redirect('tokens')
