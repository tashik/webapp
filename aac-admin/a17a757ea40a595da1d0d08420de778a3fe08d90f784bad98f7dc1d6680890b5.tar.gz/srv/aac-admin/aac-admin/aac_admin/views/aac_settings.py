import logging
import json

from django.contrib.auth.decorators import permission_required
from django.shortcuts import redirect
from django.utils.decorators import method_decorator
from django.views.generic.base import TemplateView

from aac_admin.forms import AACSettingFormset
from aac_admin.models import AACSettings


logger = logging.getLogger('aac_admin_actions')


class AACSettingsView(TemplateView):
    template_name = 'views/aac_settings_view.html'
    formset = None

    @method_decorator(permission_required('aac_admin.view_aac_setting'))
    def get(self, request, *args, **kwargs):
        self.formset = AACSettingFormset()
        return super(AACSettingsView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context_data = super(AACSettingsView, self).get_context_data(**kwargs)
        context_data['title'] = 'Настройки'
        context_data['formset'] = self.formset
        return context_data

    @method_decorator(permission_required('aac_admin.change_aac_setting'))
    def post(self, request, *args, **kwargs):
        self.formset = AACSettingFormset(request.POST)
        if self.formset.is_valid():
            old_settings = [(setting.name, setting.value, setting.vtype, setting.descr)
                            for setting in AACSettings.objects.all()]
            logger.info(f'изменение Settings пользователем {request.user.username}: {request.POST.copy()}.'
                        f' до изменения: {json.dumps(old_settings, ensure_ascii=False)}')
            self.formset.save()
            return redirect('aac_settings')
        else:
            for error in self.formset.errors:
                if error.get('value'):
                    logger.error(error.get('value')[0])
            return super(AACSettingsView, self).get(request, *args, **kwargs)
