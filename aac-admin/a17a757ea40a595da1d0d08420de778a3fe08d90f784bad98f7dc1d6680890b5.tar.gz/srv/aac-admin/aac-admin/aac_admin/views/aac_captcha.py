import logging
import json
from django.contrib.auth.decorators import permission_required
from django.urls import reverse_lazy
from django.views import generic
from django.utils.decorators import method_decorator

from aac_admin.forms import AACCaptchaForm
from aac_admin.models import AACCaptcha

from aac_admin.views import LangsCodesContextMixin

logger = logging.getLogger('aac_admin_actions')


class AACCaptchaView(LangsCodesContextMixin, generic.ListView):
    model = AACCaptcha
    template_name = 'views/captcha/aac_captcha_view.html'

    def get_queryset(self):
        return AACCaptcha.objects.all().order_by('id')

    @method_decorator(permission_required('aac_admin.view_aac_setting'))
    def get(self, request, *args, **kwargs):
        return super(AACCaptchaView, self).get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'CAPTCHA'
        return context_data


class AACCaptchaSettingsView(generic.UpdateView):
    model = AACCaptcha
    form_class = AACCaptchaForm
    template_name = 'views/captcha/aac_captcha_settings_view.html'
    success_url = reverse_lazy('aac_captcha')

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'CAPTCHA'
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_setting'))
    def get(self, request, *args, **kwargs):
        return super(AACCaptchaSettingsView, self).get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.change_aac_setting'))
    def post(self, request, *args, **kwargs):
        old_params = AACCaptcha.objects.get(id=int(kwargs.get('pk')))
        data = dict(request.POST)
        data['id'] = old_params.id
        data['description'] = old_params.description
        if 'settings' in data:
            data['settings'] = data['settings'][0]  # Settings json in converted to list after 'dict(request.POST)'.
        form = AACCaptchaForm(data=data,
                              initial={'settings': old_params.settings,
                                       'description': old_params.description})
        if form.is_valid() and form.has_changed():
            logger.info(f'изменение Captcha({kwargs}) пользователем {request.user.username}: {request.POST.copy()}. '
                        f'до изменения: {json.dumps(old_params.settings, ensure_ascii=False)}')
        return super().post(request, *args, **kwargs)
