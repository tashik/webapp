# -*- coding: utf-8 -*-

import logging

from django.contrib.auth.decorators import permission_required
from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.views import generic

from aac_admin.forms import SocialForm
from aac_admin.models import Social
from aac_admin.views import LangsCodesContextMixin, EmptyTitleContextMixin
from aac_admin.views.clients import ClientLogMixin

logger = logging.getLogger('aac_admin_actions')


class SocialsView(LangsCodesContextMixin, generic.ListView):
    model = Social
    template_name = 'views/social/socials_view.html'

    def get_queryset(self):
        return Social.objects.all()

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        context_data['title'] = 'Социальные сети'
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_social'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)


class SocialUpdateView(EmptyTitleContextMixin, generic.UpdateView, ClientLogMixin):
    model = Social
    form_class = SocialForm
    template_name = 'views/social/social_detail.html'
    success_url = reverse_lazy('socials')

    def get_context_data(self, **kwargs):
        context_data = super().get_context_data(**kwargs)
        if self.object:
            context_data['title'] = self.object.get_name().upper()
        return context_data

    @method_decorator(permission_required('aac_admin.view_aac_social'))
    def get(self, request, *args, **kwargs):
        return super().get(request, *args, **kwargs)

    @method_decorator(permission_required('aac_admin.change_aac_social'))
    def post(self, request, *args, **kwargs):
        response = super().post(request, *args, **kwargs)
        data = dict(request.POST)
        data.setdefault('enabled', ['off'])
        logger.info(f'изменение Social({kwargs}) пользователем {request.user.username}: {data}')
        return response
