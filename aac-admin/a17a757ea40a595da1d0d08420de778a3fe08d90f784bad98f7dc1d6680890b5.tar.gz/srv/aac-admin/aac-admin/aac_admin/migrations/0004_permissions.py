# -*- coding: utf-8 -*-

from __future__ import unicode_literals

from django.db import migrations

MODELS_DATA = ('aac_cache',)
GROUPDS_DATA = {
    'aac_cache': (u'просмотр раздела Caches', u'изменение данных в разделе Caches')
}

APP_LABEL = 'aac_admin'
PERMISSIONS_DATA = (('view_%s', 'Can view %s'), ('add_%s', 'Can add %s'), ('change_%s', 'Can change %s'),
                    ('delete_%s', 'Can delete %s'))


def aac_admin_permission(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    Permission = apps.get_model('auth', 'Permission')
    ContentType = apps.get_model('contenttypes', 'ContentType')

    for model_name in MODELS_DATA:
        content_type = ContentType(model=model_name, app_label=APP_LABEL)
        content_type.save()

        permissions = []
        for codename_tmpl, name_tmpl in PERMISSIONS_DATA:
            permissions.append(Permission(name=name_tmpl % model_name, content_type=content_type,
                                          codename=codename_tmpl % model_name))
        Permission.objects.bulk_create(permissions)

        view_group, edit_group = GROUPDS_DATA[model_name]
        groups = Group.objects.bulk_create([
            Group(name=view_group),
            Group(name=edit_group),
        ])
        groups[0].permissions.set([permissions[0]])
        groups[0].save()

        groups[1].permissions.set(permissions)
        groups[1].save()


def reverse_aac_admin_permission(apps, schema_editor):
    Group = apps.get_model('auth', 'Group')
    Group.objects.filter(
        name__in=[item for data in GROUPDS_DATA for item in data]
    ).delete()

    Permission = apps.get_model('auth', 'Permission')
    Permission.objects.filter(
        codename__in=[permision_data[0] % model_name
                      for model_name in MODELS_DATA for permision_data in PERMISSIONS_DATA]
    ).delete()

    ContentType = apps.get_model('contenttypes', 'ContentType')
    ContentType.objects.filter(model__in=MODELS_DATA, app_label=APP_LABEL).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('aac_admin', '0003_permissions'),
    ]

    operations = [
        migrations.RunPython(aac_admin_permission, reverse_aac_admin_permission)
    ]
