from enum import Enum

from django.db import models
import django.contrib.postgres.fields as pfields
from django.core.validators import RegexValidator
from django.utils.translation import ugettext_lazy as _

from aac_admin.api.v1.custom_validators import JsonValueLengthValidator

# rfc6749#section-3.3
from main import settings

SCOPE_VALUE_REGEXP_STR = "^[`~!@#$%^?&*()\-_+=|\{\}\[\]',.:;<>/0-9A-Za-z]+$"
CLIENT_ID_SECRET_VALUE_REGEXP_STR = "^[\[\]\{\}|`~:;<=?>!@#$%^&*\"()'_+\.,/\-\s0-9A-z]+$"
ALL_RESPONSE_TYPES = ['code', 'token', 'id_token', 'id_token code', 'code id_token', 'code token id_token']
CLIENT_STATUSES = {
    'A': 'Активный',
    'B': 'Заблокированный'
}


class VerboseNameMixin:
    def get_verbose_name(self):
        if self._meta.verbose_name:
            return self._meta.verbose_name
        return self


class Scope(models.Model):
    id = models.AutoField(primary_key=True)
    value = models.TextField(
        max_length=128,
        validators=[RegexValidator(SCOPE_VALUE_REGEXP_STR, message='Название скоупа содержит недопустимые символы.')])
    description = pfields.JSONField(blank=True, validators=[
        JsonValueLengthValidator(max_length=1024,
                                 message='Описание скоупа на каждом языке не должно превышать {} символов.')])

    class Meta:
        managed = False
        db_table = 'scope'
        app_label = 'aac'


class LoginForm(models.Model):
    id = models.AutoField(primary_key=True)
    descr = models.TextField('login form description')

    def __str__(self):
        return self.descr

    class Meta:
        managed = False
        db_table = 'login_forms'
        app_label = 'aac'


class UserIdProvider(models.Model):
    id = models.AutoField(primary_key=True)
    descr = models.TextField('provider description')
    aeroflot_id_base_value = models.BigIntegerField(unique=True)
    subsystem_user_id_field = models.TextField()

    def __str__(self):
        return self.descr

    class Meta:
        managed = False
        db_table = 'user_id_providers'
        app_label = 'aac'


class Client(models.Model, VerboseNameMixin):
    id = models.AutoField(primary_key=True)
    redirect_uris = pfields.ArrayField(models.TextField())
    client_salt = models.TextField()
    response_types = pfields.ArrayField(models.TextField(), default=ALL_RESPONSE_TYPES)
    client_secret = models.TextField(validators=[RegexValidator(CLIENT_ID_SECRET_VALUE_REGEXP_STR)])
    client_id = models.TextField(
        unique=True,
        validators=[RegexValidator(CLIENT_ID_SECRET_VALUE_REGEXP_STR)],
        error_messages={
            'unique': _('%(model_name)s with such a field "%(field_label)s" value already exists.')
        },
        verbose_name='Идентификатор приложения-клиента')
    policy_uri = models.TextField()
    logo_uri = models.TextField()
    tos_uri = models.TextField()
    sector_id = models.IntegerField()
    subject_type = models.TextField()
    name = pfields.JSONField(default={}, validators=[JsonValueLengthValidator(
        max_length=128,
        message='Название приложения-клиента на каждом языке не должно превышать {} символов.')])
    client_type = models.IntegerField(default=1)
    post_logout_redirect_uris = pfields.ArrayField(models.TextField())
    status = models.CharField(max_length=1, default='B')
    security_policy_id = models.IntegerField()
    token_lifetime = models.IntegerField(default=3600)
    utility_urls = pfields.JSONField(default={})
    description = pfields.JSONField(default={}, validators=[JsonValueLengthValidator(
        max_length=1024,
        message='Описание приложения-клиента на каждом языке не должно превышать {} символов.')])
    user_id_provider = models.ForeignKey(UserIdProvider, on_delete=models.SET_NULL, db_column='user_id_provider')
    login_form = models.ForeignKey(LoginForm, on_delete=models.SET_NULL, db_column='login_form')
    available_login_forms = pfields.ArrayField(models.IntegerField())

    class Meta:
        managed = False
        db_table = 'clients'
        app_label = 'aac'
        verbose_name = 'Приложение-клиент'

    def get_verbose_name(self):
        verbose_name = super().get_verbose_name()
        return f'{verbose_name} ({self.client_id})'

    @property
    def verbose_status(self):
        return CLIENT_STATUSES.get(self.status, '-')


class ClientScope(models.Model):
    client = models.ForeignKey(Client, models.CASCADE, primary_key=True)
    scope = models.ForeignKey(Scope, models.CASCADE, db_column='scope')

    class Meta:
        managed = False
        db_table = 'client_scope'
        app_label = 'aac'
        unique_together = (('client_id', 'scope'),)


class UserStatus(Enum):
    Active = 'A'
    Blocked = 'B'

    @classmethod
    def get_translated_choices(cls):
        return ((status.value, 'Активный' if status.name == 'Active' else 'Заблокированный') for status in cls)

    @staticmethod
    def default_status_value():
        return UserStatus.Active.value


class User(models.Model, VerboseNameMixin):
    id = models.AutoField(primary_key=True)
    aeroflot_id = models.BigIntegerField(unique=True)
    consents = pfields.JSONField(default=list)
    lk_user_id = models.BigIntegerField()
    last_modified = models.DateField(auto_now=True)
    status = models.CharField(max_length=1, default=UserStatus.default_status_value())

    class Meta:
        managed = False
        db_table = 'users'
        app_label = 'aac'
        verbose_name = 'Пользователь'

    def get_verbose_name(self):
        verbose_name = super().get_verbose_name()
        return f'{verbose_name} ({self.aeroflot_id}-{self.lk_user_id})'


class AACSettings(models.Model):
    name = models.TextField(primary_key=True)
    value = models.TextField()
    vtype = models.TextField()
    descr = models.TextField()

    class Meta:
        managed = False
        db_table = 'settings'
        app_label = 'aac'


class AACCaptcha(models.Model):
    id = models.AutoField(primary_key=True)
    description = pfields.JSONField(default={})
    settings = pfields.JSONField(default={})

    class Meta:
        managed = False
        db_table = 'client_security_policy'
        app_label = 'aac'


class Social(models.Model):
    id = models.AutoField(primary_key=True)
    name = pfields.JSONField()
    enabled = models.BooleanField(default=False)
    params = pfields.JSONField()
    css_class = models.TextField()
    backend_class = models.TextField(unique=True, default=None)
    siebel_id = models.TextField(unique=True)

    class Meta:
        managed = False
        db_table = 'socials'
        app_label = 'aac'

    def get_name(self):
        return settings.SOCIAL_AUTH_BACKENDS[self.backend_class]['name']


class JwkKey(models.Model, VerboseNameMixin):
    id = models.AutoField(primary_key=True)
    public = models.TextField()
    private = models.TextField()
    is_active = models.BooleanField(default=False)

    class Meta:
        managed = False
        db_table = 'jwk_keys'
        app_label = 'aac'
        ordering = ['id']
        verbose_name = 'Jwk ключ'

    def get_verbose_name(self):
        verbose_name = super().get_verbose_name()
        return f'{verbose_name} (id={self.id} kid={self.kid})'

    @property
    def kid(self):
        from Cryptodome.PublicKey import RSA
        from jwkest.jwk import RSAKey
        _key = RSA.import_key(self.private)
        usage = 'sig' if self.is_active else 'ver'
        rsa_key = RSAKey(key=_key, use=usage)
        rsa_key.add_kid()
        return rsa_key.kid

    @property
    def verbose_status(self):
        return 'Активный' if self.is_active else 'Неактивен'

    @classmethod
    def active_remains(cls, exclude_id):
        return cls.objects.filter(is_active=True).exclude(id=exclude_id).exists()
