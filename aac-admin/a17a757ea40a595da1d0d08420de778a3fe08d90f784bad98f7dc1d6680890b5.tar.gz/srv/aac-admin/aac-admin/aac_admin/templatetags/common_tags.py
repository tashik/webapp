import logging
import os
import subprocess

from django.conf import settings
from django.template.defaulttags import register
from django.utils.safestring import mark_safe


@register.simple_tag
def get_item(dictionary, key, default=None):
    if not isinstance(dictionary, dict):
        return default
    return dictionary.get(key, default)


@register.filter()
def can_view_aac_admin_model(user, model_name):
    permissions = (f'aac_admin.view_{model_name}', f'aac_admin.add_{model_name}', f'aac_admin.change_{model_name}',
                   f'aac_admin.delete_{model_name}')

    for permission in permissions:
        has_permission = user.has_perm(permission)
        if has_permission:
            return True

    return False


def get_app_revision():
    revision = os.environ.get("app_version", '')
    if not revision:
        try:
            revision = subprocess.check_output(['svnversion', settings.BASE_DIR]).decode()[:-1]
        except Exception:
            logging.exception('Error invoking svnversion command')
            revision = u'Недоступно'
    return revision


@register.simple_tag(takes_context=True)
def get_revision_label(context):
    if settings.DEBUG:
        return mark_safe(f'<div class="clearfix"><div class="revision-info">Revision: '
                         f'{ get_app_revision() }</div></div>')
    return ''
