import logging

from django.shortcuts import redirect
from social_core import exceptions
from social_django.middleware import SocialAuthExceptionMiddleware


LOG = logging.getLogger('aac_admin')


class AACSocialAuthExceptionMiddleware(SocialAuthExceptionMiddleware):

    def process_exception(self, request, exception):
        if isinstance(exception, exceptions.AuthException):
            LOG.error(exception)
            return redirect('home')

        super().process_exception(request, exception)
