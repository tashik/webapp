import logging
import os
import signal

import sys

default_app_config = 'aac_admin.apps.AacAdminConfig'


# def shutdown_logging(*args, **kwargs):
#     if os.environ.get('RUN_MAIN') == 'true':
#         logging.getLogger('aac_admin').info('AAC admin stopped')
#     sys.exit(0)
#
#
# for signal_name in ('SIGINT', 'SIGHUP'):
#     try:
#         signal.signal(getattr(signal, signal_name), shutdown_logging)
#     except AttributeError:
#         pass
