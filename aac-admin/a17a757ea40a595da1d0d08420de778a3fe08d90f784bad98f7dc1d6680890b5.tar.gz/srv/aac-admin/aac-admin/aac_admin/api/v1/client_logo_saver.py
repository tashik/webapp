import hashlib
import logging
import os.path
import requests
import urllib.parse
from datetime import datetime

from django.conf import settings

logger = logging.getLogger('aac_admin')


class LogoServiceError(Exception):
    def __init__(self, message):
        super().__init__()
        self.message = message


class WebDavStorage(object):
    @staticmethod
    def _object_urls(client_id):
        md5sum = hashlib.md5((client_id + str(datetime.now())).encode('utf-8')).hexdigest()
        return (
            urllib.parse.urljoin(settings.WEB_DAV_STORAGE_URL, md5sum + '.png'),
            urllib.parse.urljoin(settings.UPLOADED_DATA_BASE_URL, md5sum + '.png')
        )

    @classmethod
    def save(cls, object_id, object_data):
        """
        Сохраняет файл изображения на WebDAV сервер
        https://trac.com.spb.ru/afl_site/wiki/WebDav
        :param object_id: client_id клиента
        :param object_data: файл изображения
        :return: tuple(Bool, String)
        if Bool == true:
            выполнено успешно, в String - uri нового изображения
        else:
            произошла ошибка, в String - описание ошибки
        """
        try:
            web_dav_url, uploaded_data_url = cls._object_urls(object_id)
            r = requests.put(web_dav_url, data=object_data, auth=(settings.WEB_DAV_USER, settings.WEB_DAV_PASSWORD))
            if r.status_code == 201 or r.status_code == 204:
                return uploaded_data_url
            else:
                raise LogoServiceError('Неудачная загрузка изображения. Попробуйте ещё раз.')
        except requests.exceptions.RequestException:
            raise LogoServiceError('Сервис загрузки изображений временно недоступен. Попробуйте позже.')

    @staticmethod
    def delete(object_uri):
        # FIXME: удалять объект нужно по client_id, а не по URI
        image_name = object_uri.rsplit('/', 1)[-1]
        web_dav_url = urllib.parse.urljoin(settings.WEB_DAV_STORAGE_URL, image_name)
        try:
            r = requests.delete(web_dav_url, auth=(settings.WEB_DAV_USER, settings.WEB_DAV_PASSWORD))
            if r.status_code == 204:
                return f'Удалено изображение {object_uri}'
            else:
                raise LogoServiceError(f'Не получилось удалить изображение {object_uri}')
        except requests.exceptions.RequestException:
            raise LogoServiceError(f'Не удалось удалить изображение {object_uri}. Сервис временно недоступен.')


class FileStorage(object):
    @staticmethod
    def _object_urls(client_id):
        storage_dir = urllib.parse.urlparse(settings.WEB_DAV_STORAGE_URL).path
        md5sum = hashlib.md5((client_id + str(datetime.now())).encode('utf-8')).hexdigest()
        return (
            os.path.join(storage_dir, md5sum + '.png'),
            urllib.parse.urljoin(settings.UPLOADED_DATA_BASE_URL, md5sum + '.png')
        )

    @classmethod
    def save(cls, object_id, object_data):
        filename, uploaded_data_url = cls._object_urls(object_id)
        try:
            with open(filename, 'wb') as f:
                    for chunk in object_data.chunks():
                        f.write(chunk)
        except (IOError, OSError) as exc:
            raise LogoServiceError('Ошибка загрузки изображения: %s' % exc)
        return uploaded_data_url

    @staticmethod
    def delete(object_uri):
        storage_dir = urllib.parse.urlparse(settings.WEB_DAV_STORAGE_URL).path
        image_name = object_uri.rsplit('/', 1)[-1]
        filename = os.path.join(storage_dir, image_name)
        try:
            os.unlink(filename)
        except OSError:
            raise LogoServiceError(f'Не получилось удалить изображение {object_uri}')
        return f'Удалено изображение {object_uri}'


class ClientLogoSaver:
    if settings.WEB_DAV_STORAGE_URL.startswith('file:'):
        storage_driver = FileStorage()
    else:
        storage_driver = WebDavStorage()

    @classmethod
    def save_logo_image(cls, logo_image, client_id):
        try:
            return True, cls.storage_driver.save(client_id, logo_image)
        except LogoServiceError as exc:
            return False, exc.message

    @classmethod
    def delete_logo_image(cls, image_uri):
        try:
            return True, cls.storage_driver.delete(image_uri)
        except LogoServiceError as exc:
            return False, exc.message
