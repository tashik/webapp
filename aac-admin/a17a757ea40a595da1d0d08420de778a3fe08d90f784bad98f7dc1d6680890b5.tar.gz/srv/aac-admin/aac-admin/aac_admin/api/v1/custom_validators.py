import imghdr

from django.core.exceptions import ValidationError
from django.core.files.images import get_image_dimensions
from django.utils.deconstruct import deconstructible


@deconstructible
class ImageValidator(object):
    error_massages = {
        'content_type': 'Неверный формат изображения. Допустимые форматы: {image_types}.',
        'width': 'Убедитесь, что ширина изображения равна {width}. Ширина изображения: {got_width}.',
        'height': 'Убедитесь, что высота изображения равна {height}. Высота изображения: {got_height}.',
    }

    def __init__(self, image_types=(), width: int = None, height: int = None) -> None:
        self.image_types = image_types
        self.width = width
        self.height = height

    def __call__(self, image):
        if self.image_types:
            # возможны проблемы с imghdr.what, если указатель чтения файла будет не в начале
            image.seek(0)
            if imghdr.what(image) not in self.image_types:
                raise ValidationError(self.error_massages['content_type'].format(image_types=str(*self.image_types)))

        image_width, image_height = get_image_dimensions(image)

        if self.width is not None and self.width != image_width:
            raise ValidationError(self.error_massages['width'].format(width=self.width, got_width=image_width))

        if self.height is not None and self.height != image_height:
            raise ValidationError(self.error_massages['height'].format(height=self.height, got_height=image_height))

    def __eq__(self, other):
        return (
            isinstance(other, self.__class__) and
            self.image_types == other.image_types and
            self.width == other.width and
            self.height == other.height
        )


@deconstructible
class JsonValueLengthValidator(object):
    message = 'Поле превысило максимальную длину {}.'

    def __init__(self, max_length: int, message: str = None) -> None:
        self.max_length = max_length
        if message:
            self.message = message

    def __call__(self, json):
        for value in json.values():
            if value and len(value) > self.max_length:
                raise ValidationError(self.message.format(self.max_length))

    def __eq__(self, other):
        return (
            isinstance(other, self.__class__) and
            self.max_length == other.max_length and
            self.message == other.message
        )
