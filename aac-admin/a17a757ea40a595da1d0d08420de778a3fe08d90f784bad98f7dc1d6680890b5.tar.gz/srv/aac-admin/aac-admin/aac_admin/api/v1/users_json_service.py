import datetime
import re
from django.http import JsonResponse, HttpResponseBadRequest

from aac_admin.models import User

# Patterns for incoming params validation
digit_pattern = re.compile('^\d*$')
id_pattern = re.compile('^[0-9*?]*$')
DEFAULT_ITEMS_COUNT = 100
DEFAULT_OFFSET = 0


def get_users_list_json(request):
    """
    Service to get users list in JSON.

    :param request: incoming users request.
    :return: JsonResponse with data, containing link to previous page, next page and list of users.
    """
    aeroflot_id = request.GET.get('aeroflot_id')
    lk_user_id = request.GET.get('lk_user_id')
    items_count = request.GET.get('items_count')
    offset = request.GET.get('offset')
    current_url = request.get_full_path()

    try:
        data = get_users_list_dict(aeroflot_id=aeroflot_id, lk_user_id=lk_user_id, items_count=items_count,
                                   offset=offset)
    except InvalidParamsException:
        return HttpResponseBadRequest()

    data['prev'] = re.sub(str(current_url),
                          "offset=\d+",
                          "offset={}".format(data['prev']['offset'])) if data['prev'] is not None else None

    data['next'] = re.sub(str(current_url),
                          "offset=\d+",
                          "offset={}".format(data['next']['offset'])) if data['next'] is not None else None
    return JsonResponse(data, json_dumps_params={'default': datetime_handler})


def get_users_list_dict(aeroflot_id=None, lk_user_id=None, items_count=None, offset=None):
    """
    Function to get list of Users in Dictionary.

    :param aeroflot_id: mask(pattern) of aeroflot_id, where '*' means {0, inf} times and '?' means {1} times;
    :param lk_user_id: mask(pattern) of lk_user_id, where '*' means {0, inf} times and '?' means {1} times;
        EX: 1*1 is 111, 1221, 13211, etc...
        EX: 1?1 is 111, 121, 131, 141, etc...

    :param items_count: how many users to show;
    :param offset: how many users to pass;
    :return: dictionary with a previous page configuration, list of Users, next page configuration;
    """

    lk_pattern: str
    aeroflot_pattern: str

    # Validation and correction
    try:
        validate_params(aeroflot_id, lk_user_id, items_count, offset)
    except InvalidParamsException as e:
        if 'aeroflot_id' in e.invalid_params:
            if aeroflot_id == '':
                aeroflot_id = None
            elif aeroflot_id is not None:
                raise e

        if 'lk_user_id' in e.invalid_params:
            if lk_user_id == '':
                lk_user_id = None
            elif lk_user_id is not None:
                raise e

        if 'items_count' in e.invalid_params:
            items_count = DEFAULT_ITEMS_COUNT

        if 'offset' in e.invalid_params:
            offset = DEFAULT_OFFSET

    offset = int(offset)
    items_count = int(items_count)

    # Patterns creating;
    if aeroflot_id is not None:
        aeroflot_pattern = "^" + str(aeroflot_id).replace("*", "\d*").replace("?", "\d{1}") + "$"

    if lk_user_id is not None:
        lk_pattern = "^" + str(lk_user_id).replace("*", "\d*").replace("?", "\d{1}") + "$"

    # Assigning prev and next
    data = {'prev': None if offset <= 0 else {'offset': offset - items_count if offset - items_count >= 0 else 0,
                                              'items_count': items_count},
            'next': {'offset': offset + items_count,
                     'items_count': items_count}}

    # Forming items (client_models) list;
    if aeroflot_id is None:
        if lk_user_id is None:
            items = User.objects.all().order_by('aeroflot_id')[offset:items_count + offset]
        else:
            items = User.objects.extra(where=["CAST(lk_user_id as TEXT) ~ %s"], order_by=['aeroflot_id'],
                                       params=[lk_pattern])[offset:items_count + offset]
    else:
        if lk_user_id is None:
            items = User.objects.extra(where=["CAST(aeroflot_id as TEXT) ~ %s"], order_by=['lk_user_id'],
                                       params=[aeroflot_pattern])[offset:items_count + offset]
        else:
            items = User.objects.extra(where=["CAST(aeroflot_id as TEXT) ~ %s", "CAST(lk_user_id as TEXT) ~ %s"],
                                       order_by=['aeroflot_id'],
                                       params=[aeroflot_pattern, lk_pattern])[offset:items_count + offset]

    data['client_models'] = [{'id': item.id,
                              'aeroflot_id': item.aeroflot_id,
                              'lk_user_id': item.lk_user_id,
                              'consents': item.consents,
                              'last_modified': item.last_modified} for item in items]
    return data


def datetime_handler(x):
    """
    JSON doesn't support datetime, that's why it's needed to convert it into some JSON-supportable format.

    :param x: variable to be checked;
    :return: if type(x) is datetime, convert it into string by isoformat();
    """
    if isinstance(x, datetime.datetime):
        return x.isoformat()


def validate_params(aeroflot_id, lk_user_id, items_count, offset):
    invalid_params = []

    if items_count is None or items_count == '' or not (digit_pattern.match(str(items_count))):
        invalid_params.append('items_count')

    if offset is None or offset == '' or not (digit_pattern.match(str(offset))):
        invalid_params.append('offset')

    if aeroflot_id is None or aeroflot_id == '' or not id_pattern.match(str(aeroflot_id)):
        invalid_params.append('aeroflot_id')

    if lk_user_id is None or lk_user_id == '' or not id_pattern.match(str(lk_user_id)):
        invalid_params.append('lk_user_id')

    if invalid_params is None or len(invalid_params) == 0:
        return True

    else:
        message = ""
        for param in invalid_params:
            message += f'{param} is invalid; '
        raise InvalidParamsException(message, invalid_params)


class InvalidParamsException(Exception):
    def __init__(self, message, invalid_params):
        super(InvalidParamsException, self).__init__(message)
        self.invalid_params = invalid_params
