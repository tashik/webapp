import logging
from django.db import IntegrityError
from rest_framework import viewsets
from rest_framework.response import Response

from aac_admin.api.v1.serializers import ScopeSerializer
from aac_admin.models import Scope


logger = logging.getLogger('aac_admin')


class ScopesViewSet(viewsets.ModelViewSet):
    """
    API endpoint that allows scopes to be viewed or edited.
    """
    queryset = Scope.objects.all().order_by('value')
    serializer_class = ScopeSerializer
    pagination_class = None

    def create(self, request, *args, **kwargs):
        try:
            response = super().create(request, *args, **kwargs)
            request_data = request.POST.copy()
            logger.info(f"создание Scope({{'pk': '{response.data.get('id')}'}}) пользователем "
                        f"{request.user.username}: {request_data}")
            return response
        except IntegrityError:
            return Response(status=400, data={'value': ['Скоуп с таким именем уже существует.']})

    def update(self, request, *args, **kwargs):
        try:
            response = super().update(request, *args, **kwargs)
            request_data = request.POST.copy()
            logger.info(f'изменение Scope({kwargs}) пользователем {request.user.username}: {request_data}')
            return response
        except IntegrityError:
            return Response(status=400, data={'value': ['Скоуп с таким именем уже существует.']})

    def destroy(self, request, *args, **kwargs):
        response = super().destroy(request, *args, **kwargs)
        logger.info(f'удаление Scope({kwargs}) пользователем {request.user.username}')
        return response
