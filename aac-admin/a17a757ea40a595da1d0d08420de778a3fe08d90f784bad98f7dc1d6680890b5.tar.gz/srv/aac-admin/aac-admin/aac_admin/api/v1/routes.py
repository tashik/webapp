from rest_framework import routers

from aac_admin.api.v1 import views as api_views


api_router = routers.DefaultRouter()
api_router.register(r'scopes', api_views.ScopesViewSet)
