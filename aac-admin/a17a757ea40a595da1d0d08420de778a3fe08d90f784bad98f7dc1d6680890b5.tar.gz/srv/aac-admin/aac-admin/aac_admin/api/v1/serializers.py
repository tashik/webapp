from rest_framework import serializers

from aac_admin.models import Scope


class ScopeSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Scope
        fields = ('id', 'url', 'value', 'description')
        extra_kwargs = {
            'value': {
                'error_messages': {
                    'blank': 'Название скоупа не может быть пустым.',
                    'max_length': f'Название скоупа превысило максимальную длину '
                                  f'{Scope._meta.get_field("value").max_length} символов.'
                }
            }
        }
