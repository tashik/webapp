import logging
import os
from django.apps import AppConfig

from main import settings


class AacAdminConfig(AppConfig):
    name = 'aac_admin'

    def ready(self):
        if os.environ.get('RUN_MAIN') == 'true':
            logging.getLogger('aac_admin').info('AAC admin started')
        from aac_admin.models import Social
        configured_social_objects = []
        for backend_class in settings.SOCIAL_AUTH_BACKENDS:
            try:
                social = Social.objects.get(backend_class=backend_class)
            except Social.DoesNotExist:
                props = settings.SOCIAL_AUTH_BACKENDS[backend_class]
                social = Social(id=props['id'], backend_class=backend_class, siebel_id=props['siebel_id'], params={
                    'KEY': '', 'SECRET': '', 'SCOPE': ['email'], 'USER_FIELDS': ['email', 'uid']
                }, css_class=props['css_class'])
                social.save()
            configured_social_objects.append(social.id)
        db_objects = Social.objects.all()
        for db_social in db_objects:
            if db_social.id not in configured_social_objects:
                db_social.enabled = False
                db_social.save()
