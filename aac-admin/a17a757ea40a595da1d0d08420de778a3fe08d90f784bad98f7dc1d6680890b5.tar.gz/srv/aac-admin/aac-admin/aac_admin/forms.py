import ast
import json

from django import forms
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.conf import settings
from django.db import transaction
from django.forms import modelformset_factory
from django.utils import translation

from aac_admin.utils import ValidationMixin
from aac_admin.api.v1.custom_validators import ImageValidator
from aac_admin.models import (SCOPE_VALUE_REGEXP_STR, Scope, Client, CLIENT_STATUSES, ClientScope, User, AACSettings,
                              CLIENT_ID_SECRET_VALUE_REGEXP_STR, UserIdProvider, LoginForm, UserStatus, AACCaptcha,
                              Social)
from aac_admin.utils import (get_language_codes, get_all_scopes_choices, get_all_captcha_choices,
                             get_new_client_initial_captcha, get_all_login_forms)


def get_afl_bonus_add():
    return UserIdProvider.objects.get(id=1).aeroflot_id_base_value


class AsteriskRequired:
    required_css_class = 'required'


class TranslationTextArea(forms.Textarea):
    class Media:
        css = {
            'all': ('css/bootstrap-navtabs.css',)
        }
        js = ('js/bootstrap-tabs.js',)

    template_name = 'widgets/translation_text_area.html'

    def get_context(self, name, value, attrs):

        context = super().get_context(name, value, attrs)
        context['widget']['langs'] = get_language_codes()
        return context

    def value_from_datadict(self, data, files, name):
        """
        Given a dictionary of data and this widget's name, returns the value
        of this widget. Returns None if it's not provided.
        """
        result = {}
        languages = get_language_codes()
        for language in languages:
            result[language] = data.get(f'{name}_{language}')

        return result

    def format_value(self, value):
        """
        Return a value as it should appear when rendered in a template.
        """
        if value == '' or value is None:
            return {}

        if isinstance(value, dict):
            return value

        if isinstance(value, str):
            return json.loads(value)

        return {}

    def value_omitted_from_data(self, data, files, name):
        for lang, lang_translation in settings.LANGUAGES:
            if f'{name}_{lang}' not in data:
                return True

        return False


class ArrayFormatTextArea(forms.Textarea):
    def value_from_datadict(self, data, files, name):
        """
        Given a dictionary of data and this widget's name, returns the value
        of this widget. Returns None if it's not provided.
        """

        return data.get(name, '').split('\r\n')

    def format_value(self, value):
        """
        Return a value as it should appear when rendered in a template.
        """
        if value == '' or value is None:
            return ''

        if isinstance(value, list):
            return '\r\n'.join(value)

        return ''


class ScopeForm(forms.ModelForm, AsteriskRequired):
    value = forms.CharField(required=True, widget=forms.TextInput, validators=[RegexValidator(SCOPE_VALUE_REGEXP_STR)])
    description = forms.Field(widget=TranslationTextArea(attrs={'class': 'noresize input__textarea-input'}))

    class Meta:
        model = Scope
        fields = '__all__'
        localized_fields = '__all__'


class ClientForm(forms.ModelForm, AsteriskRequired):
    # TODO: Изменить параметр 'cols' под адаптивную верстку для всех TextArea, т.к. выходит за пределы окна.
    name = forms.Field(label='Название', widget=TranslationTextArea(attrs={'cols': 65,
                                                                           'class': 'noresize input__textarea-input'}),
                       required=True)
    redirect_uris = forms.Field(label='Разрешенные ссылки после аутентификации пользователя',
                                required=True,
                                widget=ArrayFormatTextArea(attrs={'cols': 65,
                                                                  'class': 'noresize input__textarea-input'}))
    response_types = forms.Field(widget=forms.Textarea, required=False)
    post_logout_redirect_uris = forms.Field(label='Разрешенные ссылки после выхода пользователя', required=True,
                                            widget=ArrayFormatTextArea(
                                                attrs={'cols': 65, 'class': 'noresize input__textarea-input'}))
    description = forms.Field(label='Описание',
                              widget=TranslationTextArea(attrs={'cols': 65, 'class': 'noresize input__textarea-input'}),
                              required=True)
    status = forms.ChoiceField(label='Статус приложения-клиента', choices=(('A', CLIENT_STATUSES['A']),
                                                                           ('B', CLIENT_STATUSES['B'])),
                               initial='B')
    client_id = forms.Field(label='Идентификатор приложения-клиента', required=True,
                            validators=[RegexValidator(CLIENT_ID_SECRET_VALUE_REGEXP_STR)])
    client_secret = forms.Field(label='Пароль приложения-клиента', required=True,
                                validators=[RegexValidator(CLIENT_ID_SECRET_VALUE_REGEXP_STR)])
    client_type = forms.ChoiceField(label='Тип приложения-клиента', choices=((1, 'Публичное'), (2, 'Конфиденциальное')),
                                    initial=1)
    scopes = forms.MultipleChoiceField(label='Скоупы', widget=forms.CheckboxSelectMultiple,
                                       choices=get_all_scopes_choices, required=False)
    user_id_provider = forms.ModelChoiceField(UserIdProvider.objects.all(), empty_label=None,
                                              label='Идентификация пользователя')
    login_form = forms.ModelChoiceField(LoginForm.objects.all(), empty_label=None,
                                        label='Форма входа пользователя по умолчанию')
    logo_image = forms.FileField(required=False, label='Изображение формата PNG размером 128x128px',
                                 validators=[ImageValidator(['png'], 128, 128)])
    token_lifetime = forms.IntegerField(required=True, label='Время жизни токена (сек)', min_value=0, initial=3600)
    security_policy_id = forms.ChoiceField(label='Политика безопасности приложения-клиента', widget=forms.Select,
                                           initial=lambda: get_new_client_initial_captcha().id,
                                           choices=get_all_captcha_choices, required=False)
    available_login_forms = forms.MultipleChoiceField(label='Доступные формы входа пользователя',
                                                      widget=forms.CheckboxSelectMultiple,
                                                      choices=get_all_login_forms, required=False)

    class Meta:
        model = Client
        fields = ('name', 'description', 'redirect_uris', 'status', 'client_id', 'client_secret', 'client_type',
                  'post_logout_redirect_uris', 'user_id_provider', 'login_form', 'available_login_forms',
                  'logo_image', 'token_lifetime', 'security_policy_id')

    def save(self, commit=True):
        instance = super().save(commit)
        client_scopes = ClientScope.objects.filter(client_id=instance.id)
        form_scopes = self.cleaned_data.get('scopes', [])
        scopes = dict((scope.value, scope) for scope in Scope.objects.all())

        with transaction.atomic():
            for client_scope in client_scopes:
                if client_scope.scope.value not in form_scopes:
                    client_scope.delete()

            for form_scope in form_scopes:
                ClientScope.objects.get_or_create(client=instance, scope=scopes[form_scope])

        return instance

    def get_initial_for_field(self, field, field_name):
        initial = super().get_initial_for_field(field, field_name)
        client_id = self.initial.get('client_id')
        if field_name == 'scopes' and client_id:
            client_scopes = ClientScope.objects.filter(client__client_id=client_id)
            initial = [client_scope.scope.value for client_scope in client_scopes]

        return initial

    def clean_available_login_forms(self):
        result = []
        for item in self.cleaned_data['available_login_forms']:
            try:
                result.append(int(item))
            except ValueError:
                pass
        return result


class ConsentsSelectMultiple(forms.CheckboxSelectMultiple):
    def format_value(self, value):
        """
        Return a value as it should appear when rendered in a template.
        """

        if isinstance(value, list):
            return value

        if isinstance(value, str):
            return json.loads(value)

        return {}


def get_consents_choices(form):
    """
    Function needed to get consents into choices format, acceptable by Django ChoiceField class.
    :param form: UserForm
    :return: list of choices in format ((id, name), (id, name),...)
    """
    consents = form.instance.consents
    json_list_of_choices = list()
    for dictionary in consents:
        client = Client.objects.filter(id=dictionary.get('id')).first()
        if client is not None:
            json_list_of_choices.append((dictionary.get('id'),
                                         client.name.get(translation.get_language())))

    return json_list_of_choices


class UserForm(forms.ModelForm, AsteriskRequired):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['consents'].choices = get_consents_choices(self)

    aeroflot_id = forms.IntegerField(label='Aeroflot ID', required=False, disabled=True,
                                     widget=forms.TextInput(attrs={'readonly': 'readonly'}))
    lk_user_id = forms.IntegerField(label='ID пользователя ЛК', required=False, disabled=True)
    status = forms.ChoiceField(label='Статус', choices=UserStatus.get_translated_choices(),
                               initial=UserStatus.default_status_value())
    consents = forms.MultipleChoiceField(label='Согласия', required=False,
                                         widget=ConsentsSelectMultiple(attrs={"checked": "True", "class": "checkbox"}))

    class Meta:
        model = User
        fields = ('aeroflot_id', 'lk_user_id', 'status', 'consents')

    def save(self, commit=True):
        if self.cleaned_data.get('consents'):
            input_consents = list(map(int, self.cleaned_data.get('consents')))
            initial_consents = self.initial.get('consents')
            result_list = list()
            for initial_consent in initial_consents:
                if initial_consent.get('id') in input_consents:
                    result_list.append(initial_consent)

            self.instance.consents = result_list

        return super().save(commit)

    def clean_aeroflot_id(self):
        if self.instance and self.instance.aeroflot_id is not None:
            return str(self.instance.aeroflot_id)

        return 0


class AACSettingsForm(forms.ModelForm, ValidationMixin):
    descr = forms.Field(
        required=False,
        disabled=True
    )

    class Meta:
        model = AACSettings
        fields = ('name', 'value', 'descr', 'vtype')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly'}),
            'value': forms.TextInput(attrs={'class': 'form-control', 'required': True}),
            'descr': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly'}),
            'vtype': forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly'}),
        }

    def clean_value(self):
        type_validation = {'int': self._is_int,
                           'float': self._is_float,
                           'str': self._is_string,
                           'bool': self._is_boolean,
                           'json': self._is_json,
                           'url': self._is_url}

        value = self.cleaned_data.get('value')
        current_type = self.instance.vtype
        if not type_validation[current_type](value):
            self.add_error('value',
                           f'Значение переменной {self.instance.name} не соответствует '
                           f'заданному типу {self.instance.vtype}.')
        return value


class CaptchaJsonSettingsWidget(forms.Widget):
    template_name = 'widgets/captcha_json_settings_widget.html'

    def format_value(self, value):
        """
        Return a value as it should appear when rendered in a template.
        """
        if value == '' or value is None:
            return {}

        if isinstance(value, list):
            return value

        if isinstance(value, dict):
            return value

        if isinstance(value, str):
            return json.loads(value)

        return {}


class AACCaptchaForm(forms.ModelForm, ValidationMixin):
    id = forms.Field(label='Идентификатор', disabled=True, widget=forms.TextInput(
        attrs={'readonly': 'readonly', 'label': 'Идентификатор', 'class': 'form-control'}), required=False)
    description = forms.Field(label='Описание', disabled=True, widget=forms.TextInput(
        attrs={'readonly': 'readonly', 'label': 'Описание', 'class': 'form-control'}), required=False)
    settings = forms.Field(widget=CaptchaJsonSettingsWidget(), required=False)

    non_negative_setting_params = ('period', 'attempts')

    class Meta:
        model = AACCaptcha
        fields = ('id', 'description', 'settings')

    def get_initial_for_field(self, field, field_name):
        initial = super().get_initial_for_field(field, field_name)
        if field_name == 'description':
            if isinstance(initial, dict):
                initial = initial['ru']
        return initial

    def clean_settings(self):
        type_validation = {
            'int': self._is_int,
            'text': self._is_string,
            'date': self._is_date,
            'datetime': self._is_datetime,
            'time': self._is_time
        }
        settings_value = self.cleaned_data.get('settings')
        if settings_value == '' or settings_value is None:
            return self.initial['settings']
        settings_value = json.loads(settings_value)
        for setting_name, setting_params in settings_value.items():
            current_type = settings_value[setting_name]['type']
            value = settings_value[setting_name]['value']

            if not type_validation[current_type](value):
                self.add_error('settings',
                               f'Значение по ключу {setting_name} не соответствует '
                               f'заданному типу {current_type}.')
            elif setting_name in self.non_negative_setting_params and current_type == 'int' \
                    and not self._is_non_negative_int(value):
                self.add_error('settings', f'Значение по ключу {setting_name} не может быть отрицательным.')
        return settings_value

    def clean_description(self):
        return self.cleaned_data.get('description')


AACSettingFormset = modelformset_factory(AACSettings, form=AACSettingsForm, extra=0)


class SocialParamsWidget(forms.Widget):

    template_name = 'widgets/social_params.html'

    def __init__(self, *args, **kwargs):
        super(SocialParamsWidget, self).__init__(*args, **kwargs)

    def format_value(self, value):
        return value

    def value_from_datadict(self, data, files, name):
        result = {}
        for key in data:
            if key.startswith(name + '_'):
                values = data.getlist(key)
                if len(values) == 2 and values[0] and values[1]:
                    try:
                        val = ast.literal_eval(values[1])
                    except Exception:
                        val = values[1]
                    result[values[0]] = val
        return result


class SocialParamsField(forms.Field):
    widget = SocialParamsWidget


class SocialForm(forms.ModelForm, AsteriskRequired):
    name = forms.Field(widget=TranslationTextArea(attrs={'cols': 65, 'class': 'noresize input__textarea-input'}),
                       required=True)
    enabled = forms.BooleanField(required=False)
    css_class = forms.Field(required=False, widget=forms.TextInput(), label='CSS class')
    params = SocialParamsField(required=False)

    class Meta:
        model = Social
        fields = ('name', 'enabled', 'css_class', 'params')
