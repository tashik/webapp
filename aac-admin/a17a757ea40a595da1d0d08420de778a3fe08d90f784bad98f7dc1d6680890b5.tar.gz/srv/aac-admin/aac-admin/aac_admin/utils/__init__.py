import datetime
import json
import urllib.parse as urlparse

from django.conf import settings

from aac_admin.models import Scope, LoginForm, AACCaptcha


def get_language_codes():
    return settings.TRANSLATION_TEXT_LANGUAGES


def get_all_scopes_choices():
    all_scopes = Scope.objects.all()
    return [(scope.value, scope.value) for scope in all_scopes]


def get_all_login_forms():
    return [(login_form.id, login_form.descr) for login_form in LoginForm.objects.all()]


def get_all_captcha_choices():
    all_captcha = AACCaptcha.objects.all().order_by('id')
    return [(captcha.id, captcha.description.get('ru', '')) for captcha in all_captcha]


def get_new_client_initial_captcha():
    return AACCaptcha.objects.get(id=1)


class ValidationMixin:
    def _is_non_negative_int(self, value):
        return value.isdigit()

    def _is_int(self, value):
        if value.startswith('-'):
            value = value[1:]
        return value.isdigit()

    def _is_float(self, value):
        try:
            return float(value) and '.' in value
        except ValueError:
            return False

    def _is_string(self, value):
        return isinstance(value, str)

    def _is_boolean(self, value):
        return value in ('True', 'False')

    def _is_json(self, value):
        try:
            value = json.loads(value)
        except (ValueError, TypeError):
            return False
        return True

    def _is_url(self, value):
        url = urlparse.urlparse(value)
        if url.scheme and url.netloc:
            return True
        return False

    def _is_date(self, value):
        try:
            datetime.datetime.strptime(value, '%d.%m.%Y')
        except ValueError:
            return False
        return True

    def _is_datetime(self, value):
        try:
            datetime.datetime.strptime(value, '%d.%m.%Y %H:%M')
        except ValueError:
            return False
        return True

    def _is_time(self, value):
        try:
            datetime.datetime.strptime(value, '%H:%M')
        except ValueError:
            return False
        return True
