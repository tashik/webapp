import base64
import json
import re
from datetime import datetime

import redis
from django.conf import settings

from aac_admin.models import CLIENT_ID_SECRET_VALUE_REGEXP_STR

T_TOKEN_MATCH = 'T-*'

REDIS_CLIENT = redis.StrictRedis(host=settings.REDIS_HOST, port=settings.REDIS_PORT, db=settings.REDIS_DB)

special_chars = re.compile(r'([!@#$%&\'\"+\-.,^`|~:\[\]{}()/=<>;])')
slashes = re.compile(r'(\\(?![?*]))')
star = re.compile(r'(?<!\\)(\*)')
question = re.compile(r'(?<!\\)(\?)')


class TokenList:
    @staticmethod
    def _escape_chars(s):
        s = slashes.sub(r'\\\\', s)        # экранирует \, после которых нет * или ?
        s = special_chars.sub(r'\\\1', s)  # экранирует все спец символы, кроме \
        s = star.sub(r'.\1', s)            # *, перед которой нет \, заменяется на .*
        s = question.sub('.', s)           # ?, перед которым нет \, заменяется на .
        return s

    @classmethod
    def _create_text_validator(cls, field, regex):
        if field and re.search(regex, field):
            field = cls._escape_chars(field)
            regex_validator = re.compile('^{}$'.format(field))
            return lambda val: regex_validator.match(val) if val else False
        else:
            return lambda val: True

    @staticmethod
    def _create_date_validator(date_range, first_date, second_date):
        if date_range in ('before', 'after', 'between'):
            try:
                first_date = int(datetime.strptime(first_date, '%Y-%m-%dT%H:%M').timestamp())
                if date_range == 'before':
                    return lambda val: int(val) < first_date
                elif date_range == 'after':
                    return lambda val: first_date < int(val)
                elif date_range == 'between':
                    second_date = int(datetime.strptime(second_date, '%Y-%m-%dT%H:%M').timestamp())
                    if first_date <= second_date:
                        return lambda val: first_date <= int(val) <= second_date
                    else:
                        return lambda val: True
            except (TypeError, ValueError):
                return lambda val: True
        else:
            return lambda val: True

    @classmethod
    def _create_filters(cls, filters):
        return [
            cls._create_text_validator(filters.get('client_id'), CLIENT_ID_SECRET_VALUE_REGEXP_STR),
            cls._create_text_validator(filters.get('aeroflot_id'), '^[0-9*?]+$'),
            cls._create_date_validator(filters.get('iat_range'), filters.get('iat1'), filters.get('iat2')),
            cls._create_date_validator(filters.get('exp_range'), filters.get('exp1'), filters.get('exp2'))
        ]

    @staticmethod
    def parse_token_payload(token):
        if not token:
            return {}
        token_split = token.split('.')
        if not token_split or len(token_split) < 2:
            return {}

        payload = token_split[1]
        missing_padding = len(payload) % 4
        if missing_padding:
            payload += (4 - missing_padding) * '='
        return json.loads(base64.urlsafe_b64decode(payload))

    @staticmethod
    def _timestamp_to_date_str(timestamp):
        return datetime.fromtimestamp(int(timestamp)).strftime('%d-%m-%Y %H:%M:%S') if timestamp else ''

    @classmethod
    def get_tokens_by_aeroflot_id(cls, aeroflot_id):
        sessions = REDIS_CLIENT.zrange(aeroflot_id, 0, -1)
        tokens = []
        pipe = REDIS_CLIENT.pipeline()
        [pipe.get(sid) for sid in sessions]
        for sid, sid_info in zip(sessions, pipe.execute()):
            if not sid_info:
                continue
            sid_info = json.loads(sid_info)
            access_token = cls.parse_token_payload(sid_info.get('access_token'))
            if not access_token:
                continue
            tokens.append({
                'jti': access_token.get('jti'),
                'session_id': sid.decode('ascii'),
                'client_id': access_token.get('azp'),
                'aeroflot_id': access_token.get('sub'),
                'iat': cls._timestamp_to_date_str(access_token.get('iat')),
                'exp': cls._timestamp_to_date_str(access_token.get('exp')),
                'iat_int': int(access_token.get('iat'))
            })
        return tokens

    @classmethod
    def new_token_list(cls, cursor, count, parameters):
        def retrieve_data(pipe):
            nonlocal cursor, t_tokens, session_ids
            cursor, t_tokens = pipe.scan(match=T_TOKEN_MATCH, cursor=cursor, count=count)

            pipe.multi()
            [pipe.get(t_token) for t_token in t_tokens]
            session_ids = pipe.execute()
            [pipe.get(session_id) for session_id in session_ids]

        filters = cls._create_filters(parameters)
        tokens = []
        t_tokens, session_ids, session_id_info = None, None, None
        while True:
            session_id_info = REDIS_CLIENT.transaction(retrieve_data, T_TOKEN_MATCH)
            for jti, session_id, info in zip(t_tokens, session_ids, session_id_info):
                if info:
                    info = json.loads(info)
                else:
                    continue
                parsed_token = cls.parse_token_payload(info.get('access_token'))
                new_token = {
                    'jti': jti.decode('ascii'),
                    'session_id': session_id.decode('ascii'),
                    'client_id': parsed_token.get('azp'),
                    'aeroflot_id': parsed_token.get('sub'),
                    'iat': parsed_token.get('iat'),
                    'exp': parsed_token.get('exp')
                }
                if not all(validate(field) for validate, field in zip(filters, list(new_token.values())[2:])):
                    continue

                new_token['iat'] = cls._timestamp_to_date_str(new_token['iat'])
                new_token['exp'] = cls._timestamp_to_date_str(new_token['exp'])
                tokens.append(new_token)
            if cursor == 0 or len(tokens) >= count:
                break
        return cursor, tokens


def delete_sessions_by_aeroflot_id(aeroflot_id):
    sessions = REDIS_CLIENT.zrange(aeroflot_id, 0, -1)
    REDIS_CLIENT.delete(aeroflot_id)
    if not sessions:
        return []
    REDIS_CLIENT.delete(*sessions)
    cursor = 0
    pipe = REDIS_CLIENT.pipeline()
    jti_list = []
    while True:
        cursor, t_tokens = REDIS_CLIENT.scan(match=T_TOKEN_MATCH, cursor=cursor)
        [pipe.get(t_token) for t_token in t_tokens]
        sessions_ids = pipe.execute()
        for jti, sid in zip(t_tokens, sessions_ids):
            if sid in sessions:
                pipe.delete(jti)
                jti_list.append(jti)
        pipe.execute()
        if cursor == 0:
            break
    return zip(sessions, jti_list)


def delete_client_sessions_for_users(client_id, aeroflot_ids: list):
    pipe = REDIS_CLIENT.pipeline()
    for aeroflot_id in aeroflot_ids:
        sessions = REDIS_CLIENT.zrange(aeroflot_id, 0, -1)
        [pipe.get(sid) for sid in sessions]
        for sid, sid_info in zip(sessions, pipe.execute()):
            try:
                sid_info = json.loads(sid_info)
                if sid_info.get('client_id') == client_id:
                    access_token = TokenList.parse_token_payload(sid_info.get('access_token'))
                    pipe.delete(sid).zrem(aeroflot_id, sid).delete(access_token.get('jti'))
            except (TypeError, json.JSONDecodeError):
                pass
        pipe.execute()


def delete_user_tokens_by_client_ids(aeroflot_id, client_ids: list):
    if not client_ids:
        return []
    pipe = REDIS_CLIENT.pipeline()
    sessions = REDIS_CLIENT.zrange(aeroflot_id, 0, -1)
    [pipe.get(sid) for sid in sessions]
    sessions_info = pipe.execute()
    [pipe.ttl(sid) for sid in sessions]
    sessions_ttl = pipe.execute()
    result = []
    for sid, sid_info, sid_ttl in zip(sessions, sessions_info, sessions_ttl):
        try:
            sid_info = json.loads(sid_info)
            client_id = sid_info.get('client_id')
            if client_id in client_ids:
                access_token = TokenList.parse_token_payload(sid_info.pop('access_token', ''))
                jti = access_token.get('jti')
                pipe.delete(jti)
                result.append((sid, jti, client_id))
                if sid_ttl > 0:
                    pipe.set(sid, json.dumps(sid_info), ex=sid_ttl)
        except (TypeError, json.JSONDecodeError):
            pass
    pipe.execute()
    return result


def delete_all_client_sessions_for_users(client_id, count=100):
    pipe = REDIS_CLIENT.pipeline()
    cursor = 0
    result = []
    while True:
        cursor, t_tokens = REDIS_CLIENT.scan(cursor=cursor, match=T_TOKEN_MATCH, count=count)
        if not t_tokens:
            break
        [pipe.get(jti) for jti in t_tokens]
        sessions = pipe.execute()
        [pipe.get(sid) for sid in sessions]
        sessions_info = pipe.execute()
        for jti, sid, sid_info in zip(t_tokens, sessions, sessions_info):
            if not sid_info:
                continue
            try:
                sid_info = json.loads(sid_info)
            except (TypeError, json.JSONDecodeError):
                continue
            access_token = TokenList.parse_token_payload(sid_info.get('access_token'))
            if not access_token:
                continue
            try:
                if client_id in access_token['aud']:
                    aeroflot_id = access_token.get('sub')
                    pipe.delete(sid).zrem(aeroflot_id, sid).delete(jti)
                    result.append((sid, jti, aeroflot_id))
            except KeyError:
                continue
        pipe.execute()
        if cursor == 0:
            break
    return result
