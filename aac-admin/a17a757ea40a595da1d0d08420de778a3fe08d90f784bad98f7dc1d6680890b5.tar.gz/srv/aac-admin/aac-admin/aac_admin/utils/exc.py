from enum import Enum

from auth import exc as auth_exc
from aac_admin import exc as admin_exc


class AvailableExceptions(Enum):
    UnknownError = admin_exc.UnknownError
    SocialAccessDeniedError = auth_exc.SocialAccessDeniedError
    SocialInactiveUserError = auth_exc.SocialInactiveUserError
