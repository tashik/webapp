from django import forms
from django.core.exceptions import ObjectDoesNotExist
from django.contrib import admin
from django.contrib.auth import authenticate
from django.contrib.auth.admin import UserAdmin, GroupAdmin
from django.contrib.admin.forms import AdminAuthenticationForm
from django.contrib.auth.models import User, Group
from django.utils.translation import gettext_lazy as _


class CustomAdminAuthenticationForm(AdminAuthenticationForm):
    """
    См. https://code.djangoproject.com/ticket/28645.
    Станет deprecated в Django 2.1.
    """
    error_messages = {
        'invalid_login': _(
            "Please enter a correct %(username)s and password. Note that both "
            "fields may be case-sensitive."
        ),
        'inactive': _("This account is inactive."),
    }

    def clean(self):
        username = self.cleaned_data.get('username')
        password = self.cleaned_data.get('password')

        if username is not None and password:
            self.user_cache = authenticate(self.request, username=username, password=password)
            if self.user_cache is None:
                try:
                    user = User.objects.get(username=username)
                except ObjectDoesNotExist:
                    user = None
                if user is not None:
                    if user.check_password(password):
                        self.confirm_login_allowed(user)
                raise forms.ValidationError(
                    self.error_messages['invalid_login'],
                    code='invalid_login',
                    params={'username': self.username_field.verbose_name},
                )

        return self.cleaned_data

    def confirm_login_allowed(self, user):
        if not user.is_active:
            raise forms.ValidationError(
                self.error_messages['inactive'],
                code='inactive',
                params={'username': self.username_field.verbose_name}
            )


class AdminLoginSite(admin.AdminSite):
    login_form = CustomAdminAuthenticationForm
    site_header = "Администрирование ЕЦА"

    def each_context(self, request):
        # Copy-pasted and modified;
        context = super().each_context(request)
        context['is_popup'] = False  # is_popup exception solver;
        return context


class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'is_active')


admin.site = AdminLoginSite()
admin.site.register(User, CustomUserAdmin)
admin.site.register(Group, GroupAdmin)
