# конфиг для запуска manage.py collectstatic при отсутствии БД
import config
config.SECRET_KEY = '123'

# aac_admin обращается к БД при инициализации (aac_admin.apps.AacAdminConfig#ready)
config.INSTALLED_APPS.remove('aac_admin')
from config import *
