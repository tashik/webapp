from config import *
validate_config()
