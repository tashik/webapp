# переопределение параметров конфига для тестов
import config
config.SECRET_KEY = '123'
config.WEB_DAV_STORAGE_URL = 'http://localhost:8085/data/'
config.UPLOADED_DATA_BASE_URL = 'https://aac-aeroflot.test/data/'

from config import *
