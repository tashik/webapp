"""aac_admin URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.contrib.auth.decorators import login_required
from django.urls import path, include

from aac_admin.api.v1.routes import api_router
from aac_admin.api.v1 import users_json_service
from aac_admin import views
from aac_admin.views import scopes as scopes_views, aac_captcha
from aac_admin.views import clients as clients_views
from aac_admin.views import socials as socials_views
from aac_admin.views import users as users_views
from aac_admin.views import tokens as tokens_views
from aac_admin.views import aac_settings as aac_settings_view
from aac_admin.views import monitoring as monitoring_views
from aac_admin.views import jwk_keys as jwk_views
from aac_admin.views import caches as caches_views

urlpatterns = [
    path('admin/', views.root_view, name='home'),
    path('admin/users/get_users', login_required(users_json_service.get_users_list_json), name='users_list'),
    path('admin/users/user_list_html/', users_views.user_list_html, name='user_list_html'),
    path('admin/error', views.ErrorView.as_view(), name='error'),
    path('admin/scopes/', login_required(scopes_views.ScopesView.as_view()), name='scopes'),
    path('admin/clients/', login_required(clients_views.ClientsView.as_view()), name='clients'),
    path('admin/clients/add/', login_required(clients_views.ClientAddView.as_view()), name='client_add'),
    path('admin/clients/<int:pk>/', login_required(clients_views.ClientUpdateView.as_view()), name='client_update'),
    path('admin/clients/<int:pk>/delete/', login_required(clients_views.ClientDeleteView.as_view()),
         name='client_delete'),
    path('admin/users/', login_required(users_views.users_view), name='users'),
    path('admin/users/add/', login_required(users_views.UserAddView.as_view()), name='user_add'),
    path('admin/users/<int:pk>/', login_required(users_views.UserUpdateView.as_view()), name='user_update'),
    path('admin/users/user_tokens/', users_views.user_tokens, name='user_tokens'),
    path('admin/users/<int:pk>/delete/', login_required(users_views.UserDeleteView.as_view()), name='user_delete'),
    path('admin/tokens/', login_required(tokens_views.tokens_view), name='tokens'),
    path('admin/tokens/token_list_html/', tokens_views.token_list_html, name='token_list_html'),
    path('admin/tokens/<str:session_id>/<str:jti>/<str:aeroflot_id>/delete/',
         login_required(tokens_views.TokenDeleteView.as_view()), name='token_delete'),
    path('admin/admin/', admin.site.urls),
    path('admin/login/', views.login_view, name='login'),
    path('admin/logout/', views.logout_view, name='logout'),
    path('admin/logout/callback', views.logout_callback_view, name='logout_callback'),
    path('admin/oauth/', include('social_django.urls', namespace='social')),
    path('admin/settings/', login_required(aac_settings_view.AACSettingsView.as_view()), name='aac_settings'),
    path('admin/captcha/', login_required(aac_captcha.AACCaptchaView.as_view()), name='aac_captcha'),
    path('admin/captcha/<int:pk>/', login_required(aac_captcha.AACCaptchaSettingsView.as_view()),
         name='aac_captcha_settings'),
    path('admin/socials/', login_required(socials_views.SocialsView.as_view()), name='socials'),
    path('admin/socials/<int:pk>/', login_required(socials_views.SocialUpdateView.as_view()), name='social_update'),
    path('admin/jwk_keys/', login_required(jwk_views.JwkKeysView.as_view()), name='jwk_keys'),
    path('admin/jwk_keys/add/', login_required(jwk_views.jwk_key_add_view), name='jwk_key_add'),
    path('admin/jwk_keys/<int:pk>/', jwk_views.JwkKeyUpdateView.as_view(), name='jwk_key_update'),
    path('admin/jwk_keys/<int:pk>/delete/', login_required(jwk_views.JwkKeyDeleteView.as_view()),
         name='jwk_key_delete'),
    path('admin/caches/', login_required(caches_views.CachesView.as_view()), name='caches'),

    # API:V1
    path('admin/api/v1/', include(api_router.urls)),

    # Monitoring
    path('admin/monitoring/status', monitoring_views.StatusView.as_view(), name='monitoring_status'),
    path('admin/monitoring/ping', monitoring_views.PingView.as_view(), name='monitoring_ping'),
]
