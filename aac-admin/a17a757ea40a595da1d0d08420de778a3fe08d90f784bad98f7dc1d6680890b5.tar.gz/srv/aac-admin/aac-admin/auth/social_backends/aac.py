from jwkest.jwk import KEYS
from social_core.backends.open_id_connect import OpenIdConnectAuth
from social_core.utils import cache
from django.conf import settings


class AACOICAuth(OpenIdConnectAuth):
    """AAC oidc"""
    name = 'aac'
    AUTHORIZATION_URL = settings.AAC_AUTHORIZATION_URL
    ACCESS_TOKEN_URL = settings.AAC_ACCESS_TOKEN_URL
    USERINFO_URL = settings.AAC_USERINFO_URL
    JWKS_URI = settings.AAC_JWKS_URI
    ID_TOKEN_ISSUER = settings.AAC_ID_TOKEN_ISSUER

    def auth_complete_params(self, state=None):
        client_id, client_secret = self.get_key_and_secret()
        return {
            'grant_type': 'authorization_code',  # request auth code
            'code': self.data.get('code', ''),  # server response code
            'client_id': client_id,
            'redirect_uri': self.get_redirect_uri(state)
        }

    def auth_complete_credentials(self):
        return self.get_key_and_secret()

    def get_user_details(self, response):
        """Return user details from AAC account"""
        return {'username': response.get('login'),
                'email': response.get('email') or '',
                'first_name': response.get('name')}

    def request_access_token(self, *args, **kwargs):
        """
        Retrieve the access token. Also, validate the id_token and
        store it (temporarily).
        """
        response = self.get_json(*args, **kwargs)
        id_token = response.get('id_token')
        if id_token:
            self.id_token = self.validate_and_return_id_token(response['id_token'])
        return response

    @cache(settings.JWKS_CACHE_TTL)
    def get_jwks_keys(self):
        keys = KEYS()
        keys.load_from_url(self.jwks_uri())
        # Add client secret as oct key so it can be used for HMAC signatures
        client_id, client_secret = self.get_key_and_secret()
        keys.add({'key': client_secret, 'kty': 'oct'})
        return keys
