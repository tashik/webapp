from aac_admin.exc import AACAdminError


class SocialAccessDeniedError(AACAdminError):
    code = '999001001'
    msg = 'Access denied'


class SocialInactiveUserError(AACAdminError):
    code = '999001002'
    msg = 'Inactive user'
