import base64
import json
from urllib.parse import urlencode
from django.shortcuts import redirect, resolve_url
from auth.social_backends.aac import AACOICAuth

from auth.exc import SocialAccessDeniedError


def get_aac_user(backend, uid, *args, **kwargs):
    user = backend.strategy.get_user(username=uid)
    if not user:
        params = urlencode({'error_code': SocialAccessDeniedError.code})
        return redirect(f'{resolve_url("error")}?{params}')

    return {'user': user}


def get_aac_username(backend, uid, *args, **kwargs):
    """ Return unique username for AAC provider
    """
    if isinstance(backend, AACOICAuth) and isinstance(uid, int):
        return {'username': str(uid)}


def session_expiry(user, backend, uid, *args, **kwargs):
    try:
        access_token = user.social_auth.get().extra_data['access_token']
        payload = access_token.split('.')[1]
        payload = base64.urlsafe_b64decode(payload + '=' * (-len(payload) % 4))
        payload = json.loads(payload)
        social = kwargs.get('social') or backend.strategy.storage.user.get_social_auth(backend.name, uid)
        if social:
            social.extra_data['expires'] = payload['exp']
    except (KeyError, IndexError, ValueError, TypeError, json.decoder.JSONDecodeError):
        pass  # session reverts to using the global session expiry policy
